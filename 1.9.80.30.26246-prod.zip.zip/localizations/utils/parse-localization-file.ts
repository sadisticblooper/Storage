const plfFs: typeof import('node:fs') = require('node:fs');

const protobuf: typeof import('protobufjs') = require('protobufjs');

function parseLocalizationFile(localePath: string, dtoPath: string): Record<string, string> {
    const root = protobuf.loadSync(dtoPath);
    const LocalizationDTO = root.lookupType("LocalizationDTO");
    const decoded = LocalizationDTO.decode(plfFs.readFileSync(localePath)) as protobuf.Message & { localizations: Record<string, { value: string }> };
    return Object.fromEntries(Object.entries(decoded.localizations).map(([key, message]) => [key, message.value]))
}
