const fs = require('node:fs');
const path = require('node:path');

const SOURCE = 'https://files.airflow.nekki.com/works/sfa_automated_tasks/percentiles_for_leaderboards/result.txt';
const OUTPUT = path.resolve('configs', 'scripts', 'features', 'leaderboard', 'leaderboard-percentile-table.ts');

async function main() {
  const response = await fetch(SOURCE);
  if (!response.ok) {
    throw new Error(`HTTP error: ${response.status}`);
  }

  const result = await response.text();

  const fileContent = [
    "/** Don't edit this file manually; run `npm run update_leaderboard_percentiles` instead. */",
    "",
    "const LEADERBOARD_PERCENTILE_TABLE = {",
    result,
    "};"
  ].join('\n');

  fs.writeFileSync(OUTPUT, fileContent);
}

main();
