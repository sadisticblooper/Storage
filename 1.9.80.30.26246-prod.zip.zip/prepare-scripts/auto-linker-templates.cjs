module.exports.REGION_RULES = [
    // regExp for region, [regExps for filePath]

    [new RegExp("LiveOps: visual for roulette"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/roulette/visual.ts"),
    ]],

    [new RegExp("LiveOps: visual for tournaments"), [
        new RegExp("features/monetization/activities/([\\s\\S]+?)/tournaments/visual.ts"),
        new RegExp("features/monetization/events/([\\s\\S]+?)/tournaments/visual.ts"),
    ]],

    [new RegExp("LiveOps: visual for marathons"), [
        new RegExp("features/monetization/activities/([\\s\\S]+?)/marathons/visual.ts"),
        new RegExp("features/monetization/events/([\\s\\S]+?)/marathons/visual.ts"),
    ]],

    [new RegExp("LiveOps: visual for gacha"), [
        new RegExp("features/monetization/liveops-blocks/classic/gacha-banners/visual/presets/(([A-z0-9_-])*?)visual.ts"),
    ]],

    [new RegExp("LiveOps: event's common visual"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/visual.ts"),
    ]],

    [new RegExp("LiveOps: rewards for tournaments"), [
        new RegExp("features/monetization/activities/([\\s\\S]+?)/tournaments/rewards.ts"),
        new RegExp("features/monetization/events/([\\s\\S]+?)/tournaments/rewards.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/rewards.ts"),
    ]],

    [new RegExp("LiveOps: dynamic offers/one-time offers"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)(?<!/skins/)(?<!skin-)offers.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)(?<!/skins/)(?<!skin-)offers.ts"),
    ]],

    [new RegExp("LiveOps skeletons: for offers"), [
        new RegExp("features/promo-offers/offers/templates/skeletons/([\\s\\S]*?)skeleton([\\s\\S]*?).ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/skeleton.ts"),
    ]],

    [new RegExp("LiveOps skins: for offers"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/skins/offers.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/skin-offers.ts"),
    ]],

    [new RegExp("Marathons: entities"), [
        new RegExp("features/monetization/static/marathons/([\\s\\S]*?).ts"),
    ]],

    [new RegExp("LiveOps: marathons"), [
        new RegExp("features/monetization/activities/([\\s\\S]*?)/marathons/marathons.ts"),
        new RegExp("features/monetization/events/([\\s\\S]*?)/marathons/marathons.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]*?)/marathons.ts"),
    ]],

    [new RegExp("LiveOps skeletons: marathons"), [
        new RegExp("features/quests/quests-and-marathons/marathons/templates/skeletons/([\\s\\S]*?).ts"),
    ]],

    [new RegExp("LiveOps skins: marathons"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/skins/marathons.ts"),
        new RegExp("features/monetization/activities/([\\s\\S]+?)/skin-marathons.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/skin-marathons.ts"),
    ]],

    [new RegExp("LiveOps: roulette"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/roulette/roulette.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)roulettes?.ts"),
    ]],

    [new RegExp("LiveOps skeletons: for roulette"), [
        new RegExp("features/roulette/roulette/templates/skeletons/([\\s\\S]+?).ts"),
    ]],

    [new RegExp("LiveOps skins: for roulette"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/skins/roulette.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/skin-roulettes.ts"),
    ]],

    [new RegExp("LiveOps: tournaments"), [
        new RegExp("features/monetization/activities/([\\s\\S]+?)/tournaments/tournaments.ts"),
        new RegExp("features/monetization/events/([\\s\\S]+?)/tournaments/tournaments.ts"),
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)/tournaments.ts"),
    ]],

    [new RegExp("LiveOps: gacha banners"), [
        new RegExp("features/monetization/liveops-blocks/([\\s\\S]+?)banners.ts"),
    ]],

    [new RegExp("LiveOps: event entities"), [
        new RegExp("features/monetization/events/([\\s\\S]+?)/event.ts"),
    ]],
];
