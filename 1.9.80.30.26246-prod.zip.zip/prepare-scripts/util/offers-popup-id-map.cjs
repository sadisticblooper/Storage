const fs = require("fs");
const {SETTINGS} = require("../run/settings.cjs");

function getPopupIDToOffersMap(offersMap) {
    let popupsIDsToOffersMap = {
        withoutPopup: [],
    };

    for (let offerID of offersMap.getKeys()) {
        let offer = offersMap.get(offerID);
        let popupSettings = offer.PopUpSettings;

        if (popupSettings == null) {
            if (offer._enablePopup === true) {
                popupsIDsToOffersMap["withoutPopup"].push({
                    id: offerID,
                    name: offer.Name,
                })

            }

            continue;
        }

        let popupID = popupSettings.popUpId;

        if (popupsIDsToOffersMap[popupID] == undefined) {
            popupsIDsToOffersMap[popupID] = [];
        }

        popupsIDsToOffersMap[popupID].push({
            id: offer.ID,
            name: offer.Name,
        })
    }

    return popupsIDsToOffersMap;
}

function getSkinPrefix(name, id) {
    //usual name for offer generated from skin "prefix_{name_prefix}_{offer_prefix}_{offer_id}"
    let parts = name.split('_');
    if (parts.length > 2) {
        if (parts[parts.length - 1] == id) {
            parts.pop();
            parts.pop();
        }
    }
    return parts.join('_');
}

function loadOffersMap() {
    eval(fs.readFileSync(SETTINGS.PATH_TO_FULL).toString());

    return offersMap;
}

module.exports.getPopupIDToOffersMap = getPopupIDToOffersMap;
module.exports.loadOffersMap = loadOffersMap;
module.exports.getSkinPrefix = getSkinPrefix;