// Give the answer: which region is match for the file path

module.exports.RegionMatcher = class RegionMatcher {
    // { [regionNumber: number]: array of patterns to test file path }
    // patterns;

    // regions: see LinkerManager.regions
    // rules: see REGION_RULES
    constructor(regions, rules) {
        this.patterns = {};

        for (let regionNumber = 0; regionNumber < regions.length; regionNumber++ ) {
            let region = regions[regionNumber];

            for (let rule of rules) {
                let regionRule = rule[0];
                let filePathPatterns = rule[1];

                if (regionRule.test(region.startRowText)) {
                    this.patterns[regionNumber] = filePathPatterns;
                    break;
                }
            }
        }
    }

    // Return -1 if not found
    getRegionNumberForFilePath(filePath) {
        for (let regionNumber in this.patterns) {
            for (let filePathPattern of this.patterns[regionNumber]) {
                if (filePathPattern.test(filePath)) {
                    return +regionNumber;
                }
            }
        }

        return -1;
    }
};
