// Methods to:
// * add new file into region
// * set/unset DONT-COMPILE-TAG for file
// * check if file presents in list
// * get text content after changes
// * check if file path do compile

const fs = require("fs");
const path = require("path");
const {toNormalizeConfigsPath} = require("./util.cjs");

module.exports.LinkerManager = class LinkerManager {
    // string[]
    // linkerContentRows;

    // { [filePath: string]: { rowNumber: number, doCompile: boolean } }
    // filesInfo;

    // { startRow: number, endRow: number, startRowText: string }[]
    // regions;

    // string
    // dontCompileTag;

    // bool
    // changed;

    // string
    // pathToScripts;

    constructor(linkerContent, dontCompileTag, pathToScripts) {
        this.linkerContentRows = linkerContent.split("\n");
        this.dontCompileTag = dontCompileTag;
        this.pathToScripts = pathToScripts;
        this.filesInfo = {};
        this.regions = [];
        this.changed = false;

        this.prepareFilesInfo();
        this.prepareRegions();
    }

    getRegions() {
        return this.regions;
    }

    addFilePathIntoRegion(filePath, regionNumber) {
        filePath = toNormalizeConfigsPath(filePath);
        let region = this.regions[regionNumber];

        if (!region) {
            throw new Error(`Region ${regionNumber} for file ${filePath} not found`);
        }

        let rowToAdd = region.endRow;
        this.linkerContentRows.splice(rowToAdd, 0, `///<reference path="${filePath}"/>`);

        for (let region of this.regions) {
            if (region.startRow >= rowToAdd) {
                region.startRow++;
            }

            if (region.endRow >= rowToAdd) {
                region.endRow++;
            }
        }

        for (let fp in this.filesInfo) {
            if (this.filesInfo[fp].rowNumber >= rowToAdd) {
                this.filesInfo[fp].rowNumber++;
            }
        }

        this.filesInfo[filePath] = {rowNumber: rowToAdd, doCompile: true};
        this.changed = true;
    }

    setFilePathCompilation(filePath, doCompile) {
        filePath = toNormalizeConfigsPath(filePath);

        if (!this.isFilePathPresents(filePath)) {
            throw new Error(`You can't set compilation flag for file [${filePath}] which does not present in linker.`);
        }

        let info = this.filesInfo[filePath];

        if (info.doCompile !== doCompile) {
            this.changed = true;
        }

        info.doCompile = doCompile;
        this.linkerContentRows[info.rowNumber] = doCompile
            ? `///<reference path="${filePath}"/>`
            : `${this.dontCompileTag} ///<reference path="${filePath}"/>`;
    }

    isFilePathDoCompilation(filePath) {
        filePath = toNormalizeConfigsPath(filePath);
        return this.filesInfo[filePath].doCompile;
    }

    isFilePathPresents(filePath) {
        filePath = toNormalizeConfigsPath(filePath);
        return Boolean(this.filesInfo[filePath]);
    }

    wasChanged() {
        return this.changed;
    }

    getTextContent() {
        return this.linkerContentRows.join("\n");
    }

    prepareFilesInfo() {
        for (let rowNumber = 0; rowNumber < this.linkerContentRows.length; rowNumber++) {
            let row = this.linkerContentRows[rowNumber];
            let filePath = this.getFilePathFromLinkerRow(row);

            if (filePath) {
                filePath = toNormalizeConfigsPath(filePath);

                if (!fs.existsSync(path.join(this.pathToScripts, filePath))) {
                    throw new Error(`File '${filePath}' does not exist. Row ${row}`);
                }

                if (this.filesInfo[filePath] !== undefined) {
                    throw new Error(`File '${filePath}' already exists in linker. Check rows `
                        +`${this.filesInfo[filePath].rowNumber + 1} and ${rowNumber + 1}.`);
                }

                let isFileRemovedFromCompilation = this.isFileRemovedFromCompilationFromLinkerRow(row);
                this.filesInfo[filePath] = { rowNumber: rowNumber, doCompile: !isFileRemovedFromCompilation };
            }
        }
    }

    prepareRegions() {
        for (let rowNumber = 0; rowNumber < this.linkerContentRows.length; rowNumber++) {
            let row = this.linkerContentRows[rowNumber];

            if (this.isRegionStart(row)) {
                let innerRegionStarts = 1;
                let endRow = rowNumber;

                for (let rowNumberInRegion = rowNumber + 1; rowNumberInRegion < this.linkerContentRows.length; rowNumberInRegion++) {
                    let rowInRegion = this.linkerContentRows[rowNumberInRegion];
                    let isStartRegion = this.isRegionStart(rowInRegion);
                    let isRegionEnd = this.isRegionEnd(rowInRegion);

                    if (isStartRegion) {
                        innerRegionStarts++;
                    } else if (isRegionEnd) {
                        innerRegionStarts--;

                        if (innerRegionStarts === 0) {
                            endRow = rowNumberInRegion;
                            break;
                        }
                    }
                }

                if (endRow === rowNumber) {
                    throw new Error(`Illegal region syntax. Check '${row}' on ${rowNumber}`);
                }

                this.regions.push({startRow: rowNumber, endRow: endRow, startRowText: row});
            }
        }
    }

    getFilePathFromLinkerRow(row) {
        let regexp = /<reference path="([\s\S]+?)"\/>/g;
        let match = regexp.exec(row);

        if (match && match[1]) {
            return match[1];
        }

        return null;
    }

    isFileRemovedFromCompilationFromLinkerRow(row) {
        return row.indexOf(this.dontCompileTag) > -1;
    }

    isRegionStart(row) {
        let regWithOneLineComment = RegExp("^// region", "g");
        return regWithOneLineComment.test(row);
    }

    isRegionEnd(row) {
        let regWithOneLineComment = RegExp("^// endregion", "g");
        return regWithOneLineComment.test(row);
    }
};
