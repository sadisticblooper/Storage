// Methods to:
// * check tags settings
// * check if file path under tag
// * check compilation for file path

const fs = require("fs");
const {isTsFile, getAllFilesRecursive, toNormalizeConfigsPath} = require("./util.cjs");

module.exports.TagSystem = class TagSystem {
    // { [filePath: string]: do compile }
    // filePathsWithTag;

    // { [tagNumber: number]: doCompile }
    // tags;

    constructor(tags, tagsForFiles, activeMap) {
        this.prepareTagsMap(tags, activeMap);
        this.prepareFilePathsWithTag(tagsForFiles);
    }

    isFilePathWithTag(filePath) {
        filePath = toNormalizeConfigsPath(filePath);
        return filePath in this.filePathsWithTag;
    }

    isFilePathDoCompile(filePath) {
        filePath = toNormalizeConfigsPath(filePath);
        return this.filePathsWithTag[filePath];
    }

    prepareTagsMap(tags, activeMap) {
        this.tags = {};

        for (let tagName in tags) {
            let tagNumber = tags[tagName];

            if (tagNumber in this.tags) {
                throw new Error(`Tag number '${tagNumber}' already exists in tag map.`);
            }

            this.tags[tagNumber] = false;
        }

        for (let tagNumber in activeMap) {
            if (!(tagNumber in this.tags)) {
                throw new Error(`Tag number '${tagNumber}' (from active map) not found.`);
            }

            this.tags[tagNumber] = activeMap[tagNumber];
        }
    }

    prepareFilePathsWithTag(tagsForFiles) {
        let priorityMap = {};
        this.filePathsWithTag = {};

        for (let block of tagsForFiles) {
            let {path, tag: tagNumber} = block;
            path = toNormalizeConfigsPath(path);

            if (!(tagNumber in this.tags)) {
                throw new Error(`Tag number '${tagNumber}' (from tags for files array) not found. Path '${path}'`);
            }

            if (!fs.existsSync(path)) {
                throw new Error(`Path '${path}' does not exist. Tag number '${tagNumber}'.`);
            }

            let priority = path.split("/").length;
            let pathsToProcess = getAllFilesRecursive(path);

            for (let filePath of pathsToProcess) {
                filePath = toNormalizeConfigsPath(filePath);

                if (!isTsFile(filePath)) {
                    continue;
                }

                let oldPriority = priorityMap[filePath] || 0;

                if (priority >= oldPriority) {
                    priorityMap[filePath] = priority;
                    this.filePathsWithTag[filePath] = this.tags[tagNumber];
                }
            }
        }
    }
};
