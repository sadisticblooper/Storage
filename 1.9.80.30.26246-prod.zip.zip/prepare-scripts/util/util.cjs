const fs = require("fs");
const path = require("path");

function isTsFile(filePath) {
    return filePath.split(".").pop() === "ts";
}

function getAllFilesRecursive(filePath, exclude = []) {
    if (exclude.indexOf(toNormalizeConfigsPath(filePath)) > -1) {
        return [];
    }

    if (!fs.existsSync(filePath)) {
        throw new Error(`Path '${filePath}' does not exist.`);
    }

    let result = [];

    if (fs.lstatSync(filePath).isDirectory()) {
        let listNames = fs.readdirSync(filePath);

        for (let name of listNames) {
            result.push(...getAllFilesRecursive(path.join(filePath, name), exclude));
        }
    } else {
        result.push(filePath);
    }

    return result;
};

function isPathsAreSame(path1, path2) {
    return path.relative(path1, path2) === "";
}

function toNormalizeConfigsPath(filePath) {
    return path.normalize(filePath).replace(/\\/g, "/");
}

module.exports.isTsFile = isTsFile;
module.exports.getAllFilesRecursive = getAllFilesRecursive;
module.exports.isPathsAreSame = isPathsAreSame;
module.exports.toNormalizeConfigsPath = toNormalizeConfigsPath;
