module.exports.TreeView = class TreeView {
    constructor() {
        this.VERTICAL_SYMBOL = "│";
        this.SUB_DIR_SYMBOL = "├───";
        this.CORNER_SYMBOL = "└───";
        this.EMPTY_SYMBOL = " ";
        this.SPACES = "   ";
        this.FILES_CONTAINER_PATH = ".";
    }

    getText(pathsFiles) {
        let tree =  this.createTree(pathsFiles);
        return this.showBranchRows(tree).join("\n");
    }

    createTree(pathsFiles) {
        let tree = {};

        for (let filePath of pathsFiles) {
            let parts = filePath.split("/");
            let currentBranch = tree;

            for (let partIndex = 0; partIndex < parts.length - 1; partIndex++) {
                let part = parts[partIndex];

                if (!(part in currentBranch)) {
                    currentBranch[part] = {};
                }

                currentBranch = currentBranch[part];
            }

            if (!(this.FILES_CONTAINER_PATH in currentBranch)) {
                currentBranch[this.FILES_CONTAINER_PATH] = [];
            }

            currentBranch[this.FILES_CONTAINER_PATH].push(parts[parts.length - 1]);
        }

        return tree;
    }

    showBranchRows(branch) {
        let result = [];
        let folders = Object.keys(branch)
            .filter(f => f !== this.FILES_CONTAINER_PATH)
            .sort();
        let startSymbol = folders.length === 0 ? this.EMPTY_SYMBOL : this.VERTICAL_SYMBOL;

        if (branch[this.FILES_CONTAINER_PATH]) {
            for (let file of branch[this.FILES_CONTAINER_PATH]) {
                result.push(startSymbol + this.SPACES + file);
            }

            result.push(startSymbol);
        }

        for (let i = 0; i < folders.length; i++) {
            let folder = folders[i];
            let subDirSymbols = i === folders.length - 1 ? this.CORNER_SYMBOL : this.SUB_DIR_SYMBOL;
            let verticalSymbols = (i === folders.length - 1 ? this.EMPTY_SYMBOL : this.VERTICAL_SYMBOL) + this.SPACES;
            result.push(subDirSymbols + folder);
            result.push(...(this.showBranchRows(branch[folder]).map(el => verticalSymbols + el)));
        }

        return result;
    }
};
