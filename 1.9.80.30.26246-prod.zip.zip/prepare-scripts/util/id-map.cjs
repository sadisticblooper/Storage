const fs = require("fs");
const {SETTINGS} = require("../run/settings.cjs");

function getUsedIds(map) {
    return map.getKeys().map(Number)
}

function getFreeIds(usedIds, maxId) {
    const freeIds = [];
    let current = 1;

    for (let usedId of usedIds) {
        while (current < usedId) {
            freeIds.push(current);
            current++;
        }
        current++;
    }

    while (current <= maxId) {
        freeIds.push(current);
        current++;
    }

    return freeIds;
}

function formatIdRanges(ids) {
    let formattedRanges = [];
    let rangeStart = ids[0];
    let previousId = ids[0];

    if (ids.length === 0) return "";

    for (let i = 1; i < ids.length; i++) {
        if (ids[i] !== previousId + 1) {
            formattedRanges.push(rangeStart === previousId ? `${rangeStart}` : `${rangeStart} - ${previousId}`);
            rangeStart = ids[i];
        }
        previousId = ids[i];
    }

    formattedRanges.push(rangeStart === previousId ? `${rangeStart}` : `${rangeStart} - ${previousId}`);
    return formattedRanges.join(", ");
}

function loadEntityMaps() {
    eval(fs.readFileSync(SETTINGS.PATH_TO_FULL).toString());

    return [
        gachaBannersMap,
        draftTournamentsMap,
        QuestMarathonsMap,
        offersMap,
        shopSlotsMap,
        seasonalEventsMap,
        rouletteMap,
    ];
}

module.exports.getUsedIds = getUsedIds;
module.exports.getFreeIds = getFreeIds;
module.exports.formatIdRanges = formatIdRanges;
module.exports.loadEntityMaps = loadEntityMaps;