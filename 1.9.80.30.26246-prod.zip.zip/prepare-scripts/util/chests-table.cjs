const fs = require("fs");
const {SETTINGS} = require("../run/settings.cjs");

function loadChestsMap() {
    eval(fs.readFileSync(SETTINGS.PATH_TO_FULL).toString());

    return chestsMap
}

module.exports.loadChestsMap = loadChestsMap;