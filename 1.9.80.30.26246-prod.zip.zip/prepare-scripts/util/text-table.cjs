// Show text table as:

//  ———————————
// | Header 1  |
//  -----------
// | Content 1 |
//  ———————————
// | Header 2  |
//  -----------
// | Content 2 |
//  ——————————— 

module.exports.TextTable = class TextTable {
    // { title: string, body: string }[]
    // blocks;

    constructor() {
        this.blocks = [];
    }

    add(title, body) {
        this.blocks.push({ title: title || "empty", body: body || "empty" });
        return this;
    }

    getTextTable() {
        let maxLength = this.blocks.reduce((max, block) =>
                Math.max(
                    max,
                    block.title.split("\n").reduce((a, row) => Math.max(a, row.length), 0),
                    block.body.split("\n").reduce((a, row) => Math.max(a, row.length), 0)
                ), 0);
        const bound = ` ${new Array(maxLength + 2).fill("—").join("")} `;
        const headerBound = ` ${new Array(maxLength + 2).fill("-").join("")} `;
        const result = [bound];

        for (let block of this.blocks) {
            result.push(...block.title.split("\n").map(row => `| ${this.getRowWithSpaces(row, maxLength)} |`) );
            result.push(headerBound);
            result.push(...block.body.split("\n").map(row => `| ${this.getRowWithSpaces(row, maxLength)} |`) );
            result.push(bound);
        }

        return result.join("\n");
    }

    getRowWithSpaces(text, goalLength) {
        goalLength = Math.max(text.length, goalLength);
        return text + new Array(goalLength - text.length).fill(" ").join("");
    }
};
