const fs = require("fs");
const path = require("path");
const {loadChestsMap} = require("../util/chests-table.cjs");
const {SETTINGS} = require("./settings.cjs");

const pathToOnefile = SETTINGS.PATH_TO_ONEFILE
const CHESTS_TABLE_FILE= "chests_table.csv"
const outputFilePath = path.join(pathToOnefile, CHESTS_TABLE_FILE);
const chestsMap = loadChestsMap();
const tableRows = [];

function extractChestData() {
    tableRows.push("ID,Config Name,Alias Name,Image");

    const chestIds = chestsMap.getKeys();

    for (const id of chestIds) {
        const chest = chestsMap.get(id);

        if (!chest) continue;

        const configName = chest.Name || "";
        const alias = chest.alias || "";
        const image = chest.icon || "";

        tableRows.push(`${id},${configName},${alias},${image}`);
    }

    return tableRows.join("\n");
}

const csvData = extractChestData();

fs.writeFileSync(outputFilePath, csvData, "utf8");
console.log(`CSV data saved to ${outputFilePath}`);