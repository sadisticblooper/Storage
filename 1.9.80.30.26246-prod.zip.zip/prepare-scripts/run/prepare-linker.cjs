const fs = require("fs");
const path = require("path");
const {TAGS, ACTIVE_TAGS_MAP, TAGS_FOR_FILES} = require("../tag-system.cjs");
const {REGION_RULES} = require("../auto-linker-templates.cjs");
const {SETTINGS} = require("./settings.cjs");
const {TagSystem} = require("../util/tag-system.cjs");
const {LinkerManager} = require("../util/linker-manager.cjs");
const {RegionMatcher} = require("../util/region-matcher.cjs");
const {TreeView} = require("../util/tree-view.cjs");
const {TextTable} = require("../util/text-table.cjs");
const Util = require("../util/util.cjs");

function prepareLinker(showResultLog = false) {
    let linkerContent = fs.readFileSync(SETTINGS.PATH_TO_LINKER).toString();
    let linkerManager = new LinkerManager(linkerContent, SETTINGS.DONT_COMPILE_TAG, SETTINGS.PATH_TO_SCRIPTS);
    let regionMatcher = new RegionMatcher(linkerManager.getRegions(), REGION_RULES);
    let tagSystem = new TagSystem(TAGS, TAGS_FOR_FILES, ACTIVE_TAGS_MAP);
    let allTSFiles = Util.getAllFilesRecursive(SETTINGS.PATH_TO_SCRIPTS, [Util.toNormalizeConfigsPath(SETTINGS.PATH_TO_AB_FOLDER)])
        .filter(filePath => Util.isTsFile(filePath) && !Util.isPathsAreSame(filePath, SETTINGS.PATH_TO_LINKER))
        .map(filePath => Util.toNormalizeConfigsPath(filePath));

    let autoAddedFiles = [];
    let unlinkedFiles = [];
    let ignoreCompiledFiles = [];

    for (let filePath of allTSFiles) {
        let filePathForLinker = Util.toNormalizeConfigsPath(path.relative(SETTINGS.PATH_TO_SCRIPTS, filePath));

        if (!linkerManager.isFilePathPresents(filePathForLinker)) {
            let regionNumber = regionMatcher.getRegionNumberForFilePath(filePathForLinker);

            if (regionNumber > -1) {
                linkerManager.addFilePathIntoRegion(filePathForLinker, regionNumber);
                autoAddedFiles.push(filePath);
            } else {
                unlinkedFiles.push(filePath);
                continue;
            }
        }

        if (tagSystem.isFilePathWithTag(filePath)) {
            linkerManager.setFilePathCompilation(filePathForLinker, tagSystem.isFilePathDoCompile(filePath));
        }

        if (!linkerManager.isFilePathDoCompilation(filePathForLinker)) {
            ignoreCompiledFiles.push(filePath);
        }
    }

    if (unlinkedFiles.length > 0) {
        throw new Error(`There are TS files which does not exist in linker.ts:\n` + unlinkedFiles.join("\n"));
    }

    if (linkerManager.wasChanged()) {
        fs.writeFileSync(SETTINGS.PATH_TO_LINKER, linkerManager.getTextContent());
    }

    if (showResultLog) {
        let treeView = new TreeView();
        let textTable = new TextTable();

        if (autoAddedFiles.length > 0) {
            textTable.add("Files: auto-added to linker.ts", treeView.getText(autoAddedFiles));
        }

        if (ignoreCompiledFiles.length > 0) {
            textTable.add("Files: remove from compilation", treeView.getText(ignoreCompiledFiles));
        }

        console.log(textTable.getTextTable());
    }
}

const ARGS = process.argv.filter(arg => arg.substring(0, 2) === "--").map(arg => arg.substring(2));

if (ARGS.indexOf("run") > -1) {
    prepareLinker(ARGS.indexOf("log") > -1);
}

module.exports.prepareLinker = prepareLinker;
