module.exports.SETTINGS = {
    DONT_COMPILE_TAG: "//[==DONT-COMPILE==]",
    PATH_TO_SCRIPTS: "./configs/scripts/",
    PATH_TO_MAIN: "./configs/scripts/main.ts",
    PATH_TO_LINKER: "./configs/scripts/linker.ts",
    PATH_TO_AB_FOLDER: "./configs/scripts/ab",
    PATH_TO_ONEFILE: "./configs/scripts/onefile",
    PATH_TO_FULL: "./configs/scripts/onefile/full.js",
};
