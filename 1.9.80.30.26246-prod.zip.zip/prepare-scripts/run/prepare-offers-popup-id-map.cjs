const fs = require("fs");
const path = require("path");
const PopupIdMapUtil = require("../util/offers-popup-id-map.cjs");
const {SETTINGS} = require("./settings.cjs");
const {TextTable} = require("../util/text-table.cjs");
const pathToOnefile = SETTINGS.PATH_TO_ONEFILE
const ID_MAP_FILE= "offers_popup_id_map.txt"
const outputFilePath = path.join(pathToOnefile, ID_MAP_FILE);
const offersMap = PopupIdMapUtil.loadOffersMap();

let popupsIDsToOffersMap = PopupIdMapUtil.getPopupIDToOffersMap(offersMap);
let sortedIDs = Object.keys(popupsIDsToOffersMap).sort((a,b) => a - b);
let textTable = new TextTable();
for (let popupID of sortedIDs) {
    let title = `popupID ${popupID}`;
    let body = '';

    let lastSkinPrefix = '';
    let lastOfferID = 0;
    let isParsingSkin = false;

    for (let offerInfo of popupsIDsToOffersMap[popupID]) {
        let skinPrefix = PopupIdMapUtil.getSkinPrefix(offerInfo.name, offerInfo.id);

        if (skinPrefix === lastSkinPrefix) {
            isParsingSkin = true;
        } else {
            if (isParsingSkin) {
                body += ` - ${lastOfferID}`;
                isParsingSkin = false;
            }
            if (lastSkinPrefix !== '') {
                body += '\n';
            }
        }

        if (!isParsingSkin) {
            body += `   name: ${skinPrefix} | id: ${offerInfo.id}`;
        }

        lastOfferID = offerInfo.id;
        lastSkinPrefix = skinPrefix;
    }

    textTable.add(title, body);
}

fs.writeFileSync(outputFilePath, textTable.getTextTable(), "utf8");
console.log(`offers popupID map saved to ${outputFilePath}`);