const fs = require("fs");
const path = require("path");
const IdMapUtil = require("../util/id-map.cjs");
const {SETTINGS} = require("./settings.cjs");

const pathToOnefile = SETTINGS.PATH_TO_ONEFILE
const ID_MAP_FILE= "id_map.txt"
let reportContent = "";
const outputFilePath = path.join(pathToOnefile, ID_MAP_FILE);
const entityMaps = IdMapUtil.loadEntityMaps();

for (let entityMap of entityMaps) {
    const entityName = entityMap.name;
    const usedIds = IdMapUtil.getUsedIds(entityMap);
    const freeIds = IdMapUtil.getFreeIds(usedIds);

    reportContent += `Free IDs for ${entityName}:\n`;
    reportContent += IdMapUtil.formatIdRanges(freeIds) + "\n\n";

    reportContent += `Map for ${entityName}:\n`;
    reportContent += `IDs: ${IdMapUtil.formatIdRanges(usedIds)}\n\n`;
}

fs.writeFileSync(outputFilePath, reportContent, "utf8");
console.log(`ID map saved to ${outputFilePath}`);