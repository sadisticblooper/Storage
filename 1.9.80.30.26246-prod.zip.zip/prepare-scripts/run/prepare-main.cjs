const fs = require("fs");
const {prepareLinker} = require("./prepare-linker.cjs");
const {SETTINGS} = require("./settings.cjs");

const pathToMain = SETTINGS.PATH_TO_MAIN;
const pathToLinker = SETTINGS.PATH_TO_LINKER;
const removeLineTag = SETTINGS.DONT_COMPILE_TAG;

prepareLinker();
let mainContent = fs.readFileSync(pathToMain).toString();
const linkerContent = fs.readFileSync(pathToLinker)
    .toString()
    .split("\n")
    .filter(line => line.indexOf(removeLineTag) === -1)
    .join("\n");

let refs = linkerContent.match(/path="([\s\S]+?)\.ts"/mg).map(ref => ref.match(/path="([\s\S]+?)\.ts"/)[1]);
let refsInMainJs = refs.map(ref => `'${ref}.js',`).join("\n    ");
let result = `var main = [
    ${refsInMainJs}
];`;
mainContent = mainContent.replace(/var main = \[[\s\S]*?\];/m, result);
fs.writeFileSync(pathToMain, mainContent);
