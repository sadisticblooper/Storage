var _a, _b;
var BattleConstants = (function () {
    function BattleConstants() {
    }
    BattleConstants.defaultBattleID = 1;
    BattleConstants.defaultGameSettingsTemplate = (_a = {},
        _a[TEAM_MODE._3_VS_3_] = {
            RoundsToWin: 3,
            RoundsToLose: 3,
            RoundTime: 99,
        },
        _a[TEAM_MODE._1_VS_1_] = {
            RoundsToWin: 2,
            RoundsToLose: 2,
            RoundTime: 99,
            Tags: ["ONE_VS_ONE"],
        },
        _a);
    BattleConstants.eventItuFruitNinja = (_b = {},
        _b[TEAM_MODE._3_VS_3_] = {
            RoundsToWin: 1,
            RoundsToLose: 1,
            RoundTime: 200,
        },
        _b[TEAM_MODE._1_VS_1_] = {
            RoundsToWin: 1,
            RoundsToLose: 1,
            RoundTime: 90,
            Tags: ["ONE_VS_ONE", "EVENT_ITU_FRUIT_NINJA_BATTLE_TAG"],
        },
        _b);
    BattleConstants.fightRoundsToWin = {
        1: "FIGHT_ROUNDS_TO_WIN_ONE",
        2: "FIGHT_ROUNDS_TO_WIN_TWO",
        3: "FIGHT_ROUNDS_TO_WIN_THREE",
        4: "FIGHT_ROUNDS_TO_WIN_FOUR",
        5: "FIGHT_ROUNDS_TO_WIN_FIVE",
        6: "FIGHT_ROUNDS_TO_WIN_SIX",
        7: "FIGHT_ROUNDS_TO_WIN_SEVEN",
        8: "FIGHT_ROUNDS_TO_WIN_EIGHT",
        9: "FIGHT_ROUNDS_TO_WIN_NINE",
        10: "FIGHT_ROUNDS_TO_WIN_TEN",
    };
    return BattleConstants;
}());
