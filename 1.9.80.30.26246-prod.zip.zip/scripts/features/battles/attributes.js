var AttributesConfigs = (function () {
    function AttributesConfigs() {
        this.multipliersFromHeroRarity = [];
        this.heroAttributes = {};
        this.fakeHeroAttributes = {};
        this.weaponHeroAttributes = {};
        this.shiftWeaponHeroAttributes = {};
        this.multipliersFromTalents = [];
        this.multipliersFromHeroRarity = [];
        this.multipliersFromHeroLevels = [];
        this.shiftsFromTalents = [];
        this.accountAttributeCustomMultiplier = HeroConstants.accountAttributeCustomMultiplier;
        this.accountMultiplier = HeroConstants.accountMultiplier;
        this.weaponAspectAttributes = {};
    }
    return AttributesConfigs;
}());
