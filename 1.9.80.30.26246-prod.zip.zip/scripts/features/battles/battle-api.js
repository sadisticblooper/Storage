function getBattleSettings(settings) {
    return BattleUtils.getBattleSettings(settings);
}
function getBattleSettingsForMatcher(settings) {
    return BattleUtils.getBattleSettingsForMatcher(settings);
}
function getDefaultRoundsToWin(settings) {
    return BattleUtils.getDefaultRoundsToWin(settings);
}
function getWarrior(settings) {
    return BattleUtils.getWarrior(settings);
}
function getConfigsForAttributes(settings) {
    return BattleUtils.getConfigsForAttributes(settings);
}
