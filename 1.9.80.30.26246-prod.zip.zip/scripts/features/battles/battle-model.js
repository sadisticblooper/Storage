var Battle = (function () {
    function Battle(settings) {
        this.RoundsToWin = 3;
        this.RoundsToLose = 3;
        this.Warriors = [];
        this.Tags = [];
        var battleSettings = settings.battleSettings, teamMode = settings.teamMode, roguelikeHeroRoundVisited = settings.roguelikeHeroRoundVisited, overrideParameters = settings.overrideParameters;
        this.ID = battleSettings.ID;
        this.Alias = battleSettings.Alias;
        this.Location = battleSettings.Location;
        this.FightMode = getValueByKeyDefault(battleSettings, "FightMode", FIGHT_MODE.AI);
        this.FightResultStrategy
            = getValueByKeyDefault(battleSettings, "FightResultStrategy", FIGHT_RESULT_STRATEGY.FAIR);
        this.LocalPlayerML
            = getValueByKeyDefault(battleSettings, "LocalPlayerML", { EnableForLocalPlayer: false });
        var gameSettings;
        var isRoguelike = [FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(this.FightMode) > -1;
        this.Tags = [];
        if (isRoguelike) {
            if (battleSettings.RoguelikeSettings == undefined) {
                throw new Error("battle ".concat(this.ID, " error: no settings for rougelike mode"));
            }
            if (RoguelikeConstants.fightTags[this.FightMode]) {
                this.Tags.push(RoguelikeConstants.fightTags[this.FightMode]);
            }
            gameSettings = battleSettings.RoguelikeSettings;
        }
        else {
            gameSettings = battleSettings.GameSettings[teamMode];
        }
        if (!gameSettings) {
            gameSettings = BattleConstants.defaultGameSettingsTemplate[teamMode];
        }
        this.RoundsToWin = gameSettings.RoundsToWin;
        this.RoundsToLose = gameSettings.RoundsToLose;
        this.RoundTime = gameSettings.RoundTime;
        this.DisableRoundTimer = getValueByKeyDefault(gameSettings, "DisableRoundTimer", false);
        this.Warriors = [];
        this.SwitchLocation = getValueByKeyDefault(battleSettings, "SwitchLocation", null);
        if (isRoguelike) {
            var chapterId = RoguelikeMetaUtils.getChapterIdByBattleId(this.ID);
            var chapter = chaptersMap.get(chapterId);
            if (chapter) {
                var overrideLocations = chapter.getOverrideLocations({
                    initLocation: this.Location,
                    switchLocation: this.SwitchLocation,
                    roguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
                });
                this.SwitchLocation = overrideLocations.switchLocation;
                this.setLocation(overrideLocations.initLocation);
            }
        }
        if (overrideParameters) {
            if (overrideParameters.locationId) {
                var location_1 = locationsMap.get(overrideParameters.locationId);
                if (location_1) {
                    this.setLocation(location_1);
                }
            }
            if (overrideParameters.roundsToWin) {
                this.RoundsToWin = overrideParameters.roundsToWin;
            }
            if (overrideParameters.roundDuration != undefined) {
                this.RoundTime = overrideParameters.roundDuration;
            }
        }
        var rules = battleSettings.Rules;
        var tags = gameSettings.Tags;
        var warriors = gameSettings.OverrideWarriorSettings;
        if (rules) {
            for (var _i = 0, rules_1 = rules; _i < rules_1.length; _i++) {
                var id = rules_1[_i];
                var rule = tournamentRulesMap.checkedGet(id);
                for (var _a = 0, _b = rule.Tags; _a < _b.length; _a++) {
                    var tag = _b[_a];
                    if (this.Tags.indexOf(tag) == -1) {
                        this.Tags.push(tag);
                    }
                }
            }
        }
        if (tags) {
            for (var _c = 0, tags_1 = tags; _c < tags_1.length; _c++) {
                var tag = tags_1[_c];
                if (this.Tags.indexOf(tag) == -1) {
                    this.Tags.push(tag);
                }
            }
        }
        if (BattleConstants.fightRoundsToWin[this.RoundsToWin] != undefined) {
            var roundsToWinTag = BattleConstants.fightRoundsToWin[this.RoundsToWin];
            if (this.Tags.indexOf(roundsToWinTag) == -1) {
                this.Tags.push(roundsToWinTag);
            }
        }
        if (warriors) {
            for (var _d = 0, warriors_1 = warriors; _d < warriors_1.length; _d++) {
                var settings_1 = warriors_1[_d];
                this.Warriors.push(settings_1);
            }
        }
    }
    Battle.prototype.addTags = function (tags) {
        for (var _i = 0, tags_2 = tags; _i < tags_2.length; _i++) {
            var tag = tags_2[_i];
            if (this.Tags.indexOf(tag) == -1) {
                this.Tags.push(tag);
            }
        }
    };
    Battle.prototype.setLocation = function (location) {
        this.Location = location;
    };
    return Battle;
}());
