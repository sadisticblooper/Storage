var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var BattleUtils = (function () {
    function BattleUtils() {
    }
    BattleUtils.getBattleSettingsForMatcher = function (settings) {
        var p1 = settings.p1, p2 = settings.p2, MatchingMode = settings.MatchingMode, TeamMode = settings.TeamMode, OverrideBattleParameters = settings.OverrideBattleParameters, BattleId = settings.BattleId;
        return BattleUtils.getBattleData({
            teamMode: TeamMode,
            contextEntityType: MatchingMode,
            contextEntityId: p1.tournamentId,
            locationHistory: p1.locationHistory,
            locationHistoryEnemy: p2 && p2.locationHistory,
            overrideBattleParameters: OverrideBattleParameters,
            battleId: BattleId,
        });
    };
    BattleUtils.getBattleSettings = function (settings) {
        var BattleID = settings.BattleID, OverrideBattleParameters = settings.OverrideBattleParameters, TeamMode = settings.TeamMode, RoguelikeHeroRoundVisited = settings.RoguelikeHeroRoundVisited;
        var battleSetting = battleSettingsMap.checkedGet(BattleID);
        var battle = new Battle({
            battleSettings: battleSetting,
            teamMode: TeamMode,
            roguelikeHeroRoundVisited: RoguelikeHeroRoundVisited,
            overrideParameters: OverrideBattleParameters,
        });
        battle.addTags(BuffModifierUtils.getTagsFromModifiers(settings.BoosterModifierIds));
        return { Battle: battle };
    };
    BattleUtils.getBattleData = function (arg) {
        var contextEntityId = arg.contextEntityId, contextEntityType = arg.contextEntityType, battleId = arg.battleId, teamMode = arg.teamMode, locationHistory = arg.locationHistory, locationHistoryEnemy = arg.locationHistoryEnemy, boosterModifierIds = arg.boosterModifierIds, overrideBattleParameters = arg.overrideBattleParameters, roguelikeHeroRoundVisited = arg.roguelikeHeroRoundVisited, pveTournamentStage = arg.pveTournamentStage;
        var tutorialLocation = locations.bamboo_arena_tutorial.ID;
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        if (!battleId && FIGHT_MODE[contextEntityType] == undefined && !contextEntityId) {
            throw "getBattleId: battle id not found for input args: \n                \r".concat(JSON.stringify([contextEntityType, contextEntityId, battleId]));
        }
        if (battleId) {
            var battleSettings_1 = battleSettingsMap.get(battleId);
            if (battleSettings_1) {
                if (battleSettings_1.FightMode == FIGHT_MODE.TUTORIAL
                    || battleSettings_1.FightMode == FIGHT_MODE.PRE_TUTORIAL) {
                    return BattleUtils.getBattleSettings({
                        BattleID: battleId,
                        TeamMode: teamMode,
                        RoguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
                        OverrideBattleParameters: overrideBattleParameters,
                    });
                }
            }
        }
        if (contextEntityType == FIGHT_MODE.TOURNAMENT) {
            var tournament = draftTournamentsMap.checkedGet(contextEntityId);
            var tournamentGroupSettings = tournament.Settings.TournamentGroup.Settings;
            var locations_1 = tournamentGroupSettings.LocationPool.slice();
            battleId = tournament.getBattleId(pveTournamentStage);
            if (locations_1.length == 0) {
                locations_1 = [tutorialLocation];
            }
            shuffle(locations_1, rnd);
            var overrideSettings = {
                locationId: (overrideBattleParameters && overrideBattleParameters.locationId) || locations_1[0],
            };
            return BattleUtils.getBattleSettings({
                BattleID: battleId,
                OverrideBattleParameters: overrideSettings,
                TeamMode: teamMode,
                RoguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
            });
        }
        if (contextEntityType == FIGHT_MODE.ROGUELIKE_SURVIVAL || contextEntityType == FIGHT_MODE.ROGUELIKE_COMMON) {
            var chapter = chaptersMap.checkedGet(contextEntityId);
            battleId = chapter.battleId;
            return BattleUtils.getBattleSettings({
                BattleID: battleId,
                TeamMode: teamMode,
                BoosterModifierIds: boosterModifierIds,
                OverrideBattleParameters: overrideBattleParameters,
                RoguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
            });
        }
        if (contextEntityType == FIGHT_MODE.FRIEND || contextEntityType == FIGHT_MODE.LOCAL_PVP_FRIEND) {
            var battleSettings_2 = battleSettingsMap.checkedGet(battleId);
            if (battleSettings_2.FightMode != FIGHT_MODE.FRIEND && battleSettings_2.FightMode != FIGHT_MODE.LOCAL_PVP_FRIEND) {
                throw new Error("getBattleData: wrong FightMode in battle ".concat(battleId, " for fight with friend"));
            }
        }
        else if (FIGHT_MODE[contextEntityType] != undefined) {
            if (contextEntityType == FIGHT_MODE.AI) {
                battleId = battleSettings.UNRANKED.ID;
            }
            else if (contextEntityType == FIGHT_MODE.TRAINING) {
                return BattleUtils.getBattleSettings({
                    BattleID: battleSettings.TRAINING.ID,
                    TeamMode: teamMode,
                    OverrideBattleParameters: overrideBattleParameters,
                    RoguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
                });
            }
            else {
                battleId = battleSettings.RANKED.ID;
            }
        }
        var chosenLocationId;
        if (overrideBattleParameters
            && overrideBattleParameters.locationId
            && locationsMap.get(overrideBattleParameters.locationId)) {
            chosenLocationId = overrideBattleParameters.locationId;
        }
        else {
            var weights = LocationModel.getWeightForLocationsByHistory(getArrayFromRaw(locationHistory));
            var weightsForP2 = locationHistoryEnemy
                ? {}
                : LocationModel.getWeightForLocationsByHistory(getArrayFromRaw(locationHistoryEnemy));
            for (var locationId in weightsForP2) {
                if (weights[locationId] != undefined) {
                    weights[locationId] = (weights[locationId] + weightsForP2[locationId]) / 2;
                }
                else {
                    weights[locationId] = weightsForP2[locationId];
                }
            }
            var collection = new RandomCollection();
            var locationIds = Object.keys(weights).sort(function (a, b) { return (+a) - (+b); });
            for (var _i = 0, locationIds_1 = locationIds; _i < locationIds_1.length; _i++) {
                var locationId = locationIds_1[_i];
                collection.add(new CollectionObjectContainer(locationId, weights[locationId]));
            }
            if (collection.size() == 0) {
                if (locationIds.length > 0) {
                    chosenLocationId = +locationIds[0];
                }
                else {
                    chosenLocationId = tutorialLocation;
                }
            }
            else {
                chosenLocationId = +collection.next(rnd).get();
            }
        }
        return BattleUtils.getBattleSettings({
            BattleID: battleId,
            TeamMode: teamMode,
            OverrideBattleParameters: __assign(__assign({}, (overrideBattleParameters ? overrideBattleParameters : {})), { locationId: chosenLocationId }),
            RoguelikeHeroRoundVisited: roguelikeHeroRoundVisited,
        });
    };
    BattleUtils.getDefaultRoundsToWin = function (settings) {
        var battleId = settings.battleId, teamMode = settings.teamMode;
        var battleSetting = battleSettingsMap.checkedGet(battleId);
        var battle = new Battle({
            battleSettings: battleSetting,
            teamMode: teamMode,
            roguelikeHeroRoundVisited: null,
        });
        return battle.RoundsToWin;
    };
    BattleUtils.getWarrior = function (settings) {
        var heroID = settings.heroID, talents = settings.talents;
        var otherSquadHeroesTalents = settings.otherSquadHeroesTalents || {};
        var tagsWithQuantity = {};
        var chosenTaunts = settings.taunts ? getArrayFromRaw(settings.taunts) : [];
        var origWarrior = heroesMap.checkedGet(heroID);
        var shadowAbilities = __assign({}, origWarrior.ShadowAbilities);
        var altEquip = false;
        var tags = origWarrior.getTags().slice();
        for (var _i = 0, talents_1 = talents; _i < talents_1.length; _i++) {
            var talentID = talents_1[_i];
            var talent = talentsMap.checkedGet(talentID);
            if (talent.isAlternativeEquip()) {
                altEquip = true;
            }
            var tag = talent.getTag(talents);
            tags.push(tag);
            if (talent.StackTalentsForSquad) {
                tagsWithQuantity[tag] = (tagsWithQuantity[tag] || 0) + 1;
            }
            var shadowOverride = talent.getOverrideShadowAbilities(talents);
            for (var key in shadowOverride)
                if (shadowOverride.hasOwnProperty(key)) {
                    shadowAbilities[key] = shadowOverride[key];
                }
        }
        var skin = skinsMap.checkedGet(settings.skinId || origWarrior.DefaultSkinId);
        var weapon = weaponsMap.checkedGet(settings.weaponId || origWarrior.getCommonWeaponIfNotSelected(skin.ID));
        var appearance = skin.Appearance;
        var skinName = appearance.skinName;
        var equipments = appearance.getAppearanceItemList({ alternative: altEquip });
        equipments.push(weapon.Settings.Component);
        tags = tags.concat(appearance.Tags);
        for (var _a = 0, chosenTaunts_1 = chosenTaunts; _a < chosenTaunts_1.length; _a++) {
            var id = chosenTaunts_1[_a];
            var taunt = tauntsMap.checkedGet(id);
            tags = tags.concat(taunt.Tags);
        }
        tags.push.apply(tags, ArrayUtils.ensureArray(weapon.Settings.Tag));
        var stanceTag = "";
        for (var _b = 0, _c = settings.stanceIds; _b < _c.length; _b++) {
            var stID = _c[_b];
            var stance = stancesMap.checkedGet(stID);
            tags.push(stance.Settings.Tag);
            if (stance.Settings.StanceType == STANCE_TYPE.START_POSE) {
                stanceTag = stance.Settings.Tag;
            }
        }
        for (var side in shadowAbilities) {
            var shAbility = shadowAbilities[side];
            if (shAbility && shAbility.Tag) {
                tags.push(shAbility.Tag);
            }
        }
        for (var squadHeroId in otherSquadHeroesTalents) {
            var talentIds = otherSquadHeroesTalents[squadHeroId];
            for (var _d = 0, talentIds_1 = talentIds; _d < talentIds_1.length; _d++) {
                var talentId = talentIds_1[_d];
                var talent = talentsMap.checkedGet(talentId);
                var talentTag = talent.getTag(talentIds);
                if (talent.StackTalentsForSquad) {
                    tags.push(talentTag);
                    tagsWithQuantity[talentTag] = (tagsWithQuantity[talentTag] || 0) + 1;
                }
            }
        }
        tags = ArrayUtils.getUniqueArray(tags);
        return {
            id: origWarrior.ID,
            alias: origWarrior.Alias,
            skinName: skinName,
            equipments: equipments,
            shadowAbilities: shadowAbilities,
            tags: tags,
            talents: talents ? talents : [],
            stanceTag: stanceTag,
            tagsWithQuantity: tagsWithQuantity,
        };
    };
    BattleUtils.DefineHeroWeapon = function (hero, weaponId) {
        if (!weaponId) {
            var defaultSkin = skinsMap.checkedGet(hero.DefaultSkinId);
            return weaponsMap.checkedGet(defaultSkin.DefaultWeaponId);
        }
        else {
            return weaponsMap.checkedGet(weaponId);
        }
    };
    BattleUtils.DefineWeaponAspects = function (weapon, aspectId) {
        var aspects = weapon.Settings.Aspects;
        if (aspects.length > 0) {
            var aspectIndex = 0;
            if (aspectId) {
                for (var i = 0; i < aspects.length; i++) {
                    if (aspects[i].ID == aspectId) {
                        aspectIndex = i;
                        break;
                    }
                }
            }
            return aspects[aspectIndex];
        }
        return null;
    };
    BattleUtils.getConfigsForAttributes = function (settings) {
        var configs = new AttributesConfigs();
        var hero = heroesMap.checkedGet(settings.heroID);
        var weapon = this.DefineHeroWeapon(hero, settings.weaponId);
        var aspect = this.DefineWeaponAspects(weapon, settings.weaponAspectId);
        var weaponAspectAttributes = aspect ? aspect.attributesMultipliers : {};
        configs.heroAttributes = hero.getHeroAttributes();
        configs.fakeHeroAttributes = hero.getFakeAttributes();
        configs.weaponHeroAttributes = weapon.Settings.AttributesMultipliers;
        configs.shiftWeaponHeroAttributes = weapon.Settings.AttributeShifts;
        configs.multipliersFromTalents = getAttributeMultipliersFromTalents(settings.talents);
        configs.multipliersFromHeroLevels = hero.getLevelAttributesByLevel(settings.warriorLevel);
        configs.shiftsFromTalents = getAttributeShiftsFromTalents(settings.talents);
        configs.accountAttributeCustomMultiplier = HeroConstants.accountAttributeCustomMultiplier;
        configs.accountMultiplier = HeroConstants.accountMultiplier;
        configs.weaponAspectAttributes = weaponAspectAttributes;
        return configs;
    };
    return BattleUtils;
}());
