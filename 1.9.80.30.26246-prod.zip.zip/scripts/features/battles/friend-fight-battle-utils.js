var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var FriendFightBattleUtils = (function () {
    function FriendFightBattleUtils() {
    }
    FriendFightBattleUtils.duplicateFriendFightsForLocalFight = function (battlesMap, startBoundCreatingId, endBoundCreatingId) {
        var _a;
        var friendBattles = [];
        for (var name_1 in battlesMap) {
            var battle = battlesMap[name_1];
            if (battle.FightMode == FIGHT_MODE.FRIEND) {
                friendBattles.push(battle);
            }
        }
        friendBattles
            .sort(function (a, b) { return a.ID - b.ID; });
        for (var _i = 0, friendBattles_1 = friendBattles; _i < friendBattles_1.length; _i++) {
            var battle = friendBattles_1[_i];
            var id = startBoundCreatingId++;
            if (id > endBoundCreatingId) {
                throw new Error("duplicateFriendFightsForLocalFight: cant create battle with id ".concat(id, "."));
            }
            var name_2 = "duplicate_friend_battle_".concat(id);
            if (battlesMap[name_2] != undefined) {
                throw new Error("duplicateFriendFightsForLocalFight: name '".concat(name_2, "' already exist."));
            }
            battlesMap[name_2] = __assign(__assign({}, battle), { ID: id, FightMode: FIGHT_MODE.LOCAL_PVP_FRIEND, GameSettings: __assign(__assign({}, battle.GameSettings), (_a = {}, _a[TEAM_MODE._1_VS_1_] = __assign(__assign({}, battle.GameSettings[TEAM_MODE._1_VS_1_]), { Tags: __spreadArray(__spreadArray([], (battle.GameSettings[TEAM_MODE._1_VS_1_].Tags || []), true), [
                        "LOCAL_PVP"
                    ], false) }), _a)) });
            FriendFightBattleUtils.duplicatedLocalFriendFights[battle.ID] = id;
        }
    };
    FriendFightBattleUtils.getLocalFriendFightDuplicateIdByOriginalId = function (id) {
        return FriendFightBattleUtils.duplicatedLocalFriendFights[id];
    };
    FriendFightBattleUtils.duplicatedLocalFriendFights = {};
    return FriendFightBattleUtils;
}());
