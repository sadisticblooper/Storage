var _a;
var lobbyDefaultEffects = (_a = {},
    _a[LOBBY_LOCATION.BATTLEPASS] = { path: "Effects/Prefabs/Common/Events/Premium_Lobby/PL_Snow_Lobby", position: { x: 0, y: 0, z: 0 } },
    _a);
var lobbyEffectPeriods = [];
