function isBgVfxEnabled() {
    return true;
}
function getActiveLobbyEffectPeriod(arg) {
    for (var _i = 0, lobbyEffectPeriods_1 = lobbyEffectPeriods; _i < lobbyEffectPeriods_1.length; _i++) {
        var period = lobbyEffectPeriods_1[_i];
        if (arg.serverTime >= period.startTime && arg.serverTime < period.endTime) {
            var config = period.effects[arg.lobbyLocation];
            if (config) {
                return {
                    id: period.id,
                    backgroundVfxPath: config.path,
                    position: config.position,
                };
            }
        }
    }
    var defaultConfig = lobbyDefaultEffects[arg.lobbyLocation];
    if (defaultConfig) {
        return {
            id: "default",
            backgroundVfxPath: defaultConfig.path,
            position: defaultConfig.position,
        };
    }
    return null;
}
