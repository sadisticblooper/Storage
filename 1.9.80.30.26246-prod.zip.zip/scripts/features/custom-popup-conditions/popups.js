var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
CustomPopUpConditions.add(__spreadArray(__spreadArray([
    {
        daysOfWeek: [
            DayOfWeek.Monday,
            DayOfWeek.Wednesday,
            DayOfWeek.Saturday,
        ],
        condition: function (s) { return s.playerProgress.maxPlayerRating >= 70; },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100000,
                    "priority": 4,
                    "navigation": POPUP_NAVIGATION.ROULETTE,
                    "navigationArg": 4,
                    "activeTime": [{
                            start: new Date("2023-01-01").getTime(),
                            end: new Date("2030-01-01").getTime()
                        }],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 19,
                    "rulesDescription": {
                        "alias": "roulette_new_players_popup_title",
                        "color": "#ff4747"
                    },
                    "rulesHeader": {
                        "alias": "roulette_new_players_attention",
                        "color": "#ffffff"
                    },
                    "header": {
                        "alias": "roulette_title_new_players",
                        "color": "#ffffff"
                    },
                    "subHeader": null,
                    "timer": {
                        "alias": "quest_ends_timer",
                        "color": "#ffd75e"
                    },
                    "button": {
                        "alias": "button_roulette",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/UniversalLuckyboard/art_activity_adLuckyboard",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/UniversalLuckyboard/bg_activity_adLuckyboard",
                        "color": "#e5e0d1"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#FF4747"
                    },
                    "particles": {
                        "maxColor": "#FF47474C",
                        "minColor": "#FF4747FA"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a2727"
                            },
                            {
                                "time": 0.98,
                                "color": "#8a2727"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a2727"
                            },
                            {
                                "time": 0.99,
                                "color": "#e5bc40"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "roulette_new_players_popup_a",
                            "color": "#ffd147"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "roulette_new_players_popup_b",
                            "color": "#ffd147"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "roulette_new_players_popup_c",
                            "color": "#ffd147"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Halloween_Event22/pattern_halloween",
                        "color": "#735e20"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-02-27").getTime(), end: new Date("2025-03-14").getTime() },
        ],
        condition: function (s) { return s.playerProgress.playerRating >= 40; },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100011,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://ninjaparty.com/?videoId=6l6_bZSmNs8",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-02-27").getTime(), end: new Date("2025-03-14").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": icons.icon_ninja_party.ID,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "np_teaser_trailer",
                        "color": "#ffe81a"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#ba75ff"
                    },
                    "particles": {
                        "maxColor": "#ba75ff",
                        "minColor": "#ba75ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#5C44A1"
                            },
                            {
                                "time": 0.98,
                                "color": "#5C44A1"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#235eb8"
                            },
                            {
                                "time": 0.99,
                                "color": "#521a8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_1",
                            "color": "#c68cff"
                        },
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_2",
                            "color": "#c68cff"
                        },
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_3",
                            "color": "#c68cff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                        "color": "#6d23b8FF"
                    },
                    "customPrefabPath": ""
                }
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-03-19T18:00:00Z").getTime(), end: new Date("2025-03-26").getTime() },
        ],
        condition: function (s) { return s.playerProgress.maxPlayerRating > 20; },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100012,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://sf3.onelink.me/S2uR/LegSF3",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-03-19T18:00:00Z").getTime(), end: new Date("2025-03-26").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 25,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "popup_title_crosspromo_leg_lynx",
                        "color": "#e6352c"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Lynx_L_Hood/art_event_Lynx_L_Hood",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Lynx_L_Hood/bg_event_Lynx_L_Hood",
                        "color": "#63588a"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#8a201a"
                    },
                    "particles": {
                        "maxColor": "#ffb647",
                        "minColor": "#ffb647"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a201a"
                            },
                            {
                                "time": 0.98,
                                "color": "#8a201a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a201a"
                            },
                            {
                                "time": 0.99,
                                "color": "#63588a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_crosspromo_leg_lynx_bulletpoint1",
                            "color": "#a593e6"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_crosspromo_leg_lynx_bulletpoint2",
                            "color": "#a593e6"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_crosspromo_leg_lynx_bulletpoint3",
                            "color": "#a593e6"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Lynx_L_Hood/pattern_Lynx_L_Hood",
                        "color": "#8476B82E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-04-17T23:00:00+03:00").getTime(), end: new Date("2025-04-25").getTime() },
        ],
        condition: function (s) { return s.playerProgress.playerRating >= 40; },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100013,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://youtu.be/csvu1olK1mU",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-04-17T23:00:00+03:00").getTime(), end: new Date("2025-04-25").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": icons.icon_ninja_party.ID,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "np_teaser_trailer_new",
                        "color": "#ffe81a"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#ba75ff"
                    },
                    "particles": {
                        "maxColor": "#ba75ff",
                        "minColor": "#ba75ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#5C44A1"
                            },
                            {
                                "time": 0.98,
                                "color": "#5C44A1"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#235eb8"
                            },
                            {
                                "time": 0.99,
                                "color": "#521a8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_1",
                            "color": "#c68cff"
                        },
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_2",
                            "color": "#c68cff"
                        },
                        {
                            "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                            "alias": "np_teaser_trailer_bulletpoint_3",
                            "color": "#c68cff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                        "color": "#6d23b8FF"
                    },
                    "customPrefabPath": ""
                }
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-04-17T23:00:00+03:00").getTime(), end: new Date("2025-04-25").getTime() },
        ],
        condition: function (s) { return s.playerProgress.playerRating >= 40; },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100014,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://www.youtube.com/watch?v=pZbHDdd5drA",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-04-17T23:00:00+03:00").getTime(), end: new Date("2025-04-25").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 27,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "spine_promo_header",
                        "color": "#b3ff5c"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/SPINE_art_4",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/SPINE_bg_4",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#0aadff"
                    },
                    "particles": {
                        "maxColor": "#0aadff",
                        "minColor": "#0aadff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#077db8"
                            },
                            {
                                "time": 0.98,
                                "color": "#077db8"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#077db8"
                            },
                            {
                                "time": 0.99,
                                "color": "#b807ac"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/decor_spine_bullet_point",
                            "alias": "spine_promo_desc_1",
                            "color": "#b3ff5c"
                        },
                        {
                            "icon": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/decor_spine_bullet_point",
                            "alias": "spine_promo_desc_2",
                            "color": "#b3ff5c"
                        },
                        {
                            "icon": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/decor_spine_bullet_point",
                            "alias": "spine_promo_desc_3",
                            "color": "#b3ff5c"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/pattern_spine",
                        "color": "#FFFFFF6E"
                    },
                    "customPrefabPath": ""
                },
            },
        ]),
    }
], (function () {
    return [
        {
            id: 100015, pls: [PLATFORM.IOS, PLATFORM.IOS_EGS, PLATFORM.IOS_VIETNAM].map(function (p) { return p.toString(); }),
            name: "ios"
        },
        {
            id: 100016, pls: [PLATFORM.ANDROID, PLATFORM.HUAWEI, PLATFORM.XSOLLA, PLATFORM.ANDROID_EGS, PLATFORM.ANDROID_VIETNAM].map(function (p) { return p.toString(); }),
            name: "android"
        },
    ].map(function (EL) {
        return {
            activeTimes: [
                { start: new Date("2025-05-15").getTime(), end: new Date("2025-06-30").getTime() },
            ],
            collapseIdInActiveTime: true,
            condition: function (s) {
                return s.playerProgress.playerRating >= 40 && EL.pls.indexOf(s.regionalSettings.platform.toString()) > -1;
            },
            popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
                {
                    data: {
                        "ID": EL.id,
                        "priority": 3,
                        "navigation": POPUP_NAVIGATION.URL,
                        "navigationLinkURL": "https://ninjaparty.onelink.me/XCsQ/xoq5cd2c",
                        "navigationArg": 0,
                        "activeTime": [
                            { start: new Date("2025-05-15").getTime(), end: new Date("2025-06-30").getTime() },
                        ],
                        "endDate": null,
                    },
                    visual: {
                        "displayedCurrencies": null,
                        "iconId": 36,
                        "rulesDescription": null,
                        "rulesHeader": null,
                        "header": {
                            "alias": "np_preregistration_popup_".concat(EL.name, "_header"),
                            "color": "#ffe81a"
                        },
                        "subHeader": null,
                        "timer": null,
                        "button": {
                            "alias": "button_proceed",
                            "frameColor": "#75FF83",
                            "glow1Color": "#D7FFCE",
                            "glow2Color": "#D7FFCE",
                            "effect1Color": "#75FF83",
                            "effect2Color": "#75FF83",
                            "effect3Color": "#75FF83",
                            "effect4Color": "#75FF83",
                            "corner1Color": "#75FF83",
                            "corner2Color": "#75FF83"
                        },
                        "preview": {
                            "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art_Kibo",
                            "color": "#ffffff"
                        },
                        "background": {
                            "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg",
                            "color": "#ffffff"
                        },
                        "backgroundEffect": {
                            "sprite": "",
                            "color": "#ba75ff"
                        },
                        "particles": {
                            "maxColor": "#ba75ff",
                            "minColor": "#ba75ff"
                        },
                        "gradientLeft": {
                            "mode": 0,
                            "colorKeys": [
                                {
                                    "time": 0,
                                    "color": "#5C44A1"
                                },
                                {
                                    "time": 0.98,
                                    "color": "#5C44A1"
                                }
                            ],
                            "alphaKeys": [
                                {
                                    "time": 0,
                                    "alpha": 1
                                },
                                {
                                    "time": 1,
                                    "alpha": 0
                                }
                            ]
                        },
                        "gradientRight": {
                            "mode": 0,
                            "colorKeys": [
                                {
                                    "time": 0,
                                    "color": "#235eb8"
                                },
                                {
                                    "time": 0.99,
                                    "color": "#521a8a"
                                }
                            ],
                            "alphaKeys": [
                                {
                                    "time": 0,
                                    "alpha": 1
                                },
                                {
                                    "time": 1,
                                    "alpha": 1
                                }
                            ]
                        },
                        "descriptionItems": [
                            {
                                "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                                "alias": "np_preregistration_popup_".concat(EL.name, "_point1"),
                                "color": "#c68cff"
                            },
                            {
                                "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                                "alias": "np_preregistration_popup_".concat(EL.name, "_point2"),
                                "color": "#c68cff"
                            },
                            {
                                "icon": "Sprites/Assets/Fight/decor_rhombus_small",
                                "alias": "np_preregistration_popup_".concat(EL.name, "_point3"),
                                "color": "#c68cff"
                            }
                        ],
                        "pattern": {
                            "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                            "color": "#6d23b8FF"
                        },
                        "customPrefabPath": ""
                    },
                },
            ]),
        };
    });
})(), true), [
    {
        activeTimes: [
            {
                start: new Date("2025-06-19").getTime(),
                end: new Date("2030-01-01").getTime()
            },
        ],
        condition: function (s) {
            if (SteamPlatformUtils.isPCBuild(s.regionalSettings.platform)) {
                return false;
            }
            return (s.paymentSum === 0 && s.serverTime > s.regionalSettings.createdPlayerTime + new Time({ Days: 21 }).value);
        },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100017,
                    "priority": 5,
                    "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
                    "navigationArg": 0,
                    "navigationLinkURL": "sfa://tapjoy",
                    "activeTime": [{
                            start: new Date("2025-06-19").getTime(),
                            end: new Date("2030-01-01").getTime()
                        }],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 20,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "popup_tapjoy_title",
                        "color": "#ff4747"
                    },
                    "description": {
                        "alias": "popup_tapjoy",
                        "color": "#ffffff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/Tapjoy/tapjoy_art",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/Tapjoy/tapjoy_bg",
                        "color": "#521E1E"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#ff3030"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#8a2727",
                        "minColor": "#ff4747"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a2727"
                            },
                            {
                                "time": 0.98,
                                "color": "#8a2727"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#a11010"
                            },
                            {
                                "time": 0.99,
                                "color": "#2e1515"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                        "color": "#73353599"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 0
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-06-19").getTime(), end: new Date("2025-06-25").getTime() },
        ],
        condition: function (s) { return s.playerProgress.playerRating >= 40; },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100018,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://www.youtube.com/watch?v=wD1o_XY60ic",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-06-19").getTime(), end: new Date("2025-06-25").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": icons.icon_RAIKICHI.ID,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "popup_raikihi_title",
                        "color": "#a3acff"
                    },
                    "description": null,
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Raikichi/art_activity_RaikichiTrailer",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Raikichi/bg_raikichi",
                        "color": "#5e87ff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#a3acff"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#a3acff",
                        "minColor": "#767cb8"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#767cb8"
                            },
                            {
                                "time": 0.98,
                                "color": "#767cb8"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#2a3d73"
                            },
                            {
                                "time": 0.99,
                                "color": "#0d0e17"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_raikihi_bulletpoint_1",
                            "color": "#a3acff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_raikihi_bulletpoint_2",
                            "color": "#a3acff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_raikihi_bulletpoint_3",
                            "color": "#a3acff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/WidowEvent/pattern_widow",
                        "color": "#00000033"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 3000
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-07-03").getTime(), end: new Date("2025-07-11").getTime() },
        ],
        condition: function (s) {
            return s.playerProgress.playerRating >= 40 &&
                [PLATFORM.ANDROID, PLATFORM.HUAWEI, PLATFORM.XSOLLA, PLATFORM.ANDROID_EGS, PLATFORM.ANDROID_VIETNAM].map(function (p) { return p.toString(); })
                    .indexOf(s.regionalSettings.platform.toString()) > -1;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100019,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://ninjaparty.onelink.me/XCsQ/xoq5cd2c",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-07-03").getTime(), end: new Date("2025-07-11").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 36,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "np_promo_header",
                        "color": "#ffe81a"
                    },
                    "subHeader": null,
                    "description": {
                        "alias": "np_promo_desc",
                        "color": "#ffffff"
                    },
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art_Itu",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg_2",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#e58240"
                    },
                    "particles": {
                        "maxColor": "#cf3ab4",
                        "minColor": "#920df5"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.98,
                                "color": "#b86833"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.99,
                                "color": "#8a2762"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                        "color": "#DB3F9CFF"
                    },
                    "customPrefabPath": ""
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-07-31T15:00:00+03:00").getTime(), end: new Date("2025-08-15").getTime() },
        ],
        condition: function (s) {
            var platform = s.regionalSettings.platform.toString();
            if ([PLATFORM.IOS, PLATFORM.IOS_EGS, PLATFORM.IOS_CHINA, PLATFORM.IOS_VIETNAM].map(function (p) { return p.toString(); }).indexOf(platform) > -1) {
                return false;
            }
            return s.playerProgress.playerRating >= 40;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100020,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://ninjaparty.onelink.me/XCsQ/xoq5cd2c",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-07-31T15:00:00+03:00").getTime(), end: new Date("2025-08-15").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 36,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "np_promo_release_header",
                        "color": "#ffe81a"
                    },
                    "subHeader": null,
                    "description": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art_Lynx",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg_2",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#e58240"
                    },
                    "particles": {
                        "maxColor": "#cf3ab4",
                        "minColor": "#920df5"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.98,
                                "color": "#b86833"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.99,
                                "color": "#8a2762"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "np_promo_release_bulletpoint_1",
                            "color": "#e68240"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "np_promo_release_bulletpoint_2",
                            "color": "#e68240"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "np_promo_release_bulletpoint_3",
                            "color": "#e68240"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                        "color": "#DB3F9CFF"
                    },
                    "customPrefabPath": ""
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-07-24").getTime(), end: new Date("2025-07-27").getTime() },
            { start: new Date("2025-07-27").getTime(), end: new Date("2025-07-29").getTime() },
            { start: new Date("2025-07-29").getTime(), end: new Date("2025-08-01").getTime() },
            { start: new Date("2025-08-01").getTime(), end: new Date("2025-08-04").getTime() },
        ],
        condition: function (s) {
            var requiredSkins = [skins.Lynx_L_Hood.ID, skins.Legion_King_L_Castle.ID, skins.Itu_L_Cosmic.ID];
            var playerSkins = s.playerProgress.skins;
            return requiredSkins.some(function (skinId) {
                return playerSkins.indexOf(skinId) !== -1;
            });
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100021,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://docs.google.com/forms/d/e/1FAIpQLSd0EEqsJtJvcWMX8wVVHnvvFpTFuhWmxqMze9tj3NcZXHICKg/viewform?usp=dialog",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-07-24").getTime(), end: new Date("2025-07-27").getTime() },
                        { start: new Date("2025-07-27").getTime(), end: new Date("2025-07-29").getTime() },
                        { start: new Date("2025-07-29").getTime(), end: new Date("2025-08-01").getTime() },
                        { start: new Date("2025-08-01").getTime(), end: new Date("2025-08-04").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 39,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "Lynx_Questionnaire_popup_title",
                        "color": "#a3c8ff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "Lynx_Questionnaire_button",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/art_event_Legion_King_L_Castle",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/bg_event_legskins",
                        "color": "#a3c8ff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#a3c8ff98"
                    },
                    "particles": {
                        "maxColor": "#d1f1ff",
                        "minColor": "#d1f1ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#2c3d45"
                            },
                            {
                                "time": 0.98,
                                "color": "#2c3d45"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#71828a"
                            },
                            {
                                "time": 0.99,
                                "color": "#586c8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "description": {
                        "alias": "Lynx_Questionnaire_additional_points_1_skin_chest",
                        "color": "#ffffff"
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/pattern_Legion_King_L_Castle",
                        "color": "#2A363A73"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
            { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
            { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
            { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
            { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
            { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
            { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            return WORLD_PROD_EU_COUNTRIES.some(function (euCountry) { return playerCountry === euCountry; });
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100022,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.MARATHONS,
                    "navigationArg": 30001,
                    "countryCode": WORLD_PROD_EU_COUNTRIES,
                    "activeTime": [
                        { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
                        { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
                        { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
                        { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
                        { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
                        { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
                        { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 30,
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#FFFFFF"
                    },
                    "rulesDescription": {
                        "alias": "popup_rules_clan_test_tournament_EU",
                        "color": "#1190cd"
                    },
                    "header": {
                        "alias": "popup_title_clan_test_tournament",
                        "color": "#e6c493"
                    },
                    "description": null,
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_art_hypothesis",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_bg_hypothesis",
                        "color": "#8a7658"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#5ee7ff"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#54aebe",
                        "minColor": "#337d8a"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#337d8a"
                            },
                            {
                                "time": 0.98,
                                "color": "#337d8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#44b8b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#b89d76"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_1",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_2_EU",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_3",
                            "color": "#5ee7ff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                        "color": "#b89d76FF"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 0
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
            { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
            { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
            { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
            { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
            { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
            { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            return WORLD_PROD_US_COUNTRIES.some(function (usCountry) { return playerCountry === usCountry; });
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100023,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.MARATHONS,
                    "navigationArg": 30002,
                    "countryCode": WORLD_PROD_US_COUNTRIES,
                    "activeTime": [
                        { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
                        { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
                        { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
                        { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
                        { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
                        { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
                        { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 30,
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#FFFFFF"
                    },
                    "rulesDescription": {
                        "alias": "popup_rules_clan_test_tournament_US",
                        "color": "#1190cd"
                    },
                    "header": {
                        "alias": "popup_title_clan_test_tournament",
                        "color": "#e6c493"
                    },
                    "description": null,
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_art_hypothesis",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_bg_hypothesis",
                        "color": "#8a7658"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#5ee7ff"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#54aebe",
                        "minColor": "#337d8a"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#337d8a"
                            },
                            {
                                "time": 0.98,
                                "color": "#337d8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#44b8b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#b89d76"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_1",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_2_US",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_3",
                            "color": "#5ee7ff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                        "color": "#b89d76FF"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 0
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
            { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
            { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
            { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
            { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
            { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
            { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            return WORLD_PROD_AS_COUNTRIES.some(function (asCountry) { return playerCountry === asCountry; });
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100024,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.MARATHONS,
                    "navigationArg": 30003,
                    "countryCode": WORLD_PROD_AS_COUNTRIES,
                    "activeTime": [
                        { start: new Date("2025-08-04").getTime(), end: new Date("2025-08-05").getTime() },
                        { start: new Date("2025-08-07").getTime(), end: new Date("2025-08-08").getTime() },
                        { start: new Date("2025-08-11").getTime(), end: new Date("2025-08-12").getTime() },
                        { start: new Date("2025-08-14").getTime(), end: new Date("2025-08-15").getTime() },
                        { start: new Date("2025-08-18").getTime(), end: new Date("2025-08-19").getTime() },
                        { start: new Date("2025-08-21").getTime(), end: new Date("2025-08-22").getTime() },
                        { start: new Date("2025-08-25").getTime(), end: new Date("2025-08-26").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 30,
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#FFFFFF"
                    },
                    "rulesDescription": {
                        "alias": "popup_rules_clan_test_tournament_AS",
                        "color": "#1190cd"
                    },
                    "header": {
                        "alias": "popup_title_clan_test_tournament",
                        "color": "#e6c493"
                    },
                    "description": null,
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_art_hypothesis",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Hypothesis/popup_bg_hypothesis",
                        "color": "#8a7658"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#5ee7ff"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#54aebe",
                        "minColor": "#337d8a"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#337d8a"
                            },
                            {
                                "time": 0.98,
                                "color": "#337d8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#44b8b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#b89d76"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_1",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_2_AS",
                            "color": "#5ee7ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "clant_test_tournament_popup_additional_point_3",
                            "color": "#5ee7ff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                        "color": "#b89d76FF"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 0
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-09-02").getTime(), end: new Date("2025-09-17").getTime() },
        ],
        condition: function (s) {
            var platform = s.regionalSettings.platform.toString();
            var platformPassed = [PLATFORM.IOS, PLATFORM.IOS_EGS, PLATFORM.IOS_CHINA, PLATFORM.IOS_VIETNAM].map(function (p) { return p.toString(); }).indexOf(platform) > -1;
            return s.playerProgress.playerRating >= 40 && platformPassed;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100025,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://ninjaparty.onelink.me/XCsQ/xoq5cd2c",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-09-02").getTime(), end: new Date("2025-09-17").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 36,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "ninja_party_ios_header",
                        "color": "#ffe81a"
                    },
                    "subHeader": null,
                    "description": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_art_Lynx",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_bg_2",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#e58240"
                    },
                    "particles": {
                        "maxColor": "#cf3ab4",
                        "minColor": "#920df5"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.98,
                                "color": "#b86833"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#b86833"
                            },
                            {
                                "time": 0.99,
                                "color": "#8a2762"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "ninja_party_ios_bulletpoint_1",
                            "color": "#e68240"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "ninja_party_ios_bulletpoint_2",
                            "color": "#e68240"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "ninja_party_ios_bulletpoint_3",
                            "color": "#e68240"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/AdvertisingNP/NP_pattern",
                        "color": "#DB3F9CFF"
                    },
                    "customPrefabPath": ""
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-09-26").getTime(), end: new Date("2025-09-27").getTime() },
            { start: new Date("2025-09-28").getTime(), end: new Date("2025-09-29").getTime() },
            { start: new Date("2025-09-30").getTime(), end: new Date("2025-10-01").getTime() },
        ],
        condition: function (s) {
            var requiredSkin = skins.Itu_L_Cosmic.ID;
            var playerSkins = s.playerProgress.skins;
            return playerSkins.indexOf(requiredSkin) === -1;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100026,
                    "priority": 7,
                    "navigation": POPUP_NAVIGATION.ROULETTE,
                    "navigationArg": 5003,
                    "activeTime": [
                        { start: new Date("2025-09-26").getTime(), end: new Date("2025-09-27").getTime() },
                        { start: new Date("2025-09-28").getTime(), end: new Date("2025-09-29").getTime() },
                        { start: new Date("2025-09-30").getTime(), end: new Date("2025-10-01").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 33,
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#FFFFFF"
                    },
                    "rulesDescription": {
                        "alias": "popup_presentation_the_itu_leg_skin",
                        "color": "#158ed1"
                    },
                    "header": {
                        "alias": "leg_skin_Itu_presentation_popup_title",
                        "color": "#ffe3ba"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_roulette",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Itu_L_Cosmic/art_event_Itu_L_Cosmic",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/Itu_L_Cosmic/bg_activity_Itu_L_Cosmic",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#FFE3BA98"
                    },
                    "particles": {
                        "maxColor": "#bcd9e5",
                        "minColor": "#ffe3ba"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#273f8a"
                            },
                            {
                                "time": 0.98,
                                "color": "#273f8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#273f8a"
                            },
                            {
                                "time": 0.99,
                                "color": "#cf3ac0"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_itu_leg_skin_points1",
                            "color": "#cf3ac0"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_itu_leg_skin_points2",
                            "color": "#cf3ac0"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_itu_leg_skin_points3",
                            "color": "#cf3ac0"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                        "color": "#FFFFFF67"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-09-25").getTime(), end: new Date("2025-10-17").getTime() },
        ],
        condition: function (s) {
            var playerCompanyName = s.regionalSettings.companyName;
            var xsollaCompanyNames = ["GA_asfa_xsollatest_WW_AllLang_Val_tRoas_250925", "FB_asfa_xsollatest_AAC_WW_LAL_Val_250925"];
            var companyPassed = playerCompanyName &&
                xsollaCompanyNames.some(function (companyName) { return playerCompanyName.indexOf(companyName) !== -1; });
            return companyPassed;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100027,
                    "priority": 3,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://sf-arena-main.xsolla.site/store",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-09-25").getTime(), end: new Date("2025-10-17").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": icons.icon_arena_violet.ID,
                    "rulesHeader": null,
                    "rulesDescription": null,
                    "header": {
                        "alias": "popup_webshop_title",
                        "color": "#a393e6"
                    },
                    "description": {
                        "alias": "popup_webshop_desc",
                        "color": "#ffffff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_webshop",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/Webshop/popup_art_webshop",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/Webshop/popup_bg_webshop",
                        "color": "#63588a"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#a393e5"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#a3acff",
                        "minColor": "#a393e5"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a2260"
                            },
                            {
                                "time": 0.98,
                                "color": "#8a2260"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#8a2260"
                            },
                            {
                                "time": 0.99,
                                "color": "#63588a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/Webshop/popup_pattern_webshop",
                        "color": "#00000024"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 0
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-11-10").getTime(), end: new Date("2025-11-14").getTime() },
        ],
        condition: function (s) {
            return true;
        },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100030,
                    "priority": 9,
                    "navigation": POPUP_NAVIGATION.URL,
                    navigationLinkURL: "https://www.youtube.com/watch?v=-kNla5p0yvg",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-11-10").getTime(), end: new Date("2025-11-14").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 46,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "popup_nonna_title",
                        "color": "#e67f2c"
                    },
                    "description": null,
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/NonnaPromo/popup_art_nonna_promo",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Advertising/NonnaPromo/popup_bg_nonna_promo",
                        "color": "#8a1a1a"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#cf2727"
                    },
                    "bigIcon": null,
                    "particles": {
                        "maxColor": "#cf2727",
                        "minColor": "#cf2727"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#2e0909"
                            },
                            {
                                "time": 0.98,
                                "color": "#2e0909"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#2e0909"
                            },
                            {
                                "time": 0.99,
                                "color": "#733400"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_nonna_bulletpoint_1",
                            "color": "#e67f2c"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_nonna_bulletpoint_2",
                            "color": "#e67f2c"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_nonna_bulletpoint_3",
                            "color": "#e67f2c"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Advertising/NonnaPromo/popup_pattern_nonna_promo",
                        "color": "#8A7F7D2E"
                    },
                    "customPrefabPath": "",
                    "skipTimeMs": 3000
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2025-12-16").getTime(), end: new Date("2025-12-17").getTime() },
            { start: new Date("2025-12-17").getTime(), end: new Date("2025-12-18").getTime() },
            { start: new Date("2025-12-18").getTime(), end: new Date("2025-12-19").getTime() },
        ],
        collapseIdInActiveTime: true,
        condition: function (s) {
            return true;
        },
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100031,
                    "priority": 9,
                    "navigation": POPUP_NAVIGATION.URL,
                    navigationLinkURL: "https://www.youtube.com/watch?v=l__0Gz8jm80",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2025-12-16").getTime(), end: new Date("2025-12-17").getTime() },
                        { start: new Date("2025-12-17").getTime(), end: new Date("2025-12-18").getTime() },
                        { start: new Date("2025-12-18").getTime(), end: new Date("2025-12-19").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 48,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "popup_mk_skin_trailer_title",
                        "color": "#e6c155"
                    },
                    "subHeader": null,
                    "description": null,
                    "timer": null,
                    "button": {
                        "alias": "button_watch_trailer",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_art_legskin_mk",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_bg_legskin_mk",
                        "color": "#a3baff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#b48cff"
                    },
                    "particles": {
                        "maxColor": "#b48cff",
                        "minColor": "#b48cff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#3d2073"
                            },
                            {
                                "time": 0.98,
                                "color": "#3d2073"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#6233b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#8ca9ff"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_mk_skin_trailer_bulletpoint_1",
                            "color": "#e6c155"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_mk_skin_trailer_bulletpoint_2",
                            "color": "#e6c155"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_mk_skin_trailer_bulletpoint_3",
                            "color": "#e6c155"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_pattern_legskin_mk",
                        "color": "#4775FF2E"
                    },
                    "customPrefabPath": "",
                    skipTimeMs: 3000
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
            { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
            { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
            { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            var correctCountry = ["RU"].some(function (asCountry) { return playerCountry === asCountry; });
            var skinRarity = SKIN_RARITY.LEGENDARY;
            var playerSkins = s.playerProgress.skins;
            var hasLegendarySkin = false;
            for (var _i = 0, playerSkins_1 = playerSkins; _i < playerSkins_1.length; _i++) {
                var skin = playerSkins_1[_i];
                var model = skinsMap.checkedGet(skin);
                if (model.rarity == skinRarity)
                    hasLegendarySkin = true;
            }
            return hasLegendarySkin && correctCountry;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100032,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://docs.google.com/forms/d/e/1FAIpQLSdGgA0WUtyXkXpKUKOh6FWcxIHF3t6eimPFTk4l4HT6Wzb42A/viewform?usp=dialog",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
                        { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
                        { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
                        { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 48,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "Lynx_Questionnaire_popup_title",
                        "color": "#e6c155"
                    },
                    "subHeader": null,
                    "description": {
                        "alias": "Lynx_Questionnaire_additional_points_1_skin_chest",
                        "color": "#ffffff"
                    },
                    "timer": null,
                    "button": {
                        "alias": "Lynx_Questionnaire_button",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_art_legskin_mk",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_bg_legskin_mk",
                        "color": "#a3baff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#b48cff"
                    },
                    "particles": {
                        "maxColor": "#b48cff",
                        "minColor": "#b48cff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#3d2073"
                            },
                            {
                                "time": 0.98,
                                "color": "#3d2073"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#6233b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#8ca9ff"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_pattern_legskin_mk",
                        "color": "#4775FF2E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
            { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
            { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
            { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            var isIgnoredCountry = __spreadArray(__spreadArray([], CIS_COUNTRIES, true), ["RU", "TR", "VN"], false).some(function (ignoredCountry) { return playerCountry === ignoredCountry; });
            var skinRarity = SKIN_RARITY.LEGENDARY;
            var playerSkins = s.playerProgress.skins;
            var hasLegendarySkin = false;
            for (var _i = 0, playerSkins_2 = playerSkins; _i < playerSkins_2.length; _i++) {
                var skin = playerSkins_2[_i];
                var model = skinsMap.checkedGet(skin);
                if (model.rarity == skinRarity)
                    hasLegendarySkin = true;
            }
            return hasLegendarySkin && !isIgnoredCountry;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100033,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://docs.google.com/forms/d/e/1FAIpQLSePbNrzhcugR7Vm-cC2ytjTfhPeEVy_h1wMe9aJLUmIimBbJg/viewform?usp=dialog",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
                        { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
                        { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
                        { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 48,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "Lynx_Questionnaire_popup_title",
                        "color": "#e6c155"
                    },
                    "subHeader": null,
                    "description": {
                        "alias": "Lynx_Questionnaire_additional_points_1_skin_chest",
                        "color": "#ffffff"
                    },
                    "timer": null,
                    "button": {
                        "alias": "Lynx_Questionnaire_button",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_art_legskin_mk",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_bg_legskin_mk",
                        "color": "#a3baff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#b48cff"
                    },
                    "particles": {
                        "maxColor": "#b48cff",
                        "minColor": "#b48cff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#3d2073"
                            },
                            {
                                "time": 0.98,
                                "color": "#3d2073"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#6233b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#8ca9ff"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_pattern_legskin_mk",
                        "color": "#4775FF2E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
            { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
            { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
            { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            var correctCountry = ["TR"].some(function (asCountry) { return playerCountry === asCountry; });
            var skinRarity = SKIN_RARITY.LEGENDARY;
            var playerSkins = s.playerProgress.skins;
            var hasLegendarySkin = false;
            for (var _i = 0, playerSkins_3 = playerSkins; _i < playerSkins_3.length; _i++) {
                var skin = playerSkins_3[_i];
                var model = skinsMap.checkedGet(skin);
                if (model.rarity == skinRarity)
                    hasLegendarySkin = true;
            }
            return hasLegendarySkin && correctCountry;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100034,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://docs.google.com/forms/d/e/1FAIpQLSdrrhf0es8LVlOGRHGy4NpNApYMZKxrAK2kzTJFs_cl0d1UCA/viewform?usp=dialog",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
                        { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
                        { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
                        { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 48,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "Lynx_Questionnaire_popup_title",
                        "color": "#e6c155"
                    },
                    "subHeader": null,
                    "description": {
                        "alias": "Lynx_Questionnaire_additional_points_1_skin_chest",
                        "color": "#ffffff"
                    },
                    "timer": null,
                    "button": {
                        "alias": "Lynx_Questionnaire_button",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_art_legskin_mk",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_bg_legskin_mk",
                        "color": "#a3baff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#b48cff"
                    },
                    "particles": {
                        "maxColor": "#b48cff",
                        "minColor": "#b48cff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#3d2073"
                            },
                            {
                                "time": 0.98,
                                "color": "#3d2073"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#6233b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#8ca9ff"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_pattern_legskin_mk",
                        "color": "#4775FF2E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
            { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
            { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
            { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
        ],
        condition: function (s) {
            var playerCountry = s.regionalSettings.countryCode;
            var correctCountry = ["VN"].some(function (asCountry) { return playerCountry === asCountry; });
            var skinRarity = SKIN_RARITY.LEGENDARY;
            var playerSkins = s.playerProgress.skins;
            var hasLegendarySkin = false;
            for (var _i = 0, playerSkins_4 = playerSkins; _i < playerSkins_4.length; _i++) {
                var skin = playerSkins_4[_i];
                var model = skinsMap.checkedGet(skin);
                if (model.rarity == skinRarity)
                    hasLegendarySkin = true;
            }
            return hasLegendarySkin && correctCountry;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100035,
                    "priority": 8,
                    "navigation": POPUP_NAVIGATION.URL,
                    "navigationLinkURL": "https://docs.google.com/forms/d/e/1FAIpQLSdZHKTjuJryZaBADrBqoQytnARy5Yeo69x0lMk3FJWkM0lfhw/viewform?usp=dialog",
                    "navigationArg": 0,
                    "activeTime": [
                        { start: new Date("2026-02-12").getTime(), end: new Date("2026-02-15").getTime() },
                        { start: new Date("2026-02-15").getTime(), end: new Date("2026-02-17").getTime() },
                        { start: new Date("2026-02-17").getTime(), end: new Date("2025-02-20").getTime() },
                        { start: new Date("2025-02-20").getTime(), end: new Date("2025-02-23").getTime() },
                    ],
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 48,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "Lynx_Questionnaire_popup_title",
                        "color": "#e6c155"
                    },
                    "subHeader": null,
                    "description": {
                        "alias": "Lynx_Questionnaire_additional_points_1_skin_chest",
                        "color": "#ffffff"
                    },
                    "timer": null,
                    "button": {
                        "alias": "Lynx_Questionnaire_button",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_art_legskin_mk",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_bg_legskin_mk",
                        "color": "#a3baff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#b48cff"
                    },
                    "particles": {
                        "maxColor": "#b48cff",
                        "minColor": "#b48cff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#3d2073"
                            },
                            {
                                "time": 0.98,
                                "color": "#3d2073"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#6233b8"
                            },
                            {
                                "time": 0.99,
                                "color": "#8ca9ff"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/popup_pattern_legskin_mk",
                        "color": "#4775FF2E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: RouletteTimeConstants.roulette_wpn_Butcher_L_Gore.popup._1,
        condition: function (s) {
            var requiredWeapon = heroWeapons.wpn_Butcher_L_Gore.ID;
            var playerWeapons = s.playerProgress.weapons;
            return playerWeapons.indexOf(requiredWeapon) === -1;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100037,
                    "priority": 30,
                    "navigation": POPUP_NAVIGATION.ROULETTE,
                    "navigationArg": 3023,
                    "activeTime": RouletteTimeConstants.roulette_wpn_Butcher_L_Gore.popup._1,
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 50,
                    "rulesDescription": {
                        "alias": "popup_presentation_the_Butcher_leg_wpn_new",
                        "color": "#5EE7FFB8"
                    },
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#ffffff8a"
                    },
                    "header": {
                        "alias": "Leg_wpn_Butcher_presentation_popup_title",
                        "color": "#5ee7ff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_roulette",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/ButcherWeapon/popup_art_wpn_Butcher_L_Gore",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/ButcherWeapon/popup_bg_wpn_Butcher_L_Gore",
                        "color": "#8a272c"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#5EE7FF3F"
                    },
                    "particles": {
                        "maxColor": "#5ee7ff",
                        "minColor": "#5ee7ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#22535c"
                            },
                            {
                                "time": 0.98,
                                "color": "#22535c"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#22535c"
                            },
                            {
                                "time": 0.99,
                                "color": "#45000a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_Butcher_leg_wpn_points1",
                            "color": "#e64049"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_Butcher_leg_wpn_points2",
                            "color": "#e64049"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_Butcher_leg_wpn_points3",
                            "color": "#e64049"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/ButcherWeapon/popup_pattern_legendary_weapon",
                        "color": "#8a272c2E"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: EventTimeConstants.EarthDay_2026.popups._1,
        condition: function (s) {
            return true;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100038,
                    "priority": 5,
                    "navigation": POPUP_NAVIGATION.MARATHONS,
                    "navigationArg": 30021,
                    "activeTime": EventTimeConstants.EarthDay_2026.popups._1,
                    "endDate": EventTimeConstants.EarthDay_2026.marathons.end,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 51,
                    "rulesDescription": {
                        "alias": "popup_rules_day_Earth_2026",
                        "color": "#5eff6eb8"
                    },
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#ffffff8a"
                    },
                    "header": {
                        "alias": "popup_title_day_Earth_2026",
                        "color": "#5eff6e"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75ff83",
                        "glow1Color": "#d7ffce",
                        "glow2Color": "#d7ffce",
                        "effect1Color": "#75ff838a",
                        "effect2Color": "#75ff835c",
                        "effect3Color": "#75ff835c",
                        "effect4Color": "#75ff835c",
                        "corner1Color": "#75ff83",
                        "corner2Color": "#75ff83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/EarthDay/popup_art_earth_day",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/EarthDay/popup_bg_earth_day",
                        "color": "#ffffff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#5eff6e"
                    },
                    "particles": {
                        "maxColor": "#ffd75eb8",
                        "minColor": "#ffd75e5c"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#074520"
                            },
                            {
                                "time": 0.98,
                                "color": "#074520"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 0.54
                            },
                            {
                                "time": 1,
                                "alpha": 0.54
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#225c28"
                            },
                            {
                                "time": 0.99,
                                "color": "#2da139"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "day_Earth_2026_popup_additional_point_1",
                            "color": "#ffc61a"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "day_Earth_2026_popup_additional_point_2",
                            "color": "#ffc61a"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "day_Earth_2026_popup_additional_point_3",
                            "color": "#ffc61a"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/EarthDay/popup_pattern_earth_day",
                        "color": "#1FA12C2E"
                    }
                }
            }
        ])
    },
    {
        activeTimes: [
            {
                start: new Date("2026-07-02").getTime(),
                end: new Date("2026-08-02").getTime(),
            }
        ],
        condition: function (s) {
            var tag = "free_toffee_not_p";
            var hasTag = s.accountTags.indexOf(tag) > -1;
            var hasToffee = useToffeeInsteadOfDefaultPayment({
                settings: s.regionalSettings,
                worldContainer: s.world,
            });
            return hasTag && hasToffee;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100041,
                    "priority": 7,
                    "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
                    "navigationArg": 0,
                    "navigationLinkURL": "sfa://shop?section=Offers&offer=81066",
                    "activeTime": [
                        {
                            start: new Date("2026-07-02").getTime(),
                            end: new Date("2026-08-02").getTime(),
                        }
                    ],
                    "endDate": new Date("2026-08-02").getTime(),
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": null,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "toffee_pay_presentation_popup_title",
                        "color": "#a38cff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_nice",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/Toffee/popup_art_toffee",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/Assets/Layouts/ui_pixel_sprite",
                        "color": "#090d11"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#4791ff"
                    },
                    "particles": {
                        "maxColor": "#4791ff",
                        "minColor": "#4791ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#1a345c"
                            },
                            {
                                "time": 0.98,
                                "color": "#1a345c"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#204173"
                            },
                            {
                                "time": 0.99,
                                "color": "#493f73"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "description": {
                        "alias": "popup_presentation_toffee_pay_5",
                        "color": "#ffffff"
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/pattern_Legion_King_L_Castle",
                        "color": "#2A363A00"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: [
            {
                start: new Date("2026-07-02").getTime(),
                end: new Date("2026-08-02").getTime(),
            }
        ],
        condition: function (s) {
            var tag = "free_toffee_p";
            var hasTag = s.accountTags.indexOf(tag) > -1;
            var hasToffee = useToffeeInsteadOfDefaultPayment({
                settings: s.regionalSettings,
                worldContainer: s.world,
            });
            return hasTag && hasToffee;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100042,
                    "priority": 7,
                    "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
                    "navigationArg": 0,
                    "navigationLinkURL": "sfa://shop?section=Offers&offer=81067",
                    "activeTime": [
                        {
                            start: new Date("2026-07-02").getTime(),
                            end: new Date("2026-08-02").getTime(),
                        }
                    ],
                    "endDate": new Date("2026-08-02").getTime(),
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": null,
                    "rulesDescription": null,
                    "rulesHeader": null,
                    "header": {
                        "alias": "toffee_pay_presentation_popup_title",
                        "color": "#a38cff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_nice",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Advertising/Toffee/popup_art_toffee",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/Assets/Layouts/ui_pixel_sprite",
                        "color": "#090d11"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#4791ff"
                    },
                    "particles": {
                        "maxColor": "#4791ff",
                        "minColor": "#4791ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#1a345c"
                            },
                            {
                                "time": 0.98,
                                "color": "#1a345c"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#204173"
                            },
                            {
                                "time": 0.99,
                                "color": "#493f73"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "description": {
                        "alias": "popup_presentation_toffee_pay_10",
                        "color": "#ffffff"
                    },
                    "descriptionItems": null,
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/pattern_Legion_King_L_Castle",
                        "color": "#2A363A00"
                    }
                },
            },
        ]),
    },
    {
        activeTimes: CommonUtils
            .getStartEndByDays(LegSkinImplementationTimeConstants.LegionKingLCastle.start, [2, 4, 6]),
        condition: function (s) {
            var requiredSkin = skins.Legion_King_L_Castle.ID;
            var playerSkins = s.playerProgress.skins;
            return playerSkins.indexOf(requiredSkin) === -1;
        },
        collapseIdInActiveTime: true,
        popups: CustomPopUpConditions.setActivityPopupsOverMap(activityPopupsMap, [
            {
                data: {
                    "ID": 100043,
                    "priority": 10,
                    "navigation": POPUP_NAVIGATION.ROULETTE,
                    "navigationArg": 5011,
                    "activeTime": CommonUtils
                        .getStartEndByDays(LegSkinImplementationTimeConstants.LegionKingLCastle.start, [2, 4, 6]),
                    "endDate": null,
                },
                visual: {
                    "displayedCurrencies": null,
                    "iconId": 39,
                    "rulesHeader": {
                        "alias": "popup_event_rules_title",
                        "color": "#FFFFFF"
                    },
                    "rulesDescription": {
                        "alias": "popup_presentation_the_Legion_King_leg_skin",
                        "color": "#7f96a1"
                    },
                    "header": {
                        "alias": "leg_skin_Legion_King_presentation_popup_title",
                        "color": "#a3c8ff"
                    },
                    "subHeader": null,
                    "timer": null,
                    "button": {
                        "alias": "button_proceed",
                        "frameColor": "#75FF83",
                        "glow1Color": "#D7FFCE",
                        "glow2Color": "#D7FFCE",
                        "effect1Color": "#75FF83",
                        "effect2Color": "#75FF83",
                        "effect3Color": "#75FF83",
                        "effect4Color": "#75FF83",
                        "corner1Color": "#75FF83",
                        "corner2Color": "#75FF83"
                    },
                    "preview": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/art_event_Legion_King_L_Castle",
                        "color": "#ffffff"
                    },
                    "background": {
                        "sprite": "Sprites/PreviewImages/Events/LegendarySkins/bg_event_legskins",
                        "color": "#a3c8ff"
                    },
                    "backgroundEffect": {
                        "sprite": "",
                        "color": "#a3c8ff98"
                    },
                    "particles": {
                        "maxColor": "#d1f1ff",
                        "minColor": "#d1f1ff"
                    },
                    "gradientLeft": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#2c3d45"
                            },
                            {
                                "time": 0.98,
                                "color": "#2c3d45"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 0
                            }
                        ]
                    },
                    "gradientRight": {
                        "mode": 0,
                        "colorKeys": [
                            {
                                "time": 0,
                                "color": "#71828a"
                            },
                            {
                                "time": 0.99,
                                "color": "#586c8a"
                            }
                        ],
                        "alphaKeys": [
                            {
                                "time": 0,
                                "alpha": 1
                            },
                            {
                                "time": 1,
                                "alpha": 1
                            }
                        ]
                    },
                    "descriptionItems": [
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_legion_king_leg_skin_points1",
                            "color": "#a3c8ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_legion_king_leg_skin_points2",
                            "color": "#a3c8ff"
                        },
                        {
                            "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                            "alias": "popup_presentation_the_legion_king_leg_skin_points3",
                            "color": "#a3c8ff"
                        }
                    ],
                    "pattern": {
                        "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/pattern_Legion_King_L_Castle",
                        "color": "#2A363A73"
                    }
                },
            },
        ]),
    },
], false));
