var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var CustomPopUpConditions = (function () {
    function CustomPopUpConditions() {
    }
    CustomPopUpConditions.add = function (popups) {
        for (var _i = 0, popups_1 = popups; _i < popups_1.length; _i++) {
            var popup = popups_1[_i];
            CustomPopUpConditions.popups.push(popup);
        }
    };
    CustomPopUpConditions.getActive = function (settings) {
        var serverTime = settings.serverTime;
        var _a = settings.regionalSettings, countryCode = _a.countryCode, platform = _a.platform;
        var today = new Date(serverTime);
        var weekDay = today.getUTCDay();
        var result = [];
        for (var _i = 0, _b = CustomPopUpConditions.popups; _i < _b.length; _i++) {
            var dailyPopup = _b[_i];
            var isActive = false;
            if (dailyPopup.activeTimes) {
                for (var _c = 0, _d = dailyPopup.activeTimes; _c < _d.length; _c++) {
                    var activeTime = _d[_c];
                    if (serverTime >= activeTime.start && serverTime <= activeTime.end) {
                        isActive = true;
                        break;
                    }
                }
            }
            if (dailyPopup.daysOfWeek) {
                isActive = dailyPopup.daysOfWeek.indexOf(weekDay) > -1;
            }
            if (dailyPopup.condition(settings) && isActive) {
                for (var _e = 0, _f = dailyPopup.popups; _e < _f.length; _e++) {
                    var popup = _f[_e];
                    var commonSettings = popup.data;
                    var commonId = commonSettings.ID;
                    if (commonSettings.countryCode && commonSettings.countryCode.length > 0) {
                        if (commonSettings.countryCode.indexOf(countryCode) == -1) {
                            break;
                        }
                    }
                    if (commonSettings.platform) {
                        if (commonSettings.platform != platform) {
                            break;
                        }
                    }
                    var idForResult = CustomPopUpConditions
                        .generateConditionPopUpId({
                        popupId: commonId,
                        activeTime: commonSettings.activeTime,
                        serverTime: serverTime,
                        collapseIdInActiveTime: dailyPopup.collapseIdInActiveTime,
                    }).toString();
                    var forView = CustomPopUpConditions.getCommonIdFromPopUpId(+idForResult);
                    if (activityPopupsMap[forView] == undefined) {
                        logMessageOverEnvironment("CustomPopUpConditions error: Activity popup with id ".concat(idForResult, " ")
                            + " [real ".concat(forView, "] not found! See popup ").concat(commonId));
                        continue;
                    }
                    result.push(__assign(__assign({}, commonSettings), { ID: +idForResult }));
                }
            }
        }
        return result;
    };
    CustomPopUpConditions.setActivityPopupsOverMap = function (map, popups) {
        for (var _i = 0, popups_2 = popups; _i < popups_2.length; _i++) {
            var popup = popups_2[_i];
            var id = CustomPopUpConditions.generatePopUpIdByDay(popup.data.ID, 0).toString();
            if (map[id] != undefined) {
                throw new Error("CustomPopUpConditions.setActivityPopupsOverMap: repeated id ".concat(id, ". ")
                    + "See popup with id ".concat(popup.data.ID));
            }
            map[id] = popup;
        }
        return popups;
    };
    CustomPopUpConditions.isIdForPopUp = function (id) {
        return id >= 1000000000 && id <= 1999999999;
    };
    CustomPopUpConditions.getCommonIdFromPopUpId = function (id) {
        if (!CustomPopUpConditions.isIdForPopUp(id)) {
            throw new Error("getCommonIdFromPopUpId: id ".concat(id, " isnt custom conditions popup!"));
        }
        var strId = id.toString();
        return +(strId.substring(0, 6) + "0000");
    };
    CustomPopUpConditions.generatePopUpIdByDay = function (popupId, dayNumber) {
        var result = +(popupId + CommonUtils.getNumberWithStrictLength(dayNumber, 4));
        if (!CustomPopUpConditions.isIdForPopUp(result)) {
            throw new Error("generatePopUpIdByDay: cant create custom popup id for popup ".concat(popupId));
        }
        return result;
    };
    CustomPopUpConditions.generateConditionPopUpId = function (settings) {
        var activeTime = settings.activeTime, popupId = settings.popupId, serverTime = settings.serverTime, collapseIdInActiveTime = settings.collapseIdInActiveTime;
        var start = activeTime && activeTime[0] && activeTime[0].start || serverTime;
        start = new Date(start).setUTCHours(0, 0, 0, 0);
        var day = 0;
        if (collapseIdInActiveTime && activeTime) {
            for (var i = 0; i < activeTime.length; i++) {
                var _a = activeTime[i], start_1 = _a.start, end = _a.end;
                if (serverTime >= start_1 && serverTime < end) {
                    break;
                }
                day++;
            }
        }
        else {
            day = (Math.abs(serverTime - start) / new Time({ Days: 1 }).value) >> 0;
        }
        return CustomPopUpConditions.generatePopUpIdByDay(popupId, day);
    };
    CustomPopUpConditions.popups = [];
    return CustomPopUpConditions;
}());
