var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101;
var inAppSettings = {
    IN_APP_1: {
        ID: 1,
        ProductID: "com.nekki.shadowfightarena.gempack1",
        EGS: {
            EGSProductID: "211239b863e4484487964ef22db422c3",
            CatalogID: "7a544ce2dd1342adad0595a723119ffd",
        },
        CashPrice: 0.99,
        LocalPrice: {
            "default": "$0.99"
        },
        Compensation: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 100, _a) }),
    },
    IN_APP_2: {
        ID: 2,
        ProductID: "com.nekki.shadowfightarena.gempack2",
        EGS: {
            EGSProductID: "9543d686089b48d2b1851fbb4153870f",
            CatalogID: "42d12277b7d1467cae13c64292251a2c",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99"
        },
        Compensation: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 500, _b) }),
    },
    IN_APP_3: {
        ID: 3,
        ProductID: "com.nekki.shadowfightarena.gempack3",
        EGS: {
            EGSProductID: "e4c9c3289a0d46d68cec3939e8ec73fb",
            CatalogID: "6b0fff3651644ee59bed4660f5762f98",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99"
        },
        Compensation: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 1000, _c) }),
    },
    IN_APP_4: {
        ID: 4,
        ProductID: "com.nekki.shadowfightarena.gempack4",
        EGS: {
            EGSProductID: "02fd78281554410eafd6637e047bf265",
            CatalogID: "abda2d50ea5c4fdc8a262fbd14660384",
        },
        CashPrice: 24.99,
        LocalPrice: {
            "default": "$24.99"
        },
        Compensation: new Loot({ Currencies: (_d = {}, _d[CURRENCY.BONUS] = 2500, _d) }),
    },
    IN_APP_5: {
        ID: 5,
        ProductID: "com.nekki.shadowfightarena.gempack5",
        EGS: {
            EGSProductID: "edb4269b72564c8592425c6b390f1b03",
            CatalogID: "6bf6c0df6a9541d587949a5bbe503eb6",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99"
        },
        Compensation: new Loot({ Currencies: (_e = {}, _e[CURRENCY.BONUS] = 5000, _e) }),
    },
    IN_APP_6: {
        ID: 6,
        ProductID: "com.nekki.shadowfightarena.gempack6",
        EGS: {
            EGSProductID: "06f8a24d86a145ed8c02ebdc1e370e5e",
            CatalogID: "c2715b61c6ab47a5ac82f10cc00a1778",
        },
        CashPrice: 99.99,
        LocalPrice: {
            "default": "$99.99"
        },
        Compensation: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 10000, _f) }),
    },
    SUBSCRIBE: {
        ID: 9999,
        ProductID: "com.nekki.shadowfightarena.subscription_1",
        VietnamAndroidID: "com.nekki.shadowfightarena.subscription1",
        EGS: {
            EGSProductID: "99c92d2d969948a38f37177377dded1b",
            CatalogID: "d268dbe99ee04bf2a8b527464cb44a69",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99"
        },
        Type: INAPP_PURCHASE_TYPE.SUBSCRIPTION,
        Compensation: new Loot({ Currencies: (_g = {}, _g[CURRENCY.BONUS] = 1000, _g) }),
    },
    PRICE_0_39: {
        ID: 100391,
        ProductID: "com.nekki.shadowfightarena.offer_0_39",
        EGS: {
            EGSProductID: "79e886ec06474329adfa556808d3f684",
            CatalogID: "33154a9ca0c14421b8d9132b11ae977a",
        },
        CashPrice: 0.39,
        LocalPrice: {
            "default": "$0.39"
        },
        Compensation: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 40, _h) }),
    },
    PRICE_0_49: {
        ID: 100491,
        ProductID: "com.nekki.shadowfightarena.offer_0_49",
        EGS: {
            EGSProductID: "16a7a537217f4de19736eb9371fa8a49",
            CatalogID: "3b2374db84b24175864b687d22d3f428",
        },
        CashPrice: 0.49,
        LocalPrice: {
            "default": "$0.49"
        },
        Compensation: new Loot({ Currencies: (_j = {}, _j[CURRENCY.BONUS] = 50, _j) }),
    },
    PRICE_0_79: {
        ID: 100791,
        ProductID: "com.nekki.shadowfightarena.offer_0_79",
        EGS: {
            EGSProductID: "4073af7669c14b16a3f02af06fedfdab",
            CatalogID: "b0bdb4432d77410eb64f023abffd140b",
        },
        CashPrice: 0.79,
        LocalPrice: {
            "default": "$0.79"
        },
        Compensation: new Loot({ Currencies: (_k = {}, _k[CURRENCY.BONUS] = 80, _k) }),
    },
    PRICE_1: {
        ID: 1011,
        ProductID: "com.nekki.shadowfightarena.offer_1",
        EGS: {
            EGSProductID: "123ffa41689b430caf076d4cb64eae62",
            CatalogID: "5308e2a2f24648b3aff8988cf7bfd594",
        },
        CashPrice: 0.99,
        LocalPrice: {
            "default": "$0.99"
        },
        Compensation: new Loot({ Currencies: (_l = {}, _l[CURRENCY.BONUS] = 100, _l) }),
    },
    PRICE_1_49: {
        ID: 101491,
        ProductID: "com.nekki.shadowfightarena.offer_1_49",
        EGS: {
            EGSProductID: "c784c1f01e8c4d86bff8ff551e4f2e95",
            CatalogID: "dcebb3083b1f475ab0e4174079c28cbb",
        },
        CashPrice: 1.49,
        LocalPrice: {
            "default": "$1.49"
        },
        Compensation: new Loot({ Currencies: (_m = {}, _m[CURRENCY.BONUS] = 150, _m) }),
    },
    PRICE_3: {
        ID: 1031,
        ProductID: "com.nekki.shadowfightarena.offer_3",
        EGS: {
            EGSProductID: "c463f9af05ca4905a458c41a2a2cfcfc",
            CatalogID: "a2856cfaa8a64707b25a984aff34c648",
        },
        CashPrice: 2.99,
        LocalPrice: {
            "default": "$2.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_o = {}, _o[CURRENCY.BONUS] = 300, _o) }),
    },
    PRICE_3_2: {
        ID: 1032,
        ProductID: "com.nekki.shadowfightarena.offer_3_2",
        EGS: {
            EGSProductID: "8965dd41e5234dfcb1e2c441576c9aa1",
            CatalogID: "bdfcfe4f84284c50abbc045c29fc1602",
        },
        CashPrice: 2.99,
        LocalPrice: {
            "default": "$2.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_p = {}, _p[CURRENCY.BONUS] = 300, _p) }),
    },
    PRICE_3_3: {
        ID: 1033,
        ProductID: "com.nekki.shadowfightarena.offer_3_3",
        EGS: {
            EGSProductID: "2ff029e4be5241b696b24d95da6fa655",
            CatalogID: "5cd5f5b6b267442ea8a32022ca5fa5ed",
        },
        CashPrice: 2.99,
        LocalPrice: {
            "default": "$2.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_q = {}, _q[CURRENCY.BONUS] = 300, _q) }),
    },
    PRICE_5_broken: {
        ID: 1051,
        ProductID: "com.nekki.shadowfightarena.offer_5",
        EGS: {
            EGSProductID: "0d248285c4fa48ccbdc7547cbcfdb426",
            CatalogID: "101d0ab4784e4472be3078349fcce94b",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_r = {}, _r[CURRENCY.BONUS] = 500, _r) }),
    },
    PRICE_5: {
        ID: 1052,
        ProductID: "com.nekki.shadowfightarena.offer_5_2",
        EGS: {
            EGSProductID: "b64cc817b3ee4ac2a6152b49b884e45a",
            CatalogID: "ca28e46a59b24e83baa28664d6ae0f90",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_s = {}, _s[CURRENCY.BONUS] = 500, _s) }),
    },
    PRICE_5_3: {
        ID: 1053,
        ProductID: "com.nekki.shadowfightarena.offer_5_3",
        EGS: {
            EGSProductID: "172d3c9f2bda4a688c720fd4161737e1",
            CatalogID: "9e66426c08b244b1af5a7e0cc2107fe1",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_t = {}, _t[CURRENCY.BONUS] = 500, _t) }),
    },
    PRICE_5_4: {
        ID: 1054,
        ProductID: "com.nekki.shadowfightarena.offer_5_4",
        EGS: {
            EGSProductID: "9f3134b40aff4dcdb53723f5bec0f9b7",
            CatalogID: "7eb64d95ec76470d9f95093cf8e9eba0",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_u = {}, _u[CURRENCY.BONUS] = 500, _u) }),
    },
    PRICE_5_5: {
        ID: 1055,
        ProductID: "com.nekki.shadowfightarena.offer_5_5",
        EGS: {
            EGSProductID: "57a516337060454c8dae1fa368e08634",
            CatalogID: "b2344d9a3f144b33add87df2cbe05ccc",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_v = {}, _v[CURRENCY.BONUS] = 500, _v) }),
    },
    PRICE_5_6: {
        ID: 1056,
        ProductID: "com.nekki.shadowfightarena.offer_5_6",
        EGS: {
            EGSProductID: "4a465397679e48f898346ba3bef4a48a",
            CatalogID: "1d14825970c947b496f4d53c24662687",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_w = {}, _w[CURRENCY.BONUS] = 500, _w) }),
    },
    PRICE_5_7: {
        ID: 1057,
        ProductID: "com.nekki.shadowfightarena.offer_5_7",
        EGS: {
            EGSProductID: "a0defa9c24174bb3abb21f57f6397753",
            CatalogID: "445b7b078ab643e192270f1f767cf76c",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_x = {}, _x[CURRENCY.BONUS] = 500, _x) }),
    },
    PRICE_5_8: {
        ID: 1058,
        ProductID: "com.nekki.shadowfightarena.offer_5_8",
        EGS: {
            EGSProductID: "b5f734ebd6854f9c9fef93eb349f8c54",
            CatalogID: "99c803c72a614736837d2b5ebf24ae55",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_y = {}, _y[CURRENCY.BONUS] = 500, _y) }),
    },
    PRICE_5_9: {
        ID: 1059,
        ProductID: "com.nekki.shadowfightarena.offer_5_9",
        EGS: {
            EGSProductID: "e6344d31788142979a0f7a236ba20e90",
            CatalogID: "ae353f9ca2664c27bd3acee98591ebb8",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_z = {}, _z[CURRENCY.BONUS] = 500, _z) }),
    },
    PRICE_5_10: {
        ID: 10510,
        ProductID: "com.nekki.shadowfightarena.offer_5_10",
        EGS: {
            EGSProductID: "b40168b70dc94df699a584170cc8ad15",
            CatalogID: "aad03a4aa98f40ad9af754c1a8ee320c",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.BONUS] = 500, _0) }),
    },
    PRICE_5_11: {
        ID: 10511,
        ProductID: "com.nekki.shadowfightarena.offer_5_11",
        EGS: {
            EGSProductID: "8e9ffb04dceb4a0c8882806c6216437f",
            CatalogID: "5ed389920b754bf19240c0b1ced13f02",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.BONUS] = 500, _1) }),
    },
    PRICE_5_12: {
        ID: 10512,
        ProductID: "com.nekki.shadowfightarena.offer_5_12",
        EGS: {
            EGSProductID: "0c1ef25d184b45f188975b60c0717923",
            CatalogID: "6816a5954b6b4540b122706230e35406",
        },
        CashPrice: 4.99,
        LocalPrice: {
            "default": "$4.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.BONUS] = 500, _2) }),
    },
    PRICE_8: {
        ID: 1081,
        ProductID: "com.nekki.shadowfightarena.offer_8",
        EGS: {
            EGSProductID: "3e14921c84ef4d99ab524e4ce77fd4a2",
            CatalogID: "4425819fd7194f0c8c03a06e79f96f79",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.BONUS] = 800, _3) }),
    },
    PRICE_8_2: {
        ID: 1082,
        ProductID: "com.nekki.shadowfightarena.offer_8_2",
        EGS: {
            EGSProductID: "ba12537547ca446cbd88336c8f6d7045",
            CatalogID: "09a1f0ec78fc47fc817491247acdeb43",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.BONUS] = 800, _4) }),
    },
    PRICE_8_3: {
        ID: 1083,
        ProductID: "com.nekki.shadowfightarena.offer_8_3",
        EGS: {
            EGSProductID: "4957353bbd6240d18ff6953139e04ead",
            CatalogID: "4fa44158a37b4648a9060731fe9d893e",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.BONUS] = 800, _5) }),
    },
    PRICE_8_4: {
        ID: 1084,
        ProductID: "com.nekki.shadowfightarena.offer_8_4",
        EGS: {
            EGSProductID: "76e994eda083400889a5f323f42b20ee",
            CatalogID: "75fa2a1414a442ab96fe533632cd473a",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.BONUS] = 800, _6) }),
    },
    PRICE_8_5: {
        ID: 1085,
        ProductID: "com.nekki.shadowfightarena.offer_8_5",
        EGS: {
            EGSProductID: "5a17c33702da4affb0fca2c3a888bc4c",
            CatalogID: "e6e3fffe477e4e7899769834f3747f5e",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_7 = {}, _7[CURRENCY.BONUS] = 800, _7) }),
    },
    PRICE_8_6: {
        ID: 1086,
        ProductID: "com.nekki.shadowfightarena.offer_8_6",
        EGS: {
            EGSProductID: "d4b597d994d149379129974393ccec86",
            CatalogID: "b04e6dbc9bb44cae92b97efd9b33b995",
        },
        CashPrice: 7.99,
        LocalPrice: {
            "default": "$7.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.BONUS] = 800, _8) }),
    },
    PRICE_10: {
        ID: 1101,
        ProductID: "com.nekki.shadowfightarena.offer_10",
        EGS: {
            EGSProductID: "4a728b7f7df645b3b145b979b3cb5705",
            CatalogID: "a51138dc7a7140158b5146db39d1edf5",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.BONUS] = 1000, _9) }),
    },
    FPRICE_10_2: {
        ID: 1102,
        ProductID: "com.nekki.shadowfightarena.offer_10_2",
        EGS: {
            EGSProductID: "d69aabc7b589439dab1f044b182625e2",
            CatalogID: "6dedecebcf64493382d24b283865d60d",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.BONUS] = 1000, _10) }),
    },
    PRICE_10_3: {
        ID: 1103,
        ProductID: "com.nekki.shadowfightarena.offer_10_3",
        EGS: {
            EGSProductID: "270fc3a7b1474b01b2cbcffa7969092b",
            CatalogID: "2d1b863bd47944199a540db2acae7c76",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_11 = {}, _11[CURRENCY.BONUS] = 1000, _11) }),
    },
    PRICE_10_4: {
        ID: 1104,
        ProductID: "com.nekki.shadowfightarena.offer_10_4",
        EGS: {
            EGSProductID: "292136927c924d679e051e15b6e426ff",
            CatalogID: "87a4d3be2a284ad4becfd80ca9cfd0c9",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_12 = {}, _12[CURRENCY.BONUS] = 1000, _12) }),
    },
    PRICE_10_5: {
        ID: 1105,
        ProductID: "com.nekki.shadowfightarena.offer_10_5",
        EGS: {
            EGSProductID: "a24f45712b644c3191997c2acc857ccd",
            CatalogID: "ddde950b02394aa0a89a5b7b371dea54",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.BONUS] = 1000, _13) }),
    },
    PRICE_10_6: {
        ID: 1106,
        ProductID: "com.nekki.shadowfightarena.offer_10_6",
        EGS: {
            EGSProductID: "b670534b2f1140b1b61dd8249852eefb",
            CatalogID: "641163f5516d4e279ec739fafc6c69a9",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_14 = {}, _14[CURRENCY.BONUS] = 1000, _14) }),
    },
    PRICE_10_7: {
        ID: 1107,
        ProductID: "com.nekki.shadowfightarena.offer_10_7",
        EGS: {
            EGSProductID: "92a5c41d2b974f2d87c02ced8cfeb124",
            CatalogID: "2932d99daa544f0ea4363dc5f2414e2c",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_15 = {}, _15[CURRENCY.BONUS] = 1000, _15) }),
    },
    PRICE_10_8: {
        ID: 1108,
        ProductID: "com.nekki.shadowfightarena.offer_10_8",
        EGS: {
            EGSProductID: "b5f47b504fcc4d5c8937555e859aea07",
            CatalogID: "84c0565270014ca78476e4c1cff431f6",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_16 = {}, _16[CURRENCY.BONUS] = 1000, _16) }),
    },
    PRICE_10_9: {
        ID: 1109,
        ProductID: "com.nekki.shadowfightarena.offer_10_9",
        EGS: {
            EGSProductID: "31504eb51dcb4b40a549912a4c9287f5",
            CatalogID: "cbaa4a3bfb8148d4a4af7ef779af8394",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_17 = {}, _17[CURRENCY.BONUS] = 1000, _17) }),
    },
    PRICE_10_10: {
        ID: 11010,
        ProductID: "com.nekki.shadowfightarena.offer_10_10",
        EGS: {
            EGSProductID: "2f38b38e038b42a5a1f9eef4a21bfbbd",
            CatalogID: "ec5e92826de646f9a31d10eca48d144c",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_18 = {}, _18[CURRENCY.BONUS] = 1000, _18) }),
    },
    PRICE_10_11: {
        ID: 11011,
        ProductID: "com.nekki.shadowfightarena.offer_10_11",
        EGS: {
            EGSProductID: "4b834b4fd1964141b48c50d41d3502dc",
            CatalogID: "8d2dc355b90a4e559eebb6a8f48fc690",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.BONUS] = 1000, _19) }),
    },
    PRICE_10_12: {
        ID: 11012,
        ProductID: "com.nekki.shadowfightarena.offer_10_12",
        EGS: {
            EGSProductID: "2412b675da754511a5806a27ed42282a",
            CatalogID: "4a5d0fd9a96944c59b503ad7a6f458d4",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_20 = {}, _20[CURRENCY.BONUS] = 1000, _20) }),
    },
    PRICE_10_13: {
        ID: 11013,
        ProductID: "com.nekki.shadowfightarena.offer_10_13",
        EGS: {
            EGSProductID: "e55e926e4a674aa5a765bd68a1324dec",
            CatalogID: "c1888206fc594345ad3752349eee3e8a",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_21 = {}, _21[CURRENCY.BONUS] = 1000, _21) }),
    },
    PRICE_10_14: {
        ID: 11014,
        ProductID: "com.nekki.shadowfightarena.offer_10_14",
        EGS: {
            EGSProductID: "473fb23f1e494a59b87522bebbafed56",
            CatalogID: "85df83fd191244c189ae0e56c08e26bc",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_22 = {}, _22[CURRENCY.BONUS] = 1000, _22) }),
    },
    PRICE_10_15: {
        ID: 11015,
        ProductID: "com.nekki.shadowfightarena.offer_10_15",
        EGS: {
            EGSProductID: "085733403e1b4887aa4a0793c160e3c1",
            CatalogID: "023bf0dd7b3f4962aace82c6f1d96a78",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_23 = {}, _23[CURRENCY.BONUS] = 1000, _23) }),
    },
    PRICE_10_16: {
        ID: 11016,
        ProductID: "com.nekki.shadowfightarena.offer_10_16",
        EGS: {
            EGSProductID: "fceb6509722d43cbb0490d662eccf53d",
            CatalogID: "1d5dafd7a2944da08c74cc1969d6fbe6",
        },
        CashPrice: 9.99,
        LocalPrice: {
            "default": "$9.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_24 = {}, _24[CURRENCY.BONUS] = 1000, _24) }),
    },
    PRICE_15: {
        ID: 1151,
        ProductID: "com.nekki.shadowfightarena.offer_15",
        EGS: {
            EGSProductID: "cb822ccdee83465f81f8fe6596bf798f",
            CatalogID: "d1efb822c388407b80fbd1cbd5026a01",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_25 = {}, _25[CURRENCY.BONUS] = 1500, _25) }),
    },
    FPRICE_15_2: {
        ID: 1152,
        ProductID: "com.nekki.shadowfightarena.offer_15_2",
        EGS: {
            EGSProductID: "7dff2e89ccc540f492c1ce10a7475bb0",
            CatalogID: "9ef5b45e461f498e8da9ff939f008aa6",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.BONUS] = 1500, _26) }),
    },
    PRICE_15_3: {
        ID: 1153,
        ProductID: "com.nekki.shadowfightarena.offer_15_3",
        EGS: {
            EGSProductID: "2c0ec38653d8472a8aaf96c198d8b26f",
            CatalogID: "24d8f0beacb944899fd8c25cecb061c9",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_27 = {}, _27[CURRENCY.BONUS] = 1500, _27) }),
    },
    PRICE_15_4: {
        ID: 1154,
        ProductID: "com.nekki.shadowfightarena.offer_15_4",
        EGS: {
            EGSProductID: "c5f9e6e229c34c5095754d0f90bf0839",
            CatalogID: "1cc43c58399e4e2c94c084fea25ac38f",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_28 = {}, _28[CURRENCY.BONUS] = 1500, _28) }),
    },
    PRICE_15_5: {
        ID: 1155,
        ProductID: "com.nekki.shadowfightarena.offer_15_5",
        EGS: {
            EGSProductID: "45fc443253264ac6b3f1b44b1206a535",
            CatalogID: "a65210fb53f943949217322b6dd0fcb9",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.BONUS] = 1500, _29) }),
    },
    PRICE_15_6: {
        ID: 1156,
        ProductID: "com.nekki.shadowfightarena.offer_15_6",
        EGS: {
            EGSProductID: "1d2dadc2a4f14c28829f50d3930a4c0f",
            CatalogID: "71a07e9a9c8643a8a2834caae18832c1",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_30 = {}, _30[CURRENCY.BONUS] = 1500, _30) }),
    },
    PRICE_15_7: {
        ID: 1157,
        ProductID: "com.nekki.shadowfightarena.offer_15_7",
        EGS: {
            EGSProductID: "923a34ce1ec34dd4985707a220276ce8",
            CatalogID: "d5d1e72878754966b41ad6596128c22b",
        },
        CashPrice: 14.99,
        LocalPrice: {
            "default": "$14.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_31 = {}, _31[CURRENCY.BONUS] = 1500, _31) }),
    },
    PRICE_20: {
        ID: 1201,
        ProductID: "com.nekki.shadowfightarena.offer_20",
        EGS: {
            EGSProductID: "665ee666705343099bca6dda0f02a43f",
            CatalogID: "1e019f191f2646dfa8d14ec70ab87595",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.BONUS] = 2000, _32) }),
    },
    PRICE_20_2: {
        ID: 1202,
        ProductID: "com.nekki.shadowfightarena.offer_20_2",
        EGS: {
            EGSProductID: "756ff5c45cf44bfbb752d78359769ea5",
            CatalogID: "a5c4e29d0c6c4e60b3abda5c83bb9c00",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_33 = {}, _33[CURRENCY.BONUS] = 2000, _33) }),
    },
    PRICE_20_3: {
        ID: 1203,
        ProductID: "com.nekki.shadowfightarena.offer_20_3",
        EGS: {
            EGSProductID: "db523e50b0c649bcadaac3430386d71c",
            CatalogID: "b25286ab9b8a4babb5f46fe5410d0c8a",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.BONUS] = 2000, _34) }),
    },
    PRICE_20_4: {
        ID: 1204,
        ProductID: "com.nekki.shadowfightarena.offer_20_4",
        EGS: {
            EGSProductID: "962cc645b0734f12855d3edf61a00d27",
            CatalogID: "87a409f1d58a4928aa87488095a6a87c",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_35 = {}, _35[CURRENCY.BONUS] = 2000, _35) }),
    },
    PRICE_20_5: {
        ID: 1205,
        ProductID: "com.nekki.shadowfightarena.offer_20_5",
        EGS: {
            EGSProductID: "49d7009207a44c27b4f8b8ecff040f79",
            CatalogID: "79f0899864654d8fbd49959397e33094",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_36 = {}, _36[CURRENCY.BONUS] = 2000, _36) }),
    },
    PRICE_20_6: {
        ID: 1206,
        ProductID: "com.nekki.shadowfightarena.offer_20_6",
        EGS: {
            EGSProductID: "0f7d7f71520a464798617f7308e45b4c",
            CatalogID: "6d3fdd3cbed940efac4c3f75bbb23739",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.BONUS] = 2000, _37) }),
    },
    PRICE_20_7: {
        ID: 1207,
        ProductID: "com.nekki.shadowfightarena.offer_20_7",
        EGS: {
            EGSProductID: "65cb0d866ba24b2882d6704df8a346c1",
            CatalogID: "2ed30335181a40b0b278b51e55acf395",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_38 = {}, _38[CURRENCY.BONUS] = 2000, _38) }),
    },
    PRICE_20_8: {
        ID: 1208,
        ProductID: "com.nekki.shadowfightarena.offer_20_8",
        EGS: {
            EGSProductID: "de66dcfa7554411fa8dc7964638945ac",
            CatalogID: "59542a03e0a1418fa003f62e96cdb02f",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_39 = {}, _39[CURRENCY.BONUS] = 2000, _39) }),
    },
    PRICE_20_9: {
        ID: 1209,
        ProductID: "com.nekki.shadowfightarena.offer_20_9",
        EGS: {
            EGSProductID: "c9be0a68f5ee49e2ac191d3dd58586af",
            CatalogID: "96822ede7d3b472b8a3db65496db95d2",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_40 = {}, _40[CURRENCY.BONUS] = 2000, _40) }),
    },
    PRICE_20_10: {
        ID: 12010,
        ProductID: "com.nekki.shadowfightarena.offer_20_10",
        EGS: {
            EGSProductID: "ebe07cd1e1ef4721a602bf23853a3284",
            CatalogID: "dd7d1493ed654f269433e9214f5d3abb",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_41 = {}, _41[CURRENCY.BONUS] = 2000, _41) }),
    },
    PRICE_20_11: {
        ID: 12011,
        ProductID: "com.nekki.shadowfightarena.offer_20_11",
        EGS: {
            EGSProductID: "32751e7328f84387aa092b8cb8b6c890",
            CatalogID: "2bbdd8eca5fb48a9b556ca0e8c0f3281",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_42 = {}, _42[CURRENCY.BONUS] = 2000, _42) }),
    },
    PRICE_20_12: {
        ID: 12012,
        ProductID: "com.nekki.shadowfightarena.offer_20_12",
        EGS: {
            EGSProductID: "1e468af217e446dd8c786389cc30dc46",
            CatalogID: "041587ffa27945a7be4e0e63d3a9fbf0",
        },
        CashPrice: 19.99,
        LocalPrice: {
            "default": "$19.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.BONUS] = 2000, _43) }),
    },
    PRICE_25: {
        ID: 1251,
        ProductID: "com.nekki.shadowfightarena.offer_25",
        EGS: {
            EGSProductID: "1fc0a6b9399548d289f2dacada4c7c2b",
            CatalogID: "39b1e6b7b96747d1a8a72bc2e0b02f35",
        },
        CashPrice: 24.99,
        LocalPrice: {
            "default": "$24.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_44 = {}, _44[CURRENCY.BONUS] = 2500, _44) }),
    },
    PRICE_25_2: {
        ID: 1252,
        ProductID: "com.nekki.shadowfightarena.offer_25_2",
        EGS: {
            EGSProductID: "c317e256e8e14bb394b6c57c6f81c27a",
            CatalogID: "04708298cb914de99a238aa8fe08700c",
        },
        CashPrice: 24.99,
        LocalPrice: {
            "default": "$24.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_45 = {}, _45[CURRENCY.BONUS] = 2500, _45) }),
    },
    PRICE_25_3: {
        ID: 1253,
        ProductID: "com.nekki.shadowfightarena.offer_25_3",
        EGS: {
            EGSProductID: "cf808cb53a3041db80934272d423d5e5",
            CatalogID: "a70c1d72d576481a94582eb644c5bc81",
        },
        CashPrice: 24.99,
        LocalPrice: {
            "default": "$24.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.BONUS] = 2500, _46) }),
    },
    PRICE_30: {
        ID: 1301,
        ProductID: "com.nekki.shadowfightarena.offer_30",
        EGS: {
            EGSProductID: "7f9279a9ae474030bb29816012143a43",
            CatalogID: "cfc73777890a47469335a2e35ac20039",
        },
        CashPrice: 29.99,
        LocalPrice: {
            "default": "$29.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_47 = {}, _47[CURRENCY.BONUS] = 3000, _47) }),
    },
    PRICE_30_2: {
        ID: 1302,
        ProductID: "com.nekki.shadowfightarena.offer_30_2",
        EGS: {
            EGSProductID: "0c13d5face6d4dfd9b81020e4c5dd66d",
            CatalogID: "75a9a81848884fd498cc732cb4da113d",
        },
        CashPrice: 29.99,
        LocalPrice: {
            "default": "$29.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_48 = {}, _48[CURRENCY.BONUS] = 3000, _48) }),
    },
    PRICE_30_3: {
        ID: 1303,
        ProductID: "com.nekki.shadowfightarena.offer_30_3",
        EGS: {
            EGSProductID: "72a3158f6f834d509db54f726f5d39f1",
            CatalogID: "daa5ec00854a4fc2acd9e181eff3ac59",
        },
        CashPrice: 29.99,
        LocalPrice: {
            "default": "$29.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_49 = {}, _49[CURRENCY.BONUS] = 3000, _49) }),
    },
    PRICE_30_4: {
        ID: 1304,
        ProductID: "com.nekki.shadowfightarena.offer_30_4",
        EGS: {
            EGSProductID: "d0a8f3b31fda478489661d283300541e",
            CatalogID: "58db49b06e184ddcaebe2c09a5f13b7d",
        },
        CashPrice: 29.99,
        LocalPrice: {
            "default": "$29.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.BONUS] = 3000, _50) }),
    },
    PRICE_30_5: {
        ID: 1305,
        ProductID: "com.nekki.shadowfightarena.offer_30_5",
        EGS: {
            EGSProductID: "731375b4efa9491cb2bca396d63802c0",
            CatalogID: "ba54e3d9b1544858af1ed5169959cd49",
        },
        CashPrice: 29.99,
        LocalPrice: {
            "default": "$29.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_51 = {}, _51[CURRENCY.BONUS] = 3000, _51) }),
    },
    PRICE_35: {
        ID: 1351,
        ProductID: "com.nekki.shadowfightarena.offer_35",
        EGS: {
            EGSProductID: "b2f48b56bdb44b0a8876d832f05a7ff3",
            CatalogID: "6c465b2844574446ab6efb04a7e84415",
        },
        CashPrice: 34.99,
        LocalPrice: {
            "default": "$34.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_52 = {}, _52[CURRENCY.BONUS] = 3500, _52) }),
    },
    PRICE_40: {
        ID: 1401,
        ProductID: "com.nekki.shadowfightarena.offer_40",
        EGS: {
            EGSProductID: "c81edb33094e40809f5a0a1be71f76bb",
            CatalogID: "0cf1a9a2cb1a432182e6a50626d894d8",
        },
        CashPrice: 39.99,
        LocalPrice: {
            "default": "$39.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_53 = {}, _53[CURRENCY.BONUS] = 4000, _53) }),
    },
    PRICE_44_99: {
        ID: 1044991,
        ProductID: "com.nekki.shadowfightarena.offer_44_99",
        EGS: {
            EGSProductID: "3353a07edea04ac08f721f7975a9241c",
            CatalogID: "67a46481f1be4114a2f9773bb313adac",
        },
        CashPrice: 44.99,
        LocalPrice: {
            "default": "$44.99"
        },
        Compensation: new Loot({ Currencies: (_54 = {}, _54[CURRENCY.BONUS] = 4500, _54) }),
    },
    PRICE_50: {
        ID: 1501,
        ProductID: "com.nekki.shadowfightarena.offer_50",
        EGS: {
            EGSProductID: "0a0bb62e937f4380a7a575a21abad5f9",
            CatalogID: "b29c15c1d5dd42068027dc11ad0d3067",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_55 = {}, _55[CURRENCY.BONUS] = 5000, _55) }),
    },
    PRICE_50_2: {
        ID: 1502,
        ProductID: "com.nekki.shadowfightarena.offer_50_2",
        EGS: {
            EGSProductID: "7049a5e79822447a9356fa790ebc5fb2",
            CatalogID: "60c27f38cd764d3db1ad7f90a750ea25",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_56 = {}, _56[CURRENCY.BONUS] = 5000, _56) }),
    },
    PRICE_50_3: {
        ID: 1503,
        ProductID: "com.nekki.shadowfightarena.offer_50_3",
        EGS: {
            EGSProductID: "4c573d8099944aa8af74a71f161393c3",
            CatalogID: "3b1f7d9bbd0d4974a4dfcde5b241e9af",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_57 = {}, _57[CURRENCY.BONUS] = 5000, _57) }),
    },
    PRICE_50_4: {
        ID: 1504,
        ProductID: "com.nekki.shadowfightarena.offer_50_4",
        EGS: {
            EGSProductID: "58df9a02702e445b8233c02355d7e661",
            CatalogID: "15e41a4af502454c876de0e4afd40269",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_58 = {}, _58[CURRENCY.BONUS] = 5000, _58) }),
    },
    PRICE_50_5: {
        ID: 1505,
        ProductID: "com.nekki.shadowfightarena.offer_50_5",
        EGS: {
            EGSProductID: "aab81b6efa6c4588909091ff0173a7f0",
            CatalogID: "820890cecdd94388aff9e00ab663be79",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_59 = {}, _59[CURRENCY.BONUS] = 5000, _59) }),
    },
    PRICE_50_6: {
        ID: 1506,
        ProductID: "com.nekki.shadowfightarena.offer_50_6",
        EGS: {
            EGSProductID: "2b23c64097d64adcb43dc52d08491583",
            CatalogID: "bfd2ce871c4547bf94714078db893aad",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_60 = {}, _60[CURRENCY.BONUS] = 5000, _60) }),
    },
    PRICE_50_7: {
        ID: 1507,
        ProductID: "com.nekki.shadowfightarena.offer_50_7",
        EGS: {
            EGSProductID: "2044fe59f6174376bc278aff598536fb",
            CatalogID: "1423eb69d38f4e4ca2af1fbef1371fb1",
        },
        CashPrice: 49.99,
        LocalPrice: {
            "default": "$49.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_61 = {}, _61[CURRENCY.BONUS] = 5000, _61) }),
    },
    PRICE_75: {
        ID: 1750,
        ProductID: "com.nekki.shadowfightarena.offer_75",
        EGS: {
            EGSProductID: "5a1463af5a7642d79ff4969f5cf628b7",
            CatalogID: "6b653fbd6d604015aff8c7f622a4d03f",
        },
        CashPrice: 74.99,
        LocalPrice: {
            "default": "$74.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.BONUS] = 7500, _62) }),
    },
    PRICE_100: {
        ID: 2001,
        ProductID: "com.nekki.shadowfightarena.offer_100",
        EGS: {
            EGSProductID: "fce1da35789c49479f3d67681433a6b9",
            CatalogID: "ce33fa11f37041ef84e683fc64aef973",
        },
        CashPrice: 99.99,
        LocalPrice: {
            "default": "$99.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_63 = {}, _63[CURRENCY.BONUS] = 10000, _63) }),
    },
    PRICE_100_2: {
        ID: 2002,
        ProductID: "com.nekki.shadowfightarena.offer_100_2",
        EGS: {
            EGSProductID: "f56bc185c98d4b11a2c0b3b3e1924ba8",
            CatalogID: "f9b8bde62ca540a685281b0f37093065",
        },
        CashPrice: 99.99,
        LocalPrice: {
            "default": "$99.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_64 = {}, _64[CURRENCY.BONUS] = 10000, _64) }),
    },
    PRICE_2: {
        ID: 1021,
        ProductID: "com.nekki.shadowfightarena.offer_2",
        EGS: {
            EGSProductID: "39ac6af217494196ab7d5c6615ca65c6",
            CatalogID: "4465b7dc25d04253a61af96d8369e545",
        },
        CashPrice: 1.99,
        LocalPrice: {
            "default": "$1.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_65 = {}, _65[CURRENCY.BONUS] = 100, _65) }),
    },
    PRICE_4: {
        ID: 1041,
        ProductID: "com.nekki.shadowfightarena.offer_4",
        EGS: {
            EGSProductID: "cd9d6a91dd8340f68061c0c5e7502828",
            CatalogID: "5794c320821a4b9887b8445663185924",
        },
        CashPrice: 3.99,
        LocalPrice: {
            "default": "$3.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_66 = {}, _66[CURRENCY.BONUS] = 200, _66) }),
    },
    PRICE_6: {
        ID: 1061,
        ProductID: "com.nekki.shadowfightarena.offer_6",
        EGS: {
            EGSProductID: "43535ac2b52142b1875276a4678d36e4",
            CatalogID: "a60ae820347645daad25874befd7af49",
        },
        CashPrice: 5.99,
        LocalPrice: {
            "default": "$5.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_67 = {}, _67[CURRENCY.BONUS] = 300, _67) }),
    },
    PRICE_7: {
        ID: 1071,
        ProductID: "com.nekki.shadowfightarena.offer_7",
        EGS: {
            EGSProductID: "d4c8f05ba51d460db54df44a073cc993",
            CatalogID: "4cc71b537c7d4831a05de163e8e5d7b8",
        },
        CashPrice: 6.99,
        LocalPrice: {
            "default": "$6.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_68 = {}, _68[CURRENCY.BONUS] = 350, _68) }),
    },
    PRICE_9: {
        ID: 1091,
        ProductID: "com.nekki.shadowfightarena.offer_9",
        EGS: {
            EGSProductID: "5ac6174d9fe94b10ad128806a72ce205",
            CatalogID: "ed2fa4cbc9744e76a825747fc665ccef",
        },
        CashPrice: 8.99,
        LocalPrice: {
            "default": "$8.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_69 = {}, _69[CURRENCY.BONUS] = 450, _69) }),
    },
    PRICE_12: {
        ID: 10121,
        ProductID: "com.nekki.shadowfightarena.offer_12",
        EGS: {
            EGSProductID: "6013c6ae08b84119963d9e8c2652069a",
            CatalogID: "a91f920a4cf740dc86575146301bc84e",
        },
        CashPrice: 11.99,
        LocalPrice: {
            "default": "$11.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_70 = {}, _70[CURRENCY.BONUS] = 600, _70) }),
    },
    PRICE_13: {
        ID: 10131,
        ProductID: "com.nekki.shadowfightarena.offer_13",
        EGS: {
            EGSProductID: "134dace61f554247ba0253d8bfbdb651",
            CatalogID: "7524720b95424933a0e0c9bc1aed903e",
        },
        CashPrice: 12.99,
        LocalPrice: {
            "default": "$12.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_71 = {}, _71[CURRENCY.BONUS] = 650, _71) }),
    },
    PRICE_14: {
        ID: 10141,
        ProductID: "com.nekki.shadowfightarena.offer_14",
        EGS: {
            EGSProductID: "6882e0bd58c24ee497fb8d8b7ca2bc6f",
            CatalogID: "f68912938933475db0e808bc9fa551ec",
        },
        CashPrice: 13.99,
        LocalPrice: {
            "default": "$13.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_72 = {}, _72[CURRENCY.BONUS] = 700, _72) }),
    },
    PRICE_16: {
        ID: 10161,
        ProductID: "com.nekki.shadowfightarena.offer_16",
        EGS: {
            EGSProductID: "9175f1a96f8d40ee89dfe47bedaf3c5c",
            CatalogID: "0d1b70daf7754ad8b5db98b1ce20042a",
        },
        CashPrice: 15.99,
        LocalPrice: {
            "default": "$15.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_73 = {}, _73[CURRENCY.BONUS] = 800, _73) }),
    },
    PRICE_18: {
        ID: 10181,
        ProductID: "com.nekki.shadowfightarena.offer_18",
        EGS: {
            EGSProductID: "f03f5ed0fcc140198abee696a47a49d9",
            CatalogID: "e3c0b0b0d9a9476e863428d3f9903852",
        },
        CashPrice: 17.99,
        LocalPrice: {
            "default": "$17.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_74 = {}, _74[CURRENCY.BONUS] = 900, _74) }),
    },
    PRICE_21: {
        ID: 10211,
        ProductID: "com.nekki.shadowfightarena.offer_21",
        EGS: {
            EGSProductID: "ef1dffd2a40c42129578823f25c0389d",
            CatalogID: "a2180ef73baa4616babe09fbfcfd6bec",
        },
        CashPrice: 20.99,
        LocalPrice: {
            "default": "$20.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_75 = {}, _75[CURRENCY.BONUS] = 1050, _75) }),
    },
    PRICE_22: {
        ID: 10221,
        ProductID: "com.nekki.shadowfightarena.offer_22",
        EGS: {
            EGSProductID: "f4a3acacf4d744cfaa59ba6a5d299096",
            CatalogID: "a5190070e6c44199890517e5e4ecf361",
        },
        CashPrice: 21.99,
        LocalPrice: {
            "default": "$21.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_76 = {}, _76[CURRENCY.BONUS] = 1100, _76) }),
    },
    PRICE_23: {
        ID: 10231,
        ProductID: "com.nekki.shadowfightarena.offer_23",
        EGS: {
            EGSProductID: "0d73ddf3e5e641348b3aa2b5a13fc46a",
            CatalogID: "5336335eeaf848ab80af4c9d36c6f06a",
        },
        CashPrice: 22.99,
        LocalPrice: {
            "default": "$22.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_77 = {}, _77[CURRENCY.BONUS] = 1150, _77) }),
    },
    PRICE_24: {
        ID: 10241,
        ProductID: "com.nekki.shadowfightarena.offer_24",
        EGS: {
            EGSProductID: "8a3b06943b7e46ad93a022807d308732",
            CatalogID: "6eb3cc17fc9e4dedb1d1164a0c422ea9",
        },
        CashPrice: 23.99,
        LocalPrice: {
            "default": "$23.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_78 = {}, _78[CURRENCY.BONUS] = 1200, _78) }),
    },
    PRICE_27: {
        ID: 10271,
        ProductID: "com.nekki.shadowfightarena.offer_27",
        EGS: {
            EGSProductID: "a3c4339474c24c958aee542fb8b9c2b9",
            CatalogID: "c974547406e142ef95fe478b0ae8d32d",
        },
        CashPrice: 26.99,
        LocalPrice: {
            "default": "$26.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_79 = {}, _79[CURRENCY.BONUS] = 1350, _79) }),
    },
    PRICE_28: {
        ID: 10281,
        ProductID: "com.nekki.shadowfightarena.offer_28",
        EGS: {
            EGSProductID: "ff5100671a1d4445bd1b002d36d44518",
            CatalogID: "c2c8ca35ee274bd885d954fa6b37fe59",
        },
        CashPrice: 27.99,
        LocalPrice: {
            "default": "$27.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_80 = {}, _80[CURRENCY.BONUS] = 1400, _80) }),
    },
    PRICE_32: {
        ID: 10321,
        ProductID: "com.nekki.shadowfightarena.offer_32",
        EGS: {
            EGSProductID: "13057375388443029adaa480dca5e492",
            CatalogID: "f4276f8c031d4de596dbfc696907548f",
        },
        CashPrice: 31.99,
        LocalPrice: {
            "default": "$31.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_81 = {}, _81[CURRENCY.BONUS] = 1600, _81) }),
    },
    PRICE_36: {
        ID: 10361,
        ProductID: "com.nekki.shadowfightarena.offer_36",
        EGS: {
            EGSProductID: "95d561f42cec4bdb8aa4582e03d53d85",
            CatalogID: "a6f157a5bcac44d881e0dbbd32435e50",
        },
        CashPrice: 35.99,
        LocalPrice: {
            "default": "$35.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_82 = {}, _82[CURRENCY.BONUS] = 1800, _82) }),
    },
    PRICE_38: {
        ID: 10381,
        ProductID: "com.nekki.shadowfightarena.offer_38",
        EGS: {
            EGSProductID: "0a3ac37ce1eb46d492b51aeede9640a0",
            CatalogID: "86c60df652b54ee58a199e2685adf829",
        },
        CashPrice: 37.99,
        LocalPrice: {
            "default": "$37.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_83 = {}, _83[CURRENCY.BONUS] = 1900, _83) }),
    },
    PRICE_42: {
        ID: 10421,
        ProductID: "com.nekki.shadowfightarena.offer_42",
        EGS: {
            EGSProductID: "381c5f84585d48afa5775e6c22426941",
            CatalogID: "6a81c2a66d90435587c8e59105eb0d81",
        },
        CashPrice: 41.99,
        LocalPrice: {
            "default": "$41.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_84 = {}, _84[CURRENCY.BONUS] = 2100, _84) }),
    },
    PRICE_45: {
        ID: 10451,
        ProductID: "com.nekki.shadowfightarena.offer_45",
        EGS: {
            EGSProductID: "0d925fa386c84820b385d43bf8f28ef7",
            CatalogID: "aac4e3c4f93b47e39d0b17a54ae6f328",
        },
        CashPrice: 44.99,
        LocalPrice: {
            "default": "$44.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_85 = {}, _85[CURRENCY.BONUS] = 2250, _85) }),
    },
    PRICE_48: {
        ID: 10481,
        ProductID: "com.nekki.shadowfightarena.offer_48",
        EGS: {
            EGSProductID: "455a805edb0246769a51e013cd384c60",
            CatalogID: "49a96de8ed9949629a4cb14f65bb3bf7",
        },
        CashPrice: 47.99,
        LocalPrice: {
            "default": "$47.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_86 = {}, _86[CURRENCY.BONUS] = 2400, _86) }),
    },
    PRICE_55: {
        ID: 10551,
        ProductID: "com.nekki.shadowfightarena.offer_55",
        EGS: {
            EGSProductID: "348985961fdc42cca21b9cf2d6390f2a",
            CatalogID: "08be41b04563497bb33fb2929c5ac653",
        },
        CashPrice: 54.99,
        LocalPrice: {
            "default": "$54.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_87 = {}, _87[CURRENCY.BONUS] = 2750, _87) }),
    },
    PRICE_60_2: {
        ID: 10602,
        ProductID: "com.nekki.shadowfightarena.offer_60_2",
        EGS: {
            EGSProductID: "28c54fe8aa844c68b4086d219047f7e5",
            CatalogID: "5447bd6625de4cb8b2c06050dbcd290c",
        },
        CashPrice: 59.99,
        LocalPrice: {
            "default": "$59.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_88 = {}, _88[CURRENCY.BONUS] = 3000, _88) }),
    },
    PRICE_70: {
        ID: 10701,
        ProductID: "com.nekki.shadowfightarena.offer_70",
        EGS: {
            EGSProductID: "d3d3f4b4dbf84c22b3f855b873ead690",
            CatalogID: "64b78f8c387e4c0b892e12bd064ffc50",
        },
        CashPrice: 69.99,
        LocalPrice: {
            "default": "$69.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_89 = {}, _89[CURRENCY.BONUS] = 3500, _89) }),
    },
    PRICE_80: {
        ID: 10801,
        ProductID: "com.nekki.shadowfightarena.offer_80",
        EGS: {
            EGSProductID: "fc6f3d6f3d0148a1b0e615ad5f6f3986",
            CatalogID: "7bbe8466f8584b7880f0d9543f452417",
        },
        CashPrice: 79.99,
        LocalPrice: {
            "default": "$79.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_90 = {}, _90[CURRENCY.BONUS] = 4000, _90) }),
    },
    PRICE_90: {
        ID: 10901,
        ProductID: "com.nekki.shadowfightarena.offer_90",
        EGS: {
            EGSProductID: "14ba3b08ea314984a9fd9485985530fe",
            CatalogID: "a0c980e2213747cbb9e8d77b3959debd",
        },
        CashPrice: 89.99,
        LocalPrice: {
            "default": "$89.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_91 = {}, _91[CURRENCY.BONUS] = 4500, _91) }),
    },
    PRICE_120: {
        ID: 101201,
        ProductID: "com.nekki.shadowfightarena.offer_120",
        EGS: {
            EGSProductID: "7080ad27e1c34efeac451c1374cf5fce",
            CatalogID: "80419062c3944d769c82911b7ca2132b",
        },
        CashPrice: 119.99,
        LocalPrice: {
            "default": "$119.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_92 = {}, _92[CURRENCY.BONUS] = 6000, _92) }),
    },
    FPRICE_2_2: {
        ID: 1022,
        ProductID: "com.nekki.shadowfightarena.offer_2_2",
        EGS: {
            EGSProductID: "98bacf9d27ed4d14b296f9e96ee1ceea",
            CatalogID: "4125588d0b1b40f299889e0cdd9931ff",
        },
        CashPrice: 1.99,
        LocalPrice: {
            "default": "$1.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_93 = {}, _93[CURRENCY.BONUS] = 100, _93) }),
    },
    FPRICE_3_4: {
        ID: 1034,
        ProductID: "com.nekki.shadowfightarena.offer_3_4",
        EGS: {
            EGSProductID: "e138eb32938c4d8b91954aeef3819fc5",
            CatalogID: "ecfff09969c146ac8ed484a9ecba1473",
        },
        CashPrice: 2.99,
        LocalPrice: {
            "default": "$2.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_94 = {}, _94[CURRENCY.BONUS] = 150, _94) }),
    },
    FPRICE_4_2: {
        ID: 1042,
        ProductID: "com.nekki.shadowfightarena.offer_4_2",
        EGS: {
            EGSProductID: "d0cf41a9315f492db21a7fadf02f6b6d",
            CatalogID: "c9aa3e0739534e4e857610a059bf800f",
        },
        CashPrice: 3.99,
        LocalPrice: {
            "default": "$3.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_95 = {}, _95[CURRENCY.BONUS] = 200, _95) }),
    },
    FPRICE_6_2: {
        ID: 1062,
        ProductID: "com.nekki.shadowfightarena.offer_6_2",
        EGS: {
            EGSProductID: "fb217e19fc88480c84d96a4dcd6c4772",
            CatalogID: "911ad56b6a7a4f65997df9c98c60307b",
        },
        CashPrice: 5.99,
        LocalPrice: {
            "default": "$5.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_96 = {}, _96[CURRENCY.BONUS] = 300, _96) }),
    },
    FPRICE_7_2: {
        ID: 1072,
        ProductID: "com.nekki.shadowfightarena.offer_7_2",
        EGS: {
            EGSProductID: "2fcd194f0ca54721a5c06b8a74a1a75b",
            CatalogID: "cde6db7d63ab48fd80f4bc4b745477a8",
        },
        CashPrice: 6.99,
        LocalPrice: {
            "default": "$6.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_97 = {}, _97[CURRENCY.BONUS] = 350, _97) }),
    },
    FPRICE_9_2: {
        ID: 1092,
        ProductID: "com.nekki.shadowfightarena.offer_9_2",
        EGS: {
            EGSProductID: "d6658e34358f4d44a8eb8f28e65d7a89",
            CatalogID: "8d32366859e04677823f0b463db19691",
        },
        CashPrice: 8.99,
        LocalPrice: {
            "default": "$8.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_98 = {}, _98[CURRENCY.BONUS] = 450, _98) }),
    },
    FPRICE_12_2: {
        ID: 10122,
        ProductID: "com.nekki.shadowfightarena.offer_12_2",
        EGS: {
            EGSProductID: "5078c96e499a438c87f7ac7c9c4596a4",
            CatalogID: "7755b412c26b4378a18f59673fe8dda2",
        },
        CashPrice: 11.99,
        LocalPrice: {
            "default": "$11.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_99 = {}, _99[CURRENCY.BONUS] = 600, _99) }),
    },
    FPRICE_14_2: {
        ID: 10142,
        ProductID: "com.nekki.shadowfightarena.offer_14_2",
        EGS: {
            EGSProductID: "92851cb6aef74a7c8ab1363de1ebad28",
            CatalogID: "3cca19e2abc14ab1af0d815fe6f1b646",
        },
        CashPrice: 13.99,
        LocalPrice: {
            "default": "$13.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_100 = {}, _100[CURRENCY.BONUS] = 700, _100) }),
    },
    FPRICE_18_2: {
        ID: 10182,
        ProductID: "com.nekki.shadowfightarena.offer_18_2",
        EGS: {
            EGSProductID: "e92aba4b9e2240bbaffcd1794babdb3e",
            CatalogID: "ebc2960a07194861b1a9cfb07c4339c8",
        },
        CashPrice: 17.99,
        LocalPrice: {
            "default": "$17.99",
            "CONTENT": "26 грн."
        },
        Compensation: new Loot({ Currencies: (_101 = {}, _101[CURRENCY.BONUS] = 900, _101) }),
    },
};
var inApps = createIDMap(inAppSettings, "inApps");
var inAppsByProductsMap = Object.keys(inAppSettings)
    .reduce(function (map, name) {
    map[inAppSettings[name].ProductID] = inAppSettings[name];
    return map;
}, {});
