var regionalProductSettings = { cohorts: {}, groups: {} };
