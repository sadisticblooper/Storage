var regionalProductsConditionArray = [
    {
        name: "low-cost-corrected-v1",
        playerRegistrationCondition: { more_or_equal: new Date("2022-12-23").getTime() },
        cohorts: regionalProductSettings.cohorts.lowCost_v1,
        groups: regionalProductSettings.groups.lowCost_v1,
    },
    {
        name: "low-cost",
        playerRegistrationCondition: { more_or_equal: new Date("2022-06-23T18:00:00Z").getTime() },
        cohorts: regionalProductSettings.cohorts.lowCost,
        groups: regionalProductSettings.groups.lowCost,
    },
    {
        name: "default",
        cohorts: regionalProductSettings.cohorts.default,
        groups: regionalProductSettings.groups.default,
    },
];
