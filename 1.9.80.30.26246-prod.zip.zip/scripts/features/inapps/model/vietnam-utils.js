var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
var InAppVietnamUtils = (function () {
    function InAppVietnamUtils() {
    }
    InAppVietnamUtils.getAllRegionalPackagesForVietnam = function (settings) {
        var vietnamRate = 24545;
        var currencyShopTypes = [SHOP_TYPE.RUBIES];
        var result = [];
        for (var _i = 0, currencyShopTypes_1 = currencyShopTypes; _i < currencyShopTypes_1.length; _i++) {
            var shopType = currencyShopTypes_1[_i];
            var offers_2 = generateShopOffersForPlayer(__assign(__assign({}, settings), { shopType: shopType }));
            for (var _a = 0, offers_1 = offers_2; _a < offers_1.length; _a++) {
                var offer = offers_1[_a];
                var inAppSettings_1 = inAppsByProductsMap[offer.InApp];
                if (!inAppSettings_1) {
                    continue;
                }
                var items = [];
                for (var cur in offer.loot.Currencies) {
                    var amount = offer.loot.getCurrencyByType(cur);
                    if (amount > 0) {
                        items.push({
                            name: InAppVietnamUtils.getCurrencyName(+cur) + " ".concat(amount),
                            number: amount,
                            itemIcon: "",
                            qualityIcon: "",
                        });
                    }
                }
                if (items.length > 0) {
                    var giftName = "Shop offer ".concat(offer.ID);
                    for (var offerName in ShopSlots) {
                        if (ShopSlots[offerName].ID == offer.ID) {
                            giftName = InAppVietnamUtils.getPackName(offerName);
                            break;
                        }
                    }
                    var amountUSD = inAppSettings_1.CashPrice;
                    var vietnamPrice = CommonUtils.roundMathToSignificantDigits(amountUSD * vietnamRate, 10, 1000, Math.floor);
                    result.push({
                        id: offer.ID,
                        giftName: giftName,
                        amount: vietnamPrice,
                        amountUSD: amountUSD,
                        item: items,
                        expireTime: null,
                        productID: inAppSettings_1.ProductID,
                        limitNumber: null,
                    });
                }
            }
        }
        return result;
    };
    InAppVietnamUtils.getPackName = function (packName) {
        return InAppVietnamUtils.translate.packs[packName] || packName;
    };
    InAppVietnamUtils.getCurrencyName = function (currency) {
        return InAppVietnamUtils.translate.loot.currency[currency] || CURRENCY[currency];
    };
    InAppVietnamUtils.translate = {
        packs: {
            RUBIES_SLOT_1: "VỐC NGỌC",
            RUBIES_SLOT_2: "CHỒNG NGỌC",
            RUBIES_SLOT_3: "TÚI NGỌC",
            RUBIES_SLOT_4: "HỘP NGỌC",
            RUBIES_SLOT_5: "RƯƠNG NGỌC",
            RUBIES_SLOT_6: "NÚI NGỌC",
        },
        loot: {
            currency: (_a = {},
                _a[CURRENCY.BONUS] = "NGỌC",
                _a),
        }
    };
    return InAppVietnamUtils;
}());
