var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var InAPPUtils = (function () {
    function InAPPUtils() {
    }
    InAPPUtils.createOfferPurchaseResult = function (settings) {
        var chestPositions = PseudorandomPositionGetter.getFromRaw(settings.chestQueuePositions);
        var result = {
            offerId: settings.offerId,
            chestQueuePositions: chestPositions,
            unlockBattlePassPremiumSeason: false,
            freeOfAdsAfterPurchaseTimeMillis: 0,
            unlockRewardCollectingForMarathons: [],
        };
        var shopOfferSettingsParameters = shopSlotsMap.get(settings.offerId);
        var promoOffer = offersMap.get(settings.offerId);
        var commonOfferContainer;
        if (!shopOfferSettingsParameters && !promoOffer) {
            throw new Error("createInAppPurchaseResult: There in no such offer/shopSlot with id ".concat(settings.offerId));
        }
        if (promoOffer != null) {
            var seed = settings.seed || 0;
            if (settings.dailyShop == undefined) {
                throw new Error("There is no daily shop in settings: ".concat(JSON.stringify(settings)));
            }
            var offerSettings = {
                offerId: settings.offerId,
                playerProgress: settings.playerProgress,
                dailyShop: { dailyOffers: settings.dailyShop },
                regionalSettings: null,
                seed: seed,
                startTimeOfCurrentDayMS: settings.startTimeOfCurrentDayMS,
            };
            var offer = generatePromoOffer(offerSettings).offer;
            commonOfferContainer = offer;
            if (offer._loot && !offer._loot.isEmpty()) {
                result.loot = offer._loot;
            }
            if (offer._chests && offer._chests.length > 0) {
                result.chestsLoot = [];
                var localSeed = seed;
                var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
                if (result.loot) {
                    HeroUtils.combineLoot(playerProgress, result.loot);
                }
                for (var _i = 0, _a = offer._chests; _i < _a.length; _i++) {
                    var chest = _a[_i];
                    var chestParams = {
                        ChestID: chest.ID,
                        PlayerProgress: playerProgress,
                        Seed: localSeed,
                        ChestQueuePositions: chestPositions,
                        ChestArena: playerProgress.playerArenaId,
                        StartTimeOfCurrentDayMS: settings.startTimeOfCurrentDayMS,
                    };
                    var chestResult = generateLootFromChest(chestParams);
                    chestPositions = chestResult.ChestQueuePositions;
                    localSeed = chestResult.NewSeed;
                    if (chestResult.Loot && !chestResult.Loot.isEmpty()) {
                        result.chestsLoot.push({
                            loot: chestResult.Loot,
                            chestId: chest.ID
                        });
                        HeroUtils.combineLoot(playerProgress, chestResult.Loot);
                    }
                }
            }
        }
        else if (shopOfferSettingsParameters != null) {
            var params = shopOfferSettingsParameters;
            var shopOfferSettings = new ShopOfferSettings(params);
            var offer = new ShopOffer();
            var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
            var playerSettings = {
                playerProgress: playerProgress,
                shopType: SHOP_TYPE.RUBIES,
                regionalSettings: null,
                seed: 1,
                startTimeOfCurrentDayMS: settings.startTimeOfCurrentDayMS,
            };
            offer.generate(playerSettings, shopOfferSettings);
            commonOfferContainer = offer;
            if (offer.isEmpty()) {
                throw new Error("createInAppPurchaseResult: offer has empty loot and chest. ID: ".concat(settings.offerId, ". \n                    \rOfferParameters: ") + JSON.stringify(params));
            }
            if (offer.loot && !offer.loot.isEmpty()) {
                result.loot = offer.loot;
            }
            if (offer._chestID) {
                var chestParams = {
                    ChestID: offer._chestID,
                    PlayerProgress: playerProgress,
                    ChestQueuePositions: chestPositions,
                    ChestArena: playerProgress.playerArenaId,
                    Seed: 1,
                    StartTimeOfCurrentDayMS: settings.startTimeOfCurrentDayMS,
                };
                var lootFromChest = generateLootFromChest(chestParams);
                chestPositions = lootFromChest.ChestQueuePositions;
                result.chestsLoot = [{ chestId: offer._chestID, loot: lootFromChest.Loot }];
            }
        }
        var additionalSettings = commonOfferContainer.additionalSettings;
        result.unlockBattlePassPremiumSeason = additionalSettings.unlockBattlePassPremiumSeason;
        result.freeOfAdsAfterPurchaseTimeMillis = additionalSettings.freeOfAdsAfterPurchaseTimeMillis;
        result.unlockRewardCollectingForMarathons = additionalSettings.unlockRewardCollectingForMarathons;
        if (additionalSettings.offerPurchaseMarathonProgressMap) {
            result.marathonProgressMap = additionalSettings.offerPurchaseMarathonProgressMap;
        }
        result.doPaidRollForRoulette = additionalSettings.doPaidRollForRoulette;
        result.chestQueuePositions = chestPositions;
        return result;
    };
    InAPPUtils.getOfferCompensation = function (settings) {
        var _a;
        var result = new Loot({ Currencies: (_a = {},
                _a[CURRENCY.BONUS] = 50,
                _a) });
        for (var _i = 0, _b = inApps.getKeys(); _i < _b.length; _i++) {
            var id = _b[_i];
            var inAppSettings_1 = inApps.checkedGet(id);
            if (inAppSettings_1.ProductID == settings.ProductID) {
                return inAppSettings_1.Compensation;
            }
        }
        return result;
    };
    InAPPUtils.getRegionalInApp = function (settings) {
        var productID = settings.productID, regionalSettings = settings.regionalSettings;
        var countryCode = regionalSettings.countryCode, platform = regionalSettings.platform, createdPlayerTime = regionalSettings.createdPlayerTime, companyName = regionalSettings.companyName;
        var result = null;
        var conditionSettings = InAPPUtils.getRegionalSettingsByRegDate(createdPlayerTime);
        var distributionsMapByCohortId = {};
        for (var cohortName in conditionSettings.cohorts) {
            distributionsMapByCohortId[conditionSettings.cohorts[cohortName].ID]
                = conditionSettings.cohorts[cohortName].distribution;
        }
        for (var _i = 0, _a = inApps.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var inAppSettings_2 = inApps.get(id);
            if (inAppSettings_2.ProductID == productID) {
                result = inAppSettings_2;
                for (var groupName in conditionSettings.groups) {
                    var group = conditionSettings.groups[groupName];
                    if (group.inAppID == id) {
                        var cohortsByCompany = [];
                        var cohortsByOtherCohortSettings = [];
                        for (var cohortId_1 in group.conformity) {
                            var distribution = distributionsMapByCohortId[+cohortId_1];
                            if (distribution.companyNames.length > 0
                                && distribution.companyNames.indexOf(companyName) > -1) {
                                cohortsByCompany.push(+cohortId_1);
                            }
                            if (distribution.countries.indexOf(countryCode) > -1
                                && distribution.platforms.indexOf(platform) > -1) {
                                cohortsByOtherCohortSettings.push(+cohortId_1);
                            }
                        }
                        var intersection = ArrayUtils.getArraysIntersection(cohortsByCompany, cohortsByOtherCohortSettings);
                        var cohortId = intersection[0] || cohortsByCompany[0] || cohortsByOtherCohortSettings[0];
                        if (cohortId) {
                            return inApps.checkedGet(group.conformity[cohortId]);
                        }
                        break;
                    }
                }
                break;
            }
        }
        return result;
    };
    InAPPUtils.isRegionalProductCorrect = function (settings) {
        var offerID = settings.offerID, productID = settings.productID, regionalSettings = settings.regionalSettings;
        var platform = regionalSettings.platform;
        var shopOfferSettingsParameters = shopSlotsMap.get(offerID);
        var promoOffer = offersMap.get(offerID);
        var originalInApp = promoOffer && promoOffer.InApp
            || shopOfferSettingsParameters && shopOfferSettingsParameters.InApp;
        var inAppForPlatform = InAPPUtils.getProductForPlatform(platform, originalInApp);
        var disableRegionalPrices = false;
        if (promoOffer && promoOffer._disableRegionalPrices) {
            disableRegionalPrices = true;
        }
        else if (shopOfferSettingsParameters && shopOfferSettingsParameters.DisableRegionalPrices) {
            disableRegionalPrices = true;
        }
        if (!originalInApp) {
            return false;
        }
        if (disableRegionalPrices) {
            return productID == inAppForPlatform;
        }
        var regionalInAppSettings = InAPPUtils.getRegionalInApp({
            productID: originalInApp,
            regionalSettings: regionalSettings,
        });
        if (!regionalInAppSettings) {
            return false;
        }
        var regionalInAppForPlatform = InAPPUtils.getProductForPlatform(platform, regionalInAppSettings.ProductID);
        return regionalInAppForPlatform == productID;
    };
    InAPPUtils.checkCohorts = function () {
        for (var _i = 0, regionalProductsConditionArray_1 = regionalProductsConditionArray; _i < regionalProductsConditionArray_1.length; _i++) {
            var conditionSettings = regionalProductsConditionArray_1[_i];
            var cohortsMap = conditionSettings.cohorts;
            var groupsMap = conditionSettings.groups;
            var cohortNamesById = {};
            var inAppsArray = [];
            for (var cohortName in cohortsMap) {
                var cohort = cohortsMap[cohortName];
                cohortNamesById[cohort.ID] = cohortName;
                if (cohort.distribution.countries.length == 0 || cohort.distribution.platforms.length == 0) {
                    throw new Error("Check ".concat(conditionSettings.name, ".")
                        + "Cohort ".concat(cohortName, " have not countries or platforms!"));
                }
            }
            for (var settingsName in groupsMap) {
                var settings = groupsMap[settingsName];
                if (inAppsArray.indexOf(settings.inAppID) > -1) {
                    throw new Error("Repeated iaApp id ".concat(settings.inAppID, " for '").concat(settingsName, "' \n                            \rin '").concat(conditionSettings.name, "'"));
                }
                inAppsArray.push(settings.inAppID);
                for (var cohortID in cohortNamesById) {
                    if (settings.conformity[cohortID] == undefined) {
                        throw new Error("No conformity for '".concat(cohortNamesById[cohortID], "' \n                            \rin regionalInAppProductSettings '").concat(settingsName, "'"));
                    }
                }
            }
        }
    };
    InAPPUtils.getRegionalSettingsByRegDate = function (regDate) {
        for (var _i = 0, regionalProductsConditionArray_2 = regionalProductsConditionArray; _i < regionalProductsConditionArray_2.length; _i++) {
            var conditionSettings = regionalProductsConditionArray_2[_i];
            if (!conditionSettings.playerRegistrationCondition
                || OfferChecker.checkConditionOperand(regDate, conditionSettings.playerRegistrationCondition)) {
                return conditionSettings;
            }
        }
        throw new Error("getRegionalSettingsByRegDate: settings not found");
    };
    InAPPUtils.getUmoneyPrice = function (price) {
        var rate = 90;
        return {
            value: Math.floor(price * rate),
            code: "RUB",
        };
    };
    InAPPUtils.getUmoneyPriceForInApp = function (inAppId) {
        var inAppSettings = inApps.checkedGet(inAppId);
        return InAPPUtils.getUmoneyPrice(inAppSettings.CashPrice);
    };
    InAPPUtils.getUmoneyPriceStringForInApp = function (inAppId) {
        var inAppSettings = inApps.get(inAppId);
        if (!inAppSettings) {
            return "";
        }
        var rublesPrice = InAPPUtils.getUmoneyPrice(inAppSettings.CashPrice);
        return "".concat(rublesPrice.value, ",00 \u20BD");
    };
    InAPPUtils.isSubscriptionAvailableForPlayer = function (settings) {
        var platform = settings && settings.platform;
        var isCareGameBuild = CareGameState.getIsCareGameBuild() || platform == PLATFORM.CARE_GAME;
        var isEGS = [PLATFORM.ANDROID_EGS, PLATFORM.IOS_EGS].indexOf(platform) > -1;
        var isPCBuild = SteamPlatformUtils.isPCBuild(platform);
        return !(isCareGameBuild || isEGS || isPCBuild);
    };
    InAPPUtils.getInAppSettings = function (settings) {
        var platform = settings.platform;
        var isEGS = InAPPUtils.isEGSPlatform(platform);
        var isAndroidVietnam = platform == PLATFORM.ANDROID_VIETNAM;
        var result = {};
        for (var name_1 in inAppSettings) {
            var settings_1 = inAppSettings[name_1];
            var subscriptionInApp = settings_1.Type == INAPP_PURCHASE_TYPE.SUBSCRIPTION;
            var productId = settings_1.ProductID;
            if (isAndroidVietnam && subscriptionInApp && settings_1.VietnamAndroidID) {
                productId = settings_1.VietnamAndroidID;
            }
            if (isEGS) {
                productId = settings_1.EGS.EGSProductID;
            }
            result[name_1] = __assign(__assign({}, settings_1), { ProductID: productId });
        }
        return result;
    };
    InAPPUtils.isEGSPlatform = function (platform) {
        return [PLATFORM.IOS_EGS, PLATFORM.ANDROID_EGS].indexOf(platform) > -1;
    };
    InAPPUtils.getProductForPlatform = function (platform, product) {
        var inApp = inAppsByProductsMap[product];
        var isEGS = InAPPUtils.isEGSPlatform(platform);
        return inApp ? (isEGS ? inApp.EGS.EGSProductID : inApp.ProductID) : null;
    };
    InAPPUtils.getSteamOfferInfo = function (settings) {
        var offerId = settings.offerId, countryCode = settings.countryCode, productId = settings.productId;
        var shopOfferSettingsParameters = shopSlotsMap.get(offerId);
        var promoOffer = offersMap.get(offerId);
        if (!shopOfferSettingsParameters && !promoOffer) {
            throw new Error("createInAppPurchaseResult: There in no such offer/shopSlot with id ".concat(offerId));
        }
        var steamPrice = InAPPUtils.getSteamPriceByProductAndRegion(productId, countryCode);
        var description = promoOffer != null
            ? promoOffer._offerNameAlias
            : shopOfferSettingsParameters.Alias;
        return {
            amount: steamPrice.amount,
            currency: steamPrice.currency,
            description: description,
        };
    };
    InAPPUtils.getSteamOfferDefaultPrice = function (settings) {
        var productId = settings.productId;
        var inapp = inAppsByProductsMap[productId];
        if (!inapp) {
            throw new Error("getSteamPriceByProductAndRegion: inapp for product '".concat(productId, "' not found."));
        }
        return SteamUtils.getDefaultSteamPrice(inapp.CashPrice);
    };
    InAPPUtils.getSteamPriceByProductAndRegion = function (productId, countryCode) {
        var inapp = inAppsByProductsMap[productId];
        if (!inapp) {
            throw new Error("getSteamPriceByProductAndRegion: inapp for product '".concat(productId, "' not found."));
        }
        return SteamUtils.getSteamPrice(countryCode, inapp.CashPrice);
    };
    InAPPUtils.getSteamOfferPrice = function (settings) {
        var productId = settings.productId, countryCode = settings.countryCode;
        var price = InAPPUtils.getSteamPriceByProductAndRegion(productId, countryCode);
        return {
            price: SteamUtils.roundPrice(price.amount / 100),
            currency: price.currency
        };
    };
    InAPPUtils.getSteamOfferPriceMap = function (settings) {
        var result = {};
        for (var name_2 in inAppSettings) {
            var inApp = inAppSettings[name_2];
            result[inApp.ProductID] = InAPPUtils.getSteamOfferPrice({
                countryCode: settings.countryCode,
                productId: inApp.ProductID,
            });
        }
        return result;
    };
    InAPPUtils.getToffeeOfferInfo = function (settings) {
        var offerId = settings.offerId, countryCode = settings.countryCode, productId = settings.productId;
        var shopOfferSettingsParameters = shopSlotsMap.get(offerId);
        var promoOffer = offersMap.get(offerId);
        if (!shopOfferSettingsParameters && !promoOffer) {
            throw new Error("createInAppPurchaseResult: There in no such offer/shopSlot with id ".concat(offerId));
        }
        var inapp = inAppsByProductsMap[productId];
        if (!inapp) {
            throw new Error("getSteamPriceByProductAndRegion: inapp for product '".concat(productId, "' not found."));
        }
        var image = inapp.ToffeeSettings && inapp.ToffeeSettings.image || InAppConstants.defaultToffeeImage;
        var price = Math.round(inapp.CashPrice * 100);
        var description = promoOffer != null
            ? promoOffer._offerNameAlias
            : shopOfferSettingsParameters.Alias;
        return {
            amount: price,
            currency: InAppConstants.defaultToffeeCurrency,
            description: description,
            image: image
        };
    };
    ;
    InAPPUtils.useToffeeInsteadOfDefaultPayment = function (settings) {
        var checkers = InAppConstants.forceToffeeConditionsOneOf;
        for (var _i = 0, checkers_1 = checkers; _i < checkers_1.length; _i++) {
            var checker = checkers_1[_i];
            if (checker(settings)) {
                return true;
            }
        }
        return false;
    };
    return InAPPUtils;
}());
