var TOFFEE_COUNTRIES = [
    "AG", "AI", "AR", "AW", "BB", "BM", "BO", "BQ", "BR", "BS", "BZ", "CA", "CL", "CO", "CR", "CU", "CW",
    "DM", "DO", "EC", "GD", "GF", "GL", "GP", "GT", "GY", "HN", "HT", "JM", "KN", "KY", "LC", "MF", "MQ",
    "MS", "MX", "NI", "PA", "PE", "PR", "PY", "SR", "SV", "SX", "TC", "TT", "US", "UY", "VC", "VE", "VG", "VI"
];
var TOFFEE_USEU_COUNTRIES = [
    "US", "AT", "BE", "BG", "HU", "DE", "GR", "DK", "IE", "ES", "IT", "CY", "LV", "LT", "LU", "MT", "NL", "PL", "PT",
    "RO", "SK", "SI", "FI", "FR", "HR", "CZ", "SE", "EE"
];
var InAppConstants = (function () {
    function InAppConstants() {
    }
    InAppConstants.defaultToffeeImage = "https://sfacdn.nekki.com/assets/toffeepay/product_icon.png";
    InAppConstants.defaultToffeeCurrency = "USD";
    InAppConstants.forceToffeeConditionsOneOf = [
        function (p) {
            return ["TEST_SFA_TOFFEE_PAY_REVIEW"].indexOf(p.settings.companyName) > -1;
        },
        function (p) {
            return p.settings.countryCode == "US"
                && [PLATFORM.IOS].indexOf(p.settings.platform) > -1
                && Boolean(p.settings.companyName)
                && (p.worldContainer.indexOf('prod-') === -1 || p.worldContainer.indexOf('prod-us') > -1);
        },
    ];
    return InAppConstants;
}());
