function createOfferPurchaseResult(settings) {
    return InAPPUtils.createOfferPurchaseResult(settings);
}
function getOfferCompensation(settings) {
    return InAPPUtils.getOfferCompensation(settings);
}
function isRegionalProductCorrect(settings) {
    return InAPPUtils.isRegionalProductCorrect(settings);
}
function isSubscriptionAvailableForPlayer(settings) {
    return InAPPUtils.isSubscriptionAvailableForPlayer(settings);
}
function getUmoneyPriceForInApp(inAppId) {
    return InAPPUtils.getUmoneyPriceForInApp(inAppId);
}
function getUmoneyPriceStringForInApp(inAppId) {
    return InAPPUtils.getUmoneyPriceStringForInApp(inAppId);
}
function getAllRegionalPackagesForVietnam(settings) {
    return InAppVietnamUtils.getAllRegionalPackagesForVietnam(settings);
}
function getInAppSettings(settings) {
    return InAPPUtils.getInAppSettings(settings);
}
function getSteamOfferInfo(settings) {
    return InAPPUtils.getSteamOfferInfo(settings);
}
function getSteamOfferDefaultPrice(settings) {
    return InAPPUtils.getSteamOfferDefaultPrice(settings);
}
function getSteamOfferPrice(settings) {
    return InAPPUtils.getSteamOfferPrice(settings);
}
function getSteamOfferPriceMap(settings) {
    return InAPPUtils.getSteamOfferPriceMap(settings);
}
function useToffeeInsteadOfDefaultPayment(settings) {
    return InAPPUtils.useToffeeInsteadOfDefaultPayment(settings);
}
function getToffeeOfferInfo(settings) {
    return InAPPUtils.getToffeeOfferInfo(settings);
}
