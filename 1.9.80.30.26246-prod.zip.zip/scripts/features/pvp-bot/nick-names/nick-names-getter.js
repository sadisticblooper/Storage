var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var NickNamesGetter = (function () {
    function NickNamesGetter() {
        this.isVowels = {};
    }
    NickNamesGetter.prototype.generateNickName = function (ri) {
        var tries = 1000;
        var nick = this.generateNickNameWithoutCensored(ri);
        var censureResult = censureWord(nick);
        while (tries > 0 && !censureResult.verified) {
            nick = this.generateNickNameWithoutCensored(ri);
            censureResult = censureWord(nick);
        }
        return nick;
    };
    NickNamesGetter.prototype.generateNickNameWithoutCensored = function (ri) {
        var length = NickNamesSettings.nickNameLength.getRandomValue(ri);
        var result = "";
        var prefix = null;
        while (result.length < length) {
            result += this.getRandomSymbols(ri);
        }
        var isPrefixNeeded = this.isPrefixNeeded(ri);
        var isDelimiterNeeded = this.isDelimiterNeeded(ri);
        if (isPrefixNeeded) {
            var prefixes = NickNamesSettings.prefixes;
            if (prefixes.length > 0) {
                var prefix_1 = prefixes[ri.nextInt(prefixes.length)];
                var testedChar = prefix_1.charAt(prefix_1.length - 1);
                var delimiter = isDelimiterNeeded || this.isVowel(testedChar) == this.isVowel(result.charAt(0))
                    ? NickNamesSettings.delimiter
                    : "";
                result = prefix_1 + delimiter + result;
            }
        }
        if (!isPrefixNeeded && this.isPostfixNeeded(ri)) {
            var postfixes = NickNamesSettings.postfixes.filter(function (p) { return p != prefix; });
            if (postfixes.length > 0) {
                var postfix = postfixes[ri.nextInt(postfixes.length)];
                var testedChar = result.charAt(result.length - 1);
                var delimiter = isDelimiterNeeded || this.isVowel(testedChar) == this.isVowel(postfix.charAt(0))
                    ? NickNamesSettings.delimiter
                    : "";
                result = result + delimiter + postfix;
            }
        }
        result = result.toUpperCase();
        if (this.isDigitEndNeeded(ri)) {
            var pow = NickNamesSettings.digitEndInterval.getRandomValue(ri);
            var max = Math.pow(10, pow);
            result += (ri.nextInt(max - 1) + 1).toString();
        }
        else {
            for (var _i = 0, _a = NickNamesSettings.digitReplaces; _i < _a.length; _i++) {
                var _b = _a[_i], original = _b[0], replace = _b[1];
                if (this.isDigitReplaceNeeded(ri)) {
                    result = result.replace(new RegExp(original.toUpperCase(), "g"), replace);
                }
            }
        }
        for (var _c = 0, _d = NickNamesSettings.symbolsReplaces; _c < _d.length; _c++) {
            var _e = _d[_c], original = _e[0], replace = _e[1];
            if (this.isSymbolReplaceNeeded(ri)) {
                result = result.replace(new RegExp(original.toUpperCase(), "g"), replace);
            }
        }
        return result.toUpperCase();
    };
    NickNamesGetter.prototype.getRandomIndex = function (ri, symbolsTable) {
        var collection = new RandomCollection();
        for (var index = 0; index < symbolsTable.length; index++) {
            var _a = symbolsTable[index], _ = _a[0], weight = _a[1];
            collection.add(new CollectionObjectContainer(index, weight));
        }
        return collection.next(ri).get();
    };
    NickNamesGetter.prototype.isPrefixNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.prefixChance;
    };
    NickNamesGetter.prototype.isPostfixNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.postfixChance;
    };
    NickNamesGetter.prototype.isDelimiterNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.delimiterChance;
    };
    NickNamesGetter.prototype.isDigitEndNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.digitEndChance;
    };
    NickNamesGetter.prototype.isDigitReplaceNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.digitReplaceChance;
    };
    NickNamesGetter.prototype.isSymbolReplaceNeeded = function (ri) {
        return ri.nextDouble() < NickNamesSettings.symbolsReplaceChance;
    };
    NickNamesGetter.prototype.isVowel = function (symbol) {
        symbol = symbol.toUpperCase();
        if (this.isVowels[symbol] === undefined) {
            var isVowel = false;
            for (var _i = 0, _a = NickNamesSettings.alphabetVowelsChances; _i < _a.length; _i++) {
                var chanceSettings = _a[_i];
                var symb = chanceSettings[0];
                if (symbol == symb.toUpperCase()) {
                    isVowel = true;
                    break;
                }
            }
            this.isVowels[symbol] = isVowel;
        }
        return this.isVowels[symbol];
    };
    NickNamesGetter.createNickGetter = function (isAlphabet) {
        return isAlphabet ? new NickNamesGetterAlphabet() : new NickNamesGetterSyllable();
    };
    return NickNamesGetter;
}());
var NickNamesGetterAlphabet = (function (_super) {
    __extends(NickNamesGetterAlphabet, _super);
    function NickNamesGetterAlphabet() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.symbolType = -1;
        return _this;
    }
    NickNamesGetterAlphabet.prototype.getRandomSymbols = function (ri) {
        this.symbolType = this.symbolType == -1
            ? (new RndFromInterval(0, 1)).getRandomValue(ri)
            : (this.symbolType + 1) % 2;
        var symbolsTable = this.symbolType == 0
            ? NickNamesSettings.alphabetVowelsChances
            : NickNamesSettings.alphabetConsonantsChances;
        var index = this.getRandomIndex(ri, symbolsTable);
        var symbols = symbolsTable[index][0];
        return symbols;
    };
    return NickNamesGetterAlphabet;
}(NickNamesGetter));
var NickNamesGetterSyllable = (function (_super) {
    __extends(NickNamesGetterSyllable, _super);
    function NickNamesGetterSyllable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NickNamesGetterSyllable.prototype.getRandomSymbols = function (ri) {
        var symbolsTable = NickNamesSettings.syllableChances;
        var index = this.getRandomIndex(ri, symbolsTable);
        var symbols = symbolsTable[index][0];
        return symbols;
    };
    return NickNamesGetterSyllable;
}(NickNamesGetter));
