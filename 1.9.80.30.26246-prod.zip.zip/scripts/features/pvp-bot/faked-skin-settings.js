var _a;
var OpponentFakedSkinSettings = (function () {
    function OpponentFakedSkinSettings() {
    }
    OpponentFakedSkinSettings.fightCounterBound = { min: 3, max: 6 };
    OpponentFakedSkinSettings.botRaritySkinChances = (_a = {},
        _a[SKIN_RARITY.COMMON] = 0.4,
        _a[SKIN_RARITY.RARE] = 0.3,
        _a[SKIN_RARITY.EPIC] = 0.15,
        _a[SKIN_RARITY.SEASON] = 0.15,
        _a[SKIN_RARITY.LEGENDARY] = 0.25,
        _a);
    OpponentFakedSkinSettings.allowedMatchingMode = [
        FIGHT_MODE.RANKED,
        FIGHT_MODE.TOURNAMENT,
    ];
    OpponentFakedSkinSettings.ratingBounds = {
        pvp: { min: 0, max: 600 },
        bot: { min: 0, max: 1000 },
    };
    return OpponentFakedSkinSettings;
}());
