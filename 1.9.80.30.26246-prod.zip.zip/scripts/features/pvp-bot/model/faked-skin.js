var OpponentFakedSkin = (function () {
    function OpponentFakedSkin() {
    }
    OpponentFakedSkin.getUpdatedCounter = function (settings) {
        var currentValue = settings.currentValue, isBot = settings.isBot, matchingMode = settings.matchingMode, rating = settings.rating, rnd = settings.rnd;
        if (OpponentFakedSkinSettings.allowedMatchingMode.indexOf(matchingMode) == -1) {
            return currentValue;
        }
        var ratingBounds;
        if (isBot) {
            ratingBounds = OpponentFakedSkinSettings.ratingBounds.bot;
        }
        else {
            ratingBounds = OpponentFakedSkinSettings.ratingBounds.pvp;
        }
        if (rating < ratingBounds.min || rating > ratingBounds.max) {
            return currentValue;
        }
        if (currentValue == null || currentValue < 0) {
            return OpponentFakedSkin.getNewCounterValue(rnd);
        }
        return currentValue - 1;
    };
    OpponentFakedSkin.getNewCounterValue = function (rnd) {
        var minMax = OpponentFakedSkinSettings.fightCounterBound;
        return new RndFromInterval(minMax.min, minMax.max).getRandomValue(rnd);
    };
    OpponentFakedSkin.getFakedSkinId = function (currentId, rnd, isBot) {
        var skin = skinsMap.checkedGet(currentId);
        if (!skin.PutOnHero && !skin.IsDefault && !isBot) {
            return currentId;
        }
        var heroId = skin.OwnerHeroID;
        var skinsByRarity = {};
        for (var _i = 0, _a = skinsMap.getKeys(); _i < _a.length; _i++) {
            var skinId = _a[_i];
            var heroSkin = skinsMap.get(skinId);
            if (heroSkin.OwnerHeroID == heroId) {
                if (skinsByRarity[heroSkin.Rarity] == undefined) {
                    skinsByRarity[heroSkin.Rarity] = [];
                }
                skinsByRarity[heroSkin.Rarity].push(skinId);
            }
        }
        var rarityChances = OpponentFakedSkinSettings.botRaritySkinChances;
        var rarityCollection = new RandomCollection();
        for (var rarity in rarityChances)
            if (rarityChances.hasOwnProperty(rarity)) {
                if (skinsByRarity[+rarity] != undefined) {
                    var weight = rarityChances[rarity];
                    rarityCollection.add(new CollectionObjectContainer(rarity, weight));
                }
            }
        if (rarityCollection.size() == 0) {
            return currentId;
        }
        var chosenRarity = Number(rarityCollection.next(rnd).get());
        var skinCollection = new RandomCollection();
        for (var _b = 0, _c = skinsByRarity[chosenRarity]; _b < _c.length; _b++) {
            var skinId = _c[_b];
            skinCollection.add(new CollectionObjectContainer(skinId, 1));
        }
        if (skinCollection.size() > 0) {
            return skinCollection.next(rnd).get();
        }
        return currentId;
    };
    OpponentFakedSkin.getFakedSkinAndUpdatedFightCounter = function (settings) {
        var fakedSkinFightCounter = settings.fakedSkinFightCounter, matchingMode = settings.matchingMode, warriorSkins = settings.warriorSkins, rating = settings.rating;
        var isBot = true;
        var seed = CommonUtils.getRandomJSSeed();
        var rnd = new PcgRandom(seed);
        var currentValue = OpponentFakedSkin.getUpdatedCounter({
            currentValue: fakedSkinFightCounter,
            rating: rating,
            isBot: isBot,
            matchingMode: matchingMode,
            rnd: rnd,
        });
        if (currentValue > 0 || currentValue == fakedSkinFightCounter) {
            return {
                fakedSkinFightCounter: currentValue,
                warriorSkins: warriorSkins,
            };
        }
        currentValue = OpponentFakedSkin.getNewCounterValue(rnd);
        var heroIds = [];
        for (var hid in warriorSkins) {
            heroIds.push(+hid);
        }
        if (heroIds.length == 0) {
            return {
                fakedSkinFightCounter: currentValue,
                warriorSkins: warriorSkins,
            };
        }
        var heroId = heroIds[rnd.nextInt(heroIds.length)];
        var hero = heroesMap.checkedGet(heroId);
        warriorSkins[heroId] = OpponentFakedSkin
            .getFakedSkinId(warriorSkins[heroId] || hero.DefaultSkinId, rnd, isBot);
        return {
            fakedSkinFightCounter: currentValue,
            warriorSkins: warriorSkins,
        };
    };
    OpponentFakedSkin.getFakeSkinAndUpdatedFightCounterForBot = function (settings) {
        var fakedSkinFightCounter = settings.fakedSkinFightCounter, matchingMode = settings.matchingMode, rankRating = settings.rankRating, rating = settings.rating, warriors = settings.warriors;
        var warriorSkins = {};
        for (var _i = 0, warriors_1 = warriors; _i < warriors_1.length; _i++) {
            var warrior = warriors_1[_i];
            warriorSkins[warrior.heroID] = warrior.skinID;
        }
        return OpponentFakedSkin.getFakedSkinAndUpdatedFightCounter({
            warriorSkins: warriorSkins,
            rating: rating,
            matchingMode: matchingMode,
            rankRating: rankRating,
            fakedSkinFightCounter: fakedSkinFightCounter,
        });
    };
    return OpponentFakedSkin;
}());
