var BotBrawler = (function () {
    function BotBrawler() {
    }
    BotBrawler.buildBrawlerSearchBounds = function (settings) {
        var rating = settings.rating, teamMode = settings.teamMode, rankRating = settings.rankRating, isCalibrationOfMatching = settings.isCalibrationOfMatching;
        var fightConstants = getFightConstants(teamMode);
        var maxRankRating = CalculationRatingSettings.rankRatingCap[teamMode];
        var maxHeroLevels = [];
        var avgHeroLevels = [];
        var avgLevels = BotUtils.getAverageBotLevelsSettings(rating, rankRating, teamMode).averageBotLevels;
        var powerDeviationIndex = CommonGameUtils.getNumberIntervalIndex(rating, BotConstants.powerDeviationAtRatingForBotsPool);
        var powerDeviation = BotConstants.powerDeviationAtRatingForBotsPool[powerDeviationIndex].items[0];
        if (isCalibrationOfMatching && teamMode == TEAM_MODE._1_VS_1_) {
            var accountLevel = settings.accountLevel, heroLevel = settings.heroLevel;
            var ratingSettings = RatingUtils.getRatingSettingsByLevelPower(accountLevel + heroLevel, TEAM_MODE._1_VS_1_);
            rankRating = ratingSettings.range.start - 1;
            avgLevels = {
                AvgAccountLevel: ratingSettings.items[0].accountLevel,
                AvgHeroLevel: ratingSettings.items[0].maxHeroLevel,
            };
            powerDeviation = "0";
        }
        for (var i = 0; i < fightConstants.formationsCountLimit; i++) {
            maxHeroLevels.push(HeroConstants.maxHeroLevel);
            avgHeroLevels.push(avgLevels.AvgHeroLevel);
        }
        var maxPower = HeroUtils.getCorePower({
            accountLevel: MAX_ACCOUNT_LEVEL,
            heroLevels: maxHeroLevels,
        });
        var avgPower = HeroUtils.getCorePower({
            accountLevel: avgLevels.AvgAccountLevel,
            heroLevels: avgHeroLevels,
        });
        var ratingDeviationIndex = CommonGameUtils.getNumberIntervalIndex(rating, BotConstants.rankRatingDeviationAtRatingForBotsPool);
        var ratingDeviation = BotConstants.rankRatingDeviationAtRatingForBotsPool[ratingDeviationIndex].items[0];
        var rankRatingBound = CommonUtils.getRelativeNumber(rankRating, ratingDeviation);
        var powerBound = CommonUtils.getRelativeNumber(avgPower, powerDeviation);
        if (maxRankRating < rankRating) {
            maxRankRating = rankRating;
        }
        return {
            minRankRating: Math.max(0, rankRating - rankRatingBound),
            maxRankRating: Math.min(maxRankRating, rankRating + rankRatingBound),
            minPower: Math.max(0, avgPower - powerBound),
            maxPower: Math.min(maxPower, avgPower + powerBound),
        };
    };
    BotBrawler.calcMatchingPower = function (settings) {
        var formation = settings.formation, accountLevel = settings.accountLevel;
        var heroLevels = [];
        for (var _i = 0, _a = formation.heroes; _i < _a.length; _i++) {
            var warrior = _a[_i];
            heroLevels.push(warrior.warriorLevel);
        }
        return HeroUtils.getCorePower({
            accountLevel: accountLevel,
            heroLevels: heroLevels,
        });
    };
    return BotBrawler;
}());
