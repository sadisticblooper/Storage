var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var BotGenerator = (function () {
    function BotGenerator() {
    }
    BotGenerator.getBotAccount = function (botGeneratorSettings) {
        BotGenerator.randomGenerator = new PcgRandom(CommonUtils.getRandomJSSeed());
        var botAccount;
        var playerAccount = botGeneratorSettings.ourAccount, enemiesPool = botGeneratorSettings.enemyPool, repeatedPool = botGeneratorSettings.alreadyGeneratedPool, matchingMode = botGeneratorSettings.matchingMode, teamMode = botGeneratorSettings.teamMode, autoBotSettings = botGeneratorSettings.autoBotSettings, fakedSkinFightCounter = botGeneratorSettings.fakedSkinFightCounter, fightCounters = botGeneratorSettings.fightCounters, isCalibrationOfMatching = botGeneratorSettings.isCalibrationOfMatching;
        var averageLevelsSettings = BotUtils.getAverageBotLevelsSettings(playerAccount.Rating, playerAccount.RankRating, teamMode);
        var formationsCountLimit = getFightConstants(teamMode).formationsCountLimit;
        if (isCalibrationOfMatching && teamMode == TEAM_MODE._1_VS_1_) {
            var accountLevel = playerAccount.AccountLevel;
            var heroLevel = playerAccount.Heroes[0].warriorLevel;
            var ratingSettings = RatingUtils.getRatingSettingsByLevelPower(accountLevel + heroLevel, TEAM_MODE._1_VS_1_);
            averageLevelsSettings = {
                averageBotLevels: {
                    AvgHeroLevel: ratingSettings.items[0].maxHeroLevel,
                    AvgAccountLevel: ratingSettings.items[0].accountLevel,
                },
            };
            playerAccount.RankRating = ratingSettings.range.start - 1;
        }
        this.setAvgBotLevels(averageLevelsSettings.averageBotLevels);
        var playerHeroLevels = [];
        for (var _i = 0, _a = playerAccount.Heroes; _i < _a.length; _i++) {
            var warrior = _a[_i];
            playerHeroLevels.push(warrior.warriorLevel);
        }
        playerAccount.Power = HeroUtils.getCorePower({
            accountLevel: playerAccount.AccountLevel,
            heroLevels: playerHeroLevels
        });
        var availablePool = enemiesPool.filter(function (enemy) {
            if (!enemy.Heroes || enemy.Heroes.length != formationsCountLimit) {
                return false;
            }
            var enemyAccountId = enemy.AccountId;
            var repeats = repeatedPool.reduce(function (sum, repeatedEnemy) {
                return sum + ((isNumber(repeatedEnemy.AccountId) && repeatedEnemy.AccountId == enemyAccountId) ? 1 : 0);
            }, 0);
            return repeats == 0;
        });
        if (matchingMode == FIGHT_MODE.RANKED && teamMode == TEAM_MODE._1_VS_1_ && isCalibrationOfMatching) {
            var metaPower_1 = RatingUtils.getMetaPower({
                accountLevel: playerAccount.AccountLevel,
                heroLevels: playerHeroLevels,
            });
            availablePool = availablePool.filter(function (enemy) {
                var enemyPower = RatingUtils.getMetaPower({
                    accountLevel: enemy.AccountLevel,
                    heroLevels: enemy.Heroes.map(function (warrior) { return warrior.warriorLevel; }),
                });
                return enemyPower == metaPower_1;
            });
        }
        if (matchingMode == FIGHT_MODE.RANKED) {
            if (availablePool && availablePool.length) {
                shuffle(availablePool, this.randomGenerator);
                botAccount = availablePool[0];
                if (!isCalibrationOfMatching) {
                    var rankRatingDiff = Math.abs(botAccount.RankRating - playerAccount.RankRating);
                    for (var _b = 0, availablePool_1 = availablePool; _b < availablePool_1.length; _b++) {
                        var account = availablePool_1[_b];
                        var currentDiff = Math.abs(playerAccount.RankRating - account.RankRating);
                        if (currentDiff < rankRatingDiff) {
                            rankRatingDiff = currentDiff;
                            botAccount = account;
                        }
                    }
                }
            }
            else {
                botAccount = BotGenerator.generateBotRanked({
                    player: playerAccount,
                    teamMode: teamMode,
                    averageLevelsSettings: averageLevelsSettings,
                });
            }
        }
        else {
            var filteredAvailablePool = availablePool.filter(function (enemy) {
                return HeroUtils.isValidCorePower(playerAccount.Power, enemy.Power);
            });
            if (filteredAvailablePool && filteredAvailablePool.length) {
                botAccount = filteredAvailablePool[0];
                var powerDiff = Math.abs(playerAccount.Power - botAccount.Power);
                for (var _c = 0, availablePool_2 = availablePool; _c < availablePool_2.length; _c++) {
                    var account = availablePool_2[_c];
                    var currentDiff = Math.abs(playerAccount.Power - account.Power);
                    if (currentDiff < powerDiff) {
                        powerDiff = currentDiff;
                        botAccount = account;
                    }
                }
            }
            else {
                botAccount = BotGenerator.generateBotUnranked(playerAccount, availablePool, teamMode);
            }
        }
        if (botAccount.Rating) {
            var arenaForBot = ArenaUtils.getArenaByRating(botAccount.Rating);
            if (arenaForBot) {
                botAccount.ArenaId = arenaForBot.ID;
            }
        }
        if (!botAccount.ArenaId) {
            botAccount.ArenaId = playerAccount.ArenaId;
        }
        if (!botAccount.AccountId) {
            botAccount.MaxRankRating = botAccount.RankRating;
            var names = BotConstants.BotPoolNames;
            botAccount.PlayerName = names[this.randomGenerator.nextInt(names.length)];
        }
        var botType = BOT_TYPE_FOR_ML_SETTINGS.RANKED;
        if (matchingMode == FIGHT_MODE.AI) {
            botType = BOT_TYPE_FOR_ML_SETTINGS.UNRANKED;
        }
        else if (matchingMode == FIGHT_MODE.RANKED && !autoBotSettings) {
            botType = BOT_TYPE_FOR_ML_SETTINGS.COMMON_BOT_RANKED;
        }
        var mlMode = this.getMLMode({
            rating: botAccount.Rating,
            rankRating: botAccount.RankRating,
            teamMode: teamMode,
            botType: botType,
        });
        var isMlBotEnable = BotConstants.defaultMLSettings.isMlBotEnable;
        for (var _d = 0, _e = botAccount.Heroes; _d < _e.length; _d++) {
            var warrior = _e[_d];
            var hasHeroMlSettings = BotConstants.defaultMLSettings.noMlHeroesIds.indexOf(warrior.heroID) == -1;
            if (hasHeroMlSettings && isMlBotEnable) {
                warrior.mlBotMode = mlMode;
            }
            else {
                warrior.mlBotMode = MLBOT_MODE.DISABLED;
            }
        }
        if (autoBotSettings && !autoBotSettings.allowPvPMatching && matchingMode == FIGHT_MODE.RANKED) {
            var winRate = MatchingModel.calcWinRate({
                rankedBattleCount: botGeneratorSettings.autoBotSettings.rankedBattleCount,
                winRateHistory: botGeneratorSettings.autoBotSettings.winRateHistory,
            });
            if (winRate >= 0 && winRate <= 1) {
                var autoBotPreset = MatchingModel.getAutoBotPreset(playerAccount.Rating, winRate, autoBotSettings.preset, teamMode);
                if (autoBotPreset) {
                    this.applyAutoBotPreset(botAccount, autoBotPreset);
                }
            }
        }
        if (!autoBotSettings && matchingMode == FIGHT_MODE.RANKED) {
            botAccount.RankRating = playerAccount.RankRating;
            botAccount.Rating = playerAccount.Rating;
        }
        var firstMatchOpponent = false;
        if (matchingMode == FIGHT_MODE.RANKED && teamMode == TEAM_MODE._1_VS_1_ && !isCalibrationOfMatching) {
            var opponent = this.getFirstMatcherOpponent(fightCounters);
            if (opponent) {
                botAccount.Heroes[0] = opponent;
                firstMatchOpponent = true;
            }
        }
        botAccount = this.applyLevelsRestrictionsAndChooseTalents(botAccount, playerAccount, firstMatchOpponent);
        var fakesSettings = {
            warriorSkins: {},
            fakedSkinFightCounter: fakedSkinFightCounter,
        };
        if (botAccount.AccountId == null) {
            fakesSettings
                = OpponentFakedSkin.getFakeSkinAndUpdatedFightCounterForBot({
                    fakedSkinFightCounter: fakedSkinFightCounter,
                    rankRating: botAccount.RankRating,
                    matchingMode: matchingMode,
                    rating: botAccount.Rating,
                    warriors: botAccount.Heroes,
                });
            BotUtils.replaceSkin(botAccount.Heroes, fakesSettings.warriorSkins);
            BotUtils.setDefaultSkinWeapons(botAccount.Heroes);
        }
        for (var _f = 0, _g = botAccount.Heroes; _f < _g.length; _f++) {
            var hero = _g[_f];
            var weapon = weaponsMap.checkedGet(hero.weaponId);
            if (weapon.rarity == HERO_WEAPON_RARITY.LEGENDARY) {
                BotUtils.setDefaultSkinWeapon(hero);
            }
        }
        if (!this.isAiModeDetermined(botAccount.Heroes)) {
            this.setDefaultAiMode(botAccount.Heroes);
        }
        botAccount.PlayerName = BotGenerator.createBotName(this.randomGenerator);
        return {
            accountBattleSettings: botAccount,
            fakedSkinFightCounter: fakesSettings.fakedSkinFightCounter,
        };
    };
    BotGenerator.createBotName = function (rnd) {
        var getter = NickNamesGetter.createNickGetter(true);
        return getter.generateNickName(rnd);
    };
    BotGenerator.applyAutoBotPreset = function (botAccount, settings) {
        var maxHeroLevel = HeroConstants.maxHeroLevel;
        botAccount.AccountLevel
            = Math.min(MAX_ACCOUNT_LEVEL, Math.max(1, botAccount.AccountLevel + settings.power));
        for (var _i = 0, _a = botAccount.Heroes; _i < _a.length; _i++) {
            var warrior = _a[_i];
            var hero = heroesMap.checkedGet(warrior.heroID);
            warrior.warriorLevel
                = Math.min(maxHeroLevel, Math.max(hero.StartLevel, warrior.warriorLevel + settings.power));
            if (warrior.mlBotMode != MLBOT_MODE.DISABLED) {
                warrior.mlBotMode
                    = Math.min(MLBOT_MODE.PRESET_10, Math.max(MLBOT_MODE.PRESET_1, warrior.mlBotMode + settings.mlPreset));
            }
        }
    };
    BotGenerator.isAiModeDetermined = function (warriors) {
        for (var _i = 0, warriors_1 = warriors; _i < warriors_1.length; _i++) {
            var warrior = warriors_1[_i];
            if (warrior.aiMode == undefined) {
                return false;
            }
            else {
                var mode = TacticsModesMap.get(warrior.aiMode);
                if (!mode) {
                    return false;
                }
            }
        }
        return true;
    };
    BotGenerator.setDefaultAiMode = function (warriors) {
        for (var _i = 0, warriors_2 = warriors; _i < warriors_2.length; _i++) {
            var warrior = warriors_2[_i];
            warrior.aiMode = BotConstants.defaultAiMode;
        }
    };
    BotGenerator.applyLevelsRestrictionsAndChooseTalents = function (bot, player, firstMatchOpponent) {
        var maxHeroLevel = HeroConstants.maxHeroLevel;
        var acc = {
            AccountId: bot.AccountId,
            Power: bot.Power,
            Rating: bot.Rating,
            RankRating: bot.RankRating,
            MaxRankRating: bot.MaxRankRating,
            PlayerName: bot.PlayerName,
            ArenaId: bot.ArenaId,
            AccountLevel: bot.AccountLevel,
            Heroes: [],
        };
        var botFromZero = acc.AccountId == null;
        for (var i = 0; i < bot.Heroes.length; i++) {
            var warrior = bot.Heroes[i];
            var hero = heroesMap.checkedGet(warrior.heroID);
            var level = Math.min(maxHeroLevel, Math.max(hero.StartLevel, warrior.warriorLevel));
            var talents_1 = [];
            if (botFromZero && !firstMatchOpponent) {
                var randomLevel = this.getRandomTalentLevelForBotWarrior(hero, player.Heroes[i]);
                talents_1 = hero.getRandomTalentsByLevel(randomLevel, this.randomGenerator);
            }
            else {
                talents_1 = warrior.talents;
            }
            var skin = warrior.skinID
                ? skinsMap.checkedGet(warrior.skinID)
                : skinsMap.checkedGet(hero.DefaultSkinId);
            acc.Heroes.push({
                warriorLevel: level,
                skinID: skin.ID,
                heroID: warrior.heroID,
                talents: talents_1,
                aiMode: warrior.aiMode,
                mlBotMode: warrior.mlBotMode,
                weaponId: warrior.weaponId ? warrior.weaponId : skin.DefaultWeaponId,
            });
        }
        return acc;
    };
    BotGenerator.getRandomTalentLevelForBotWarrior = function (botHero, playerWarrior) {
        if (!playerWarrior) {
            return 0;
        }
        var playerHero = heroesMap.checkedGet(playerWarrior.heroID);
        var level = playerHero.getTalentLevelByTalents(playerWarrior.talents);
        var _a = botHero.getMinMaxTalentLevels(), min = _a[0], max = _a[1];
        level = (-1 + this.randomGenerator.nextDouble() * 3) + level;
        level = Math.min(Math.max(min, level), max);
        return (level >> 0);
    };
    BotGenerator.getAllowedHeroesAtArena = function (arenaNumber) {
        var result = [];
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            if (hero.AllowInBotSquad && arenaNumber < hero.AllowInBotSquad.sinceArenaNumber
                || arenaNumber < hero.ArenaNumberNeeded) {
                continue;
            }
            result.push(hero.ID);
        }
        return result;
    };
    BotGenerator.setAvgBotLevels = function (levels) {
        BotGenerator.averageBotLevels = levels;
    };
    BotGenerator.generateBotRanked = function (settings) {
        var player = settings.player, teamMode = settings.teamMode, averageLevelsSettings = settings.averageLevelsSettings;
        var ri = this.randomGenerator;
        var botAccount = {
            AccountId: null,
            PlayerName: "",
            AccountLevel: 1,
            ArenaId: 1,
            Heroes: [],
            Power: 0,
            Rating: 0,
            RankRating: 0,
            MaxRankRating: 0,
        };
        var arena = arenasMap.checkedGet(player.ArenaId);
        var _a = averageLevelsSettings.averageBotLevels, AvgHeroLevel = _a.AvgHeroLevel, AvgAccountLevel = _a.AvgAccountLevel;
        var goalAccountPower = AvgHeroLevel + AvgAccountLevel;
        var deltaForLevel = BotGenerator.getRankedDeltaLevel(averageLevelsSettings.averageBotLevels, 2, ri);
        var accountLevel = AvgAccountLevel + deltaForLevel;
        var expectedHeroLevel = AvgHeroLevel - deltaForLevel;
        botAccount.Rating = player.Rating;
        botAccount.RankRating = player.RankRating;
        botAccount.ArenaId = player.ArenaId;
        botAccount.AccountLevel = accountLevel;
        botAccount.Heroes = [];
        var availableHeroes = BotGenerator
            .getAvailableHeroesSeparatedByClass(botAccount.AccountLevel, arena.ArenaNumber, expectedHeroLevel);
        var availableIdsPool = __spreadArray(__spreadArray(__spreadArray([], availableHeroes.SHADOW, true), availableHeroes.ANTI_SHADOW, true), availableHeroes.PHYSICS, true);
        shuffle(availableIdsPool, ri);
        var goalHeroesQuantity = getFightConstants(teamMode).formationsCountLimit;
        var neededHeroQuantity = goalHeroesQuantity - availableIdsPool.length;
        if (neededHeroQuantity > 0) {
            var allIdsPool = heroesMap.getKeys().slice();
            shuffle(allIdsPool, ri);
            for (var _i = 0, allIdsPool_1 = allIdsPool; _i < allIdsPool_1.length; _i++) {
                var id = allIdsPool_1[_i];
                if (availableIdsPool.indexOf(id) == -1) {
                    availableIdsPool.push(id);
                    neededHeroQuantity--;
                    if (neededHeroQuantity <= 0) {
                        break;
                    }
                }
            }
        }
        var heroWithMaxLevel = null;
        for (var _b = 0, availableIdsPool_1 = availableIdsPool; _b < availableIdsPool_1.length; _b++) {
            var hid = availableIdsPool_1[_b];
            var hero = heroesMap.checkedGet(hid);
            if (hero.StartLevel <= expectedHeroLevel) {
                heroWithMaxLevel = hid;
                break;
            }
        }
        var iterations = Math.min(goalHeroesQuantity, availableIdsPool.length);
        for (var i = 0; i < iterations; i++) {
            var hero = heroesMap.checkedGet(availableIdsPool[i]);
            var skin = skinsMap.checkedGet(hero.DefaultSkinId);
            var heroLevel = heroWithMaxLevel == hero.ID
                ? expectedHeroLevel
                : BotGenerator.getRankedBotLevel(hero.Rarity, ri, averageLevelsSettings);
            heroLevel = Math.max(hero.StartLevel, Math.min(expectedHeroLevel, heroLevel));
            var warriorSettings = {
                warriorLevel: heroLevel,
                talents: [],
                skinID: skin.ID,
                heroID: hero.ID,
                aiMode: BotConstants.defaultAiMode,
                mlBotMode: null,
                weaponId: skin.DefaultWeaponId,
            };
            botAccount.Heroes.push(warriorSettings);
        }
        return botAccount;
    };
    BotGenerator.generateBotUnranked = function (player, notRepeatedEnemies, teamMode) {
        var arena = arenasMap.checkedGet(player.ArenaId);
        var allowedHeroesAtArena = BotGenerator.getAllowedHeroesAtArena(arena.ArenaNumber);
        var fightConstants = getFightConstants(teamMode);
        var bot = {
            AccountId: null,
            PlayerName: "",
            AccountLevel: player.AccountLevel,
            RankRating: player.RankRating,
            ArenaId: player.ArenaId,
            Heroes: [],
            Power: 0,
            Rating: player.Rating,
            MaxRankRating: 0,
        }, availableHeroesIds, ri = this.randomGenerator, availableHeroes = HeroUtils.getAvailableHeroesOnAccLevel(player.AccountLevel, allowedHeroesAtArena), fromEnemies = false;
        notRepeatedEnemies = notRepeatedEnemies.filter(function (enemy) {
            var allowIds = [];
            for (var _i = 0, _a = enemy.Heroes; _i < _a.length; _i++) {
                var warrior = _a[_i];
                if (warrior.heroID) {
                    var hero = heroesMap.get(warrior.heroID);
                    if (hero && player.AccountLevel >= hero.AccLevelNeeded && arena.ArenaNumber >= hero.ArenaNumberNeeded) {
                        allowIds.push(warrior.heroID);
                    }
                }
            }
            return allowIds.length >= fightConstants.formationsCountLimit;
        });
        if (notRepeatedEnemies.length) {
            var heroes_2 = notRepeatedEnemies[ri.nextInt(notRepeatedEnemies.length)].Heroes;
            availableHeroesIds = [];
            for (var _i = 0, heroes_1 = heroes_2; _i < heroes_1.length; _i++) {
                var warrior = heroes_1[_i];
                availableHeroesIds.push(warrior.heroID);
            }
            fromEnemies = true;
        }
        var power = 0, maxAttempts = 100, levels = [], averageLevel = 0;
        for (var _a = 0, _b = player.Heroes; _a < _b.length; _a++) {
            var warrior = _b[_a];
            averageLevel += warrior.warriorLevel;
        }
        averageLevel = Math.round(averageLevel / player.Heroes.length);
        while (!HeroUtils.isValidCorePower(player.Power, power) && maxAttempts--) {
            if (fromEnemies) {
                fromEnemies = false;
            }
            else {
                shuffle(availableHeroes, ri);
                availableHeroesIds = availableHeroes.slice();
            }
            bot.Heroes = [];
            levels = [];
            var warriorsIteration = Math.min(fightConstants.formationsCountLimit, availableHeroesIds.length);
            for (var i = 0; i < warriorsIteration; i++) {
                var hero = heroesMap.checkedGet(availableHeroesIds[i]);
                var skin = skinsMap.checkedGet(hero.DefaultSkinId);
                levels[i] = this.getUnrankedBotLevel(averageLevel, hero.Rarity, ri);
                bot.Heroes.push({
                    heroID: availableHeroesIds[i],
                    warriorLevel: 1,
                    talents: [],
                    skinID: skin.ID,
                    aiMode: BotConstants.defaultAiMode,
                    mlBotMode: null,
                    weaponId: skin.DefaultWeaponId,
                });
            }
            power = HeroUtils.getCorePower({
                accountLevel: player.AccountLevel,
                heroLevels: levels,
            });
        }
        if (!maxAttempts) {
            for (var i in player.Heroes) {
                levels[i] = player.Heroes[i].warriorLevel;
                bot.Heroes[i].heroID = player.Heroes[i].heroID;
            }
            power = player.Power;
        }
        for (var i in bot.Heroes) {
            bot.Heroes[i].warriorLevel = levels[i];
        }
        bot.Power = power;
        return bot;
    };
    BotGenerator.getRankedBotLevel = function (rarity, ri, averageBotSettings) {
        var avgLevel = averageBotSettings.averageBotLevels.AvgHeroLevel;
        var deltaLevel;
        deltaLevel = this.getDeltaLevelInChancesTable(BotConstants.ChanceHeroLevelDefault, rarity, ri);
        return avgLevel + deltaLevel;
    };
    BotGenerator.getRankedDeltaLevel = function (averageBotLevels, expectedDelta, ri) {
        var AvgAccountLevel = averageBotLevels.AvgAccountLevel, AvgHeroLevel = averageBotLevels.AvgHeroLevel;
        var min = Math.max(AvgHeroLevel - HeroConstants.maxHeroLevel, 1 - AvgAccountLevel, -expectedDelta);
        var max = Math.min(AvgHeroLevel - 1, MAX_ACCOUNT_LEVEL - AvgAccountLevel, expectedDelta);
        var delta = max - min;
        return min + ri.nextInt(delta + 1);
    };
    BotGenerator.getUnrankedBotLevel = function (averageLevel, rarity, ri) {
        var delta = this.getDeltaLevelInChancesTable(BotConstants.ChanceHeroLevelUnranked, rarity, ri);
        return averageLevel + delta;
    };
    BotGenerator.getDeltaLevelInChancesTable = function (table, rarity, ri) {
        var defaultLevel = 0;
        var chances = table[rarity];
        if (!chances) {
            return defaultLevel;
        }
        var rndCollection = new RandomCollection();
        for (var delta in chances) {
            var weight = chances[delta];
            rndCollection.add(new CollectionObjectContainer(delta, weight));
        }
        var deltaLevel = Number(rndCollection.next(ri).get());
        return isNumber(deltaLevel) ? deltaLevel : defaultLevel;
    };
    BotGenerator.getAvailableHeroesSeparatedByClass = function (level, arenaNumber, expectedHeroLevel) {
        var heroes = {
            SHADOW: [],
            ANTI_SHADOW: [],
            PHYSICS: []
        };
        var allowedHeroesByArena = BotGenerator.getAllowedHeroesAtArena(arenaNumber);
        for (var _i = 0, allowedHeroesByArena_1 = allowedHeroesByArena; _i < allowedHeroesByArena_1.length; _i++) {
            var id = allowedHeroesByArena_1[_i];
            var hero = heroesMap.get(id);
            if (hero && hero.AccLevelNeeded <= level && hero.StartLevel <= expectedHeroLevel) {
                heroes[HERO_CLASS[hero.hero_class]].push(id);
            }
        }
        return heroes;
    };
    BotGenerator.getRankedBotTooltipInfo = function (settings) {
        var result = {
            showTooltip: false,
            winDeltaRating: 0,
            loseDeltaRating: 0,
            recommendedValue: 0
        };
        var rankRating = settings.rankRating, teamMode = settings.teamMode, accountLevel = settings.accountLevel, playerFormation = settings.playerFormation, rating = settings.rating;
        var currentValue = RatingUtils.getMetaPower({
            heroLevels: playerFormation.heroes.map(function (w) { return w.warriorLevel; }),
            accountLevel: accountLevel,
        });
        var penaltyCoefficient = RatingUtils.getBotPowerPenalty({
            rankRating: rankRating,
            actualValue: currentValue,
            teamMode: teamMode,
        });
        if (penaltyCoefficient >= 1) {
            return result;
        }
        var recommendedValue = RatingUtils.getRecommendedValueWithoutBotPenalty(rankRating, teamMode);
        if (currentValue >= recommendedValue || recommendedValue == -1) {
            return result;
        }
        else {
            result.showTooltip = true;
            result.recommendedValue = Math.round(recommendedValue);
        }
        var calcDeltaRatingTemplateSettings = {
            enemyRankRating: 0,
            matchingInfo: { teamMode: teamMode, mode: FIGHT_MODE.RANKED, enemyMode: ENEMY_MODE.COMMON_BOT },
            playerAccountLevel: accountLevel,
            playerRating: rating,
            playerRankRating: rankRating,
            enemyFormation: { formationId: teamMode, heroes: [] },
            enemyAccountLevel: 0,
            playerFormation: playerFormation,
            fightResult: FIGHT_RESULT.WIN,
            pvpWinStreak: 0,
        };
        var matchingBounds = buildBrawlerSearchBounds({
            rankRating: rankRating,
            teamMode: teamMode,
            rating: rating,
            accountLevel: accountLevel,
            isCalibrationOfMatching: false,
        });
        calcDeltaRatingTemplateSettings = CommonUtils.replaceSimple(calcDeltaRatingTemplateSettings, {
            enemyRankRating: rankRating,
        });
        result.winDeltaRating = calcDeltaRating(calcDeltaRatingTemplateSettings).commonRankRating;
        calcDeltaRatingTemplateSettings = CommonUtils.replaceSimple(calcDeltaRatingTemplateSettings, {
            fightResult: FIGHT_RESULT.LOSE,
            enemyRankRating: rankRating,
        });
        result.loseDeltaRating = calcDeltaRating(calcDeltaRatingTemplateSettings).commonRankRating;
        return result;
    };
    BotGenerator.getMLMode = function (settings) {
        var rankRating = settings.rankRating, teamMode = settings.teamMode, botType = settings.botType;
        var tableRankRating = BotConstants.mlBotDifficultiesByRankRating[teamMode][botType];
        var defaultResult = BotConstants.defaultMLSettings.defaultMLMode;
        var presetNumberRank = null;
        if (tableRankRating) {
            var rankIntervalIndexIndex = CommonGameUtils.getNumberIntervalIndex(rankRating, tableRankRating);
            presetNumberRank = tableRankRating[rankIntervalIndexIndex]
                && tableRankRating[rankIntervalIndexIndex].items[0];
        }
        return presetNumberRank || defaultResult;
    };
    BotGenerator.getFirstMatcherOpponent = function (fightCounters) {
        var rankCounter = fightCounters[FIGHT_MODE.RANKED] || 0;
        var opponent = BotConstants.firstMatchesOpponents[rankCounter];
        if (!opponent) {
            return null;
        }
        var hero = heroesMap.checkedGet(opponent.hid);
        var skin = skinsMap.checkedGet(hero.DefaultSkinId);
        var rnd = this.randomGenerator;
        return {
            heroID: opponent.hid,
            warriorLevel: opponent.level,
            talents: hero.getRandomTalentsByLevel(opponent.talents, rnd),
            skinID: skin.ID,
            weaponId: skin.DefaultWeaponId,
            aiMode: opponent.aiPreset,
            mlBotMode: opponent.mlPreset,
        };
    };
    return BotGenerator;
}());
