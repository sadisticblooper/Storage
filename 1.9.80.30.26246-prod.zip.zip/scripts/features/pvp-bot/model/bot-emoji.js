var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var BotEmoji = (function () {
    function BotEmoji() {
    }
    BotEmoji.getBotEmojiPreset = function (settings) {
        var defaultResult = {
            cooldownIntervalMs: 100,
            events: {},
        };
        for (var eventId in BOT_EMOJI_EVENTS)
            if (isNumber(eventId)) {
                defaultResult.events[eventId] = [{
                        emoji: { ID: -1 },
                        probability: 1,
                    }];
            }
        if (BotUtils.doPlayerKnowAboutBot(settings)) {
            return defaultResult;
        }
        var seed = CommonUtils.getRandomJSSeed();
        RandomInstance.setSeed(seed);
        var randomCol = new RandomCollection();
        for (var _i = 0, _a = botEmojiPresetsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var preset = botEmojiPresetsMap.get(id);
            randomCol.add(new CollectionObjectContainer(id, preset.weight));
        }
        var chosenPresetId = randomCol.next(RandomInstance).get();
        var chosenPreset = botEmojiPresetsMap.get(chosenPresetId);
        if (chosenPreset == null) {
            return defaultResult;
        }
        var emojiPool = [];
        var allowedIds = [];
        if (chosenPreset.emojiQuantityAnimated > 0) {
            for (var _b = 0, _c = emojiMap.getKeys(); _b < _c.length; _b++) {
                var emojiId = _c[_b];
                if (BotEmojiSettings[emojiId] != undefined) {
                    allowedIds.push(emojiId);
                }
            }
            var iterations = Math.min(chosenPreset.emojiQuantityAnimated, allowedIds.length);
            for (var i = 0; i < iterations; i++) {
                randomCol.clear();
                for (var _d = 0, allowedIds_1 = allowedIds; _d < allowedIds_1.length; _d++) {
                    var id = allowedIds_1[_d];
                    var sum = 0;
                    for (var eventId in BOT_EMOJI_EVENTS)
                        if (isNumber(eventId)) {
                            var emojiWeight = BotEmojiSettings[id][eventId] ? BotEmojiSettings[id][eventId] : 0;
                            var presetProb = chosenPreset.events[eventId] ? chosenPreset.events[eventId] : 0;
                            sum += emojiWeight * presetProb;
                        }
                    randomCol.add(new CollectionObjectContainer(id, sum));
                }
                if (randomCol.size() == 0) {
                    continue;
                }
                var chosenId = randomCol.next(RandomInstance).get();
                var index = allowedIds.indexOf(chosenId);
                allowedIds.splice(index, 1);
                emojiPool.push({
                    emoji: { ID: chosenId },
                    probability: 0,
                });
            }
        }
        if (chosenPreset.emojiQuantityText > 0) {
            var allowedIndexes = Object.keys(BotTextEmojiSettings).map(Number);
            var iterations = Math.min(chosenPreset.emojiQuantityText, allowedIndexes.length);
            for (var i = 0; i < iterations; i++) {
                randomCol.clear();
                for (var _e = 0, allowedIndexes_1 = allowedIndexes; _e < allowedIndexes_1.length; _e++) {
                    var index_1 = allowedIndexes_1[_e];
                    var sum = 0;
                    for (var eventId in BOT_EMOJI_EVENTS)
                        if (isNumber(eventId)) {
                            var emojiWeight = BotTextEmojiSettings[index_1][eventId] ? BotTextEmojiSettings[index_1][eventId] : 0;
                            var presetProb = chosenPreset.events[eventId] ? chosenPreset.events[eventId] : 0;
                            sum += emojiWeight * presetProb;
                        }
                    randomCol.add(new CollectionObjectContainer(index_1, sum));
                }
                if (randomCol.size() == 0) {
                    continue;
                }
                var chosenIndex = randomCol.next(RandomInstance).get();
                var index = allowedIds.indexOf(chosenIndex);
                allowedIndexes.splice(index, 1);
                emojiPool.push({
                    textTauntBubble: { index: chosenIndex },
                    probability: 0,
                });
            }
        }
        if (emojiPool.length == 0) {
            return defaultResult;
        }
        var result = {
            cooldownIntervalMs: chosenPreset.showCooldown,
            events: {},
        };
        for (var eventId in BOT_EMOJI_EVENTS)
            if (isNumber(eventId)) {
                if (chosenPreset.events[eventId]) {
                    result.events[eventId] = [{
                            emoji: { ID: -1 },
                            probability: 1 - chosenPreset.events[eventId],
                        }];
                    var sum = 0;
                    for (var _f = 0, emojiPool_1 = emojiPool; _f < emojiPool_1.length; _f++) {
                        var emoji_1 = emojiPool_1[_f];
                        var settingsPool = emoji_1.textTauntBubble != undefined
                            ? BotTextEmojiSettings[emoji_1.textTauntBubble.index]
                            : BotEmojiSettings[emoji_1.emoji.ID];
                        var weight = settingsPool[eventId] ? settingsPool[eventId] : 0;
                        sum += weight;
                    }
                    var coefficient = sum == 0 ? 0 : chosenPreset.events[eventId] / sum;
                    for (var _g = 0, emojiPool_2 = emojiPool; _g < emojiPool_2.length; _g++) {
                        var emoji_2 = emojiPool_2[_g];
                        var settingsPool = emoji_2.textTauntBubble != undefined
                            ? BotTextEmojiSettings[emoji_2.textTauntBubble.index]
                            : BotEmojiSettings[emoji_2.emoji.ID];
                        var tempProbability = (settingsPool[eventId] || 0) * coefficient;
                        result.events[eventId].push(__assign(__assign({}, emoji_2), { probability: tempProbability }));
                    }
                }
                else {
                    result.events[eventId] = defaultResult.events[eventId];
                }
            }
        return result;
    };
    return BotEmoji;
}());
