var PickerBot = (function () {
    function PickerBot() {
    }
    PickerBot.pickBotHero = function (botChoice) {
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        if (botChoice.heroes.length < 1 || botChoice.botHeroes.length < 1) {
            throw new Error("Length of player heroes or bot heroes is 0");
        }
        if (botChoice.botHeroes.length == 1) {
            return botChoice.botHeroes[0];
        }
        var botHeroes = botChoice.botHeroes;
        shuffle(botHeroes, rnd);
        return botHeroes[0];
    };
    return PickerBot;
}());
