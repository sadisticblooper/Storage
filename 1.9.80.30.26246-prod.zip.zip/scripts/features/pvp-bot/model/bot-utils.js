var BotUtils = (function () {
    function BotUtils() {
    }
    BotUtils.getAverageBotLevelsSettings = function (rating, rankRating, teamMode) {
        var table = CalculationRatingSettings.deltaRatingSettings[teamMode];
        var index = CommonGameUtils.getNumberIntervalIndex(rankRating, table);
        var averageSettings = table[index].items[0];
        return {
            averageBotLevels: {
                AvgAccountLevel: averageSettings.accountLevel,
                AvgHeroLevel: averageSettings.maxHeroLevel,
            },
        };
    };
    BotUtils.doPlayerKnowAboutBot = function (matchingInfo) {
        return matchingInfo.enemyMode == ENEMY_MODE.COMMON_BOT;
    };
    BotUtils.replaceSkin = function (warriors, warriorSkins) {
        for (var _i = 0, warriors_1 = warriors; _i < warriors_1.length; _i++) {
            var warrior = warriors_1[_i];
            if (warriorSkins[warrior.heroID] != undefined) {
                warrior.skinID = warriorSkins[warrior.heroID];
            }
        }
    };
    BotUtils.setDefaultSkinWeapons = function (warriors, excludeHeroes) {
        for (var _i = 0, warriors_2 = warriors; _i < warriors_2.length; _i++) {
            var warrior = warriors_2[_i];
            if (excludeHeroes && excludeHeroes.indexOf(warrior.heroID) > -1) {
                continue;
            }
            this.setDefaultSkinWeapon(warrior);
        }
    };
    BotUtils.setDefaultSkinWeapon = function (warrior) {
        var skinId = warrior.skinID
            ? warrior.skinID
            : heroesMap.checkedGet(warrior.heroID).DefaultSkinId;
        var skin = skinsMap.checkedGet(skinId);
        warrior.weaponId = skin.WeaponId;
    };
    BotUtils.setDefaultCommonWeapons = function (warriors, excludeHeroes) {
        for (var _i = 0, warriors_3 = warriors; _i < warriors_3.length; _i++) {
            var warrior = warriors_3[_i];
            if (excludeHeroes && excludeHeroes.indexOf(warrior.heroID) > -1) {
                continue;
            }
            var hero = heroesMap.checkedGet(warrior.heroID);
            var skinId = warrior.skinID || heroesMap.checkedGet(warrior.heroID).DefaultSkinId;
            warrior.weaponId = hero.getCommonWeaponIfNotSelected(skinId);
        }
    };
    BotUtils.generateFightID = function (settings) {
        var currentServerTime = settings.currentServerTime, playerID = settings.playerID, shard = settings.shard, matchingInfo = settings.matchingInfo, botId = settings.botId;
        var emptyResult = { fightId: "", botId: "" };
        if (BotUtils.doPlayerKnowAboutBot(settings.matchingInfo) || matchingInfo.mode == FIGHT_MODE.LOCAL_PVP_FRIEND) {
            return emptyResult;
        }
        if (!botId) {
            var id = ((Math.sin(currentServerTime) + 1) / 3 + 1 / 3)
                * (Math.pow(10, ((6.5 + Math.sin(currentServerTime) * 1.5) >> 0))) >> 0;
            id = id != playerID ? id : playerID + 1;
            botId = id.toString();
        }
        return {
            fightId: "".concat(shard, "-").concat(currentServerTime, "-").concat(playerID, "-").concat(botId),
            botId: botId,
        };
    };
    BotUtils.calcAutobotRematch = function (settings) {
        var settingsForForceBotByTimeout = AutoBotSettings.autoBotByTimeout[settings.mode];
        var tableIndex = CommonGameUtils.getNumberIntervalIndex(settings.rating, settingsForForceBotByTimeout);
        var timeoutSettings = settingsForForceBotByTimeout[tableIndex];
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        var duration = MatchingConstants.rematchAutobotDecision.end;
        var randomDecision = rnd.nextInt(100) <= BotConstants.rematchBotSettings.autobotRematchChance * 100;
        var randomDuration = Math.max(MatchingConstants.rematchAutobotDecision.start, rnd.nextInt(duration));
        return {
            isAccepted: !!timeoutSettings.items && randomDecision,
            delayBeforeDecision: randomDuration,
        };
    };
    BotUtils.getTimeoutBeforeMatchStart = function () {
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        return BotConstants.rematchBotSettings.botTimeoutSecondsBeforeMatchStart.getRandomValue(rnd) * 1000;
    };
    return BotUtils;
}());
