var _a, _b, _c, _d, _e;
var BotConstants = (function () {
    function BotConstants() {
    }
    BotConstants.botsPoolSize = 10;
    BotConstants.recentEnemiesCount = 5;
    BotConstants.defaultAiMode = AI_MODE.AI_PRESET_5;
    BotConstants.defaultMLSettings = {
        isMlBotEnable: true,
        defaultMLMode: MLBOT_MODE.PRESET_1,
        noMlHeroesIds: []
    };
    BotConstants.rankRatingDeviationAtRatingForBotsPool = [
        { range: { start: 0, end: 599 }, items: ["5"] },
        { range: { start: 600, end: 99999 }, items: ["30"] },
    ];
    BotConstants.powerDeviationAtRatingForBotsPool = [
        { range: { start: 0, end: 199 }, items: ["5%"] },
        { range: { start: 200, end: 499 }, items: ["5%"] },
        { range: { start: 500, end: 599 }, items: ["5%"] },
        { range: { start: 600, end: 1399 }, items: ["10%"] },
        { range: { start: 1400, end: 1799 }, items: ["10%"] },
        { range: { start: 1800, end: 2199 }, items: ["10%"] },
        { range: { start: 2200, end: 2599 }, items: ["10%"] },
        { range: { start: 2600, end: 2999 }, items: ["15%"] },
        { range: { start: 3000, end: 3399 }, items: ["15%"] },
        { range: { start: 3400, end: 4999 }, items: ["15%"] },
        { range: { start: 5000, end: 5999 }, items: ["15%"] },
        { range: { start: 6000, end: 6499 }, items: ["15%"] },
        { range: { start: 6500, end: 7000 }, items: ["15%"] },
    ];
    BotConstants.BotPoolNames = [
        'NICKDRAG', 'DRSPACELOVE', 'FALLENCOIN', 'TROUBLEMAKER', 'MINIONLOVER', 'SASHA', 'DRSTRANGE', 'DRAGONFIGHT',
        'FIGHTOCTOBER', 'MASTER OKADA', 'SHIBATA', 'DENG RAO', 'GIZMO', 'GALEN', 'CAPITAN PHANG', 'AMBASSADOR', 'GRETA',
        'ALEXANDER HOME', 'MOIRA', 'QUEEN IOLANDA', 'XIANG TZU', 'MASTER BOLO', 'KITSUNE-1', 'MAY', 'NANAMI',
        'EMISSARY WEI', 'ARBITER', 'UNKLE NAGIL', 'URSUS THE IMMORTAL', 'MIDNIGHT LOTUS', 'FANGIRL', 'VAMPIRE LORD',
        'JAIL KEEPER', 'DRAGON MENTOR', 'SWAMPER', 'RED LION', 'WARMONGER', 'SEIGFRIED', 'NIGHT WARRIOR',
        'GUARDIAN DRAGON', 'GENERAL TAO', 'IMPOSTER', 'USURPER', 'ORCHID', 'FUTURE KEEPER', 'THE DIVINE JUDGE', 'MNEMOS',
        'CLAW THE SPECTRE', 'ADA', 'OCTOPUS', 'TIBERIUS', 'SIR REINHARD', 'CRUSHER', 'PHANTASM', 'HIVE', 'SPECTRE',
        'MOTH', 'ELDER',
    ];
    BotConstants.ChanceHeroLevelDefault = (_a = {},
        _a[HERO_RARITY.COMMON] = { "-2": 1, "-1": 1, "0": 1, "1": 1, "2": 1, },
        _a[HERO_RARITY.RARE] = { "-2": 1, "-1": 1, "0": 1, "1": 1, "2": 1, },
        _a[HERO_RARITY.EPIC] = { "-2": 1, "-1": 1, "0": 1, "1": 1, "2": 1, },
        _a[HERO_RARITY.LEGENDARY] = { "-2": 1, "-1": 1, "0": 1, "1": 1, "2": 1, },
        _a);
    BotConstants.ChanceHeroLevelUnranked = (_b = {},
        _b[HERO_RARITY.COMMON] = { "-2": 0, "-1": 0, "0": 0.3, "1": 0.5, "2": 0.2, },
        _b[HERO_RARITY.RARE] = { "-2": 0.3, "-1": 0.5, "0": 0.2, "1": 0, "2": 0, },
        _b[HERO_RARITY.EPIC] = { "-2": 0.7, "-1": 0.3, "0": 0, "1": 0, "2": 0, },
        _b[HERO_RARITY.LEGENDARY] = { "-2": 0.7, "-1": 0.3, "0": 0, "1": 0, "2": 0, },
        _b);
    BotConstants.mlBotDifficultiesByRankRating = (_c = {},
        _c[TEAM_MODE._1_VS_1_] = (_d = {},
            _d[BOT_TYPE_FOR_ML_SETTINGS.RANKED] = [
                { range: { start: 0, end: 49 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 50, end: 99 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 100, end: 149 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 150, end: 199 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 200, end: 299 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 300, end: 399 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 400, end: 499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 500, end: 599 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 600, end: 699 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 700, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _d[BOT_TYPE_FOR_ML_SETTINGS.COMMON_BOT_RANKED] = [
                { range: { start: 0, end: 49 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 50, end: 99 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 100, end: 149 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 150, end: 199 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 200, end: 299 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 300, end: 399 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 400, end: 499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 500, end: 599 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 600, end: 699 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 700, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _d[BOT_TYPE_FOR_ML_SETTINGS.UNRANKED] = [
                { range: { start: 0, end: 49 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 50, end: 99 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 100, end: 149 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 150, end: 199 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 200, end: 299 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 300, end: 399 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 400, end: 499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 500, end: 599 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 600, end: 699 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 700, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _d),
        _c[TEAM_MODE._3_VS_3_] = (_e = {},
            _e[BOT_TYPE_FOR_ML_SETTINGS.RANKED] = [
                { range: { start: 0, end: 149 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 150, end: 299 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 300, end: 449 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 450, end: 599 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 600, end: 899 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 900, end: 1199 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 1200, end: 1499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 1500, end: 1799 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 1800, end: 2099 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 2100, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _e[BOT_TYPE_FOR_ML_SETTINGS.COMMON_BOT_RANKED] = [
                { range: { start: 0, end: 149 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 150, end: 299 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 300, end: 449 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 450, end: 599 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 600, end: 899 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 900, end: 1199 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 1200, end: 1499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 1500, end: 1799 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 1800, end: 2099 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 2100, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _e[BOT_TYPE_FOR_ML_SETTINGS.UNRANKED] = [
                { range: { start: 0, end: 149 }, items: [MLBOT_MODE.PRESET_1] },
                { range: { start: 150, end: 299 }, items: [MLBOT_MODE.PRESET_2] },
                { range: { start: 300, end: 449 }, items: [MLBOT_MODE.PRESET_3] },
                { range: { start: 450, end: 599 }, items: [MLBOT_MODE.PRESET_4] },
                { range: { start: 600, end: 899 }, items: [MLBOT_MODE.PRESET_5] },
                { range: { start: 900, end: 1199 }, items: [MLBOT_MODE.PRESET_6] },
                { range: { start: 1200, end: 1499 }, items: [MLBOT_MODE.PRESET_7] },
                { range: { start: 1500, end: 1799 }, items: [MLBOT_MODE.PRESET_8] },
                { range: { start: 1800, end: 2099 }, items: [MLBOT_MODE.PRESET_9] },
                { range: { start: 2100, end: 10000 }, items: [MLBOT_MODE.PRESET_10] },
            ],
            _e),
        _c);
    BotConstants.commonMLBotPresets = [
        MLBOT_MODE.PRESET_1,
        MLBOT_MODE.PRESET_2,
        MLBOT_MODE.PRESET_3,
        MLBOT_MODE.PRESET_4,
        MLBOT_MODE.PRESET_5,
        MLBOT_MODE.PRESET_6,
        MLBOT_MODE.PRESET_7,
        MLBOT_MODE.PRESET_8,
        MLBOT_MODE.PRESET_9,
        MLBOT_MODE.PRESET_10,
    ];
    BotConstants.firstMatchesOpponents = [
        { hid: heroes.Kibo.ID, level: 3, talents: 0, mlPreset: MLBOT_MODE.PRESET_3, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Helga.ID, level: 2, talents: 0, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Ironclad.ID, level: 2, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Liquidator.ID, level: 4, talents: 0, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Monk.ID, level: 3, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Helga.ID, level: 3, talents: 0, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Liquidator.ID, level: 3, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Kibo.ID, level: 4, talents: 0, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Ironclad.ID, level: 3, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Ling.ID, level: 3, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
        { hid: heroes.Monkey_King.ID, level: 4, talents: 1, mlPreset: MLBOT_MODE.PRESET_1, aiPreset: AI_MODE.AI_PRESET_5 },
    ];
    BotConstants.rematchBotSettings = {
        defeatBotDelayTime: new Time({ Seconds: 15 }).value,
        autobotRematchChance: 0.7,
        autobotRematchTimes: 1,
        botTimeoutSecondsBeforeMatchStart: new RndFromInterval(4, 8),
        displayQuitAfterTime: new Time({ Seconds: 15 }).value,
    };
    return BotConstants;
}());
