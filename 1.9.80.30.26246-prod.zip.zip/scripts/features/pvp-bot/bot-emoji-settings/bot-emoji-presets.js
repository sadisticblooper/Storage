var _a;
var botEmojiPresets = {
    preset1: {
        ID: 1,
        weight: 1,
        events: (_a = {},
            _a[BOT_EMOJI_EVENTS.GREETING] = 0.85,
            _a[BOT_EMOJI_EVENTS.FAREWELL] = 0.5,
            _a[BOT_EMOJI_EVENTS.TURTLING] = 0.35,
            _a[BOT_EMOJI_EVENTS.DEALING_DAMAGE] = 0.07,
            _a[BOT_EMOJI_EVENTS.ANSWER] = 0.3,
            _a[BOT_EMOJI_EVENTS.ROUND_END] = 0.5,
            _a),
        showCooldown: 15000,
        emojiQuantityAnimated: 8,
        emojiQuantityText: 6,
    },
};
var botEmojiPresetsMap = createIDMap(botEmojiPresets, "botEmojiPresetsMap");
