function buildBrawlerSearchBounds(settings) {
    return BotBrawler.buildBrawlerSearchBounds(settings);
}
function calcMatchingPower(settings) {
    return BotBrawler.calcMatchingPower(settings);
}
function pickBotHero(iBotChoice) {
    return PickerBot.pickBotHero(iBotChoice);
}
function getBotAccount(botGeneratorSettings) {
    return BotGenerator.getBotAccount(botGeneratorSettings);
}
function getRankedBotTooltipInfo(p) {
    return BotGenerator.getRankedBotTooltipInfo(p);
}
function generateFightID(settings) {
    return BotUtils.generateFightID(settings);
}
function getBotEmojiPreset(settings) {
    return BotEmoji.getBotEmojiPreset(settings);
}
function calcAutobotRematch(settings) {
    return BotUtils.calcAutobotRematch(settings);
}
function getTimeoutBeforeMatchStart() {
    return BotUtils.getTimeoutBeforeMatchStart();
}
function getDisplayQuitAfterTime() {
    return BotConstants.rematchBotSettings.displayQuitAfterTime;
}
