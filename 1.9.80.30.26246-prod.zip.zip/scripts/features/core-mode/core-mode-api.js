function is3vs3Available(settings) {
    return CoreMode.is3vs3Available(settings);
}
function getLootWithMissingHeroesFor3vs3(settings) {
    return CoreMode.getLootWithMissingHeroesFor3vs3(settings);
}
