var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var CoreMode = (function () {
    function CoreMode() {
    }
    CoreMode.is3vs3Available = function (settings) {
        var maxPlayerRating = settings.maxPlayerRating;
        return maxPlayerRating >= CoreModeConstants.rating3vs3ModeUnlock;
    };
    CoreMode.getLootWithMissingHeroesFor3vs3 = function (settings) {
        var neededQuantity = getFightConstants(TEAM_MODE._3_VS_3_).formationsCountLimit;
        var playerHeroIds = [];
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var heroId = id.toString();
            if (settings.heroes[heroId] != undefined) {
                playerHeroIds.push(id);
            }
        }
        if (playerHeroIds.length >= neededQuantity) {
            return null;
        }
        var shardSettings = {};
        var heroesWithPriority = __spreadArray([
            heroes.Liquidator.ID,
            heroes.Ironclad.ID
        ], heroesMap.getKeys(), true);
        for (var _b = 0, heroesWithPriority_1 = heroesWithPriority; _b < heroesWithPriority_1.length; _b++) {
            var id = heroesWithPriority_1[_b];
            if (playerHeroIds.indexOf(id) == -1) {
                var hero = heroesMap.get(id);
                playerHeroIds.push(id);
                shardSettings[id] = hero.ShardsNeeded;
                if (playerHeroIds.length >= neededQuantity) {
                    break;
                }
            }
        }
        return new Loot({ Shards: shardSettings });
    };
    CoreMode.check = function () {
        for (var mode in TEAM_MODE)
            if (isNumber(mode)) {
                var modeName = TEAM_MODE[mode];
                if (!MatchingConstants.matchingZones[mode]) {
                    throw new Error("You must add settings in matchingZones for mode ".concat(modeName));
                }
                if (!MatchingConstants.timeFindOpponentsByRating[mode]) {
                    throw new Error("You must add settings in timeFindOpponentsByRating for mode ".concat(modeName));
                }
                if (!MatchingConstants.matchmakingShowBotByRating[mode]) {
                    throw new Error("You must add settings in matchmakingShowBotByRating for mode ".concat(modeName));
                }
                if (!FightConstants.maxWinRounds[mode]) {
                    throw new Error("You must add settings in maxWinRounds for mode ".concat(modeName));
                }
                if (!FightConstants.formationsCountLimit[mode]) {
                    throw new Error("You must add settings in formationsCountLimit for mode ".concat(modeName));
                }
                var levelsInfo = getRankRanges(+mode);
                if (!levelsInfo) {
                    throw new Error("You must add levels info in coreModeRanks for mode ".concat(modeName));
                }
                var levels = Object.keys(levelsInfo).length;
                for (var i = 1; i <= levels; i++) {
                    if (!levelsInfo[i]) {
                        throw new Error("You must add info about ".concat(i, " level in coreModeRanks for mode ").concat(modeName));
                    }
                }
            }
    };
    return CoreMode;
}());
