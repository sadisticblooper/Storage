var CoreModeConstants = (function () {
    function CoreModeConstants() {
    }
    CoreModeConstants.rating3vs3ModeUnlock = ArenaConstants.arenaFeatures[ARENA_FEATURE.TEAM_MODES].rating;
    CoreModeConstants.ratingToCheckHeroQuantityFor3vs3 = CoreModeConstants.rating3vs3ModeUnlock - 20;
    return CoreModeConstants;
}());
