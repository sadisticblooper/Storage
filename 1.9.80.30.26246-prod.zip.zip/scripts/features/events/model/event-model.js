var SeasonalEvent = (function () {
    function SeasonalEvent(settings) {
        this.ID = settings.ID;
        this.startTime = settings.startTime;
        this.endTime = settings.endTime;
        this.processCurrencies(settings);
        this.activities = settings.activities;
        this.visualConfig = settings.visualConfig;
        this.currencyGroupConfig = settings.currencyGroupConfig;
    }
    SeasonalEvent.prototype.processCurrencies = function (settings) {
        this.eventCurrencies = [];
        this.eventCurrenciesToCurrencies = settings.eventCurrenciesToCurrencies;
        this.currenciesToEventCurrencies = {};
        for (var eventCurrency in this.eventCurrenciesToCurrencies) {
            var currency = this.eventCurrenciesToCurrencies[eventCurrency];
            this.eventCurrencies.push(currency);
            if (this.currenciesToEventCurrencies[currency]) {
                throw new Error("Seasonal event ".concat(this.ID, ": repeat of event currency ").concat(currency, " in \n                    \r ").concat(eventCurrency, " and ").concat(this.currenciesToEventCurrencies[currency]));
            }
            this.currenciesToEventCurrencies[currency] = eventCurrency;
        }
    };
    SeasonalEvent.prototype.check = function (serverTime) {
        var skip = [53];
        if (skip.indexOf(this.ID) > -1) {
            return;
        }
        if (serverTime > this.endTime) {
            return;
        }
        if (this.visualConfig == null) {
            throw "Visual config of event ".concat(this.ID, " is empty!");
        }
        if (this.endTime <= this.startTime) {
            throw new Error("Seasonal event ".concat(this.ID, ": end time <= start time"));
        }
        {
            for (var _i = 0, _a = this.activities.roulette; _i < _a.length; _i++) {
                var id = _a[_i];
                var roulette_1 = rouletteMap.get(id);
                if (!roulette_1) {
                    throw new Error("Seasonal event ".concat(this.ID, ": there is no roulette with id ").concat(id));
                }
                var prices = roulette_1.settings.singleRoll
                    && roulette_1.settings.singleRoll.prices.map(function (p) { return p.currency; }).filter(function (c) { return !!c; })
                    || [];
                if (roulette_1.settings.multipleRoll && roulette_1.settings.multipleRoll.price.currency) {
                    prices.push(roulette_1.settings.multipleRoll.price.currency);
                }
                for (var _b = 0, prices_1 = prices; _b < prices_1.length; _b++) {
                    var price = prices_1[_b];
                    if (SeasonalEventUtils
                        .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, Object.keys(price).map(Number))) {
                        throw new Error("Seasonal event ".concat(this.ID, ": \n                                \rroulette ").concat(id, " has incorrect price"));
                    }
                }
                var rewards = [];
                for (var _c = 0, _d = roulette_1.settings.slots; _c < _d.length; _c++) {
                    var slot = _d[_c];
                    rewards = rewards.concat(slot.rewards);
                }
                if (roulette_1.settings.bonusSlot) {
                    for (var _e = 0, _f = roulette_1.settings.bonusSlot.queue; _e < _f.length; _e++) {
                        var bonus = _f[_e];
                        rewards.push(bonus.reward);
                    }
                }
                if (roulette_1.settings.finalSlot) {
                    rewards.push(roulette_1.settings.finalSlot.reward);
                }
                for (var _g = 0, rewards_1 = rewards; _g < rewards_1.length; _g++) {
                    var reward = rewards_1[_g];
                    if (SeasonalEventUtils
                        .hasWrongCurrenciesInRewardContent(this.eventCurrencies, reward)) {
                        throw new Error("Seasonal event ".concat(this.ID, ": roulette ").concat(id, " has incorrect rewards currency"));
                    }
                }
            }
            for (var _h = 0, _j = this.activities.tournamentGroups; _h < _j.length; _h++) {
                var group = _j[_h];
                if (!group.isLifetimeBounds()) {
                    throw new Error("Seasonal event ".concat(this.ID, ": \n                            \rtournament group ").concat(group.ID, " must has active time in Start/End format"));
                }
                for (var _k = 0, _l = group.getTournaments(); _k < _l.length; _k++) {
                    var tournament = _l[_k];
                    if (!tournament) {
                        throw new Error("Seasonal event ".concat(this.ID, ": there is no tournament with id ").concat(tournament.ID));
                    }
                    if (tournament.Settings.TournamentGroup.Settings.EndDate > this.endTime
                        || tournament.Settings.TournamentGroup.Settings.StartDate < this.startTime) {
                        throw new Error("Seasonal event ".concat(this.ID, ": \n                            \rtournament ").concat(tournament.ID, " must has active time such as event time"));
                    }
                    var prices = tournament.Settings.Prices.slice();
                    for (var _m = 0, prices_2 = prices; _m < prices_2.length; _m++) {
                        var price = prices_2[_m];
                        if (SeasonalEventUtils
                            .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, Object.keys(price).map(Number))) {
                            throw new Error("Seasonal event ".concat(this.ID, ": \n                                \rtournament ").concat(tournament.ID, " has incorrect price"));
                        }
                    }
                    var rewardSettings = tournament.Settings.Rewards;
                    for (var _o = 0, _p = rewardSettings.loseRewards; _o < _p.length; _o++) {
                        var loseReward = _p[_o];
                        if (SeasonalEventUtils
                            .hasWrongCurrenciesInRewardContent(this.eventCurrencies, loseReward.reward)) {
                            throw new Error("Seasonal event ".concat(this.ID, ": \n                                        \rtournament ").concat(tournament.ID, " has incorrect rewards currency for loss"));
                        }
                    }
                    for (var stage in rewardSettings.rewards) {
                        var lines = ["repeatable", "onetime"];
                        for (var _q = 0, lines_1 = lines; _q < lines_1.length; _q++) {
                            var line = lines_1[_q];
                            var rewardContent = rewardSettings.rewards[+stage][line];
                            if (SeasonalEventUtils
                                .hasWrongCurrenciesInRewardContent(this.eventCurrencies, rewardContent)) {
                                throw new Error("Seasonal event ".concat(this.ID, ": \n                                        \rtournament ").concat(tournament.ID, " has incorrect rewards currency: \n                                        \rstage ").concat(stage, ", line: ").concat(line));
                            }
                        }
                    }
                }
            }
            for (var _r = 0, _s = this.activities.marathons; _r < _s.length; _r++) {
                var id = _s[_r];
                var marathon = MarathonsMap.get(id);
                if (!marathon) {
                    throw new Error("Seasonal event ".concat(this.ID, ": there is no marathon with id ").concat(id));
                }
                var offer = marathon.getPromoOffer();
                var endBound = offer._activeTime.endGenerationBound;
                var startBound = offer._activeTime.startGenerationBound;
                var duration = offer._activeTime.duration ? offer._activeTime.duration : 0;
                if (!endBound || endBound > this.endTime) {
                    throw new Error("Seasonal event ".concat(this.ID, ": \n                        \rmarathon ").concat(id, " must has endGenerationBound <= ").concat(this.endTime));
                }
                if (endBound + duration > this.endTime) {
                    throw new Error("Seasonal event ".concat(this.ID, ": \n                        \rmarathon ").concat(id, " must has endGenerationBound + duration <= ").concat(this.endTime));
                }
                if (startBound && startBound < this.startTime) {
                    throw new Error("Seasonal event ".concat(this.ID, ": \n                        \rmarathon ").concat(id, " must has startGenerationBound > ").concat(this.startTime));
                }
                for (var stage in marathon.Rewards) {
                    if (SeasonalEventUtils
                        .hasWrongCurrenciesInRewardContent(this.eventCurrencies, marathon.Rewards[+stage])) {
                        throw new Error("Seasonal event ".concat(this.ID, ": marathon ").concat(id, " has incorrect rewards currency"));
                    }
                }
            }
            var _loop_1 = function (id) {
                var offer = offersMap.get(id);
                if (!offer) {
                    throw new Error("Seasonal event ".concat(this_1.ID, ": there is no offer with id ").concat(id));
                }
                var startBound = offer._activeTime.startGenerationBound;
                if (startBound && startBound < this_1.startTime) {
                    throw new Error("Seasonal event ".concat(this_1.ID, ": \n                        \roffer ").concat(id, " must has startGenerationBound > ").concat(this_1.startTime));
                }
                if (offer.price) {
                    if (SeasonalEventUtils
                        .hasCurrenciesDifferentEventCurrency(this_1.eventCurrencies, Object.keys(offer.price).map(Number))) {
                        throw new Error("Seasonal event ".concat(this_1.ID, ": \n                                \roffer ").concat(id, " has incorrect price"));
                    }
                }
                var rewards = [];
                offer.lootSlotsIterator(function (variants) {
                    for (var _i = 0, variants_1 = variants; _i < variants_1.length; _i++) {
                        var variant = variants_1[_i];
                        rewards.push(variant.item);
                        if (variant.item.arenas) {
                            for (var arena in variant.item.arenas) {
                                rewards.push(variant.item.arenas[arena]);
                            }
                        }
                    }
                });
                for (var _7 = 0, rewards_2 = rewards; _7 < rewards_2.length; _7++) {
                    var reward = rewards_2[_7];
                    if (SeasonalEventUtils
                        .hasWrongCurrenciesInRewardContent(this_1.eventCurrencies, reward)) {
                        throw new Error("Seasonal event ".concat(this_1.ID, ": offer ").concat(id, " has incorrect rewards currency"));
                    }
                }
            };
            var this_1 = this;
            for (var _t = 0, _u = this.activities.offers; _t < _u.length; _t++) {
                var id = _u[_t];
                _loop_1(id);
            }
            {
                var aggregator = EventQuestsAggregatorMap.get(this.activities.questsAggregator);
                if (aggregator) {
                    for (var _v = 0, _w = aggregator.startTimes; _v < _w.length; _v++) {
                        var time = _w[_v];
                        if (time < this.startTime || time > this.endTime) {
                            throw new Error("Seasonal event ".concat(this.ID, ": \n                                \rquest aggregator ").concat(aggregator.ID, " must has active time such as event time"));
                        }
                    }
                }
                for (var _x = 0, _y = aggregator.getAllQuests(); _x < _y.length; _x++) {
                    var quest = _y[_x];
                    if (quest.RewardsSettings == undefined) {
                        continue;
                    }
                    var questEventCurrencies = [];
                    for (var _z = 0, _0 = quest.RewardsSettings; _z < _0.length; _z++) {
                        var rs = _0[_z];
                        var reward = rs.LootReward
                            ? rs.LootReward
                            : QuestConstants.eventDifficulties.indexOf(rs.Difficulty) > -1
                                ? QuestConstants.questsDifficultCapacity[rs.Difficulty]
                                : new Loot();
                        questEventCurrencies = questEventCurrencies.concat(reward.getNotEmptyCurrencies());
                    }
                    if (SeasonalEventUtils.hasCurrenciesDifferentEventCurrency(this.eventCurrencies, questEventCurrencies)) {
                        throw new Error("Seasonal event ".concat(this.ID, ": current quest [").concat(quest.ID, "] ")
                            + "difficulties has incorrect reward");
                    }
                }
            }
            {
                var eventShop = seasonalEventShopsMap.get(this.activities.shop);
                if (eventShop) {
                    var slotNumber = 0;
                    for (var _1 = 0, _2 = eventShop.slots; _1 < _2.length; _1++) {
                        var slot = _2[_1];
                        var variants = slot.length;
                        var currentVariant = 0;
                        for (var _3 = 0, slot_1 = slot; _3 < slot_1.length; _3++) {
                            var variant = slot_1[_3];
                            var place = "Seasonal event ".concat(this.ID, ": shop ").concat(eventShop.ID, ", ")
                                + "slot: ".concat(slotNumber, ", variant: ").concat(currentVariant, ".");
                            if (variant.expireTime &&
                                (variant.expireTime < this.startTime || variant.expireTime > this.endTime)) {
                                throw new Error("".concat(place, " Check times for offers."));
                            }
                            if (currentVariant < variants - 1 && !variant.expireTime) {
                                throw new Error("".concat(place, " If slot has several variants they must have expireTime"));
                            }
                            if (currentVariant == variants - 1) {
                                if (variant.expireTime && variant.expireTime != this.endTime) {
                                    throw new Error("".concat(place, " Expire time of offer must be equal for time of event end"));
                                }
                            }
                            if (variant.replaceSettings) {
                                var prices = [];
                                if (variant.replaceSettings.fixed && variant.replaceSettings.fixed.fixedPrice) {
                                    prices.push(variant.replaceSettings.fixed.fixedPrice);
                                }
                                if (variant.replaceSettings.random && variant.replaceSettings.random.fixedPrice) {
                                    prices.push(variant.replaceSettings.random.fixedPrice);
                                }
                                for (var _4 = 0, prices_3 = prices; _4 < prices_3.length; _4++) {
                                    var price = prices_3[_4];
                                    if (SeasonalEventUtils
                                        .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, Object.keys(price).map(Number))) {
                                        throw new Error("".concat(place, " incorrect price"));
                                    }
                                }
                            }
                            if (variant.shopOffer.FixedPrice) {
                                if (SeasonalEventUtils
                                    .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, Object.keys(variant.shopOffer.FixedPrice).map(Number))) {
                                    throw new Error("".concat(place, " incorrect price"));
                                }
                            }
                            if (variant.shopOffer.FixedLoot) {
                                if (SeasonalEventUtils
                                    .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, variant.shopOffer.FixedLoot.getNotEmptyCurrencies())) {
                                    throw new Error("".concat(place, " incorrect price"));
                                }
                            }
                            if (variant.shopOffer.SlotVariants) {
                                for (var _5 = 0, _6 = variant.shopOffer.SlotVariants; _5 < _6.length; _5++) {
                                    var shopSlotVariant = _6[_5];
                                    var curs = [];
                                    if (shopSlotVariant.CurrencyRewardType) {
                                        curs.push(shopSlotVariant.CurrencyRewardType);
                                    }
                                    if (shopSlotVariant.CurrencyType) {
                                        curs.push(shopSlotVariant.CurrencyType);
                                    }
                                    if (SeasonalEventUtils
                                        .hasCurrenciesDifferentEventCurrency(this.eventCurrencies, curs)) {
                                        throw new Error("".concat(place, " incorrect shop offer reward"));
                                    }
                                }
                            }
                            currentVariant++;
                        }
                        slotNumber++;
                    }
                    this.checkEventWeaponsAndSkinsInRandomDrop(eventShop);
                }
            }
        }
    };
    SeasonalEvent.prototype.checkEventWeaponsAndSkinsInRandomDrop = function (eventShop) {
        var weapons = [];
        var skins = [];
        for (var _i = 0, _a = eventShop.slots; _i < _a.length; _i++) {
            var slot = _a[_i];
            for (var _b = 0, slot_2 = slot; _b < slot_2.length; _b++) {
                var variant = slot_2[_b];
                var fixedLoot = variant.shopOffer.FixedLoot;
                if (fixedLoot) {
                    skins.push.apply(skins, fixedLoot.HeroSkins);
                    weapons.push.apply(weapons, fixedLoot.Weapons);
                }
                if (variant.replaceSettings && variant.replaceSettings.fixed) {
                    var replaceFixedLoot = variant.replaceSettings.fixed.fixedLoot;
                    if (replaceFixedLoot) {
                        skins.push.apply(skins, replaceFixedLoot.HeroSkins);
                        weapons.push.apply(weapons, replaceFixedLoot.Weapons);
                    }
                }
            }
        }
        for (var _c = 0, weapons_1 = weapons; _c < weapons_1.length; _c++) {
            var id = weapons_1[_c];
            if (WeaponConstants.availableWeaponsForRandomGeneration.indexOf(id) != -1) {
                throw new Error("Weapon ".concat(id, " is presented in random generation and in event ").concat(this.ID, ": shop ").concat(eventShop.ID));
            }
        }
        for (var _d = 0, skins_1 = skins; _d < skins_1.length; _d++) {
            var id = skins_1[_d];
            if (SkinConstants.availableSkinsForRandomGeneration.indexOf(id) != -1) {
                throw new Error("Skin ".concat(id, " is presented in random generation and in event ").concat(this.ID, ": shop ").concat(eventShop.ID));
            }
        }
    };
    return SeasonalEvent;
}());
