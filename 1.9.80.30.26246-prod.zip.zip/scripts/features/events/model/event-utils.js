var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var SeasonalEventUtils = (function () {
    function SeasonalEventUtils() {
    }
    SeasonalEventUtils.getActiveSeasonalEventsByServerTime = function (serverTime) {
        var result = [];
        for (var _i = 0, _a = seasonalEventsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var event_1 = seasonalEventsMap.get(id);
            if (serverTime >= event_1.startTime && serverTime <= event_1.endTime) {
                result.push(id);
            }
        }
        return result;
    };
    SeasonalEventUtils.getTimeLeftToNextEvent = function (serverTime) {
        var nextEventStartTime;
        for (var _i = 0, _a = seasonalEventsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var event_2 = seasonalEventsMap.get(id);
            if (serverTime <= event_2.startTime) {
                nextEventStartTime = event_2.startTime;
                return nextEventStartTime;
            }
        }
        if (nextEventStartTime == undefined) {
            return null;
        }
    };
    SeasonalEventUtils.getConvertedSeasonalEventCurrencies = function (settings) {
        var result = {};
        var accrual = {};
        var withdraw = {};
        var wasWithdraw = false;
        var wasAccrual = false;
        for (var currency in CURRENCY)
            if (isNumber(currency)) {
                if (settings.eventCurrencies[currency] != undefined) {
                    var currSettings = currencySettings[currency];
                    if (currSettings) {
                        if (isNumber(currSettings.convertRateAtSeasonEnd)) {
                            var rate = currSettings.convertRateAtSeasonEnd;
                            var actualValue = settings.eventCurrencies[currency];
                            var newValue = (rate * actualValue) >> 0;
                            if (newValue > actualValue) {
                                wasAccrual = true;
                                accrual[currency] = (newValue - actualValue);
                            }
                            else if (newValue < actualValue) {
                                wasWithdraw = true;
                                withdraw[currency] = (actualValue - newValue);
                            }
                        }
                    }
                }
            }
        if (wasWithdraw) {
            result.withdraw = withdraw;
        }
        if (wasAccrual) {
            result.loot = new Loot({ Currencies: accrual });
        }
        return result;
    };
    SeasonalEventUtils.getTimeOfUpdateEventQuests = function (settings) {
        var seasonalEvent = seasonalEventsMap.get(settings.seasonalEventID);
        if (!seasonalEvent) {
            return null;
        }
        var result = 0;
        var aggregator = EventQuestsAggregatorMap.get(seasonalEvent.activities.questsAggregator);
        if (aggregator) {
            for (var _i = 0, _a = aggregator.startTimes; _i < _a.length; _i++) {
                var time = _a[_i];
                if (time > settings.serverTime) {
                    result = time;
                    break;
                }
            }
        }
        return result;
    };
    SeasonalEventUtils.getEventVisualSettings = function (eventId) {
        var event = seasonalEventsMap.get(eventId);
        if (!event) {
            return null;
        }
        var popups = [];
        for (var _i = 0, _a = event.visualConfig.popups; _i < _a.length; _i++) {
            var popup = _a[_i];
            popups.push(+CommonPopUpUtils.getActivityPopupId(popup.data.ID, 0));
        }
        return __assign(__assign({}, event.visualConfig.commonVisual), { sharingPopupVisuals: popups });
    };
    SeasonalEventUtils.hasWrongCurrenciesInRewardContent = function (targetCurrency, rewardContent) {
        var currenciesFromReward = LootUtils.getNotEmptyCurrenciesFromRewardContent(rewardContent);
        return this.hasCurrenciesDifferentEventCurrency(targetCurrency, currenciesFromReward);
    };
    SeasonalEventUtils.hasCurrenciesDifferentEventCurrency = function (targetCurrency, testCurrencies) {
        for (var _i = 0, testCurrencies_1 = testCurrencies; _i < testCurrencies_1.length; _i++) {
            var currency = testCurrencies_1[_i];
            var settings = currencySettings[currency];
            if (!settings || settings.isEventCurrency && targetCurrency.indexOf(+currency) == -1) {
                return true;
            }
        }
        return false;
    };
    SeasonalEventUtils.getActivityPopupSettings = function (settings) {
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        settings = __assign(__assign({}, settings), { playerProgress: playerProgress });
        var _a = settings.regionalSettings, platform = _a.platform, countryCode = _a.countryCode;
        var featuresPopups = [];
        var popupsResult = [];
        var events = getActiveSeasonalEventsByServerTime(settings.serverTime);
        if (Roulette.isRouletteAvailable(__assign(__assign({}, playerProgress), { tutorialPassed: settings.isTutorialPassed }))) {
            featuresPopups.push.apply(featuresPopups, roulettePopupVisualConfigs);
        }
        if (GachaBanner.isGachaBannerFeatureActive(__assign(__assign({}, playerProgress), { tutorialPassed: settings.isTutorialPassed }))) {
            featuresPopups.push.apply(featuresPopups, gachaPopupVisualConfigs);
        }
        if (settings.activeTournaments.length > 0) {
            featuresPopups.push.apply(featuresPopups, tournamentsPopupVisualConfigs);
        }
        featuresPopups.push.apply(featuresPopups, crossPromoPopupVisualConfigs);
        if (playerProgress.maxPlayerRating >= QuestConstants.ArenaRatingToUnlock) {
            featuresPopups.push.apply(featuresPopups, marathonsPopupVisualConfigs);
        }
        if (events.length > 0) {
            for (var _i = 0, events_1 = events; _i < events_1.length; _i++) {
                var eventId = events_1[_i];
                var event_3 = seasonalEventsMap.checkedGet(eventId);
                for (var _b = 0, _c = event_3.visualConfig.popups; _b < _c.length; _b++) {
                    var popup = _c[_b];
                    featuresPopups.push(popup);
                }
            }
        }
        featuresPopups = featuresPopups.filter(function (config) {
            if (config.data.countryCode && config.data.countryCode.length > 0) {
                if (config.data.countryCode.indexOf(countryCode) == -1) {
                    return false;
                }
            }
            if (config.data.platform) {
                if (config.data.platform != platform) {
                    return false;
                }
            }
            return settings.serverTime >= config.data.activeTime[0].start
                && settings.serverTime <= config.data.activeTime[config.data.activeTime.length - 1].end;
        });
        for (var _d = 0, featuresPopups_1 = featuresPopups; _d < featuresPopups_1.length; _d++) {
            var popup = featuresPopups_1[_d];
            var commonId = popup.data.ID;
            for (var subId = 0; subId < popup.data.activeTime.length; subId++) {
                var id = CommonPopUpUtils.getActivityPopupId(commonId, subId);
                if (activityPopupsMap[id] == undefined) {
                    logMessageOverEnvironment("Activity popup with id ".concat(id, " not found! See popup ").concat(commonId));
                    continue;
                }
                var showDate = popup.data.activeTime[subId];
                if (settings.serverTime >= showDate.start && settings.serverTime <= showDate.end) {
                    popupsResult.push(__assign(__assign({}, popup.data), { ID: +id }));
                    break;
                }
            }
        }
        var dailyPopups = CustomPopUpConditions.getActive(settings);
        popupsResult = popupsResult.concat(dailyPopups);
        popupsResult.sort(function (a, b) { return b.priority - a.priority; });
        var isCareGameBuild = CareGameState.getIsCareGameBuild();
        popupsResult = popupsResult.filter(function (p) { return !(p.navigation == POPUP_NAVIGATION.URL && isCareGameBuild); });
        return popupsResult;
    };
    SeasonalEventUtils.getActivityPopupVisualSettings = function (popUpId) {
        if (CustomPopUpConditions.isIdForPopUp(popUpId)) {
            popUpId = CustomPopUpConditions.getCommonIdFromPopUpId(popUpId);
        }
        return activityPopupsMap[popUpId] && activityPopupsMap[popUpId].visual || null;
    };
    SeasonalEventUtils.getActivityPopupSettingsById = function (popupId) {
        var isCareGameBuild = CareGameState.getIsCareGameBuild();
        if (CustomPopUpConditions.isIdForPopUp(popupId)) {
            popupId = CustomPopUpConditions.getCommonIdFromPopUpId(popupId);
        }
        var result = activityPopupsMap[popupId] && activityPopupsMap[popupId].data || null;
        if (CommonPopUpUtils.breakPopUpForCareGame(result, isCareGameBuild)) {
            return null;
        }
        return result;
    };
    return SeasonalEventUtils;
}());
