var EventCurrency = (function () {
    function EventCurrency() {
    }
    EventCurrency.getAllActiveCurrencyNames = function (seasonalEventID) {
        var result = [];
        for (var curId in currencySettings)
            if (isNumber(curId) && CURRENCY[curId] != undefined) {
                var settings = currencySettings[curId];
                if (!settings.isEventCurrency) {
                    result.push(+curId);
                }
            }
        if (seasonalEventID) {
            var seasonalEvent = seasonalEventsMap.get(seasonalEventID);
            if (seasonalEvent) {
                result.push.apply(result, seasonalEvent.eventCurrencies);
            }
        }
        return result;
    };
    EventCurrency.getEventCurrencies = function () {
        return Object
            .keys(currencySettings)
            .filter(function (k) { return currencySettings[k].isEventCurrency; })
            .map(Number);
    };
    return EventCurrency;
}());
