var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var EventQuestAggregator = (function () {
    function EventQuestAggregator(settings) {
        this.ID = settings.ID;
        this.commonQuestSequences = [];
        this.premiumQuestSequences = [];
        this.startTimes = settings.startTimes;
        var iteratorTypes = [
            { questSettings: settings.commonQuestSequences, aggregatorQuests: this.commonQuestSequences },
            { questSettings: settings.premiumQuestSequences, aggregatorQuests: this.premiumQuestSequences },
        ];
        for (var _i = 0, iteratorTypes_1 = iteratorTypes; _i < iteratorTypes_1.length; _i++) {
            var currentIterationType = iteratorTypes_1[_i];
            var sequences = currentIterationType.questSettings;
            for (var _a = 0, sequences_1 = sequences; _a < sequences_1.length; _a++) {
                var sequence = sequences_1[_a];
                var questGroupsInSequence = [];
                var iterationPreviousQuestGroupId = 0;
                for (var _b = 0, sequence_1 = sequence; _b < sequence_1.length; _b++) {
                    var questGroup = sequence_1[_b];
                    var currentQuestGroupId = EventQuestAggregator.getNewQuestGroupId();
                    var questsInGroup = [];
                    var _loop_1 = function (questSettings) {
                        var previousQuestGroupId = iterationPreviousQuestGroupId;
                        var questPrototype = questSettings.QuestPrototype;
                        var eventQuest = new Quest(__assign(__assign(__assign(__assign({}, questPrototype), { ShowCondition: function (args, questList) {
                                return previousQuestGroupId == 0
                                    || QuestUtils.isQuestPassedFromGroup(questList, previousQuestGroupId);
                            } }), questSettings), { EventQuest: true, SeasonQuest: false, DailyQuest: false, SpecialQuest: false, DefaultType: QUEST_TYPE.EVENT, MultiplePass: true, ID: EventQuestAggregator.getNewQuestId(), DamageQuestForHeroId: questSettings.DamageQuestForHeroId === undefined
                                ? null
                                : questSettings.DamageQuestForHeroId, QuestGroup: currentQuestGroupId, ParentGroup: questPrototype.ID }));
                        questsInGroup.push(eventQuest);
                    };
                    for (var _c = 0, questGroup_1 = questGroup; _c < questGroup_1.length; _c++) {
                        var questSettings = questGroup_1[_c];
                        _loop_1(questSettings);
                    }
                    iterationPreviousQuestGroupId = currentQuestGroupId;
                    questGroupsInSequence.push(questsInGroup);
                }
                currentIterationType.aggregatorQuests.push(questGroupsInSequence);
            }
        }
    }
    EventQuestAggregator.prototype.check = function () {
        var timesLength = this.startTimes.length;
        var commonLength = this.commonQuestSequences.length;
        var premiumLength = this.commonQuestSequences.length;
        if (timesLength != commonLength || commonLength != premiumLength) {
            throw new Error("Event quests aggregator ".concat(this.ID, ": length of times and sequences dont match"));
        }
        var currentTime = 0;
        for (var _i = 0, _a = this.startTimes; _i < _a.length; _i++) {
            var time = _a[_i];
            if (time < currentTime) {
                throw new Error("Event quests aggregator ".concat(this.ID, ": check startTimes for order"));
            }
            currentTime = time;
        }
    };
    EventQuestAggregator.prototype.getAllQuests = function () {
        var result = [];
        for (var _i = 0, _a = [this.commonQuestSequences, this.premiumQuestSequences]; _i < _a.length; _i++) {
            var sequences = _a[_i];
            for (var _b = 0, sequences_2 = sequences; _b < sequences_2.length; _b++) {
                var sequence = sequences_2[_b];
                for (var _c = 0, sequence_2 = sequence; _c < sequence_2.length; _c++) {
                    var group = sequence_2[_c];
                    result = result.concat(group);
                }
            }
        }
        return result;
    };
    EventQuestAggregator.prototype.getStartTimesIndexByTime = function (serverTime) {
        var index = -1;
        for (var _i = 0, _a = this.startTimes; _i < _a.length; _i++) {
            var time = _a[_i];
            if (serverTime >= time) {
                index++;
            }
            else {
                break;
            }
        }
        return index;
    };
    EventQuestAggregator.addEventQuestsToQuestsFromAggregator = function (aggregatorMap, quests) {
        for (var aggregatorName in aggregatorMap) {
            var aggregator = aggregatorMap[aggregatorName];
            var eventQuests = aggregator.getAllQuests();
            for (var _i = 0, eventQuests_1 = eventQuests; _i < eventQuests_1.length; _i++) {
                var quest = eventQuests_1[_i];
                var name_1 = "Event_quest_".concat(quest.ID);
                if (quests[name_1] != undefined) {
                    throw new Error("addEventQuestsToQuests error! quests map already has quest with name ".concat(name_1));
                }
                quests[name_1] = quest;
            }
        }
    };
    EventQuestAggregator.expandByUnusedQuests = function (quests) {
        var rewardSettings = [];
        for (var difficulty in QUEST_DIFFICULTY)
            if (isNumber(difficulty)) {
                rewardSettings.push({ Counter: 999999, Difficulty: +difficulty });
            }
        for (var questId = EventQuestAggregator.currentQuestId; questId <= EventQuestAggregator.maxQuestId; questId++) {
            var name_2 = "Event_unused_quest_".concat(questId);
            if (quests[name_2] != undefined) {
                throw new Error("expandByUnusedQuests error! quests map already has quest with name ".concat(name_2));
            }
            quests[name_2] = new Quest({
                ID: questId,
                Description: name_2,
                ViewConfig: QuestView.Account,
                RewardsSettings: rewardSettings,
                ShowEvents: [], UpdateTriggers: [], UpdateEvents: [],
                Weight: 0, EventQuest: true, MultiplePass: true,
                ShowCondition: function (args, questList) {
                    return false;
                },
                Update: function (args) {
                    return 0;
                },
            });
        }
    };
    EventQuestAggregator.getAllEventQuestIds = function () {
        var result = [];
        for (var questId = EventQuestAggregator.minQuestId; questId <= EventQuestAggregator.maxQuestId; questId++) {
            result.push(questId);
        }
        return result;
    };
    EventQuestAggregator.getNewQuestId = function () {
        if (EventQuestAggregator.currentQuestId > EventQuestAggregator.maxQuestId) {
            throw new Error("event quests: max event quest id is ".concat(EventQuestAggregator.maxQuestId));
        }
        return EventQuestAggregator.currentQuestId++;
    };
    EventQuestAggregator.getNewQuestGroupId = function () {
        return EventQuestAggregator.questGroupId++;
    };
    EventQuestAggregator.minQuestId = 10000;
    EventQuestAggregator.currentQuestId = EventQuestAggregator.minQuestId;
    EventQuestAggregator.maxQuestId = 10664;
    EventQuestAggregator.questGroupId = 10000;
    return EventQuestAggregator;
}());
