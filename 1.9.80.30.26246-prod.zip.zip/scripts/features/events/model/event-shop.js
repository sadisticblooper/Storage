var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var SeasonalEventShop = (function () {
    function SeasonalEventShop(settings) {
        this.ID = settings.ID;
        this.slots = settings.slots;
    }
    SeasonalEventShop.prototype.getShopOfferFromSlot = function (slotNumber, serverTime, playerProgress, seed) {
        var _a;
        var slots = this.getSlots(seed);
        var slot = slots[slotNumber];
        if (!slot) {
            return null;
        }
        for (var _i = 0, slot_1 = slot; _i < slot_1.length; _i++) {
            var variant = slot_1[_i];
            if (!variant.expireTime || serverTime < variant.expireTime) {
                var shopOffer = new ShopOffer();
                var offerParams = SeasonalEventShop.getShopOfferParameters(variant, playerProgress);
                var offerSettings = new ShopOfferSettings(offerParams);
                shopOffer.generate({
                    shopType: SHOP_TYPE.COMMON,
                    regionalSettings: null,
                    seed: 0,
                    playerProgress: playerProgress,
                    startTimeOfCurrentDayMS: serverTime,
                }, offerSettings);
                var canClaimed = shopOffer.canClaimByCustomization(playerProgress);
                if (shopOffer.isEmpty()) {
                    shopOffer.addLoot(new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 20, _a) }));
                }
                var purchaseCounter = (variant.hidePurchaseQuantityIfCustomization
                    && shopOffer.loot.hasCustomize())
                    ? 0
                    : variant.purchasesQuantity;
                return {
                    expireTime: purchaseCounter && purchaseCounter > 0 ? null : variant.expireTime,
                    purchasesQuantity: purchaseCounter,
                    shopOffer: shopOffer,
                    canClaimed: canClaimed,
                    slotIndex: slotNumber,
                };
            }
        }
        return null;
    };
    SeasonalEventShop.prototype.getSlots = function (seed) {
        var result = [];
        for (var _i = 0, _a = this.slots; _i < _a.length; _i++) {
            var slot = _a[_i];
            var resultSlot = [];
            var originalIndexesForRandom = [];
            for (var index = 0; index < slot.length; index++) {
                var variant = slot[index];
                if (variant.randomVariantAmongOthers) {
                    originalIndexesForRandom.push(index);
                }
            }
            var randomizedIndexesForRandom = originalIndexesForRandom.slice();
            var randomiseMap = {};
            var rnd = new PcgRandom(seed);
            shuffle(randomizedIndexesForRandom, rnd);
            for (var i = 0; i < randomizedIndexesForRandom.length; i++) {
                randomiseMap[originalIndexesForRandom[i]] = randomizedIndexesForRandom[i];
            }
            for (var index = 0; index < slot.length; index++) {
                if (randomiseMap[index] != undefined) {
                    var variant = slot[index];
                    var randomVariant = slot[randomiseMap[index]];
                    resultSlot.push(__assign(__assign({}, randomVariant), { expireTime: variant.expireTime }));
                }
                else {
                    resultSlot.push(slot[index]);
                }
            }
            result.push(resultSlot);
        }
        return result;
    };
    SeasonalEventShop.getShopOfferParameters = function (slotSettings, playerProgress) {
        if (slotSettings.replaceSettings
            && !slotSettings.replaceSettings.random != !slotSettings.replaceSettings.fixed) {
            var loot = void 0;
            var price = slotSettings.shopOffer.FixedPrice;
            if (slotSettings.replaceSettings.random) {
                var ri = new PcgRandom(slotSettings.shopOffer.ID);
                var rndSettings = slotSettings.replaceSettings.random.randomLoot;
                loot = OffersUtils.getRandomCustomizationLoot({
                    playerProgress: playerProgress,
                    randomSettings: rndSettings,
                    ri: ri,
                });
                if (slotSettings.replaceSettings.random.fixedPrice) {
                    price = slotSettings.replaceSettings.random.fixedPrice;
                }
            }
            else {
                var fixedLoot = slotSettings.replaceSettings.fixed.fixedLoot;
                var lootGenerator = LootGeneratorBuilder.getEventShopLootGenerator();
                lootGenerator.setPlayerParams(playerProgress);
                loot = lootGenerator.getLootFromFixedLoot(fixedLoot);
                if (slotSettings.replaceSettings.fixed.fixedPrice) {
                    price = slotSettings.replaceSettings.fixed.fixedPrice;
                }
            }
            if (loot && !loot.isEmpty()) {
                return __assign(__assign({}, slotSettings.shopOffer), { FixedLoot: loot, FixedPrice: price, SlotVariants: undefined });
            }
        }
        return slotSettings.shopOffer;
    };
    SeasonalEventShop.prototype.getActiveOffers = function (serverTime, seed) {
        var result = [];
        var slots = this.getSlots(seed);
        for (var _i = 0, slots_1 = slots; _i < slots_1.length; _i++) {
            var slot = slots_1[_i];
            for (var _a = 0, slot_2 = slot; _a < slot_2.length; _a++) {
                var variant = slot_2[_a];
                if (variant.expireTime == undefined || serverTime < variant.expireTime) {
                    result.push(variant.shopOffer.ID);
                    break;
                }
            }
        }
        return result;
    };
    SeasonalEventShop.generateSeasonalEventShop = function (settings) {
        var seasonalEvent = seasonalEventsMap.get(settings.seasonalEventID);
        if (!seasonalEvent) {
            return null;
        }
        var shop = seasonalEventShopsMap.get(seasonalEvent.activities.shop);
        if (!shop) {
            return null;
        }
        var result = {
            expireTimeForEventShop: seasonalEvent.endTime,
            slots: [],
        };
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        for (var i = 0; i < shop.slots.length; i++) {
            var shopSlot = shop.getShopOfferFromSlot(i, settings.serverTime, playerProgress, settings.seed);
            if (shopSlot) {
                result.slots.push(shopSlot);
            }
        }
        return result;
    };
    SeasonalEventShop.generateSeasonalEventShopSlot = function (settings) {
        var seasonalEvent = seasonalEventsMap.get(settings.seasonalEventID);
        if (!seasonalEvent) {
            return null;
        }
        var shop = seasonalEventShopsMap.get(seasonalEvent.activities.shop);
        if (!shop) {
            return null;
        }
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        return shop.getShopOfferFromSlot(settings.slot, settings.serverTime, playerProgress, settings.seed);
    };
    SeasonalEventShop.addShopOffersToShopSlots = function (shopSlots, seasonalEventShops) {
        for (var name_1 in seasonalEventShops) {
            var eventShop = seasonalEventShops[name_1];
            var slotNumber = 0;
            for (var _i = 0, _a = eventShop.slots; _i < _a.length; _i++) {
                var slot = _a[_i];
                var variantNumber = 0;
                for (var _b = 0, slot_3 = slot; _b < slot_3.length; _b++) {
                    var offerSettings = slot_3[_b];
                    var offerName = "".concat(name_1, "_slot_").concat(slotNumber, "_variant_").concat(variantNumber++);
                    if (shopSlots[offerName] != undefined) {
                        throw new Error("addShopOffersToShopSlots: ".concat(offerName, " was repeated!"));
                    }
                    shopSlots[offerName] = offerSettings.shopOffer;
                }
                slotNumber++;
            }
        }
    };
    SeasonalEventShop.getActiveShopEventOffers = function (settings) {
        var seed = settings.seed, serverTime = settings.serverTime;
        var result = {};
        var activeEvents = getActiveSeasonalEventsByServerTime(serverTime);
        for (var _i = 0, activeEvents_1 = activeEvents; _i < activeEvents_1.length; _i++) {
            var eventId = activeEvents_1[_i];
            var event_1 = seasonalEventsMap.get(eventId);
            var shop = seasonalEventShopsMap.get(event_1.activities.shop);
            if (shop) {
                var activeOffers = shop.getActiveOffers(serverTime, seed);
                if (activeOffers.length > 0) {
                    result[eventId] = activeOffers;
                }
            }
        }
        return result;
    };
    return SeasonalEventShop;
}());
