function getSeasonalEventById(id) {
    return seasonalEventsMap.get(id);
}
function getActiveSeasonalEventsByServerTime(serverTime) {
    return SeasonalEventUtils.getActiveSeasonalEventsByServerTime(serverTime);
}
function getTimeLeftToNextEvent(serverTime) {
    return SeasonalEventUtils.getTimeLeftToNextEvent(serverTime);
}
function areSeasonalEventsAvailable(playerProgress_) {
    var playerProgress = PlayerState.getCorrectFromRawOrCache(playerProgress_);
    return playerProgress.accountLevel >= 2;
}
function getConvertedSeasonalEventCurrencies(settings) {
    return SeasonalEventUtils.getConvertedSeasonalEventCurrencies(settings);
}
function getAllActiveCurrencyId(seasonalEventID) {
    return EventCurrency.getAllActiveCurrencyNames(seasonalEventID);
}
function getTimeOfUpdateEventQuests(settings) {
    return SeasonalEventUtils.getTimeOfUpdateEventQuests(settings);
}
function generateSeasonalEventShop(settings) {
    return SeasonalEventShop.generateSeasonalEventShop(settings);
}
function generateSeasonalEventShopSlot(settings) {
    return SeasonalEventShop.generateSeasonalEventShopSlot(settings);
}
function getActiveShopEventOffers(settings) {
    return SeasonalEventShop.getActiveShopEventOffers(settings);
}
function getEventVisualSettings(eventId) {
    return SeasonalEventUtils.getEventVisualSettings(eventId);
}
function getActivityPopupSettings(settings) {
    return SeasonalEventUtils.getActivityPopupSettings(settings);
}
function getActivityPopupSettingsById(popupId) {
    return SeasonalEventUtils.getActivityPopupSettingsById(popupId);
}
function getActivityPopupVisualSettings(popupId) {
    return SeasonalEventUtils.getActivityPopupVisualSettings(popupId);
}
