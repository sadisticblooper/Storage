function getOfferWallRewards() {
    return OfferWallUtils.getOfferWallRewards();
}
function getActiveOfferWalls() {
    return OfferWallUtils.getActiveOfferWalls();
}
function getFreeOfferByType(type) {
    return FreeOffersMap.checkedGet(type);
}
function getAllFreeOfferTypes() {
    return FreeOffer.getAllFreeOfferTypes();
}
function getFreeOfferVisualSettings(type) {
    return FreeOffersMap.checkedGet(type).getVisual();
}
function getOfferWallVisualSettings(type) {
    return offerWallsMap.checkedGet(type).getVisual();
}
function convertTapjoyLoot(params) {
    return OfferWallUtils.convertTapjoyLoot(params);
}
