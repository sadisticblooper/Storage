var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z;
var FreeOffers = {
    SUBSCRIBE_VK: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_VK,
        url: "https://vk.com/shadowarena",
        includedRegions: ["AM", "AZ", "BY", "KZ", "KG", "MD", "RU", "TJ", "UZ", "TM", "UA"],
        platforms: [PLATFORM.ANDROID, PLATFORM.IOS],
        reward: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 20, _a) }),
        sortingOrder: 100,
        visualSettings: {
            "headerAlias": "vk",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#547cb8"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#7690b8",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_VK",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_FACEBOOK: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_FACEBOOK,
        url: "https://www.facebook.com/shadowfightarena",
        excludedRegions: ["CN", "RU"],
        reward: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 20, _b) }),
        sortingOrder: 200,
        visualSettings: {
            "headerAlias": "facebook",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#4467b8"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#657eb8",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_FACEBOOK",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_TWITTER: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_TWITTER,
        url: "https://twitter.com/SFArenaGame",
        excludedRegions: ["CN", "RU"],
        reward: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 20, _c) }),
        sortingOrder: 300,
        visualSettings: {
            "headerAlias": "social_x",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#171717"
                    },
                    {
                        "time": 1,
                        "color": "#2e2e2e"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#5C5C5C",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_X",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_YOUTUBE: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_YOUTUBE,
        url: "https://www.youtube.com/c/ShadowFightGames",
        excludedRegions: ["CN"],
        reward: new Loot({ Currencies: (_d = {}, _d[CURRENCY.BONUS] = 20, _d) }),
        sortingOrder: 400,
        visualSettings: {
            "headerAlias": "youtube",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#ff0000"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#ff4747",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_YOUTUBE",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_WECHAT: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_WECHAT,
        url: "http://shadowfight3.com/mobile-zh",
        includedRegions: ["CN"],
        reward: new Loot({ Currencies: (_e = {}, _e[CURRENCY.BONUS] = 20, _e) }),
        sortingOrder: 500,
        visualSettings: {
            "headerAlias": "wechat",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#76b833"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#86b854",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_WECHAT",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_WEIBO: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_WEIBO,
        url: "https://www.weibo.com/shadowfightgame?is_hot=1",
        includedRegions: ["CN"],
        reward: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 20, _f) }),
        sortingOrder: 600,
        visualSettings: {
            "headerAlias": "weibo",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#e5172c"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#e54051",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_WEIBO",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_BILIBILI: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_BILIBILI,
        url: "https://space.bilibili.com/281429014/#/",
        includedRegions: ["CN"],
        reward: new Loot({ Currencies: (_g = {}, _g[CURRENCY.BONUS] = 20, _g) }),
        sortingOrder: 700,
        visualSettings: {
            "headerAlias": "bilibili",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#17a8e5"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#40b4e5",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_BILIBILI",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_YOUKU: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_YOUKU,
        url: "http://i.youku.com/shadowfight",
        includedRegions: ["CN"],
        reward: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 20, _h) }),
        sortingOrder: 800,
        visualSettings: {
            "headerAlias": "youku",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#e5406a"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#e56a89",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_YOUKU",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_TikTok: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_TikTok,
        url: "https://vm.tiktok.com/ZMLSfFxyW",
        excludedRegions: ["CN"],
        reward: new Loot({ Currencies: (_j = {}, _j[CURRENCY.BONUS] = 50, _j) }),
        sortingOrder: 50,
        visualSettings: {
            "headerAlias": "tiktok",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#181818"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#000000",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_TikTok",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_TELEGRAM: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_TELEGRAM,
        url: "https://t.me/shadowfightgames",
        includedRegions: CIS_COUNTRIES.concat(["UA"]),
        reward: new Loot({ Currencies: (_k = {}, _k[CURRENCY.BONUS] = 50, _k) }),
        sortingOrder: 300,
        visualSettings: {
            "headerAlias": "telegram",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#384145"
                    },
                    {
                        "time": 1,
                        "color": "#1EAEEC"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#657EB8",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_TELEGRAM",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SUBSCRIBE_INSTAGRAM: new FreeOffer({
        ID: FREE_OFFER_TYPE.SUBSCRIBE_INSTAGRAM,
        url: "https://www.instagram.com/shadowfightgames",
        excludedRegions: ["CN", "RU"],
        reward: new Loot({ Currencies: (_l = {}, _l[CURRENCY.BONUS] = 50, _l) }),
        sortingOrder: 300,
        visualSettings: {
            "headerAlias": "instagram",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#384145"
                    },
                    {
                        "time": 1,
                        "color": "#CF28BD"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#B800A5",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_INSTAGRAM",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SPINE: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE,
        url: "https://store.steampowered.com/app/1731290/SPINE/?utm_source=sf4&utm_medium=mobile&utm_campaign=wishlist",
        reward: new Loot({ Currencies: (_m = {}, _m[CURRENCY.BONUS] = 50, _m) }),
        sortingOrder: 40,
        visualSettings: {
            "headerAlias": "wishlist_on_steam",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#45454500"
                    },
                    {
                        "time": 1,
                        "color": "#ff000000"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/free_offer_spine_art_2"
        },
    }),
    SPINE_PROMO_TRAILER: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE_PROMO_TRAILER,
        url: "https://youtu.be/vvssE4VjHys",
        reward: new Loot({ Currencies: (_o = {}, _o[CURRENCY.BONUS] = 100, _o) }),
        sortingOrder: 30,
        visualSettings: {
            "headerAlias": "button_watch_trailer",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#0a2a46"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#FFFFFF",
            "icon": "Sprites/Assets/StoreFree/icon_SPINE",
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/Assets/StoreFree/promo_art_Spine"
        },
        includedRegions: ["NO_ONE"],
    }),
    SPINE_PROMO_MARCH_2024: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE_PROMO_MARCH_2024,
        url: "https://youtu.be/w8CpzsQn1ls",
        reward: new Loot({ Currencies: (_p = {}, _p[CURRENCY.BONUS] = 100, _p) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "button_watch_trailer",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#0a2a46"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#FFFFFF",
            "icon": "Sprites/Assets/StoreFree/icon_SPINE",
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/Assets/StoreFree/promo_art_Spine"
        },
        includedRegions: ["NO_ONE"],
    }),
    SPINE_PROMO_AUGUST_2024: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE_PROMO_AUGUST_2024,
        url: "https://youtu.be/YOS3iIE3BAs",
        reward: new Loot({ Currencies: (_q = {}, _q[CURRENCY.BONUS] = 100, _q) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "spine_promo_header",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#45454500"
                    },
                    {
                        "time": 1,
                        "color": "#ff000000"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_watch_trailer",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/free_offer_spine_art_1"
        },
        includedRegions: ["NO_ONE"],
    }),
    YANDEX_NOVEMBER_2024: new FreeOffer({
        ID: FREE_OFFER_TYPE.YANDEX_NOVEMBER_2024,
        url: "https://yandex.ru/portal/defsearchpromo/landing/sf4_ru?partner=mVebrAU1T5IMf28716&offer_type=UAGdd9o1T5IMf28717&utm_source=promocode&utm_medium=ru_sf4&utm_campaign=291020240",
        reward: new Loot({ Currencies: (_r = {}, _r[CURRENCY.BONUS] = 123, _r) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": null,
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0.2,
                        "color": "#948e7e"
                    },
                    {
                        "time": 0.8,
                        "color": "#ffffff"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": 1,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/PreviewImages/Advertising/Yandex/yandex_offer_art"
        },
        includedRegions: ["NO_ONE"],
    }),
    SPINE_PROMO_DECEMBER_2024: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE_PROMO_DECEMBER_2024,
        url: "https://youtu.be/nl_9oQgLVLM",
        reward: new Loot({ Currencies: (_s = {}, _s[CURRENCY.BONUS] = 100, _s) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "spine_promo_header",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#45454500"
                    },
                    {
                        "time": 1,
                        "color": "#ff000000"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_watch_trailer",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/free_offer_spine_art_1"
        },
        includedRegions: ["NO_ONE"],
    }),
    NINJA_PARTY_FEBRUARY_2025: new FreeOffer({
        ID: FREE_OFFER_TYPE.NINJA_PARTY_FEBRUARY_2025,
        url: "https://store.steampowered.com/app/3186180/Ninja_Party/?utm_source=sf4&utm_medium=mobile&utm_campaign=wishlist",
        reward: new Loot({ Currencies: (_t = {}, _t[CURRENCY.BONUS] = 50, _t) }),
        sortingOrder: 41,
        visualSettings: {
            "headerAlias": "wishlist_now",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0.2,
                        "color": "#948e7e"
                    },
                    {
                        "time": 0.8,
                        "color": "#ffffff"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": 1,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingNP/free_offer_art_np"
        },
        includedRegions: ["NO_ONE"],
    }),
    SPINE_PROMO_TRAILER_APRIL_2025: new FreeOffer({
        ID: FREE_OFFER_TYPE.SPINE_PROMO_TRAILER_APRIL_2025,
        url: "https://www.youtube.com/watch?v=pZbHDdd5drA",
        reward: new Loot({ Currencies: (_u = {}, _u[CURRENCY.BONUS] = 100, _u) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "spine_promo_header",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#45454500"
                    },
                    {
                        "time": 1,
                        "color": "#ff000000"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE,
            "claimButtonAlias": "button_watch_trailer",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingSPINE/free_offer_spine_art_1"
        },
        includedRegions: ["NO_ONE"],
    }),
    NINJA_PARTY_TRAILER_APRIL_2025: new FreeOffer({
        ID: FREE_OFFER_TYPE.NINJA_PARTY_TRAILER_APRIL_2025,
        url: "https://youtu.be/csvu1olK1mU",
        reward: new Loot({ Currencies: (_v = {}, _v[CURRENCY.BONUS] = 100, _v) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "np_teaser_trailer_new",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0.2,
                        "color": "#948e7e"
                    },
                    {
                        "time": 0.8,
                        "color": "#ffffff"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": 1,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/PreviewImages/Advertising/AdvertisingNP/free_offer_art_np_2"
        },
        includedRegions: ["NO_ONE"],
    }),
    STEAM_PROMO: new FreeOffer({
        ID: FREE_OFFER_TYPE.STEAM_PROMO,
        url: "https://engagements.appsflyer.com/v1.0/c2s/click/app/steam/1731290?af_media_source=crosspromo_SFA&af_campaign_id=20250924SFA&af_campaign=20250925_SFA_Steam_crosspromo_inappSFA_wishlist&af_r=https%3A%2F%2Fstore.steampowered.com%2Fapp%2F1446890%2FShadow_Fight_Arena%2F",
        reward: new Loot({ Currencies: (_w = {}, _w[CURRENCY.BONUS] = 50, _w) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "empty",
            "descriptionAlias": "wishlist_now",
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 0
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0.2,
                        "color": "#ffffff"
                    },
                    {
                        "time": 0.8,
                        "color": "#ffffff"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": 1,
            "claimButtonAlias": "button_proceed",
            "promoArt": "Sprites/PreviewImages/Advertising/Steam/free_offer_steam_art"
        },
        includedRegions: ["NO_ONE"],
    }),
    STEAM_RELEASE: new FreeOffer({
        ID: FREE_OFFER_TYPE.STEAM_RELEASE,
        url: "https://engagements.appsflyer.com/v1.0/c2s/click/app/steam/1731290?af_media_source=crosspromo_SFA&af_campaign_id=20251020SFA&af_campaign=20251024_SFA_Steam_crosspromo_inappSFA_earlyaccess&af_r=https%3A%2F%2Fstore.steampowered.com%2Fapp%2F1446890%2FShadow_Fight_Arena%2F",
        reward: new Loot({ Currencies: (_x = {}, _x[CURRENCY.BONUS] = 50, _x) }),
        sortingOrder: 20,
        visualSettings: {
            "headerAlias": "empty",
            "descriptionAlias": "empty",
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 0
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0.2,
                        "color": "#ffffff"
                    },
                    {
                        "time": 0.8,
                        "color": "#ffffff"
                    }
                ]
            },
            "pattern": null,
            "patternColor": null,
            "icon": null,
            "visualType": 1,
            "claimButtonAlias": "steam_release_popup_button",
            "promoArt": "Sprites/PreviewImages/Advertising/Steam/free_offer_steam_art_2"
        },
        platforms: nonPCPlatforms,
    }),
    RATE_US: new FreeOffer({
        ID: FREE_OFFER_TYPE.RATE_US,
        url: "",
        reward: new Loot({ Currencies: (_y = {}, _y[CURRENCY.BONUS] = 25, _y) }),
        visualSettings: {
            "headerAlias": "",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": []
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "",
            "icon": "",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
    SHARE: new FreeOffer({
        ID: FREE_OFFER_TYPE.SHARE,
        url: "",
        reward: new Loot({ Currencies: (_z = {}, _z[CURRENCY.BONUS] = 25, _z) }),
        visualSettings: {
            "headerAlias": "",
            "descriptionAlias": null,
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": []
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "",
            "icon": "",
            "visualType": FREE_OFFER_VISUAL_TYPE.NARROW,
            "claimButtonAlias": "button_subscribe",
            "promoArt": null
        },
    }),
};
var FreeOffersMap = createIDMap(FreeOffers, "FreeOffersMap");
