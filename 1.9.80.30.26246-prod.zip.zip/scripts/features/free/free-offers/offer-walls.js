var offerWalls = {
    TAPJOY: new OfferWall({
        ID: OFFER_WALL_TYPE.TAPJOY,
        sortingOrder: 10,
        reward: { min: 10, max: 150 },
        isActive: true,
        visualSettings: {
            "headerAlias": "tapjoy",
            "descriptionAlias": "offerwall_reward_description",
            "claimButtonAlias": "button_proceed",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_TAPJOY",
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#FF0000"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#FF4747",
            "promoArt": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE
        },
    }),
    FYBER: new OfferWall({
        ID: OFFER_WALL_TYPE.FYBER,
        sortingOrder: 20,
        reward: { min: 20, max: 250 },
        isActive: false,
        visualSettings: {
            "headerAlias": "fyber",
            "descriptionAlias": "offerwall_reward_description",
            "claimButtonAlias": "button_proceed",
            "icon": "Sprites/Assets/StoreFree/icon_SOCIAL_FYBER",
            "bg": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#454545"
                    },
                    {
                        "time": 1,
                        "color": "#00D691"
                    }
                ]
            },
            "pattern": "Sprites/Assets/StoreFree/free_store_pattern1",
            "patternColor": "#00D691",
            "promoArt": null,
            "visualType": FREE_OFFER_VISUAL_TYPE.WIDE
        },
    }),
};
var offerWallsMap = createIDMap(offerWalls, "offerWallsMap");
