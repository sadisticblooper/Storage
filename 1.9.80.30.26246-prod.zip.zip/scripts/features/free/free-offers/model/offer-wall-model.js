var OfferWall = (function () {
    function OfferWall(settings) {
        this.settings = settings;
        this.ID = settings.ID;
    }
    OfferWall.prototype.isActive = function () {
        return this.settings.isActive;
    };
    OfferWall.prototype.getReward = function () {
        return this.settings.reward;
    };
    OfferWall.prototype.getSortingOrder = function () {
        return getValueByKeyDefault(this.settings, "sortingOrder", 10);
    };
    OfferWall.prototype.getVisual = function () {
        return this.settings.visualSettings;
    };
    return OfferWall;
}());
