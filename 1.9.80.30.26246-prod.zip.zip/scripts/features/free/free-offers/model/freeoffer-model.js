var FreeOffer = (function () {
    function FreeOffer(config) {
        this.ID = config.ID;
        this.reward = config.reward;
        this.url = config.url;
        this.includedRegions = config.includedRegions;
        this.excludedRegions = config.excludedRegions;
        this.platforms = config.platforms;
        this.sortingOrder = getValueByKeyDefault(config, "sortingOrder", 0);
        this.visualSettings = config.visualSettings;
    }
    FreeOffer.prototype.getVisual = function () {
        return this.visualSettings;
    };
    FreeOffer.getAllFreeOfferTypes = function () {
        var result = [];
        for (var type in FREE_OFFER_TYPE)
            if (isNumber(type)) {
                result.push(+type);
            }
        return result;
    };
    return FreeOffer;
}());
