var OfferWallUtils = (function () {
    function OfferWallUtils() {
    }
    OfferWallUtils.getActiveOfferWalls = function () {
        var result = [];
        for (var _i = 0, _a = offerWallsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var offerWall = offerWallsMap.get(id);
            if (offerWall.isActive()) {
                result.push({
                    type: offerWall.ID,
                    sortingOrder: offerWall.getSortingOrder(),
                });
            }
        }
        return result;
    };
    OfferWallUtils.getOfferWallRewards = function () {
        var result = {};
        for (var _i = 0, _a = offerWallsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var offerWall = offerWallsMap.get(id);
            result[offerWall.ID] = offerWall.getReward();
        }
        return result;
    };
    OfferWallUtils.convertTapjoyLoot = function (params) {
        var _a;
        var currencyId = params.currencyId, rewardAmount = params.rewardAmount;
        currencyId = currencyId.replace(/[^0-9]/, "");
        var currency = CURRENCY[currencyId] || CURRENCY.BONUS;
        rewardAmount = rewardAmount || 1;
        return new Loot({ Currencies: (_a = {}, _a[currency] = rewardAmount, _a) });
    };
    return OfferWallUtils;
}());
