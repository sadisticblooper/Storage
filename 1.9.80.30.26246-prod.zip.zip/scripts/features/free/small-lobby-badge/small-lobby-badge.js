var SmallLobbyBadge = (function () {
    function SmallLobbyBadge() {
    }
    SmallLobbyBadge.getSmallLobbyBadgeFreeOfferVisualSettings = function (settings) {
        var isNonMobile = settings.isNonMobile;
        return isNonMobile
            ? null
            : {
                glow: "#68B8548A",
                decor: "#82E56A",
                blinkGlow: "#E8FFE2",
                titleColor: "#82E56A",
                icon: "Sprites/Assets/Icons/rubies",
                lobbyBadgeLabel: {
                    isAlias: true,
                    value: "lobby_free_shop_badge",
                    placeholders: null,
                },
                bgGradient: {
                    colorKeys: [{ color: "#3F4728", time: 0 }, { color: "#502D26", time: 1 }],
                    alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
                    mode: 0,
                }
            };
    };
    SmallLobbyBadge.getSmallLobbyBadgeMultiBonusVisualSettings = function (multiBonusId) {
        var lobbyBadgeAlias = null;
        if (isNumber(multiBonusId) && multiBonusId > 0) {
            var bonus = multiBonusMap.checkedGet(multiBonusId);
            lobbyBadgeAlias = {
                isAlias: false,
                value: "x".concat(bonus.multiplier),
                placeholders: null,
            };
        }
        return {
            glow: "#B833478A",
            decor: "#E5C76A",
            blinkGlow: "#FFFFBF",
            titleColor: "#E5C76A",
            icon: "Sprites/Assets/Icons/rubies",
            lobbyBadgeLabel: lobbyBadgeAlias,
            bgGradient: {
                colorKeys: [{ color: "#3F4728", time: 0 }, { color: "#502D26", time: 1 }],
                alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
                mode: 0,
            }
        };
    };
    SmallLobbyBadge.getSmallLobbyBadgeOfferToShow = function (settings) {
        var activeOffersIds = settings.activeOfferIds;
        activeOffersIds = activeOffersIds
            .filter(function (id) {
            var offer = offersMap.checkedGet(id);
            return offer.IsStarterPack;
        })
            .sort(function (a, b) { return a - b; });
        if (activeOffersIds.length == 0) {
            return null;
        }
        return activeOffersIds[0];
    };
    SmallLobbyBadge.getSmallLobbyBadgeOfferVisualSettings = function (offerId) {
        var promoOffer = offersMap.checkedGet(offerId);
        return promoOffer.getVisualForSmallLobbyBadge() || PromoOfferConstants.visualForSmallBadgeUniversalYellow;
    };
    return SmallLobbyBadge;
}());
