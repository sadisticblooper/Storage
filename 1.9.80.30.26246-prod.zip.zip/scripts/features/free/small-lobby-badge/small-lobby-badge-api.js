function getSmallLobbyBadgeMultiBonusVisualSettings(multiBonusId) {
    return SmallLobbyBadge.getSmallLobbyBadgeMultiBonusVisualSettings(multiBonusId);
}
function getSmallLobbyBadgeFreeOfferVisualSettings(settings) {
    return SmallLobbyBadge.getSmallLobbyBadgeFreeOfferVisualSettings(settings);
}
function getSmallLobbyBadgeOfferToShow(settings) {
    return SmallLobbyBadge.getSmallLobbyBadgeOfferToShow(settings);
}
function getSmallLobbyBadgeOfferVisualSettings(offerId) {
    return SmallLobbyBadge.getSmallLobbyBadgeOfferVisualSettings(offerId);
}
