var PromoCode = (function () {
    function PromoCode(settings) {
        this.ID = settings.ID;
        this.ExpireTime = settings.ExpireTime;
        this.OneTimeCode = settings.OneTimeCode;
        this.OneTimeReward = settings.OneTimeReward;
        this.RewardSettings = settings.RewardSettings;
        this.SubscriptionDays = settings.SubscriptionDays;
        this.UnlockCurrentBattlePassPremium = settings.UnlockCurrentBattlePassPremium;
    }
    PromoCode.generateLootFromPromoCode = function (settings) {
        var code = promoCodesMap.get(settings.promoCodeId);
        if (!code) {
            return null;
        }
        var result = {};
        if (code.RewardSettings) {
            RandomInstance.setSeed(settings.seed);
            var resultReward = {
                Loot: new Loot(),
                Chests: [],
                NewSeed: 0,
            };
            var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
            var lootGenerator = LootGeneratorBuilder.getPromoCodesLootGenerator();
            lootGenerator.setPlayerParams(playerProgress);
            lootGenerator.setServerTime(settings.startTimeOfCurrentDayMS);
            for (var _i = 0, _a = code.RewardSettings; _i < _a.length; _i++) {
                var rewardContent = _a[_i];
                var rewardResult = lootGenerator.getRewardFromRewardContent(rewardContent, RandomInstance);
                if (rewardResult.Loot && !rewardResult.Loot.isEmpty()) {
                    resultReward.Loot.combineLoot(rewardResult.Loot);
                }
                if (rewardResult.Chests && rewardResult.Chests.length) {
                    resultReward.Chests = resultReward.Chests.concat(rewardResult.Chests);
                }
            }
            resultReward.NewSeed = RandomInstance.nextInt(RandomInstance.MAX_INTEGER());
            result.reward = resultReward;
        }
        if (code.UnlockCurrentBattlePassPremium != undefined) {
            result.unlockCurrentBattlePassPremium = code.UnlockCurrentBattlePassPremium;
        }
        if (code.SubscriptionDays != undefined) {
            result.subscriptionDays = code.SubscriptionDays;
        }
        return result;
    };
    return PromoCode;
}());
