var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61;
var promoCodes = {
    gift_pack_23102024: new PromoCode({
        ID: 173,
        OneTimeCode: true,
        OneTimeReward: true,
        ExpireTime: new Date('2026-01-01').getTime(),
        RewardSettings: [
            {
                chests: [chests.Small_Shard_Chest.ID],
                loot: new Loot({
                    Currencies: (_a = {}, _a[CURRENCY.COIN] = 1000, _a[CURRENCY.GACHA_KEY] = 3, _a),
                    Weapons: [heroWeapons.wpn_Sarge_R_Patterns_Rec_Mystic.ID]
                })
            },
        ],
    }),
    Widow_shards_and_cards: new PromoCode({
        ID: 175,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2025-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Shards: (_b = {}, _b[HeroNames.Widow.ID] = 10, _b),
                    HeroExp: (_c = {}, _c[HeroNames.Widow.ID] = 20, _c),
                }) },
        ],
    }),
    Cosmic_code_122024: new PromoCode({
        ID: 186,
        OneTimeCode: false,
        OneTimeReward: false,
        ExpireTime: new Date('2025-01-12').getTime(),
        RewardSettings: [
            {
                chests: [
                    chests.Emoji_chest.ID,
                    chests.Observatory_chest.ID, chests.Observatory_chest.ID, chests.Observatory_chest.ID
                ]
            },
        ],
    }),
    LegionKingReactivateMail: new PromoCode({
        ID: 284,
        OneTimeCode: false,
        OneTimeReward: false,
        ExpireTime: EventTimeConstants.Leg_Skins_2025.event.end,
        RewardSettings: [
            { loot: new Loot({
                    Currencies: (_d = {},
                        _d[CURRENCY.BONUS] = 50,
                        _d[CURRENCY.TOKEN_2] = 2500,
                        _d[CURRENCY.TICKET_2] = 25,
                        _d[CURRENCY.CHIP_2] = 250,
                        _d)
                }) },
        ],
    }),
    Raikichi_promo: new PromoCode({
        ID: 285,
        OneTimeCode: false,
        OneTimeReward: false,
        ExpireTime: new Date("2025-07-31").getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Currencies: (_e = {},
                        _e[CURRENCY.BONUS] = 100,
                        _e[CURRENCY.GACHA_KEY] = 5,
                        _e)
                }),
                chests: [chests.Medium_Shard_Chest.ID] },
        ],
    }),
    promo_NP_Marcus_weapon: new PromoCode({
        ID: 287,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Weapons: [heroWeapons.wpn_Marcus_R_Ninja_Party.ID]
                }),
                chests: [chests.Small_Shard_Chest.ID,],
            },
        ],
    }),
    promocode_for_tournaments: new PromoCode({
        ID: 288,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-05").getTime(),
        RewardSettings: [{
                chests: [chests.Epic_chest.ID,],
            },
        ],
    }),
    promocode_20250805_1: new PromoCode({
        ID: 289,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-05").getTime(),
        RewardSettings: [{
                chests: [chests.Summer_event_chest.ID, chests.Summer_event_chest.ID,],
            },
        ],
    }),
    promocode_20250805_2: new PromoCode({
        ID: 290,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-29").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_f = {}, _f[CURRENCY.TICKET_1] = 20, _f),
                    Weapons: [heroWeapons.wpn_Monkey_King_R_base_Rec_Summer.ID]
                })
            },
        ],
    }),
    promocode_20250805_3: new PromoCode({
        ID: 291,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-05").getTime(),
        RewardSettings: [{
                chests: [chests.Large_Shard_Chest_New_Hero.ID,],
            },
        ],
    }),
    promocode_20250805_4: new PromoCode({
        ID: 292,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-29").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_g = {}, _g[CURRENCY.CHIP_1] = 200, _g),
                    Weapons: [heroWeapons.wpn_Jet_R_Golden_Rec_Summer.ID]
                })
            },
        ],
    }),
    legendary_kibo_skin_2: new PromoCode({
        ID: 294,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2026-01-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Skins: [skins.Kibo_L_Eclipse.ID, skins.Lynx_L_Hood.ID, skins.Itu_L_Cosmic.ID, skins.Legion_King_L_Castle.ID],
                    Stances: [stances.stance_Kibo_E_Eclipse.ID, stances.stance_Lynx_E_shadow.ID, stances.win_Itu_E_location.ID, stances.win_Legion_King_E_statue.ID],
                    Emoji: [emoji.Kibo_Eclipse.ID, emoji.Lynx_Disappearance.ID, emoji.Itu_Hourglass.ID, emoji.Legion_King_ReachesOut.ID],
                })
            },
        ],
    }),
    advent_calendar_20250821_1: new PromoCode({
        ID: 295,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-05").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    TextEmojiPacks: [textEmojiPacks.nekkiFest2025.ID],
                }),
                chests: [chests.Medium_Shard_Chest.ID],
            },
        ],
    }),
    advent_calendar_20250821_2: new PromoCode({
        ID: 296,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-09-05").getTime(),
        RewardSettings: [{
                chests: [chests.Epic_chest.ID, chests.Small_Shard_Chest.ID],
            },
        ],
    }),
    promocode_rubies_264: new PromoCode({
        ID: 297,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2026-11-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_h = {}, _h[CURRENCY.BONUS] = 264, _h),
                })
            },
        ],
    }),
    promocode_rubies_550: new PromoCode({
        ID: 298,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2026-11-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_j = {}, _j[CURRENCY.BONUS] = 550, _j),
                })
            },
        ],
    }),
    promocode_rubies_1815: new PromoCode({
        ID: 299,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2026-11-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_k = {}, _k[CURRENCY.BONUS] = 1815, _k),
                })
            },
        ],
    }),
    promocode_rubies_3300: new PromoCode({
        ID: 300,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2026-11-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_l = {}, _l[CURRENCY.BONUS] = 3300, _l),
                })
            },
        ],
    }),
    event_nonna: new PromoCode({
        ID: 301,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2025-11-25").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_m = {},
                        _m[CURRENCY.TICKET_2] = 30,
                        _m[CURRENCY.CHIP_2] = 1250,
                        _m[CURRENCY.TOKEN_3] = 750,
                        _m),
                    Shards: (_o = {}, _o[HeroNames.Nonna.ID] = 1, _o)
                })
            },
        ],
    }),
    weapon_chest_261125: new PromoCode({
        ID: 303,
        OneTimeCode: true,
        OneTimeReward: true,
        ExpireTime: new Date("2027-01-01").getTime(),
        RewardSettings: [{
                chests: [chests.Weapon_chest.ID]
            },
        ],
    }),
    large_shard_chest_new_hero_181225: new PromoCode({
        ID: 304,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2025-12-26').getTime(),
        RewardSettings: [
            { chests: [chests.Large_Shard_Chest_New_Hero.ID] },
        ],
    }),
    legendary_mk_skin_1: new PromoCode({
        ID: 305,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2027-01-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Skins: [skins.Monkey_King_L_Crystal.ID],
                    Stances: [stances.win_Monkey_King_E_Statue.ID],
                    Emoji: [emoji.MonkeyKing_Crystal.ID]
                })
            },
        ],
    }),
    event_ny_2025: new PromoCode({
        ID: 306,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date("2026-01-13").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_p = {},
                        _p[CURRENCY.TICKET_1] = 20,
                        _p[CURRENCY.CHIP_1] = 150,
                        _p[CURRENCY.TOKEN_1] = 5000,
                        _p[CURRENCY.AD_TOKEN] = 12,
                        _p),
                })
            },],
    }),
    FightPass_unlock_3: new PromoCode({
        ID: 307,
        UnlockCurrentBattlePassPremium: true,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
    }),
    FightPass_subscription_3: new PromoCode({
        ID: 308,
        SubscriptionDays: 30,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
    }),
    Gacha_key_1_4: new PromoCode({
        ID: 309,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.GACHA_KEY] = 1, _q) }) },
        ],
    }),
    Rubies_240_3: new PromoCode({
        ID: 310,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.BONUS] = 240, _r) }) },
        ],
    }),
    Rubies_500_3: new PromoCode({
        ID: 311,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.BONUS] = 500, _s) }) },
        ],
    }),
    Rubies_1100_3: new PromoCode({
        ID: 312,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.BONUS] = 1100, _t) }) },
        ],
    }),
    Rubies_3000_3: new PromoCode({
        ID: 313,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.BONUS] = 3000, _u) }) },
        ],
    }),
    Rubies_6500_3: new PromoCode({
        ID: 314,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.BONUS] = 6500, _v) }) },
        ],
    }),
    Rubies_14000_3: new PromoCode({
        ID: 315,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.BONUS] = 14000, _w) }) },
        ],
    }),
    Itu_legendary_pack: new PromoCode({
        ID: 316,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Itu_L_Cosmic.ID],
                    Stances: [stances.win_Itu_E_location.ID],
                    Emoji: [emoji.Itu_Hourglass.ID],
                }) },
        ],
    }),
    skin_hero_Ironclad_E_Rust_2_23012025: new PromoCode({
        ID: 317,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Ironclad_E_Rust.ID],
                }) },
        ],
    }),
    skin_hero_Monk_E_White_2_23012025: new PromoCode({
        ID: 318,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Monk_E_Cursed_Rec_White.ID],
                }) },
        ],
    }),
    skin_hero_Yukka_E_Cat_2_23012025: new PromoCode({
        ID: 319,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Yukka_E_Cat.ID],
                }) },
        ],
    }),
    skin_hero_Kibo_E_Oriental_2_23012025: new PromoCode({
        ID: 320,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Kibo_E_Oriental_skin.ID],
                }) },
        ],
    }),
    New_year_skin_hero_Midnight_E_Ghost_2_23012025: new PromoCode({
        ID: 321,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Midnight_E_Ghost.ID]
                }) },
        ],
    }),
    skin_hero_Midnight_R_Blue_2_23012025: new PromoCode({
        ID: 322,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Midnight_R_Blue.ID],
                }) },
        ],
    }),
    Birthday_arena_skin_for_Ling_2_23012025: new PromoCode({
        ID: 323,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Ling_E_Samurai_Rec_Gold_skin.ID] }) },
        ],
    }),
    Ling_E_Samurai_skin_23012025: new PromoCode({
        ID: 324,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Ling_E_Samurai_skin.ID] }) },
        ],
    }),
    Bulwark_E_Gold_skin_23012025: new PromoCode({
        ID: 325,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Bulwark_E_Gold_skin.ID] }) },
        ],
    }),
    HongJoo_E_Equilibrist_skin_23012025: new PromoCode({
        ID: 326,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.HongJoo_E_Equilibrist_skin.ID] }) },
        ],
    }),
    Jet_E_Golden_23012025: new PromoCode({
        ID: 327,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Jet_E_Golden.ID] }) },
        ],
    }),
    Marcus_E_Royal_skin_23012025: new PromoCode({
        ID: 328,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Marcus_E_Royal_skin.ID] }) },
        ],
    }),
    Emperor_E_Doomed_skin_23012025: new PromoCode({
        ID: 329,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Emperor_E_Doomed_skin.ID] }) },
        ],
    }),
    Feldsher_E_Suit_skin_23012025: new PromoCode({
        ID: 330,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Feldsher_E_Suit_skin.ID] }) },
        ],
    }),
    skin_hero_Ling_E_Raven_23012025: new PromoCode({
        ID: 331,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Ling_E_Raven.ID] }) },
        ],
    }),
    skin_hero_monkeyking_E_stranger_23012025: new PromoCode({
        ID: 332,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Monkey_King_E_Stranger.ID] }) },
        ],
    }),
    skin_hero_Lynx_E_Original_23012025: new PromoCode({
        ID: 333,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) },
        ],
    }),
    skin_hero_Legion_King_E_Bone_23012025: new PromoCode({
        ID: 334,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Legion_King_E_Bone.ID] }) },
        ],
    }),
    skin_hero_Itu_E_Demon_23012025: new PromoCode({
        ID: 335,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Itu_E_Demon.ID] }) },
        ],
    }),
    skin_hero_Viper_E_Graffiti_23012025: new PromoCode({
        ID: 336,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Viper_E_Grafitti.ID] }) },
        ],
    }),
    skin_hero_Sarge_E_Jailer_23012025: new PromoCode({
        ID: 337,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Sarge_E_Jailer.ID] }) },
        ],
    }),
    skin_Ironclad_E_Gladiator_23012025: new PromoCode({
        ID: 338,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Ironclad_E_Gladiator.ID] }) },
        ],
    }),
    skin_hero_Helga_E_Phoenix_23012025: new PromoCode({
        ID: 339,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Helga_E_Phoenix_skin.ID] }) },
        ],
    }),
    skin_hero_Fireguard_E_White_Rec_Void_23012025: new PromoCode({
        ID: 340,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Fireguard_E_White_Rec_Void.ID] }) },
        ],
    }),
    Feldsher_E_Plague_23012025: new PromoCode({
        ID: 341,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Feldsher_E_Plague.ID] }) },
        ],
    }),
    Yunlin_E_Bride_23012025: new PromoCode({
        ID: 342,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Yunlin_E_Bride.ID] }) },
        ],
    }),
    skin_hero_Lynx_E_Mafia_23012025: new PromoCode({
        ID: 343,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Lynx_E_Mafia.ID],
                }) },
        ],
    }),
    skin_hero_Sarge_E_Chitin_23012025: new PromoCode({
        ID: 344,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Sarge_E_Chitin.ID],
                }) },
        ],
    }),
    skin_hero_Feldsher_E_Plague_Rec_Vampire_23012025: new PromoCode({
        ID: 345,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Feldsher_E_Plague_Rec_Vampire.ID],
                }) },
        ],
    }),
    skin_pack_1_24_23012025: new PromoCode({
        ID: 346,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [
                        skins.Lynx_E_Mafia.ID,
                        skins.Viper_E_Mobster.ID,
                        skins.Itu_E_Master.ID,
                    ],
                }) },
        ],
    }),
    skin_pack_2_24_23012025: new PromoCode({
        ID: 347,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [
                        skins.Bulwark_E_Snow_skin.ID,
                        skins.Liquidator_E_Valkyrie.ID,
                        skins.Sarge_E_Viking.ID,
                    ],
                }) },
        ],
    }),
    skin_pack_3_24_23012025: new PromoCode({
        ID: 348,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [
                        skins.Legion_King_R_Rec_Boss.ID,
                        skins.Bulwark_R_Rec_Boss_skin.ID,
                        skins.Liquidator_R_Rec_Boss.ID,
                    ],
                }) },
        ],
    }),
    skin_pack_4_24_23012025: new PromoCode({
        ID: 349,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [
                        skins.Jet_E_Nomad.ID,
                        skins.HongJoo_E_Pilgrim.ID,
                        skins.Yukka_E_Wayfarer.ID,
                    ],
                }) },
        ],
    }),
    lynx_pack_24_23012025: new PromoCode({
        ID: 350,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Lynx_L_Hood.ID],
                    Stances: [stances.stance_Lynx_E_shadow.ID],
                    Emoji: [emoji.Lynx_Disappearance.ID],
                }) },
        ],
    }),
    skin_hero_Gideon_E_Mask_23012025: new PromoCode({
        ID: 351,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Gideon_E_Mask.ID],
                }) },
        ],
    }),
    skin_hero_Itu_E_Master_23012025: new PromoCode({
        ID: 352,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Itu_E_Master.ID],
                }) },
        ],
    }),
    skin_hero_Feldsher_E_Diver_23012025: new PromoCode({
        ID: 353,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Feldsher_E_Diver.ID],
                }) },
        ],
    }),
    skin_hero_Emperor_E_Dragon_23012025: new PromoCode({
        ID: 354,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Emperor_E_Dragon_skin.ID],
                }) },
        ],
    }),
    shards_for_hero_23_Ling_23012025: new PromoCode({
        ID: 355,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_x = {}, _x[HeroNames.Ling.ID] = 10, _x) }) },
        ],
    }),
    shards_for_hero_23_Monk_23012025: new PromoCode({
        ID: 356,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_y = {}, _y[HeroNames.Monk.ID] = 10, _y) }) },
        ],
    }),
    shards_for_hero_23_Liquidator_23012025: new PromoCode({
        ID: 357,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_z = {}, _z[HeroNames.Liquidator.ID] = 10, _z) }) },
        ],
    }),
    shards_for_hero_23_Ironclad_23012025: new PromoCode({
        ID: 358,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_0 = {}, _0[HeroNames.Ironclad.ID] = 10, _0) }) },
        ],
    }),
    shards_for_hero_23_Fireguard_23012025: new PromoCode({
        ID: 359,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_1 = {}, _1[HeroNames.Fireguard.ID] = 10, _1) }) },
        ],
    }),
    shards_for_hero_23_Helga_23012025: new PromoCode({
        ID: 360,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_2 = {}, _2[HeroNames.Helga.ID] = 10, _2) }) },
        ],
    }),
    shards_for_hero_23_Jet_23012025: new PromoCode({
        ID: 361,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_3 = {}, _3[HeroNames.Jet.ID] = 10, _3) }) },
        ],
    }),
    shards_for_hero_23_Midnight_23012025: new PromoCode({
        ID: 362,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_4 = {}, _4[HeroNames.Midnight.ID] = 10, _4) }) },
        ],
    }),
    shards_for_hero_23_Feldsher_23012025: new PromoCode({
        ID: 363,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_5 = {}, _5[HeroNames.Feldsher.ID] = 10, _5) }) },
        ],
    }),
    shards_for_hero_23_Yukka_23012025: new PromoCode({
        ID: 364,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_6 = {}, _6[HeroNames.Yukka.ID] = 10, _6) }) },
        ],
    }),
    shards_for_hero_23_Bulwark_23012025: new PromoCode({
        ID: 365,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_7 = {}, _7[HeroNames.Bulwark.ID] = 10, _7) }) },
        ],
    }),
    shards_for_hero_23_Emperor_23012025: new PromoCode({
        ID: 366,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_8 = {}, _8[HeroNames.Emperor.ID] = 10, _8) }) },
        ],
    }),
    shards_for_hero_23_Kibo_23012025: new PromoCode({
        ID: 367,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_9 = {}, _9[HeroNames.Kibo.ID] = 10, _9) }) },
        ],
    }),
    shards_for_hero_23_Marcus_23012025: new PromoCode({
        ID: 368,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_10 = {}, _10[HeroNames.Marcus.ID] = 10, _10) }) },
        ],
    }),
    shards_for_hero_23_Sarge_23012025: new PromoCode({
        ID: 369,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_11 = {}, _11[HeroNames.Sarge.ID] = 10, _11) }) },
        ],
    }),
    shards_for_hero_23_HongJoo_23012025: new PromoCode({
        ID: 370,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_12 = {}, _12[HeroNames.HongJoo.ID] = 10, _12) }) },
        ],
    }),
    shards_for_hero_23_Lynx_23012025: new PromoCode({
        ID: 371,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_13 = {}, _13[HeroNames.Lynx.ID] = 10, _13) }) },
        ],
    }),
    shards_for_hero_23_Monkey_King_23012025: new PromoCode({
        ID: 372,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_14 = {}, _14[HeroNames.Monkey_King.ID] = 10, _14) }) },
        ],
    }),
    shards_for_hero_23_Viper_23012025: new PromoCode({
        ID: 373,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_15 = {}, _15[HeroNames.Viper.ID] = 10, _15) }) },
        ],
    }),
    shards_for_hero_23_Legion_King_23012025: new PromoCode({
        ID: 374,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_16 = {}, _16[HeroNames.Legion_King.ID] = 10, _16) }) },
        ],
    }),
    shards_for_hero_23_Butcher_23012025: new PromoCode({
        ID: 375,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_17 = {}, _17[HeroNames.Butcher.ID] = 10, _17) }) },
        ],
    }),
    shards_for_hero_23_Itu_23012025: new PromoCode({
        ID: 376,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_18 = {}, _18[HeroNames.Itu.ID] = 10, _18) }) },
        ],
    }),
    shards_for_hero_23_Yunlin_23012025: new PromoCode({
        ID: 377,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_19 = {}, _19[HeroNames.Yunlin.ID] = 10, _19) }) },
        ],
    }),
    shards_for_hero_23_Xiang_Tzu_23012025: new PromoCode({
        ID: 378,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_20 = {}, _20[HeroNames.Xiang_Tzu.ID] = 10, _20) }) },
        ],
    }),
    shards_for_hero_24_June_23012025: new PromoCode({
        ID: 379,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_21 = {}, _21[HeroNames.June.ID] = 10, _21) }) },
        ],
    }),
    Gideon_shard_23012025: new PromoCode({
        ID: 380,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_22 = {}, _22[heroes.Gideon.ID] = 10, _22) }) },
        ],
    }),
    Widow_shard_23012025: new PromoCode({
        ID: 381,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Shards: (_23 = {}, _23[heroes.Widow.ID] = 10, _23) }) },
        ],
    }),
    LegionKingLegendaryKit: new PromoCode({
        ID: 382,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Legion_King_L_Castle.ID],
                    Stances: [stances.win_Legion_King_E_statue.ID],
                    Emoji: [emoji.Legion_King_ReachesOut.ID],
                }) },
        ],
    }),
    hero_Raikichi: new PromoCode({
        ID: 383,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2027-01-01").getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Shards: (_24 = {},
                        _24[heroes.Raikichi.ID] = heroes.Raikichi.ShardsNeeded,
                        _24)
                }),
            },
        ],
    }),
    legendary_kibo_skin_1: new PromoCode({
        ID: 384,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2027-01-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Skins: [skins.Kibo_L_Eclipse.ID],
                    Stances: [stances.stance_Kibo_E_Eclipse.ID],
                    Emoji: [emoji.Kibo_Eclipse.ID]
                })
            },
        ],
    }),
    nonna: new PromoCode({
        ID: 385,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date("2027-01-01").getTime(),
        RewardSettings: [{
                loot: new Loot({
                    Shards: (_25 = {}, _25[HeroNames.Nonna.ID] = heroes.Nonna.ShardsNeeded, _25)
                })
            },
        ],
    }),
    common_chest: new PromoCode({
        ID: 386,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { chests: [chests.Common_chest.ID] },
        ],
    }),
    rare_chest: new PromoCode({
        ID: 387,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { chests: [chests.Rare_chest.ID] },
        ],
    }),
    emoji_chest_4: new PromoCode({
        ID: 388,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { chests: [chests.Emoji_chest.ID] },
        ],
    }),
    skin_chest_2: new PromoCode({
        ID: 389,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { chests: [chests.Skin_chest.ID] },
        ],
    }),
    weapon_chest: new PromoCode({
        ID: 390,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            {
                chests: [chests.Weapon_chest.ID],
            },
        ],
    }),
    Sarge_BanHammer: new PromoCode({
        ID: 391,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Emoji: [emoji.Sarge_BanHammer.ID],
                }) },
        ],
    }),
    wpn_Feldsher_E_RedVampire_13012026: new PromoCode({
        ID: 392,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_E_RedVampire.ID] }) },
        ],
    }),
    wpn_Monkey_King_E_Nephritis_13012026: new PromoCode({
        ID: 393,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_E_Nephritis.ID] }) },
        ],
    }),
    wpn_HongJoo_E_FireShow_13012026: new PromoCode({
        ID: 394,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_E_FireShow.ID] }) },
        ],
    }),
    wpn_Lynx_E_Legacy_2_13012026: new PromoCode({
        ID: 395,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Lynx_E_Legacy.ID],
                }) },
        ],
    }),
    wpn_Sarge_E_Burn_2_13012026: new PromoCode({
        ID: 396,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Sarge_E_Burn.ID],
                }) },
        ],
    }),
    wpn_Marcus_E_Lava_2_13012026: new PromoCode({
        ID: 397,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Marcus_E_Lava.ID],
                }) },
        ],
    }),
    wpn_Kibo_E_RedVampire_2_13012026: new PromoCode({
        ID: 398,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID],
                }) },
        ],
    }),
    wpn_Liquidator_E_Obsidians_2_13012026: new PromoCode({
        ID: 399,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Liquidator_E_Obsidians.ID],
                }) },
        ],
    }),
    wpn_Monk_E_Druid_2_13012026: new PromoCode({
        ID: 400,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Monk_E_Druid.ID],
                }) },
        ],
    }),
    wpn_Marcus_E_Knight_13012026: new PromoCode({
        ID: 401,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Marcus_E_Knight.ID] }) },
        ],
    }),
    wpn_Helga_E_White_Star_13012026: new PromoCode({
        ID: 402,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_E_White_Star.ID] }) },
        ],
    }),
    wpn_Bulwark_E_Pike_13012026: new PromoCode({
        ID: 403,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_E_Pike.ID] }) },
        ],
    }),
    wpn_Jet_E_Prism_Alias_13012026: new PromoCode({
        ID: 404,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) },
        ],
    }),
    wpn_Ling_E_Shadow_Edge_13012026: new PromoCode({
        ID: 405,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_E_Shadow_Edge.ID] }) },
        ],
    }),
    wpn_Emperor_E_Stone_Gloves_13012026: new PromoCode({
        ID: 406,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) },
        ],
    }),
    wpn_Midnight_E_Cold_13012026: new PromoCode({
        ID: 407,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) },
        ],
    }),
    wpn_Ironclad_E_Puffer_13012026: new PromoCode({
        ID: 408,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_E_Puffer.ID] }) },
        ],
    }),
    wpn_Helga_E_Black_Star_13012026: new PromoCode({
        ID: 409,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Helga_E_Black_Star.ID],
                }) },
        ],
    }),
    wpn_Itu_E_Vortex_13012026: new PromoCode({
        ID: 410,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Itu_E_Vortex.ID],
                }) },
        ],
    }),
    wpn_Sarge_E_Cage_13012026: new PromoCode({
        ID: 411,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Sarge_E_Cage.ID],
                }) },
        ],
    }),
    wpn_Yukka_E_Wind_13012026: new PromoCode({
        ID: 412,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Yukka_E_Wind.ID],
                }) },
        ],
    }),
    wpn_Fireguard_E_Bones_13012026: new PromoCode({
        ID: 413,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Fireguard_E_Bones.ID],
                }) },
        ],
    }),
    wpn_Viper_E_Chargeboom_13012026: new PromoCode({
        ID: 414,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Viper_E_Chargeboom.ID],
                }) },
        ],
    }),
    wpn_Legion_King_E_Witchblade_13012026: new PromoCode({
        ID: 415,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Legion_King_E_Witchblade.ID],
                }) },
        ],
    }),
    wpn_Legion_King_E_Abyssblade_13012026: new PromoCode({
        ID: 416,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Legion_King_E_Abyssblade.ID],
                }) },
        ],
    }),
    wpn_YunLin_E_Golden_Red_Alias_13012026: new PromoCode({
        ID: 417,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Yunlin_E_Golden_Red.ID],
                }) },
        ],
    }),
    wpn_Butcher_E_Gluttony_13012026: new PromoCode({
        ID: 418,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Butcher_E_Gluttony.ID] }) },
        ],
    }),
    wpn_Xiang_Tzu_E_Stolen_13012026: new PromoCode({
        ID: 419,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_E_Stealer.ID] }) },
        ],
    }),
    wpn_Gideon_E_Fiery_13012026: new PromoCode({
        ID: 420,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Gideon_E_Fiery.ID] }) },
        ],
    }),
    wpn_Widow_E_Waves_13012026: new PromoCode({
        ID: 421,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Widow_E_Waves.ID] }) },
        ],
    }),
    wpn_Raikichi_E_Burned_13012026: new PromoCode({
        ID: 422,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Raikichi_E_Burned.ID] }) },
        ],
    }),
    All_modifiers_13012026: new PromoCode({
        ID: 423,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Modifiers: (_26 = {}, _26[buffModifiers.twoBuffPerChoice.ID] = 1, _26) }) },
            { loot: new Loot({ Modifiers: (_27 = {}, _27[buffModifiers.timerBuff.ID] = 1, _27) }) },
            { loot: new Loot({ Modifiers: (_28 = {}, _28[buffModifiers.epicBuffs.ID] = 1, _28) }) },
        ],
    }),
    event_currency_chip_750_promo: new PromoCode({
        ID: 424,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-02-03').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.CHIP_2] = 750, _29) }) },
        ],
    }),
    monkey_King_L_Crystal_promo: new PromoCode({
        ID: 425,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Monkey_King_L_Crystal.ID] }) },
        ],
    }),
    legion_King_L_Castle_promo: new PromoCode({
        ID: 426,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Legion_King_L_Castle.ID] }) },
        ],
    }),
    kibo_L_Eclipse_promo: new PromoCode({
        ID: 427,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Kibo_L_Eclipse.ID] }) },
        ],
    }),
    itu_L_Cosmic_promo: new PromoCode({
        ID: 428,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Itu_L_Cosmic.ID] }) },
        ],
    }),
    lynx_L_Hood_promo: new PromoCode({
        ID: 429,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2027-01-01').getTime(),
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Lynx_L_Hood.ID] }) },
        ],
    }),
    currency_0216_1_promo: new PromoCode({
        ID: 430,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-02-16').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_30 = {}, _30[CURRENCY.CHIP_1] = 375, _30) }) },
        ],
    }),
    currency_0216_2_promo: new PromoCode({
        ID: 431,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-02-16').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_31 = {}, _31[CURRENCY.CHIP_1] = 1800, _31) }) },
            { loot: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.TICKET_1] = 35, _32) }) },
        ],
    }),
    currency_0302_promo: new PromoCode({
        ID: 432,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-03-02').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_33 = {}, _33[CURRENCY.CHIP_2] = 450, _33) }) },
        ],
    }),
    currency_0302_2_promo: new PromoCode({
        ID: 433,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-03-02').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.CHIP_2] = 3250, _34) }) },
            { loot: new Loot({ Currencies: (_35 = {}, _35[CURRENCY.TICKET_2] = 30, _35) }) },
        ],
    }),
    chinese_rewards_promo: new PromoCode({
        ID: 434,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-03-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_R_Base_Rec_CNY.ID] }) },
            { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Equilibrist_Rec_CNY.ID] }) },
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Yunlin_R_Base_Rec_CNY.ID] }) },
        ],
    }),
    event_rewards_1603_1_promo: new PromoCode({
        ID: 435,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-03-16').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_36 = {}, _36[CURRENCY.CHIP_1] = 450, _36) }) },
        ],
    }),
    event_rewards_1603_2_promo: new PromoCode({
        ID: 436,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-03-16').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.CHIP_1] = 3250, _37) }) },
            { loot: new Loot({ Currencies: (_38 = {}, _38[CURRENCY.TICKET_1] = 30, _38) }) },
        ],
    }),
    event_rewards_06042026_1: new PromoCode({
        ID: 437,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-04-06').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_39 = {}, _39[CURRENCY.CHIP_2] = 600, _39) }) },
        ],
    }),
    event_rewards_06042026_2: new PromoCode({
        ID: 438,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-04-06').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_40 = {}, _40[CURRENCY.CHIP_2] = 3200, _40) }) },
            { loot: new Loot({ Currencies: (_41 = {}, _41[CURRENCY.TICKET_2] = 30, _41) }) },
        ],
    }),
    butcher_leg_weapon_1: new PromoCode({
        ID: 439,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-04-28').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_42 = {}, _42[CURRENCY.CHIP_1] = 450, _42) }) },
        ],
    }),
    butcher_leg_weapon_2: new PromoCode({
        ID: 440,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-04-28').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.CHIP_1] = 2300, _43) }) },
            { loot: new Loot({ Currencies: (_44 = {}, _44[CURRENCY.TICKET_1] = 30, _44) }) },
        ],
    }),
    butcher_leg_weapon_3: new PromoCode({
        ID: 441,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-04-28').getTime(),
        RewardSettings: [
            { loot: new Loot({ Currencies: (_45 = {}, _45[CURRENCY.CHIP_1] = 450, _45) }) },
            { loot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.TICKET_1] = 20, _46) }) },
        ],
    }),
    shard_chest_1_9_70_20: new PromoCode({
        ID: 442,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-04-29').getTime(),
        RewardSettings: [
            { chests: [
                    chests.Large_Shard_Chest_New_Hero.ID,
                    chests.Butcher_legendary_weapon_chest.ID,
                ] },
        ],
    }),
    wpn_Butcher_L_Gore_1_9_70_30: new PromoCode({
        ID: 443,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Butcher_L_Gore.ID] }) },
        ],
    }),
    code_1_9_70_50_1: new PromoCode({
        ID: 444,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-05-25').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_47 = {}, _47[CURRENCY.CHIP_1] = 375, _47) }) },
        ],
    }),
    code_1_9_70_50_2: new PromoCode({
        ID: 445,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-05-25').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_48 = {}, _48[CURRENCY.CHIP_1] = 1350, _48[CURRENCY.TICKET_1] = 30, _48) }) },
        ],
    }),
    code_1_9_70_50_3: new PromoCode({
        ID: 446,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Ironclad_L_Minotaur.ID],
                    Stances: [stances.stance_Ironclad_E_wall.ID],
                    Emoji: [emoji.Ironclad_Steam.ID],
                }) },
        ],
    }),
    code_1_9_70_70_1: new PromoCode({
        ID: 447,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-06-08').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_49 = {}, _49[CURRENCY.CHIP_2] = 375, _49) }) },
        ],
    }),
    code_1_9_70_70_2: new PromoCode({
        ID: 448,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-06-08').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.TICKET_2] = 30, _50[CURRENCY.CHIP_2] = 2850, _50) }) },
        ],
    }),
    code_1_9_70_70_3: new PromoCode({
        ID: 449,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({
                    Weapons: [heroWeapons.wpn_Midnight_E_Feather.ID],
                }) },
        ],
    }),
    code_1_9_70_90_1: new PromoCode({
        ID: 450,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-06-22').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_51 = {}, _51[CURRENCY.CHIP_1] = 375, _51) }) },
        ],
    }),
    code_1_9_70_90_2: new PromoCode({
        ID: 451,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-06-22').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_52 = {}, _52[CURRENCY.CHIP_1] = 2300, _52[CURRENCY.TICKET_1] = 30, _52) }) },
        ],
    }),
    code_1_9_70_90_3: new PromoCode({
        ID: 452,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Sarge_E_Sunny.ID] }) },
        ],
    }),
    code_1_9_70_110_1: new PromoCode({
        ID: 453,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: new Date('2026-07-06').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_53 = {}, _53[CURRENCY.CHIP_2] = 450, _53) }) },
        ],
    }),
    code_1_9_70_110_2: new PromoCode({
        ID: 454,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-07-06').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_54 = {}, _54[CURRENCY.CHIP_2] = 3200, _54[CURRENCY.TICKET_2] = 30, _54) }) },
        ],
    }),
    code_1_9_70_110_3: new PromoCode({
        ID: 455,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Skins: [skins.Midnight_E_Shinobi.ID] }) },
        ],
    }),
    code_1_9_70_110_4: new PromoCode({
        ID: 456,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_E_Diver.ID] }) },
        ],
    }),
    code_1_9_70_120: new PromoCode({
        ID: 457,
        SubscriptionDays: 30,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: new Date('2026-12-31').getTime() + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({
                    Skins: [skins.Itu_L_Cosmic.ID],
                    Stances: [stances.win_Itu_E_location.ID],
                    Emoji: [emoji.Itu_Hourglass.ID],
                    Shards: (_55 = {},
                        _55[HeroNames.Itu.ID] = 10,
                        _55[HeroNames.Legion_King.ID] = 10,
                        _55[HeroNames.Raikichi.ID] = 10,
                        _55[HeroNames.Widow.ID] = 10,
                        _55[HeroNames.Nonna.ID] = 10,
                        _55)
                }) },
        ],
    }),
    code_1_9_80_5__1: new PromoCode({
        ID: 458,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('08.07.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [{
                loot: new Loot({
                    Currencies: (_56 = {}, _56[CURRENCY.BONUS] = 500, _56),
                }),
                chests: [
                    chests.Butcher_legendary_weapon_chest.ID,
                    chests.Large_Shard_Chest_New_Hero.ID,
                ],
            }],
    }),
    code_1_9_80_10__1: new PromoCode({
        ID: 459,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('31.12.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({
                    Shards: (_57 = {},
                        _57[HeroNames.Shogun.ID] = 10,
                        _57)
                }) },
        ],
    }),
    code_1_9_80_10__2: new PromoCode({
        ID: 460,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('20.07.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_58 = {}, _58[CURRENCY.CHIP_1] = 750, _58) }) },
        ],
    }),
    code_1_9_80_10__3: new PromoCode({
        ID: 461,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('20.07.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_59 = {}, _59[CURRENCY.CHIP_1] = 4500, _59[CURRENCY.TICKET_1] = 30, _59) }) },
        ],
    }),
    code_1_9_80_30__1: new PromoCode({
        ID: 462,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('31.12.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Weapons: [heroWeapons.wpn_Gideon_E_Hunter.ID] }) },
        ],
    }),
    code_1_9_80_30__2: new PromoCode({
        ID: 463,
        OneTimeCode: false,
        OneTimeReward: true,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('03.08.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_60 = {}, _60[CURRENCY.CHIP_2] = 450, _60) }) },
        ],
    }),
    code_1_9_80_30__3: new PromoCode({
        ID: 464,
        OneTimeCode: true,
        OneTimeReward: false,
        ExpireTime: Time.convertEuropeanDateToTimestampMs('03.08.2026') + new Time({ Days: 1 }).value,
        RewardSettings: [
            { loot: new Loot({ Currencies: (_61 = {}, _61[CURRENCY.CHIP_2] = 3200, _61[CURRENCY.TICKET_2] = 30, _61) }) },
        ],
    }),
};
var promoCodesMap = createIDMap(promoCodes, "promoCodesMap");
