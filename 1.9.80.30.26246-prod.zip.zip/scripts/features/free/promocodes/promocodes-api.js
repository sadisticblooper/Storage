function getPromoCodeById(id) {
    return promoCodesMap.get(id);
}
function generateLootFromPromoCode(settings) {
    return PromoCode.generateLootFromPromoCode(settings);
}
function canUsePromoCode(settings) {
    var platform = settings.platform;
    var blockedPlatforms = [];
    if (isIOSApproveInProgress) {
        blockedPlatforms.push.apply(blockedPlatforms, IOS_PLATFORMS);
    }
    return blockedPlatforms.indexOf(platform) == -1;
}
