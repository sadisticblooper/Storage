var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var CombinedRewards = (function () {
    function CombinedRewards(settings) {
        var chestQueuePositions = settings.chestQueuePositions, chestSeed = settings.chestSeed, commonSeed = settings.commonSeed, enableCombiningWithPlayer = settings.enableCombiningWithPlayer, playerProgress = settings.playerProgress;
        this.state = {
            fullLoot: new Loot(),
            chestQueuePositions: __assign({}, chestQueuePositions),
            chestSeed: chestSeed,
            commonSeed: commonSeed,
            playerProgress: deepCopyOverJSON(playerProgress)
        };
    }
    CombinedRewards.prototype.addReward = function (reward, startTimeOfCurrentDayMS) {
        var state = this.state;
        var rewardLoot = new Loot();
        var rewardChests = [];
        if (!reward) {
            return {
                Chests: rewardChests,
                Loot: rewardLoot,
            };
        }
        if (reward.Loot && !reward.Loot.isEmpty()) {
            rewardLoot.combineLoot(reward.Loot);
            HeroUtils.combineLoot(state.playerProgress, reward.Loot);
            state.fullLoot.combineLoot(reward.Loot);
        }
        if (reward.Chests && reward.Chests.length) {
            var ids = reward.Chests.sort(function (id1, id2) { return id1 - id2; });
            for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                var id = ids_1[_i];
                var chestResult = generateLootFromChest({
                    PlayerProgress: state.playerProgress,
                    ChestID: id,
                    ChestArena: state.playerProgress.playerArenaId,
                    ChestQueuePositions: state.chestQueuePositions,
                    Seed: state.chestSeed,
                    StartTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
                });
                state.chestSeed = chestResult.NewSeed;
                state.chestQueuePositions = chestResult.ChestQueuePositions;
                rewardChests.push({ ID: id, Loot: chestResult.Loot });
                HeroUtils.combineLoot(state.playerProgress, chestResult.Loot);
                state.fullLoot.combineLoot(chestResult.Loot);
            }
        }
        state.commonSeed = reward.NewSeed;
        return {
            Chests: rewardChests,
            Loot: rewardLoot,
        };
    };
    CombinedRewards.prototype.getState = function () {
        return this.state;
    };
    return CombinedRewards;
}());
