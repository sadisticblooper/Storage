var ConversionUtils = (function () {
    function ConversionUtils() {
    }
    ConversionUtils.getConversionLoot = function (settings) {
        var lootCompensator = LootCompensationFacade.getLootCompensator(settings.Place);
        var isBpConversion = BattlePass.doNeedConvertBattlePassPoints(settings.BattlePassProgress);
        var result = {
            ConvertedData: {
                cards: {},
                shards: {},
                battlePassPoints: null,
                battlePassLevels: null,
                emoji: {},
                skins: {},
                stances: {},
                taunts: {},
                weapons: {},
                textEmojiPacks: {},
                customizationShards: {},
            },
            Loot: new Loot()
        };
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.PlayerProgress);
        var originLoot = LootUtils.getLootFromRaw(settings.Loot);
        if (originLoot.isAdvertising()) {
            result.Loot.setAdvertising(originLoot.Advertisement);
        }
        result.Loot.AccountExp = originLoot.AccountExp;
        for (var cur in originLoot.Currencies)
            if (originLoot.Currencies.hasOwnProperty(cur)) {
                result.Loot.setCurrency(Number(cur), originLoot.Currencies[cur]);
            }
        if (originLoot.CustomizationShards) {
            var compensations = lootCompensator.compensateCustomizationShards(originLoot, playerProgress, result.ConvertedData);
            for (var _i = 0, compensations_1 = compensations; _i < compensations_1.length; _i++) {
                var compensation = compensations_1[_i];
                result.Loot.combineLoot(compensation.loot);
                HeroUtils.combineLoot(playerProgress, compensation.loot);
                for (var id in compensation.visual) {
                    result.ConvertedData.customizationShards[id] = compensation.visual[id];
                }
            }
        }
        var compensateIterations = [
            { compensateFunction: lootCompensator.compensateCards, destination: result.ConvertedData.cards },
            { compensateFunction: lootCompensator.compensateShards, destination: result.ConvertedData.shards },
            { compensateFunction: lootCompensator.compensateEmoji, destination: result.ConvertedData.emoji },
            { compensateFunction: lootCompensator.compensateSkins, destination: result.ConvertedData.skins },
            { compensateFunction: lootCompensator.compensateStances, destination: result.ConvertedData.stances },
            { compensateFunction: lootCompensator.compensateTaunts, destination: result.ConvertedData.taunts },
            { compensateFunction: lootCompensator.compensateWeapons, destination: result.ConvertedData.weapons },
            { compensateFunction: lootCompensator.compensateTextEmojiPacks, destination: result.ConvertedData.textEmojiPacks },
        ];
        for (var _a = 0, compensateIterations_1 = compensateIterations; _a < compensateIterations_1.length; _a++) {
            var iteration = compensateIterations_1[_a];
            var compensation = iteration.compensateFunction.call(lootCompensator, originLoot, playerProgress);
            result.Loot.combineLoot(compensation.loot);
            HeroUtils.combineLoot(playerProgress, compensation.loot);
            for (var id in compensation.visual) {
                iteration.destination[id] = compensation.visual[id];
            }
        }
        if (originLoot.BattlePassPoints) {
            if (isBpConversion) {
                var pointsConverted = BattlePassUtils.convertBattlePassPoints(originLoot.BattlePassPoints, settings.BattlePassProgress);
                var compensation = new Loot({ Currencies: pointsConverted });
                result.ConvertedData.battlePassPoints = {
                    loot: compensation,
                    sourceAmount: originLoot.BattlePassPoints,
                };
                result.Loot.combineLoot(compensation);
            }
            else {
                result.Loot.BattlePassPoints = originLoot.BattlePassPoints;
            }
        }
        if (originLoot.BattlePassLevels) {
            var compensation = BattlePassUtils.convertBattlePassLevelsToLoot(originLoot.BattlePassLevels, settings.BattlePassProgress);
            if (compensation.loot.isEmpty()) {
                result.Loot.BattlePassLevels = originLoot.BattlePassLevels;
            }
            else {
                result.Loot.BattlePassLevels = compensation.restLevels;
                result.ConvertedData.battlePassLevels = {
                    loot: compensation.loot,
                    sourceAmount: Math.max(1, originLoot.BattlePassLevels - compensation.restLevels),
                };
                result.Loot.combineLoot(compensation.loot);
            }
        }
        if (originLoot.Modifiers) {
            for (var id in originLoot.Modifiers) {
                result.Loot.setModifier(+id, originLoot.Modifiers[id]);
            }
        }
        result.Loot.setStar(originLoot.Star);
        return result;
    };
    ConversionUtils.getRateLoot = function (type, rarity, num) {
        var _a;
        var rate;
        try {
            var r = LootConstants.conversion[type][rarity];
            var mode = r.Mode;
            var total = Math.round(r.Rate[mode] * num);
            if (num > 0 && total < 1) {
                total = 1;
            }
            rate = (_a = {},
                _a[mode] = total,
                _a);
        }
        catch (e) {
            throw new Error("GetConversionLoot: rate not found. ".concat(e.message));
        }
        return new Loot({ Currencies: rate });
    };
    return ConversionUtils;
}());
