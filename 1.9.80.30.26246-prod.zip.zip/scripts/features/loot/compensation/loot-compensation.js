var DefaultLootCompensator = (function () {
    function DefaultLootCompensator() {
        this.compensatingRate = LootConstants.compensatingRate;
    }
    DefaultLootCompensator.prototype.compensateShards = function (originLoot, playerProgress) {
        var _a;
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var id in originLoot.Shards) {
            var hero = heroesMap.checkedGet(id);
            var _b = hero.getAvailableShardsAndCardsQuantity(playerProgress.heroes[id], playerProgress.heroShards[id]), availableCardsQuantity = _b.availableCardsQuantity, availableShardsQuantity = _b.availableShardsQuantity;
            var shards = originLoot.Shards[id];
            var compensation = new Loot();
            var toShards = Math.min(shards, availableShardsQuantity);
            var toCards = shards - availableShardsQuantity > 0
                ? this.getCardsRate(hero.Rarity) * (shards - availableShardsQuantity)
                : 0;
            var toCurrency = toCards - availableCardsQuantity > 0 ? toCards - availableCardsQuantity : 0;
            if (toShards > 0) {
                result.loot.setShards(+id, toShards);
            }
            if (toCurrency > 0) {
                toCards -= toCurrency;
                var cardsRate = this.getCardsCurrencies(hero.Rarity);
                compensation.combineLoot(DefaultLootCompensator.getMultipleCurrencyLoot(toCurrency, cardsRate));
            }
            if (toCards > 0) {
                compensation.combineLoot(new Loot({ HeroExp: (_a = {}, _a[id] = toCards, _a) }));
            }
            if (!compensation.isEmpty()) {
                result.visual[id] = {
                    loot: compensation,
                    sourceAmount: shards - toShards
                };
                result.loot.combineLoot(compensation);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateCards = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var id in originLoot.HeroExp) {
            var hero = heroesMap.checkedGet(id);
            var heroState = playerProgress.heroes[id];
            var _a = hero.getAvailableShardsAndCardsQuantity(heroState, playerProgress.heroShards[id]), availableCardsQuantity = _a.availableCardsQuantity, availableShardsQuantity = _a.availableShardsQuantity;
            var cards = originLoot.HeroExp[id];
            var compensation = new Loot();
            var toCards = Math.min(cards, availableCardsQuantity);
            var toCurrency = cards - toCards > 0 ? cards - toCards : 0;
            if (heroState == undefined) {
                var alreadyShards = playerProgress.heroShards[id] || 0;
                var shardsInLoot = originLoot.Shards[id] || 0;
                var isHeroOpenedByShards = alreadyShards + shardsInLoot >= hero.ShardsNeeded;
                if (!isHeroOpenedByShards) {
                    toCurrency = cards;
                    toCards = 0;
                }
            }
            if (toCurrency > 0) {
                var cardsRate = this.getCardsCurrencies(hero.Rarity);
                compensation.combineLoot(DefaultLootCompensator.getMultipleCurrencyLoot(toCurrency, cardsRate));
            }
            if (toCards > 0) {
                result.loot.setHeroExp(+id, toCards);
            }
            if (!compensation.isEmpty()) {
                result.visual[id] = {
                    loot: compensation,
                    sourceAmount: cards - toCards,
                };
                result.loot.combineLoot(compensation);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateEmoji = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.Emoji; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.emoji.indexOf(id) > -1) {
                var currencyCompensation = CustomizationUtils.getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.EMOJI);
                this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
            }
            else {
                result.loot.addEmoji(id);
                playerProgress.emoji.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateSkins = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.HeroSkins; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.skins.indexOf(id) > -1 && this.doNeedCompensateCustomization("skins", id)) {
                var customization = skinsMap.checkedGet(id);
                var currencyCompensation = CustomizationUtils
                    .getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.SKIN, customization.rarity);
                this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
            }
            else {
                result.loot.addSkin(id);
                playerProgress.skins.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateStances = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.Stances; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.stances.indexOf(id) > -1) {
                var customization = stancesMap.checkedGet(id);
                var currencyCompensation = CustomizationUtils
                    .getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.STANCE, customization.rarity);
                this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
            }
            else {
                result.loot.addStance(id);
                playerProgress.stances.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateTaunts = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.Taunts; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.taunts.indexOf(id) > -1) {
                var customization = tauntsMap.checkedGet(id);
                var currencyCompensation = CustomizationUtils
                    .getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.TAUNT, customization.rarity);
                this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
            }
            else {
                result.loot.addTaunt(id);
                playerProgress.taunts.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateWeapons = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.Weapons; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.weapons.indexOf(id) > -1 || Skin.WeaponsInKit.indexOf(id) > -1) {
                if (this.doNeedCompensateCustomization("weapons", id)) {
                    var customization = weaponsMap.checkedGet(id);
                    var currencyCompensation = CustomizationUtils
                        .getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.WEAPON, customization.rarity);
                    this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
                }
            }
            else {
                result.loot.addWeapon(id);
                playerProgress.weapons.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateTextEmojiPacks = function (originLoot, playerProgress) {
        var result = {
            loot: new Loot(),
            visual: {}
        };
        for (var _i = 0, _a = originLoot.TextEmojiPacks; _i < _a.length; _i++) {
            var id = _a[_i];
            if (playerProgress.textEmojiPacks.indexOf(id) > -1) {
                var customization = textEmojiPacksMap.checkedGet(id);
                var currencyCompensation = CustomizationUtils
                    .getCustomizationCurrencies(this.compensatingRate, CUSTOMIZATION.TEXT_EMOJI_PACK, customization.rarity);
                this.applyCustomizationCompensation(result, id, currencyCompensation, 1);
            }
            else {
                result.loot.addTextEmojiPack(id);
                playerProgress.textEmojiPacks.push(id);
            }
        }
        return result;
    };
    DefaultLootCompensator.prototype.compensateCustomizationShards = function (originLoot, playerProgress, destinations) {
        var customizationShards = {
            loot: new Loot(),
            visual: {}
        };
        var result = [customizationShards];
        var decomposedLoot = new Loot(originLoot);
        decomposedLoot.decomposeCustomizationsAsShards();
        var collections = decomposedLoot.CustomizationShards || {};
        for (var compositeId in collections) {
            var amount = collections[+compositeId];
            var data = CustomizationUtils.getCustomizationShardsData(+compositeId);
            this.resolveCustomizationShardsCompensation(result, originLoot, playerProgress, data, amount, destinations);
        }
        return result;
    };
    DefaultLootCompensator.prototype.resolveCustomizationShardsCompensation = function (result, originLoot, playerProgress, data, amount, destinations) {
        var customizationType = data.customizationType, entityId = data.entityId;
        var shardsDestination = result[0];
        var customizationMap = CustomizationUtils.getOrderMap(customizationType);
        var entity = customizationMap.checkedGet(entityId);
        var rarity = entity.rarity;
        var price = entity.ShardsNeeded;
        var compositeId = getCompositeShardsId(customizationType, entityId);
        var lootContainer = CustomizationUtils.getLootIdsContainer(customizationType, originLoot);
        var progressContainer = CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress);
        var playerHasCustomization = progressContainer.indexOf(entityId) > -1;
        var lootHasCustomization = lootContainer.indexOf(entityId) > -1;
        var customizeDestination = this.resolveDestinationCompensationTarget(customizationType, destinations);
        var playersShards = PlayerStateHelpers.tryGetCustomizationShards(playerProgress, compositeId);
        if (!price) {
            shardsDestination.loot.addCustomizationShards(compositeId, amount);
            return;
        }
        var compensationTypeRates = LootConstants.customizationShardsCompensatingRate[customizationType];
        if (!compensationTypeRates) {
            shardsDestination.loot.addCustomizationShards(compositeId, amount);
            return;
        }
        var compensationRate = compensationTypeRates[rarity];
        if (!compensationRate) {
            shardsDestination.loot.addCustomizationShards(compositeId, amount);
            return;
        }
        var itemsInLoot = lootContainer.filter(function (id) { return id == entityId; }).length;
        var costOfItemsInLoot = itemsInLoot * price;
        var rawShardsWallet = playersShards + amount - costOfItemsInLoot;
        var overflowShards = amount - costOfItemsInLoot;
        var decomposedDelta = 0;
        if (!playerHasCustomization) {
            var needToComplete = Math.max(0, price - playersShards);
            var keepInLoot = Math.min(amount, needToComplete);
            overflowShards -= keepInLoot;
            rawShardsWallet -= keepInLoot;
            if (lootHasCustomization) {
                decomposedDelta = price - keepInLoot;
            }
            if (keepInLoot > 0) {
                shardsDestination.loot.addCustomizationShards(compositeId, keepInLoot);
            }
        }
        var itemsToRemove = 0;
        if (lootHasCustomization) {
            var itemsToRemove_1 = itemsInLoot;
            if (itemsToRemove_1 > 0) {
                originLoot.removeCustomization(customizationType, entityId, itemsToRemove_1);
            }
            var duplicateItems = playerHasCustomization ? itemsToRemove_1 : Math.max(0, itemsToRemove_1 - 1);
            if (duplicateItems > 0) {
                this.applyCompensationAsCustomization(duplicateItems, price, compensationRate, customizeDestination, entityId, shardsDestination);
            }
        }
        if (overflowShards > 0 && itemsToRemove == 0) {
            this.applyCustomizationCompensation(shardsDestination, compositeId, compensationRate, overflowShards);
        }
        if (overflowShards < 0 && rawShardsWallet > 0 && !lootHasCustomization) {
            this.applyCustomizationCompensation(shardsDestination, compositeId, compensationRate, rawShardsWallet);
        }
        if (!playerHasCustomization && lootHasCustomization && decomposedDelta > 0) {
            this.applyCustomizationCompensation(shardsDestination, compositeId, compensationRate, decomposedDelta);
        }
    };
    DefaultLootCompensator.prototype.applyCompensationAsCustomization = function (duplicateItems, price, compensationRate, subDestination, entityId, mainDestination) {
        var compensation = DefaultLootCompensator.getMultipleCurrencyLoot(duplicateItems * price, compensationRate);
        if (subDestination[entityId]) {
            subDestination[entityId].loot.combineLoot(compensation);
            subDestination[entityId].sourceAmount += duplicateItems;
        }
        else {
            subDestination[entityId] = {
                loot: compensation,
                sourceAmount: duplicateItems
            };
        }
        mainDestination.loot.combineLoot(compensation);
    };
    DefaultLootCompensator.prototype.getCardsRate = function (rarity) {
        return this.compensatingRate.shards[rarity] || 1;
    };
    DefaultLootCompensator.prototype.getCardsCurrencies = function (rarity) {
        var defaultCurrencies = this.compensatingRate.defaultCompensation;
        var cardCurrencies = this.compensatingRate.cards[rarity];
        return cardCurrencies || defaultCurrencies;
    };
    DefaultLootCompensator.getMultipleCurrencyLoot = function (repeats, currencies) {
        var resultCurrencies = {};
        for (var cur in currencies) {
            resultCurrencies[cur] = currencies[cur] * repeats;
        }
        return new Loot({ Currencies: resultCurrencies });
    };
    DefaultLootCompensator.prototype.applyCustomizationCompensation = function (result, id, currencyCompensation, sourceAmount) {
        var compensation = DefaultLootCompensator.getMultipleCurrencyLoot(sourceAmount, currencyCompensation);
        if (result.visual[id]) {
            result.visual[id].loot.combineLoot(compensation);
            result.visual[id].sourceAmount += sourceAmount;
        }
        else {
            result.visual[id] = {
                loot: compensation,
                sourceAmount: sourceAmount,
            };
        }
        result.loot.combineLoot(compensation);
    };
    DefaultLootCompensator.prototype.doNeedCompensateCustomization = function (key, id) {
        var table = LootConstants.ignoreCustomizationsForCompensating[key];
        return table == undefined || table.indexOf(id) == -1;
    };
    DefaultLootCompensator.prototype.resolveDestinationCompensationTarget = function (customizationType, destinations) {
        switch (customizationType) {
            case CUSTOMIZATION.SKIN:
                return destinations.skins;
            case CUSTOMIZATION.WEAPON:
                return destinations.weapons;
            case CUSTOMIZATION.STANCE:
                return destinations.stances;
            case CUSTOMIZATION.TAUNT:
                return destinations.taunts;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return destinations.textEmojiPacks;
            case CUSTOMIZATION.EMOJI:
                return destinations.emoji;
        }
    };
    return DefaultLootCompensator;
}());
var LootCompensationFacade = (function () {
    function LootCompensationFacade() {
    }
    LootCompensationFacade.getLootCompensator = function (type) {
        switch (type) {
            case CurrencyReason.GACHA_ROLL:
                return new GachaBannerCompensation();
        }
        return new DefaultLootCompensator();
    };
    return LootCompensationFacade;
}());
