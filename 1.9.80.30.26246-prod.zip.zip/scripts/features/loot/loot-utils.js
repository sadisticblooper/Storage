var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var LootUtils = (function () {
    function LootUtils() {
    }
    LootUtils.getAvailableCustomizationsForGenerating = function (settings) {
        var result = [];
        var customizationSettings = settings.customizationSettings, customizationMap = settings.customizationMap, playerProgress = settings.playerProgress, playerIds = settings.playerIds, canRepeatCustomization = settings.canRepeatCustomization;
        var availableList = settings.availableList;
        var manualIds = [];
        var fullRarityList = {};
        var newItemsInRarity = {};
        if (customizationSettings.Ids) {
            for (var id in customizationSettings.Ids) {
                if (isNumber(id) && customizationSettings.Ids[id] && customizationMap.get(id)) {
                    manualIds.push(+id);
                }
            }
        }
        for (var _i = 0, _a = customizationMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var inManualList = manualIds.indexOf(id) > -1;
            if (!inManualList && !customizationSettings.Rarities) {
                continue;
            }
            if (availableList.indexOf(id) == -1 && !inManualList) {
                continue;
            }
            if (customizationSettings.ExcludeList && customizationSettings.ExcludeList.indexOf(id) > -1) {
                continue;
            }
            var customization = customizationMap.get(id);
            var owners = customization.heroOwners;
            var rarity = customization.rarity;
            var heroFilterPassed = true;
            if (customizationSettings.HeroFilter) {
                if (owners && owners.length > 0) {
                    for (var _b = 0, owners_1 = owners; _b < owners_1.length; _b++) {
                        var heroId = owners_1[_b];
                        if (playerProgress.heroes[heroId] == undefined) {
                            heroFilterPassed = false;
                            break;
                        }
                    }
                }
            }
            if (!heroFilterPassed) {
                continue;
            }
            if (rarity != null
                && customizationSettings.Rarities
                && !customizationSettings.Rarities[rarity]
                && !inManualList) {
                continue;
            }
            if (fullRarityList[rarity] == undefined) {
                fullRarityList[rarity] = [];
            }
            if (newItemsInRarity[rarity] == undefined) {
                newItemsInRarity[rarity] = [];
            }
            if (playerIds.indexOf(id) == -1) {
                newItemsInRarity[rarity].push(id);
            }
            fullRarityList[rarity].push(id);
        }
        var rarityOrder = Object
            .keys(fullRarityList)
            .map(function (i) { return +i; })
            .sort(function (a, b) { return a - b; });
        for (var _c = 0, rarityOrder_1 = rarityOrder; _c < rarityOrder_1.length; _c++) {
            var rarity = rarityOrder_1[_c];
            if (newItemsInRarity[rarity].length > 0) {
                result = result.concat(newItemsInRarity[rarity]);
            }
            else if (canRepeatCustomization) {
                result = result.concat(fullRarityList[rarity]);
            }
        }
        return result;
    };
    LootUtils.getSeparatedCustomizationsByRarity = function (settings) {
        var result = {};
        var availableIds = settings.availableIds, customizationMap = settings.customizationMap;
        var isResultEmpty = true;
        if (!availableIds || availableIds.length == 0) {
            return null;
        }
        var ids = availableIds.sort(function (id1, id2) { return id2 - id1; });
        for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
            var id = ids_1[_i];
            var customization = customizationMap.checkedGet(id);
            if (customization.rarity != null) {
                isResultEmpty = false;
                if (result[customization.rarity] == undefined) {
                    result[customization.rarity] = [];
                }
                result[customization.rarity].push(id);
            }
        }
        if (isResultEmpty) {
            return null;
        }
        return result;
    };
    LootUtils.getCompensate = function (customizationType, id) {
        var _a, _b;
        var unconvertableLoot = LootUtils.getUnconvertableLoot(customizationType, id);
        if (unconvertableLoot) {
            return unconvertableLoot;
        }
        var currencies = {};
        var orderMap = CustomizationUtils.getOrderMap(customizationType);
        if (!orderMap) {
            return new Loot();
        }
        var item = orderMap.checkedGet(id);
        if (item && LootConstants.convertRateOfCustomizations[customizationType]) {
            if (item.rarity) {
                if (LootConstants.convertRateOfCustomizations[customizationType][item.rarity]) {
                    currencies = LootConstants.convertRateOfCustomizations[customizationType][item.rarity];
                }
            }
            else {
                currencies = (_a = {}, _a[CURRENCY.BONUS] = 1, _a);
            }
        }
        var loot = new Loot({ Currencies: currencies });
        if (loot.isEmpty()) {
            loot = new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 1, _b) });
        }
        return loot;
    };
    LootUtils.getUnconvertableLoot = function (customizationType, id) {
        var table = null;
        var lootSettings = null;
        switch (customizationType) {
            case CUSTOMIZATION.SKIN:
                table = LootConstants.ignoreCustomizationsToConvert.skins;
                lootSettings = { Skins: [id] };
                break;
            case CUSTOMIZATION.WEAPON:
                table = LootConstants.ignoreCustomizationsToConvert.weapons;
                lootSettings = { Weapons: [id] };
                break;
        }
        if (table && table.indexOf(id) > -1) {
            return new Loot(lootSettings);
        }
        return null;
    };
    LootUtils.getLootFromRaw = function (rawLoot) {
        var lootSettings = {};
        if (rawLoot.AccountExp != undefined) {
            lootSettings.AccountExp = rawLoot.AccountExp;
        }
        if (rawLoot.HeroExp != undefined) {
            lootSettings.HeroExp = rawLoot.HeroExp;
        }
        if (rawLoot.BattlePassPoints != undefined) {
            lootSettings.BattlePassPoints = rawLoot.BattlePassPoints;
        }
        if (rawLoot.BattlePassLevels != undefined) {
            lootSettings.BattlePassLevels = rawLoot.BattlePassLevels;
        }
        if (rawLoot.Shards != undefined) {
            lootSettings.Shards = rawLoot.Shards;
        }
        if (rawLoot.Currencies != undefined) {
            lootSettings.Currencies = rawLoot.Currencies;
        }
        if (rawLoot.HeroSkins != undefined) {
            lootSettings.Skins = getArrayFromRaw(rawLoot.HeroSkins);
        }
        if (rawLoot.Taunts != undefined) {
            lootSettings.Taunts = getArrayFromRaw(rawLoot.Taunts);
        }
        if (rawLoot.Emoji != undefined) {
            lootSettings.Emoji = getArrayFromRaw(rawLoot.Emoji);
        }
        if (rawLoot.TextEmojiPacks != undefined) {
            lootSettings.TextEmojiPacks = getArrayFromRaw(rawLoot.TextEmojiPacks);
        }
        if (rawLoot.Stances != undefined) {
            lootSettings.Stances = getArrayFromRaw(rawLoot.Stances);
        }
        if (rawLoot.Weapons != undefined) {
            lootSettings.Weapons = getArrayFromRaw(rawLoot.Weapons);
        }
        if (rawLoot.Modifiers != undefined) {
            lootSettings.Modifiers = rawLoot.Modifiers;
        }
        if (rawLoot.Star != undefined) {
            lootSettings.Star = rawLoot.Star;
        }
        if (rawLoot.CustomizationShards != undefined) {
            lootSettings.CustomizationShards = rawLoot.CustomizationShards;
        }
        var loot = new Loot(lootSettings);
        if (rawLoot.Advertisement != undefined) {
            if (rawLoot.Advertisement.Place != undefined && rawLoot.Advertisement.Place > 0
                || rawLoot.Advertisement.Quantity != undefined && rawLoot.Advertisement.Quantity > 0) {
                var advertisement = {
                    Place: rawLoot.Advertisement.Place ? rawLoot.Advertisement.Place : 0,
                    Quantity: rawLoot.Advertisement.Quantity ? rawLoot.Advertisement.Quantity : 1,
                };
                if (rawLoot.Advertisement.ExtraAdParameters) {
                    CommonUtils.replaceReadOnlyProperty(advertisement, "ExtraAdParameters", rawLoot.Advertisement.ExtraAdParameters);
                }
                loot.setAdvertising(advertisement);
            }
        }
        return loot;
    };
    LootUtils.getHeroIDFromWeights = function (heroesWithWeights, rng) {
        if (Object.keys(heroesWithWeights).length == 0) {
            return null;
        }
        var allWeights = [];
        var sortedHeroIds = Object
            .keys(heroesWithWeights)
            .sort(function (a, b) { return Number(a) - Number(b); });
        for (var _i = 0, sortedHeroIds_1 = sortedHeroIds; _i < sortedHeroIds_1.length; _i++) {
            var idn = sortedHeroIds_1[_i];
            if (heroesWithWeights.hasOwnProperty(idn)) {
                allWeights.push(new CollectionObjectContainer(idn, heroesWithWeights[idn]));
            }
        }
        var collection = new RandomCollection();
        collection.addAll(allWeights);
        var result = collection.next(rng);
        return Number(result.get());
    };
    LootUtils.getCollectionFromRandomWeights = function (weights) {
        try {
            var collection = new RandomCollection();
            var allWeights = [];
            for (var _i = 0, weights_1 = weights; _i < weights_1.length; _i++) {
                var weight = weights_1[_i];
                var w = weight;
                var w_old = weight;
                if (w_old.Amount != undefined) {
                    allWeights.push(new CollectionObjectContainer(w_old.Amount, w_old.Weight));
                }
                else {
                    allWeights.push(new CollectionObjectContainer(w.N, w.W));
                }
            }
            collection.addAll(allWeights);
            return collection;
        }
        catch (e) {
            var mes = "GetCollectionFromRandomWeights: ";
            if (!weights || weights.length < 1) {
                mes += "weights are null/undefined or []. ";
            }
            else {
                mes += "weights are: " + JSON.stringify(weights);
            }
            throw new Error("Error when getCollectionFromRandomWeights. " + mes + " StackTrace: " + e.stackTrace.toString());
        }
    };
    LootUtils.getWeightsAmountWithoutImpossibleWeights = function (originalWeights) {
        var result = [];
        if (originalWeights) {
            for (var _i = 0, originalWeights_1 = originalWeights; _i < originalWeights_1.length; _i++) {
                var item = originalWeights_1[_i];
                if (item.W > 0) {
                    result.push({ W: item.W, N: item.N, });
                }
            }
        }
        return result;
    };
    LootUtils.findNearestAvailableRarity = function (settings) {
        var result = HERO_RARITY.UNKNOWN;
        var commonOrder = LootConstants.orderRarity.slice();
        var reverseOrder = commonOrder.slice().reverse();
        var orderRarity = __spreadArray(__spreadArray([], commonOrder, true), reverseOrder, true);
        var reverseOrderRarity = __spreadArray(__spreadArray([], reverseOrder, true), commonOrder, true);
        var rarityOrder = settings.forwardSearch
            ? orderRarity
            : reverseOrderRarity;
        var availableHeroes = settings.availableSeparated.available;
        var index = rarityOrder.indexOf(settings.currentRarityNumber);
        if (index > -1 && index < rarityOrder.length - 1) {
            var startPosition = settings.strictOrderStart ? index : index + 1;
            for (var i = startPosition; i < rarityOrder.length; i++) {
                var rarityNumber = rarityOrder[i];
                if (availableHeroes[rarityNumber]) {
                    if (settings.cardType == CARD_ITEM.CARDS) {
                        if (availableHeroes[rarityNumber].cards.length) {
                            result = rarityNumber;
                            break;
                        }
                    }
                    else if (settings.cardType == CARD_ITEM.SHARDS) {
                        if (availableHeroes[rarityNumber].shards.length) {
                            result = rarityNumber;
                            break;
                        }
                    }
                }
            }
        }
        return result;
    };
    LootUtils.setOrCreateSlotsSettings = function (settings) {
        var rarities = settings.rarities;
        if (!rarities[settings.rarityNumber]) {
            rarities[settings.rarityNumber] = { Slots: 0, ShardsMode: settings.shardMode };
        }
        if (settings.cardType == CARD_ITEM.SHARDS) {
            if (!rarities[settings.rarityNumber].ShardsWeight) {
                CommonUtils
                    .replaceReadOnlyProperty(rarities[settings.rarityNumber], "ShardsWeight", [{ W: 1, N: 0 }]);
            }
        }
        else if (settings.cardType == CARD_ITEM.CARDS) {
            if (!rarities[settings.rarityNumber].CardsWeight) {
                CommonUtils
                    .replaceReadOnlyProperty(rarities[settings.rarityNumber], "CardsWeight", [{ W: 1, N: 0 }]);
            }
        }
    };
    LootUtils.getIncreasedWeightsAmount = function (weights, num) {
        var result = [];
        if (weights) {
            for (var _i = 0, weights_2 = weights; _i < weights_2.length; _i++) {
                var item = weights_2[_i];
                result.push({ N: item.N + num, W: item.W });
            }
        }
        return result;
    };
    LootUtils.getCorrectedCardsSettings = function (settings) {
        var cardsSlots = settings.cardsSlots, availableSettings = settings.availableSettings, cardsRate = settings.cardsRate;
        var totalMinCards = 0;
        var totalSlots = 0;
        var rarities = {};
        var requirements = {};
        var desiredCards = cardsSlots.TotalCards;
        var desiredShards = 0;
        var noCards = true;
        var availableHeroes = availableSettings.available;
        for (var rarityNumberString in cardsSlots.Rarities) {
            var rarityNumber = +rarityNumberString;
            var slotSettings = cardsSlots.Rarities[rarityNumberString];
            var cardsWeightOrigin = slotSettings.CardsWeight;
            var cardsWeight = this.getWeightsAmountWithoutImpossibleWeights(cardsWeightOrigin);
            var shardsWeightOrigin = slotSettings.ShardsWeight;
            var shardsWeight = this.getWeightsAmountWithoutImpossibleWeights(shardsWeightOrigin);
            var availableHeroesInRarity = !!availableHeroes[rarityNumber];
            var cardHeroes = availableHeroesInRarity ? availableHeroes[rarityNumber].cards.length : 0;
            var shardHeroes = availableHeroesInRarity ? availableHeroes[rarityNumber].shards.length : 0;
            if (cardsWeight.length) {
                var min = CommonGameUtils.findMinimumFromWeights(cardsWeight);
                var slots = slotSettings.Slots;
                if (cardHeroes != 0) {
                    slots = Math.min(slots, cardHeroes);
                    totalMinCards += min;
                    totalSlots += slots;
                    rarities[rarityNumberString] = {
                        ShardsMode: slotSettings.ShardsMode,
                        Slots: slots,
                        CardsWeight: cardsWeight,
                    };
                    noCards = false;
                }
                else {
                    requirements[rarityNumber] = {
                        cards: { cards: min, slots: slots },
                        shardsMode: slotSettings.ShardsMode,
                    };
                }
            }
            if (shardsWeight.length) {
                var minShards = CommonGameUtils.findMinimumFromWeights(shardsWeight);
                desiredShards += minShards;
                if (shardHeroes != 0) {
                    if (rarities[rarityNumberString] == undefined) {
                        rarities[rarityNumberString] = {
                            ShardsMode: slotSettings.ShardsMode,
                            Slots: 0
                        };
                    }
                    CommonUtils.replaceReadOnlyProperty(rarities[rarityNumberString], "ShardsWeight", shardsWeight);
                }
                else {
                    if (requirements[rarityNumber] == undefined) {
                        requirements[rarityNumber] = {};
                    }
                    requirements[rarityNumber].shards = minShards;
                    requirements[rarityNumber].shardsMode = slotSettings.ShardsMode;
                }
            }
        }
        for (var rarityNumber in requirements)
            if (requirements.hasOwnProperty(rarityNumber)) {
                var requirement = requirements[rarityNumber];
                if (requirement.shards) {
                    var nearestRarityNumber = this.findNearestAvailableRarity({
                        availableSeparated: availableSettings,
                        currentRarityNumber: Number(rarityNumber),
                        cardType: CARD_ITEM.SHARDS,
                        forwardSearch: false,
                    });
                    if (nearestRarityNumber) {
                        this.setOrCreateSlotsSettings({
                            rarities: rarities,
                            rarityNumber: nearestRarityNumber,
                            cardType: CARD_ITEM.SHARDS,
                            shardMode: requirement.shardsMode,
                        });
                        CommonUtils.replaceReadOnlyProperty(rarities[nearestRarityNumber], "ShardsWeight", this.getIncreasedWeightsAmount(rarities[nearestRarityNumber].ShardsWeight, requirement.shards));
                    }
                }
                if (requirement.cards && requirement.cards.cards && requirement.cards.slots) {
                    var nearestRarityNumber = this.findNearestAvailableRarity({
                        availableSeparated: availableSettings,
                        currentRarityNumber: Number(rarityNumber),
                        cardType: CARD_ITEM.CARDS,
                        forwardSearch: false,
                    });
                    if (nearestRarityNumber) {
                        var cardHeroes = availableHeroes[nearestRarityNumber].cards.length;
                        var cards = requirement.cards.cards;
                        var slots = requirement.cards.slots;
                        if (cardsRate) {
                            var k = LootUtils.getCardsRate(+rarityNumber, nearestRarityNumber, cardsRate);
                            cards = Math.ceil(cards * k);
                        }
                        this.setOrCreateSlotsSettings({
                            rarities: rarities,
                            rarityNumber: nearestRarityNumber,
                            cardType: CARD_ITEM.CARDS,
                            shardMode: requirement.shardsMode,
                        });
                        var correctedSlotsNumber = Math.min(cardHeroes, rarities[nearestRarityNumber].Slots + slots);
                        var toTotalSlots = correctedSlotsNumber - rarities[nearestRarityNumber].Slots;
                        CommonUtils.replaceReadOnlyProperty(rarities[nearestRarityNumber], "CardsWeight", this.getIncreasedWeightsAmount(rarities[nearestRarityNumber].CardsWeight, cards));
                        totalMinCards += cards;
                        noCards = false;
                        totalSlots += toTotalSlots;
                        CommonUtils.replaceReadOnlyProperty(rarities[nearestRarityNumber], "Slots", correctedSlotsNumber);
                    }
                }
            }
        if (Object.keys(rarities).length == 0) {
            if (desiredCards) {
                var lowRarityNumber = this.findNearestAvailableRarity({
                    availableSeparated: availableSettings,
                    currentRarityNumber: HERO_RARITY.COMMON,
                    cardType: CARD_ITEM.CARDS,
                    forwardSearch: true,
                    strictOrderStart: true,
                });
                if (lowRarityNumber) {
                    var slots = Math.min(availableHeroes[lowRarityNumber].cards.length, cardsSlots.TotalSlots);
                    totalMinCards = desiredCards;
                    noCards = false;
                    totalSlots = slots;
                    rarities[lowRarityNumber] = { Slots: slots, CardsWeight: [{ N: desiredCards, W: 1 }] };
                }
            }
            if (desiredShards) {
                var lowRarityNumber = this.findNearestAvailableRarity({
                    availableSeparated: availableSettings,
                    currentRarityNumber: HERO_RARITY.COMMON,
                    cardType: CARD_ITEM.SHARDS,
                    forwardSearch: true,
                    strictOrderStart: true,
                });
                if (lowRarityNumber) {
                    if (rarities[lowRarityNumber] == undefined) {
                        rarities[lowRarityNumber] = { Slots: 0, ShardsWeight: [{ N: desiredShards, W: 1 }] };
                    }
                    else {
                        CommonUtils.replaceReadOnlyProperty(rarities[lowRarityNumber], "ShardsWeight", [{ N: desiredShards, W: 1 }]);
                    }
                }
            }
        }
        return {
            TotalCards: noCards ? 0 : Math.max(cardsSlots.TotalCards, totalMinCards),
            TotalSlots: Math.min(cardsSlots.TotalSlots, totalSlots),
            Rarities: rarities,
        };
    };
    LootUtils.getModificationShardWeight = function (delta, table) {
        var result = 1;
        if (table.length > 0) {
            var minSettings = table[0];
            var maxSettings = table[0];
            for (var _i = 0, table_1 = table; _i < table_1.length; _i++) {
                var settings = table_1[_i];
                if (settings.delta > maxSettings.delta) {
                    maxSettings = settings;
                }
                if (settings.delta < minSettings.delta) {
                    minSettings = settings;
                }
            }
            for (var _a = 0, table_2 = table; _a < table_2.length; _a++) {
                var settings = table_2[_a];
                if (settings.delta >= delta) {
                    var currentDiff = Math.abs(settings.delta - delta);
                    var oldDiff = Math.abs(maxSettings.delta - delta);
                    if (currentDiff <= oldDiff) {
                        maxSettings = settings;
                    }
                }
                if (settings.delta <= delta) {
                    var currentDiff = Math.abs(settings.delta - delta);
                    var oldDiff = Math.abs(minSettings.delta - delta);
                    if (currentDiff <= oldDiff) {
                        minSettings = settings;
                    }
                }
            }
            var weightDistance = maxSettings.weight - minSettings.weight;
            var deltaDistance = maxSettings.delta - minSettings.delta;
            var partOfDelta = deltaDistance == 0 ? 0 : (delta - minSettings.delta) / deltaDistance;
            result = minSettings.weight + partOfDelta * weightDistance;
        }
        return result;
    };
    LootUtils.getCardsRate = function (fromRarity, toRarity, table) {
        var defaultValue = 1;
        if (!table || !table[fromRarity] == undefined || !table[toRarity]) {
            return defaultValue;
        }
        return table[fromRarity] / table[toRarity];
    };
    LootUtils.getGeneratedLootFromRewardResult = function (settings) {
        var playerProgress = settings.playerProgress, reward = settings.reward, chestSeed = settings.chestSeed, chestQueuePositions = settings.chestQueuePositions, enableCombiningWithPlayer = settings.enableCombiningWithPlayer, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        playerProgress = deepCopyOverJSON(playerProgress);
        var loot = new Loot();
        var chests = [];
        if (reward.Loot && !reward.Loot.isEmpty()) {
            loot.combineLoot(reward.Loot);
            if (enableCombiningWithPlayer) {
                HeroUtils.combineLoot(playerProgress, reward.Loot);
            }
        }
        if (reward.Chests && reward.Chests.length) {
            var ids = reward.Chests.sort(function (id1, id2) { return id1 - id2; });
            for (var _i = 0, ids_2 = ids; _i < ids_2.length; _i++) {
                var id = ids_2[_i];
                var chestResult = generateLootFromChest({
                    PlayerProgress: playerProgress,
                    ChestID: id,
                    ChestArena: playerProgress.playerArenaId,
                    ChestQueuePositions: chestQueuePositions,
                    Seed: chestSeed,
                    StartTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
                });
                chestSeed = chestResult.NewSeed;
                chestQueuePositions = chestResult.ChestQueuePositions;
                if (enableCombiningWithPlayer) {
                    HeroUtils.combineLoot(playerProgress, chestResult.Loot);
                }
                chests.push({
                    id: id,
                    loot: chestResult.Loot,
                });
            }
        }
        return {
            loot: loot,
            chests: chests,
            chestSeed: chestSeed,
            chestQueuePositions: chestQueuePositions,
        };
    };
    LootUtils.combineCardSlots = function (cardSlots) {
        var totalSlots = 0;
        var totalCards = 0;
        var rarities = { Rarities: {} };
        var shardsMode = {};
        for (var _i = 0, cardSlots_1 = cardSlots; _i < cardSlots_1.length; _i++) {
            var cardSlotSettings = cardSlots_1[_i];
            totalCards += cardSlotSettings.TotalCards;
            totalSlots += cardSlotSettings.TotalSlots;
            for (var rarityNumberString in cardSlotSettings.Rarities) {
                var originSetting = cardSlotSettings.Rarities[rarityNumberString];
                if (rarities.Rarities[rarityNumberString] == undefined) {
                    rarities.Rarities[rarityNumberString] = {
                        Slots: 0,
                        CardsWeight: [],
                    };
                }
                var goalSettings = rarities.Rarities[rarityNumberString];
                var newChances = [];
                if (shardsMode[rarityNumberString] == undefined) {
                    shardsMode[rarityNumberString] = originSetting.ShardsMode;
                }
                else if (shardsMode[rarityNumberString] != originSetting.ShardsMode
                    && originSetting.ShardsMode != undefined) {
                    shardsMode[rarityNumberString] = SHARDS_GENERATING_MODE.RANDOM;
                }
                goalSettings.Slots += originSetting.Slots;
                for (var _a = 0, _b = goalSettings.CardsWeight; _a < _b.length; _a++) {
                    var goalChance = _b[_a];
                    for (var _c = 0, _d = originSetting.CardsWeight; _c < _d.length; _c++) {
                        var originChance = _d[_c];
                        newChances.push({
                            Weight: originChance.Weight * goalChance.Weight,
                            Amount: originChance.Amount + goalChance.Amount
                        });
                    }
                }
                if (newChances.length == 0) {
                    goalSettings.CardsWeight = originSetting.CardsWeight;
                }
                else {
                    goalSettings.CardsWeight = newChances;
                }
            }
        }
        for (var rarityNumberString in rarities.Rarities) {
            rarities.Rarities[rarityNumberString].ShardsMode = shardsMode[rarityNumberString];
        }
        return {
            Rarities: rarities.Rarities,
            TotalSlots: totalSlots,
            TotalCards: totalCards,
        };
    };
    LootUtils.getNotEmptyCurrenciesFromLootSettings = function (lootSettings) {
        var result = [];
        if (lootSettings.AdditionalFixedLoot) {
            result = result.concat(lootSettings.AdditionalFixedLoot.getNotEmptyCurrencies());
        }
        if (lootSettings.CurrencySlots) {
            for (var type in lootSettings.CurrencySlots) {
                var noZeroWeight = false;
                for (var _i = 0, _a = lootSettings.CurrencySlots[+type]; _i < _a.length; _i++) {
                    var variant = _a[_i];
                    if (variant.Weight > 0 && variant.Amount.getMin() > 0) {
                        noZeroWeight = true;
                        break;
                    }
                }
                if (noZeroWeight && result.indexOf(+type) == -1) {
                    result.push(+type);
                }
            }
        }
        return result;
    };
    LootUtils.getNotEmptyCurrenciesFromRewardContent = function (reward) {
        var result = [];
        if (!reward) {
            return result;
        }
        if (reward.loot) {
            result = reward.loot.getNotEmptyCurrencies();
        }
        if (reward.lootSettings) {
            result = result.concat(LootUtils.getNotEmptyCurrenciesFromLootSettings(reward.lootSettings));
        }
        return result;
    };
    LootUtils.getAvailableHeroesForShardsOrDuplicates = function (availableHeroes, rarity, shardsMode, playerProgress) {
        var availableSeparated = availableHeroes.available;
        var duplicates = [];
        var shards = [];
        if (availableSeparated[rarity] != undefined) {
            for (var _i = 0, _a = availableSeparated[rarity].shards; _i < _a.length; _i++) {
                var hid = _a[_i];
                if (playerProgress.heroes[hid] == undefined) {
                    shards.push(hid);
                }
                else {
                    duplicates.push(hid);
                }
            }
        }
        switch (shardsMode) {
            case SHARDS_GENERATING_MODE.RANDOM:
                return shards.concat(duplicates);
            default:
                var shardsGenerator = new ShardsGenerator();
                return shardsGenerator.getHeroIdsForGeneratingByShardsMode({
                    rnd: null,
                    strictMode: true,
                    mode: shardsMode,
                    availableHeroesForDuplicates: duplicates,
                    availableHeroesForShards: shards,
                });
        }
    };
    LootUtils.getMergedLoot = function (settings) {
        if (settings.rewards.length == 0) {
            throwDebugOrReturnDefault("getMergedLoot: no items to merge");
        }
        var result = new Loot();
        for (var _i = 0, _a = settings.rewards; _i < _a.length; _i++) {
            var fightLoot = _a[_i];
            var originLoot = LootUtils.getLootFromRaw(fightLoot);
            result.combineLoot(originLoot);
        }
        if (result.isEmpty()) {
            throwDebugOrReturnDefault("getMergedLoot: final loot is empty");
        }
        return result;
    };
    LootUtils.mergeRewardResult = function (dst, source) {
        dst.Loot.combineLoot(source.Loot);
        dst.Chests = dst.Chests.concat(source.Chests);
        dst.IsHidden = dst.IsHidden || source.IsHidden;
    };
    LootUtils.mergeRewardContent = function (dst, source) {
        var _a;
        if (source.loot && !source.loot.isEmpty()) {
            if (!dst.loot) {
                dst.loot = new Loot();
            }
            dst.loot.combineLoot(source.loot);
        }
        if (source.chests && source.chests.length > 0) {
            if (!dst.chests) {
                dst.chests = [];
            }
            (_a = dst.chests).push.apply(_a, source.chests);
        }
    };
    LootUtils.multiplyCurrency = function (loot, currency, coefficient) {
        var current = loot.getCurrencyByType(currency);
        if (current > 0) {
            var newValue = Math.round(current * coefficient);
            loot.setCurrency(currency, newValue);
        }
    };
    LootUtils.getHeroIDsFromCardsAndShards = function (rewardContent) {
        var _a;
        var result = [];
        var allLoot = [
            rewardContent.loot,
            (_a = rewardContent.lootSettings) === null || _a === void 0 ? void 0 : _a.AdditionalFixedLoot,
        ].filter(Boolean);
        for (var _i = 0, allLoot_1 = allLoot; _i < allLoot_1.length; _i++) {
            var part = allLoot_1[_i];
            for (var heroID in part.HeroExp) {
                result.push(+heroID);
            }
            for (var heroID in part.Shards) {
                result.push(+heroID);
            }
        }
        return result;
    };
    LootUtils.getHeroIDsFromCustomizations = function (rewardContent) {
        var _a;
        var result = [];
        var allLoot = [
            rewardContent.loot,
            (_a = rewardContent.lootSettings) === null || _a === void 0 ? void 0 : _a.AdditionalFixedLoot,
        ].filter(Boolean);
        for (var _i = 0, allLoot_2 = allLoot; _i < allLoot_2.length; _i++) {
            var part = allLoot_2[_i];
            var customizationsMaps = {
                'HeroSkins': skinsMap,
                'Stances': stancesMap,
                'Taunts': tauntsMap,
                'Emoji': emojiMap,
                'Weapons': weaponsMap,
            };
            for (var customizationArray in customizationsMaps) {
                for (var _b = 0, _c = part[customizationArray]; _b < _c.length; _b++) {
                    var id = _c[_b];
                    var customization = customizationsMaps[customizationArray].checkedGet(id);
                    result.push.apply(result, customization.heroOwners);
                    if (customization instanceof Emoji && customization.HeroId !== null) {
                        result.push(customization.HeroId);
                    }
                }
            }
        }
        return result;
    };
    LootUtils.getSkinsFromRewardContents = function (rewardContent) {
        var _a, _b, _c, _d, _e;
        return __spreadArray(__spreadArray([], ((_b = (_a = rewardContent.loot) === null || _a === void 0 ? void 0 : _a.HeroSkins) !== null && _b !== void 0 ? _b : []), true), ((_e = (_d = (_c = rewardContent.lootSettings) === null || _c === void 0 ? void 0 : _c.AdditionalFixedLoot) === null || _d === void 0 ? void 0 : _d.HeroSkins) !== null && _e !== void 0 ? _e : []), true);
    };
    return LootUtils;
}());
