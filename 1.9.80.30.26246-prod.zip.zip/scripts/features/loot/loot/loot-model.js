var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var Loot = (function () {
    function Loot(js) {
        this.Advertisement = null;
        if (js) {
            js = getObjectFromRaw(js);
            this.AccountExp = js.AccountExp ? js.AccountExp : 0;
            this.BattlePassPoints = js.BattlePassPoints ? js.BattlePassPoints : 0;
            this.BattlePassLevels = js.BattlePassLevels ? js.BattlePassLevels : 0;
            this.HeroExp = js.HeroExp ? getObjectFromRaw(js.HeroExp) : {};
            this.Shards = js.Shards ? getObjectFromRaw(js.Shards) : {};
            this.HeroSkins = js.Skins ? getArrayFromRaw(js.Skins) : [];
            this.Taunts = js.Taunts ? getArrayFromRaw(js.Taunts) : [];
            this.Emoji = js.Emoji ? getArrayFromRaw(js.Emoji) : [];
            this.Stances = js.Stances ? getArrayFromRaw(js.Stances) : [];
            this.Weapons = js.Weapons ? getArrayFromRaw(js.Weapons) : [];
            this.TextEmojiPacks = js.TextEmojiPacks ? getArrayFromRaw(js.TextEmojiPacks) : [];
            this.setCurrencySettings(js.Currencies);
            this.Modifiers = js.Modifiers ? getObjectFromRaw(js.Modifiers) : {};
            this.Star = js.Star ? getObjectFromRaw(js.Star) : null;
            this.CustomizationShards = js.CustomizationShards ? getObjectFromRaw(js.CustomizationShards) : {};
        }
        else {
            this.clear();
        }
    }
    Loot.prototype.clear = function () {
        this.AccountExp = 0;
        this.BattlePassPoints = 0;
        this.BattlePassLevels = 0;
        this.HeroExp = {};
        this.Shards = {};
        this.HeroSkins = [];
        this.Taunts = [];
        this.Emoji = [];
        this.Stances = [];
        this.Weapons = [];
        this.TextEmojiPacks = [];
        this.setCurrencySettings();
        this.Modifiers = {};
        this.Advertisement = null;
        this.Star = null;
        this.CustomizationShards = {};
    };
    Loot.prototype.getShardsByHeroID = function (hero_id) { return this.Shards[hero_id] ? this.Shards[hero_id] : 0; };
    Loot.prototype.getHeroExpByHeroID = function (hero_id) { return this.HeroExp[hero_id] ? this.HeroExp[hero_id] : 0; };
    Loot.prototype.getCurrencyByType = function (c_type) { return this.Currencies[c_type] ? this.Currencies[c_type] : 0; };
    Loot.prototype.getModifierByID = function (mod_id) { return this.Modifiers[mod_id] ? this.Modifiers[mod_id] : 0; };
    Loot.prototype.getNotEmptyCurrencies = function () {
        var _this = this;
        return Object
            .keys(this.Currencies)
            .filter(function (c) { return _this.Currencies[c] > 0; })
            .map(Number);
    };
    Loot.prototype.getCustomizationShards = function (compositeId) {
        var shards = this.CustomizationShards && this.CustomizationShards[compositeId];
        return shards ? shards : 0;
    };
    Loot.prototype.setShards = function (hero_id, shards) {
        this.Shards[hero_id] = shards;
    };
    Loot.prototype.removeShards = function (hero_id) {
        if (this.Shards[hero_id] != undefined) {
            delete this.Shards[hero_id];
        }
    };
    Loot.prototype.removeAllShards = function () {
        this.Shards = {};
    };
    Loot.prototype.setHeroExp = function (hero_id, exp) {
        this.HeroExp[hero_id] = exp;
    };
    Loot.prototype.removeHeroExp = function (hero_id) {
        if (this.HeroExp[hero_id] != undefined) {
            delete this.HeroExp[hero_id];
        }
    };
    Loot.prototype.setCurrency = function (c_type, amount) {
        if (CURRENCY[c_type] != undefined) {
            if (amount > 0) {
                this.Currencies[c_type] = amount;
            }
            else {
                delete this.Currencies[c_type];
            }
        }
    };
    Loot.prototype.setModifier = function (modifierId, amount) {
        this.Modifiers[modifierId] = amount;
    };
    Loot.prototype.setStar = function (star) {
        if (star) {
            this.Star = { ChapterId: star.ChapterId, HeroId: star.HeroId };
        }
        else {
            this.clearStar();
        }
    };
    Loot.prototype.clearStar = function () {
        this.Star = null;
    };
    Loot.prototype.setBattlePassPoints = function (points) {
        this.BattlePassPoints = points;
    };
    Loot.prototype.addSkin = function (id) { Loot.addCustomization(id, this.HeroSkins); };
    Loot.prototype.addSkins = function (ids) { Loot.addCustomizations(ids, this.HeroSkins); };
    Loot.prototype.removeSkin = function (id) { Loot.removeCustomization(id, this.HeroSkins); };
    Loot.prototype.removeAllSkins = function () { this.HeroSkins = []; };
    Loot.prototype.addTaunt = function (id) { Loot.addCustomization(id, this.Taunts); };
    Loot.prototype.addTaunts = function (ids) { Loot.addCustomizations(ids, this.Taunts); };
    Loot.prototype.removeTaunt = function (id) { Loot.removeCustomization(id, this.Taunts); };
    Loot.prototype.removeAllTaunts = function () { this.Taunts = []; };
    Loot.prototype.addEmoji = function (id) { Loot.addCustomization(id, this.Emoji); };
    Loot.prototype.addEmotes = function (ids) { Loot.addCustomizations(ids, this.Emoji); };
    Loot.prototype.removeEmoji = function (id) { Loot.removeCustomization(id, this.Emoji); };
    Loot.prototype.removeAllEmoji = function () { this.Emoji = []; };
    Loot.prototype.addTextEmojiPack = function (id) { Loot.addCustomization(id, this.TextEmojiPacks); };
    Loot.prototype.addTextEmojiPacks = function (ids) { Loot.addCustomizations(ids, this.TextEmojiPacks); };
    Loot.prototype.removeTextEmojiPack = function (id) { Loot.removeCustomization(id, this.TextEmojiPacks); };
    Loot.prototype.removeAllTextEmojiPacks = function () { this.TextEmojiPacks = []; };
    Loot.prototype.addStance = function (id) { Loot.addCustomization(id, this.Stances); };
    Loot.prototype.addStances = function (ids) { Loot.addCustomizations(ids, this.Stances); };
    Loot.prototype.removeStance = function (id) { Loot.removeCustomization(id, this.Stances); };
    Loot.prototype.removeAllStances = function () { this.Stances = []; };
    Loot.prototype.addWeapon = function (id) { Loot.addCustomization(id, this.Weapons); };
    Loot.prototype.addWeapons = function (ids) { Loot.addCustomizations(ids, this.Weapons); };
    Loot.prototype.removeWeapon = function (id) { Loot.removeCustomization(id, this.Weapons); };
    Loot.prototype.removeAllWeapon = function () { this.Weapons = []; };
    Loot.prototype.mergeCustomizationShards = function (shards) {
        if (!shards || Object.keys(shards).length == 0)
            return;
        for (var _i = 0, _a = Object.keys(shards); _i < _a.length; _i++) {
            var compositeId = _a[_i];
            var amount = shards[+compositeId];
            if (!amount || amount <= 0)
                continue;
            this.addCustomizationShards(+compositeId, amount);
        }
    };
    Loot.prototype.addCustomizationShards = function (compositeId, amount) {
        if (!this.CustomizationShards) {
            this.CustomizationShards = {};
        }
        var owned = this.CustomizationShards[compositeId];
        if (!owned) {
            this.CustomizationShards[compositeId] = amount;
            return;
        }
        this.CustomizationShards[compositeId] = (+owned || 0) + amount;
    };
    Loot.prototype.removeAllCustomizationShards = function () { this.CustomizationShards = {}; };
    Loot.prototype.removeCustomizationShards = function (compositeId, amount) {
        if (amount <= 0)
            return;
        var customizationShards = this.CustomizationShards;
        if (!customizationShards)
            return;
        var content = customizationShards[compositeId];
        if (!content || content <= 0)
            return;
        var targetAmount = content - amount;
        if (targetAmount > 0) {
            customizationShards[compositeId] = targetAmount;
            return;
        }
        delete customizationShards[compositeId];
    };
    Loot.prototype.setAdvertising = function (advertising) {
        this.Advertisement = Advertising.copyAdvertisingObject(advertising);
    };
    Loot.prototype.isAdvertising = function () {
        return !!this.Advertisement;
    };
    Loot.prototype.clearAdvertising = function () {
        this.Advertisement = null;
    };
    Loot.prototype.combineLoot = function (other) {
        this.AccountExp += other.AccountExp;
        this.BattlePassPoints += other.BattlePassPoints;
        this.BattlePassLevels += other.BattlePassLevels;
        for (var type in CURRENCY) {
            if (isNumber(type)) {
                this.setCurrency(+type, this.getCurrencyByType(type) + other.getCurrencyByType(type));
            }
        }
        for (var heroID in other.HeroExp) {
            if (!this.HeroExp[heroID]) {
                this.HeroExp[heroID] = 0;
            }
            this.HeroExp[heroID] += other.HeroExp[heroID];
        }
        for (var heroID in other.Shards) {
            if (!this.Shards[heroID]) {
                this.Shards[heroID] = 0;
            }
            this.Shards[heroID] += other.Shards[heroID];
        }
        for (var modifierId in other.Modifiers) {
            if (!this.Modifiers[modifierId]) {
                this.Modifiers[modifierId] = 0;
            }
            this.Modifiers[modifierId] += other.Modifiers[modifierId];
        }
        if (other.Star && !this.Star) {
            this.setStar(other.Star);
        }
        this.addSkins(other.HeroSkins);
        this.addTaunts(other.Taunts);
        this.addEmotes(other.Emoji);
        this.addStances(other.Stances);
        this.addWeapons(other.Weapons);
        this.addTextEmojiPacks(other.TextEmojiPacks);
        if (other.hasCustomizationShards()) {
            this.mergeCustomizationShards(other.CustomizationShards);
        }
        if (other.Advertisement) {
            if (!this.Advertisement) {
                this.setAdvertising(other.Advertisement);
            }
            else {
                var quantity = this.Advertisement.Quantity + other.Advertisement.Quantity;
                var extraAdParameters = this.Advertisement.ExtraAdParameters || other.Advertisement.ExtraAdParameters;
                CommonUtils.replaceReadOnlyProperty(this.Advertisement, "Quantity", quantity);
                if (extraAdParameters) {
                    CommonUtils.replaceReadOnlyProperty(this.Advertisement, "ExtraAdParameters", extraAdParameters);
                }
            }
        }
    };
    Loot.prototype.isEmpty = function () {
        return !this.hasCustomize()
            && !this.hasCurrency()
            && !this.hasCards()
            && !this.hasShards()
            && !this.AccountExp
            && !this.BattlePassPoints
            && !this.BattlePassLevels
            && !this.hasModifiers()
            && !this.Star
            && !this.hasCustomizationShards();
    };
    Loot.prototype.hasCustomize = function () {
        return (this.Stances.length > 0
            || this.Taunts.length > 0
            || this.Emoji.length > 0
            || this.Weapons.length > 0
            || this.HeroSkins.length > 0
            || this.TextEmojiPacks.length > 0);
    };
    Loot.prototype.hasCurrency = function () {
        for (var type in this.Currencies) {
            if (this.Currencies[type]) {
                return true;
            }
        }
        return false;
    };
    Loot.prototype.hasCards = function () {
        var _this = this;
        return Object.keys(this.HeroExp).reduce(function (a, v) { return a + _this.HeroExp[v]; }, 0) > 0;
    };
    Loot.prototype.hasShards = function () {
        var _this = this;
        return Object.keys(this.Shards).reduce(function (a, v) { return a + _this.Shards[v]; }, 0) > 0;
    };
    Loot.prototype.hasModifiers = function () {
        var _this = this;
        return Object.keys(this.Modifiers).reduce(function (a, v) { return a + _this.Modifiers[v]; }, 0) > 0;
    };
    Loot.prototype.hasCustomizationShards = function () {
        var collections = this.CustomizationShards;
        if (!collections)
            return false;
        for (var _i = 0, _a = Object.keys(collections); _i < _a.length; _i++) {
            var compId = _a[_i];
            var content = collections[+compId];
            if (!content && content <= 0)
                continue;
            return true;
        }
        return false;
    };
    Loot.prototype.getUniqueHashOfContent = function () {
        var strings = [];
        var arraysData = [
            { data: Object.keys(this.HeroExp).sort(CommonUtils.defaultNumberComparator), key: "ehe" },
            { data: Object.keys(this.Shards).sort(CommonUtils.defaultNumberComparator), key: "shs" },
            { data: Object.keys(this.Currencies).sort(CommonUtils.defaultNumberComparator), key: "cur" },
            { data: this.Taunts.slice().sort(CommonUtils.defaultNumberComparator), key: "ta" },
            { data: this.HeroSkins.slice().sort(CommonUtils.defaultNumberComparator), key: "sk" },
            { data: this.Emoji.slice().sort(CommonUtils.defaultNumberComparator), key: "em" },
            { data: this.Stances.slice().sort(CommonUtils.defaultNumberComparator), key: "st" },
            { data: this.Weapons.slice().sort(CommonUtils.defaultNumberComparator), key: "we" },
            { data: this.TextEmojiPacks.slice().sort(CommonUtils.defaultNumberComparator), key: "tp" },
        ];
        arraysData.forEach(function (el) { return strings.push(el.key + el.data.join(".")); });
        return CommonUtils.hashCode(strings.join());
    };
    Loot.addCustomization = function (id, customizeRef) {
        customizeRef.push(id);
    };
    Loot.addCustomizations = function (ids, customizeRef) {
        for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
            var id = ids_1[_i];
            customizeRef.push(id);
        }
    };
    Loot.removeCustomization = function (id, customizeRef) {
        var index = customizeRef.indexOf(id);
        if (index > -1) {
            customizeRef.splice(index, 1);
        }
    };
    Loot.prototype.setCurrencySettings = function (currencies) {
        if (currencies === void 0) { currencies = null; }
        this.Currencies = {};
        if (currencies) {
            for (var type in CURRENCY) {
                if (isNumber(type)) {
                    if (currencies[type] > 0) {
                        this.setCurrency(+type, Math.ceil(currencies[type]));
                    }
                }
            }
        }
    };
    Loot.prototype.decomposeCustomizationsAsShards = function () {
        if (!this.hasCustomize())
            return;
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.Weapons, true), CUSTOMIZATION.WEAPON);
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.HeroSkins, true), CUSTOMIZATION.SKIN);
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.Taunts, true), CUSTOMIZATION.TAUNT);
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.Stances, true), CUSTOMIZATION.STANCE);
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.Emoji, true), CUSTOMIZATION.EMOJI);
        this.decomposeCustomizationsAndAddShards(__spreadArray([], this.TextEmojiPacks, true), CUSTOMIZATION.TEXT_EMOJI_PACK);
    };
    Loot.prototype.decomposeCustomizationsAndAddShards = function (items, type) {
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var id = items_1[_i];
            var orderMap = CustomizationUtils.getOrderMap(type);
            var customize = orderMap.checkedGet(id);
            if (customize.ShardsNeeded && customize.ShardsNeeded > 0) {
                var compositeId = CustomizationUtils.getCompositeCustomizationShardID({ id: id, type: type });
                this.addCustomizationShards(compositeId, customize.ShardsNeeded);
                this.removeCustomization(type, id);
            }
        }
    };
    Loot.prototype.removeCustomization = function (customizationType, entityId, repeats) {
        if (repeats === void 0) { repeats = 1; }
        switch (customizationType) {
            case CUSTOMIZATION.SKIN:
                for (var i = 0; i < repeats; i++)
                    this.removeSkin(entityId);
                break;
            case CUSTOMIZATION.WEAPON:
                for (var i = 0; i < repeats; i++)
                    this.removeWeapon(entityId);
                break;
            case CUSTOMIZATION.STANCE:
                for (var i = 0; i < repeats; i++)
                    this.removeStance(entityId);
                break;
            case CUSTOMIZATION.TAUNT:
                for (var i = 0; i < repeats; i++)
                    this.removeTaunt(entityId);
                break;
            case CUSTOMIZATION.EMOJI:
                for (var i = 0; i < repeats; i++)
                    this.removeEmoji(entityId);
                break;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                for (var i = 0; i < repeats; i++)
                    this.removeTextEmojiPack(entityId);
                break;
        }
    };
    return Loot;
}());
