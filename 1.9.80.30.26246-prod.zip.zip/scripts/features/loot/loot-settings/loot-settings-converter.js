var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var LootSettingsConverter = (function () {
    function LootSettingsConverter() {
    }
    LootSettingsConverter.convert = function (settings) {
        var result = {};
        if (settings.CardsSlots) {
            var rarities = {};
            for (var rarityNumberString in settings.CardsSlots.Rarities) {
                var raritySettings = settings.CardsSlots.Rarities[rarityNumberString];
                var resultRaritySettings = {
                    Slots: raritySettings.Slots,
                    CardsWeight: [],
                };
                for (var _i = 0, _a = raritySettings.CardsWeight; _i < _a.length; _i++) {
                    var variant = _a[_i];
                    resultRaritySettings.CardsWeight.push({ W: variant.Weight, N: variant.Amount });
                }
                CommonUtils.replaceReadOnlyProperty(rarities, rarityNumberString, resultRaritySettings);
            }
            CommonUtils.replaceReadOnlyProperty(result, "CardsSlots", {
                TotalSlots: settings.CardsSlots.TotalSlots,
                TotalCards: settings.CardsSlots.TotalCards,
                Rarities: rarities,
            });
        }
        if (settings.ShardsSlots) {
            if (!result.CardsSlots) {
                CommonUtils.replaceReadOnlyProperty(result, "CardsSlots", {
                    TotalSlots: 0,
                    TotalCards: 0,
                    Rarities: {},
                });
            }
            for (var rarityNumberString in settings.ShardsSlots.Rarities) {
                var raritySettings = settings.ShardsSlots.Rarities[rarityNumberString];
                var resultRaritySettings = result.CardsSlots.Rarities[rarityNumberString] || {
                    Slots: 0,
                    ShardsWeight: []
                };
                if (raritySettings.ShardsMode != undefined) {
                    CommonUtils
                        .replaceReadOnlyProperty(resultRaritySettings, "ShardsMode", raritySettings.ShardsMode);
                }
                var shardWeights = [];
                for (var _b = 0, _c = raritySettings.CardsWeight; _b < _c.length; _b++) {
                    var variant = _c[_b];
                    shardWeights.push({ W: variant.Weight, N: variant.Amount });
                }
                CommonUtils.replaceReadOnlyProperty(resultRaritySettings, "ShardsWeight", shardWeights);
                CommonUtils
                    .replaceReadOnlyProperty(result.CardsSlots.Rarities, rarityNumberString, resultRaritySettings);
            }
        }
        if (settings.CurrencySlots) {
            CommonUtils.replaceReadOnlyProperty(result, "CurrencySlots", {});
            for (var cType in settings.CurrencySlots) {
                result.CurrencySlots[cType] = [];
                for (var _d = 0, _e = settings.CurrencySlots[cType]; _d < _e.length; _d++) {
                    var variant = _e[_d];
                    result.CurrencySlots[cType].push({
                        Weight: variant.Weight,
                        Amount: new RndFromInterval(variant.Amount.min, variant.Amount.max)
                    });
                }
            }
        }
        if (settings.Weapons) {
            CommonUtils.replaceReadOnlyProperty(result, "Weapons", deepCopyOverJSON(settings.Weapons));
        }
        if (settings.AdditionalFixedLoot && !settings.AdditionalFixedLoot.isEmpty()) {
            CommonUtils.replaceReadOnlyProperty(result, "AdditionalFixedLoot", {});
            if (settings.AdditionalFixedLoot.hasCards()) {
                result.AdditionalFixedLoot.HeroExp = {};
                for (var hid in settings.AdditionalFixedLoot.HeroExp) {
                    result.AdditionalFixedLoot.HeroExp[hid] = settings.AdditionalFixedLoot.HeroExp[hid];
                }
            }
            if (settings.AdditionalFixedLoot.hasShards()) {
                result.AdditionalFixedLoot.Shards = {};
                for (var hid in settings.AdditionalFixedLoot.Shards) {
                    result.AdditionalFixedLoot.Shards[hid] = settings.AdditionalFixedLoot.Shards[hid];
                }
            }
            if (settings.AdditionalFixedLoot.hasCurrency()) {
                result.AdditionalFixedLoot.Currencies = {};
                for (var ctype in settings.AdditionalFixedLoot.Currencies) {
                    result.AdditionalFixedLoot.Currencies[ctype] = settings.AdditionalFixedLoot.Currencies[ctype];
                }
            }
            if (settings.AdditionalFixedLoot.HeroSkins.length) {
                result.AdditionalFixedLoot.Skins = settings.AdditionalFixedLoot.HeroSkins.slice();
            }
            if (settings.AdditionalFixedLoot.Emoji.length) {
                result.AdditionalFixedLoot.Emoji = settings.AdditionalFixedLoot.Emoji.slice();
            }
            if (settings.AdditionalFixedLoot.TextEmojiPacks.length) {
                result.AdditionalFixedLoot.TextEmojiPacks = settings.AdditionalFixedLoot.TextEmojiPacks.slice();
            }
            if (settings.AdditionalFixedLoot.Taunts.length) {
                result.AdditionalFixedLoot.Taunts = settings.AdditionalFixedLoot.Taunts.slice();
            }
            if (settings.AdditionalFixedLoot.Stances.length) {
                result.AdditionalFixedLoot.Stances = settings.AdditionalFixedLoot.Stances.slice();
            }
            if (settings.AdditionalFixedLoot.Weapons.length) {
                result.AdditionalFixedLoot.Weapons = settings.AdditionalFixedLoot.Weapons.slice();
            }
            if (settings.AdditionalFixedLoot.BattlePassPoints) {
                result.AdditionalFixedLoot.BattlePassPoints = settings.AdditionalFixedLoot.BattlePassPoints;
            }
            if (settings.AdditionalFixedLoot.BattlePassLevels) {
                result.AdditionalFixedLoot.BattlePassLevels = settings.AdditionalFixedLoot.BattlePassLevels;
            }
            if (settings.AdditionalFixedLoot.AccountExp) {
                result.AdditionalFixedLoot.AccountExp = settings.AdditionalFixedLoot.AccountExp;
            }
            if (settings.AdditionalFixedLoot.Modifiers) {
                result.AdditionalFixedLoot.Modifiers = __assign({}, settings.AdditionalFixedLoot.Modifiers);
            }
            if (settings.AdditionalFixedLoot.Star) {
                result.AdditionalFixedLoot.Star = __assign({}, settings.AdditionalFixedLoot.Star);
            }
            if (settings.AdditionalFixedLoot.CustomizationShards) {
                result.AdditionalFixedLoot.CustomizationShards = __assign({}, settings.AdditionalFixedLoot.CustomizationShards);
            }
        }
        if (settings.RoguelikeModifiers) {
            CommonUtils
                .replaceReadOnlyProperty(settings, "RoguelikeModifiers", settings.RoguelikeModifiers.slice());
        }
        return result;
    };
    return LootSettingsConverter;
}());
