var LootGeneratorAdditionalSettings = (function () {
    function LootGeneratorAdditionalSettings(settings) {
        this.settings = {};
        if (settings) {
            for (var settingName in settings) {
                this.settings[settingName] = settings[settingName];
            }
        }
    }
    LootGeneratorAdditionalSettings.prototype.getChestId = function () {
        return this.settings.chestId || null;
    };
    LootGeneratorAdditionalSettings.prototype.getCardsRate = function () {
        return this.settings.cardsRate || null;
    };
    return LootGeneratorAdditionalSettings;
}());
