var ShardsGenerator = (function () {
    function ShardsGenerator() {
    }
    ShardsGenerator.prototype.getHeroIdsForGeneratingByShardsMode = function (settings) {
        var availableHeroesForDuplicates = settings.availableHeroesForDuplicates, availableHeroesForShards = settings.availableHeroesForShards, mode = settings.mode, modeChancesTable = settings.modeChancesTable, rnd = settings.rnd, strictMode = settings.strictMode;
        var idsForGenerating = [];
        mode = mode || LootConstants.defaultShardsGeneratingMode;
        if (!modeChancesTable) {
            modeChancesTable = LootConstants.shardsModeDistribution;
        }
        switch (mode) {
            case SHARDS_GENERATING_MODE.SHARDS:
                idsForGenerating = availableHeroesForShards.length > 0 || strictMode
                    ? availableHeroesForShards
                    : availableHeroesForDuplicates;
                break;
            case SHARDS_GENERATING_MODE.DUPLICATES:
                idsForGenerating = availableHeroesForDuplicates.length > 0 || strictMode
                    ? availableHeroesForDuplicates
                    : availableHeroesForShards;
                break;
            default:
                var collection = new RandomCollection();
                var shardsWeight = modeChancesTable[SHARDS_GENERATING_MODE.SHARDS] || 1;
                var duplicatesWeight = modeChancesTable[SHARDS_GENERATING_MODE.DUPLICATES] || 1;
                collection.add(new CollectionObjectContainer(availableHeroesForShards, shardsWeight));
                collection.add(new CollectionObjectContainer(availableHeroesForDuplicates, duplicatesWeight));
                if (collection.size() > 0) {
                    idsForGenerating = collection.next(rnd).get();
                }
                if (idsForGenerating.length == 0) {
                    idsForGenerating = availableHeroesForShards.concat(availableHeroesForDuplicates);
                }
                break;
        }
        return idsForGenerating;
    };
    ShardsGenerator.prototype.getRandomHero = function (settings) {
        var playerProgress = settings.playerProgress, availablePool = settings.availablePool, rnd = settings.rnd;
        if (!availablePool || availablePool.length == 0) {
            return undefined;
        }
        var heroGroups = {};
        var maxGroup = 0;
        availablePool.sort(function (id1, id2) { return id1 - id2; });
        for (var _i = 0, availablePool_1 = availablePool; _i < availablePool_1.length; _i++) {
            var hid = availablePool_1[_i];
            var heroState = playerProgress.heroes[hid];
            var groupId = heroState ? heroState.TalentLevel + 1 : 0;
            maxGroup = Math.max(maxGroup, groupId);
            if (heroGroups[groupId] == undefined) {
                heroGroups[groupId] = [];
            }
            heroGroups[groupId].push(hid);
        }
        var collection = new RandomCollection();
        for (var groupId = 0; groupId <= maxGroup; groupId++) {
            if (heroGroups[groupId] == undefined) {
                continue;
            }
            var groupWeight = maxGroup - groupId + 1;
            groupWeight *= LootUtils.getModificationShardWeight(groupWeight, LootConstants.shardsModificationProgress);
            collection.add(new CollectionObjectContainer(groupId, groupWeight));
        }
        if (collection.size() == 0) {
            return undefined;
        }
        var chosenGroup = heroGroups[collection.next(rnd).get()];
        if (!chosenGroup) {
            return undefined;
        }
        collection.clear();
        for (var _a = 0, chosenGroup_1 = chosenGroup; _a < chosenGroup_1.length; _a++) {
            var hid = chosenGroup_1[_a];
            var hero = heroesMap.checkedGet(hid);
            var weight = 0;
            if (playerProgress.heroes[hid] == undefined) {
                var shards = playerProgress.heroShards[hid] || 0;
                shards += 1;
                weight = hero.ShardsWeightForGenerating * (shards / hero.ShardsNeeded);
            }
            else {
                var heroState = playerProgress.heroes[hid];
                var partTalentLevel = hero.getTalentPartLevel(heroState.TalentLevel, heroState.Duplicates + 1);
                weight = (hero.DuplicatesWeightForGenerating * (partTalentLevel - heroState.TalentLevel)) || MAX_TALENT_MIN_WEIGHT;
            }
            weight *= LootUtils.getModificationShardWeight(weight, LootConstants.shardsModificationContent);
            collection.add(new CollectionObjectContainer(hid, weight));
        }
        if (collection.size() == 0) {
            return undefined;
        }
        return collection.next(rnd).get();
    };
    ShardsGenerator.prototype.getAvailableHeroesForDuplicatesAndShards = function (settings) {
        var playerProgress = settings.playerProgress, availableSeparated = settings.availableSeparated;
        var result = {};
        var fullProgressHeroes = {};
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            var rarity = hero.Rarity;
            var isHeroAvailable = availableSeparated.available[rarity] && availableSeparated.available[rarity].shards.indexOf(hid) > -1;
            var state = playerProgress.heroes[hid];
            var availableQuantities = hero.getAvailableShardsAndCardsQuantity(state, playerProgress.heroShards[hid]);
            if (isHeroAvailable) {
                if (result[rarity] == undefined) {
                    result[rarity] = { duplicates: [], shards: [], };
                }
                if (fullProgressHeroes[hero.Rarity] == undefined) {
                    fullProgressHeroes[hero.Rarity] = [];
                }
                if (state == undefined && hero.ShardsWeightForGenerating > 0) {
                    result[rarity].shards.push(hid);
                }
                else if (state != undefined && hero.DuplicatesWeightForGenerating > 0) {
                    if (availableQuantities.availableShardsQuantity == 0) {
                        fullProgressHeroes[rarity].push(hid);
                    }
                    else {
                        result[rarity].duplicates.push(hid);
                    }
                }
            }
        }
        for (var rarityNumber in result) {
            var infoByRarity = result[rarityNumber];
            if (infoByRarity.shards.length == 0 && infoByRarity.duplicates.length == 0) {
                infoByRarity.duplicates = fullProgressHeroes[rarityNumber];
            }
        }
        return result;
    };
    ShardsGenerator.prototype.generate = function (settings) {
        var playerProgress = settings.playerProgress, availableSettings = settings.availableSettings, availableSeparated = settings.availableSeparated, rnd = settings.rnd, flags = settings.flags;
        var rarityOrder = LootConstants.orderRarity.slice();
        var heroesForDuplicatesAndShards = this.getAvailableHeroesForDuplicatesAndShards(settings);
        var isShop = FlagUtils.check(LootConstants.flag.ShopGeneration, flags);
        var result = new Loot();
        for (var _i = 0, rarityOrder_1 = rarityOrder; _i < rarityOrder_1.length; _i++) {
            var rarityNumber = rarityOrder_1[_i];
            var shardsWeightsAmounts = availableSettings.Rarities[rarityNumber] && availableSettings.Rarities[rarityNumber].ShardsWeight;
            if (shardsWeightsAmounts != undefined && heroesForDuplicatesAndShards[rarityNumber] != undefined) {
                var collection = LootUtils.getCollectionFromRandomWeights(shardsWeightsAmounts);
                var amount = +collection.next(rnd).get();
                if (!amount || amount < 0) {
                    continue;
                }
                var shardMode = availableSettings.Rarities[rarityNumber].ShardsMode;
                var idsPool = this.getHeroIdsForGeneratingByShardsMode({
                    availableHeroesForShards: heroesForDuplicatesAndShards[rarityNumber].shards,
                    availableHeroesForDuplicates: heroesForDuplicatesAndShards[rarityNumber].duplicates,
                    mode: shardMode,
                    strictMode: isShop,
                    rnd: rnd,
                });
                if (idsPool.length == 0) {
                    continue;
                }
                var heroId = this.getRandomHero({
                    availablePool: idsPool,
                    playerProgress: playerProgress,
                    rnd: rnd,
                });
                if (heroId) {
                    result.setShards(heroId, amount);
                }
            }
        }
        return result;
    };
    return ShardsGenerator;
}());
