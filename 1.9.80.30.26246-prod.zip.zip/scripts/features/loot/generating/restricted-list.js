var RestrictedList = (function () {
    function RestrictedList() {
    }
    RestrictedList.getDefault = function () {
        var result = { Cards: [], Shards: [] };
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            if (!hero.ShardsWeightForGenerating && !hero.DuplicatesWeightForGenerating) {
                result.Shards.push(hid);
            }
        }
        return result;
    };
    RestrictedList.extend = function (currentList, addedRL) {
        for (var _i = 0, _a = addedRL.Cards; _i < _a.length; _i++) {
            var heroID = _a[_i];
            if (currentList.Cards.indexOf(heroID) == -1) {
                currentList.Cards.push(heroID);
            }
        }
        for (var _b = 0, _c = addedRL.Shards; _b < _c.length; _b++) {
            var heroID = _c[_b];
            if (currentList.Shards.indexOf(heroID) == -1) {
                currentList.Shards.push(heroID);
            }
        }
    };
    RestrictedList.extendByLocks = function (currentList) {
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var heroID = _a[_i];
            var hero = heroesMap.get(heroID);
            if (hero.LockCards) {
                if (currentList.Cards.indexOf(heroID) == -1) {
                    currentList.Cards.push(heroID);
                }
            }
            if (hero.LockShards) {
                if (currentList.Shards.indexOf(heroID) == -1) {
                    currentList.Shards.push(heroID);
                }
            }
        }
    };
    RestrictedList.extendShardsByAccount = function (currentList, playerProgress) {
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            if (playerProgress.heroes[hid] == undefined) {
                if ((!hero.ShardsWeightForGenerating && !hero.DuplicatesWeightForGenerating)
                    || playerProgress.accountLevel < hero.AccLevelNeeded
                    || hero.ArenaNumberNeeded != 1) {
                    if (currentList.Shards.indexOf(hid) == -1) {
                        currentList.Shards.push(hid);
                    }
                }
            }
        }
    };
    RestrictedList.extendByBlockedByTime = function (currentList, serverTime) {
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            if (hero.UnlockHeroSinceDateTime && hero.UnlockHeroSinceDateTime > serverTime) {
                if (currentList.Shards.indexOf(hid) == -1) {
                    currentList.Shards.push(hid);
                }
                if (currentList.Cards.indexOf(hid) == -1) {
                    currentList.Cards.push(hid);
                }
            }
        }
    };
    RestrictedList.updateByLoot = function (list, loot) {
        for (var heroId in loot.HeroExp) {
            var id = Number(heroId);
            if (list.Cards.indexOf(id) == -1) {
                list.Cards.push(id);
            }
        }
        for (var heroId in loot.Shards) {
            var id = Number(heroId);
            if (list.Shards.indexOf(id) == -1) {
                list.Shards.push(id);
            }
        }
    };
    RestrictedList.clear = function (list) {
        list.Cards = [];
        list.Shards = [];
    };
    return RestrictedList;
}());
