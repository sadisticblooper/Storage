var LootGeneratorBuilder = (function () {
    function LootGeneratorBuilder() {
    }
    LootGeneratorBuilder.getChestLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlag(LootConstants.flag.ChestGeneration);
        generator.setFlag(LootConstants.flag.CompensateCustomizations);
        return generator;
    };
    LootGeneratorBuilder.getCommonLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.CompensateCustomizations,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getTournamentLootGenerator = function () {
        return this.getCommonLootGenerator();
    };
    LootGeneratorBuilder.getBattlePassLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getMailMessageLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.CompensateCustomizations,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getEventShopLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getSeasonShopLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.IgnoreCustomizationRepeatsInFixedLoot,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getRouletteLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.IgnoreCustomizationRepeatsInFixedLoot,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getPromoCodesLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.IgnoreCustomizationRepeatsInFixedLoot,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getOffersLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.CompensateCustomizations,
            LootConstants.flag.SkipFixedCardsAndShardsCompensation,
            LootConstants.flag.IgnoreOverflowShardsCheck,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getMarathonsLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.IgnoreLocksForCardsAndShards,
            LootConstants.flag.CompensateCustomizations,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getShopLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.ShopGeneration,
            LootConstants.flag.CompensateCustomizations,
        ]);
        return generator;
    };
    LootGeneratorBuilder.getGachaLootGenerator = function () {
        var generator = new LootGenerator();
        generator.setFlags([
            LootConstants.flag.SkipFixedLootCompensation,
            LootConstants.flag.IgnoreOverflowShardsCheck,
        ]);
        generator.setAdditionalSettings(new LootGeneratorAdditionalSettings({
            cardsRate: LootConstants.cardsRateTable,
        }));
        return generator;
    };
    return LootGeneratorBuilder;
}());
