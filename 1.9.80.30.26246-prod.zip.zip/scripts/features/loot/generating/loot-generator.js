var LootGenerator = (function () {
    function LootGenerator() {
        this._restrictedList = RestrictedList.getDefault();
        this._flags = 0;
        this._additionalSettings = new LootGeneratorAdditionalSettings();
    }
    LootGenerator.prototype.setFlag = function (flag) { this._flags = FlagUtils.set(flag, this._flags); };
    LootGenerator.prototype.unsetFlag = function (flag) { this._flags = FlagUtils.unset(flag, this._flags); };
    LootGenerator.prototype.setFlags = function (flags) { for (var _i = 0, flags_1 = flags; _i < flags_1.length; _i++) {
        var flag = flags_1[_i];
        this._flags = FlagUtils.set(flag, this._flags);
    } };
    LootGenerator.prototype.setLootSettings = function (settings) {
        this._lootSettings = settings;
    };
    LootGenerator.prototype.setLootSettings_oldFormat = function (settings) {
        this._lootSettings = LootSettingsConverter.convert(settings);
    };
    LootGenerator.prototype.setAdditionalSettings = function (settings) {
        if (settings) {
            this._additionalSettings = settings;
        }
    };
    LootGenerator.prototype.setPlayerParams = function (playerProgress) {
        this._playerProgress = deepCopyOverJSON(playerProgress);
    };
    LootGenerator.prototype.setRestrictedList = function (restrictedList) {
        this._outRestrictedList = restrictedList;
    };
    LootGenerator.prototype.setServerTime = function (serverTime) {
        this._currentServerTime = serverTime;
    };
    LootGenerator.prototype.checkParamsExist = function () {
        if (!this._lootSettings || !this.checkPlayerProgress()) {
            throw new Error("LootGenerator error: you need to call SetLootSettings and SetPlayerParams methods");
        }
    };
    LootGenerator.prototype.checkPlayerProgress = function () {
        return !!this._playerProgress;
    };
    LootGenerator.prototype.checkServerTimeExist = function () {
        if (!this._currentServerTime) {
            throw new Error("LootGenerator error: you need to set currentServerTime");
        }
    };
    LootGenerator.prototype.generateLoot = function (rng) {
        this.checkParamsExist();
        var result = new Loot();
        if (this._lootSettings.AdditionalFixedLoot
            && !FlagUtils.check(LootConstants.flag.SkipAdditionalFixedLootGenerating, this._flags)) {
            var fixedLoot = this.getLootFromFixedLoot(new Loot(this._lootSettings.AdditionalFixedLoot));
            if (!fixedLoot.isEmpty()) {
                result.combineLoot(fixedLoot);
                HeroUtils.combineLoot(this._playerProgress, fixedLoot);
                EXTENDED_DROP_POPUP_PROXY_MANAGER.addFixedLoot(fixedLoot);
            }
        }
        if (this._lootSettings.CardsSlots) {
            this.checkServerTimeExist();
            var cardsShardsLoot = this.generateCardsAndShards(rng);
            HeroUtils.combineLoot(this._playerProgress, cardsShardsLoot);
            result.combineLoot(cardsShardsLoot);
        }
        if (this._lootSettings.CurrencySlots) {
            result.combineLoot(this.generateCurrency(rng));
        }
        var customizationLoot = this.generateCustomizationsFromLootSettings(rng);
        if (!customizationLoot.isEmpty()) {
            HeroUtils.combineLoot(this._playerProgress, customizationLoot);
            result.combineLoot(customizationLoot);
        }
        if (this._lootSettings.CustomizationShards) {
            var shardsLoot = this.generateCustomizationShards(rng);
            if (!shardsLoot.isEmpty()) {
                HeroUtils.combineLoot(this._playerProgress, shardsLoot);
                result.combineLoot(shardsLoot);
            }
        }
        if (this._lootSettings.RoguelikeModifiers) {
            var lootWithModifiers = this.generateRoguelikeModifiers(rng);
            result.combineLoot(lootWithModifiers);
        }
        return result;
    };
    LootGenerator.prototype.generateCardsAndShards = function (rng) {
        this.prepareRestrictedList();
        var availableSeparated = HeroUtils.getAvailableSeparatedHeroes(this._playerProgress, this._restrictedList);
        if (FlagUtils.check(LootConstants.flag.ExpandAvailableList, this._flags)) {
            availableSeparated = HeroUtils.getExpandedAvailableSeparatedHeroes(this._playerProgress, availableSeparated, this._lootSettings.CardsSlots, this._restrictedList);
        }
        var availableSettings = LootUtils.getCorrectedCardsSettings({
            cardsSlots: this._lootSettings.CardsSlots,
            availableSettings: availableSeparated,
            cardsRate: this._additionalSettings.getCardsRate(),
        });
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setCorrectedCardsSettings(availableSettings);
        var rarityOrder = LootConstants.orderRarity.slice();
        var heroWeights = this.getHeroWeights({ availableSeparated: availableSeparated }).heroWeights;
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setHeroCardsWeights(heroWeights);
        var cardAmounts = this.getAmountsForGenerating({
            rarityOrder: rarityOrder,
            availableSeparated: availableSeparated,
            availableSettings: availableSettings,
            rng: rng,
            isShop: FlagUtils.check(LootConstants.flag.ShopGeneration, this._flags),
        }).cardAmounts;
        var slotAmounts = this.getSlotAmounts({
            rarityOrder: rarityOrder,
            availableSettings: availableSettings,
            availableSeparated: availableSeparated,
            cardAmounts: cardAmounts,
        }).slotAmounts;
        var resultLoot = new Loot();
        for (var _i = 0, rarityOrder_1 = rarityOrder; _i < rarityOrder_1.length; _i++) {
            var rarityNumber = rarityOrder_1[_i];
            if (!availableSettings.Rarities[rarityNumber]) {
                continue;
            }
            var cards = cardAmounts[rarityNumber] ? cardAmounts[rarityNumber] : 0;
            var slots = slotAmounts[rarityNumber] ? slotAmounts[rarityNumber] : 0;
            if (cards > 0 && slots > 0) {
                var amounts = ArrayUtils.redistributePile(cards, slots, LootConstants.KPile);
                for (var _a = 0, amounts_1 = amounts; _a < amounts_1.length; _a++) {
                    var amount = amounts_1[_a];
                    var hid = LootUtils.getHeroIDFromWeights(heroWeights[rarityNumber], rng);
                    if (hid) {
                        resultLoot.setHeroExp(hid, amount);
                        delete heroWeights[rarityNumber][hid];
                    }
                }
            }
        }
        var shardsGenerator = new ShardsGenerator();
        resultLoot.combineLoot(shardsGenerator.generate({
            playerProgress: this._playerProgress,
            availableSettings: availableSettings,
            availableSeparated: availableSeparated,
            flags: this._flags,
            rnd: rng,
        }));
        return resultLoot;
    };
    LootGenerator.prototype.getHeroWeights = function (settings) {
        var availableSeparated = settings.availableSeparated;
        var availableHeroesSeparated = availableSeparated.available;
        var maxLevels = {};
        var heroWeights = {};
        for (var rarityNumber in availableHeroesSeparated)
            if (availableHeroesSeparated.hasOwnProperty(rarityNumber)) {
                for (var _i = 0, _a = availableHeroesSeparated[rarityNumber].cards; _i < _a.length; _i++) {
                    var hid = _a[_i];
                    var trueState = Hero.upLevelIfNecessary(availableSeparated.heroesInfo[hid], hid);
                    var upgradeInfo = HeroUtils.heroLevelUpPrices(trueState.Level, hid);
                    var partLevelHero = upgradeInfo
                        ? trueState.Level + (trueState.Exp / upgradeInfo.exp)
                        : trueState.Level;
                    if (!heroWeights[rarityNumber]) {
                        heroWeights[rarityNumber] = {};
                    }
                    heroWeights[rarityNumber][hid] = partLevelHero;
                    maxLevels[rarityNumber] = maxLevels[rarityNumber]
                        ? Math.max(maxLevels[rarityNumber], trueState.Level)
                        : trueState.Level;
                }
            }
        for (var rarityNumber in availableHeroesSeparated)
            if (availableHeroesSeparated.hasOwnProperty(rarityNumber)) {
                for (var _b = 0, _c = availableHeroesSeparated[rarityNumber].cards; _b < _c.length; _b++) {
                    var hid = _c[_b];
                    var hero = heroesMap.checkedGet(hid);
                    var justOpenedHero = heroWeights[rarityNumber][hid] == hero.StartLevel;
                    if (FlagUtils.check(LootConstants.flag.ShopGeneration, this._flags)) {
                        var diff = this._playerProgress.accountLevel - Math.floor(heroWeights[rarityNumber][hid]);
                        heroWeights[rarityNumber][hid] = ShopUtils.findHeroWeightFromAccDiff(diff);
                    }
                    else {
                        if (FlagUtils.check(LootConstants.flag.ChestGeneration, this._flags) && justOpenedHero) {
                            heroWeights[rarityNumber][hid] = LootConstants.justOpenedHeroWeight;
                        }
                        else {
                            heroWeights[rarityNumber][hid]
                                = (maxLevels[rarityNumber] + 1 - heroWeights[rarityNumber][hid]) * 100;
                        }
                    }
                }
            }
        return {
            heroWeights: heroWeights,
        };
    };
    LootGenerator.prototype.getAmountsForGenerating = function (settings) {
        var availableSeparated = settings.availableSeparated, rarityOrder = settings.rarityOrder, availableSettings = settings.availableSettings, rng = settings.rng;
        var availableHeroesSeparated = availableSeparated.available;
        var cardAmounts = {};
        var cardMinAmounts = {};
        var cardMaxAmounts = {};
        var cardsSum = 0;
        for (var _i = 0, rarityOrder_2 = rarityOrder; _i < rarityOrder_2.length; _i++) {
            var rarityNumber = rarityOrder_2[_i];
            if (availableSettings.Rarities[rarityNumber]) {
                if (availableHeroesSeparated[rarityNumber]) {
                    var cardsWeightsAmounts = availableSettings.Rarities[rarityNumber].CardsWeight;
                    if (cardsWeightsAmounts != undefined && availableHeroesSeparated[rarityNumber].cards.length) {
                        var collection = LootUtils.getCollectionFromRandomWeights(cardsWeightsAmounts);
                        var amount = Number(collection.next(rng).get());
                        cardMinAmounts[rarityNumber] = CommonGameUtils.findMinimumFromWeights(cardsWeightsAmounts);
                        cardAmounts[rarityNumber] = amount;
                        cardMaxAmounts[rarityNumber] = Infinity;
                        cardsSum += amount;
                    }
                }
            }
        }
        if (cardsSum != availableSettings.TotalCards) {
            if (cardsSum < availableSettings.TotalCards) {
                var rarityIndex = 0;
                var infinityStop = LootConstants.orderRarity.length * 2;
                while (infinityStop--) {
                    var rarityNumber = LootConstants.orderRarity[rarityIndex];
                    if (cardAmounts[rarityNumber] != undefined) {
                        cardAmounts[rarityNumber] += availableSettings.TotalCards - cardsSum;
                        break;
                    }
                    rarityIndex = (rarityIndex + 1) % LootConstants.orderRarity.length;
                }
            }
            else {
                if (availableSettings.Rarities[HERO_RARITY.COMMON]
                    && cardAmounts[HERO_RARITY.COMMON] != undefined
                    && cardAmounts[HERO_RARITY.COMMON] > cardsSum - availableSettings.TotalCards) {
                    cardAmounts[HERO_RARITY.COMMON] -= (cardsSum - availableSettings.TotalCards);
                }
                else {
                    cardAmounts = this.getValidAmounts(availableSettings, availableSettings.TotalCards, cardAmounts, cardMinAmounts, cardMaxAmounts);
                }
            }
        }
        return {
            cardAmounts: cardAmounts,
        };
    };
    LootGenerator.prototype.getSlotAmounts = function (settings) {
        var rarityOrder = settings.rarityOrder, availableSeparated = settings.availableSeparated, availableSettings = settings.availableSettings, cardAmounts = settings.cardAmounts;
        var availableHeroesSeparated = availableSeparated.available;
        var slotAmounts = {};
        var slotMaxAmounts = {};
        var slotMinAmounts = {};
        var slotsSum = 0;
        for (var _i = 0, rarityOrder_3 = rarityOrder; _i < rarityOrder_3.length; _i++) {
            var rarityNumber = rarityOrder_3[_i];
            if (availableSettings.Rarities[rarityNumber]) {
                var cardAmount = cardAmounts[rarityNumber] ? cardAmounts[rarityNumber] : 0;
                var slots = availableSettings.Rarities[rarityNumber].Slots;
                var heroesCount = availableHeroesSeparated[rarityNumber].cards.length;
                var maxSlots = Math.min(cardAmount, heroesCount);
                slots = Math.min(slots, maxSlots);
                slotsSum += slots;
                slotAmounts[rarityNumber] = slots;
                slotMaxAmounts[rarityNumber] = maxSlots;
                if (slots > 0) {
                    slotMinAmounts[rarityNumber] = 1;
                }
                else {
                    slotMinAmounts[rarityNumber] = 0;
                }
            }
        }
        if (slotsSum != availableSettings.TotalSlots) {
            if (slotsSum > availableSettings.TotalSlots) {
                slotAmounts = this.getValidAmounts(availableSettings, availableSettings.TotalSlots, slotAmounts, slotMinAmounts, slotMaxAmounts);
            }
        }
        return {
            slotAmounts: slotAmounts,
        };
    };
    LootGenerator.prototype.getValidAmounts = function (sets, g, c, mns, mxs) {
        var result = {};
        var curr_ = [];
        var mines_ = [];
        var maxes_ = [];
        for (var _i = 0, _a = LootConstants.orderRarity; _i < _a.length; _i++) {
            var rarityNumber = _a[_i];
            if (sets.Rarities[rarityNumber]) {
                curr_.push(c[rarityNumber]);
                mines_.push(mns[rarityNumber]);
                maxes_.push(mxs[rarityNumber]);
            }
        }
        var validCurr = ArrayUtils.getArrayProportionalMinimized(g, curr_, maxes_, mines_);
        var index = 0;
        for (var _b = 0, _c = LootConstants.orderRarity; _b < _c.length; _b++) {
            var rarityNumber = _c[_b];
            if (sets.Rarities[rarityNumber]) {
                result[rarityNumber] = validCurr[index];
                index++;
            }
        }
        return result;
    };
    LootGenerator.prototype.generateCurrency = function (rng) {
        var result = new Loot();
        var settings = this._lootSettings.CurrencySlots;
        var curOrder = Object.keys(settings).sort(function (a, b) { return Number(a) - Number(b); });
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setCurrencySettings(settings);
        for (var _i = 0, curOrder_1 = curOrder; _i < curOrder_1.length; _i++) {
            var currencyType = curOrder_1[_i];
            if (settings.hasOwnProperty(currencyType) && CURRENCY[currencyType]) {
                var collection = LootUtils.getCollectionFromRandomWeights(settings[currencyType]);
                var currency = collection.next(rng).get();
                var amount = currency.getRandomValue(rng);
                if (currencyType && amount) {
                    result.setCurrency(Number(currencyType), amount);
                }
            }
        }
        return result;
    };
    LootGenerator.prototype.generateCustomizationsFromLootSettings = function (rng) {
        var canRepeatCustomization = false;
        var chestId = this._additionalSettings.getChestId();
        if (chestId) {
            var chest = chestsMap.checkedGet(chestId);
            canRepeatCustomization = chest.canRepeatCustomization();
        }
        var customizationLootSettings = {};
        var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
        var specify = { chestId: chestId };
        for (var _i = 0, allCustomizations_1 = allCustomizations; _i < allCustomizations_1.length; _i++) {
            var customizationType = allCustomizations_1[_i];
            var customizationSettings = CustomizationUtils.getGeneratorLootSettingsContainer(customizationType, this._lootSettings);
            var customizationMap = CustomizationUtils.getOrderMap(customizationType);
            var playerIds = CustomizationUtils.getPlayerIdsContainer(customizationType, this._playerProgress);
            var availableList = CustomizationUtils.getAvailableIdsForRandomGenerating(customizationType, specify);
            if (customizationSettings && playerIds && customizationMap) {
                var ids = LootGenerator.generateCustomizations({
                    customizationSettings: customizationSettings,
                    customizationMap: customizationMap,
                    availableList: availableList,
                    playerIds: playerIds,
                    playerProgress: this._playerProgress,
                    canRepeatCustomization: canRepeatCustomization,
                    customizationType: customizationType,
                }, rng);
                if (ids.length) {
                    var pool = CustomizationUtils.createLootSettings(customizationType, customizationLootSettings);
                    pool.push.apply(pool, ids);
                }
            }
        }
        return new Loot(customizationLootSettings);
    };
    LootGenerator.generateCustomizations = function (settings, rnd) {
        var customizationSettings = settings.customizationSettings, customizationMap = settings.customizationMap, customizationType = settings.customizationType;
        var availableIds = LootUtils.getAvailableCustomizationsForGenerating(settings);
        if (!availableIds || availableIds.length == 0) {
            return [];
        }
        var availableByRarity = LootUtils.getSeparatedCustomizationsByRarity({
            customizationMap: customizationMap,
            availableIds: availableIds,
        });
        var collection = new RandomCollection();
        var sumChances = 0;
        var raritySettings = customizationSettings.Rarities;
        var idSettings = customizationSettings.Ids;
        var extendedRarityChances = {};
        var extendedIdChances = {};
        if (raritySettings && availableByRarity) {
            var ordered = Object.keys(raritySettings).sort(function (a, b) { return (+a) - (+b); });
            for (var _i = 0, ordered_1 = ordered; _i < ordered_1.length; _i++) {
                var rarityNumber = ordered_1[_i];
                if (availableByRarity[rarityNumber] && availableByRarity[rarityNumber].length) {
                    var item_1 = { type: "rarity", value: +rarityNumber };
                    var chance = raritySettings[rarityNumber];
                    collection.add(new CollectionObjectContainer(item_1, chance));
                    extendedRarityChances[rarityNumber] = chance;
                    sumChances += chance;
                }
            }
        }
        if (idSettings) {
            var ordered = Object.keys(idSettings).sort(function (a, b) { return (+a) - (+b); });
            for (var _a = 0, ordered_2 = ordered; _a < ordered_2.length; _a++) {
                var id = ordered_2[_a];
                if (availableIds.indexOf(+id) > -1) {
                    var item_2 = { type: 'id', value: +id };
                    var chance = idSettings[id];
                    collection.add(new CollectionObjectContainer(item_2, chance));
                    extendedIdChances[id] = chance;
                    sumChances += chance;
                }
            }
        }
        if (1 - sumChances > 0) {
            collection.add(new CollectionObjectContainer(null, 1 - sumChances));
        }
        if (collection.size() == 0) {
            return [];
        }
        EXTENDED_DROP_POPUP_PROXY_MANAGER.addCustomizationSettings({
            type: customizationType,
            rarityChances: extendedRarityChances,
            idChances: extendedIdChances,
            availableByRarity: availableByRarity,
        });
        var item = collection.next(rnd).get();
        if (item == null) {
            return [];
        }
        if (item.type == "id") {
            return [item.value];
        }
        else {
            var rarityIds = availableByRarity[item.value];
            var id = rarityIds[rnd.nextInt(rarityIds.length)];
            return [id];
        }
    };
    LootGenerator.prototype.generateCustomizationShards = function (rng) {
        var _a;
        var customizationSettings = this._lootSettings.CustomizationShards;
        var resultLoot = new Loot();
        if (customizationSettings.items) {
            var collection = new RandomCollection();
            for (var _i = 0, _b = customizationSettings.items; _i < _b.length; _i++) {
                var item = _b[_i];
                var itemParams = item.params;
                var weight = itemParams.W;
                collection.add(new CollectionObjectContainer(item, weight));
            }
            var selectedContainer = collection.next(rng);
            var selected = selectedContainer ? selectedContainer.get() : null;
            if (selected) {
                resultLoot.CustomizationShards = (_a = {}, _a[selected.id] = selected.params.N, _a);
                EXTENDED_DROP_POPUP_PROXY_MANAGER.addCustomizationShards(customizationSettings.items);
            }
        }
        return resultLoot;
    };
    LootGenerator.prototype.generateRoguelikeModifiers = function (rng) {
        var generatingSettings = this._lootSettings.RoguelikeModifiers;
        var result = new Loot();
        var collection = new RandomCollection();
        for (var _i = 0, generatingSettings_1 = generatingSettings; _i < generatingSettings_1.length; _i++) {
            var item = generatingSettings_1[_i];
            collection.add(new CollectionObjectContainer(item, item.w));
        }
        if (collection.size() > 0) {
            var randomItem = collection.next(rng).get();
            if (randomItem && randomItem.m) {
                for (var _a = 0, _b = randomItem.m; _a < _b.length; _a++) {
                    var modifier = _b[_a];
                    result.setModifier(modifier.id, modifier.a);
                }
            }
        }
        return result;
    };
    LootGenerator.prototype.getLootFromFixedLoot = function (loot) {
        var _a;
        if (FlagUtils.check(LootConstants.flag.SkipFixedLootCompensation, this._flags)) {
            return loot;
        }
        this.checkPlayerProgress();
        var correctedLoot = new Loot();
        if (!FlagUtils.check(LootConstants.flag.SkipAdditionalFixedLootGenerating, this._flags)) {
            for (var _i = 0, _b = heroesMap.getKeys(); _i < _b.length; _i++) {
                var hid = _b[_i];
                var shards = loot.Shards[hid] || 0;
                var cards = loot.HeroExp[hid] || 0;
                if (shards + cards == 0) {
                    continue;
                }
                if (this._playerProgress.heroes[hid] != undefined) {
                    if (cards > 0) {
                        correctedLoot.setHeroExp(hid, cards);
                    }
                    if (shards > 0) {
                        correctedLoot.setShards(hid, shards);
                    }
                }
                else {
                    var hero = heroesMap.get(hid);
                    var already = this._playerProgress.heroShards[hid];
                    if (already + shards >= hero.ShardsNeeded) {
                        if (cards > 0) {
                            correctedLoot.setHeroExp(hid, cards);
                        }
                        if (shards > 0) {
                            correctedLoot.setShards(hid, shards);
                        }
                    }
                    else {
                        if (already + shards + cards <= hero.ShardsNeeded) {
                            correctedLoot.setShards(hid, shards + cards);
                        }
                        else {
                            var toOpenHero = hero.ShardsNeeded - already;
                            cards = cards - (toOpenHero - shards);
                            shards = toOpenHero;
                            if (cards > 0) {
                                correctedLoot.setHeroExp(hid, cards);
                            }
                            if (shards > 0) {
                                correctedLoot.setShards(hid, shards);
                            }
                        }
                    }
                }
            }
        }
        else {
            correctedLoot.Shards = loot.Shards;
            correctedLoot.HeroExp = loot.HeroExp;
        }
        var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
        for (var _c = 0, allCustomizations_2 = allCustomizations; _c < allCustomizations_2.length; _c++) {
            var customizationType = allCustomizations_2[_c];
            var originalArray = CustomizationUtils.getLootIdsContainer(customizationType, loot);
            var correctedArray = CustomizationUtils.getLootIdsContainer(customizationType, correctedLoot);
            var playerIds = CustomizationUtils.getPlayerIdsContainer(customizationType, this._playerProgress);
            if (originalArray == undefined || playerIds == undefined || correctedArray == undefined) {
                continue;
            }
            for (var _d = 0, originalArray_1 = originalArray; _d < originalArray_1.length; _d++) {
                var id = originalArray_1[_d];
                if (playerIds.indexOf(id) > -1
                    && !FlagUtils.check(LootConstants.flag.IgnoreCustomizationRepeatsInFixedLoot, this._flags)) {
                    if (FlagUtils.check(LootConstants.flag.CompensateCustomizations, this._flags)) {
                        var compensation = LootUtils.getCompensate(customizationType, id);
                        correctedLoot.combineLoot(compensation);
                    }
                }
                else {
                    if (correctedArray.indexOf(id) == -1) {
                        correctedArray.push(id);
                    }
                }
            }
        }
        for (var cur in loot.Currencies)
            if (loot.Currencies.hasOwnProperty(cur)) {
                var already = correctedLoot.getCurrencyByType(cur);
                correctedLoot.setCurrency(Number(cur), already + loot.Currencies[cur]);
            }
        if (loot.AccountExp) {
            correctedLoot.AccountExp = loot.AccountExp;
        }
        if (loot.BattlePassPoints) {
            correctedLoot.BattlePassPoints = loot.BattlePassPoints;
        }
        if (loot.BattlePassLevels) {
            correctedLoot.BattlePassLevels = loot.BattlePassLevels;
        }
        for (var modifier in loot.Modifiers)
            if (loot.Modifiers.hasOwnProperty(modifier)) {
                var already = correctedLoot.getModifierByID(modifier);
                correctedLoot.setModifier(Number(modifier), already + loot.Modifiers[modifier]);
            }
        if (loot.hasCustomizationShards()) {
            for (var id in loot.CustomizationShards) {
                var shardId = +id;
                var shardsAmount = loot.CustomizationShards[shardId];
                var shardsData = CustomizationUtils.getCustomizationShardsData(shardId);
                var customizeContainer = CustomizationUtils.getPlayerIdsContainer(shardsData.customizationType, this._playerProgress);
                var hasCustomization = customizeContainer.indexOf(shardsData.entityId) > -1;
                var orderMap = CustomizationUtils.getOrderMap(shardsData.customizationType);
                var entity = orderMap.checkedGet(shardsData.entityId);
                var compensationRate = (_a = LootConstants.customizationShardsCompensatingRate[shardsData.customizationType]) === null || _a === void 0 ? void 0 : _a[entity.rarity];
                if (compensationRate == null) {
                    correctedLoot.CustomizationShards[shardId] = shardsAmount;
                    continue;
                }
                if (hasCustomization) {
                    var compensation = DefaultLootCompensator.getMultipleCurrencyLoot(shardsAmount, compensationRate);
                    correctedLoot.combineLoot(compensation);
                    continue;
                }
                correctedLoot.CustomizationShards[shardId] = shardsAmount;
            }
        }
        correctedLoot.setStar(loot.Star);
        return correctedLoot;
    };
    LootGenerator.prototype.prepareRestrictedList = function () {
        this._restrictedList = RestrictedList.getDefault();
        if (!FlagUtils.check(LootConstants.flag.IgnoreLocksForCardsAndShards, this._flags)) {
            RestrictedList.extendByLocks(this._restrictedList);
        }
        if (!FlagUtils.check(LootConstants.flag.IgnoreAccountParameters, this._flags)) {
            RestrictedList.extendShardsByAccount(this._restrictedList, this._playerProgress);
        }
        if (!FlagUtils.check(LootConstants.flag.IgnoreHeroDropBlockByTime, this._flags)) {
            RestrictedList.extendByBlockedByTime(this._restrictedList, this._currentServerTime);
        }
        if (this._outRestrictedList) {
            RestrictedList.extend(this._restrictedList, this._outRestrictedList);
        }
    };
    LootGenerator.prototype.getRewardFromRewardContent = function (reward, rnd) {
        var result = {
            Loot: new Loot(),
            Chests: [],
            NewSeed: 0,
            IsHidden: !!reward.isHidden,
        };
        if (reward.lootSettings) {
            this.setLootSettings_oldFormat(reward.lootSettings);
            result.Loot.combineLoot(this.generateLoot(rnd));
        }
        if (reward.loot) {
            var loot = this.getLootFromFixedLoot(reward.loot);
            HeroUtils.combineLoot(this._playerProgress, loot);
            result.Loot.combineLoot(loot);
        }
        if (reward.chests && reward.chests.length > 0) {
            result.Chests = reward.chests.slice();
        }
        result.NewSeed = rnd.nextInt(rnd.MAX_INTEGER());
        return result;
    };
    return LootGenerator;
}());
