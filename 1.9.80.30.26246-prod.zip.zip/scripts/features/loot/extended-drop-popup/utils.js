var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var ExtendedDropPopupUtils = (function () {
    function ExtendedDropPopupUtils() {
    }
    ExtendedDropPopupUtils.showRandomRewardFullscreenTooltip = function (settings) {
        return true;
    };
    ExtendedDropPopupUtils.getDroppedGroupId = function (type) {
        var params = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            params[_i - 1] = arguments[_i];
        }
        return __spreadArray([type], params, true).join("_");
    };
    ExtendedDropPopupUtils.getRandomRewardDetailsDrop = function (settings) {
        var _a, _b, _c;
        var rewardDataType = settings.rewardDataType, id = settings.id;
        settings.playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var result = null;
        var hero;
        var weapon;
        var lootSettings;
        switch (rewardDataType) {
            case RewardDataType.Chest:
                result = ExtendedDropPopupUtils.getChestRandomRewardDetailsDrop(settings);
                break;
            case RewardDataType.HeroCard:
                hero = heroesMap.checkedGet(id);
                lootSettings = {
                    CardsSlots: {
                        TotalSlots: 1, TotalCards: 1,
                        Rarities: (_a = {},
                            _a[hero.Rarity] = {
                                Slots: 1,
                                CardsWeight: [{ N: 1, W: 1 }]
                            },
                            _a)
                    }
                };
                result = ExtendedDropPopupUtils.getLootSettingsRandomRewardDetailsDrop(settings, lootSettings, id, ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, hero.Rarity));
                break;
            case RewardDataType.HeroShard:
                hero = heroesMap.checkedGet(id);
                lootSettings = {
                    CardsSlots: {
                        TotalSlots: 1, TotalCards: 1,
                        Rarities: (_b = {},
                            _b[hero.Rarity] = {
                                Slots: 1,
                                ShardsWeight: [{ N: 1, W: 1 }]
                            },
                            _b)
                    }
                };
                result = ExtendedDropPopupUtils.getLootSettingsRandomRewardDetailsDrop(settings, lootSettings, id, ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, hero.Rarity));
                break;
            case RewardDataType.HeroWeapon:
                weapon = weaponsMap.checkedGet(id);
                lootSettings = {
                    Weapons: {
                        Rarities: (_c = {},
                            _c[weapon.rarity] = 1,
                            _c)
                    }
                };
                result = ExtendedDropPopupUtils.getLootSettingsRandomRewardDetailsDrop(settings, lootSettings, id, ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.WEAPON, weapon.rarity));
                break;
            default:
                throw new Error("getRandomRewardDetailsDrop: type '".concat(rewardDataType, "' not supported."));
        }
        EXTENDED_DROP_POPUP_PROXY_MANAGER.clear();
        return result;
    };
    ExtendedDropPopupUtils.getLootSettingsRandomRewardDetailsDrop = function (settings, lootSettings, id, groupId) {
        var playerProgress = settings.playerProgress, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var proxy = new ExtendedDropPopupProxy();
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setProxy(proxy);
        var lootGenerator = LootGeneratorBuilder.getCommonLootGenerator();
        lootGenerator.setLootSettings(lootSettings);
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(startTimeOfCurrentDayMS);
        lootGenerator.generateLoot(new PcgRandom(0));
        var proxyResultGroups = ExtendedDropPopupUtils.getFromProxy(proxy);
        var resultGroups = __assign(__assign({}, (proxyResultGroups.otherGroups || {})), (proxyResultGroups.shardGroups || {}));
        if (proxyResultGroups.customizationGroups) {
            for (var type in proxyResultGroups.customizationGroups) {
                ExtendedDropPopupUtils
                    .mergeGroups(resultGroups, proxyResultGroups.customizationGroups[type]);
            }
        }
        ExtendedDropPopupUtils.mergeGroups(resultGroups, proxyResultGroups.fixedLoot || {});
        ExtendedDropPopupUtils.divideStances(resultGroups);
        ExtendedDropPopupUtils.removeEmptyGroups(resultGroups);
        ExtendedDropPopupUtils.normalizeChances(resultGroups);
        if (resultGroups[groupId] == undefined) {
            resultGroups[groupId] = { chance: 1, items: {} };
        }
        if (resultGroups[groupId].items[id] == undefined) {
            resultGroups[groupId].chance = 1;
        }
        return ExtendedDropPopupUtils.createVisual(resultGroups);
    };
    ExtendedDropPopupUtils.getChestRandomRewardDetailsDrop = function (settings) {
        var id = settings.id, playerProgress = settings.playerProgress, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, chestArenaId = settings.chestArenaId;
        var customizationGroupsResult = {};
        var shardGroupsResult = {};
        var pseudorandomSettings = PseudorandomSettings.settings[id];
        var chest = chestsMap.checkedGet(id);
        if (pseudorandomSettings && chest.canUsePseudorandomForPopup()) {
            var _a = ExtendedDropPopupUtils.fillCustomizationAndShardsSettingsByPseudorandom({
                pseudorandomSettings: pseudorandomSettings,
                playerProgress: playerProgress,
                chestId: id,
                serverTime: startTimeOfCurrentDayMS,
            }), customizationGroups = _a.customizationGroups, shardGroups = _a.shardGroups;
            customizationGroupsResult = customizationGroups;
            shardGroupsResult = shardGroups;
        }
        var proxy = new ExtendedDropPopupProxy();
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setProxy(proxy);
        ChestUtils.setChestArenaIdInPlayerProgress(playerProgress, chestArenaId || playerProgress.playerArenaId);
        var lootGenerator = LootGeneratorBuilder.getChestLootGenerator();
        var lootSettings = chest.getLootSettingsFromPlayerProgress(playerProgress);
        lootGenerator.setLootSettings(lootSettings);
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(startTimeOfCurrentDayMS);
        lootGenerator.setAdditionalSettings(new LootGeneratorAdditionalSettings({
            chestId: chest.ID,
        }));
        lootGenerator.generateLoot(new PcgRandom(0));
        var resultGroups;
        var proxyResultGroups = ExtendedDropPopupUtils.getFromProxy(proxy);
        if (lootSettings.Groups) {
            resultGroups = ExtendedDropPopupUtils.getChancesFromCustomGroupsDrop(lootSettings.Groups, proxy);
        }
        else {
            if (proxyResultGroups.shardGroups) {
                ExtendedDropPopupUtils.mergeGroups(shardGroupsResult, proxyResultGroups.shardGroups);
            }
            if (proxyResultGroups.customizationGroups) {
                for (var type in proxyResultGroups.customizationGroups) {
                    if (customizationGroupsResult[type] == undefined) {
                        customizationGroupsResult[type] = {};
                    }
                    ExtendedDropPopupUtils.mergeGroups(customizationGroupsResult[type], proxyResultGroups.customizationGroups[type]);
                }
            }
            resultGroups = __assign(__assign({}, (proxyResultGroups.otherGroups || {})), shardGroupsResult);
            for (var type in customizationGroupsResult) {
                for (var groupId in customizationGroupsResult[type]) {
                    resultGroups[groupId] = customizationGroupsResult[type][groupId];
                }
            }
            ExtendedDropPopupUtils.mergeGroups(resultGroups, proxyResultGroups.fixedLoot || {});
        }
        ExtendedDropPopupUtils.divideStances(resultGroups);
        ExtendedDropPopupUtils.removeEmptyGroups(resultGroups);
        ExtendedDropPopupUtils.normalizeChances(resultGroups);
        return ExtendedDropPopupUtils.createVisual(resultGroups);
    };
    ExtendedDropPopupUtils.fillCustomizationAndShardsSettingsByPseudorandom = function (s) {
        var pseudorandomSettings = s.pseudorandomSettings, chestId = s.chestId, playerProgress = s.playerProgress, serverTime = s.serverTime;
        var length = 0;
        var customizationGroups = {};
        var shardGroups = {};
        var customizationItems = {};
        var shardsItems = {};
        for (var _i = 0, _a = pseudorandomSettings.queue; _i < _a.length; _i++) {
            var el = _a[_i];
            if (el >= 0) {
                length += el;
                continue;
            }
            var item = el;
            if ([
                PSRND_ITEM.COMMON_HERO,
                PSRND_ITEM.RARE_HERO,
                PSRND_ITEM.EPIC_HERO,
                PSRND_ITEM.LEGENDARY_HERO,
            ].indexOf(item) > -1) {
                shardsItems[item] = true;
                var rarity = ChestsConstants.pseudorandomRarityMap[item];
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, rarity);
                if (shardGroups[groupId] == undefined) {
                    shardGroups[groupId] = { chance: 0, items: {} };
                }
                shardGroups[groupId].chance++;
            }
            else {
                var types = [];
                if ([PSRND_ITEM.SEASON_ANIMATION,
                    PSRND_ITEM.COMMON_ANIMATION,
                    PSRND_ITEM.RARE_ANIMATION,
                    PSRND_ITEM.EPIC_ANIMATION,
                ].indexOf(item) > -1) {
                    switch (item) {
                        case PSRND_ITEM.COMMON_ANIMATION:
                            types.push(PSRND_ITEM.COMMON_STANCE, PSRND_ITEM.COMMON_WINPOSE, PSRND_ITEM.COMMON_TAUNT);
                            break;
                        case PSRND_ITEM.RARE_ANIMATION:
                            types.push(PSRND_ITEM.RARE_STANCE, PSRND_ITEM.RARE_WINPOSE, PSRND_ITEM.RARE_TAUNT);
                            break;
                        case PSRND_ITEM.EPIC_ANIMATION:
                            types.push(PSRND_ITEM.EPIC_STANCE, PSRND_ITEM.EPIC_WINPOSE, PSRND_ITEM.EPIC_TAUNT);
                            break;
                        case PSRND_ITEM.SEASON_ANIMATION:
                            types.push(PSRND_ITEM.SEASON_STANCE, PSRND_ITEM.SEASON_WINPOSE, PSRND_ITEM.SEASON_TAUNT);
                            break;
                    }
                }
                else {
                    types.push(item);
                }
                for (var _b = 0, types_1 = types; _b < types_1.length; _b++) {
                    var item_1 = types_1[_b];
                    customizationItems[item_1] = true;
                    var chestTooltipType = CustomizationUtils.getCustomizationChestTooltipTypeByPsrnd(item_1);
                    var customizationType = CustomizationUtils.getCustomizationTypeByChestTooltipType(chestTooltipType);
                    if (customizationGroups[customizationType] == undefined) {
                        customizationGroups[customizationType] = {};
                    }
                    var rarity = ChestsConstants.pseudorandomRarityMap[item_1];
                    var groupId = ExtendedDropPopupUtils
                        .getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, customizationType, rarity);
                    if (customizationGroups[customizationType][groupId] == undefined) {
                        customizationGroups[customizationType][groupId] = { chance: 0, items: {} };
                    }
                    customizationGroups[customizationType][groupId].chance++;
                }
            }
            length++;
        }
        var proxy = new ExtendedDropPopupProxy();
        EXTENDED_DROP_POPUP_PROXY_MANAGER.setProxy(proxy);
        var rnd = new PcgRandom(0);
        var generators = [
            new PseudorandomCustomizationGenerator({
                playerProgress: playerProgress,
                rnd: rnd,
                chestId: chestId,
                items: Object.keys(customizationItems).map(Number),
                serverTime: serverTime,
            }),
            new PseudorandomInflationShardsGenerator({
                playerProgress: playerProgress,
                rnd: rnd,
                chestId: chestId,
                items: Object.keys(shardsItems).map(Number),
                serverTime: serverTime,
            }),
        ];
        for (var _c = 0, generators_1 = generators; _c < generators_1.length; _c++) {
            var generator = generators_1[_c];
            generator.generate();
        }
        if (proxy.heroShardsWeights) {
            var proxyShards = ExtendedDropPopupUtils.getChancesOfItemsFromShadowWeights(proxy);
            for (var groupId in proxyShards) {
                shardGroups[groupId].items = proxyShards[groupId].items;
            }
        }
        for (var g in shardGroups) {
            shardGroups[g].chance /= length;
        }
        if (proxy.customizationSettings) {
            for (var _d = 0, _e = proxy.customizationSettings; _d < _e.length; _d++) {
                var sets = _e[_d];
                var droppedInfoChances = ExtendedDropPopupUtils.getFromCustomization(sets);
                var type = sets.type;
                for (var groupId in droppedInfoChances) {
                    customizationGroups[type][groupId].chance /= length;
                    var currentItems = droppedInfoChances[groupId].items;
                    var goalItems = customizationGroups[type][groupId].items;
                    for (var id in currentItems) {
                        if (goalItems[id] == undefined) {
                            goalItems[id] = currentItems[id];
                            continue;
                        }
                        goalItems[id] = (goalItems[id] + currentItems[id]) / 2;
                    }
                }
            }
        }
        return {
            customizationGroups: customizationGroups,
            shardGroups: shardGroups,
        };
    };
    ExtendedDropPopupUtils.getFromCustomization = function (customizationSettings) {
        var result = {};
        var rarityChances = __assign({}, customizationSettings.rarityChances);
        var idChances = __assign({}, customizationSettings.idChances);
        var availableByRarity = {};
        var availableByRaritySpecial = {};
        var orderMap = CustomizationUtils.getOrderMap(customizationSettings.type);
        for (var r in rarityChances) {
            availableByRarity[r] = customizationSettings.availableByRarity[r].slice();
        }
        for (var id in idChances) {
            var customization = orderMap.checkedGet(id);
            rarityChances[customization.rarity] = (rarityChances[customization.rarity] || 0) + idChances[id];
            if (availableByRaritySpecial[customization.rarity] == undefined) {
                availableByRaritySpecial[customization.rarity] = [];
            }
            availableByRaritySpecial[customization.rarity].push(+id);
        }
        var sumChances = 0;
        for (var r in rarityChances) {
            sumChances += rarityChances[r];
        }
        for (var id in idChances) {
            idChances[id] /= sumChances;
        }
        for (var r in rarityChances) {
            var groupId = ExtendedDropPopupUtils
                .getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, customizationSettings.type, +r);
            result[groupId] = { chance: Math.min(rarityChances[r], 1), items: {} };
            var availableSpecial = availableByRaritySpecial[r] || [];
            var available = ArrayUtils.getArraySubstraction(availableByRarity[r] || [], availableSpecial);
            if (available.length > 0) {
                var specialChances = availableSpecial.reduce(function (a, id) { return a + idChances[id]; }, 0);
                if (specialChances >= 1) {
                    specialChances = 0;
                }
                var chance = (1 - specialChances) / available.length;
                for (var _i = 0, available_1 = available; _i < available_1.length; _i++) {
                    var id = available_1[_i];
                    result[groupId].items[id] = chance;
                }
            }
            for (var _a = 0, availableSpecial_1 = availableSpecial; _a < availableSpecial_1.length; _a++) {
                var id = availableSpecial_1[_a];
                result[groupId].items[id] = idChances[id];
            }
        }
        return result;
    };
    ExtendedDropPopupUtils.getFromProxy = function (proxy) {
        var result = {};
        if (proxy.heroShardsWeights) {
            result.shardGroups = ExtendedDropPopupUtils.getChancesOfItemsFromShadowWeights(proxy);
            ExtendedDropPopupUtils.fillShardsByShardsSlots(result.shardGroups, proxy);
        }
        if (proxy.customizationSettings) {
            result.customizationGroups = {};
            for (var _i = 0, _a = proxy.customizationSettings; _i < _a.length; _i++) {
                var sets = _a[_i];
                result.customizationGroups[sets.type] = ExtendedDropPopupUtils.getFromCustomization(sets);
            }
        }
        if (proxy.currencySettings) {
            var currencyGroups = {};
            var allWeights = [];
            var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CURRENCY);
            for (var cid in proxy.currencySettings) {
                var chance = ExtendedDropPopupUtils.getNoneZeroCurrencyChance(proxy.currencySettings[cid]);
                if (chance <= 0) {
                    continue;
                }
                if (currencyGroups[groupId] == undefined) {
                    currencyGroups[groupId] = { chance: 0, items: {} };
                }
                currencyGroups[groupId].items[+cid] = chance;
                allWeights.push.apply(allWeights, proxy.currencySettings[cid]);
            }
            if (Object.keys(currencyGroups).length > 0) {
                result.otherGroups = currencyGroups;
                result.otherGroups[groupId].chance
                    = ExtendedDropPopupUtils.getNoneZeroCurrencyChance(allWeights);
            }
        }
        if (proxy.heroCardsWeights) {
            var cardWeightsGroups = {};
            var hasWeights = false;
            for (var rarity in proxy.correctedCardsSettings.Rarities) {
                var slotSettings = proxy.correctedCardsSettings.Rarities[rarity];
                if (slotSettings.CardsWeight != undefined) {
                    hasWeights = true;
                    break;
                }
            }
            if (hasWeights) {
                for (var rarity in proxy.correctedCardsSettings.Rarities)
                    if (proxy.heroCardsWeights[rarity]) {
                        var slotSettings = proxy.correctedCardsSettings.Rarities[rarity];
                        var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, +rarity);
                        var chance = ExtendedDropPopupUtils.getNonZeroChance(slotSettings.CardsWeight);
                        if (chance <= 0) {
                            continue;
                        }
                        cardWeightsGroups[groupId] = { chance: chance, items: {} };
                    }
                for (var r in proxy.heroCardsWeights) {
                    var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, +r);
                    if (cardWeightsGroups[groupId] == undefined) {
                        continue;
                    }
                    for (var hid in proxy.heroCardsWeights[r]) {
                        cardWeightsGroups[groupId].items[+hid] = proxy.heroCardsWeights[r][hid];
                    }
                }
                if (Object.keys(cardWeightsGroups).length > 0) {
                    if (result.otherGroups == undefined) {
                        result.otherGroups = {};
                    }
                    result.otherGroups = __assign(__assign({}, result.otherGroups), cardWeightsGroups);
                }
            }
        }
        if (proxy.fixedLoot) {
            result.fixedLoot = {};
            var heroesLoot = [
                { type: EXTENDED_DROP_GROUP_TYPE.CARDS, map: proxy.fixedLoot.HeroExp },
                { type: EXTENDED_DROP_GROUP_TYPE.SHARDS, map: proxy.fixedLoot.Shards },
            ];
            for (var _b = 0, heroesLoot_1 = heroesLoot; _b < heroesLoot_1.length; _b++) {
                var iteration = heroesLoot_1[_b];
                var map = iteration.map, type = iteration.type;
                for (var hid in map) {
                    var hero = heroesMap.checkedGet(hid);
                    var groupId = ExtendedDropPopupUtils.getDroppedGroupId(type, hero.Rarity);
                    if (result.fixedLoot[groupId] == undefined) {
                        result.fixedLoot[groupId] = { items: {}, chance: 0 };
                    }
                    result.fixedLoot[groupId].chance = 1;
                    result.fixedLoot[groupId].items[+hid] = 1;
                }
            }
            for (var cid in proxy.fixedLoot.Currencies) {
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CURRENCY);
                if (result.fixedLoot[groupId] == undefined) {
                    result.fixedLoot[groupId] = { items: {}, chance: 0 };
                }
                result.fixedLoot[groupId].chance = 1;
                result.fixedLoot[groupId].items[+cid] = 1;
            }
            for (var _c = 0, _d = CustomizationUtils.getAllCustomizationsOrder(); _c < _d.length; _c++) {
                var type = _d[_c];
                var ids = CustomizationUtils.getLootIdsContainer(type, proxy.fixedLoot);
                var map = CustomizationUtils.getOrderMap(type);
                for (var _e = 0, ids_1 = ids; _e < ids_1.length; _e++) {
                    var id = ids_1[_e];
                    var customization = map.checkedGet(id);
                    var groupId = ExtendedDropPopupUtils
                        .getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, type, customization.rarity);
                    if (result.fixedLoot[groupId] == undefined) {
                        result.fixedLoot[groupId] = { items: {}, chance: 0 };
                    }
                    result.fixedLoot[groupId].chance = 1;
                    result.fixedLoot[groupId].items[+id] = 1;
                }
            }
        }
        if (proxy.customizationShards) {
            result.customizationShardsGroups = {};
            for (var _f = 0, _g = proxy.customizationShards; _f < _g.length; _f++) {
                var set = _g[_f];
                var droppedInfoChances = ExtendedDropPopupUtils.getFromCustomizationShards(set);
                for (var groupId in droppedInfoChances) {
                    var items = droppedInfoChances[groupId].items;
                    result.customizationShardsGroups[groupId] = {
                        chance: droppedInfoChances[groupId].chance,
                        items: items,
                    };
                }
            }
        }
        return result;
    };
    ExtendedDropPopupUtils.getChancesOfItemsFromShadowWeights = function (proxy) {
        var result = {};
        if (proxy.heroShardsWeights) {
            for (var hid in proxy.heroShardsWeights) {
                var hero = heroesMap.checkedGet(hid);
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, hero.Rarity);
                if (result[groupId] == undefined) {
                    result[groupId] = { items: {}, chance: 0 };
                }
                result[groupId].items[hero.ID] = proxy.heroShardsWeights[hid];
            }
        }
        return result;
    };
    ExtendedDropPopupUtils.fillShardsByShardsSlots = function (shards, proxy) {
        if (proxy.correctedCardsSettings) {
            for (var rarity in proxy.correctedCardsSettings.Rarities) {
                var slotSettings = proxy.correctedCardsSettings.Rarities[rarity];
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, +rarity);
                shards[groupId].chance = ExtendedDropPopupUtils.getNonZeroChance(slotSettings.ShardsWeight);
            }
        }
    };
    ExtendedDropPopupUtils.getNonZeroChance = function (weights) {
        var sum = 0;
        var nonZeroSum = 0;
        for (var _i = 0, weights_1 = weights; _i < weights_1.length; _i++) {
            var el = weights_1[_i];
            sum += el.W;
            if (el.N > 0) {
                nonZeroSum += el.W;
            }
        }
        return sum == 0 ? 0 : nonZeroSum / sum;
    };
    ExtendedDropPopupUtils.getNoneZeroCurrencyChance = function (weights) {
        var sum = 0;
        var nonZeroSum = 0;
        for (var _i = 0, weights_2 = weights; _i < weights_2.length; _i++) {
            var el = weights_2[_i];
            sum += el.Weight;
            if (el.Amount.getMin() > 0) {
                nonZeroSum += el.Weight;
            }
        }
        return sum == 0 ? 0 : nonZeroSum / sum;
    };
    ExtendedDropPopupUtils.divideStances = function (dst) {
        var _a;
        var goalGroup = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE);
        var newItems = (_a = {},
            _a[STANCE_TYPE.START_POSE] = {},
            _a[STANCE_TYPE.WIN_POSE] = {},
            _a);
        for (var groupId in dst) {
            if (groupId.substring(0, goalGroup.length) != goalGroup) {
                continue;
            }
            var ids = dst[groupId].items;
            var chance = dst[groupId].chance;
            for (var id in ids) {
                var stance = stancesMap.checkedGet(id);
                var postfix = stance.Settings.StanceType;
                var newGroup = ExtendedDropPopupUtils
                    .getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, postfix, stance.rarity);
                if (newItems[postfix][newGroup] == undefined) {
                    newItems[postfix][newGroup] = { chance: chance, items: {} };
                }
                newItems[postfix][newGroup].items[id] = dst[groupId].items[id];
            }
            delete dst[groupId];
        }
        for (var type in newItems) {
            ExtendedDropPopupUtils.mergeGroups(dst, newItems[type]);
        }
    };
    ExtendedDropPopupUtils.removeEmptyGroups = function (dst) {
        for (var groupId in dst) {
            var ids = dst[groupId].items;
            if (Object.keys(ids).length == 0) {
                delete dst[groupId];
            }
        }
    };
    ExtendedDropPopupUtils.normalizeChances = function (dst) {
        var K = (Math.pow(10, ExtendedDropPopupSettings.DIGITS)) * 100;
        var MIN = 1 / K;
        for (var groupId in dst) {
            var group = dst[groupId];
            group.chance = CommonUtils.clamp(dst[groupId].chance, MIN, 1);
            var sum = 0;
            for (var id in group.items) {
                sum += group.items[id];
            }
            var idOrder = Object.keys(group.items).map(Number).sort(function (a, b) { return a - b; });
            var chances = [];
            var maxes = [];
            var mines = [];
            for (var _i = 0, idOrder_1 = idOrder; _i < idOrder_1.length; _i++) {
                var id = idOrder_1[_i];
                chances.push(K * CommonUtils.clamp(group.items[id] / sum, MIN, 1));
                maxes.push(K);
                mines.push(MIN * K);
            }
            var normalChances = ArrayUtils.getArrayProportionalMinimized(K, chances, maxes, mines);
            for (var i = 0; i < idOrder.length; i++) {
                group.items[idOrder[i]] = normalChances[i] / K;
            }
        }
    };
    ExtendedDropPopupUtils.mergeGroups = function (dst, src) {
        var MIN = 1 / (Math.pow(10, ExtendedDropPopupSettings.DIGITS));
        for (var groupId in src) {
            if (dst[groupId] == undefined) {
                dst[groupId] = src[groupId];
                continue;
            }
            dst[groupId].chance = Math.min(1, Math.max(src[groupId].chance, dst[groupId].chance));
            var srcItems = src[groupId].items;
            var dstItems = dst[groupId].items;
            for (var id in srcItems) {
                dstItems[id] = Math.max(dstItems[id] || MIN, srcItems[id]);
            }
        }
    };
    ExtendedDropPopupUtils.findGroup = function (groupId) {
        for (var _i = 0, _a = ExtendedDropPopupSettings.GROUPS; _i < _a.length; _i++) {
            var group = _a[_i];
            if (group.groupId == groupId) {
                return group;
            }
        }
        return null;
    };
    ExtendedDropPopupUtils.createVisual = function (groups) {
        var result = [];
        var DIGITS = ExtendedDropPopupSettings.DIGITS;
        var MIN = 1 / (Math.pow(10, ExtendedDropPopupSettings.DIGITS));
        for (var groupId in groups) {
            var settings = groups[groupId];
            var group = ExtendedDropPopupUtils.findGroup(groupId);
            if (!group) {
                continue;
            }
            var resultGroup = {
                header: {
                    alias: { alias: group.alias, color: group.color },
                    backgroundColor: group.backgroundColor,
                    chance: (settings.chance * 100).toFixed(DIGITS) + "%"
                },
                items: []
            };
            for (var id in settings.items) {
                var chance = CommonUtils.clamp(settings.items[id] * 100, MIN, 100);
                resultGroup.items.push({
                    chance: chance.toFixed(DIGITS) + "%",
                    reward: group.rewardGetter(+id),
                    isClaimed: false,
                    isHighChance: false
                });
            }
            result.push(resultGroup);
        }
        return result;
    };
    ExtendedDropPopupUtils.getChancesFromCustomGroupsDrop = function (groups, proxy) {
        var result = {};
        var totalWeight = groups.reduce(function (acc, g) { return acc + (g.Weight || 0); }, 0);
        if (totalWeight <= 0) {
            return result;
        }
        for (var _i = 0, groups_1 = groups; _i < groups_1.length; _i++) {
            var group = groups_1[_i];
            var groupChance = (group.Weight || 0) / totalWeight;
            if (groupChance <= 0) {
                continue;
            }
            if (group.Groups && group.Groups.length > 0) {
                var subGroups = ExtendedDropPopupUtils.getChancesFromCustomGroupsDrop(group.Groups, proxy);
                for (var subGroupId in subGroups) {
                    if (result[subGroupId] == undefined) {
                        result[subGroupId] = { chance: 0, items: {} };
                    }
                    result[subGroupId].chance = Math.max(result[subGroupId].chance, groupChance);
                    for (var id in subGroups[subGroupId].items) {
                        result[subGroupId].items[id] = (result[subGroupId].items[id] || 0) + subGroups[subGroupId].items[id] * groupChance;
                    }
                }
            }
            else {
                var itemChances = [];
                if (group.Weapons) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.Weapons, CUSTOMIZATION.WEAPON));
                }
                if (group.Emoji) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.Emoji, CUSTOMIZATION.EMOJI));
                }
                if (group.TextEmojiPacks) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.TextEmojiPacks, CUSTOMIZATION.TEXT_EMOJI_PACK));
                }
                if (group.Skins) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.Skins, CUSTOMIZATION.SKIN));
                }
                if (group.Taunts) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.Taunts, CUSTOMIZATION.TAUNT));
                }
                if (group.Stances) {
                    itemChances.push(ExtendedDropPopupUtils.getChancesFromCommonSettings(groupChance, group.Stances, CUSTOMIZATION.STANCE));
                }
                if (group.CustomizationShards) {
                    for (var _a = 0, _b = group.CustomizationShards.items; _a < _b.length; _a++) {
                        var item = _b[_a];
                        itemChances.push(ExtendedDropPopupUtils.getFromCustomizationShards(item));
                    }
                }
                if (group.CardsSlots) {
                    var proxyResultGroups = ExtendedDropPopupUtils.getFromProxy(proxy);
                    if (proxyResultGroups.shardGroups) {
                        itemChances.push(proxyResultGroups.shardGroups);
                    }
                    if (proxyResultGroups.otherGroups) {
                        var cardGroups = {};
                        for (var gid in proxyResultGroups.otherGroups) {
                            if (gid.indexOf(EXTENDED_DROP_GROUP_TYPE.CARDS.toString()) == 0) {
                                cardGroups[gid] = proxyResultGroups.otherGroups[gid];
                            }
                        }
                        if (Object.keys(cardGroups).length > 0) {
                            itemChances.push(cardGroups);
                        }
                    }
                }
                for (var _c = 0, itemChances_1 = itemChances; _c < itemChances_1.length; _c++) {
                    var itemChance = itemChances_1[_c];
                    for (var groupId in itemChance) {
                        if (result[groupId] == undefined) {
                            result[groupId] = { chance: 0, items: {} };
                        }
                        result[groupId].chance = Math.max(result[groupId].chance, groupChance);
                        for (var id in itemChance[groupId].items) {
                            result[groupId].items[id] = (result[groupId].items[id] || 0) + itemChance[groupId].items[id] * groupChance;
                        }
                    }
                }
            }
        }
        return result;
    };
    ExtendedDropPopupUtils.getChancesFromCommonSettings = function (groupChance, settings, type) {
        var result = {};
        var idChances = settings.Ids || {};
        var orderMap = CustomizationUtils.getOrderMap(type);
        if (Object.keys(idChances).length > 0) {
            for (var id in idChances) {
                var customization = orderMap.checkedGet(id);
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, type, customization.rarity);
                if (result[groupId] == undefined) {
                    result[groupId] = { chance: groupChance, items: {} };
                }
                result[groupId].items[id] = idChances[id];
            }
        }
        else if (settings.Rarities) {
            var _loop_1 = function (r) {
                var rarity = +r;
                var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, type, rarity);
                var availableIds = CustomizationUtils.getAvailableIdsForRandomGenerating(type) || [];
                var filteredIds = availableIds.filter(function (id) {
                    var item = orderMap.get(id);
                    return item && item.rarity == rarity;
                });
                if (filteredIds.length > 0) {
                    result[groupId] = { chance: groupChance, items: {} };
                    var itemChance = 1 / filteredIds.length;
                    for (var _i = 0, filteredIds_1 = filteredIds; _i < filteredIds_1.length; _i++) {
                        var id = filteredIds_1[_i];
                        result[groupId].items[id] = itemChance;
                    }
                }
            };
            for (var r in settings.Rarities) {
                _loop_1(r);
            }
        }
        return result;
    };
    ExtendedDropPopupUtils.getFromCustomizationShards = function (set) {
        var result = {};
        var shardsData = CustomizationUtils.getCustomizationShardsData(set.id);
        var orderMap = CustomizationUtils.getOrderMap(shardsData.customizationType);
        var entity = orderMap.checkedGet(shardsData.entityId);
        var weight = set.params.W;
        var groupId = ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION_SHARDS, shardsData.customizationType, CUSTOMIZATION_RARITY.LEGENDARY_WEAPON);
        if (result[groupId] == undefined) {
            result[groupId] = { items: {}, chance: 0 };
        }
        result[groupId].items[set.id] = 1;
        return result;
    };
    return ExtendedDropPopupUtils;
}());
