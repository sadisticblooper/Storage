var ExtendedDropPopupSettings = (function () {
    function ExtendedDropPopupSettings() {
    }
    ExtendedDropPopupSettings.DIGITS = 2;
    ExtendedDropPopupSettings.colorRarityPresets = {
        legendary: '#ffd75e',
        epic: '#c68cff',
        rare: '#8cbaff',
        common: '#97aeb8',
        season: '#ff4763',
    };
    ExtendedDropPopupSettings.colorRarityBackgroundPresets = {
        legendary: '#ffd75e17',
        epic: '#c68cff17',
        rare: '#8cbaff17',
        common: '#97aeb817',
        season: '#ff476317',
    };
    ExtendedDropPopupSettings.GROUPS = [
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, HERO_RARITY.LEGENDARY),
            alias: 'gacha_legendary_cards',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ HeroExp: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, HERO_RARITY.EPIC),
            alias: 'gacha_epic_cards',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ HeroExp: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, HERO_RARITY.RARE),
            alias: 'gacha_rare_cards',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ HeroExp: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CARDS, HERO_RARITY.COMMON),
            alias: 'gacha_common_cards',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ HeroExp: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, HERO_RARITY.LEGENDARY),
            alias: 'gacha_legendary_shard',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ Shards: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, HERO_RARITY.EPIC),
            alias: 'gacha_epic_shard',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ Shards: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, HERO_RARITY.RARE),
            alias: 'gacha_rare_shard',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ Shards: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.SHARDS, HERO_RARITY.COMMON),
            alias: 'gacha_common_shard',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ Shards: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.WEAPON, HERO_WEAPON_RARITY.LEGENDARY),
            alias: 'gacha_legendary_weapon',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Weapons: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.WEAPON, HERO_WEAPON_RARITY.EPIC),
            alias: 'gacha_epic_weapon',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Weapons: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.WEAPON, HERO_WEAPON_RARITY.RARE),
            alias: 'gacha_rare_weapon',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Weapons: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.WEAPON, HERO_WEAPON_RARITY.COMMON),
            alias: 'gacha_common_weapon',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Weapons: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.SKIN, SKIN_RARITY.LEGENDARY),
            alias: 'gacha_legendary_skin',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Skins: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.SKIN, SKIN_RARITY.SEASON),
            alias: 'gacha_seasonal_skin',
            color: ExtendedDropPopupSettings.colorRarityPresets.season,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.season,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Skins: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.SKIN, SKIN_RARITY.EPIC),
            alias: 'gacha_epic_skin',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Skins: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.SKIN, SKIN_RARITY.RARE),
            alias: 'gacha_rare_skin',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Skins: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.SKIN, SKIN_RARITY.COMMON),
            alias: 'gacha_common_skin',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Skins: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.START_POSE, STANCE_RARITY.SEASON),
            alias: 'gacha_seasonal_stance',
            color: ExtendedDropPopupSettings.colorRarityPresets.season,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.season,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.START_POSE, STANCE_RARITY.EPIC),
            alias: 'gacha_epic_stance',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.START_POSE, STANCE_RARITY.RARE),
            alias: 'gacha_rare_stance',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.START_POSE, STANCE_RARITY.COMMON),
            alias: 'gacha_common_stance',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.WIN_POSE, STANCE_RARITY.SEASON),
            alias: 'gacha_seasonal_win_pose',
            color: ExtendedDropPopupSettings.colorRarityPresets.season,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.season,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.WIN_POSE, STANCE_RARITY.EPIC),
            alias: 'gacha_epic_win_pose',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.WIN_POSE, STANCE_RARITY.RARE),
            alias: 'gacha_rare_win_pose',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.STANCE, STANCE_TYPE.WIN_POSE, STANCE_RARITY.COMMON),
            alias: 'gacha_common_win_pose',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Stances: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TAUNT, TAUNT_RARITY.SEASON),
            alias: 'gacha_seasonal_taunt',
            color: ExtendedDropPopupSettings.colorRarityPresets.season,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.season,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Taunts: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TAUNT, TAUNT_RARITY.EPIC),
            alias: 'gacha_epic_taunt',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Taunts: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TAUNT, TAUNT_RARITY.RARE),
            alias: 'gacha_rare_taunt',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Taunts: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TAUNT, TAUNT_RARITY.COMMON),
            alias: 'gacha_common_taunt',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Taunts: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.EMOJI, EMOJI_RARITY.ANY),
            alias: 'emoji_gacha',
            color: '#55e5ba5C',
            backgroundColor: '#55e5ba17',
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ Emoji: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TEXT_EMOJI_PACK, TEXT_EMOJI_PACK_RARITY.LEGENDARY),
            alias: 'gacha_legendary_phrase_packs',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ TextEmojiPacks: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TEXT_EMOJI_PACK, TEXT_EMOJI_PACK_RARITY.EPIC),
            alias: 'gacha_epic_phrase_packs',
            color: ExtendedDropPopupSettings.colorRarityPresets.epic,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.epic,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ TextEmojiPacks: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TEXT_EMOJI_PACK, TEXT_EMOJI_PACK_RARITY.RARE),
            alias: 'gacha_rare_phrase_packs',
            color: ExtendedDropPopupSettings.colorRarityPresets.rare,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.rare,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ TextEmojiPacks: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION, CUSTOMIZATION.TEXT_EMOJI_PACK, TEXT_EMOJI_PACK_RARITY.COMMON),
            alias: 'gacha_common_phrase_packs',
            color: ExtendedDropPopupSettings.colorRarityPresets.common,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.common,
            rewardGetter: function (id) { return { NewSeed: 0, Chests: [], Loot: new Loot({ TextEmojiPacks: [id] }) }; },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CUSTOMIZATION_SHARDS, CUSTOMIZATION.WEAPON, CUSTOMIZATION_RARITY.LEGENDARY_WEAPON),
            alias: 'gacha_legendary_weapon_customization_shard',
            color: ExtendedDropPopupSettings.colorRarityPresets.legendary,
            backgroundColor: ExtendedDropPopupSettings.colorRarityBackgroundPresets.legendary,
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ CustomizationShards: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
        {
            groupId: ExtendedDropPopupUtils.getDroppedGroupId(EXTENDED_DROP_GROUP_TYPE.CURRENCY),
            alias: 'gacha_currencies', color: '#e5c493', backgroundColor: '#e5c49317',
            rewardGetter: function (id) {
                var _a;
                return { NewSeed: 0, Chests: [], Loot: new Loot({ Currencies: (_a = {}, _a[id] = 1, _a) }) };
            },
        },
    ];
    return ExtendedDropPopupSettings;
}());
