var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var ExtendedDropPopupProxyManager = (function () {
    function ExtendedDropPopupProxyManager() {
    }
    ExtendedDropPopupProxyManager.prototype.setProxy = function (proxy) {
        this.proxy = proxy;
        return this;
    };
    ExtendedDropPopupProxyManager.prototype.setCorrectedCardsSettings = function (correctedCardsSettings) {
        if (this.proxy) {
            this.proxy.setCorrectedCardsSettings(correctedCardsSettings);
        }
    };
    ExtendedDropPopupProxyManager.prototype.setHeroCardsWeights = function (heroWeights) {
        if (this.proxy) {
            this.proxy.setHeroCardsWeights(heroWeights);
        }
    };
    ExtendedDropPopupProxyManager.prototype.addHeroShardsWeights = function (heroShardsWeights) {
        if (this.proxy) {
            this.proxy.addHeroShardsWeights(heroShardsWeights);
        }
    };
    ExtendedDropPopupProxyManager.prototype.addCustomizationSettings = function (settings) {
        if (this.proxy) {
            this.proxy.addCustomizationSettings(settings);
        }
    };
    ExtendedDropPopupProxyManager.prototype.addFixedLoot = function (loot) {
        if (this.proxy) {
            this.proxy.addFixedLoot(loot);
        }
    };
    ExtendedDropPopupProxyManager.prototype.setCurrencySettings = function (settings) {
        if (this.proxy) {
            this.proxy.setCurrencySettings(settings);
        }
    };
    ExtendedDropPopupProxyManager.prototype.clear = function () {
        this.proxy = null;
    };
    ExtendedDropPopupProxyManager.prototype.addCustomizationShards = function (customizationShards) {
        if (this.proxy) {
            this.proxy.addCustomizationShards(customizationShards);
        }
    };
    return ExtendedDropPopupProxyManager;
}());
var ExtendedDropPopupProxy = (function () {
    function ExtendedDropPopupProxy() {
    }
    ExtendedDropPopupProxy.prototype.setCorrectedCardsSettings = function (correctedCardsSettings) {
        this._correctedCardsSettings = correctedCardsSettings;
    };
    ExtendedDropPopupProxy.prototype.setHeroCardsWeights = function (heroWeights) {
        this._heroCardsWeights = {};
        for (var rarity in heroWeights) {
            this._heroCardsWeights[rarity] = __assign({}, heroWeights[rarity]);
        }
    };
    ExtendedDropPopupProxy.prototype.addHeroShardsWeights = function (heroShardsWeights) {
        this._heroShardsWeights = __assign(__assign({}, (this._heroShardsWeights || {})), heroShardsWeights);
    };
    ExtendedDropPopupProxy.prototype.addCustomizationShards = function (customizationShards) {
        this._customizationShards = __spreadArray(__spreadArray([], (this._customizationShards || []), true), customizationShards, true);
    };
    ExtendedDropPopupProxy.prototype.addCustomizationSettings = function (settings) {
        if (this._customizationSettings == undefined) {
            this._customizationSettings = [];
        }
        this._customizationSettings.push(settings);
    };
    ExtendedDropPopupProxy.prototype.addFixedLoot = function (loot) {
        if (this._fixedLoot == undefined) {
            this._fixedLoot = new Loot();
        }
        this._fixedLoot.combineLoot(loot);
    };
    ExtendedDropPopupProxy.prototype.setCurrencySettings = function (settings) {
        this._currencySettings = settings;
    };
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "correctedCardsSettings", {
        get: function () {
            return this._correctedCardsSettings;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "heroCardsWeights", {
        get: function () {
            return this._heroCardsWeights;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "heroShardsWeights", {
        get: function () {
            return this._heroShardsWeights;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "customizationSettings", {
        get: function () {
            return this._customizationSettings;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "fixedLoot", {
        get: function () {
            return this._fixedLoot;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "currencySettings", {
        get: function () {
            return this._currencySettings;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ExtendedDropPopupProxy.prototype, "customizationShards", {
        get: function () {
            return this._customizationShards;
        },
        enumerable: false,
        configurable: true
    });
    return ExtendedDropPopupProxy;
}());
var EXTENDED_DROP_POPUP_PROXY_MANAGER = new ExtendedDropPopupProxyManager();
