function getConversionLoot(settings) {
    return ConversionUtils.getConversionLoot(settings);
}
function getMergedLoot(settings) {
    return LootUtils.getMergedLoot(settings);
}
function getRandomRewardDetailsDrop(settings) {
    return ExtendedDropPopupUtils.getRandomRewardDetailsDrop(settings);
}
function showRandomRewardFullscreenTooltip(settings) {
    return ExtendedDropPopupUtils.showRandomRewardFullscreenTooltip(settings);
}
