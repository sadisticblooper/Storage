var Notifications = (function () {
    function Notifications() {
    }
    Notifications.canShowNotificator = function (settings) {
        var notifierType = settings.notifierType, fightCounters = settings.fightCounters, isTutorialCompletedOnThisAppInstall = settings.isTutorialCompletedOnThisAppInstall;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var fights = BundlesUtils.getFightCounterAfterBundles(fightCounters);
        if (notifierType === NotifierType.SettingsCustomizeControls) {
            return fights >= 1;
        }
        if (!isTutorialCompletedOnThisAppInstall)
            return false;
        switch (notifierType) {
            case NotifierType.SettingsCustomizeHud:
                return fights >= 1;
            case NotifierType.Movelist:
                return fights >= 2;
            case NotifierType.Training:
                return fights >= 5;
            case NotifierType.SocialProfile:
                return fights >= 10;
            case NotifierType.Leaderboard:
                return playerProgress.maxPlayerRating >= 150;
        }
        return false;
    };
    return Notifications;
}());
