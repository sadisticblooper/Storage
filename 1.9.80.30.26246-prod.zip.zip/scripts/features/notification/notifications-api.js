function canShowNotificator(settings) {
    return Notifications.canShowNotificator(settings);
}
