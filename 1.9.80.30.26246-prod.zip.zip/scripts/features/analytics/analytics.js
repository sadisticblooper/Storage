var AppsFlyerConstants = (function () {
    function AppsFlyerConstants() {
    }
    AppsFlyerConstants.logOrganic = true;
    AppsFlyerConstants.inactiveDaysThreshold = 90;
    return AppsFlyerConstants;
}());
var AnalyticsEventType = {
    ACCOUNT_LEVEL: 1,
    ADMIN_ERASE: 2,
    ADMIN_SET_PERMISSIONS: 3,
    APPS_FLYER: 4,
    ARENA_LEVEL: 5,
    BRAWLER_FINISH: 6,
    CHEAT: 7,
    CHEAT_PRESET: 8,
    CHEST_BOOST: 9,
    CHEST_OPEN: 10,
    CURRENCY_CHANGE: 11,
    DAILY_INVENTORY: 12,
    ERASE: 13,
    HERO_LEVEL: 14,
    HERO_TALENT: 15,
    LINK_GOOGLE_PLAY: 16,
    LOGIN: 17,
    LOGOUT: 18,
    MAKE_PURCHASE: 19,
    MATCHER: 20,
    PVP_FINISH_BATTLE: 21,
    PVP_MATCHER: 22,
    SHOP_PURCHASE: 23,
    TUTORIAL_STEP: 24,
    VIDEO_AD: 25,
    BATTLE_PERFORMANCE: 26,
    ADMIN_RESET_PLAYER: 27,
    MILESTONE_REWARD: 28,
    SHOW_OFFER: 29,
    REWARDED_VIDEO_AD: 30,
    AD_STATUS: 31,
    EXCHANGE_CURRENCY: 32,
    FIGHT_QUALITY: 33,
    CLIENT_ERROR: 34,
    HERO_SKIN: 35,
    TAUNTS: 36,
    EMOJI: 37,
    BATTLE_PASS_LEVEL: 38,
    BATTLE_PASS_REWARD: 39,
    PURCHASE_RECEIPT: 40,
    FREE_OFFER: 41,
    TOURNAMENT_JOIN: 42,
    TOURNAMENT_TEAM: 43,
    TOURNAMENT_BATTLE: 44,
    BUNDLE_DOWNLOAD: 45,
    BUNDLE_EVENT: 46,
    PENDING_ORDER_ACCEPT: 47,
    PENDING_ORDER_STORE: 48,
    ROULETTE_ROLL: 49,
    ADMIN_BIND_ACCOUNT: 50,
    ADMIN_CHANGE_NAME: 51,
    LOOT_CONVERSION: 52,
    HERO_WEAPON: 53,
    QUEST_PROGRESS: 54,
    MARATHON_PROGRESS: 55,
    TRY_OPEN_VIDEO: 56,
    START_WATCH_VIDEO: 57,
    CLIENT_LOG: 58,
    PRE_APP_OPEN: 59,
    PROMO_CODE_USED: 60,
    PROMO_CODE_BRUTE: 61,
    TAPJOY_INCOME: 62,
    ADS_INIT: 63,
    CLIENT_BUY_EVENT: 64,
    ROULETTE_EXTRA_REWARD: 65,
    GACHA: 66,
    PVE_FIGHT_END: 67,
    PVE_LEVEL: 68,
    ADMIN_ADD_CURRENCY: 69,
    REFERRAL_LINK: 70,
    REFERRAL_JOIN: 71,
    REFERRAL_INVITE: 72,
    SHOP_VIEWS: 73,
    SEASON: 74,
    SOFT_BAN: 75,
    REMATCH_REQUEST: 76,
    PENDING_ORDER_REPLACE: 77,
    FRIEND_FIGHT_END: 78,
    TRAINING_FINISH: 79,
    ADMIN_REPLACE_PLAYER: 80,
    ADMIN_WITHDRAW_CURRENCIES: 81,
    ADMIN_CHARGE_PURCHASE: 82,
    ADMIN_REMOVE_SUBSCRIPTION: 83,
    ANTI_CHEAT: 84,
    ADMIN_MODIFY_RATING: 85,
    BAN: 86,
    SOCIAL_PERMISSIONS_CHANGED: 87,
    FRIEND_ACTION: 88,
    BLACKLIST_ACTION: 89,
    DUEL_ACTION: 90,
    SOCIAL_PROFILE_RETRIEVE: 91,
    REPLAY_LAUNCH: 92,
    FIND_CUSTOMIZATION: 93,
    BP_PURCHASE_TUTORIAL: 94,
    LOBBY_CHEAT_DETECT: 95,
    PVP_CHEAT_DETECT: 96,
    ADMIN_MAIL_MESSAGE_CREATE: 97,
    ADMIN_MAIL_MESSAGE_STOP: 98,
    PLAYER_MAIL_MESSAGE_CLAIMED: 99,
    PLAYER_MAIL_MESSAGE_RECEIVED: 100,
    ADMIN_BAN_WRONG_WORLD: 101,
    TRANSFER_PROGRESS_GENERATE_CODE: 102,
    TRANSFER_PROGRESS_EXECUTE: 103,
    BUY_MARATHON_FROM_POPUP: 104,
    SOFT_BAN_RELEASE: 105,
    HERO_TEXT_EMOJI_PACK: 106,
    ALL_HEROES_TEXT_EMOJI_PACK: 107,
    AD_VIEWS: 108,
    PAYMENTS_STAT: 109,
    BUNDLE_PART_DOWNLOADED: 110,
    EMAIL: 111,
    EMAIL_SHARE: 112,
    ARENA_PURCHASE: 113,
    ARENA_PURCHASE_SUB: 114,
    ARENA_AD_REVENUE: 115,
    GAME_BANNER_LINK_CLICK: 116,
    HERO_STANCE: 117,
    ERASE_REQUEST: 118,
    ORDER_PAID: 119,
    PURCHASE_DEBUG: 120,
    XSOLLA_WS_LOGIN_TOKEN: 121,
    KEYBOARD_BUTTON_REMAP: 122,
    LOCAL_PVP_BATTLE_FINISH: 123,
    LINK_NEKKI_ID: 124,
    CUSTOMIZATION_UNLOCK: 125,
};
var LogLevel = {
    DISABLED: {
        ID: 1,
        Events: []
    },
    MINIMUM: {
        ID: 2,
        Events: [
            AnalyticsEventType.CHEST_OPEN,
            AnalyticsEventType.APPS_FLYER,
            AnalyticsEventType.LOGIN,
            AnalyticsEventType.LOGOUT,
            AnalyticsEventType.MAKE_PURCHASE,
            AnalyticsEventType.ORDER_PAID,
            AnalyticsEventType.PVP_FINISH_BATTLE,
            AnalyticsEventType.TUTORIAL_STEP,
            AnalyticsEventType.SHOW_OFFER,
            AnalyticsEventType.PURCHASE_RECEIPT,
            AnalyticsEventType.DAILY_INVENTORY,
            AnalyticsEventType.LOOT_CONVERSION,
            AnalyticsEventType.PAYMENTS_STAT,
            AnalyticsEventType.PURCHASE_DEBUG,
            AnalyticsEventType.XSOLLA_WS_LOGIN_TOKEN,
            AnalyticsEventType.REWARDED_VIDEO_AD,
            AnalyticsEventType.PROMO_CODE_USED,
            AnalyticsEventType.PROMO_CODE_BRUTE,
            AnalyticsEventType.PVE_FIGHT_END,
            AnalyticsEventType.REFERRAL_LINK,
            AnalyticsEventType.SHOP_VIEWS,
            AnalyticsEventType.FRIEND_FIGHT_END,
            AnalyticsEventType.ANTI_CHEAT,
            AnalyticsEventType.FIND_CUSTOMIZATION,
            AnalyticsEventType.BP_PURCHASE_TUTORIAL,
            AnalyticsEventType.BUY_MARATHON_FROM_POPUP,
            AnalyticsEventType.SOFT_BAN,
            AnalyticsEventType.TRANSFER_PROGRESS_EXECUTE,
            AnalyticsEventType.BUNDLE_PART_DOWNLOADED,
            AnalyticsEventType.EMAIL_SHARE,
            AnalyticsEventType.ARENA_PURCHASE,
            AnalyticsEventType.ARENA_PURCHASE_SUB,
            AnalyticsEventType.ARENA_AD_REVENUE,
            AnalyticsEventType.GAME_BANNER_LINK_CLICK,
            AnalyticsEventType.ERASE_REQUEST
        ]
    },
    FULL: {
        ID: 3,
        Events: createFullEventArray()
    },
    TUTORIAL: {
        ID: 4,
        Events: [
            AnalyticsEventType.APPS_FLYER,
            AnalyticsEventType.LOGIN,
            AnalyticsEventType.LOGOUT,
            AnalyticsEventType.MAKE_PURCHASE,
            AnalyticsEventType.ORDER_PAID,
            AnalyticsEventType.PVP_FINISH_BATTLE,
            AnalyticsEventType.TUTORIAL_STEP,
            AnalyticsEventType.SHOW_OFFER,
            AnalyticsEventType.PURCHASE_RECEIPT,
            AnalyticsEventType.CHEST_OPEN,
            AnalyticsEventType.LOOT_CONVERSION,
            AnalyticsEventType.PAYMENTS_STAT,
            AnalyticsEventType.PURCHASE_DEBUG,
            AnalyticsEventType.XSOLLA_WS_LOGIN_TOKEN,
            AnalyticsEventType.REWARDED_VIDEO_AD,
            AnalyticsEventType.PROMO_CODE_USED,
            AnalyticsEventType.PROMO_CODE_BRUTE,
            AnalyticsEventType.PVE_FIGHT_END,
            AnalyticsEventType.REFERRAL_LINK,
            AnalyticsEventType.SHOP_VIEWS,
            AnalyticsEventType.FRIEND_FIGHT_END,
            AnalyticsEventType.ANTI_CHEAT,
            AnalyticsEventType.FIND_CUSTOMIZATION,
            AnalyticsEventType.BP_PURCHASE_TUTORIAL,
            AnalyticsEventType.BUY_MARATHON_FROM_POPUP,
            AnalyticsEventType.SOFT_BAN,
            AnalyticsEventType.TRANSFER_PROGRESS_EXECUTE,
            AnalyticsEventType.BUNDLE_PART_DOWNLOADED,
            AnalyticsEventType.EMAIL_SHARE,
            AnalyticsEventType.ARENA_PURCHASE,
            AnalyticsEventType.ARENA_PURCHASE_SUB,
            AnalyticsEventType.ARENA_AD_REVENUE,
            AnalyticsEventType.GAME_BANNER_LINK_CLICK,
            AnalyticsEventType.ERASE_REQUEST
        ]
    },
    SHORT: {
        ID: 6,
        Events: createFullEventArray([])
    },
};
function createFullEventArray(excludeItems) {
    if (excludeItems === void 0) { excludeItems = []; }
    var result = [];
    for (var item in AnalyticsEventType) {
        var eventId = AnalyticsEventType[item];
        if (excludeItems.indexOf(eventId) < 0) {
            result.push(eventId);
        }
    }
    return result;
}
function calcLogLevelOfPair(id1, id2) {
    if (id1 % 20 == 0 || id2 % 20 == 0) {
        return LogLevel.FULL.ID;
    }
    if (id1 % 5 == 0 || id2 % 5 == 0) {
        return LogLevel.SHORT.ID;
    }
    return LogLevel.MINIMUM.ID;
}
function calcLogLevel(settings) {
    if (!settings
        || settings.sumOfPayments == undefined
        || settings.playerId == undefined
        || settings.appsFlyerNonOrganic == undefined
        || settings.deviceId == undefined
        || settings.playerLevel == undefined) {
        return LogLevel.FULL.ID;
    }
    var id = settings.playerId > 0 ? settings.playerId : CommonUtils.positiveHashCode(settings.deviceId);
    if (settings.sumOfPayments > 0 || id % 20 == 0) {
        return LogLevel.FULL.ID;
    }
    else if (settings.appsFlyerNonOrganic || id % 5 == 0) {
        return LogLevel.SHORT.ID;
    }
    else {
        return (settings.playerLevel > 1) ? LogLevel.MINIMUM.ID : LogLevel.TUTORIAL.ID;
    }
}
(function () {
    var MUST_LOGS = [
        AnalyticsEventType.MAKE_PURCHASE,
        AnalyticsEventType.ORDER_PAID,
        AnalyticsEventType.CHEST_OPEN,
    ];
    for (var name_1 in LogLevel) {
        var log = LogLevel[name_1];
        if (log.ID == 1)
            continue;
        for (var _i = 0, MUST_LOGS_1 = MUST_LOGS; _i < MUST_LOGS_1.length; _i++) {
            var id = MUST_LOGS_1[_i];
            if (log.Events.indexOf(id) == -1) {
                throw new Error("LogLevel ".concat(name_1, " must contain next events: ").concat(JSON.stringify(MUST_LOGS)));
            }
        }
    }
})();
var LogLevelMap = createIDMap(LogLevel, "LogLevelMap");
