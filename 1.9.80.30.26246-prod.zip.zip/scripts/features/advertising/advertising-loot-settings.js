var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67;
var advertisingLootSettings = (_a = {},
    _a[ADVERTISING_PLACE.FIGHT_REWARD] = {
        1: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 350, _b) }) } },
        ],
        2: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 350, _c) }) } },
        ],
        3: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.COIN] = 350, _d) }) } },
        ],
        4: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.COIN] = 350, _e) }) } },
        ],
        5: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 350, _f) }) } },
        ],
        6: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.COIN] = 350, _g) }) } },
        ],
        7: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.COIN] = 350, _h) }) } },
        ],
        8: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 350, _j) }) } },
        ],
        9: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.COIN] = 350, _k) }) } },
        ],
        10: [
            { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.COIN] = 350, _l) }) } },
        ],
    },
    _a[ADVERTISING_PLACE.CHEST] = (function () {
        var _a, _b, _c, _d, _e, _f;
        var balance = [
            { weight: 75, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 200, _a) }) } },
            { weight: 75, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 10, _b) }) } },
            { weight: 55, lootSettings: { CardsSlots: { TotalSlots: 1, TotalCards: 15, Rarities: (_c = {}, _c[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ N: 15, W: 1 }] }, _c) } } },
            { weight: 45, lootSettings: { CardsSlots: { TotalSlots: 1, TotalCards: 5, Rarities: (_d = {}, _d[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ N: 5, W: 1 }] }, _d) } } },
            { weight: 35, lootSettings: { CardsSlots: { TotalSlots: 1, TotalCards: 1, Rarities: (_e = {}, _e[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ N: 1, W: 1 }] }, _e) } } },
            { weight: 15, lootSettings: { CardsSlots: { TotalSlots: 1, TotalCards: 1, Rarities: (_f = {}, _f[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ N: 1, W: 1 }] }, _f) } } },
        ];
        var result = {};
        for (var arena = 1; arena <= 10; arena++) {
            result[arena] = balance;
        }
        return result;
    })(),
    _a[ADVERTISING_PLACE.ROGUELIKE_LOOT] = (function () {
        var _a;
        var result = {};
        for (var arena = 1; arena <= 10; arena++) {
            result[arena] = [
                { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.SILVER] = 85, _a) }) } }
            ];
        }
        return result;
    })(),
    _a);
var advertisingLootSettingsForGuarantee = (_m = {},
    _m[ADVERTISING_PLACE.SHOP] = {
        1: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_o = {}, _o[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _o) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_p = {}, _p[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _p) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_q = {}, _q[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _q) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_r = {}, _r[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _r) } } },
        ],
        2: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_s = {}, _s[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _s) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_t = {}, _t[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _t) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_u = {}, _u[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _u) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_v = {}, _v[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _v) } } },
        ],
        3: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_w = {}, _w[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _w) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_x = {}, _x[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _x) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_y = {}, _y[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _y) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_z = {}, _z[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _z) } } },
        ],
        4: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_0 = {}, _0[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _0) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_1 = {}, _1[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _1) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_2 = {}, _2[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _2) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_3 = {}, _3[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _3) } } },
        ],
        5: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_4 = {}, _4[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _4) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_5 = {}, _5[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _5) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_6 = {}, _6[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _6) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_7 = {}, _7[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _7) } } },
        ],
        6: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_8 = {}, _8[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _8) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_9 = {}, _9[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _9) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_10 = {}, _10[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _10) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_11 = {}, _11[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _11) } } },
        ],
        7: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_12 = {}, _12[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _12) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_13 = {}, _13[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _13) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_14 = {}, _14[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _14) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_15 = {}, _15[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _15) } } },
        ],
        8: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_16 = {}, _16[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _16) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_17 = {}, _17[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _17) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_18 = {}, _18[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _18) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_19 = {}, _19[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _19) } } },
        ],
        9: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_20 = {}, _20[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _20) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_21 = {}, _21[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _21) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_22 = {}, _22[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _22) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_23 = {}, _23[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _23) } } },
        ],
        10: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_24 = {}, _24[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _24) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_25 = {}, _25[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _25) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_26 = {}, _26[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _26) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_27 = {}, _27[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _27) } } },
        ],
    },
    _m[ADVERTISING_PLACE.CHEST] = {
        1: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_28 = {}, _28[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _28) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_29 = {}, _29[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _29) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_30 = {}, _30[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _30) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_31 = {}, _31[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _31) } } },
        ],
        2: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_32 = {}, _32[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _32) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_33 = {}, _33[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _33) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_34 = {}, _34[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _34) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_35 = {}, _35[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _35) } } },
        ],
        3: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_36 = {}, _36[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _36) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_37 = {}, _37[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _37) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_38 = {}, _38[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _38) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_39 = {}, _39[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _39) } } },
        ],
        4: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_40 = {}, _40[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _40) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_41 = {}, _41[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _41) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_42 = {}, _42[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _42) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_43 = {}, _43[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _43) } } },
        ],
        5: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_44 = {}, _44[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _44) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_45 = {}, _45[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _45) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_46 = {}, _46[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _46) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_47 = {}, _47[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _47) } } },
        ],
        6: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_48 = {}, _48[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _48) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_49 = {}, _49[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _49) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_50 = {}, _50[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _50) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_51 = {}, _51[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _51) } } },
        ],
        7: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_52 = {}, _52[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _52) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_53 = {}, _53[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _53) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_54 = {}, _54[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _54) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_55 = {}, _55[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _55) } } },
        ],
        8: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_56 = {}, _56[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _56) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_57 = {}, _57[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _57) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_58 = {}, _58[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _58) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_59 = {}, _59[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _59) } } },
        ],
        9: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_60 = {}, _60[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _60) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_61 = {}, _61[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _61) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_62 = {}, _62[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _62) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_63 = {}, _63[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _63) } } },
        ],
        10: [
            { weight: 47, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_64 = {}, _64[HERO_RARITY.COMMON] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _64) } } },
            { weight: 26, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_65 = {}, _65[HERO_RARITY.RARE] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _65) } } },
            { weight: 20, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_66 = {}, _66[HERO_RARITY.EPIC] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _66) } } },
            { weight: 7, lootSettings: { CardsSlots: { TotalSlots: 0, TotalCards: 0, Rarities: (_67 = {}, _67[HERO_RARITY.LEGENDARY] = { Slots: 0, ShardsWeight: [{ W: 1, N: 2 }], ShardsMode: SHARDS_GENERATING_MODE.RANDOM }, _67) } } },
        ],
    },
    _m[ADVERTISING_PLACE.ROGUELIKE_LOOT] = (function () {
        var _a, _b, _c;
        var result = {};
        for (var i = 1; i <= 10; i++) {
            result[i] = [
                { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_a = {}, _a[buffModifiers.epicBuffs.ID] = 1, _a) }) } },
                { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_b = {}, _b[buffModifiers.timerBuff.ID] = 1, _b) }) } },
                { weight: 1, lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_c = {}, _c[buffModifiers.twoBuffPerChoice.ID] = 1, _c) }) } },
            ];
        }
        return result;
    })(),
    _m);
