function generateAdvertisingLoot(parameters) {
    return Advertising.generateAdvertisingLoot(parameters);
}
function getExcludedAdvertisingSources() {
    return [];
}
function AdsAvailable(settings) {
    return Advertising.adsAvailable(settings);
}
function getAdvertisingOfferLimit(offerId) {
    return Advertising.getAdvertisingOfferLimit(offerId);
}
function getAdClaimsToGetGuaranteedReward() {
    return AdvertisingConstants.adClaimsToGetGuarantee;
}
function getAdPlacesToDisable() {
    return AdvertisingConstants.adOfferDisablePlaces;
}
function getAppLovinExtraParametersForInit(settings) {
    return Advertising.getAppLovinExtraParametersForInit(settings);
}
function isAdCardFaceUpInPlacement(settings) {
    return Advertising.isAdCardFaceUpInPlacement(settings);
}
