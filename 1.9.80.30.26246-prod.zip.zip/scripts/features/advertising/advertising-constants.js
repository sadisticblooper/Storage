var _a, _b;
var AdvertisingConstants = (function () {
    function AdvertisingConstants() {
    }
    AdvertisingConstants.advertisingSchedule = {
        Origin: "2016-01-01T03:00:00+03:00",
        Period: new Time({ Days: 1 }).value
    };
    AdvertisingConstants.advertisingLimitDuringShopSchedule = 2;
    AdvertisingConstants.advertisingLimit = (_a = {},
        _a[ADVERTISING_PLACE.ROGUELIKE_LOOT] = 4,
        _a[ADVERTISING_PLACE.FIGHT_REWARD] = 10,
        _a[ADVERTISING_PLACE.TOURNAMENT_STAGE_REWARD] = 3,
        _a);
    AdvertisingConstants.advertisingEnable = [
        ADVERTISING_PLACE.SHOP,
        ADVERTISING_PLACE.CHEST,
        ADVERTISING_PLACE.FIGHT_REWARD,
        ADVERTISING_PLACE.ROGUELIKE_LOOT,
        ADVERTISING_PLACE.TOURNAMENT_STAGE_REWARD,
    ];
    AdvertisingConstants.freeOfAdsAfterPurchaseTime = new Time({ Days: 0 }).value;
    AdvertisingConstants.advertisingOfferLimits = {
        advertisingLimit: 5,
    };
    AdvertisingConstants.adClaimsToGetGuarantee = (_b = {},
        _b[ADVERTISING_PLACE.CHEST] = null,
        _b[ADVERTISING_PLACE.SHOP] = null,
        _b[ADVERTISING_PLACE.FIGHT_REWARD] = null,
        _b[ADVERTISING_PLACE.ROGUELIKE_LOOT] = 4,
        _b);
    AdvertisingConstants.adOfferDisablePlaces = [
        ADVERTISING_PLACE.SHOP,
        ADVERTISING_PLACE.CHEST,
        ADVERTISING_PLACE.FIGHT_REWARD,
        ADVERTISING_PLACE.CHEST_SKIP,
        ADVERTISING_PLACE.ROGUELIKE_BUFF_REROLL,
        ADVERTISING_PLACE.ROGUELIKE_RESURRECTION,
    ];
    AdvertisingConstants.waitForRewardTimeInSeconds = 5;
    AdvertisingConstants.waitForRewardedEventAfterTimeoutTimeInSeconds = 5;
    AdvertisingConstants.storageCapacityForMedianViews = 4;
    AdvertisingConstants.AD_SLOT_VARIANTS = [
        {
            SlotType: SHOP_SLOT_TYPE.SHARDS, Rarity: HERO_RARITY.COMMON, Num: 1, CurrencyType: CURRENCY.BONUS,
            CurrencyNum: 0, Weight: 47
        },
        {
            SlotType: SHOP_SLOT_TYPE.SHARDS, Rarity: HERO_RARITY.RARE, Num: 1, CurrencyType: CURRENCY.BONUS,
            CurrencyNum: 0, Weight: 26
        },
        {
            SlotType: SHOP_SLOT_TYPE.SHARDS, Rarity: HERO_RARITY.EPIC, Num: 1, CurrencyType: CURRENCY.BONUS,
            CurrencyNum: 0, Weight: 20
        },
        {
            SlotType: SHOP_SLOT_TYPE.SHARDS, Rarity: HERO_RARITY.LEGENDARY, Num: 1, CurrencyType: CURRENCY.BONUS,
            CurrencyNum: 0, Weight: 7
        },
    ];
    AdvertisingConstants.PLACES_WITH_FACE_UP = [];
    AdvertisingConstants.adTokensPriceToSkipAdInPlacement = (function () {
        var table = {};
        Object.keys(ADVERTISING_PLACE)
            .filter(isNumber)
            .map(Number)
            .forEach(function (c) {
            var _a;
            return table[c] = (_a = {}, _a[CURRENCY.AD_TOKEN] = 1, _a);
        });
        return table;
    })();
    return AdvertisingConstants;
}());
