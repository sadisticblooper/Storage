var AdCustomClaim = (function () {
    function AdCustomClaim(counters, adObject) {
        this.loadParameters(counters, adObject);
    }
    AdCustomClaim.prototype.updateViewCounter = function () {
        if (this.maxCounter) {
            this.counter = (this.counter + 1) % this.maxCounter;
            this.counters[this.place] = this.counter;
        }
    };
    AdCustomClaim.prototype.isCustomRewardNeeded = function () {
        return this.maxCounter && this.counter == 0;
    };
    AdCustomClaim.prototype.getUpdatedViewCounters = function () {
        return this.counters;
    };
    AdCustomClaim.prototype.loadParameters = function (counters, adObject) {
        this.place = adObject.Place;
        this.counters = counters;
        this.maxCounter = AdvertisingConstants.adClaimsToGetGuarantee[this.place] || 0;
        this.counter = this.maxCounter ? (counters[this.place] || 0) : 0;
    };
    return AdCustomClaim;
}());
