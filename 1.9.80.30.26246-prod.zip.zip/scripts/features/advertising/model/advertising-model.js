var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var Advertising = (function () {
    function Advertising() {
    }
    Advertising.isEnable = function (type) {
        return AdvertisingConstants.advertisingEnable.indexOf(type) != -1;
    };
    Advertising.isAvailableByCounter = function (type, currentCounter) {
        return AdvertisingConstants.advertisingLimit[type] == undefined
            || currentCounter < AdvertisingConstants.advertisingLimit[type];
    };
    Advertising.copyAdvertisingObject = function (obj) {
        var result = {
            Place: obj.Place,
            Quantity: obj.Quantity,
        };
        if (obj.ExtraAdParameters) {
            CommonUtils.replaceReadOnlyProperty(result, "ExtraAdParameters", __assign({}, obj.ExtraAdParameters));
        }
        return result;
    };
    Advertising.adsAvailable = function (settings) {
        var deviceInfoJSON = JSON.parse(settings.deviceInfo);
        if ((deviceInfoJSON["RAM"] < 1700 && deviceInfoJSON["OS"].toLowerCase().indexOf("android") >= 0))
            return [];
        return [
            OFFER_WALL_TYPE.APPLOVIN,
            OFFER_WALL_TYPE.FYBER,
            OFFER_WALL_TYPE.TAPJOY
        ];
    };
    Advertising.generateAdvertisingLoot = function (parameters) {
        var _a;
        var AdvertisingObject = parameters.AdvertisingObject, BattlePassProgress = parameters.BattlePassProgress, isFreeOfAds = parameters.IsFreeOfAds, Seed = parameters.Seed, AdClaimCounters = parameters.AdClaimCounters, StartTimeOfCurrentDayMS = parameters.StartTimeOfCurrentDayMS, SilverBonusId = parameters.SilverBonusId;
        RandomInstance.setSeed(Seed);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(parameters.PlayerProgress);
        var chestPositions = PseudorandomPositionGetter.getFromRaw(parameters.ChestQueuePositions);
        if (!AdvertisingObject) {
            throw new Error("There in no AdvertisingObject in generateAdvertisingLoot."
                + JSON.stringify([parameters]));
        }
        var adCustomClaim = new AdCustomClaim(AdClaimCounters, AdvertisingObject);
        var advertisingPlace = AdvertisingObject.Place;
        var isBpConversion = BattlePass.doNeedConvertBattlePassPoints(BattlePassProgress);
        var adsCardQuantity = AdvertisingObject.Quantity ? +AdvertisingObject.Quantity : 1;
        adsCardQuantity = (isFreeOfAds || advertisingPlace == ADVERTISING_PLACE.FIGHT_REWARD) ? adsCardQuantity : 1;
        var loot;
        if (advertisingPlace == ADVERTISING_PLACE.TOURNAMENT_STAGE_REWARD) {
            var tournamentResult = TournamentReward.generateAdvertisingLoot({
                extraAdParameters: AdvertisingObject.ExtraAdParameters,
                chestQueuePositions: chestPositions,
                adCustomClaim: adCustomClaim,
                playerProgress: playerProgress,
                rnd: RandomInstance,
                seed: Seed,
                startTimeOfCurrentDayMS: StartTimeOfCurrentDayMS,
            });
            loot = tournamentResult.loot;
            chestPositions = tournamentResult.chestQueuePositions;
        }
        else if (advertisingPlace == ADVERTISING_PLACE.SHOP) {
            var shopResult = Advertising.generateAdvertisingLootForShop({
                playerProgress: playerProgress,
                adCustomClaim: adCustomClaim,
                rnd: RandomInstance,
                startTimeOfCurrentDayMS: StartTimeOfCurrentDayMS,
                chestQueuePositions: chestPositions,
                seed: Seed,
            });
            loot = shopResult.loot;
            chestPositions = shopResult.chestQueuePositions;
        }
        else {
            loot = Advertising.generateCommonAdvertisingLoot({
                playerProgress: playerProgress,
                advertisingPlace: advertisingPlace,
                adsCardQuantity: adsCardQuantity,
                adCustomClaim: adCustomClaim,
                startTimeOfCurrentDayMS: StartTimeOfCurrentDayMS,
                rnd: RandomInstance,
            });
        }
        if (!loot || loot.isEmpty()) {
            logMessageOverEnvironment("Loot is empty in generateAdvertisingLoot. ".concat(JSON.stringify(parameters)));
            loot = new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 6, _a) });
        }
        if (isBpConversion) {
            loot = BattlePassUtils.convertBattlePassLoot(loot, BattlePassProgress);
        }
        if (SilverBonusId) {
            var bonus = getRoguelikeSilverBonus({ bonusId: SilverBonusId });
            if (bonus) {
                LootUtils.multiplyCurrency(loot, bonus.applyToCurrency, bonus.bonusCoefficient);
            }
        }
        return {
            Loot: loot,
            NewSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
            ChestQueuePositions: chestPositions,
            AdClaimCounters: adCustomClaim.getUpdatedViewCounters(),
        };
    };
    Advertising.getAdvertisingOfferLimit = function (offerId) {
        return offerId == ShopSlots.RG_ENERGY_FREE.ID
            ? AdvertisingConstants.advertisingOfferLimits.advertisingLimit
            : null;
    };
    Advertising.getAppLovinExtraParametersForInit = function (settings) {
        var platform = settings.platform, deviceInfo = settings.deviceInfo, forcedResult = settings.forcedResult, adUnits = settings.adUnits;
        if (forcedResult) {
            return forcedResult;
        }
        try {
            var deviceInfoJSON = JSON.parse(deviceInfo);
            if ([PLATFORM.ANDROID].indexOf(platform) > -1 && deviceInfoJSON["RAM"] <= 4096) {
                return {
                    "disable_b2b_ad_unit_ids": adUnits ? adUnits.join(",") : ""
                };
            }
            return {};
        }
        catch (e) {
            return {};
        }
    };
    Advertising.isAdCardFaceUpInPlacement = function (settings) {
        var placement = settings.placement;
        return AdvertisingConstants.PLACES_WITH_FACE_UP.indexOf(placement) > -1;
    };
    Advertising.generateAdvertisingLootForShop = function (settings) {
        var playerProgress = settings.playerProgress, adCustomClaim = settings.adCustomClaim, rnd = settings.rnd, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, seed = settings.seed;
        var chestQueuePositions = settings.chestQueuePositions;
        var arenaId = playerProgress.playerArenaId;
        var arena = arenasMap.checkedGet(arenaId);
        var isGuaranteeReward = false;
        var resultLoot = new Loot();
        adCustomClaim.updateViewCounter();
        if (adCustomClaim.isCustomRewardNeeded()) {
            var guaranteePlaceSettings = advertisingLootSettingsForGuarantee[ADVERTISING_PLACE.SHOP];
            var variants = guaranteePlaceSettings && guaranteePlaceSettings[arenaId];
            if (variants) {
                isGuaranteeReward = true;
                resultLoot.combineLoot(Advertising.getLootFromVariants({
                    playerProgress: playerProgress,
                    variants: variants,
                    rnd: rnd,
                    serverTime: startTimeOfCurrentDayMS,
                }));
            }
        }
        if (!isGuaranteeReward) {
            var arenaNumber = Math.min(ArenaConstants.maxArenaNumber, arena.ArenaNumber);
            var shopParametersArray = ShopConstants.shopSlotsInfo[arenaNumber];
            var shopParameters = void 0;
            for (var _i = 0, shopParametersArray_1 = shopParametersArray; _i < shopParametersArray_1.length; _i++) {
                var parameters = shopParametersArray_1[_i];
                if (parameters.ShopOfferType == SHOP_OFFER_TYPE.ADVERTISING) {
                    shopParameters = parameters;
                    break;
                }
            }
            if (!shopParameters) {
                throw new Error("generateAdvertisingLoot: ADVERTISING slot not found! "
                    + "".concat(JSON.stringify([settings, shopParametersArray])));
            }
            var shopOfferSettings = new ShopOfferSettings(shopParameters);
            var offer = new ShopOffer();
            var playerSettings = {
                shopType: SHOP_TYPE.COMMON,
                playerProgress: playerProgress,
                regionalSettings: null,
                seed: seed,
                startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            };
            offer.generate(playerSettings, shopOfferSettings);
            if (!offer.loot.isEmpty()) {
                resultLoot.combineLoot(offer.loot);
            }
            if (offer._chestID) {
                var chestParameters = {
                    Seed: seed,
                    ChestID: offer._chestID,
                    PlayerProgress: playerProgress,
                    ChestQueuePositions: chestQueuePositions,
                    ChestArena: arenaId,
                    StartTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
                };
                var resultGenerating = generateLootFromChest(chestParameters);
                var chestLoot = resultGenerating.Loot;
                chestQueuePositions = resultGenerating.ChestQueuePositions;
                if (chestLoot && !chestLoot.isEmpty()) {
                    resultLoot.combineLoot(chestLoot);
                }
            }
        }
        return {
            loot: resultLoot,
            chestQueuePositions: chestQueuePositions,
        };
    };
    Advertising.generateCommonAdvertisingLoot = function (settings) {
        var advertisingPlace = settings.advertisingPlace, playerProgress = settings.playerProgress, adsCardQuantity = settings.adsCardQuantity, adCustomClaim = settings.adCustomClaim, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, rnd = settings.rnd;
        var arenaId = playerProgress.playerArenaId;
        var placeSettings = advertisingLootSettings[advertisingPlace];
        var guaranteePlaceSettings = advertisingLootSettingsForGuarantee[advertisingPlace];
        var guaranteeVariants = guaranteePlaceSettings && guaranteePlaceSettings[arenaId];
        if (!placeSettings) {
            throw new Error("There is no such place in generateAdvertisingLoot. ".concat(JSON.stringify(settings)));
        }
        var variants = placeSettings[arenaId];
        var resultLoot = new Loot();
        for (var i = 0; i < adsCardQuantity; i++) {
            adCustomClaim.updateViewCounter();
            var currentVariants = adCustomClaim.isCustomRewardNeeded() && guaranteeVariants
                ? guaranteeVariants
                : variants;
            resultLoot.combineLoot(Advertising.getLootFromVariants({
                playerProgress: playerProgress,
                variants: currentVariants,
                serverTime: startTimeOfCurrentDayMS,
                rnd: rnd,
            }));
        }
        return resultLoot;
    };
    Advertising.getLootFromVariants = function (settings) {
        var playerProgress = settings.playerProgress, rnd = settings.rnd, serverTime = settings.serverTime, variants = settings.variants;
        var collection = new RandomCollection();
        for (var _i = 0, variants_1 = variants; _i < variants_1.length; _i++) {
            var item = variants_1[_i];
            collection.add(new CollectionObjectContainer(item.lootSettings, item.weight));
        }
        var lootSettings = collection.next(rnd).get();
        var lootGenerator = LootGeneratorBuilder.getCommonLootGenerator();
        lootGenerator.setLootSettings(lootSettings);
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(serverTime);
        return lootGenerator.generateLoot(rnd);
    };
    return Advertising;
}());
