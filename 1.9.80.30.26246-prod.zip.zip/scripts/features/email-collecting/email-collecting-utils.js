var EmailCollectingUtils = (function () {
    function EmailCollectingUtils() {
    }
    EmailCollectingUtils.getEmailLinkingStateInfo = function (settings) {
        var playerEmailState = settings.playerEmailState;
        return {
            isAvailable: EmailCollectingUtils.isEmailLinkingAvailableForPlayer(settings),
            isLinked: playerEmailState == PLAYER_EMAIL_STATE.PMS_LINKED
        };
    };
    EmailCollectingUtils.getEmailLinkingMessage = function () {
        return {
            previewHeaderAlias: "email_collect_module_header",
            previewSubHeaderAlias: "email_collect_module_subheader",
            body: {
                localized: true,
                header: "email_collect_screen_header",
                subHeader: "email_collect_screen_subheader",
                body: "email_collect_screen_info",
                image: "Sprites/PreviewImages/Mail/mail_message_image_subscription",
                colorState: "Green",
                link: "sfa://emaillinkingpopup?source=MailModule",
                linkButtonColor: "Green",
                linkButtonAlias: "email_collect_subscribe",
            },
        };
    };
    EmailCollectingUtils.canShowEmailLinkingActivityPopup = function (settings) {
        var playerProgress = settings.playerProgress, emailWasLinked = settings.emailWasLinked, counterOfShowingPopup = settings.counterOfShowingPopup, previousTimeOfShowingPopup = settings.previousTimeOfShowingPopup, currentServerTime = settings.currentServerTime;
        counterOfShowingPopup = isNumber(counterOfShowingPopup) && counterOfShowingPopup > -1
            ? counterOfShowingPopup
            : 0;
        previousTimeOfShowingPopup = isNumber(previousTimeOfShowingPopup) && previousTimeOfShowingPopup > -1
            ? previousTimeOfShowingPopup
            : 0;
        var isEmailLinkingAvailable = EmailCollectingUtils.isEmailLinkingAvailableForPlayer({
            emailWasLinked: emailWasLinked,
            playerProgress: playerProgress,
        });
        var reminderSchedule = EmailCollectingConstants.reminderSchedule;
        if (emailWasLinked || !isEmailLinkingAvailable || counterOfShowingPopup > reminderSchedule.length) {
            return false;
        }
        if (counterOfShowingPopup == 0) {
            return true;
        }
        if (previousTimeOfShowingPopup == 0) {
            throw new Error("canShowEmailLinkingActivityPopup: can't get time for next showing case "
                + "previousTimeOfShowingPopup is 0");
        }
        counterOfShowingPopup = Math.min(counterOfShowingPopup - 1, reminderSchedule.length - 1);
        var delayPeriod = reminderSchedule[counterOfShowingPopup];
        var previousDateOfShowing = new Date(previousTimeOfShowingPopup).setUTCHours(0, 0, 0, 0);
        var timeToShowPopup = previousDateOfShowing + delayPeriod;
        return currentServerTime >= timeToShowPopup;
    };
    EmailCollectingUtils.isEmailLinkingAvailableForPlayer = function (settings) {
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var emailLinkingSource = settings.emailLinkingSource, emailWasLinked = settings.emailWasLinked;
        if (emailLinkingSource === undefined || emailLinkingSource == EMAIL_LINKING_SOURCE.ACCOUNT_SETTINGS) {
            return true;
        }
        if (playerProgress.accountLevel < 3) {
            return false;
        }
        return !emailWasLinked;
    };
    EmailCollectingUtils.getEmailLinkingActivityPopupVisualSettings = function () {
        return EmailCollectingConstants.popup.visual;
    };
    EmailCollectingUtils.getEmailLinkingActivityPopupSettings = function () {
        return EmailCollectingConstants.popup.data;
    };
    return EmailCollectingUtils;
}());
