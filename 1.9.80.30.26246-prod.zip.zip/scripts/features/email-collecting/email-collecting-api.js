function getEmailLinkingStateInfo(settings) {
    return EmailCollectingUtils.getEmailLinkingStateInfo(settings);
}
function getEmailLinkingMessage() {
    return EmailCollectingUtils.getEmailLinkingMessage();
}
function canShowEmailLinkingActivityPopup(settings) {
    return EmailCollectingUtils.canShowEmailLinkingActivityPopup(settings);
}
function getEmailLinkingActivityPopupVisualSettings() {
    return EmailCollectingUtils.getEmailLinkingActivityPopupVisualSettings();
}
function getEmailLinkingActivityPopupSettings() {
    return EmailCollectingUtils.getEmailLinkingActivityPopupSettings();
}
