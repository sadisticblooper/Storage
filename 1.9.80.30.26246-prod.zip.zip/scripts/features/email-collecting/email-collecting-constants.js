var EmailCollectingConstants = (function () {
    function EmailCollectingConstants() {
    }
    EmailCollectingConstants.reminderSchedule = [
        new Time({ Days: 7 }).value,
        new Time({ Days: 14 }).value,
        new Time({ Days: 21 }).value,
    ];
    EmailCollectingConstants.emailLinkingVerificationCodeLimit = 6;
    EmailCollectingConstants.truncateEmailGreaterThanLength = 40;
    EmailCollectingConstants.emailRegexPattern = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
    EmailCollectingConstants.verificationCodeCooldownSeconds = 60;
    EmailCollectingConstants.popup = {
        data: {
            "ID": 100002,
            "priority": 4,
            "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
            "navigationLinkURL": "sfa://mail?selectPinnedMessage=true",
            "navigationArg": 0,
            "activeTime": [],
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": icons.icon_collecting_email.ID,
            "rulesHeader": null,
            "rulesDescription": null,
            "header": {
                "alias": "email_collect_header",
                "color": "#5effcf"
            },
            "subHeader": null,
            "timer": null,
            "button": {
                "alias": "button_proceed",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Events/Features/art_activity_email",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Events/WidowEvent/bg_tournament_widow",
                "color": "#338A70"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#4ccfa898"
            },
            "particles": {
                "maxColor": "#4ccfa8",
                "minColor": "#4ccfa8"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#338a70"
                    },
                    {
                        "time": 0.98,
                        "color": "#338a70"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#4ccfa8"
                    },
                    {
                        "time": 0.99,
                        "color": "#bcd9e5"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": [
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "email_collect_bulletpoint_1",
                    "color": "#4ccfa8"
                },
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "email_collect_bulletpoint_2",
                    "color": "#4ccfa8"
                },
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "email_collect_bulletpoint_3",
                    "color": "#4ccfa8"
                }
            ],
            "pattern": {
                "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                "color": "#63FFD18D"
            }
        },
    };
    return EmailCollectingConstants;
}());
