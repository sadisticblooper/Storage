var OfferPriceCalculations = (function () {
    function OfferPriceCalculations() {
    }
    OfferPriceCalculations.prepareSymbols = function () {
        OfferPriceCalculations.fastSearchMap = {};
        OfferPriceCalculations.forwardReversedMaps = [];
        OfferPriceCalculations.bmpDigits = "";
        var classicDigits = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
        var indexInForwardReversedMaps = 0;
        for (var _i = 0, _a = OfferPriceCalculations.UNICODE_RANGE_STARTS; _i < _a.length; _i++) {
            var zeroSymbol = _a[_i];
            var maps = { unicodeToClassic: {}, classicToUnicode: {} };
            var startCodePoint = zeroSymbol.charCodeAt(0);
            if (startCodePoint === undefined) {
                throw new Error("prepareForwardReversedMaps error: symbol ".concat(zeroSymbol, ", no code point."));
            }
            for (var i = 0; i < classicDigits.length; i++) {
                var classicDigit = classicDigits[i];
                var unicodeDigit = String.fromCharCode(startCodePoint + i);
                maps.unicodeToClassic[unicodeDigit] = classicDigit;
                maps.classicToUnicode[classicDigit] = unicodeDigit;
                OfferPriceCalculations.fastSearchMap[unicodeDigit] = indexInForwardReversedMaps;
                OfferPriceCalculations.bmpDigits += unicodeDigit;
            }
            OfferPriceCalculations.forwardReversedMaps.push(maps);
            indexInForwardReversedMaps++;
        }
    };
    OfferPriceCalculations.getOfferOldPrice = function (settings) {
        var price = settings.price, profit = settings.profit;
        try {
            if (!price) {
                return null;
            }
            price = price.replace(OfferPriceCalculations.WHITE_SPACE_SEARCH_REGEXP, OfferPriceCalculations.WHITE_SPACE);
            var digits = price.match(new RegExp("[".concat(OfferPriceCalculations.bmpDigits, "]"), "g"));
            if (!digits || digits.length == 0) {
                return null;
            }
            var digitsStartIndex = price.indexOf(digits[0]);
            var digitsEndIndex = price.lastIndexOf(digits[digits.length - 1]);
            var prefixString = price.substring(0, digitsStartIndex);
            var postfixString = price.substring(digitsEndIndex + 1);
            var partWithDigits = price.substring(digitsStartIndex, digitsEndIndex + 1);
            var cultureInfo = OfferPriceCalculations.getCultureInfo(partWithDigits, digits);
            if (!cultureInfo) {
                return null;
            }
            var priceNumber = OfferPriceCalculations.getNumberFromPrice(partWithDigits, cultureInfo);
            if (isNaN(priceNumber)) {
                return null;
            }
            var priceWithProfit = priceNumber * profit;
            var culturePriceWithProfit = OfferPriceCalculations.toToCultureString(priceWithProfit, cultureInfo);
            return prefixString + culturePriceWithProfit + postfixString;
        }
        catch (e) { }
        return null;
    };
    OfferPriceCalculations.getCultureInfo = function (partWithDigits, digits) {
        var firstDigit = digits[0];
        var indexInMaps = OfferPriceCalculations.fastSearchMap[firstDigit];
        if (indexInMaps === undefined) {
            return null;
        }
        var maps = OfferPriceCalculations.forwardReversedMaps[indexInMaps];
        var _a = [
            OfferPriceCalculations.WHITE_SPACE,
            OfferPriceCalculations.DECIMAL_DIGITS,
            OfferPriceCalculations.COMMA_SEARCH_REGEXP,
            OfferPriceCalculations.DOT_SEARCH_REGEXP,
            OfferPriceCalculations.WHITE_SPACE_SEARCH_REGEXP,
            OfferPriceCalculations.bmpDigits,
        ], WHITE_SPACE = _a[0], DECIMAL_DIGITS = _a[1], COMMA_SEARCH_REGEXP = _a[2], DOT_SEARCH_REGEXP = _a[3], WHITE_SPACE_SEARCH_REGEXP = _a[4], BMP_DIGITS = _a[5];
        var _b = [
            OfferPriceCalculations.COMMA,
            OfferPriceCalculations.DOT,
        ], COMMA = _b[0], DOT = _b[1];
        var forceDecimalRest = false;
        var decimalDigits = DECIMAL_DIGITS;
        var groupSeparator = WHITE_SPACE;
        var decimalSeparator = DOT;
        if (partWithDigits.length >= DECIMAL_DIGITS + 1) {
            var commaSymbols = partWithDigits.match(COMMA_SEARCH_REGEXP);
            var dotSymbols = partWithDigits.match(DOT_SEARCH_REGEXP);
            var hasWhiteSpace = !!partWithDigits.match(WHITE_SPACE_SEARCH_REGEXP);
            COMMA = commaSymbols && commaSymbols.length > 0 ? commaSymbols[0] : OfferPriceCalculations.COMMA;
            DOT = dotSymbols && dotSymbols.length > 0 ? dotSymbols[0] : OfferPriceCalculations.DOT;
            var regExpForUnknownSymbols = new RegExp("[^".concat(BMP_DIGITS, "\\s").concat(COMMA).concat(DOT, "]"));
            if (regExpForUnknownSymbols.test(partWithDigits)) {
                return null;
            }
            commaSymbols = partWithDigits.match(new RegExp(COMMA, "g")) || [];
            dotSymbols = partWithDigits.match(new RegExp(DOT == "." ? "\\".concat(DOT) : DOT, "g")) || [];
            if (commaSymbols.length >= 2) {
                groupSeparator = COMMA;
                decimalSeparator = DOT;
            }
            else if (dotSymbols.length >= 2) {
                groupSeparator = DOT;
                decimalSeparator = COMMA;
            }
            else if (commaSymbols.length == 1) {
                var index = partWithDigits.lastIndexOf(COMMA);
                if (index == partWithDigits.length - 1 - DECIMAL_DIGITS || hasWhiteSpace) {
                    decimalSeparator = COMMA;
                    groupSeparator = dotSymbols.length > 0 ? DOT : WHITE_SPACE;
                }
                else {
                    decimalSeparator = DOT;
                    groupSeparator = COMMA;
                }
            }
            else if (dotSymbols.length == 1) {
                var index = partWithDigits.lastIndexOf(DOT);
                if (index == partWithDigits.length - 1 - DECIMAL_DIGITS || hasWhiteSpace) {
                    decimalSeparator = DOT;
                    groupSeparator = commaSymbols.length > 0 ? COMMA : WHITE_SPACE;
                }
                else {
                    decimalSeparator = COMMA;
                    groupSeparator = DOT;
                }
            }
        }
        var decimalSeparatorIndex = partWithDigits.lastIndexOf(decimalSeparator);
        if (decimalSeparatorIndex > -1) {
            var rest = partWithDigits.substring(decimalSeparatorIndex + 1);
            decimalDigits = rest.length;
            var restNumber = parseInt(rest);
            forceDecimalRest = !isNaN(restNumber) && restNumber == 0;
        }
        return {
            digitMaps: maps,
            decimalSeparator: decimalSeparator,
            groupSeparator: groupSeparator,
            decimalDigits: decimalDigits,
            forceDecimalRest: forceDecimalRest
        };
    };
    OfferPriceCalculations.getNumberFromPrice = function (partWithDigits, cultureInfo) {
        var decimalSeparator = cultureInfo.decimalSeparator, digitMaps = cultureInfo.digitMaps;
        var indexOfDecimalSeparator = partWithDigits.lastIndexOf(decimalSeparator);
        var regForNoneDigits = new RegExp("[^".concat(OfferPriceCalculations.bmpDigits, "]"), "g");
        var integerPart = indexOfDecimalSeparator > -1
            ? partWithDigits.substring(0, indexOfDecimalSeparator)
            : partWithDigits;
        var floatPart = indexOfDecimalSeparator > -1
            ? partWithDigits.substring(indexOfDecimalSeparator + 1)
            : "0";
        integerPart = integerPart.replace(regForNoneDigits, "");
        floatPart = floatPart.replace(regForNoneDigits, "");
        return parseFloat(OfferPriceCalculations.convertDigitsFromString(integerPart, digitMaps.unicodeToClassic)
            + OfferPriceCalculations.DOT
            + OfferPriceCalculations.convertDigitsFromString(floatPart, digitMaps.unicodeToClassic));
    };
    OfferPriceCalculations.toToCultureString = function (n, cultureInfo) {
        var digitMaps = cultureInfo.digitMaps, decimalSeparator = cultureInfo.decimalSeparator, groupSeparator = cultureInfo.groupSeparator, decimalDigits = cultureInfo.decimalDigits, forceDecimalRest = cultureInfo.forceDecimalRest;
        var integerPart = Math.floor(n);
        var floatPart = n - integerPart;
        var integerUnicodePart = OfferPriceCalculations
            .convertDigitsFromString(integerPart.toString(), digitMaps.classicToUnicode);
        var integerPartLength = integerUnicodePart.length;
        var result = "";
        for (var i = 0; i < integerPartLength; i++) {
            if (i > 0 && i % 3 == 0) {
                result = groupSeparator + result;
            }
            result = integerUnicodePart.charAt(integerPartLength - 1 - i) + result;
        }
        if (floatPart > 0 || forceDecimalRest) {
            var currentDecimalDigits = floatPart == 0 ? "0" : floatPart.toString().substring(2);
            var currentDigitsLength = currentDecimalDigits.length;
            var digits = currentDigitsLength > decimalDigits
                ? currentDecimalDigits.substring(0, decimalDigits)
                : currentDecimalDigits + (new Array(1 + decimalDigits - currentDigitsLength)).join("0");
            var floatUnicodePart = OfferPriceCalculations
                .convertDigitsFromString(digits, digitMaps.classicToUnicode);
            result += decimalSeparator + floatUnicodePart;
        }
        return result;
    };
    OfferPriceCalculations.convertDigitsFromString = function (n, map) {
        var result = "";
        for (var i = 0; i < n.length; i++) {
            var digit = n.charAt(i);
            if (map[digit] === undefined) {
                throw new Error("convertDigitsFromString error: mapped symbol for '".concat(digit, "' not found."));
            }
            result += map[digit];
        }
        return result;
    };
    OfferPriceCalculations.DOT_SEARCH_REGEXP = /[.]/g;
    OfferPriceCalculations.COMMA_SEARCH_REGEXP = /[,٫]/g;
    OfferPriceCalculations.WHITE_SPACE_SEARCH_REGEXP = /[\s+]/g;
    OfferPriceCalculations.DOT = ".";
    OfferPriceCalculations.COMMA = ",";
    OfferPriceCalculations.WHITE_SPACE = " ";
    OfferPriceCalculations.DECIMAL_DIGITS = 2;
    OfferPriceCalculations.UNICODE_RANGE_STARTS = [
        "\u0030",
        "\u0660",
        "\u06F0",
        "\u07C0",
        "\u0966",
        "\u09E6",
        "\u0A66",
        "\u0AE6",
        "\u0B66",
        "\u0BE6",
        "\u0C66",
        "\u0CE6",
        "\u0D66",
        "\u0DE6",
        "\u0E50",
        "\u0ED0",
        "\u0F20",
        "\u1040",
        "\u1090",
        "\u17E0",
        "\u1810",
        "\u1946",
        "\u19D0",
        "\u1A80",
        "\u1A90",
        "\u1B50",
        "\u1BB0",
        "\u1C40",
        "\u1C50",
        "\uA620",
        "\uA8D0",
        "\uA900",
        "\uA9D0",
        "\uA9F0",
        "\uAA50",
        "\uABF0",
        "\uFF10",
    ];
    return OfferPriceCalculations;
}());
OfferPriceCalculations.prepareSymbols();
