var PromoOfferInfo = (function () {
    function PromoOfferInfo() {
    }
    PromoOfferInfo.getPromoOfferInfo = function (params) {
        var result = PromoOfferInfo.GetClearInfo();
        var offer = offersMap.checkedGet(params.offerId);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(params.playerProgress);
        var restrictedList = { Shards: [], Cards: [], };
        RestrictedList.extendByBlockedByTime(restrictedList, params.startTimeOfCurrentDayMS);
        var AvailableSeparated = HeroUtils.getAvailableSeparatedHeroes(playerProgress, restrictedList);
        var paramsForVariantInfo = {
            playerProgress: playerProgress,
            availableSeparated: AvailableSeparated,
            variant: null,
            serverTime: params.startTimeOfCurrentDayMS,
        };
        offer.lootSlotsIterator(function (variants, placeholder_name, side_name, place_holder_index) {
            if (offer._rules
                && offer._rules[OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION]
                && offer._offerRandomCustomization) {
                for (var _i = 0, _a = offer._offerRandomCustomization; _i < _a.length; _i++) {
                    var randomCustomizationSettings = _a[_i];
                    if (randomCustomizationSettings.place.placeHolder == placeholder_name
                        && randomCustomizationSettings.place.side == side_name
                        && randomCustomizationSettings.place.additionalIndex == place_holder_index) {
                        var availableIds = OffersUtils.getAvailableRandomCustomizations(playerProgress, randomCustomizationSettings);
                        if (availableIds.length != 0) {
                            return;
                        }
                    }
                }
            }
            if (variants.length) {
                paramsForVariantInfo.variant = variants[0];
                var currentInfo = PromoOfferInfo.GetInfoFromVariant(paramsForVariantInfo);
                for (var i = 1; i < variants.length; i++) {
                    paramsForVariantInfo.variant = variants[i];
                    var variantInfo = PromoOfferInfo.GetInfoFromVariant(paramsForVariantInfo);
                    currentInfo = PromoOfferInfo.GetMinimumFromInfos(currentInfo, variantInfo);
                }
                result = PromoOfferInfo.UnionInfo(result, currentInfo);
            }
        });
        if (result.rarities[HERO_RARITY.COMMON]) {
            delete result.rarities[HERO_RARITY.COMMON];
        }
        result.customization = { taunts: [], emoji: [], skins: [], stances: [], weapons: [] };
        return result;
    };
    PromoOfferInfo.GetInfoFromVariant = function (settings) {
        var result = {
            currency: {},
            rarities: {},
            total: 0,
            customization: { taunts: [], emoji: [], skins: [], stances: [], weapons: [] }
        };
        var settingsRewardContent = OffersUtils.getPromoOfferRewardContent(settings.variant.item, settings.playerProgress);
        var lootSets = settingsRewardContent.lootSettings;
        var chestIds = settingsRewardContent.chests;
        if (lootSets && lootSets.AdditionalFixedLoot && !lootSets.AdditionalFixedLoot.isEmpty()) {
            var fixedLoot = lootSets.AdditionalFixedLoot;
            for (var hid in fixedLoot.HeroExp)
                if (fixedLoot.HeroExp.hasOwnProperty(hid)) {
                    var hero = heroesMap.checkedGet(hid);
                    if (!result.rarities[hero.Rarity]) {
                        result.rarities[hero.Rarity] = 0;
                    }
                    result.rarities[hero.Rarity] += fixedLoot.HeroExp[hid];
                    result.total += fixedLoot.HeroExp[hid];
                }
            for (var cur in fixedLoot.Currencies)
                if (fixedLoot.Currencies.hasOwnProperty(cur)) {
                    if (!result.currency[cur]) {
                        result.currency[cur] = 0;
                    }
                    result.currency[cur] += lootSets.AdditionalFixedLoot.Currencies[cur];
                }
            var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
            for (var _i = 0, allCustomizations_1 = allCustomizations; _i < allCustomizations_1.length; _i++) {
                var customizationType = allCustomizations_1[_i];
                var inLoot = CustomizationUtils.getLootIdsContainer(customizationType, fixedLoot);
                var inResult = CustomizationUtils.getPromoInfoCustomizationContainer(customizationType, result);
                var inPlayer = CustomizationUtils.getPlayerIdsContainer(customizationType, settings.playerProgress);
                if (inLoot == undefined || inResult == undefined || inPlayer == undefined) {
                    continue;
                }
                for (var _a = 0, inLoot_1 = inLoot; _a < inLoot_1.length; _a++) {
                    var id = inLoot_1[_a];
                    if (inResult.indexOf(id) == -1 && inPlayer.indexOf(id) == -1) {
                        inResult.push(id);
                    }
                }
            }
        }
        if (lootSets && lootSets.CurrencySlots) {
            for (var cur in lootSets.CurrencySlots)
                if (lootSets.CurrencySlots.hasOwnProperty(cur)) {
                    var minAmount = Infinity;
                    for (var _b = 0, _c = lootSets.CurrencySlots[cur]; _b < _c.length; _b++) {
                        var variant = _c[_b];
                        minAmount = Math.min(variant.Amount.getMin(), minAmount);
                    }
                    if (minAmount == Infinity) {
                        minAmount = 0;
                    }
                    if (!result.currency[cur]) {
                        result.currency[cur] = 0;
                    }
                    result.currency[cur] += minAmount;
                }
        }
        if (lootSets && lootSets.CardsSlots) {
            var slots = 0;
            var currentSettings = LootSettingsConverter.convert(lootSets);
            var cardSlots = LootUtils.getCorrectedCardsSettings({
                cardsSlots: currentSettings.CardsSlots,
                availableSettings: settings.availableSeparated,
            });
            for (var r in cardSlots.Rarities)
                if (cardSlots.Rarities.hasOwnProperty(r)) {
                    var slotSettings = cardSlots.Rarities[r];
                    var cardsWeight = slotSettings.CardsWeight;
                    if (cardsWeight != undefined) {
                        var minAmount = CommonGameUtils.findMinimumFromWeights(cardsWeight);
                        var rarity = +r;
                        if (!result.rarities[rarity]) {
                            result.rarities[rarity] = 0;
                        }
                        result.rarities[rarity] += minAmount;
                        result.total += minAmount;
                        slots += slotSettings.Slots;
                    }
                }
        }
        if (chestIds && chestIds.length > 0) {
            for (var _d = 0, chestIds_1 = chestIds; _d < chestIds_1.length; _d++) {
                var chestId = chestIds_1[_d];
                var chest = chestsMap.checkedGet(chestId);
                var old_values = [
                    chest.showCommonCardsChances,
                    chest.showFixLootChances,
                    chest.showRubiesChances
                ];
                chest.setShowCommonCardsChances(true);
                chest.setShowFixLootChances(true);
                chest.setShowRubiesChances(true);
                var chestInfo = chest.getChestInfo(settings.playerProgress, settings.serverTime);
                chest.setShowCommonCardsChances(old_values[0]);
                chest.setShowFixLootChances(old_values[1]);
                chest.setShowRubiesChances(old_values[2]);
                for (var cur in chestInfo.Currencies)
                    if (chestInfo.Currencies.hasOwnProperty(cur)) {
                        if (!result.currency[cur]) {
                            result.currency[cur] = 0;
                        }
                        result.currency[cur] += chestInfo.Currencies[cur].Min;
                    }
                for (var rarity in chestInfo.Rarities)
                    if (chestInfo.Rarities.hasOwnProperty(rarity)) {
                        if (!result.rarities[rarity]) {
                            result.rarities[rarity] = 0;
                        }
                        result.rarities[rarity] += +chestInfo.Rarities[rarity];
                    }
                result.total += chestInfo.Total;
            }
        }
        return result;
    };
    PromoOfferInfo.GetMinimumFromInfos = function (info1, info2) {
        var result = PromoOfferInfo.GetClearInfo();
        for (var cur in info1.currency)
            if (info2.currency[cur]) {
                result.currency[cur] = Math.min(info1.currency[cur], info2.currency[cur]);
            }
        for (var r in info1.rarities)
            if (info2.rarities[r]) {
                result.rarities[r] = Math.min(info1.rarities[r], info2.rarities[r]);
            }
        for (var cn in result.customization) {
            if (info1.customization[cn] && info2.customization[cn]) {
                for (var _i = 0, _a = info1.customization[cn]; _i < _a.length; _i++) {
                    var id = _a[_i];
                    if (info2.customization[cn].indexOf(id) != -1) {
                        result.customization[cn].push(id);
                    }
                }
            }
        }
        result.total = Math.min(info1.total, info2.total);
        return result;
    };
    PromoOfferInfo.UnionInfo = function (info1, info2) {
        var result = PromoOfferInfo.GetClearInfo();
        for (var _i = 0, _a = [info1, info2]; _i < _a.length; _i++) {
            var info = _a[_i];
            for (var cur in info.currency) {
                if (!result.currency[cur]) {
                    result.currency[cur] = 0;
                }
                result.currency[cur] += info.currency[cur];
            }
            for (var r in info.rarities) {
                if (!result.rarities[r]) {
                    result.rarities[r] = 0;
                }
                result.rarities[r] += info.rarities[r];
            }
            for (var cn in result.customization) {
                if (info.customization[cn]) {
                    for (var _b = 0, _c = info.customization[cn]; _b < _c.length; _b++) {
                        var id = _c[_b];
                        if (result.customization[cn].indexOf(id) == -1) {
                            result.customization[cn].push(id);
                        }
                    }
                }
            }
        }
        return result;
    };
    PromoOfferInfo.GetClearInfo = function () {
        return {
            currency: {},
            rarities: {},
            total: 0,
            customization: { taunts: [], emoji: [], skins: [], stances: [], weapons: [] }
        };
    };
    return PromoOfferInfo;
}());
