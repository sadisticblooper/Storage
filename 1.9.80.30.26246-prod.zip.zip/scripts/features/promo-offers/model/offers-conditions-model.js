var OfferChecker = (function () {
    function OfferChecker() {
    }
    OfferChecker.checkConditionOperand = function (value, operand) {
        return ((operand.equal == undefined || value == operand.equal)
            && (operand.not_equal == undefined || value != operand.not_equal)
            && (operand.more == undefined || value > operand.more)
            && (operand.less == undefined || value < operand.less)
            && (operand.less_or_equal == undefined || value <= operand.less_or_equal)
            && (operand.more_or_equal == undefined || value >= operand.more_or_equal));
    };
    OfferChecker.checkOfferConditions = function (offer, params) {
        var offerConditions = offer._conditions;
        if (offerConditions == undefined) {
            return true;
        }
        for (var conditionName in OfferChecker.checks)
            if (OfferChecker.checks.hasOwnProperty(conditionName)) {
                if (offerConditions.hasOwnProperty(conditionName)) {
                    if (!OfferChecker.checks[conditionName](offerConditions, params)) {
                        return false;
                    }
                }
            }
        return true;
    };
    OfferChecker.checks = {
        accountLevel: function (c, p) {
            return OfferChecker.checkConditionOperand(p.playerProgress.accountLevel, c.accountLevel);
        },
        accountExp: function (c, p) {
            return OfferChecker.checkConditionOperand(p.playerProgress.accountExp, c.accountExp);
        },
        playerRating: function (c, p) {
            return OfferChecker.checkConditionOperand(p.playerProgress.playerRating, c.playerRating);
        },
        heroRating: function (c, p) {
            if (c.heroRating == undefined) {
                return true;
            }
            if (p.heroEventSettings == undefined) {
                return false;
            }
            return OfferChecker.checkConditionOperand(p.heroEventSettings.heroRating, c.heroRating);
        },
        playerArenaId: function (c, p) {
            return OfferChecker.checkConditionOperand(p.playerProgress.playerArenaId, c.playerArenaId);
        },
        heroShards: function (c, p) {
            var shards = Hero
                .extendShards(p.playerProgress.heroShards, p.playerProgress.heroes, p.playerProgress.accountLevel);
            for (var heroID in c.heroShards)
                if (shards[heroID] != undefined) {
                    if (!OfferChecker.checkConditionOperand(shards[heroID], c.heroShards[heroID])) {
                        return false;
                    }
                }
            return true;
        },
        heroShardsSum: function (c, p) {
            for (var heroID in c.heroShardsSum) {
                var heroState = p.playerProgress.heroes[heroID];
                var shardsSum = 0;
                if (heroState == undefined) {
                    shardsSum = p.playerProgress.heroShards[heroID] ? p.playerProgress.heroShards[heroID] : 0;
                }
                else {
                    var hero = heroesMap.checkedGet(heroID);
                    var shardsByTalentLevel = 0;
                    for (var i = 1; i <= heroState.TalentLevel; i++) {
                        shardsByTalentLevel += hero.Talents.tree[i].price;
                    }
                    shardsSum = shardsByTalentLevel + heroState.Duplicates;
                }
                if (!OfferChecker.checkConditionOperand(shardsSum, c.heroShardsSum[heroID])) {
                    return false;
                }
            }
            return true;
        },
        heroCardsSum: function (c, p) {
            for (var heroID in c.heroCardsSum) {
                var heroState = p.playerProgress.heroes[heroID];
                var cardsSum = 0;
                if (heroState != undefined) {
                    var cardsByTalentLevel = 0;
                    for (var i = 1; i < heroState.Level; i++) {
                        var heroLevelUpPrice = HeroUtils.heroLevelUpPrices(i, +heroID);
                        if (heroLevelUpPrice == undefined) {
                            continue;
                        }
                        cardsByTalentLevel += heroLevelUpPrice.exp;
                    }
                    cardsSum = cardsByTalentLevel + heroState.Exp;
                }
                if (!OfferChecker.checkConditionOperand(cardsSum, c.heroCardsSum[heroID])) {
                    return false;
                }
            }
            return true;
        },
        heroes: function (c, p) {
            var heroesInfo = getObjectFromRaw(p.playerProgress.heroes);
            for (var heroID in c.heroes)
                if (heroesInfo[heroID] != undefined) {
                    var heroState = Hero.upLevelIfNecessary(heroesInfo[heroID], +heroID);
                    if (c.heroes[heroID].Level != undefined
                        && !OfferChecker.checkConditionOperand(heroState.Level, c.heroes[heroID].Level)) {
                        return false;
                    }
                    if (c.heroes[heroID].Exp != undefined
                        && !OfferChecker.checkConditionOperand(heroState.Exp, c.heroes[heroID].Exp)) {
                        return false;
                    }
                    if (c.heroes[heroID].TalentLevel != undefined
                        && !OfferChecker.checkConditionOperand(heroState.TalentLevel, c.heroes[heroID].TalentLevel)) {
                        return false;
                    }
                    if (c.heroes[heroID].Duplicates != undefined
                        && !OfferChecker.checkConditionOperand(heroState.Duplicates, c.heroes[heroID].Duplicates)) {
                        return false;
                    }
                }
                else {
                    return false;
                }
            return true;
        },
        heroesOneOfExist: function (c, p) {
            var heroesInfo = getObjectFromRaw(p.playerProgress.heroes);
            for (var _i = 0, _a = c.heroesOneOfExist; _i < _a.length; _i++) {
                var heroID = _a[_i];
                if (heroesInfo[heroID] != undefined) {
                    return true;
                }
            }
            return false;
        },
        countries: function (c, p) {
            var country = p.regionalSettings.countryCode;
            for (var _i = 0, _a = c.countries; _i < _a.length; _i++) {
                var selectedCountry = _a[_i];
                if (selectedCountry == country) {
                    return true;
                }
            }
            return false;
        },
        ignorePlatformVersions: function (c, p) {
            var deviceInfo = p.deviceInfo;
            return !(c.ignorePlatformVersions[deviceInfo.osFamily]
                && c.ignorePlatformVersions[deviceInfo.osFamily].indexOf(deviceInfo.apiLevel) > -1);
        },
        currencies: function (c, p) {
            var playerCurrencies = p.playerProgress.currencies;
            for (var currencyType in c.currencies) {
                if (playerCurrencies[currencyType] == undefined) {
                    return false;
                }
                if (!OfferChecker.checkConditionOperand(playerCurrencies[currencyType], c.currencies[currencyType])) {
                    return false;
                }
            }
            return true;
        },
        paymentCounter: function (c, p) {
            var paymentCounter = p.playerPayments && p.playerPayments.paymentCounter || 0;
            return OfferChecker.checkConditionOperand(paymentCounter, c.paymentCounter);
        },
        createdPlayerTime: function (c, p) {
            return OfferChecker.checkConditionOperand(p.regionalSettings.createdPlayerTime, c.createdPlayerTime);
        },
        fightCounters: function (c, p) {
            var passed = true;
            if (c.fightCounters.total != undefined) {
                var sum = 0;
                for (var mode in p.fightCounters) {
                    sum += p.fightCounters[mode];
                }
                passed = passed && OfferChecker.checkConditionOperand(sum, c.fightCounters.total);
            }
            if (c.fightCounters.modes) {
                for (var mode in c.fightCounters.modes) {
                    if (p.fightCounters[mode] == undefined) {
                        return false;
                    }
                    passed = passed
                        && OfferChecker.checkConditionOperand(p.fightCounters[mode], c.fightCounters.modes[mode]);
                }
            }
            if (c.fightCounters.modesSum) {
                var sum = 0;
                for (var _i = 0, _a = c.fightCounters.modesSum.modes; _i < _a.length; _i++) {
                    var mode = _a[_i];
                    if (p.fightCounters[mode.toString()] != undefined) {
                        sum += +p.fightCounters[mode.toString()];
                    }
                }
                passed = passed
                    && OfferChecker.checkConditionOperand(sum, c.fightCounters.modesSum.total);
            }
            return passed;
        },
        configVersion: function (c, p) {
            var _a;
            if (c.configVersion == undefined) {
                return true;
            }
            if (p.configVersion == undefined) {
                return false;
            }
            var operand = c.configVersion.operand;
            var compareResult = CommonUtils.compareVersions(p.configVersion, c.configVersion.value);
            var conditionOperands = (_a = {}, _a[operand] = 0, _a);
            return OfferChecker.checkConditionOperand(compareResult, conditionOperands);
        },
        accountTagsOneOf: function (c, p) {
            if (c.accountTagsOneOf == undefined) {
                return true;
            }
            if (p.accountTags == undefined) {
                return false;
            }
            return ArrayUtils.getArraysIntersection(c.accountTagsOneOf, p.accountTags).length > 0;
        },
        worlds: function (c, p) {
            if (c.worlds == undefined) {
                return true;
            }
            if (p.world == undefined) {
                return false;
            }
            return c.worlds.map(function (s) { return s.toUpperCase(); }).indexOf(p.world.toUpperCase()) > -1;
        },
    };
    return OfferChecker;
}());
