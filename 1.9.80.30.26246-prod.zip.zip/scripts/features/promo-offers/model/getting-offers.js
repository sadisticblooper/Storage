var GettingItemsLikeOffers = (function () {
    function GettingItemsLikeOffers(map, converter) {
        this._map = map;
        this._converter = converter;
    }
    GettingItemsLikeOffers.prototype.getPromos = function (params_) {
        var params = this._converter.Args(params_);
        CommonUtils.replaceReadOnlyProperty(params, "playerProgress", PlayerState.getCorrectFromRawOrCache(params.playerProgress));
        CommonUtils.replaceReadOnlyProperty(params, "generatedOffers", this.filterGeneratedOffers(params.generatedOffers, params.serverCurrentTime));
        RandomInstance.setSeed(params.seed);
        var _a = this.createInfoByGeneratedPromos(params), offerPoints = _a.offerPoints, generatedExclusiveGroupIds = _a.generatedExclusiveGroupIds, completedPromoIds = _a.completedPromoIds, completedVersusGroupIds = _a.completedVersusGroupIds, completedSaleGroupIdsOneOf = _a.completedSaleGroupIdsOneOf;
        var noPurchasePeriod = params.playerPayments && params.playerPayments.noPurchasePeriodTime || 0;
        var spent = params.playerPayments && params.playerPayments.spent || 0;
        var promoOffersResult = {};
        var dailyPromoOffers = [];
        var isDailyPromoActive = false;
        var offersToForget = [];
        for (var _i = 0, _b = this._map.getKeys(); _i < _b.length; _i++) {
            var offerKeyId = _b[_i];
            var typeItem = this._map.get(offerKeyId);
            var offer = this._converter.Type(typeItem);
            var offerId = offer.ID.toString();
            var generatedOfferInfo = params.generatedOffers[offerId];
            if (offer.isDisabledForGenerating(params.serverCurrentTime)) {
                continue;
            }
            var isTimeToRegenerate = offer.isTimeToRegenerate(params.serverCurrentTime, generatedOfferInfo);
            if (offer._offerType == PROMO_OFFER_TYPE.DAILY
                && generatedOfferInfo != undefined
                && (generatedOfferInfo.expireTime == null || generatedOfferInfo.expireTime > params.serverCurrentTime)) {
                isDailyPromoActive = true;
            }
            var isBattlePassOffer = offer.isBattlePassOffer();
            var isPeriodicalOffer = offer.isPeriodicalOffer();
            var periodEnd = offer.getPeriodEnd(params.serverCurrentTime, params.generatedOffers, params.regionalSettings);
            var offerWasGenerated = generatedOfferInfo != undefined;
            var doForceClose = offerWasGenerated && (offer._forceClose ||
                offer.doCloseAdOffer(generatedOfferInfo, params.serverCurrentTime, params) ||
                offer.doCloseDirectHeroSaleOffer(generatedOfferInfo, params.serverCurrentTime, params.playerProgress) ||
                offer.doCloseOfferInSale(completedSaleGroupIdsOneOf));
            if (doForceClose) {
                var expireTime_1 = params.serverCurrentTime - 3600000;
                var purchaseCount_1 = generatedOfferInfo.purchaseCount || 0;
                promoOffersResult[offerId] = {
                    expireTime: expireTime_1,
                    purchaseCount: purchaseCount_1,
                    seed: generatedOfferInfo.seed,
                };
                continue;
            }
            if (offerWasGenerated) {
                var expireTime_2 = isNumber(generatedOfferInfo.expireTime) && +generatedOfferInfo.expireTime > 0
                    ? +generatedOfferInfo.expireTime
                    : null;
                var isActivePromo = !generatedOfferInfo.purchaseCount
                    && (expireTime_2 == null || expireTime_2 > params.serverCurrentTime);
                var setEndlessTimer = isActivePromo
                    && expireTime_2 != null
                    && offer._activeTime.duration == PROMO_DURATION.ENDLESS;
                if (!isTimeToRegenerate && !isPeriodicalOffer && !setEndlessTimer && !isBattlePassOffer) {
                    continue;
                }
            }
            if (isPeriodicalOffer && periodEnd == 0) {
                continue;
            }
            if (offer._eventAssociatedHeroId) {
                if (params.heroEventSettings == undefined
                    || params.heroEventSettings.heroId != offer._eventAssociatedHeroId) {
                    continue;
                }
            }
            if (offer._checkTutorialPassed && !params.playerProgress.tutorialPassed) {
                continue;
            }
            if (offer._useOfferGroupAsVersus
                && offer._promoOfferGroup && completedVersusGroupIds[offer._promoOfferGroup]) {
                continue;
            }
            if (offer.isAdDisableOffer() && !offer.canAdOfferBeGenerated(params)) {
                continue;
            }
            if (offer._triggers && !offer._triggers[params.trigger]) {
                continue;
            }
            if (offer._crossPromoCompanies) {
                if (!params.regionalSettings.crossPromo || !offer._crossPromoCompanies[params.regionalSettings.crossPromo]) {
                    continue;
                }
            }
            if (offer._companies) {
                if (!params.regionalSettings.companyName || !offer._companies[params.regionalSettings.companyName]) {
                    continue;
                }
            }
            if (offer._firstTimeCompletedTournaments) {
                if (!params.completedTournamentId || !offer._firstTimeCompletedTournaments[params.completedTournamentId]) {
                    continue;
                }
            }
            if (offer._platforms && !offer._platforms[params.regionalSettings.platform]) {
                continue;
            }
            if (offer._country && !offer._country[params.regionalSettings.countryCode]) {
                continue;
            }
            if (offer._ignoreCountry && offer._ignoreCountry[params.regionalSettings.countryCode]) {
                continue;
            }
            if (offer._productGroup && generatedExclusiveGroupIds[offer._productGroup] && !isTimeToRegenerate) {
                continue;
            }
            if (offer._offerPoints) {
                if (offerPoints < offer._offerPoints.min || offerPoints > offer._offerPoints.max) {
                    continue;
                }
            }
            if (offer._marathonProgress) {
                if (params.marathonProgress == undefined) {
                    continue;
                }
                var progressCheck = OfferChecker
                    .checkConditionOperand(params.marathonProgress.progress, offer._marathonProgress.progress);
                var id = params.marathonProgress.marathonId || 0;
                var idCheck = offer._marathonProgress.marathonIds.indexOf(id) > -1;
                if (!progressCheck || !idCheck) {
                    continue;
                }
            }
            if (offer._sp || offer._medianSpent || offer._maxSpent) {
                var maxPayment = params.playerPayments && params.playerPayments.maxPayment || 0;
                var medianPayment = params.playerPayments && params.playerPayments.medianOfRecentPayments || 0;
                var spentConditions = [
                    { value: spent, condition: offer._sp, table: offer._customSpTable || PromoOfferConstants.defaultSpTable },
                    { value: medianPayment, condition: offer._medianSpent, table: PromoOfferConstants.defaultMedianSpentTable },
                    { value: maxPayment, condition: offer._maxSpent, table: PromoOfferConstants.defaultMaxSpentTable },
                ];
                var passed = true;
                for (var _c = 0, spentConditions_1 = spentConditions; _c < spentConditions_1.length; _c++) {
                    var check = spentConditions_1[_c];
                    var value = check.value, condition = check.condition, table = check.table;
                    var cc = params.regionalSettings.countryCode;
                    var actualCondition = offer.getSpentConditionByRegion(cc, condition, table);
                    if (actualCondition) {
                        if (value < actualCondition.min && actualCondition.min != -1
                            || value > actualCondition.max && actualCondition.max != -1) {
                            passed = false;
                            break;
                        }
                    }
                }
                if (!passed) {
                    continue;
                }
            }
            if (offer._idleTime.length == 2) {
                if (spent > 0) {
                    if (noPurchasePeriod < offer._idleTime[0] || noPurchasePeriod > offer._idleTime[1]) {
                        continue;
                    }
                }
                else {
                    if ((params.serverCurrentTime - params.regionalSettings.createdPlayerTime) < offer._idleTime[0] ||
                        (params.serverCurrentTime - params.regionalSettings.createdPlayerTime) > offer._idleTime[1]) {
                        continue;
                    }
                }
            }
            if (offer._timeFromLastLogin) {
                if (offer._timeFromLastLogin >= (params.serverCurrentTime - params.lastLoginTime)) {
                    continue;
                }
            }
            if (offer._timeFromLastLogout) {
                if (!OfferChecker.checkConditionOperand(params.serverCurrentTime - params.lastLogoutTime, offer._timeFromLastLogout)) {
                    continue;
                }
            }
            if (!isTimeToRegenerate
                && (offer._activeTime.startGenerationBound
                    && offer._activeTime.startGenerationBound > params.serverCurrentTime
                    || offer._activeTime.endGenerationBound
                        && offer._activeTime.endGenerationBound < params.serverCurrentTime)) {
                continue;
            }
            if (!offer.isAvailableByRules(params.playerProgress)) {
                continue;
            }
            {
                var checksQuantity = 0;
                var passedChecks = 0;
                if (offer._previousOffers) {
                    checksQuantity++;
                    for (var _d = 0, _e = offer._previousOffers; _d < _e.length; _d++) {
                        var offerId_1 = _e[_d];
                        if (completedPromoIds[offerId_1]) {
                            if (offer._previousOfferMustBeFromPastActiveDay) {
                                if (OffersUtils.isOfferFromPastActiveDay(params.serverCurrentTime, params.generatedOffers[offerId_1], this._map.get(offerId_1))) {
                                    passedChecks++;
                                    break;
                                }
                            }
                            else {
                                passedChecks++;
                                break;
                            }
                        }
                    }
                }
                if (offer._ignoredOffers) {
                    checksQuantity++;
                    for (var _f = 0, _g = offer._ignoredOffers; _f < _g.length; _f++) {
                        var offerId_2 = _g[_f];
                        var generatedOffer = params.generatedOffers[offerId_2];
                        if (generatedOffer != undefined
                            && generatedOffer.purchaseCount == 0
                            && generatedOffer.expireTime != null
                            && generatedOffer.expireTime < params.serverCurrentTime) {
                            passedChecks++;
                            break;
                        }
                    }
                }
                if (checksQuantity > 0) {
                    if (offer._combinePreviousAndIgnoredAsORCondition) {
                        if (passedChecks == 0) {
                            continue;
                        }
                    }
                    else {
                        if (passedChecks != checksQuantity) {
                            continue;
                        }
                    }
                }
            }
            if (offer._notBoughtOffers) {
                var playerDidNotBuyOfferFromList = true;
                for (var _h = 0, _j = offer._notBoughtOffers; _h < _j.length; _h++) {
                    var offerId_3 = _j[_h];
                    if (completedPromoIds[offerId_3]) {
                        playerDidNotBuyOfferFromList = false;
                        break;
                    }
                }
                if (!playerDidNotBuyOfferFromList) {
                    continue;
                }
            }
            if (!offer.checkAnotherSourceOfOffers(params.generatedOffersAnotherSource, params.serverCurrentTime)) {
                continue;
            }
            {
                var noCustomization = offer._noCustomizeExist;
                var customization = offer._customizeExist;
                if (noCustomization || customization) {
                    var passCondition = true;
                    var customizeExistPassed = false;
                    var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
                    for (var _k = 0, allCustomizations_1 = allCustomizations; _k < allCustomizations_1.length; _k++) {
                        var type = allCustomizations_1[_k];
                        var noIds = noCustomization && noCustomization[type];
                        var ids = customization && customization[type];
                        var playerIds = CustomizationUtils.getPlayerIdsContainer(type, params.playerProgress);
                        if (!playerIds) {
                            continue;
                        }
                        if (noIds) {
                            if (ArrayUtils.haveArraysSameElements(noIds, playerIds)) {
                                passCondition = false;
                                break;
                            }
                        }
                        if (ids && !customizeExistPassed) {
                            var intersection = ArrayUtils.getArraysIntersection(ids, playerIds);
                            if (customization.checkOnlyForOneOf) {
                                if (intersection.length > 0) {
                                    customizeExistPassed = true;
                                }
                            }
                            else {
                                if (intersection.length != ids.length) {
                                    passCondition = false;
                                    break;
                                }
                            }
                        }
                    }
                    if ((customization === null || customization === void 0 ? void 0 : customization.checkOnlyForOneOf) && !customizeExistPassed) {
                        passCondition = false;
                    }
                    if (!passCondition) {
                        continue;
                    }
                }
            }
            if (offer._noHeroExist) {
                var heroesInfo = getObjectFromRaw(params.playerProgress.heroes);
                var playerHasHeroFromList = false;
                for (var _l = 0, _m = offer._noHeroExist; _l < _m.length; _l++) {
                    var heroID = _m[_l];
                    if (heroesInfo[heroID] != undefined) {
                        playerHasHeroFromList = true;
                        break;
                    }
                }
                if (playerHasHeroFromList) {
                    continue;
                }
            }
            if (offer._onCombinedHeroes) {
                if (params.trigger != PROMO_TRIGGER_TYPE.COMBINE_HERO) {
                    continue;
                }
                if (!params.heroEventSettings) {
                    continue;
                }
                var heroId = params.heroEventSettings.heroId;
                if (!offer._onCombinedHeroes[heroId]) {
                    continue;
                }
            }
            if (offer._noActiveOffers) {
                var noActiveOffers = 0;
                for (var _o = 0, _p = offer._noActiveOffers; _o < _p.length; _o++) {
                    var offerId_4 = _p[_o];
                    for (var userOfferId in params.generatedOffers) {
                        var generatedOffer = params.generatedOffers[userOfferId];
                        if (userOfferId == offerId_4.toString()
                            && (generatedOffer.expireTime != null
                                && generatedOffer.expireTime <= params.serverCurrentTime
                                || generatedOffer.purchaseCount > 0)) {
                            noActiveOffers++;
                        }
                    }
                }
                if (noActiveOffers != offer._noActiveOffers.length) {
                    continue;
                }
            }
            if (offer._noActiveOffersNow) {
                var offerFromListNotActive = true;
                for (var _q = 0, _r = offer._noActiveOffersNow; _q < _r.length; _q++) {
                    var offerId_5 = _r[_q];
                    var generatedOffer = void 0;
                    if (params.generatedOffers[offerId_5] != undefined) {
                        generatedOffer = params.generatedOffers[offerId_5];
                    }
                    if (promoOffersResult[offerId_5] != undefined) {
                        generatedOffer = promoOffersResult[offerId_5];
                    }
                    if (generatedOffer
                        && generatedOffer.expireTime != null && generatedOffer.expireTime > params.serverCurrentTime
                        && !generatedOffer.purchaseCount) {
                        offerFromListNotActive = false;
                        break;
                    }
                }
                if (!offerFromListNotActive) {
                    continue;
                }
            }
            if (offer._passRoguelikeConditions) {
                var offerConditions = offer._passRoguelikeConditions;
                var paramsSettings = params.passRoguelikeChapterSettings;
                if (!paramsSettings) {
                    continue;
                }
                if (offerConditions.heroId && offerConditions.heroId != paramsSettings.heroId) {
                    continue;
                }
                if (offerConditions.chapterId != paramsSettings.chapterId) {
                    continue;
                }
                if (!OfferChecker.checkConditionOperand(paramsSettings.chapterStars, offerConditions.chapterStars)) {
                    continue;
                }
            }
            if (offer._battlePass) {
                var bpProgress = params.battlePassProgress;
                if (!bpProgress) {
                    continue;
                }
                if (!offer.isBattlePassConditionPassed(bpProgress)) {
                    continue;
                }
                var duration = offer._activeTime.duration;
                if (offerWasGenerated &&
                    !OffersUtils.checkIfBattlePassChanged(bpProgress.BattlePassId, duration, generatedOfferInfo.expireTime)) {
                    continue;
                }
            }
            if (!OfferChecker.checkOfferConditions(offer, params)) {
                continue;
            }
            if (!offer.customConditionPassed(params)) {
                continue;
            }
            var expireTime = 0;
            var purchaseCount = generatedOfferInfo ? generatedOfferInfo.purchaseCount : 0;
            if (offer._activeTime.duration && !isPeriodicalOffer) {
                if (offer._activeTime.duration == PROMO_DURATION.FAST) {
                    expireTime = params.serverCurrentTime + new Time({ Seconds: 10 }).value;
                }
                else if (offer._activeTime.duration == PROMO_DURATION.ENDLESS) {
                    expireTime = null;
                }
                else {
                    expireTime = params.serverCurrentTime + offer._activeTime.duration;
                }
                if (offer._useEndGenerationBoundWithPriority && offer._activeTime.endGenerationBound != undefined) {
                    expireTime = Math.min(expireTime, offer._activeTime.endGenerationBound);
                }
            }
            else {
                if (isPeriodicalOffer) {
                    expireTime = periodEnd;
                    purchaseCount = 0;
                }
                else {
                    if (offer._activeTime.endGenerationBound && offer._activeTime.endGenerationBound > 0) {
                        expireTime = offer._activeTime.endGenerationBound;
                        if (isTimeToRegenerate && generatedOfferInfo &&
                            offer._activeTime.endGenerationBound == generatedOfferInfo.expireTime) {
                            if (offer._activeTime.startGenerationBound && offer._activeTime.startGenerationBound > 0) {
                                expireTime = params.serverCurrentTime + Math.abs(offer._activeTime.endGenerationBound
                                    - offer._activeTime.startGenerationBound);
                            }
                            else {
                                expireTime = params.serverCurrentTime + (offer._regenerationDelay
                                    ? offer._regenerationDelay
                                    : new Time({ Seconds: 10 }).value);
                            }
                        }
                    }
                    else {
                        expireTime = params.serverCurrentTime + new Time({ Seconds: 10 }).value;
                    }
                }
            }
            if (offer._offerType != PROMO_OFFER_TYPE.DAILY) {
                promoOffersResult[offerId] = {
                    expireTime: expireTime,
                    purchaseCount: purchaseCount,
                    seed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
                };
                if (offer._productGroup) {
                    generatedExclusiveGroupIds[offer._productGroup] = true;
                }
            }
            else {
                dailyPromoOffers.push({
                    offerId: offerId,
                    expireTime: expireTime,
                    purchaseCount: purchaseCount,
                    seed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
                });
            }
            offer.updateOffersToForget(offersToForget);
        }
        if (dailyPromoOffers.length > 0 && !isDailyPromoActive) {
            var dailyOffer = dailyPromoOffers[RandomInstance.nextInt(dailyPromoOffers.length)];
            promoOffersResult[dailyOffer.offerId] = {
                expireTime: dailyOffer.expireTime,
                purchaseCount: dailyOffer.purchaseCount,
                seed: dailyOffer.seed,
                universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
            };
        }
        for (var _s = 0, offersToForget_1 = offersToForget; _s < offersToForget_1.length; _s++) {
            var id = offersToForget_1[_s];
            if (params.generatedOffers[id] != undefined && promoOffersResult[id] == undefined) {
                var expireTime = params.generatedOffers[id].expireTime;
                if (expireTime == null || expireTime >= params.serverCurrentTime) {
                    expireTime = params.serverCurrentTime - 10000;
                }
                promoOffersResult[id] = {
                    expireTime: expireTime,
                    purchaseCount: params.generatedOffers[id].purchaseCount,
                    seed: 0,
                    universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.FORGOTTEN,
                };
            }
        }
        var result = this._converter.Result({
            offers: promoOffersResult,
            newOfferPoints: offerPoints,
            newSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
        });
        if (this._converter.FilterResult != undefined) {
            result = this._converter.FilterResult(params_, result);
        }
        return result;
    };
    GettingItemsLikeOffers.prototype.createInfoByGeneratedPromos = function (params) {
        var offerPoints = params.offerPoints;
        var lastCallTime = params.lastFunctionTime;
        var now = params.serverCurrentTime;
        var generatedExclusiveGroupIds = {};
        var completedPromoIds = {};
        var completedVersusGroupIds = {};
        var completedSaleGroupIdsOneOf = {};
        var versusGroupsBlockedForBought = {};
        for (var offerId in params.generatedOffers) {
            var generatedOffer = params.generatedOffers[offerId];
            var typeItem = this._map.get(offerId);
            if (!typeItem) {
                continue;
            }
            var promoOffer = this._converter.Type(typeItem);
            var expireTime = generatedOffer.expireTime;
            var wasPurchase = generatedOffer.purchaseCount > 0;
            var addToGeneratedProductGroups = true;
            if (promoOffer.isPeriodicalOffer() && promoOffer.isPeriodicalOfferFromPreviousPeriod(params)) {
                addToGeneratedProductGroups = false;
                if (promoOffer._promoOfferGroup) {
                    versusGroupsBlockedForBought[promoOffer._promoOfferGroup] = true;
                }
            }
            if (promoOffer._productGroup && addToGeneratedProductGroups) {
                generatedExclusiveGroupIds[promoOffer._productGroup] = true;
            }
            if (wasPurchase) {
                completedPromoIds[+offerId] = true;
                if (promoOffer._useOfferGroupAsVersus
                    && promoOffer._promoOfferGroup
                    && !versusGroupsBlockedForBought[promoOffer._promoOfferGroup]) {
                    completedVersusGroupIds[promoOffer._promoOfferGroup] = true;
                }
                if (promoOffer._saleGroupId) {
                    completedSaleGroupIdsOneOf[promoOffer._saleGroupId] = true;
                }
            }
            if (expireTime != null && expireTime > lastCallTime && expireTime < now && !wasPurchase) {
                offerPoints -= (promoOffer._deltaPoints || 0);
            }
        }
        return {
            offerPoints: offerPoints,
            generatedExclusiveGroupIds: generatedExclusiveGroupIds,
            completedPromoIds: completedPromoIds,
            completedVersusGroupIds: completedVersusGroupIds,
            completedSaleGroupIdsOneOf: completedSaleGroupIdsOneOf,
        };
    };
    GettingItemsLikeOffers.prototype.filterGeneratedOffers = function (generatedOffers, serverTime) {
        var result = {};
        for (var offerId in generatedOffers) {
            var generatedInfo = generatedOffers[offerId];
            if (generatedInfo.universalOfferParameter == PROMO_OFFER_UNIVERSAL_TYPE.FORGOTTEN) {
                continue;
            }
            var typeItem = this._map.get(offerId);
            if (typeItem == undefined) {
                continue;
            }
            var offer = this._converter.Type(typeItem);
            if (offer._onceRepeatAfter && generatedInfo.expireTime <= offer._onceRepeatAfter) {
                continue;
            }
            result[+offerId] = generatedInfo;
        }
        return result;
    };
    return GettingItemsLikeOffers;
}());
