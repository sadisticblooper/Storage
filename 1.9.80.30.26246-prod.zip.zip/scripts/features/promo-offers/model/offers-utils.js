var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var OffersUtils = (function () {
    function OffersUtils() {
    }
    OffersUtils.getPlayerRandomCustomizationParameters = function (playerProgress, type) {
        var result = {
            playerIds: CustomizationUtils.getPlayerIdsContainer(type, playerProgress),
            ids: CustomizationUtils.getAvailableIdsForRandomGenerating(type).slice(),
            map: CustomizationUtils.getOrderMap(type),
        };
        var keys = Object.keys(result);
        var filledKeys = keys.filter(function (k) { return result[k] != undefined; });
        return keys.length == filledKeys.length ? result : null;
    };
    OffersUtils.getAvailableRandomCustomizations = function (playerProgress, randomSettings) {
        var types = ArrayUtils.getUniqueArray(randomSettings.types)
            .sort(function (t1, t2) { return t1 - t2; });
        var result = [];
        for (var _i = 0, types_1 = types; _i < types_1.length; _i++) {
            var type = types_1[_i];
            var settings = OffersUtils.getPlayerRandomCustomizationParameters(playerProgress, type);
            if (!settings) {
                continue;
            }
            var map = settings.map, ids = settings.ids, playerIds = settings.playerIds;
            var rarities = OffersUtils.getCustomizationRaritiesFromRandomSettings(type, randomSettings.rarities);
            var currentIds = [];
            for (var _a = 0, ids_1 = ids; _a < ids_1.length; _a++) {
                var id = ids_1[_a];
                if (playerIds.indexOf(id) == -1) {
                    var customization = map.checkedGet(id);
                    if (randomSettings.generateOnlyForOpenedHeroes) {
                        var isOwnerPresent = true;
                        if (customization.heroOwners != undefined && customization.heroOwners.length > 0) {
                            isOwnerPresent = false;
                            for (var _b = 0, _c = customization.heroOwners; _b < _c.length; _b++) {
                                var ownerId = _c[_b];
                                if (playerProgress.heroes[ownerId] != undefined) {
                                    isOwnerPresent = true;
                                    break;
                                }
                            }
                        }
                        if (!isOwnerPresent) {
                            continue;
                        }
                    }
                    if (rarities.indexOf(customization.rarity) > -1) {
                        if (randomSettings.hero != undefined
                            && customization.heroOwners != undefined
                            && customization.heroOwners.length > 0) {
                            if (customization.heroOwners.indexOf(randomSettings.hero) > -1) {
                                currentIds.push(id);
                            }
                        }
                        else {
                            currentIds.push(id);
                        }
                    }
                }
            }
            if (currentIds.length > 0) {
                result.push({ type: type, ids: currentIds });
            }
        }
        return result;
    };
    OffersUtils.getRandomCustomizationLoot = function (settings) {
        var playerProgress = settings.playerProgress, randomSettings = settings.randomSettings, ri = settings.ri;
        var availablePool = OffersUtils.getAvailableRandomCustomizations(playerProgress, randomSettings);
        if (availablePool.length == 0) {
            return new Loot();
        }
        var typesPool = [];
        for (var type in CUSTOMIZATION)
            if (isNumber(type)) {
                typesPool.push(+type);
            }
        typesPool.sort(function (t1, t2) { return t1 - t2; });
        shuffle(typesPool, ri);
        var randomPoolItem;
        for (var _i = 0, typesPool_1 = typesPool; _i < typesPool_1.length; _i++) {
            var type = typesPool_1[_i];
            for (var _a = 0, availablePool_1 = availablePool; _a < availablePool_1.length; _a++) {
                var element = availablePool_1[_a];
                if (element.type == type) {
                    randomPoolItem = element;
                    break;
                }
            }
            if (randomPoolItem) {
                break;
            }
        }
        var availableIds = randomPoolItem.ids;
        var customizationParameters = OffersUtils.getPlayerRandomCustomizationParameters(playerProgress, randomPoolItem.type);
        if (customizationParameters == null) {
            return new Loot();
        }
        var allIds = customizationParameters.ids;
        allIds.sort(function (id1, id2) { return id1 - id2; });
        shuffle(allIds, ri);
        var lootSettings = {};
        var randomId = availableIds[0];
        for (var _b = 0, allIds_1 = allIds; _b < allIds_1.length; _b++) {
            var id = allIds_1[_b];
            if (availableIds.indexOf(id) > -1) {
                randomId = id;
                break;
            }
        }
        CustomizationUtils.createLootSettings(randomPoolItem.type, lootSettings).push(randomId);
        return new Loot(lootSettings);
    };
    OffersUtils.getPromoOfferRewardContent = function (offersSettings, playerProgress) {
        var arenaNumber = playerProgress.playerArenaId;
        if (offersSettings.arenas != undefined && offersSettings.arenas[arenaNumber] != undefined) {
            return offersSettings.arenas[arenaNumber];
        }
        return offersSettings;
    };
    OffersUtils.getCustomizationRaritiesFromRandomSettings = function (type, customizationRarities) {
        var result = [];
        var raritiesForSearch = CustomizationUtils.getCustomizationRaritiesByCustomize(type);
        result = customizationRarities.filter(function (rarity) { return raritiesForSearch.indexOf(rarity) > -1; });
        result = result.map(function (rarity) { return HeroConstants.customizationRarityMap[rarity]; });
        return result;
    };
    OffersUtils.getOfferIdsFromDictionary = function (dictionary) {
        var result = [];
        for (var name_1 in dictionary) {
            result.push(dictionary[name_1].ID);
        }
        return result;
    };
    OffersUtils.extendPromoWithDisableGenerating = function (disableSince, obj, src, reportConflicts) {
        if (reportConflicts === void 0) { reportConflicts = false; }
        for (var key in src) {
            if (reportConflicts && (key in obj)) {
                throw new Error("extend: key " + key + " present in both sources.");
            }
            if (src.hasOwnProperty(key)) {
                obj[key] = src[key];
                obj[key].setDisableSince(disableSince);
            }
        }
        return obj;
    };
    OffersUtils.getPromoOfferVisualSettings = function (offerId) {
        var offer = offersMap.get(offerId);
        if (!offer) {
            return null;
        }
        var preset = OffersVisualUtils.getVisualPreset(offer._visualPreset);
        var result = OffersUtils.getStructureWithDefaults(OffersVisualUtils.getVisualWithDefaultsByType(preset.offerType), preset);
        if (offer.Discount == null) {
            result.sale.enabled = false;
        }
        return result;
    };
    OffersUtils.getPromoOfferPopUpVisualSettings = function (offerId) {
        var preset = getPromoOfferVisualSettings(offerId);
        if (!preset || !preset.popupVisualPreset) {
            return null;
        }
        return OffersUtils.getStructureWithDefaults(PromoOfferVisualPresets.popUpPresetWithNulls, OffersVisualUtils.getVisualPreset(preset.popupVisualPreset));
    };
    OffersUtils.getStructureWithDefaults = function (sample, structure) {
        if (structure == undefined) {
            return null;
        }
        if (typeof structure != "object" || typeof sample != "object" || sample == null) {
            return structure;
        }
        var result = __assign({}, structure);
        for (var keyName in sample) {
            if (structure[keyName] == undefined) {
                result[keyName] = sample[keyName];
            }
            else {
                if (typeof structure[keyName] == 'object') {
                    if (Array.isArray(structure[keyName])) {
                        var array = structure[keyName];
                        result[keyName] = [];
                        for (var _i = 0, array_1 = array; _i < array_1.length; _i++) {
                            var el = array_1[_i];
                            result[keyName].push(OffersUtils.getStructureWithDefaults(sample[keyName][0], el));
                        }
                    }
                    else {
                        result[keyName] = OffersUtils.getStructureWithDefaults(sample[keyName], structure[keyName]);
                    }
                }
                else {
                    result[keyName] = structure[keyName];
                }
            }
        }
        return result;
    };
    OffersUtils.wasOfferIgnored = function (offerId, settings) {
        var generatedOffer = settings.generatedOffers[offerId];
        return generatedOffer
            && generatedOffer.purchaseCount == 0
            && generatedOffer.expireTime != null
            && generatedOffer.expireTime < settings.serverCurrentTime;
    };
    OffersUtils.wasOfferBought = function (offerId, settings) {
        var generatedOffer = settings.generatedOffers[offerId];
        return generatedOffer
            && generatedOffer.purchaseCount > 0;
    };
    OffersUtils.getAdOfferFromList = function (settings) {
        var offerIds = settings.offerIds;
        var result = null;
        for (var _i = 0, offerIds_1 = offerIds; _i < offerIds_1.length; _i++) {
            var id = offerIds_1[_i];
            var offer = offersMap.get(id);
            if (offer && offer.isAdDisableOffer()) {
                return id;
            }
        }
        return result;
    };
    OffersUtils.doShowAdOfferPopUp = function (settings) {
        var counters = settings.counters, isAdOfferAvailable = settings.isAdOfferAvailable;
        if (!isAdOfferAvailable) {
            return false;
        }
        var adCounterPerSession = counters.adCounterPerSession, sessionCounterPerOfferLifetime = counters.sessionCounterPerOfferLifetime;
        var _a = PromoOfferConstants.adOfferPopUpSchedule, lifetimeOfferShow = _a.lifetimeOfferShow, sessionOfferShow = _a.sessionOfferShow;
        var isSessionForPopUp = false;
        if (isNumber(sessionCounterPerOfferLifetime)
            && sessionCounterPerOfferLifetime >= 0
            && lifetimeOfferShow.length > 0) {
            var stepBuffer = 0;
            for (var i = 0; i < sessionCounterPerOfferLifetime; i++) {
                var index = Math.min(i, lifetimeOfferShow.length - 1);
                stepBuffer += lifetimeOfferShow[index] + 1;
                if (stepBuffer == sessionCounterPerOfferLifetime) {
                    isSessionForPopUp = true;
                    break;
                }
                if (stepBuffer > sessionCounterPerOfferLifetime) {
                    break;
                }
            }
        }
        if (!isSessionForPopUp) {
            return false;
        }
        if (sessionOfferShow.length > 0) {
            var stepBuffer = 0;
            for (var i = 0; i < adCounterPerSession; i++) {
                stepBuffer += (sessionOfferShow[i] || 0);
                if (stepBuffer == adCounterPerSession) {
                    return true;
                }
            }
        }
        return false;
    };
    OffersUtils.updateAdOfferPopUpCounters = function (settings) {
        var currentCounters = settings.currentCounters, isAdOfferAvailable = settings.isAdOfferAvailable, updateEvent = settings.updateEvent, shownPopUpInPreviousCountersUpdate = settings.shownPopUpInPreviousCountersUpdate, shownPopUpInPreviousSession = settings.shownPopUpInPreviousSession, shownAdInPreviousSession = settings.shownAdInPreviousSession;
        var defaultResult = {
            adCounterPerSession: 0,
            sessionCounterPerOfferLifetime: 1,
        };
        if (!isAdOfferAvailable) {
            return defaultResult;
        }
        currentCounters.adCounterPerSession = isNumber(currentCounters.adCounterPerSession)
            && currentCounters.adCounterPerSession >= 0
            ? currentCounters.adCounterPerSession
            : defaultResult.adCounterPerSession;
        currentCounters.sessionCounterPerOfferLifetime = isNumber(currentCounters.sessionCounterPerOfferLifetime)
            && currentCounters.sessionCounterPerOfferLifetime >= 1
            ? currentCounters.sessionCounterPerOfferLifetime
            : defaultResult.sessionCounterPerOfferLifetime;
        var showPopUpOnCurrentCounters = doShowAdOfferPopUp({ counters: currentCounters, isAdOfferAvailable: isAdOfferAvailable });
        switch (updateEvent) {
            case AD_OFFER_COUNTERS_EVENT.AD_OFFER_GENERATED:
                return defaultResult;
            case AD_OFFER_COUNTERS_EVENT.AD_VIEWED:
                if (!showPopUpOnCurrentCounters || shownPopUpInPreviousCountersUpdate) {
                    currentCounters.adCounterPerSession++;
                }
                return currentCounters;
            case AD_OFFER_COUNTERS_EVENT.LOGIN:
                if (!showPopUpOnCurrentCounters && shownAdInPreviousSession || shownPopUpInPreviousSession) {
                    currentCounters.sessionCounterPerOfferLifetime++;
                }
                currentCounters.adCounterPerSession = 0;
                return currentCounters;
            default:
                return currentCounters;
        }
    };
    OffersUtils.isOfferFromPastActiveDay = function (serverCurrentTime, offer, prototype) {
        if (!offer || !prototype) {
            return false;
        }
        var duration = prototype._activeTime.duration;
        if (!(duration && duration > 0)) {
            return false;
        }
        var startActiveDay = new Date(offer.expireTime - duration).setUTCHours(0, 0, 0, 0);
        var nextActiveDay = startActiveDay + new Time({ Days: 1 }).value;
        return serverCurrentTime >= nextActiveDay;
    };
    OffersUtils.getHeroesSalePopupSettingsById = function (settings) {
        var id = settings.id, expireTime = settings.expireTime;
        var isCareGameBuild = CareGameState.getIsCareGameBuild();
        var saleSettings = PromoOfferSaleCreator.salesSettings[id];
        var data = saleSettings && saleSettings.popUp.data;
        if (data && expireTime) {
            data = __assign(__assign({}, data), { endDate: expireTime });
        }
        if (CommonPopUpUtils.breakPopUpForCareGame(data, isCareGameBuild)) {
            return null;
        }
        return data;
    };
    OffersUtils.getHeroesSalePopupVisualSettings = function (saleId) {
        var saleSettings = PromoOfferSaleCreator.salesSettings[saleId];
        return saleSettings && saleSettings.popUp.visual;
    };
    OffersUtils.checkIfBattlePassChanged = function (battlePassId, offerDuration, offerExpireTime) {
        var generatedTime = offerExpireTime - offerDuration;
        var previousBattlePass = BattlePass.getBattlePassByTime(generatedTime);
        if (!previousBattlePass) {
            return true;
        }
        return previousBattlePass.ID != battlePassId;
    };
    OffersUtils.createSameOffers = function (settings) {
        var prototype = settings.prototype, children = settings.children, useAutoDayInChild = settings.useAutoDayInChild;
        var result = {};
        var parentActiveTime = prototype.settings.activeTime;
        var dayDuration = new Time({ Days: 1 }).value;
        var ids = [];
        useAutoDayInChild = useAutoDayInChild === true && parentActiveTime.endGenerationBound != undefined;
        for (var name_2 in children) {
            ids.push(children[name_2].ID);
        }
        ids.sort(function (a, b) { return a - b; });
        result[prototype.name] = new PromoOffer(prototype.settings);
        for (var name_3 in children) {
            if (result[name_3] != undefined) {
                throw new Error("createSameOffers: you are trying to add offers with same name "
                    + "in parent '".concat(prototype.name, "'"));
            }
            var child = children[name_3];
            var childActiveTime = parentActiveTime;
            if (useAutoDayInChild) {
                var position = ids.indexOf(child.ID);
                childActiveTime = {
                    startGenerationBound: parentActiveTime.endGenerationBound + dayDuration * position,
                    endGenerationBound: parentActiveTime.endGenerationBound + dayDuration * (position + 1),
                };
            }
            result[name_3] = new PromoOffer(__assign(__assign(__assign({}, prototype.settings), { activeTime: childActiveTime }), child));
        }
        return result;
    };
    OffersUtils.createSamePromoOfferSettings = function (settings) {
        var prototype = settings.prototype, children = settings.children;
        var result = [{ common: prototype }];
        for (var _i = 0, children_1 = children; _i < children_1.length; _i++) {
            var child = children_1[_i];
            result.push({
                common: __assign(__assign({}, prototype), child.child)
            });
        }
        return result;
    };
    OffersUtils.repeatPromoOfferSettings = function (offers, repeats) {
        var result = offers.slice();
        for (var i = 0; i < repeats - 1; i++) {
            result = result.concat(offers);
        }
        return result;
    };
    OffersUtils.doShowTodaySalePopUp = function (settings) {
        var currentServerTime = settings.currentServerTime, expireTime = settings.expireTime, saleId = settings.saleId;
        if (expireTime == undefined) {
            return true;
        }
        var sale = PromoOfferSaleCreator.getSaleSettingsById(saleId);
        if (!sale) {
            return false;
        }
        var duration = sale.activeTime.duration;
        if (duration == undefined) {
            if (sale.activeTime.startGenerationBound == sale.activeTime.endGenerationBound) {
                return true;
            }
            duration = Math.max(0, sale.activeTime.endGenerationBound - sale.activeTime.startGenerationBound);
        }
        return true;
    };
    OffersUtils.updateSellHeroesSettings = function (entitySettings, entityId) {
        if (!entitySettings) {
            return;
        }
        if (!entitySettings.heroId || !entitySettings.sortingWeight) {
            throwDebugOrReturnDefault("hero id or sorting order in ".concat(entityId, " promo offer equals zero or undefined:\n                \nparams: ").concat(JSON.stringify(entitySettings)));
        }
        var container;
        switch (entitySettings.sellingPromoType) {
            case GAME_ENTITY.OFFER:
                container = SellSettings.heroesSellSettings[entitySettings.heroId].offers;
                break;
            case GAME_ENTITY.ROULETTE:
                container = SellSettings.heroesSellSettings[entitySettings.heroId].roulette;
                break;
            case GAME_ENTITY.GACHA:
                container = SellSettings.heroesSellSettings[entitySettings.heroId].gacha;
                break;
            case GAME_ENTITY.MARATHON:
                container = SellSettings.heroesSellSettings[entitySettings.heroId].marathons;
                break;
            default:
                throwDebugOrReturnDefault("invalid ".concat(entitySettings.sellingPromoType, " type in ").concat(entitySettings, "\n                    \rpromo offer"));
        }
        for (var _i = 0, container_1 = container; _i < container_1.length; _i++) {
            var el = container_1[_i];
            if (el.id == entityId) {
                return;
            }
        }
        container.push({ id: entityId, sortWeight: entitySettings.sortingWeight });
    };
    return OffersUtils;
}());
