var PromoOfferSaleCreator = (function () {
    function PromoOfferSaleCreator() {
    }
    PromoOfferSaleCreator.create = function (settings) {
        var _a;
        var closeSaleAfterOnePurchase = !!settings.closeSaleAfterOnePurchase;
        var offers = [];
        var result = {};
        for (var _i = 0, _b = settings.items; _i < _b.length; _i++) {
            var item = _b[_i];
            var name_1 = "sale_".concat(settings.saleId, "_offer_").concat(item.offerId);
            var hero = heroesMap.checkedGet(item.heroId);
            offers.push(item.offerId);
            result[name_1] = new PromoOffer({
                ID: item.offerId,
                visualPresetId: item.visualPresetId,
                offerNameAlias: item.offerNameAlias,
                inApp: item.inApp,
                price: item.price,
                profit: item.profit || settings.profit,
                discount: item.discount || settings.discount,
                activeTime: settings.activeTime,
                conditions: {},
                saleGroupId: settings.saleId,
                directSaleForHeroId: hero.ID,
                noHeroExist: [hero.ID],
                sellHeroSettings: { sortingWeight: 1, sellingPromoType: GAME_ENTITY.OFFER, heroId: hero.ID },
                enablePopup: false,
                offerType: PROMO_OFFER_TYPE.STATIC,
                hiddenOffer: true,
                lootSettings: {
                    additionalPlaceHolder: [
                        {
                            front: [{ weight: 1, item: { lootSettings: {
                                            AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[hero.ID] = hero.ShardsNeeded, _a) })
                                        } } }],
                        },
                    ]
                },
            });
        }
        PromoOfferSaleCreator
            .addSale(settings.saleId, {
            offers: offers,
            closeSaleAfterOnePurchase: closeSaleAfterOnePurchase,
            popUp: settings.popUp,
            activeTime: settings.activeTime,
        });
        return result;
    };
    PromoOfferSaleCreator.getSaleSettingsById = function (saleId) {
        return PromoOfferSaleCreator.salesSettings[saleId];
    };
    PromoOfferSaleCreator.addSale = function (id, sale) {
        if (PromoOfferSaleCreator.salesSettings[id] != undefined) {
            throw new Error("PromoOfferSaleCreator error: can't add same sale with ID ".concat(id));
        }
        PromoOfferSaleCreator.salesSettings[id] = sale;
    };
    PromoOfferSaleCreator.salesSettings = {};
    return PromoOfferSaleCreator;
}());
