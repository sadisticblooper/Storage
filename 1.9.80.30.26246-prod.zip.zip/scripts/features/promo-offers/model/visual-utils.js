var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var OffersVisualUtils = (function () {
    function OffersVisualUtils() {
    }
    OffersVisualUtils.getVisualPreset = function (name) {
        return PromoOfferVisualPresets.templates[name] || PromoOfferVisualPresets.presets[name];
    };
    OffersVisualUtils.createCopyVisualWithReplace = function (original, copy) {
        return __assign(__assign({}, original), copy);
    };
    OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias = function (original, path, characterAlias) {
        var typedOriginal = original;
        var mainImage = typedOriginal.mainImage
            ? __assign(__assign({}, typedOriginal.mainImage), { sprite: path }) : { enabled: true, sprite: path };
        var visualUpdates = { mainImage: mainImage };
        if (characterAlias !== undefined) {
            var characterText = typedOriginal.characterText
                ? __assign(__assign({}, typedOriginal.characterText), { title: characterAlias }) : {
                enabled: true,
                glowColor: "#8cbaff00",
                subGlowColor: "#8cbaff00",
                title: characterAlias,
                subtitle: "empty",
                titleColor: "#FFFFFFFF",
                subTitleColor: "#8CBAFFFF"
            };
            visualUpdates.characterText = characterText;
        }
        return OffersVisualUtils.createCopyVisualWithReplace(original, visualUpdates);
    };
    OffersVisualUtils.getVisualWithDefaultsByType = function (type) {
        var result = __assign({}, PromoOfferVisualPresets.presetWithDefaults);
        switch (type) {
            case OFFER_PREFAB_TYPE.OfferSmall:
                result.mainImage = null;
                result.effectImage = null;
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                break;
            case OFFER_PREFAB_TYPE.OfferCareGame:
                result.mainImage = { enabled: false, color: null, sprite: null };
                result.effectImage = { enabled: true, color: null, type: null };
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                break;
            case OFFER_PREFAB_TYPE.ArenaOffer:
                result.mainImage = { enabled: false, color: null, sprite: null };
                result.effectImage = null;
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                break;
            case OFFER_PREFAB_TYPE.OfferBig:
                result.mainImage = { enabled: false, color: null, sprite: null };
                result.effectImage = { enabled: false, color: null, type: null };
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                result.labelValue = { enabled: false, glowColor: null, subGlowColor: null, title: null };
                break;
            case OFFER_PREFAB_TYPE.VersusCutOffer:
                result.mainImage = null;
                result.effectImage = null;
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: false, color: null, sprite: null };
                break;
            case OFFER_PREFAB_TYPE.ChampionPackOffer:
                result.mainImage = null;
                result.effectImage = { enabled: true, color: null, type: null };
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                break;
            case OFFER_PREFAB_TYPE.OfferNoAds:
                result.mainImage = null;
                result.effectImage = { enabled: true, color: null, type: null };
                result.bgImage = { enabled: true, color: null, sprite: null };
                result.bgImagePattern = { enabled: true, color: null, sprite: null };
                break;
        }
        return result;
    };
    return OffersVisualUtils;
}());
