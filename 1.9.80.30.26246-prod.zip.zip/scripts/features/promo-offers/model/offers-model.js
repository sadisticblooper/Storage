var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var PromoOffer = (function (_super) {
    __extends(PromoOffer, _super);
    function PromoOffer(js) {
        var _this = _super.call(this) || this;
        _this._promoOfferSettings = js;
        _this._ID = js.ID;
        _this._offerNameAlias = js.offerNameAlias;
        _this._lootSettings = js.lootSettings;
        _this._hiddenOffer = getValueByKeyDefault(js, "hiddenOffer", false);
        _this._offerType = js.offerType;
        _this._price = getValueByKeyDefault(js, "price", {});
        _this._profit = getValueByKeyDefault(js, "profit", 1);
        _this._in_app = getValueByKeyDefault(js, "inApp", null);
        _this._disableRegionalPrices = getValueByKeyDefault(js, "disableRegionalPrices", false);
        _this._discount = getValueByKeyDefault(js, "discount", null);
        _this._idleTime = getValueByKeyDefault(js, "idleTime", []);
        _this._visualPreset = getValueByKeyDefault(js, "visualPresetId", null);
        _this._sortingOrder = getValueByKeyDefault(js, "sortingOrder", 0);
        _this._promoOfferGroup = getValueByKeyDefault(js, "promoOfferGroup", null);
        _this._useOfferGroupAsVersus = _this._promoOfferGroup !== null;
        _this._enablePopup = getValueByKeyDefault(js, "enablePopup", true);
        _this._activeTime = getValueByKeyDefault(js, "activeTime", { startGenerationBound: null, endGenerationBound: null, duration: null });
        PromoOffer.setField(_this, "_disableGeneratingSince", js.disableGeneratingSince);
        PromoOffer.setField(_this, "_conditions", js.conditions);
        PromoOffer.setField(_this, "_customCondition", js.customCondition);
        PromoOffer.setField(_this, "_rules", CommonUtils.getBooleanMapFromArray(js.rules));
        PromoOffer.setField(_this, "_triggers", CommonUtils.getBooleanMapFromArray(js.triggers));
        PromoOffer.setField(_this, "_platforms", CommonUtils.getBooleanMapFromArray(js.platforms));
        PromoOffer.setField(_this, "_country", CommonUtils.getBooleanMapFromArray(js.country));
        PromoOffer.setField(_this, "_ignoreCountry", CommonUtils.getBooleanMapFromArray(js.ignoredCountry));
        PromoOffer.setField(_this, "_timeFromLastLogin", js.timeFromLastLogin);
        PromoOffer.setField(_this, "_timeFromLastLogout", js.timeFromLastLogout);
        PromoOffer.setField(_this, "_productGroup", js.productGroup);
        PromoOffer.setField(_this, "_saleGroupId", js.saleGroupId);
        PromoOffer.setField(_this, "_directSaleForHeroId", js.directSaleForHeroId);
        PromoOffer.setField(_this, "_previousOffers", js.previousOffers);
        PromoOffer.setField(_this, "_ignoredOffers", js.ignoredOffers);
        PromoOffer.setField(_this, "_checkForOffersFromAnotherSource", js.checkForOffersFromAnotherSource);
        PromoOffer.setField(_this, "_possibleCharacterRarities", CommonUtils.getBooleanMapFromArray(js.possibleCharacterRarities));
        PromoOffer.setField(_this, "_notBoughtOffers", js.notBoughtOffers);
        PromoOffer.setField(_this, "_noActiveOffers", js.noActiveOffers);
        PromoOffer.setField(_this, "_noActiveOffersNow", js.noActiveOffersNow);
        PromoOffer.setField(_this, "_noCustomizeExist", js.noCustomizeExist);
        PromoOffer.setField(_this, "_customizeExist", js.customizeExist);
        PromoOffer.setField(_this, "_noHeroExist", js.noHeroExist);
        PromoOffer.setField(_this, "_useEndGenerationBoundWithPriority", js.useEndGenerationBoundWithPriority);
        PromoOffer.setField(_this, "_sp", js.sp);
        PromoOffer.setField(_this, "_customSpTable", js.customSpTable);
        PromoOffer.setField(_this, "_medianSpent", js.medianSpent);
        PromoOffer.setField(_this, "_maxSpent", js.maxSpent);
        PromoOffer.setField(_this, "_offerPoints", js.offerPoints);
        PromoOffer.setField(_this, "_deltaPoints", js.deltaPoints);
        PromoOffer.setField(_this, "_benefit", js.benefit);
        PromoOffer.setField(_this, "_popupSettings", js.popupSettings);
        PromoOffer.setField(_this, "_regenerationDelay", js.regenerationDelay);
        PromoOffer.setField(_this, "_dailySettings", js.dailySettings);
        PromoOffer.setField(_this, "_weeklySettings", js.weeklySettings);
        PromoOffer.setField(_this, "_everyDayOffer", js.everyDayOffer);
        PromoOffer.setField(_this, "_offerRandomCustomization", js.offerRandomCustomization);
        PromoOffer.setField(_this, "_isStarterPack", js.isStarterPack);
        PromoOffer.setField(_this, "_passRoguelikeConditions", js.passRoguelikeConditions);
        PromoOffer.setField(_this, "_autoRepeatAfter", js.autoRepeatAfter);
        PromoOffer.setField(_this, "_onceRepeatAfter", js.onceRepeatAfter || (_this._autoRepeatAfter && _this._activeTime.startGenerationBound));
        PromoOffer.setField(_this, "_smallBadgeVisual", js.smallBadgeVisual);
        PromoOffer.setField(_this, "_crossPromoCompanies", CommonUtils.getBooleanMapFromArray(js.crossPromoCompanies));
        PromoOffer.setField(_this, "_companies", CommonUtils.getBooleanMapFromArray(js.companies));
        PromoOffer.setField(_this, "_battlePass", js.battlePass);
        _this.createAdditionalSettings(js.additionalSettings);
        PromoOffer.setField(_this, "_tryRegenerateOfferAfterBought", js.tryRegenerateOfferAfterBought);
        PromoOffer.setField(_this, "_firstTimeCompletedTournaments", CommonUtils.getBooleanMapFromArray(js.firstTimeCompletedTournaments));
        PromoOffer.setField(_this, "_combinePreviousAndIgnoredAsORCondition", js.combinePreviousAndIgnoredAsORCondition);
        PromoOffer.setField(_this, "_previousOfferMustBeFromPastActiveDay", js.previousOfferMustBeFromPastActiveDay);
        PromoOffer.setField(_this, "_forgetOffers", js.forgetOffers);
        PromoOffer.setField(_this, "_checkTutorialPassed", js.checkTutorialPassed);
        PromoOffer.setField(_this, "_eventAssociatedHeroId", js.eventAssociatedHeroId);
        PromoOffer.setField(_this, "_marathonProgress", js.marathonProgress);
        PromoOffer.setField(_this, "_onCombinedHeroes", CommonUtils.getBooleanMapFromArray(js.onCombinedHeroes));
        PromoOffer.setField(_this, "_forceClose", js.forceClose);
        if (js.sellHeroSettings) {
            _this.addPromoOfferToSellHeroesSettings(js.sellHeroSettings);
        }
        return _this;
    }
    Object.defineProperty(PromoOffer.prototype, "ID", {
        get: function () { return this._ID; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "Benefit", {
        get: function () { return this._benefit !== undefined ? this._benefit : null; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "Profit", {
        get: function () { return this._profit; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "SortingOrder", {
        get: function () { return this._sortingOrder; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "PromoOfferGroup", {
        get: function () { return this._promoOfferGroup; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "UseOfferGroupAsVersus", {
        get: function () { return this._useOfferGroupAsVersus; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "price", {
        get: function () { return this._price; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "SlotsLoot", {
        get: function () { return this._slotsLoot; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "InApp", {
        get: function () { return this._in_app; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "OfferNameAlias", {
        get: function () { return this._offerNameAlias; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "Discount", {
        get: function () { return this._discount; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "PopUpSettings", {
        get: function () { return this._popupSettings !== undefined ? this._popupSettings : null; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "additionalSettings", {
        get: function () { return this._additionalSettings; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "IsStarterPack", {
        get: function () { return !!this._isStarterPack; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PromoOffer.prototype, "IsHiddenOffer", {
        get: function () { return this._hiddenOffer; },
        enumerable: false,
        configurable: true
    });
    PromoOffer.prototype.check = function (checkFlags) {
        var _this = this;
        if (checkFlags === void 0) { checkFlags = {}; }
        var activeTime = this._activeTime;
        if (this._autoRepeatAfter && !this._onceRepeatAfter) {
            throw new Error("AutoRepeatAfter is true, but onceRepeatAfter is null. Promo ".concat(this.ID, "."));
        }
        if (!this._price && !this._in_app) {
            throw new Error("There is no gamePrice/inAppPrice in offer with id " + this._ID);
        }
        if (this._dailySettings != null && this._weeklySettings != null) {
            throw new Error("Can't create offer ".concat(this.ID, " with both settings: dailySettings and weeklySettings"));
        }
        if (this._dailySettings) {
            if (this._dailySettings.day == undefined && this._dailySettings.queueFor == undefined) {
                throw new Error("Can't create offer ".concat(this.ID, " with empty dailySettings"));
            }
        }
        if (this._weeklySettings) {
            var _a = this._weeklySettings, startByOfferEarliestExpired = _a.startByOfferEarliestExpired, startDate = _a.startDate, startDateFunction = _a.startDateFunction, period = _a.period, activeDay = _a.activeDay, endDate = _a.endDate;
            if (period <= 0) {
                throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings. Period <= 0"));
            }
            if (activeDay <= 0 || activeDay > period) {
                throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings. Incorrect activeDay"));
            }
            if (endDate && !CommonUtils.checkDateCentury(21, endDate)) {
                throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings: check endDate ").concat(endDate));
            }
            if (endDate && startDate && endDate <= startDate) {
                throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings: endDate must be after startDate"));
            }
            var oneOfExists = +(startByOfferEarliestExpired != undefined)
                + +(startDate != undefined)
                + +(startDateFunction != undefined) == 1;
            if (!oneOfExists) {
                throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings. You must use only one ")
                    + "of this params: startDate OR startByOfferEarliestExpired OR startDateFunction");
            }
            if (startByOfferEarliestExpired) {
                if (startByOfferEarliestExpired.length == 0) {
                    throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings. startByOfferEarliestExpired ")
                        + "is empty");
                }
                for (var _i = 0, startByOfferEarliestExpired_1 = startByOfferEarliestExpired; _i < startByOfferEarliestExpired_1.length; _i++) {
                    var offerId = startByOfferEarliestExpired_1[_i];
                    if (!offersMap.get(offerId)) {
                        throw new Error("Can't create offer ".concat(this.ID, " with weeklySettings. startByOfferEarliestExpired ")
                            + "has offer ".concat(offerId, " which doesnt exist"));
                    }
                }
            }
        }
        if (this._everyDayOffer) {
            if (this._activeTime.startGenerationBound == undefined || this._activeTime.endGenerationBound == undefined) {
                throw new Error("Can't create offer ".concat(this.ID, " with 'everyDayOffer':")
                    + "you have to set startGenerationBound AND endGenerationBound");
            }
        }
        if (this._visualPreset) {
            var preset = OffersVisualUtils.getVisualPreset(this._visualPreset);
            if (!preset) {
                throw new Error("Can't find visual preset ".concat(this._visualPreset, " for offer ").concat(this.ID));
            }
            if (preset.popupVisualPreset && OffersVisualUtils.getVisualPreset(preset.popupVisualPreset) == undefined) {
                throw new Error("Can't find visual preset ".concat(this._visualPreset, " for popup for offer ").concat(this.ID));
            }
        }
        if (this._battlePass && this._battlePass.battlePassId == undefined) {
            if (!activeTime || !isNumber(activeTime.duration) || activeTime.duration <= 0) {
                throw new Error("Can't create battle pass offer ".concat(this.ID, " without id condition or duration in ms"));
            }
        }
        if (activeTime.startGenerationBound && !CommonUtils.checkDateCentury(21, activeTime.startGenerationBound)) {
            throw new Error("Can't create offer ".concat(this.ID, ": check startGenerationBound ").concat(activeTime.startGenerationBound));
        }
        if (activeTime.endGenerationBound && !CommonUtils.checkDateCentury(21, activeTime.endGenerationBound)) {
            throw new Error("Can't create offer ".concat(this.ID, ": check endGenerationBound ").concat(activeTime.endGenerationBound));
        }
        if (this._rules && this._rules[OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION] && !this._offerRandomCustomization) {
            throw new Error("Can't create offer ".concat(this.ID, ": check 'offerRandomCustomization' with rule RANDOM_CUSTOMIZATION"));
        }
        if (!checkFlags.skipEmptyLootCheck) {
            var isRewardContentHasEmptyLoot_1 = function (rewardContent) {
                if (rewardContent.loot && rewardContent.loot.isEmpty()) {
                    return true;
                }
                return Boolean(rewardContent.lootSettings
                    && rewardContent.lootSettings.AdditionalFixedLoot
                    && rewardContent.lootSettings.AdditionalFixedLoot.isEmpty());
            };
            this.lootSlotsIterator(function (variants, placeHolderName, sideName, placeHolderIndex) {
                for (var _i = 0, variants_1 = variants; _i < variants_1.length; _i++) {
                    var variant = variants_1[_i];
                    if (isRewardContentHasEmptyLoot_1(variant.item)) {
                        throw new Error("Empty reward in offer ".concat(_this.ID, ": ")
                            + "".concat(placeHolderName, ", ").concat(sideName, ", ").concat(placeHolderIndex));
                    }
                    if (variant.item.arenas) {
                        for (var arena in variant.item.arenas) {
                            if (isRewardContentHasEmptyLoot_1(variant.item.arenas[arena])) {
                                throw new Error("Empty reward in offer ".concat(_this.ID, " on arena ").concat(arena, ": ")
                                    + "".concat(placeHolderName, ", ").concat(sideName, ", ").concat(placeHolderIndex));
                            }
                        }
                    }
                }
            });
        }
    };
    PromoOffer.prototype.checkVisual = function (heroNames) {
        var _a, _b;
        if (this._hiddenOffer)
            return;
        var preset = OffersVisualUtils.getVisualPreset(this._visualPreset);
        var needToCheckName = heroNames[this.OfferNameAlias] === 1;
        var needToCheckText = ((_a = preset.characterText) === null || _a === void 0 ? void 0 : _a.enabled) && heroNames[preset.characterText.title] === 1;
        var needToCheckImage = (_b = preset.mainImage) === null || _b === void 0 ? void 0 : _b.enabled;
        if (!needToCheckName && !needToCheckText && !needToCheckImage) {
            return;
        }
        var heroIDsFromCardsAndShards = this.getIDsFromLootSettings(LootUtils.getHeroIDsFromCardsAndShards);
        var heroIDsFromCustomizations = this.getIDsFromLootSettings(LootUtils.getHeroIDsFromCustomizations);
        var allHeroIDs = __spreadArray(__spreadArray([], heroIDsFromCardsAndShards, true), heroIDsFromCustomizations, true);
        var skinsIDs = this.getIDsFromLootSettings(LootUtils.getSkinsFromRewardContents);
        if (needToCheckName) {
            var hasHeroWithThatName = false;
            for (var _i = 0, allHeroIDs_1 = allHeroIDs; _i < allHeroIDs_1.length; _i++) {
                var id = allHeroIDs_1[_i];
                var hero = heroesMap.checkedGet(id);
                if (hero.Alias === this.OfferNameAlias) {
                    hasHeroWithThatName = true;
                    break;
                }
            }
            if (!hasHeroWithThatName) {
                throw new Error("offer ".concat(this.ID, " doesn't contain loot from hero mentioned in its name"));
            }
        }
        if (needToCheckText) {
            var hasHeroWithThatName = false;
            for (var _c = 0, allHeroIDs_2 = allHeroIDs; _c < allHeroIDs_2.length; _c++) {
                var id = allHeroIDs_2[_c];
                var hero = heroesMap.checkedGet(id);
                if (hero.Alias === preset.characterText.title) {
                    hasHeroWithThatName = true;
                    break;
                }
            }
            if (!hasHeroWithThatName) {
                throw new Error("offer ".concat(this.ID, " doesn't contain loot from hero mentioned in its text"));
            }
        }
        var pathToHeroImages = 'Sprites/PreviewImages/Heroes/';
        if (needToCheckImage) {
            var image = preset.mainImage.sprite.replace(pathToHeroImages, "");
            var skinOnImage = void 0;
            var heroOnImage = void 0;
            var isDefaultSkinOnImage = void 0;
            for (var skinName in skins) {
                var skin = skins[skinName];
                if (image === skin.RoguelikeAvatar) {
                    skinOnImage = skin.ID;
                    heroOnImage = skin.OwnerHeroID;
                    isDefaultSkinOnImage = skin.IsDefault;
                }
            }
            if (skinOnImage !== undefined && !isDefaultSkinOnImage && skinsIDs.indexOf(skinOnImage) === -1) {
                throw new Error("offer ".concat(this.ID, ": there is no skin in reward or it doesn't match image"));
            }
            if (isDefaultSkinOnImage && allHeroIDs.indexOf(heroOnImage) === -1) {
                throw new Error("offer ".concat(this.ID, ": hero image differs from rewards"));
            }
            var imageName = image.split("/").pop();
            var heroMentionedInImageName = HeroUtils.getHeroIDFromString(imageName);
            if (heroMentionedInImageName && allHeroIDs.indexOf(heroMentionedInImageName) === -1) {
                throw new Error("offer ".concat(this.ID, ": hero mentioned in image name is not in rewards"));
            }
        }
    };
    PromoOffer.prototype.getIDsFromLootSettings = function (filterFunction) {
        var IDsInLoot = [];
        this.lootSlotsIterator(function (variants, placeHolderName, sideName, placeHolderIndex) {
            for (var _i = 0, variants_2 = variants; _i < variants_2.length; _i++) {
                var variant = variants_2[_i];
                IDsInLoot.push.apply(IDsInLoot, filterFunction(variant.item));
                if (variant.item.arenas) {
                    for (var arena in variant.item.arenas) {
                        IDsInLoot.push.apply(IDsInLoot, filterFunction(variant.item.arenas[arena]));
                    }
                }
            }
        });
        return IDsInLoot;
    };
    PromoOffer.prototype.getSkinsFromLootSettings = function () {
        var skinsInLoot = [];
        this.lootSlotsIterator(function (variants, placeHolderName, sideName, placeHolderIndex) {
            for (var _i = 0, variants_3 = variants; _i < variants_3.length; _i++) {
                var variant = variants_3[_i];
                skinsInLoot.push.apply(skinsInLoot, LootUtils.getSkinsFromRewardContents(variant.item));
                if (variant.item.arenas) {
                    for (var arena in variant.item.arenas) {
                        skinsInLoot.push.apply(skinsInLoot, LootUtils.getSkinsFromRewardContents(variant.item.arenas[arena]));
                    }
                }
            }
        });
        return skinsInLoot;
    };
    PromoOffer.prototype.isAvailableByRules = function (playerProgress) {
        if (this._rules && this._rules[OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION] && this._offerRandomCustomization) {
            if (this._offerRandomCustomization.length > 0) {
                for (var _i = 0, _a = this._offerRandomCustomization; _i < _a.length; _i++) {
                    var randomCustomizationSettings = _a[_i];
                    var pool = OffersUtils
                        .getAvailableRandomCustomizations(playerProgress, randomCustomizationSettings);
                    if (pool.length > 0) {
                        return true;
                    }
                }
                return false;
            }
        }
        return true;
    };
    PromoOffer.prototype.lootSlotsIterator = function (callback) {
        var placeholderNames = ['mainPlaceHolder', 'additionalPlaceHolder'];
        var sideNames = ['front', 'back'];
        for (var _i = 0, placeholderNames_1 = placeholderNames; _i < placeholderNames_1.length; _i++) {
            var placeholderName = placeholderNames_1[_i];
            if (this._lootSettings[placeholderName]) {
                var sideSettingsArray = placeholderName == "mainPlaceHolder"
                    ? [this._lootSettings.mainPlaceHolder]
                    : this._lootSettings.additionalPlaceHolder;
                for (var index = 0; index < sideSettingsArray.length; index++) {
                    var sideSettings = sideSettingsArray[index];
                    for (var _a = 0, sideNames_1 = sideNames; _a < sideNames_1.length; _a++) {
                        var sideName = sideNames_1[_a];
                        if (sideSettings[sideName]) {
                            var promoOfferLootVariants = sideSettings[sideName];
                            callback(promoOfferLootVariants, placeholderName, sideName, index);
                        }
                    }
                }
            }
        }
    };
    PromoOffer.prototype.clearSlotsLoot = function () {
        this._loot = new Loot();
        this._chests = [];
        this._slotsLoot = {
            additionalPlaceHolder: []
        };
    };
    PromoOffer.prototype.getVisualForSmallLobbyBadge = function () {
        return this._smallBadgeVisual;
    };
    PromoOffer.prototype.applyRulesToLoot = function (loot, playerProgress, bestLoseHeroIds, placeHolderName, sideName, placeHolderIndex) {
        var bestHeroRule = this._rules && this._rules[OFFERS_RULES_GENERATE.BEST_HERO];
        var loserHeroRule = this._rules && this._rules[OFFERS_RULES_GENERATE.LOSER_HERO];
        var playerHeroes = playerProgress.heroes;
        var playerShards = playerProgress.heroShards;
        if (bestHeroRule || loserHeroRule) {
            if (Object.keys(loot.HeroExp).length == 1) {
                var heroInLoot = heroesMap.checkedGet(Object.keys(loot.HeroExp)[0]);
                if (bestLoseHeroIds[heroInLoot.Rarity]) {
                    var heroId = bestHeroRule
                        ? bestLoseHeroIds[heroInLoot.Rarity].best
                        : bestLoseHeroIds[heroInLoot.Rarity].lose;
                    if (loot.HeroExp[heroId] == undefined) {
                        loot.HeroExp[heroId] = loot.HeroExp[heroInLoot.ID];
                        delete loot.HeroExp[heroInLoot.ID];
                    }
                }
            }
        }
        if (this._rules && this._rules[OFFERS_RULES_GENERATE.UNLOCK_HEROES]) {
            if (loot.hasShards()) {
                for (var heroId in loot.Shards) {
                    var hero = heroesMap.checkedGet(heroId);
                    var alreadyShards = playerShards[heroId] != undefined ? playerShards[heroId] : 0;
                    var rulesCounter = hero.ShardsNeeded - alreadyShards;
                    loot.Shards[heroId] = Math.max(loot.Shards[heroId], rulesCounter);
                }
            }
        }
        if (this._rules && this._rules[OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION] && this._offerRandomCustomization) {
            for (var _i = 0, _a = this._offerRandomCustomization; _i < _a.length; _i++) {
                var randomCustomizationSettings = _a[_i];
                if (randomCustomizationSettings.place.placeHolder == placeHolderName
                    && randomCustomizationSettings.place.side == sideName
                    && randomCustomizationSettings.place.additionalIndex == placeHolderIndex) {
                    var randomLoot = OffersUtils.getRandomCustomizationLoot({
                        playerProgress: playerProgress,
                        randomSettings: randomCustomizationSettings,
                        ri: RandomInstance
                    });
                    if (!randomLoot.isEmpty()) {
                        loot.clear();
                        loot.combineLoot(randomLoot);
                    }
                }
            }
        }
        if (this._rules && this._rules[OFFERS_RULES_GENERATE.COMPLETE_HEROES_LEVEL]) {
            if (loot.hasCards()) {
                for (var heroId in loot.HeroExp)
                    if (playerHeroes[heroId] != undefined) {
                        var trueState = Hero.upLevelIfNecessary(playerHeroes[heroId], Number(heroId));
                        var levelPrice = getHeroLevelUpPrice({ heroId: Number(heroId), level: trueState.Level });
                        if (levelPrice) {
                            var neededExp = levelPrice.exp;
                            var rulesCounter = Math.abs(neededExp - trueState.Exp);
                            loot.HeroExp[heroId] = Math.max(loot.HeroExp[heroId], rulesCounter);
                        }
                    }
            }
        }
    };
    PromoOffer.prototype.isTimeToRegenerate = function (currentTime, generatedInfo) {
        if (generatedInfo == undefined) {
            return false;
        }
        if (isNumber(generatedInfo.expireTime) && +generatedInfo.expireTime > 1000) {
            if (this._regenerationDelay) {
                if (generatedInfo.expireTime + this._regenerationDelay < currentTime) {
                    return true;
                }
            }
        }
        if (this._tryRegenerateOfferAfterBought && generatedInfo.purchaseCount > 0) {
            return true;
        }
        if (generatedInfo &&
            this._activeTime.endGenerationBound &&
            this._activeTime.endGenerationBound != generatedInfo.expireTime &&
            generatedInfo.expireTime > currentTime &&
            this._activeTime.endGenerationBound > currentTime) {
            return true;
        }
        return false;
    };
    PromoOffer.prototype.isDailyOffer = function () {
        return !!this._dailySettings;
    };
    PromoOffer.prototype.isPeriodicalOffer = function () {
        return this.isDailyOffer() || this.isWeeklyOffer() || this._everyDayOffer;
    };
    PromoOffer.prototype.isPeriodicalOfferFromPreviousPeriod = function (settings) {
        var generatedOffers = settings.generatedOffers, regionalSettings = settings.regionalSettings, now = settings.serverCurrentTime;
        var generatedOffer = generatedOffers[this.ID];
        if (this.isWeeklyOffer()) {
            var weeklySettings = this._weeklySettings;
            var startDate = this.getStartDateForWeeklyOffer(generatedOffers, regionalSettings, now);
            var currentPeriod = CommonUtils
                .getPeriodNumber(startDate, weeklySettings.period, now);
            var offerPeriod = CommonUtils
                .getPeriodNumber(startDate, weeklySettings.period, generatedOffer.expireTime);
            if (currentPeriod && offerPeriod && offerPeriod < currentPeriod) {
                return true;
            }
        }
        if (this._everyDayOffer || this.isDailyOffer()) {
            var today = new Date(now);
            today.setUTCHours(0, 0, 0, 0);
            if (generatedOffer.expireTime <= today.getTime()) {
                return true;
            }
        }
        return false;
    };
    PromoOffer.prototype.getPeriodEnd = function (serverTime, generatedOffers, regionalSettings) {
        if (this.isDailyOffer()) {
            return this.getDayEndForDailyOffer(serverTime, generatedOffers);
        }
        else if (this.isWeeklyOffer()) {
            return this.getPeriodEndForWeeklyOffer(serverTime, generatedOffers, regionalSettings);
        }
        else if (this._everyDayOffer) {
            return this.getPeriodEndForEveryDayOffer(serverTime, generatedOffers);
        }
        return 0;
    };
    PromoOffer.prototype.setDisableSince = function (disableSince) {
        this._disableGeneratingSince = disableSince;
    };
    PromoOffer.prototype.isDisabledForGenerating = function (serverTime) {
        return this._disableGeneratingSince != null && serverTime >= this._disableGeneratingSince;
    };
    PromoOffer.prototype.customConditionPassed = function (settings) {
        if (!this._customCondition) {
            return true;
        }
        return this._customCondition.call(this, settings);
    };
    PromoOffer.prototype.checkAnotherSourceOfOffers = function (anotherOfferSource, serverTime) {
        if (!this._checkForOffersFromAnotherSource || !anotherOfferSource) {
            return true;
        }
        var oneOfPreviousOffers = getValueByKeyDefault(this._checkForOffersFromAnotherSource, "oneOfPreviousOffers", []);
        var oneOfIgnoredOffers = getValueByKeyDefault(this._checkForOffersFromAnotherSource, "oneOfIgnoredOffers", []);
        var checkPassed = oneOfPreviousOffers.length == 0;
        for (var _i = 0, oneOfPreviousOffers_1 = oneOfPreviousOffers; _i < oneOfPreviousOffers_1.length; _i++) {
            var id = oneOfPreviousOffers_1[_i];
            if (anotherOfferSource[id] && anotherOfferSource[id].purchaseCount > 0) {
                checkPassed = true;
                break;
            }
        }
        if (!checkPassed) {
            return false;
        }
        checkPassed = oneOfIgnoredOffers.length == 0;
        for (var _a = 0, oneOfIgnoredOffers_1 = oneOfIgnoredOffers; _a < oneOfIgnoredOffers_1.length; _a++) {
            var id = oneOfIgnoredOffers_1[_a];
            if (anotherOfferSource[id]) {
                var expireTime = anotherOfferSource[id].expireTime;
                expireTime = isNumber(expireTime) && +expireTime > 0 ? +expireTime : 0;
                if (expireTime && serverTime > expireTime) {
                    checkPassed = true;
                    break;
                }
            }
        }
        return checkPassed;
    };
    PromoOffer.prototype.updateOffersToForget = function (offersToForget) {
        var forgotSettings = this._forgetOffers;
        if (forgotSettings) {
            var iterations = [
                { forgot: !!forgotSettings.offers, ids: forgotSettings.offers },
                { forgot: forgotSettings.forgetIgnored, ids: this._ignoredOffers },
                { forgot: forgotSettings.forgetPrevious, ids: this._previousOffers },
            ];
            for (var _i = 0, iterations_1 = iterations; _i < iterations_1.length; _i++) {
                var iteration = iterations_1[_i];
                var forgot = iteration.forgot, ids = iteration.ids;
                if (forgot && ids) {
                    for (var _a = 0, ids_1 = ids; _a < ids_1.length; _a++) {
                        var id = ids_1[_a];
                        if (offersToForget.indexOf(id) == -1) {
                            offersToForget.push(id);
                        }
                    }
                }
            }
        }
    };
    PromoOffer.prototype.getSpentConditionByRegion = function (cc, condition, table) {
        if (!condition) {
            return null;
        }
        if (!table || table.length == 0) {
            return condition;
        }
        var currentMin = condition.min, currentMax = condition.max;
        for (var _i = 0, table_1 = table; _i < table_1.length; _i++) {
            var segment = table_1[_i];
            var _a = segment.currentMinMax, min = _a.min, max = _a.max;
            if (currentMin >= min && currentMax <= max) {
                for (var _b = 0, _c = segment.replace; _b < _c.length; _b++) {
                    var replacer = _c[_b];
                    if (replacer.countries.indexOf(cc) > -1) {
                        return replacer.newMinMax;
                    }
                }
            }
        }
        return condition;
    };
    PromoOffer.prototype.doCloseAdOffer = function (generatedOfferInfo, serverTime, getPromoOffersSettings) {
        return Boolean(generatedOfferInfo)
            && this.isAdDisableOffer()
            && !this.canAdOfferBeGenerated(getPromoOffersSettings)
            && (generatedOfferInfo.expireTime == null || generatedOfferInfo.expireTime > serverTime);
    };
    PromoOffer.prototype.canAdOfferBeGenerated = function (getPromoOffersSettings) {
        var playerAdvertisingData = getPromoOffersSettings.playerAdvertisingData, subscribe = getPromoOffersSettings.subscribe, waitingForSubscription = getPromoOffersSettings.waitingForSubscription;
        return !playerAdvertisingData.freeOfAdsEnabled && !subscribe && !waitingForSubscription;
    };
    PromoOffer.prototype.doCloseDirectHeroSaleOffer = function (generatedOfferInfo, serverTime, playerProgress) {
        var heroId = this._directSaleForHeroId;
        if (!heroId) {
            return false;
        }
        return !!generatedOfferInfo &&
            (generatedOfferInfo.expireTime == null || generatedOfferInfo.expireTime > serverTime) &&
            !generatedOfferInfo.purchaseCount &&
            playerProgress.heroes[heroId] != undefined;
    };
    PromoOffer.prototype.doCloseOfferInSale = function (boughtSaleGroupsOneOf) {
        var saleId = this._saleGroupId;
        if (!saleId) {
            return false;
        }
        var saleSettings = PromoOfferSaleCreator.salesSettings[saleId];
        if (!saleSettings) {
            return true;
        }
        return saleSettings.closeSaleAfterOnePurchase && boughtSaleGroupsOneOf[saleId];
    };
    PromoOffer.prototype.isBattlePassConditionPassed = function (battlePassProgress) {
        if (!this._battlePass) {
            return true;
        }
        if (this._battlePass.battlePassId &&
            !OfferChecker.checkConditionOperand(battlePassProgress.BattlePassId, this._battlePass.battlePassId)) {
            return false;
        }
        if (this._battlePass.level &&
            !OfferChecker.checkConditionOperand(battlePassProgress.CurrentBattlePassLevel, this._battlePass.level)) {
            return false;
        }
        return true;
    };
    PromoOffer.prototype.isBattlePassOffer = function () {
        return !!this._battlePass;
    };
    PromoOffer.prototype.addPromoOfferToSellHeroesSettings = function (entitySettings) {
        OffersUtils.updateSellHeroesSettings(entitySettings, this.ID);
    };
    PromoOffer.prototype.getDayEndForDailyOffer = function (serverTime, generatedOffers) {
        if (!this._dailySettings) {
            return 0;
        }
        var today = new Date(serverTime);
        var weekDay = today.getUTCDay();
        var endOfToday = 1 + today.setUTCHours(23, 59, 59, 999);
        var isFirstOfferInQueue = this._dailySettings.day != undefined;
        var expireTime = 0;
        if (isFirstOfferInQueue) {
            if (this._dailySettings.day == weekDay) {
                expireTime = endOfToday;
                var generatedOffer = generatedOffers[this.ID.toString()];
                if (generatedOffer) {
                    expireTime = expireTime > generatedOffer.expireTime ? expireTime : 0;
                }
            }
        }
        else {
            var previousOfferId = this._dailySettings.queueFor;
            var generatedPreviousOffer = generatedOffers[previousOfferId.toString()];
            if (generatedPreviousOffer) {
                var startOfToday = endOfToday - new Time({ Days: 1 }).value;
                var isPreviousOfferGeneratedToday = generatedPreviousOffer.expireTime > startOfToday
                    && generatedPreviousOffer.expireTime <= endOfToday;
                if (isPreviousOfferGeneratedToday && generatedPreviousOffer.purchaseCount > 0) {
                    var generatedOffer = generatedOffers[this.ID.toString()];
                    if (!generatedOffer
                        || generatedOffer.expireTime <= startOfToday) {
                        expireTime = this._activeTime.duration
                            ? Math.min(endOfToday, serverTime + this._activeTime.duration)
                            : endOfToday;
                    }
                }
            }
        }
        return expireTime;
    };
    PromoOffer.prototype.isWeeklyOffer = function () {
        return !!this._weeklySettings;
    };
    PromoOffer.prototype.getPeriodEndForWeeklyOffer = function (serverTime, generatedOffers, regionalSettings) {
        if (!this._weeklySettings) {
            return 0;
        }
        var _a = this._weeklySettings, period = _a.period, activeDay = _a.activeDay, endDate = _a.endDate;
        var startDate = this.getStartDateForWeeklyOffer(generatedOffers, regionalSettings, serverTime);
        if (period <= 0 || !startDate || serverTime < startDate) {
            return 0;
        }
        if (endDate && serverTime >= endDate) {
            return 0;
        }
        var periods = (((serverTime - startDate) / period) >> 0) + 1;
        var expireTime = startDate + periods * period;
        var startTime = 0;
        if (endDate) {
            expireTime = Math.min(expireTime, endDate);
        }
        if (activeDay && activeDay > 0) {
            var startDateOfCurrentPeriod = startDate + (periods - 1) * period;
            expireTime = startDateOfCurrentPeriod + new Time({ Days: activeDay }).value;
            if (endDate) {
                expireTime = Math.min(expireTime, endDate);
            }
            startTime = expireTime - new Time({ Days: 1 }).value;
        }
        var generatedOffer = generatedOffers[this.ID.toString()];
        if (generatedOffer && expireTime <= generatedOffer.expireTime) {
            return 0;
        }
        return serverTime >= startTime && serverTime <= expireTime ? expireTime : 0;
    };
    PromoOffer.prototype.getPeriodEndForEveryDayOffer = function (serverTime, generatedOffers) {
        if (!this._everyDayOffer) {
            return 0;
        }
        var activeTime = this._activeTime;
        var startDate = new Date(activeTime.startGenerationBound);
        startDate.setUTCHours(0, 0, 0, 0);
        var startTime = startDate.getTime();
        var dayPeriod = new Time({ Days: 1 }).value;
        var days = Math.ceil((activeTime.endGenerationBound - activeTime.startGenerationBound) / dayPeriod);
        var expireTime = 0;
        for (var day = 0; day < days; day++) {
            var start = startTime + day * dayPeriod;
            var end = start + dayPeriod;
            if (serverTime >= start && serverTime < end) {
                expireTime = end;
                break;
            }
        }
        var generatedOffer = generatedOffers[this.ID.toString()];
        if (generatedOffer && expireTime <= generatedOffer.expireTime) {
            return 0;
        }
        return expireTime;
    };
    PromoOffer.prototype.getStartDateForWeeklyOffer = function (generatedOffers, regionalParameter, serverTime) {
        if (!this.isWeeklyOffer()) {
            return undefined;
        }
        var weeklySettings = this._weeklySettings;
        if (weeklySettings.startDate) {
            return weeklySettings.startDate;
        }
        if (weeklySettings.startByOfferEarliestExpired) {
            var earliestExpireTime = null;
            for (var _i = 0, _a = weeklySettings.startByOfferEarliestExpired; _i < _a.length; _i++) {
                var offerId = _a[_i];
                var prevOffer = generatedOffers[offerId];
                if (prevOffer && isNumber(prevOffer.expireTime) && prevOffer.expireTime > 1000) {
                    if (earliestExpireTime == null) {
                        earliestExpireTime = prevOffer.expireTime;
                    }
                    else {
                        earliestExpireTime = Math.min(earliestExpireTime, prevOffer.expireTime);
                    }
                }
            }
            if (earliestExpireTime) {
                var dayOfExpire = new Date(earliestExpireTime);
                return 1 + dayOfExpire.setUTCHours(23, 59, 59, 999);
            }
            return undefined;
        }
        if (weeklySettings.startDateFunction) {
            return weeklySettings.startDateFunction(generatedOffers, regionalParameter, serverTime);
        }
        return undefined;
    };
    PromoOffer.setField = CommonUtils.setOnlyFilledValue;
    return PromoOffer;
}(OfferBasic));
