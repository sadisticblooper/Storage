var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var OfferSkeletonUtils = (function () {
    function OfferSkeletonUtils() {
    }
    OfferSkeletonUtils.createOffersFromSkins = function (offersMap, skinsMap) {
        var _loop_1 = function (skinName) {
            var skin = skinsMap[skinName];
            var skinItemsQuantity = skin.offers.length;
            var skeletonItemsQuantity = skin.skeleton.offers.length;
            var quantity = Math.max(skinItemsQuantity, skeletonItemsQuantity);
            if (skinItemsQuantity != skeletonItemsQuantity) {
                throw new Error("createOffersFromSkins error: number of offers in skin and skeleton is incorrect. "
                    + "See ".concat(skinName));
            }
            var ids = OfferSkeletonUtils.getOfferIdsArray(skin.skeleton.offers, skin.offers);
            var offersIdsMap = OfferSkeletonUtils.createIdsMap({
                ids: ids,
                generationIdFunction: skin.offersIdGenerator
            });
            OfferSkeletonUtils.addIdsToStore(skinName, Object.keys(offersIdsMap).map(function (i) { return offersIdsMap[i]; }));
            for (var i = 0; i < quantity; i++) {
                var skinIndex = Math.min(i, skinItemsQuantity - 1);
                var skeletonIndex = Math.min(i, skeletonItemsQuantity - 1);
                try {
                    OfferSkeletonUtils.createOffer({
                        activeTime: skin.activeTime,
                        onceRepeatAfter: skin.onceRepeatAfter,
                        vars: skin.vars,
                        generationNameFunction: skin.offersNameGenerator,
                        mapWithItems: offersMap,
                        mapWitIds: offersIdsMap,
                        skeletonOfferSettings: skin.skeleton.offers[skeletonIndex],
                        skinOfferSettings: skin.offers[skinIndex],
                        index: i,
                    });
                }
                catch (e) {
                    throw new Error("Error with offer-skin '".concat(skinName, "' index ").concat(i, ". ") + e.toString());
                }
            }
        };
        for (var skinName in skinsMap) {
            _loop_1(skinName);
        }
    };
    OfferSkeletonUtils.getOfferIdsFromSkin = function (name) {
        if (OfferSkeletonUtils.savedIdsBySkins[name] == undefined) {
            throw new Error("getOfferIdsFromSkin: cant find offers for skin '".concat(name, "'"));
        }
        return OfferSkeletonUtils.savedIdsBySkins[name];
    };
    OfferSkeletonUtils.createIdsMap = function (settings) {
        var ids = settings.ids, generationIdFunction = settings.generationIdFunction;
        var result = {};
        for (var index = 0; index < ids.length; index++) {
            var id = ids[index];
            if (id == null && generationIdFunction == undefined) {
                throw new Error("You must set ID or 'FGenerateIdByIndexFunction' function. Index: ".concat(index, "."));
            }
            result[index + 1] = id || generationIdFunction(index);
        }
        return result;
    };
    OfferSkeletonUtils.createOffer = function (settings) {
        var mapWithItems = settings.mapWithItems, mapWitIds = settings.mapWitIds, skeletonOfferSettings = settings.skeletonOfferSettings, skinOfferSettings = settings.skinOfferSettings, index = settings.index, activeTime = settings.activeTime, onceRepeatAfter = settings.onceRepeatAfter, vars = settings.vars, generationNameFunction = settings.generationNameFunction;
        var skeletonPromoOfferSettings = skeletonOfferSettings.common;
        var id = mapWitIds[index + 1];
        if (id == undefined) {
            throw new Error("createOffer: can't create offer with 'undefined' ID. Index ".concat(index, "."));
        }
        if (skeletonOfferSettings.commonWithVars != undefined) {
            skeletonPromoOfferSettings = __assign(__assign({}, skeletonPromoOfferSettings), skeletonOfferSettings.commonWithVars(vars || {}, mapWitIds));
        }
        var resultActiveTime = skinOfferSettings.common.activeTime || skeletonPromoOfferSettings.activeTime || activeTime;
        var defaultOnceRepeatAfter = resultActiveTime.startGenerationBound - new Time({ Days: 1 }).value;
        if (onceRepeatAfter == undefined) {
            onceRepeatAfter = skinOfferSettings.common.onceRepeatAfter
                || skeletonPromoOfferSettings.onceRepeatAfter
                || defaultOnceRepeatAfter;
        }
        if (skinOfferSettings.activeDay && activeTime) {
            var activeDay = skinOfferSettings.activeDay;
            var dayPeriod = new Time({ Days: 1 }).value;
            resultActiveTime = {
                startGenerationBound: activeTime.startGenerationBound + (activeDay - 1) * dayPeriod,
                endGenerationBound: activeTime.startGenerationBound + activeDay * dayPeriod,
            };
        }
        var enablePopup = skinOfferSettings.common.enablePopup || skeletonPromoOfferSettings.enablePopup;
        var popupSettings = skinOfferSettings.common.popupSettings || skeletonPromoOfferSettings.popupSettings;
        if (enablePopup && popupSettings == undefined) {
            popupSettings = {
                popUpId: id,
                popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
            };
        }
        var customSettings = {
            activeTime: resultActiveTime,
            popupSettings: popupSettings,
            onceRepeatAfter: onceRepeatAfter,
        };
        var offerSettings = __assign(__assign(__assign(__assign({}, skeletonPromoOfferSettings), skinOfferSettings.common), customSettings), { ID: id });
        var name = generationNameFunction(id, skeletonOfferSettings.offerPrefix || "", vars);
        mapWithItems[name] = new PromoOffer(offerSettings);
    };
    OfferSkeletonUtils.getOfferIdsArray = function (skeletonOffers, skinOffers) {
        var quantity = Math.max(skinOffers.length, skeletonOffers.length);
        var result = [];
        for (var index = 0; index < quantity; index++) {
            var skeletonOffer = skeletonOffers[index];
            var skinOffer = skinOffers[index];
            result.push(skinOffer && skinOffer.common.ID || skeletonOffer && skeletonOffer.common.ID);
        }
        return result;
    };
    OfferSkeletonUtils.addIdsToStore = function (name, ids) {
        OfferSkeletonUtils.savedIdsBySkins[name] = ids;
    };
    OfferSkeletonUtils.savedIdsBySkins = {};
    return OfferSkeletonUtils;
}());
