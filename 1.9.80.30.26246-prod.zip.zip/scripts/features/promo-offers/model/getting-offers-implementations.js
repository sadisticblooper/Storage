var OffersToOffersConverter = (function () {
    function OffersToOffersConverter() {
    }
    OffersToOffersConverter.prototype.Args = function (p) {
        return p;
    };
    OffersToOffersConverter.prototype.Result = function (p) {
        return p;
    };
    OffersToOffersConverter.prototype.Type = function (p) {
        return p;
    };
    return OffersToOffersConverter;
}());
