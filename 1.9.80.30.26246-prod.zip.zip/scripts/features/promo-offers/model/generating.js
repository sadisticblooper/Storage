var PromoGenerating = (function () {
    function PromoGenerating() {
    }
    PromoGenerating.getPromoOffers = function (params) {
        var converter = new OffersToOffersConverter();
        var itemsGetter = new GettingItemsLikeOffers(offersMap, converter);
        return itemsGetter.getPromos(params);
    };
    PromoGenerating.generatePromoOffer = function (params) {
        try {
            RandomInstance.setSeed(params.seed);
            var offer_1 = offersMap.checkedGet(params.offerId);
            offer_1 = new PromoOffer(offer_1._promoOfferSettings);
            offer_1.clearSlotsLoot();
            var restrictedList_1 = { Cards: [], Shards: [] };
            RestrictedList.extendByBlockedByTime(restrictedList_1, params.startTimeOfCurrentDayMS);
            var playerProgress_1 = PlayerState.getCorrectFromRawOrCache(params.playerProgress);
            var bestLoseHero_1 = HeroUtils.getBestLoseHeroIdsByRarity(playerProgress_1.heroes);
            var lootGenerator_1 = LootGeneratorBuilder.getOffersLootGenerator();
            var availableSeparated_1 = HeroUtils.getAvailableSeparatedHeroes(playerProgress_1, restrictedList_1);
            offer_1.lootSlotsIterator(function (variants, placeHolderName, sideName, placeHolderIndex) {
                var collection = new RandomCollection();
                for (var _i = 0, variants_1 = variants; _i < variants_1.length; _i++) {
                    var variant_1 = variants_1[_i];
                    if (!PromoGenerating.checkVariant(variant_1, availableSeparated_1, playerProgress_1)) {
                        continue;
                    }
                    collection.add(new CollectionObjectContainer(variant_1, variant_1.weight));
                }
                if (!collection.size()) {
                    for (var _a = 0, variants_2 = variants; _a < variants_2.length; _a++) {
                        var variant_2 = variants_2[_a];
                        collection.add(new CollectionObjectContainer(variant_2, variant_2.weight));
                    }
                }
                var variant = (collection.next(RandomInstance).get());
                var settingsRewardContent = OffersUtils.getPromoOfferRewardContent(variant.item, playerProgress_1);
                var sideLoot = {
                    chests: [],
                    loot: new Loot(),
                    isHidden: settingsRewardContent.isHidden,
                };
                if (settingsRewardContent.chests) {
                    for (var _b = 0, _c = settingsRewardContent.chests; _b < _c.length; _b++) {
                        var id = _c[_b];
                        var chest = chestsMap.checkedGet(id);
                        sideLoot.chests.push(chest);
                        offer_1._chests.push(chest);
                    }
                }
                if (settingsRewardContent.lootSettings) {
                    lootGenerator_1.setLootSettings_oldFormat(settingsRewardContent.lootSettings);
                    lootGenerator_1.setPlayerParams(playerProgress_1);
                    lootGenerator_1.setServerTime(params.startTimeOfCurrentDayMS);
                    lootGenerator_1.setRestrictedList(restrictedList_1);
                    var loot = lootGenerator_1.generateLoot(RandomInstance);
                    if (!loot.isEmpty()) {
                        offer_1.applyRulesToLoot(loot, playerProgress_1, bestLoseHero_1, placeHolderName, sideName, placeHolderIndex);
                        sideLoot.loot = loot;
                        offer_1._loot.combineLoot(loot);
                        RestrictedList.updateByLoot(restrictedList_1, loot);
                        HeroUtils.combineLoot(playerProgress_1, loot);
                    }
                }
                if (placeHolderName == "mainPlaceHolder") {
                    if (offer_1._slotsLoot[placeHolderName] == undefined) {
                        offer_1._slotsLoot[placeHolderName] = {};
                    }
                    offer_1._slotsLoot[placeHolderName][sideName] = sideLoot;
                }
                else {
                    if (offer_1._slotsLoot[placeHolderName][placeHolderIndex] == undefined) {
                        offer_1._slotsLoot[placeHolderName][placeHolderIndex] = {};
                    }
                    offer_1._slotsLoot[placeHolderName][placeHolderIndex][sideName] = sideLoot;
                }
            });
            offer_1.updateInAppByRegional(params.regionalSettings);
            return {
                offer: offer_1,
            };
        }
        catch (e) {
            throw new Error("generatePromoOffer error: ".concat(e.message, ", \ninput: \n").concat(JSON.stringify(params)));
        }
    };
    PromoGenerating.generatePromoOfferMany = function (playerSettings) {
        var idSettings = playerSettings.promoOfferSettings;
        var offers = [];
        var playerProgress = PlayerState.getCorrectFromRawOrCache(playerSettings.playerProgress);
        var dailyShop = playerSettings.dailyShop, regionalSettings = playerSettings.regionalSettings;
        for (var offerIndex = 0; offerIndex < idSettings.offerId.length; offerIndex++) {
            if (idSettings.offerId[offerIndex] && idSettings.seed[offerIndex] != undefined) {
                offers.push(generatePromoOffer({
                    offerId: idSettings.offerId[offerIndex],
                    playerProgress: playerProgress,
                    dailyShop: dailyShop,
                    regionalSettings: regionalSettings,
                    seed: idSettings.seed[offerIndex],
                    startTimeOfCurrentDayMS: playerSettings.startTimeOfCurrentDayMS,
                }));
            }
        }
        return offers;
    };
    PromoGenerating.checkVariant = function (variant, separatedInfo, playerProgress) {
        var settingsRewardContent = OffersUtils.getPromoOfferRewardContent(variant.item, playerProgress);
        var separatedHeroes = separatedInfo.available;
        if (settingsRewardContent.chests && settingsRewardContent.chests.length) {
            return true;
        }
        var lootSettings = settingsRewardContent.lootSettings;
        if (lootSettings && lootSettings.CardsSlots) {
            for (var rarityNumber in lootSettings.CardsSlots.Rarities) {
                if (separatedHeroes[rarityNumber]
                    && (separatedHeroes[rarityNumber].cards.length || separatedHeroes[rarityNumber].shards.length)) {
                    return true;
                }
            }
            return false;
        }
        else {
            return true;
        }
    };
    return PromoGenerating;
}());
