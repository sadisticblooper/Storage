var HeroesSalePopUps = (function () {
    function HeroesSalePopUps() {
    }
    HeroesSalePopUps.getOne = {
        data: {
            "ID": 7000,
            "priority": 11,
            "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
            "navigationArg": 0,
            "navigationLinkURL": "sfa://heroesLibrary?section=singlemode&scrollToLockedHeroes=true",
            "activeTime": [],
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 18,
            "iconBackground": {
                "sprite": "Sprites/PreviewImages/Bonus/icon_bonus_back",
                "color": "#55E5BA"
            },
            "iconLabel": null,
            "rulesDescription": null,
            "rulesHeader": null,
            "header": {
                "alias": "popup_title_herosale",
                "color": "#55E5BA"
            },
            "subHeader": {
                "alias": "multi_bonus_popup_subheader",
                "color": "#FFFFFF"
            },
            "timer": {
                "alias": "multi_bonus_popup_ends_in",
                "color": "#55E5BA"
            },
            "content": {
                "alias": "popup_title_herosale_getone",
                "color": "#FFFFFFB8"
            },
            "button": {
                "alias": "button_to_the_HeroesLibrary",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/SalePopup/sale_art",
                "color": "#FFFFFF"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/SalePopup/sale_bg",
                "color": "#FFFFFF"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#55E5BA8A"
            },
            "particles": {
                "maxColor": "#55E5BAB2",
                "minColor": "#55E5BA4C"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#54E2B8"
                    },
                    {
                        "time": 0.98,
                        "color": "#1D292E"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#55E5BA"
                    },
                    {
                        "time": 0.99,
                        "color": "#1D292E"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": null,
            "pattern": {
                "sprite": "Sprites/PreviewImages/Bonus/pattern_bonus",
                "color": "#55E5BA2E"
            },
            "popupType": ActivityPopupType.Offer,
        },
    };
    HeroesSalePopUps.getAll = {
        data: {
            "ID": 7001,
            "priority": 11,
            "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
            "navigationArg": 0,
            "navigationLinkURL": "sfa://heroesLibrary?section=singlemode&scrollToLockedHeroes=true",
            "activeTime": [],
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 18,
            "iconBackground": {
                "sprite": "Sprites/PreviewImages/Bonus/icon_bonus_back",
                "color": "#55E5BA"
            },
            "iconLabel": null,
            "rulesDescription": null,
            "rulesHeader": null,
            "header": {
                "alias": "popup_title_herosale",
                "color": "#55E5BA"
            },
            "subHeader": {
                "alias": "multi_bonus_popup_subheader",
                "color": "#FFFFFF"
            },
            "timer": {
                "alias": "multi_bonus_popup_ends_in",
                "color": "#55E5BA"
            },
            "content": {
                "alias": "popup_title_herosale_getall",
                "color": "#FFFFFFB8"
            },
            "button": {
                "alias": "button_to_the_HeroesLibrary",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/SalePopup/sale_art",
                "color": "#FFFFFF"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/SalePopup/sale_bg",
                "color": "#FFFFFF"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#55E5BA8A"
            },
            "particles": {
                "maxColor": "#55E5BAB2",
                "minColor": "#55E5BA4C"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#54E2B8"
                    },
                    {
                        "time": 0.98,
                        "color": "#1D292E"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#55E5BA"
                    },
                    {
                        "time": 0.99,
                        "color": "#1D292E"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": null,
            "pattern": {
                "sprite": "Sprites/PreviewImages/Bonus/pattern_bonus",
                "color": "#55E5BA2E"
            },
            "popupType": ActivityPopupType.Offer,
        },
    };
    return HeroesSalePopUps;
}());
