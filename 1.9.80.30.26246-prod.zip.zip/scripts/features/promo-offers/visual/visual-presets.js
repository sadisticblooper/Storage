var PromoOfferVisualPresets = (function () {
    function PromoOfferVisualPresets() {
    }
    PromoOfferVisualPresets.check = function () {
        var intersection = ArrayUtils.getArraysIntersection(Object.keys(PromoOfferVisualPresets.presets), Object.keys(PromoOfferVisualPresets.templates));
        if (intersection.length > 0) {
            throw new Error("Same visual presets repeated in 'templates' and 'presets': " + JSON.stringify(intersection));
        }
    };
    PromoOfferVisualPresets.presetWithDefaults = {
        showTooltip: null,
        offerType: null,
        bgImagePattern: { enabled: null, sprite: null, color: null, },
        bgGradient: null,
        header: { enabled: null, color: null, saleInsteadName: null },
        sale: { enabled: null, colorText: null, colorBG: null, showPercent: null, },
        profit: { enabled: null, colorText: null, colorBG: null, },
        mainImage: { enabled: null, sprite: null, color: null, },
        effectImage: { enabled: null, type: null, color: null, },
        particles: [{ minColor: null, maxColor: null, }],
        additionalText: { enabled: null, color: null, alias: null, },
        labelValue: { enabled: null, glowColor: null, subGlowColor: null, title: null, },
        additionalImages: [{ enabled: null, sprite: null, }],
        characterText: null,
        popupVisualPreset: null,
        bgImage: { enabled: null, sprite: null, color: null, },
        subTitle: null,
        iconsDescription: [{ icon: null, iconColor: null, label: null, labelColor: null, }],
    };
    PromoOfferVisualPresets.popUpPresetWithNulls = {
        characterText: {
            enabled: null,
            glowColor: null,
            subGlowColor: null,
            title: null,
            subtitle: null,
            titleColor: null,
            subTitleColor: null,
        },
        videoId: null,
    };
    PromoOfferVisualPresets.templates = {
        "40": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#3f5473",
                        "time": 0
                    },
                    {
                        "color": "#263345",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_R_Rec_Boss.RoguelikeAvatar)
            }
        },
        "boss_Ironclad_E_Rust_Rec_Boss": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E59655",
                        "time": 0
                    },
                    {
                        "color": "#E59655",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#CF503A"
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#f0b584"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Rust_Rec_Boss.RoguelikeAvatar)
            }
        },
        "70": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                },
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E59655",
                        "time": 0
                    },
                    {
                        "color": "#E59655",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#CF503A"
            }
        },
        "71": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                },
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E59655",
                        "time": 0
                    },
                    {
                        "color": "#E59655",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#CF503A"
            }
        },
        "105": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#C68CFF5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)
            }
        },
        "cyberweek_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a347ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#00b881FF",
                        "time": 0
                    },
                    {
                        "color": "#5000a1FF",
                        "time": 0.5
                    },
                    {
                        "color": "#000000FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 0.5
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)
            }
        },
        "300": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#15CF7B",
                        "time": 0
                    },
                    {
                        "color": "#1F8DA1",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#1F8DA1"
            }
        },
        "411": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#736335",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#CFAE4C"
            }
        },
        "702": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#736335",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8a2da1"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#736335"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Original.RoguelikeAvatar)
            }
        },
        "1027": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#0D2E2E",
                        "time": 0
                    },
                    {
                        "color": "#3ACFCF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3ACFCF"
            }
        },
        "1035": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#384145",
                        "time": 0
                    },
                    {
                        "color": "#2a7332",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#5ecfff"
            }
        },
        "1073": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                },
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#B84444",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#B84444"
            }
        },
        "1246": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#B84444",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#B84444"
            }
        },
        "1271": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#B84444",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#B84444"
            }
        },
        "1311": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#FF8CAF",
                        "time": 0
                    },
                    {
                        "color": "#73612A",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#FF8CAF"
            }
        },
        "1312": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#C9FFFF",
                        "time": 0
                    },
                    {
                        "color": "#64cccc",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#326666"
            }
        },
        "1378": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#33708a",
                        "time": 0
                    },
                    {
                        "color": "#a072cf",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            }
        },
        "1379": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#33708a",
                        "time": 0
                    },
                    {
                        "color": "#a072cf",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            }
        },
        "1563": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#A13B10",
                        "time": 0
                    },
                    {
                        "color": "#686973",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#686973"
            }
        },
        "3173": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B2B844",
                        "time": 0
                    },
                    {
                        "color": "#CF8C27",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#CF8C27"
            }
        },
        "3287": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Demon.RoguelikeAvatar)
            },
            "particles": [
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                },
                {
                    "minColor": "#e5965536",
                    "maxColor": "#e59655ff"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#C68CFF5C"
            }
        },
        "3421": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#543573",
                        "time": 0
                    },
                    {
                        "color": "#A8AEE5",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A8AEE5"
            }
        },
        "offer_with_image_com_Bulwark": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#97aeb8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#384145FF",
                        "time": 0
                    },
                    {
                        "color": "#8498a1FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#97aeb85C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_base_skin.RoguelikeAvatar)
            }
        },
        "offer_with_image_rare_Helga": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 0
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar)
            }
        },
        "offer_with_image_leg_LK": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 0
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#ffd75e5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar)
            }
        },
        "5020": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "color": "#97aeb85C"
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#97aeb8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#384145FF",
                        "time": 0
                    },
                    {
                        "color": "#8498a1FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "5032": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 0
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "5046": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "color": "#C68CFF5C"
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "leaderscore_vs": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#FF47475B"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#129FB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#FF4747FF",
                        "time": 1
                    },
                    {
                        "color": "#8A2727FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
        },
        "leaderscore_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#129FB8"
            },
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#FF4747FF",
                        "time": 1
                    },
                    {
                        "color": "#8A2727FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#FF47475B"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar)
            }
        },
        "5056": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "color": "#ffd75e5C"
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 0
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "5277": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b354b8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#714873FF",
                        "time": 0
                    },
                    {
                        "color": "#e07ee5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#e56ab4"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar)
            }
        },
        "5278": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#278a8a"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#497373FF",
                        "time": 0
                    },
                    {
                        "color": "#7EE5E5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#47ffff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)
            }
        },
        "cycle_weekly_rare": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#7297CF36",
                    "maxColor": "#7297CFFF"
                },
                {
                    "minColor": "#7297CF36",
                    "maxColor": "#7297CFFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 0
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "gift_8_march": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Valentine/offer_bg_valentine",
                "color": "#e555acFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#9A6685FF",
                        "time": 0
                    },
                    {
                        "color": "#9A6685FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Wayfarer_Rec_Flower.RoguelikeAvatar)
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffdd75ff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Yukka",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000021"
            }
        },
        "cycle_weekly_epic": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#33B8A4"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4A53A1FF",
                        "time": 0
                    },
                    {
                        "color": "#33B8A4FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "cycle_weekly_epic_vs": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "gift_hero": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#33B8A4FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#203445FF",
                        "time": 0
                    },
                    {
                        "color": "#4A53A1FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "legendary_hero_vs": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    },
                    {
                        "color": "#736335FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#ffd75e"
            },
        },
        "5013_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 0
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar)
            }
        },
        "1394_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#C68CFF5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar)
            }
        },
        "starter_pack_Kibo": {
            "showTooltip": false,
            "popupVisualPreset": "starter_pack_Kibo_popup",
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#c68cff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)
            },
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd12e",
                "subGlowColor": "#ffedd12e",
                "title": "Kibo",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffedd1"
            }
        },
        "starter_pack_Kibo_popup": {
            "showTooltip": false,
            "videoId": 1103079745,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#c68cff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)
            },
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd12e",
                "subGlowColor": "#ffedd12e",
                "title": "Kibo",
                "subtitle": "starter_pack_sub_title",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#5ee7ff"
            }
        },
        "cycle_daily_1": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8a2da1"
            }
        },
        "cycle_daily_vs": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "color": "#ffd75e5C"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8a2da1"
            }
        },
        "cycle_daily_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8a2da1"
            }
        },
        "Customize_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#2C92E5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#451322FF",
                        "time": 0
                    },
                    {
                        "color": "#7C254FFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Emperor/preview_art_Emperor_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "Customize_small": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#2C92E5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B8122BFF",
                        "time": 0
                    },
                    {
                        "color": "#2C92E5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "cycle_currency": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#55D0E5",
                        "time": 0
                    },
                    {
                        "color": "#356973",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#4CBBCF"
            }
        },
        "promo_cards_common": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#97aeb8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#384145FF",
                        "time": 0
                    },
                    {
                        "color": "#8498a1FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "promo_cards_rare": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#357360",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "promo_cards_legendary": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 0
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "no_ad_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferNoAds,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#39732BFF",
                "colorBG": "#7FFF5EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#6CFF48FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "",
                "color": null
            },
            "particles": [
                {
                    "minColor": "#82e66a36",
                    "maxColor": "#82e66aFF"
                },
                {
                    "minColor": "#82e66a36",
                    "maxColor": "#82e66aFF"
                }
            ],
            "bgGradient": null,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#82e56a"
            },
            "subTitle": {
                "enabled": true,
                "color": "#ffffff84",
                "label": {
                    "isAlias": true,
                    "value": "no_ads_sub",
                    "placeholders": null
                }
            },
            "iconsDescription": [
                {
                    "icon": "Sprites/Assets/FightPass/icon_BONUS_CARD",
                    "iconColor": "#82e66a",
                    "label": {
                        "isAlias": true,
                        "value": "no_ads_gold",
                        "placeholders": null
                    },
                    "labelColor": "#ffffff"
                },
                {
                    "icon": "Sprites/Assets/NoAds/icon_NO_AD",
                    "iconColor": "#82e66a",
                    "label": {
                        "isAlias": true,
                        "value": "no_ads_buffs_revivals",
                        "placeholders": null
                    },
                    "labelColor": "#ffffff"
                },
                {
                    "icon": "Sprites/Assets/NoAds/icon_KEYS_SHARDS",
                    "iconColor": "#82e66a",
                    "label": {
                        "isAlias": true,
                        "value": "no_ads_roulette",
                        "placeholders": null
                    },
                    "labelColor": "#ffffff"
                },
                {
                    "icon": "Sprites/Assets/NoAds/icon_STAR",
                    "iconColor": "#82e66a",
                    "label": {
                        "isAlias": true,
                        "value": "no_ads_other_offers",
                        "placeholders": null
                    },
                    "labelColor": "#ffffff"
                }
            ],
            "effectImage": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "popupVisualPreset": null,
            "bgImage": null
        },
        "5018_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#97aeb8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#384145FF",
                        "time": 0
                    },
                    {
                        "color": "#8498a1FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#97aeb85C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_base_skin.RoguelikeAvatar)
            }
        },
        "127_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#7297cf",
                        "time": 0
                    },
                    {
                        "color": "#7297cf",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#91FF75"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar)
            }
        },
        "207_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#357360",
                        "time": 0
                    },
                    {
                        "color": "#495a73",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": false,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#5EFFCF5C"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Jet_base_skin.RoguelikeAvatar)
            },
            "labelValue": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "shop_offers_to_unlock"
            }
        },
        "1356_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#B14BB3"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B14BB3",
                        "time": 0
                    },
                    {
                        "color": "#B14BB3",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#75D9FF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar)
            }
        },
        "1524_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#3f5473",
                        "time": 0
                    },
                    {
                        "color": "#263345",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar)
            }
        },
        "134_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8498A1"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8498A1",
                        "time": 0
                    },
                    {
                        "color": "#8498A1",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#91FF75"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_base_skin.RoguelikeAvatar)
            },
            "characterText": {
                "enabled": false,
                "glowColor": "#DD76FF",
                "subGlowColor": "#DD76FF",
                "title": "",
                "subtitle": "",
                "titleColor": "#DD76FF",
                "subTitleColor": "#C28AFB"
            }
        },
        "208_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": false,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#5EFFCF5C"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)
            },
            "labelValue": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "shop_offers_to_unlock"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#357360",
                        "time": 0
                    },
                    {
                        "color": "#5e4973",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A072CF"
            }
        },
        "1037_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#B27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#775499"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)
            }
        },
        "1336_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8498A1"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8498A1",
                        "time": 0
                    },
                    {
                        "color": "#8498A1",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#75D9FF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)
            }
        },
        "1359_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#F1B300"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#F1B300",
                        "time": 0
                    },
                    {
                        "color": "#F1B300",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#75D9FF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar)
            }
        },
        "1347_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#409BE5"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#409BE5",
                        "time": 0
                    },
                    {
                        "color": "#409BE5",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#75D9FF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar)
            }
        },
        "5125_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 0
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#ffd75e5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)
            }
        },
        "promo_community_event": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#322045",
                        "time": 0
                    },
                    {
                        "color": "#73612A",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#C955E5"
            }
        },
        "promo_community_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#322045",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#C955E5"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Dragon.RoguelikeAvatar),
                "color": null
            },
        },
        "promo_community_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#C955E5"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#322045",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "promo_event_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4484B8FF",
                        "time": 0
                    },
                    {
                        "color": "#A27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            },
        },
        "promo_event_offer_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#b8322330",
                        "time": 0
                    },
                    {
                        "color": "#b8322330",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#ff9a47ff"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#ff9a47FF"
            }
        },
        "promo_event_offer_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4C94CFFF",
                        "time": 0
                    },
                    {
                        "color": "#2A455CFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_E_Valkyrie.RoguelikeAvatar)
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "promo_event_offer_vs": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "additionalText": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "alias": "shop_offers_to_unlock"
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#97aeb867"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B2B844",
                        "time": 0
                    },
                    {
                        "color": "#CF8C27",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "color": "#CF8C27"
            },
        },
        "promo_event_offer_2": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b84444FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#b89b44FF",
                        "time": 0
                    },
                    {
                        "color": "#b84444FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            },
        },
        "promo_event_offer_big_2": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a8aee5ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#543573ff",
                        "time": 0
                    },
                    {
                        "color": "#7E6993ff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            },
        },
        "promo_event_offer_hero_2": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b84444FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#73612aFF",
                        "time": 0
                    },
                    {
                        "color": "#cfa93aFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Oriental_skin.RoguelikeAvatar)
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Kibo",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            },
        },
        "promo_event_offer_hero_3": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b84444FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#73612aFF",
                        "time": 0
                    },
                    {
                        "color": "#cfa93aFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride.RoguelikeAvatar)
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Yunlin",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            },
        },
        "skin_marathon_vampires_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8a2da1"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar)
            }
        },
        "leg_lynx_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#4D4A57"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#170100",
                        "time": 1
                    },
                    {
                        "color": "#170100",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#5C0500"
            },
            "subTitle": null,
            "iconsDescription": null,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_L_Hood.RoguelikeAvatar),
                "color": null
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000045",
                "subGlowColor": "#00000000",
                "title": "Lynx",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#fffd75"
            }
        },
        "last_day_leg": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#736335",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8E65B8"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#736335"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince.RoguelikeAvatar)
            }
        },
        "caregame": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferCareGame,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": null,
            "profit": null,
            "mainImage": null,
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#CFAE4CB2"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "popupVisualPreset": null,
            "bgImage": null,
            "bgImagePattern": {
                "enabled": true,
                "color": "#CFAE4C"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 1
                    },
                    {
                        "color": "#736335",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "caregame_marcus": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#C68CFF5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)
            }
        },
        "7400_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "popupVisualPreset": "starter_pack_Kibo_popup",
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Kibo",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7401_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_R_Rose_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Kibo",
                "subtitle": "skin_hero_Kibo_R_Rose",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7402_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 1
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#8cbaff5C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Viper",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7404_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Itu",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffedd1"
            },
            "bgImage": null
        },
        "7405_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Midnight",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7406_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_R_Viny.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Legion_King",
                "subtitle": "skin_hero_Legion_King_R_Viny",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7407_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_R_Star.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "June",
                "subtitle": "skin_hero_June_R_Star",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7408_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_R_Red.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Itu",
                "subtitle": "skin_hero_Itu_R_Red",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7409_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_R_base_Rec_Blaze.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Monkey_King",
                "subtitle": "skin_hero_Monkey_King_R_base_Rec_Blaze",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7410_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_R_Blue.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Midnight",
                "subtitle": "skin_hero_Midnight_R_Blue",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null
        },
        "7411_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 1
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#8cbaff5C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Yunlin",
                "subtitle": "skin_hero_Yunlin_E_Bride",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7413_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Stranger.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Monkey_King",
                "subtitle": "skin_hero_monkeyking_E_stranger",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7414_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone_Rec_Lich.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Legion_King",
                "subtitle": "skin_hero_Legion_King_E_Bone_Rec_Lich",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7415_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Empress.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "June",
                "subtitle": "skin_hero_June_E_Empress",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7417_ab_starter_J24": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Demon.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Itu",
                "subtitle": "skin_hero_Itu_E_Demon",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7432_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#495a73FF",
                        "time": 1
                    },
                    {
                        "color": "#7ea8e5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Mobster.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#8cbaff5C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Viper",
                "subtitle": "skin_hero_Viper_E_Mobster",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#c68cff"
            },
            "bgImage": null
        },
        "7435_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Witch_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Midnight",
                "subtitle": "skin_hero_Midnight_E_Witch_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7436_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Legion_King",
                "subtitle": "Legion_King_E_Prince_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7441_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Mogwai_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Butcher",
                "subtitle": "skin_hero_Butcher_E_Mogwai_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7442_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Legion_King",
                "subtitle": "Legion_King_E_Prince_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7447_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Demon_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Itu",
                "subtitle": "skin_hero_Itu_E_Demon_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "7448_ab_starter_J24_T20": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 1
                    },
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_cruel_Rec_Season.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75C"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Monkey_King",
                "subtitle": "skin_hero_Monkey_King_E_Cruel_Rec_Season",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ff765e"
            },
            "bgImage": null
        },
        "skin_marathon_no_sale_epic": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#97AEB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#C68CFF",
                        "time": 0
                    },
                    {
                        "color": "#593F73",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar),
            }
        },
        "skin_marathon_no_sale_season": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#C68CFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": false,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar),
            }
        },
        "skin_marathon_no_sale_season_herocom": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#97AEB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": false,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar),
            }
        },
        "skin_marathon_no_sale_epic_hero_com": {
            "showTooltip": false,
            "offerType": 0,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#97AEB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#C68CFF",
                        "time": 0
                    },
                    {
                        "color": "#593F73",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Plague_Rec_Vampire.RoguelikeAvatar),
            }
        },
        "skin_marathon_no_sale_epic_hero_rare": {
            "showTooltip": false,
            "offerType": 0,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#C68CFF",
                        "time": 0
                    },
                    {
                        "color": "#593F73",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": true,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Cat_Rec_Black.RoguelikeAvatar),
            }
        },
        "skin_marathon_no_sale_season_hero_rare": {
            "showTooltip": false,
            "offerType": 0,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#7297cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54040",
                        "time": 0
                    },
                    {
                        "color": "#732020",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 1,
                "enabled": false,
                "color": "#8cbaff5C"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
            },
            "sale": {
                "enabled": false,
                "colorText": null,
                "colorBG": null,
                "showPercent": null
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Grafitti_Rec_Season.RoguelikeAvatar),
            }
        },
        "epic_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8e65b8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#593f73FF",
                        "time": 0
                    },
                    {
                        "color": "#8e65b8FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#c68cff"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar),
            }
        },
        "legendary_hero": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cfae4c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e5c155FF",
                        "time": 0
                    },
                    {
                        "color": "#736335FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "type": 2,
                "enabled": true,
                "color": "#ffd75e"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar),
            }
        },
        "promo_gideon": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a072cf"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5e4973FF",
                        "time": 1
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#C68CFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "bgImage": null
        },
        "summer_campaign_2024": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#8fb844"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#736335FF",
                        "time": 0
                    },
                    {
                        "color": "#e5bc40FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/SummerEvent/preview_art_offer_SummerCampaign"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffef5e"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": false,
                "glowColor": "#8cbaff",
                "subGlowColor": "#8cbaff",
                "title": "dfdf",
                "subtitle": "fsdfdf",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#8cbaff"
            },
            "bgImage": null,
            "mainImageOverrides": {
                "positionX": 212,
                "positionY": 26,
                "scale": 1.17,
                "glowColor": "#ffffff00"
            },
        },
        "olympic_2024": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#cf604c"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#733e35FF",
                        "time": 1
                    },
                    {
                        "color": "#733e35FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Olympic/preview_art_offer_Olympic"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffd75e"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "bgImage": null,
            "mainImageOverrides": {
                "positionX": 212,
                "positionY": -70,
                "scale": 1.17,
                "glowColor": "#ffffff00"
            },
        },
        "8_march_2026": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Valentine/offer_bg_valentine",
                "color": "#E555ACB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#732a56FF",
                        "time": 0
                    },
                    {
                        "color": "#732a56FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Valentine/offer_art_weapon_chest"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffdd75ff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "weapon_chest",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": 92,
                "scale": null,
                "glowColor": "#00000000"
            },
        },
        "leg_hero_season_skin": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E5C155",
                        "time": 0
                    },
                    {
                        "color": "#736335",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#e54040"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#736335"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Empress_Rec_Season.RoguelikeAvatar),
            }
        },
        "sale_1111": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b8122b"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#E51755FF",
                        "time": 1
                    },
                    {
                        "color": "#8A2762FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#E517555B"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
        },
        "promo_offer_Skich_Store": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#ffffffff"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Features/bg_offer_cinematic_arena",
                "color": "#e5e3d1ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e5d6a8FF",
                        "time": 1
                    },
                    {
                        "color": "#5c2a48FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Samurai_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#e5d6a8FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD100",
                "subGlowColor": "#FFFFFF00",
                "title": "Ling",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#ffedd100"
            }
        },
        "promo_offer_cyberweek": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a347ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#00b881FF",
                        "time": 0
                    },
                    {
                        "color": "#5000a1FF",
                        "time": 0.5
                    },
                    {
                        "color": "#000000FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 0.5
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Gray_skin.RoguelikeAvatar),
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#00ffbb"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "Kibo",
                "subtitle": "skin_hero_Kibo_E_Gray",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#c68cffff"
            },
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000070"
            }
        },
        "promo_widow": {
            "showTooltip": false,
            "offerType": 0,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/WidowEvent/bg_offer_widow",
                "color": "#ffffff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4c778aFF",
                        "time": 0
                    },
                    {
                        "color": "#4c778aFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Widow/preview_art_Widow_base_offer"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#699AB0"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffffff00",
                "subGlowColor": "#ffffff00",
                "title": "Widow",
                "subtitle": "",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#ffffff00"
            },
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "mainImageOverrides": {
                "positionX": 283,
                "positionY": -90,
                "scale": 1.17,
                "glowColor": "#ffffff00"
            }
        },
        "promo_cyberweek_mini_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#00b881FF",
                        "time": 0
                    },
                    {
                        "color": "#5000a1FF",
                        "time": 0.5
                    },
                    {
                        "color": "#000000FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 0.5
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a347ff"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#FF47475B"
            },
        },
        "promo_cyberweek_mini_offer_ArenaOffer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#00b881FF",
                        "time": 0
                    },
                    {
                        "color": "#5000a1FF",
                        "time": 0.5
                    },
                    {
                        "color": "#000000FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 0.5
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#a347ff"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#FF47475B"
            },
        },
        "gift_NY": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#62B4D7"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#388e54FF",
                        "time": 0
                    },
                    {
                        "color": "#388e54FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": null,
            "effectImage": null,
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#ffffffff"
            },
            "mainImageOverrides": null
        },
        "leg_itu_cosmic_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Itu_L_Cosmic/bg_offer_Itu_L_Cosmic",
                "color": "#a347ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#cf3ac0",
                        "time": 0
                    },
                    {
                        "color": "#5000a1FF",
                        "time": 0.5
                    },
                    {
                        "color": "#000000FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 0.5
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Itu_L_Cosmic/art_offer_Itu_L_Cosmic"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#cf3ac0"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "Itu",
                "subtitle": "skin_hero_Itu_L_Cosmic",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#ffd75eff"
            },
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#733ACFff"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000070"
            }
        },
        "leg_lk_castle_hero_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/bg_offer_castle",
                "color": "#677ea1ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4b575cFF",
                        "time": 1
                    },
                    {
                        "color": "#4b575cFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/offer_art_Legion_King_L_Castle",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#a3c8ff67"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffd75e00",
                "subGlowColor": "#FFEDD100",
                "title": "Legion_King",
                "subtitle": "Legendary_skin_tooltip_alias",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffd75eff"
            }
        },
        "leg_lk_castle_horse_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/bg_offer_castle",
                "color": "#677ea1ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4b575cFF",
                        "time": 1
                    },
                    {
                        "color": "#4b575cFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Legion_King_L_Castle/offer_art_Legion_King_L_Castle_horse",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#a3c8ff67"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffd75e00",
                "subGlowColor": "#FFEDD100",
                "title": "Legion_King",
                "subtitle": "Legendary_skin_tooltip_alias",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffd75eff"
            }
        },
        "leg_kibo_eclipse": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#171313FF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Kibo_L_Eclipse/offer_bg_Kibo_L_Eclipse",
                "color": "##CAAEAEFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4b575cFF",
                        "time": 1
                    },
                    {
                        "color": "#4b575cFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Kibo_L_Eclipse/offer_art_Kibo_L_Eclipse",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FF3C1AA3"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD159",
                "subGlowColor": "#FFEDD100",
                "title": "Kibo",
                "subtitle": "Legendary_skin_tooltip_alias",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffedd1"
            }
        },
        "hero_offer_NY": {
            "showTooltip": false,
            "offerType": 0,
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/StarlightEvent/bg_offer_winter",
                "color": "#5ecfff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#6DD477",
                        "time": 0
                    },
                    {
                        "color": "#6DD477",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar),
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#5eff6e"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#225c28ff"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000000"
            }
        },
        "offer_NY": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/StarlightEvent/bg_offer_winter",
                "color": "#5ecfff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#6DD477",
                        "time": 0
                    },
                    {
                        "color": "#6DD477",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#5eff6e"
            },
        },
        "hero_offer_MK": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#D9D9D9FF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Monkey_King_L_Crystal/offer_bg_mk_crystal",
                "color": "#a3baffff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#390e8aff",
                        "time": 1
                    },
                    {
                        "color": "#390e8aff",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Monkey_King_L_Crystal/offer_art_mk_crystal",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#b48cffff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD100",
                "subGlowColor": "#FFEDD100",
                "title": "Monkey_King",
                "subtitle": "Legendary_skin_tooltip_alias",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffd75eff"
            },
        },
        "promo_raikichi": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#33498aFF",
                        "time": 1
                    },
                    {
                        "color": "#33498aFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Raikichi/bg_offer_raikichi",
                "color": "#5e87ffff"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#a3c8ff67"
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Raikichi/offer_art_raikichi",
                "color": null
            },
            "characterText": {
                "enabled": true,
                "glowColor": "#FFFFFF00",
                "subGlowColor": "#FFFFFF00",
                "title": "Raikichi",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#FFFFFF"
            }
        },
        "small_leg_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#FFD75E"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#FFD75E",
                        "time": 0
                    },
                    {
                        "color": "#453A19",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#65b8b8FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#8CBAFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "Itu_GlassBreaking": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#ffffffff"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Features/bg_offer_cinematic_arena",
                "color": "#e5e3d1ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#FFD75E",
                        "time": 1
                    },
                    {
                        "color": "#453A19",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Ling/preview_art_Ling_E_Samurai",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#e5d6a8FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD160",
                "subGlowColor": "#FFFFFF00",
                "title": "Ling",
                "subtitle": "shop_starter_pack_unlock",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#ffedd1ff"
            }
        },
        "small_leg_offer_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#FFD75E"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#453A19",
                        "time": 0
                    },
                    {
                        "color": "#FFD75E",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#65b8b8FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#8CBAFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "promo_nonna": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#B0B0B0FF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Nonna/offer_bg_Nonna",
                "color": "#FFFFFFFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8a251aFF",
                        "time": 1
                    },
                    {
                        "color": "#8a251aFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Nonna/offer_art_Nonna",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#b86f33FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD100",
                "subGlowColor": "#FFEDD100",
                "title": "Nonna",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffedd1ff"
            }
        },
        "promo_nonna_no_sale": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#B0B0B0FF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Nonna/offer_bg_Nonna",
                "color": "#FFFFFFFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8a251aFF",
                        "time": 1
                    },
                    {
                        "color": "#8a251aFF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Nonna/offer_art_Nonna",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#b86f33FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#FFEDD100",
                "subGlowColor": "#FFEDD100",
                "title": "Nonna",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffedd1ff"
            }
        },
        "cycle_weekly_epic_no_sale": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": [
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                },
                {
                    "minColor": "#FFD75E36",
                    "maxColor": "#FFD75EFF"
                }
            ],
            "bgImagePattern": {
                "enabled": true,
                "color": "#A072CF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#5E4973FF",
                        "time": 0
                    },
                    {
                        "color": "#B27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        },
        "meme_67": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#45403FFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#B8AAA7FF",
                        "time": 0
                    },
                    {
                        "color": "#5C5554FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "hero_diwali": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Community/offer_bg_diwali",
                "color": "#9e2ce5"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8A210E",
                        "time": 0
                    },
                    {
                        "color": "#B7206A",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar),
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FFAC30FF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Helga",
                "subtitle": "rare_hero",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#8CBAFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "steam_arena_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#1CA3DDFF"
            },
            "profit": {
                "enabled": false
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": "Sprites/PreviewImages/ArenaLocations/location_crypt"
            },
            "particles": null,
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#111d2eff",
                        "time": 0
                    },
                    {
                        "color": "#111d2eff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Steam/offer_bg_steam",
                "color": "#1286B82E"
            },
        },
        "steam_hero_offer": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Steam/offer_bg_steam",
                "color": "#1286B82E"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#111d2eff",
                        "time": 0
                    },
                    {
                        "color": "#111d2eff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_base_skin.RoguelikeAvatar),
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#1CA3DDFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Bulwark",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#8CBAFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "dsw_hero_offer_big": {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferBig,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Valentine/offer_bg_valentine",
                "color": "#e555acFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#9A6685FF",
                        "time": 0
                    },
                    {
                        "color": "#9A6685FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Valentine/offer_art_Helga_R_Valentine"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffdd75ff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Helga",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000021"
            }
        },
        "dsw_wpn_hero_offer_big": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#1a98ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#1a98ffFF",
                        "time": 1
                    },
                    {
                        "color": "#894A77FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Gladiator_Rec_Holi.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#EE78CC67"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Ironclad",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            }
        },
        "dsw_wpn_hero_base_offer_big": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#1a98ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#1a98ffFF",
                        "time": 1
                    },
                    {
                        "color": "#894A77FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar),
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#EE78CC67"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "Ironclad",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            }
        },
        "free_wpn_steam": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Steam/offer_bg_steam",
                "color": "#1286B82E"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#111d2eff",
                        "time": 0
                    },
                    {
                        "color": "#111d2eff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Lottery/UniversalRoulette/preview_wpn_Bulwark_R_Base_Rec_Steam"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#1CA3DDFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "wpn_Bulwark_R_Base_Rec_Steam_name",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#8CBAFFFF"
            },
            "mainImageOverrides": {
                "positionX": 320,
                "positionY": -80,
                "scale": 0.9,
                "glowColor": "#0000005E"
            }
        },
        "tokens_for_login_on_steam": {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": false,
                "sprite": "",
                "color": "#FFFFFF00"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#225c30",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": false,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": false,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#1CA3DDFF"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": null,
            "mainImageOverrides": null
        },
        "beatuiful_Itu": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/Assets/Decor/Offers/offer_surface_pattern_Itu",
                "color": "#278a8aB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#357373FF",
                        "time": 0
                    },
                    {
                        "color": "#357373FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Itu/preview_art_Itu_offer"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#47ffffff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#00000000"
            }
        },
        "sakura_weapon_base": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/SakuraEvent/bg_offer_sakura_weapons",
                "color": "#FFFFFFFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#3f528aFF",
                        "time": 0
                    },
                    {
                        "color": "#593f73FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/SakuraEvent/wpn_Itu_R_Base_Rec_Sakura"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FDBCDD41"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "wpn_Itu_R_Base_Rec_Sakura",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": 380,
                "positionY": -20,
                "scale": 0.9,
                "glowColor": "#ffffff00"
            }
        },
        "sakura_hero_base": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#e57e9dFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#3f528aFF",
                        "time": 0
                    },
                    {
                        "color": "#593f73FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FDBCDD41"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "sakura_common_base": {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#e57e9dFF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#3f528aFF",
                        "time": 0
                    },
                    {
                        "color": "#593f73FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FDBCDD41"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "expensive_lynx_leg_skin": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#4D4A57"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#170100",
                        "time": 1
                    },
                    {
                        "color": "#170100",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Lynx_L_Hood/art_event_Lynx_L_Hood"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#5C0500"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000045",
                "subGlowColor": "#00000000",
                "title": "Lynx",
                "subtitle": "unlock_hero",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#fffd75"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1.3,
                "glowColor": "#ffffff00"
            }
        },
        "kibo_offer_beatiful": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Community/offer_bg_kibo",
                "color": "#FFFFFFB8"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#44a6b8ff",
                        "time": 0
                    },
                    {
                        "color": "#112a2eff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Community/preview_art_Kibo_offer"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#47ffffff"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Kibo",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": 380,
                "positionY": 70,
                "scale": 0.85,
                "glowColor": "#0000004C"
            }
        },
        "butcher_event_square": {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f5c73FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8a272cFF",
                        "time": 0
                    },
                    {
                        "color": "#3f5c73FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "butcher_event_narrow": {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f5c73FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8a272cFF",
                        "time": 0
                    },
                    {
                        "color": "#3f5c73FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "earth_day": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/EarthDay/offer_bg_earth_day",
                "color": "#ffffff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#225c28",
                        "time": 1
                    },
                    {
                        "color": "#225c28",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/EarthDay/offer_art_earth_day"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#5eff6e"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#fffd75"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1,
                "glowColor": "#ffffff00"
            }
        },
        "labor_event_square": {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b8a365FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#575A26FF",
                        "time": 0
                    },
                    {
                        "color": "#b8a776FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FDBCDD41"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "labor_event_narrow": {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#b8a365FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#575A26FF",
                        "time": 0
                    },
                    {
                        "color": "#b8a776FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#FDBCDD41"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "offer_hero_L_Bull": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#337cb8FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8F7F4FFF",
                        "time": 0
                    },
                    {
                        "color": "#091e5cFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "offer_simple_L_Bull": {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#337cb8FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#8F7F4FFF",
                        "time": 0
                    },
                    {
                        "color": "#091e5cFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "offer_Ironclad_L_Bull": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Ironclad_L_Bull/offer_bg_ironclad_l_bull",
                "color": "#b85b33"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#1a588a",
                        "time": 1
                    },
                    {
                        "color": "#1a588a",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Ironclad_L_Bull/offer_art_ironclad_l_bull"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffe8a3"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "Ironclad",
                "subtitle": "subtitle_promo_offer_Lynx_L",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#fffd75"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1,
                "glowColor": "#0000004C"
            }
        },
        "leg_event_hero_Gideon": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#B8B8B8FF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#ffd75e"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4b575cff",
                        "time": 0
                    },
                    {
                        "color": "#97aeb8ff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "leg_event": {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#ffd75e"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#97aeb8ff",
                        "time": 0
                    },
                    {
                        "color": "#97aeb8ff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        "offer_Ironclad_L_Bull_without_sub": {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Ironclad_L_Bull/offer_bg_ironclad_l_bull",
                "color": "#b85b33"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#1a588a",
                        "time": 1
                    },
                    {
                        "color": "#1a588a",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Ironclad_L_Bull/offer_art_ironclad_l_bull"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#ffe8a3"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#FFFFFF"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1,
                "glowColor": "#0000004C"
            }
        },
        offer_hero_vampires_Gideon: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f4473ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#88242aff",
                        "time": 0
                    },
                    {
                        "color": "#3f212cff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_vampires: {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f4473ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54049",
                        "time": 0
                    },
                    {
                        "color": "#e54049",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_vampires_small: {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f4473ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54049",
                        "time": 0
                    },
                    {
                        "color": "#e54049",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_vampires_vs: {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.VersusCutOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f4473ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#e54049",
                        "time": 0
                    },
                    {
                        "color": "#e54049",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_wpn_Midnight_E_Feather: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#3f4473ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#88242aff",
                        "time": 0
                    },
                    {
                        "color": "#3f212cff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Lottery/Lottery_NewVampires/Roulette_NewVampires_Art"
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": 380,
                "positionY": -70,
                "scale": 0.846,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_midsommar: {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A2D775"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#649F55FF",
                        "time": 0
                    },
                    {
                        "color": "#B39437FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_small_midsommar: {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A2D775"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#649F55FF",
                        "time": 0
                    },
                    {
                        "color": "#B39437FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_hero_midsommar: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A2D775"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#649F55FF",
                        "time": 1
                    },
                    {
                        "color": "#B39437FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "subTitle": null,
            "iconsDescription": null,
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Helga/preview_art_Helga_base",
                "color": null
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#97aeb867"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#ffedd100",
                "subGlowColor": "#ffedd100",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#8cbaff"
            }
        },
        offer_hero_feldsher_rework: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Feldsher/offer_bg_feldsher",
                "color": "#337d8a"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#224a5c",
                        "time": 1
                    },
                    {
                        "color": "#224a5c",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Feldsher/offer_art_feldsher"
            },
            "effectImage": {
                "enabled": true,
                "type": 1,
                "color": "#55d0e5"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "Feldsher",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffffff00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1,
                "glowColor": "#0000004C"
            }
        },
        offer_simple_feldsher_rework: {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#54a9b8ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#423f73",
                        "time": 1
                    },
                    {
                        "color": "#423f73",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_narrow_feldsher_rework: {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#54a9b8ff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#423f73",
                        "time": 1
                    },
                    {
                        "color": "#423f73",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        april_hero: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4C94CFFF",
                        "time": 0
                    },
                    {
                        "color": "#2A455CFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        april_basic: {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4484B8FF",
                        "time": 0
                    },
                    {
                        "color": "#A27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        april_narrow: {
            "showTooltip": false,
            "offerType": 3,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4484B8FF",
                        "time": 0
                    },
                    {
                        "color": "#A27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        april_vs: {
            "showTooltip": false,
            "offerType": 4,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4484B8FF",
                        "time": 0
                    },
                    {
                        "color": "#A27EE5FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_april_event_wpn_Feldsher_E_Diver_alias: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#A27EE5FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#4C94CFFF",
                        "time": 0
                    },
                    {
                        "color": "#2A455CFF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/AprilEvent/preview_wpn_Feldsher_E_Diver"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Feldsher",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": 340,
                "positionY": -26,
                "scale": 0.8,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_Shogun_small: {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#4b4d5cff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#652115FF",
                        "time": 1
                    },
                    {
                        "color": "#B43A25FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_simple_Shogun_big: {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.ArenaOffer,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#4b4d5cff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#652115FF",
                        "time": 1
                    },
                    {
                        "color": "#B43A25FF",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#3f5c7341"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        offer_hero_Shogun_2: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Shogun/offer_bg_shogun",
                "color": "#ffffff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#491b13ff",
                        "time": 0
                    },
                    {
                        "color": "#491b13ff",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Events/Shogun/offer_art_shogun"
            },
            "effectImage": {
                "enabled": false,
                "type": 2,
                "color": "#979ab8"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Shogun",
                "subtitle": "legendary_hero",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#ffd75eff"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#0000003D"
            }
        },
        offer_toffee_pay: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#ffffffff"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Advertising/Toffee/offer_bg_toffee",
                "color": "#5e87ffff"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#6758a1",
                        "time": 1
                    },
                    {
                        "color": "#6758a1",
                        "time": 0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Advertising/Toffee/offer_art_toffee"
            },
            "effectImage": {
                "enabled": true,
                "type": 2,
                "color": "#B6A3FF91"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#00000000",
                "subGlowColor": "#00000000",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF",
                "subTitleColor": "#ffffff00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": 1,
                "glowColor": "#00000000"
            }
        },
        event_viper_basic: {
            "showTooltip": false,
            "offerType": 1,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#2CE592FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#A1842DFF",
                        "time": 0
                    },
                    {
                        "color": "#2CE592FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        event_viper_small: {
            "showTooltip": false,
            "offerType": OFFER_PREFAB_TYPE.OfferSmall,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#2CE592FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#A1842DFF",
                        "time": 0
                    },
                    {
                        "color": "#2CE592FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": false,
                "sprite": ""
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "empty",
                "subtitle": "empty",
                "titleColor": "#FFFFFF00",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
        event_viper_hero_offer: {
            "showTooltip": false,
            "offerType": 0,
            "bgImage": {
                "enabled": true,
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#FFFFFFFF"
            },
            "bgImagePattern": {
                "enabled": true,
                "sprite": "",
                "color": "#FFD147FF"
            },
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#23B875FF",
                        "time": 0
                    },
                    {
                        "color": "#B8A923FF",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "header": {
                "enabled": true,
                "color": "#FFFFFFFF",
                "saleInsteadName": false
            },
            "profit": {
                "enabled": true,
                "colorText": "#73612AFF",
                "colorBG": "#FFD75EFF"
            },
            "sale": {
                "enabled": true,
                "colorText": "#FFFFFF",
                "colorBG": "#FF4747FF",
                "showPercent": true
            },
            "mainImage": {
                "enabled": true,
                "sprite": "Sprites/PreviewImages/Heroes/Gideon/Base/preview_art_Gideon_base"
            },
            "effectImage": {
                "enabled": false,
                "type": 1,
                "color": "#65b8b800"
            },
            "particles": null,
            "additionalText": null,
            "labelValue": null,
            "additionalImages": null,
            "characterText": {
                "enabled": true,
                "glowColor": "#8cbaff00",
                "subGlowColor": "#8cbaff00",
                "title": "Gideon",
                "subtitle": "empty",
                "titleColor": "#FFFFFFFF",
                "subTitleColor": "#FFFFFF00"
            },
            "mainImageOverrides": {
                "positionX": null,
                "positionY": null,
                "scale": null,
                "glowColor": "#ffffff00"
            }
        },
    };
    PromoOfferVisualPresets.presets = {
        "42": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["40"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_R_Rec_Boss_skin.RoguelikeAvatar)),
        "44": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["40"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_R_Rec_Boss.RoguelikeAvatar)),
        "boss_Sarge_E_Jailer_Rec_Boss": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Jailer_Rec_Boss.RoguelikeAvatar)),
        "boss_Helga_E_Phoenix_Rec_Boss_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Phoenix_Rec_Boss_skin.RoguelikeAvatar)),
        "703": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["702"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar)),
        "704": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["702"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone.RoguelikeAvatar)),
        "705": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["702"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_R_Purple.RoguelikeAvatar)),
        "706": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["702"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)),
        "707": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["702"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar)),
        "1348": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Original.RoguelikeAvatar)),
        "1349": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Oriental_skin.RoguelikeAvatar)),
        "1351": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Ghost.RoguelikeAvatar)),
        "1352": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Doomed_skin.RoguelikeAvatar)),
        "1354": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Mogwai.RoguelikeAvatar)),
        "1389": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_R_Red.RoguelikeAvatar)),
        "boos_Monk_E_Cursed_Rec_Creepy": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Cursed_Rec_Creepy.RoguelikeAvatar)),
        "1600": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_R_Hazy.RoguelikeAvatar)),
        "5003": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar)),
        "5004": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_base_skin.RoguelikeAvatar)),
        "5005": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)),
        "offer_with_image_rare_Viper": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar)),
        "offer_with_image_com_Ironclad": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar)),
        "offer_with_image_rare_Viper_R_base_Rec_Brat": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_R_base_Rec_Brat.RoguelikeAvatar)),
        "offer_with_image_com_alias_Ironclad": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar), heroes.Ironclad.Alias),
        "offer_with_image_rare_Jet": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_base_skin.RoguelikeAvatar)),
        "offer_with_image_com_Feldsher": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar)),
        "offer_with_image_com_alias_Feldsher": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar), heroes.Feldsher.Alias),
        "5011": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar)),
        "offer_with_image_alias_Sarge": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar), heroes.Sarge.Alias),
        "offer_with_image_alias_Viper": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar), heroes.Viper.Alias),
        "offer_hero_midsommar_Sarge_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_midsommar"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar), heroes.Sarge.Alias),
        "offer_with_image_alias_Jet": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_base_skin.RoguelikeAvatar), heroes.Jet.Alias),
        "offer_with_image_alias_Helga": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar), heroes.Helga.Alias),
        "5012": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)),
        "5013": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar)),
        "offer_with_image_alias_Yunlin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar), heroes.Yunlin.Alias),
        "offer_with_image_alias_Yukka": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar), heroes.Yukka.Alias),
        "offer_with_image_alias_Ling": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_Base_skin.RoguelikeAvatar), heroes.Ling.Alias),
        "offer_with_image_alias_Monk": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar), heroes.Monk.Alias),
        "offer_with_image_alias_Fireguard": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_base_skin.RoguelikeAvatar), heroes.Fireguard.Alias),
        "offer_with_image_alias_Liquidator": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_base_skin.RoguelikeAvatar), heroes.Liquidator.Alias),
        "offer_with_image_alias_Bulwark": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_base_skin.RoguelikeAvatar), heroes.Bulwark.Alias),
        "offer_with_image_alias_HongJoo": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar), heroes.HongJoo.Alias),
        "offer_with_image_HongJoo_E_Pilgrim": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Pilgrim.RoguelikeAvatar)),
        "offer_with_image_com_Monk": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Monkey_King": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Monkey_King_E_Stranger": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Stranger.RoguelikeAvatar)),
        "offer_with_image_leg_Monkey_King_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar), heroes.Monkey_King.Alias),
        "offer_with_image_leg_Itu": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Itu_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar), heroes.Itu.Alias),
        "5039": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)),
        "offer_with_image_rare_Ling": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_Base_skin.RoguelikeAvatar)),
        "5017": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)),
        "offer_with_image_com_Fireguard": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_base_skin.RoguelikeAvatar)),
        "offer_with_image_rare_HongJoo": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar)),
        "5120": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar)),
        "5125": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)),
        "5132": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar)),
        "5135": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar)),
        "5136": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)),
        "5137": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar)),
        "5138": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_base_skin.RoguelikeAvatar)),
        "Widow_E_Night_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_E_Night.RoguelikeAvatar)),
        "Legion_King_E_Prince_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince.RoguelikeAvatar)),
        "Midnight_E_Assassin_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Assassin.RoguelikeAvatar)),
        "Monkey_King_E_Sylvan_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Sylvan.RoguelikeAvatar)),
        "Gideon_E_Mask_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Mask.RoguelikeAvatar)),
        "Raikichi_E_Burned_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_E_Burned.RoguelikeAvatar)),
        "Gideon_E_Cowboy_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Cowboy.RoguelikeAvatar)),
        "Emperor_R_Cyan_skin_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_R_Cyan_skin.RoguelikeAvatar)),
        "Itu_E_Demon_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Demon.RoguelikeAvatar)),
        "Itu_E_Master_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Master.RoguelikeAvatar)),
        "cyberweek_hero_Sarge_R_Dark": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_R_Dark.RoguelikeAvatar)),
        "cyberweek_hero_Itu_R_Star": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_R_Star.RoguelikeAvatar)),
        "Butcher_E_Mogwai_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Mogwai.RoguelikeAvatar)),
        "5139": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_base_skin.RoguelikeAvatar)),
        "5180": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Legion_King_R_Viny": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_R_Viny.RoguelikeAvatar)),
        "offer_with_image_leg_June": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_June_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar), heroes.June.Alias),
        "boss_Legion_King_E_Bone_Rec_Lich": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone_Rec_Lich.RoguelikeAvatar)),
        "offer_with_image_leg_Nonna": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Nonna_E_Valkyriea": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_E_Valkyrie.RoguelikeAvatar)),
        "offer_with_image_leg_Shogun": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Shogun_Base_skin.RoguelikeAvatar)),
        "offer_with_image_leg_Nonna_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_base_skin.RoguelikeAvatar), heroes.Nonna.Alias),
        "offer_with_image_leg_LK_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_leg_LK"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar), heroes.Legion_King.Alias),
        "promo_cards_epic": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cycle_weekly_epic"], "Sprites/PreviewImages/ArenaLocations/location_crypt"),
        "1440_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["40"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar)),
        "1446_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["40"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_base_skin.RoguelikeAvatar)),
        "1573_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["40"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar)),
        "5011_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5013_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar)),
        "5019_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5013_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar)),
        "5120_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar)),
        "5132_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5013_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar)),
        "5135_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar)),
        "Gideon_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar)),
        "Widow_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_base_skin.RoguelikeAvatar)),
        "Raikichi_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_base_skin.RoguelikeAvatar)),
        "Nonna_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_base_skin.RoguelikeAvatar)),
        "june_no_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar)),
        "boss_Emperor_E_Doomed_Rec_Enlighten_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Doomed_Rec_Enlighten_skin.RoguelikeAvatar)),
        "epic_hero_emperor": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)),
        "epic_hero_Emperor_R_Cyan_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_R_Cyan_skin.RoguelikeAvatar)),
        "epic_hero_Kibo_R_Rose_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_R_Rose_skin.RoguelikeAvatar)),
        "epic_hero_Midnight": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar)),
        "epic_hero_Marcus_E_Veteran_Rec_Nouveau_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Veteran_Rec_Nouveau_skin.RoguelikeAvatar)),
        "lynx_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)),
        "widow_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_base_skin.RoguelikeAvatar)),
        "offer_hero_L_Bull_Ironclad_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_L_Bull"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar), heroes.Ironclad.Alias),
        "xiang_Tzu_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar)),
        "marcus_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)),
        "epic_hero_Marcus_R_Winy_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_R_Winy_skin.RoguelikeAvatar)),
        "epic_hero_Midnight_R_Blue": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_R_Blue.RoguelikeAvatar)),
        "epic_hero_kibo": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)),
        "boss_Bulwark_E_Gold_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["boss_Ironclad_E_Rust_Rec_Boss"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Gold_skin.RoguelikeAvatar)),
        "feldsher_suit_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Suit_skin.RoguelikeAvatar)),
        "feldsher_suit_marathon_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Suit_skin.RoguelikeAvatar), heroes.Feldsher.Alias),
        "ironclad_rust_marathon_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Rust.RoguelikeAvatar), heroes.Ironclad.Alias),
        "last_day_leg_Monkey_King_E_Sylvan": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Sylvan.RoguelikeAvatar)),
        "helga_vampire_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Vampire.RoguelikeAvatar)),
        "ling_ronin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin.RoguelikeAvatar)),
        "Liqui_forged_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged.RoguelikeAvatar)),
        "Helga_E_Phoenix_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Phoenix_skin.RoguelikeAvatar)),
        "skin_marathon_no_sale_Helga_E_Paladin_skin_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Paladin_skin.RoguelikeAvatar), heroes.Helga.Alias),
        "Viper_E_Mobster_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Mobster.RoguelikeAvatar)),
        "Viper_graffiti_mar": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Grafitti.RoguelikeAvatar)),
        "Jet_E_Burglar_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Burglar.RoguelikeAvatar)),
        "Bulwark_Snow_mar": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Snow_skin.RoguelikeAvatar)),
        "Monk_Royal_Rec_Gold_mar": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Royal_Rec_Gold.RoguelikeAvatar)),
        "june_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar)),
        "mk_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar)),
        "midnight_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar)),
        "emperor_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)),
        "marcus_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)),
        "gideon_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar)),
        "lynx_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)),
        "kibo_sale": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["5277"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)),
        "hongjoo_piligrim_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Pilgrim.RoguelikeAvatar)),
        "sarge_viking_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Viking.RoguelikeAvatar)),
        "yunlin_bride_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride.RoguelikeAvatar)),
        "yunlin_e_winter_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Winter.RoguelikeAvatar)),
        "promo_gideon_mask": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["promo_gideon"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Mask.RoguelikeAvatar)),
        "monk_creepy_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Cursed_Rec_Creepy.RoguelikeAvatar)),
        "ironclad_fervor_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Fervor.RoguelikeAvatar)),
        "ling_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_Base_skin.RoguelikeAvatar)),
        "bulw_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_base_skin.RoguelikeAvatar)),
        "marc_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar)),
        "kibo_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar)),
        "feld_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar)),
        "ironclad_sale_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar)),
        "widow_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_base_skin.RoguelikeAvatar)),
        "gideon_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar)),
        "vipe_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar)),
        "liqu_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_base_skin.RoguelikeAvatar)),
        "lk_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar)),
        "empe_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)),
        "lynx_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar)),
        "itu_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar)),
        "hong_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar)),
        "mk_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar)),
        "sarge_sale_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar)),
        "raikichi_sale_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_base_skin.RoguelikeAvatar)),
        "jet_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_base_skin.RoguelikeAvatar)),
        "monk_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar)),
        "yunl_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar)),
        "fire_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_base_skin.RoguelikeAvatar)),
        "midnight_sale_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar)),
        "nonna_sale_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_base_skin.RoguelikeAvatar)),
        "xiang_tzu_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar)),
        "Ling_E_Ronin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin.RoguelikeAvatar)),
        "Ling_E_Ronin_Rec_Black_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin_Rec_Black.RoguelikeAvatar)),
        "Lynx_E_Mafia_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Mafia.RoguelikeAvatar)),
        "Kibo_E_Gray_Rec_Venom_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Gray_Rec_Venom.RoguelikeAvatar)),
        "Butcher_E_Khan_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Khan.RoguelikeAvatar)),
        "Jet_E_Nomad_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Nomad.RoguelikeAvatar)),
        "Jet_E_Burglar_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Burglar.RoguelikeAvatar)),
        "Jet_E_Water_Rec_Pink_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Water_Rec_Pink.RoguelikeAvatar)),
        "HongJoo_E_Cupid_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Cupid.RoguelikeAvatar)),
        "Xiang_Tzu_E_Winner_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Winner.RoguelikeAvatar)),
        "Viper_E_Grafitti_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Grafitti.RoguelikeAvatar)),
        "Emperor_E_Dragon_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Dragon_skin.RoguelikeAvatar)),
        "Emperor_E_Doomed_Rec_Enlighten_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Doomed_Rec_Enlighten_skin.RoguelikeAvatar)),
        "Itu_E_Demon_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Demon.RoguelikeAvatar)),
        "Itu_E_Master_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Master.RoguelikeAvatar)),
        "Monk_E_Cursed_Rec_Creepy_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Cursed_Rec_Creepy.RoguelikeAvatar)),
        "Monk_E_Moth_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Moth.RoguelikeAvatar)),
        "sale_1111_Marcus_E_Magma_skin_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Magma_skin.RoguelikeAvatar), heroes.Marcus.Alias),
        "sale_1111_Emperor_E_Dragon_Rec_Orange_skin_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Dragon_Rec_Orange_skin.RoguelikeAvatar), heroes.Emperor.Alias),
        "sale_1111_HongJoo_E_Cupid_Rec_Dark_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Cupid_Rec_Dark.RoguelikeAvatar), heroes.HongJoo.Alias),
        "sale_1111_Widow_R_Seer_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_R_Seer.RoguelikeAvatar), heroes.Widow.Alias),
        "sale_1111_Midnight_E_Witch_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Witch.RoguelikeAvatar), heroes.Midnight.Alias),
        "sale_1111_Lynx_E_Original_Rec_White_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Original_Rec_White.RoguelikeAvatar), heroes.Lynx.Alias),
        "sale_1111_Marcus_E_Royal_skin_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Royal_skin.RoguelikeAvatar), heroes.Marcus.Alias),
        "sale_1111_Raikichi_R_Base_Rec_Inky_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_R_Base_Rec_Inky.RoguelikeAvatar), heroes.Raikichi.Alias),
        "Midnight_E_Assassin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Assassin.RoguelikeAvatar)),
        "sale_1111_Widow_E_Bonemoth_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_E_Bonemoth.RoguelikeAvatar), heroes.Widow.Alias),
        "sale_1111_Xiang_Tzu_E_Indian_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Indian.RoguelikeAvatar), heroes.Xiang_Tzu.Alias),
        "Xiang_Tzu_E_Reiver_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Reiver.RoguelikeAvatar)),
        "Xiang_Tzu_E_Reiver_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Reiver.RoguelikeAvatar)),
        "cyberweek_hero_Butcher_E_Khan": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Khan.RoguelikeAvatar)),
        "Ling_E_Ronin_Rec_Black_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin_Rec_Black.RoguelikeAvatar)),
        "cyberweek_hero_Feldsher_E_Suit_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Suit_skin.RoguelikeAvatar)),
        "cyberweek_hero_Monk_E_Cursed": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Cursed.RoguelikeAvatar)),
        "Kibo_E_Gray_Rec_Venom_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Gray_Rec_Venom.RoguelikeAvatar)),
        "cyberweek_hero_Gideon_E_Forwarder": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Forwarder.RoguelikeAvatar)),
        "cyberweek_hero_Jet_E_Burglar": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Burglar.RoguelikeAvatar)),
        "cyberweek_hero_Ironclad_E_Rust": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Rust.RoguelikeAvatar)),
        "Gideon_E_Forwarder_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Forwarder.RoguelikeAvatar)),
        "Kibo_E_Crane_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Crane_skin.RoguelikeAvatar)),
        "Yukka_E_Cat_Rec_Black_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Cat_Rec_Black.RoguelikeAvatar)),
        "Yukka_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar)),
        "Yukka_E_Wayfarer_Rec_Flower_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Wayfarer_Rec_Flower.RoguelikeAvatar)),
        "Yukka_E_Rebel_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Rebel.RoguelikeAvatar)),
        "Bulwark_E_Snow_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Snow_skin.RoguelikeAvatar)),
        "Bulwark_E_Clover_Rec_Chill_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Clover_Rec_Chill.RoguelikeAvatar)),
        "Bulwark_E_Ivy_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Ivy.RoguelikeAvatar)),
        "Raikichi_E_Burned_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_E_Burned.RoguelikeAvatar)),
        "Ironclad_E_Rust_Rec_Boss_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Rust_Rec_Boss.RoguelikeAvatar)),
        "Ironclad_E_Gladiator_Rec_Holi_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Gladiator_Rec_Holi.RoguelikeAvatar)),
        "Viper_E_Mobster_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Mobster.RoguelikeAvatar)),
        "Yunlin_E_Bride_Rec_Indian_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride_Rec_Indian.RoguelikeAvatar)),
        "Marcus_E_Veteran_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Veteran_skin.RoguelikeAvatar)),
        "Marcus_E_Lord_Rec_Fall_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Lord_Rec_Fall_skin.RoguelikeAvatar)),
        "Sarge_E_Chitin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Chitin.RoguelikeAvatar)),
        "Sarge_E_Viking_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Viking.RoguelikeAvatar)),
        "Sarge_E_Jailer_Rec_Boss_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Jailer_Rec_Boss.RoguelikeAvatar)),
        "Sarge_E_Chitin_Rec_Winter_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Chitin_Rec_Winter.RoguelikeAvatar)),
        "Monkey_King_E_Sylvan_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Sylvan.RoguelikeAvatar)),
        "Monkey_King_E_Dragon_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Dragon.RoguelikeAvatar)),
        "Lynx_E_Original_Rec_White_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Original_Rec_White.RoguelikeAvatar)),
        "Legion_King_E_Bone_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone.RoguelikeAvatar)),
        "Legion_King_E_Bone_Rec_Lich_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone_Rec_Lich.RoguelikeAvatar)),
        "Butcher_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar)),
        "Liquidator_E_Forged_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged.RoguelikeAvatar)),
        "Liquidator_S_Gold_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_S_Gold.RoguelikeAvatar)),
        "Helga_E_Phoenix_Rec_Boss_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Phoenix_Rec_Boss_skin.RoguelikeAvatar)),
        "Helga_E_Phoenix_Rec_Glory_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Phoenix_Rec_Glory.RoguelikeAvatar)),
        "Midnight_E_Witch_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Witch.RoguelikeAvatar)),
        "Butcher_E_Mogwai_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Mogwai.RoguelikeAvatar)),
        "HongJoo_E_Equilibrist_Rec_Sakura_skin_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Equilibrist_Rec_Sakura_skin.RoguelikeAvatar)),
        "June_E_Sakura_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Sakura.RoguelikeAvatar)),
        "June_E_Empress_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Empress.RoguelikeAvatar)),
        "Feldsher_E_Plague_Rec_Vampire_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Plague_Rec_Vampire.RoguelikeAvatar)),
        "Feldsher_E_Diver_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_Rec_Star_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain_Rec_Star.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain.RoguelikeAvatar)),
        "Gideon_E_Mask_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Mask.RoguelikeAvatar)),
        "Midnight_E_Assassin_Rec_White_1111": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Assassin_Rec_White.RoguelikeAvatar)),
        "sale_1111_June_R_Star": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.June_R_Star.RoguelikeAvatar)),
        "sale_1111_Jet_E_Golden": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Golden.RoguelikeAvatar)),
        "sale_1111_Monk_E_Royal_Rec_Gold": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Royal_Rec_Gold.RoguelikeAvatar)),
        "sale_1111_Gideon_E_Cowboy": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Cowboy.RoguelikeAvatar)),
        "sale_1111_Nonna_R_Celtic_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sale_1111"], "Sprites/PreviewImages/Heroes/".concat(skins.Nonna_R_Celtic.RoguelikeAvatar), heroes.Nonna.Alias),
        "Kibo_E_Crane_skin_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Crane_skin.RoguelikeAvatar)),
        "Bulwark_E_Ivy_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Ivy.RoguelikeAvatar)),
        "Midnight_E_Assassin_Rec_White_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Assassin_Rec_White.RoguelikeAvatar)),
        "Sarge_E_Chitin_Rec_Winter_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Chitin_Rec_Winter.RoguelikeAvatar)),
        "Legion_King_E_Bone_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone.RoguelikeAvatar)),
        "Marcus_E_Veteran_skin_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Veteran_skin.RoguelikeAvatar)),
        "Lynx_R_base_Rec_Fancy_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_R_base_Rec_Fancy.RoguelikeAvatar)),
        "NY_Widow": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_base_skin.RoguelikeAvatar)),
        "NY_Ironclad_E_Fervor": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Fervor.RoguelikeAvatar)),
        "NY_Xiang_Tzu_E_Indian": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Indian.RoguelikeAvatar)),
        "NY_June_E_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Sakura.RoguelikeAvatar)),
        "NY_Widow_E_Bonemoth": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_E_Bonemoth.RoguelikeAvatar)),
        "NY_Raikichi_E_Burned": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_E_Burned.RoguelikeAvatar)),
        "NY_Legion_King": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar)),
        "NY_Monkey_King_E_Dragon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Dragon.RoguelikeAvatar)),
        "NY_Midnight_E_Assassin_Rec_White": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["hero_offer_NY"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Assassin_Rec_White.RoguelikeAvatar)),
        "feldsher_diver_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver.RoguelikeAvatar)),
        "skin_marathon_no_sale_alias_Sarge_E_Chitin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Chitin.RoguelikeAvatar), heroes.Sarge.Alias),
        "skin_marathon_no_sale_alias_HongJoo_E_Equilibrist": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Equilibrist_skin.RoguelikeAvatar), heroes.HongJoo.Alias),
        "skin_marathon_no_sale_alias_Ling_E_Samurai": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Samurai_skin.RoguelikeAvatar), heroes.Ling.Alias),
        "skin_marathon_no_sale_alias_Monk_E_Moth": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Samurai_skin.RoguelikeAvatar), heroes.Monk.Alias),
        "skin_marathon_no_sale_Yukka_E_Cat_Rec_Black_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Cat_Rec_Black.RoguelikeAvatar), heroes.Yukka.Alias),
        "Yukka_E_Rebel_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Rebel.RoguelikeAvatar)),
        "Ling_E_Raven_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Raven.RoguelikeAvatar)),
        "HongJoo_E_Cupid_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Cupid.RoguelikeAvatar)),
        "Sarge_E_Jailer_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Jailer.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain.RoguelikeAvatar)),
        "Fireguard_E_White_Rec_Void_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_White_Rec_Void.RoguelikeAvatar)),
        "Bulwark_E_Clover_Rec_Chill_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Clover_Rec_Chill.RoguelikeAvatar)),
        "Helga_E_Phoenix_Rec_Glory_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Phoenix_Rec_Glory.RoguelikeAvatar)),
        "Bulwark_E_Gold_skin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Gold_skin.RoguelikeAvatar)),
        "Monkey_King_E_Sylvan_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Sylvan.RoguelikeAvatar)),
        "Monkey_King_E_Dragon_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_Dragon.RoguelikeAvatar)),
        "Monkey_King_E_cruel_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_cruel.RoguelikeAvatar)),
        "June_E_Sakura_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Sakura.RoguelikeAvatar)),
        "Itu_E_Master_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_E_Master.RoguelikeAvatar)),
        "June_E_Empress_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Empress.RoguelikeAvatar)),
        "Legion_King_E_Bone_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Bone.RoguelikeAvatar)),
        "Legion_King_E_Prince_last_day_leg": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["last_day_leg"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince.RoguelikeAvatar)),
        "Jet_E_Golden_skin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Golden.RoguelikeAvatar)),
        "Jet_E_Burglar_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Burglar.RoguelikeAvatar)),
        "Widow_E_Bonemoth_last_day_epic": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_E_Bonemoth.RoguelikeAvatar)),
        "Kibo_E_Gray_skin_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_E_Gray_skin.RoguelikeAvatar)),
        "Marcus_E_Lord_skin_last_day_epic": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_E_Lord_skin.RoguelikeAvatar)),
        "epic_hero_Lynx_E_Original": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Original.RoguelikeAvatar)),
        "Jet_E_Water_skin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Water.RoguelikeAvatar)),
        "Jet_R_base_Rec_Purple_skin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_R_base_Rec_Purple.RoguelikeAvatar)),
        "Jet_E_Nomad_skin_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Nomad.RoguelikeAvatar)),
        "Liquidator_E_Valkyrie_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Valkyrie.RoguelikeAvatar)),
        "Yunlin_E_Bride_Rec_Indian_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride_Rec_Indian.RoguelikeAvatar)),
        "Ling_E_Ronin_Rec_Black_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin_Rec_Black.RoguelikeAvatar)),
        "Liquidator_E_Forged_Rec_Joust_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged_Rec_Joust.RoguelikeAvatar)),
        "Bulwark_E_Ivy_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Ivy.RoguelikeAvatar)),
        "epic_hero_butcher": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar)),
        "epic_hero_Gideon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar)),
        "epic_hero_Gideon_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar), heroes.Gideon.Alias),
        "Butcher_epic_hero_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["epic_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar), heroes.Butcher.Alias),
        "Fireguard_E_Cyber_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Cyber.RoguelikeAvatar)),
        "Fireguard_E_Cyber_Rec_Green_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_com"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Cyber_Rec_Green.RoguelikeAvatar)),
        "Yukka_E_Wayfarer_Rec_Flower_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Wayfarer_Rec_Flower.RoguelikeAvatar)),
        "Yukka_E_Wayfarer_marathon": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_E_Wayfarer.RoguelikeAvatar)),
        "Gideon_E_Forwarder_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_E_Forwarder.RoguelikeAvatar)),
        "HongJoo_E_Cupid_Rec_Dark_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Cupid_Rec_Dark.RoguelikeAvatar)),
        "Lynx_E_Mafia_Rec_Violet_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Mafia_Rec_Violet.RoguelikeAvatar)),
        "Feldsher_E_Diver_Rec_Heated_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver_Rec_Heated.RoguelikeAvatar)),
        "Xiang_Tzu_E_Indian_Rec_White_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_E_Indian_Rec_White.RoguelikeAvatar)),
        "last_bp_Butcher_E_Sushi": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_E_Sushi.RoguelikeAvatar)),
        "Viper_E_Mobster_Rec_Glow_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["skin_marathon_no_sale_epic_hero_rare"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_E_Mobster_Rec_Glow.RoguelikeAvatar)),
        "Emperor_E_Dragon_Rec_Orange": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["1394_no_sale"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Dragon_Rec_Orange_skin.RoguelikeAvatar)),
        "Liquidator_E_Forged_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_Rec_Star_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain_Rec_Star.RoguelikeAvatar)),
        "Bulwark_E_Snow_skin_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_E_Snow_skin.RoguelikeAvatar)),
        "offer_with_image_com_Feldsher_E_Plague_Rec_Vampire": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Plague_Rec_Vampire.RoguelikeAvatar)),
        "Ling_E_Ronin_Rec_Black_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin_Rec_Black.RoguelikeAvatar)),
        "Jet_R_base_Rec_Purple_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_R_base_Rec_Purple.RoguelikeAvatar)),
        "offer_with_image_rare_Ling_E_Ronin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_E_Ronin.RoguelikeAvatar)),
        "offer_with_image_rare_Sarge_E_Jailer": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Jailer.RoguelikeAvatar)),
        "rare_hero_Yukka_R_Red": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_R_Red.RoguelikeAvatar)),
        "offer_with_image_rare_Helga_R_base_Rec_Unsight": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_R_base_Rec_Unsight.RoguelikeAvatar)),
        "Sarge_E_Chitin_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Chitin.RoguelikeAvatar)),
        "HongJoo_E_Cupid_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Cupid.RoguelikeAvatar)),
        "HongJoo_R_base_Rec_Flame_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_R_base_Rec_Flame.RoguelikeAvatar)),
        "Yunlin_E_Bride_Rec_Indian_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_E_Bride_Rec_Indian.RoguelikeAvatar)),
        "Ironclad_E_Rust_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Rust.RoguelikeAvatar)),
        "Liquidator_R_Purple_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_R_Purple.RoguelikeAvatar)),
        "offer_with_image_com_Monk_E_Cursed": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Cursed.RoguelikeAvatar)),
        "Bulwark_R_Black_skin_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Bulwark_R_Black_skin.RoguelikeAvatar)),
        "offer_with_image_com_Liquidator_E_White": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_White.RoguelikeAvatar)),
        "Feldsher_E_Suit_skin_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Suit_skin.RoguelikeAvatar)),
        "Fireguard_E_Cyber_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Cyber.RoguelikeAvatar)),
        "Monk_E_Royal_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_com_Bulwark"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Royal.RoguelikeAvatar)),
        "Ironclad_base_steam_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar), heroes.Ironclad.Alias),
        "Fireguard_base_steam_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_base_skin.RoguelikeAvatar), heroes.Fireguard.Alias),
        "Liquidator_base_steam_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_base_skin.RoguelikeAvatar), heroes.Liquidator.Alias),
        "Monk_base_steam_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar), heroes.Monk.Alias),
        "Feldsher_base_steam_com_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar), heroes.Feldsher.Alias),
        "Viper_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Viper_base_Skin.RoguelikeAvatar), heroes.Viper.Alias),
        "Jet_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_base_skin.RoguelikeAvatar), heroes.Jet.Alias),
        "Helga_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_base_skin.RoguelikeAvatar), heroes.Helga.Alias),
        "Sarge_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_base_skin.RoguelikeAvatar), heroes.Sarge.Alias),
        "Ling_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Ling_Base_skin.RoguelikeAvatar), heroes.Ling.Alias),
        "HongJoo_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar), heroes.HongJoo.Alias),
        "Yukka_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Yukka_base_skin.RoguelikeAvatar), heroes.Yukka.Alias),
        "Yunlin_base_steam_rare_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar), heroes.Yunlin.Alias),
        "Midnight_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_base_skin.RoguelikeAvatar), heroes.Midnight.Alias),
        "Marcus_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Marcus_base_skin.RoguelikeAvatar), heroes.Marcus.Alias),
        "Kibo_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar), heroes.Kibo.Alias),
        "Lynx_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar), heroes.Lynx.Alias),
        "Emperor_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar), heroes.Emperor.Alias),
        "Gideon_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar), heroes.Gideon.Alias),
        "Xiang_Tzu_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar), heroes.Xiang_Tzu.Alias),
        "Raikichi_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Raikichi_base_skin.RoguelikeAvatar), heroes.Raikichi.Alias),
        "Butcher_base_steam_epic_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Butcher_base_skin.RoguelikeAvatar), heroes.Butcher.Alias),
        "Itu_base_steam_leg_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar), heroes.Itu.Alias),
        "Legion_King_base_steam_leg_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar), heroes.Legion_King.Alias),
        "Monkey_King_base_steam_leg_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_base_skin.RoguelikeAvatar), heroes.Monkey_King.Alias),
        "June_base_steam_leg_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["steam_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.June_base_skin.RoguelikeAvatar), heroes.June.Alias),
        "Fireguard_E_Cyber_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Cyber.RoguelikeAvatar)),
        "Liquidator_E_Forged_Rec_Joust_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged_Rec_Joust.RoguelikeAvatar)),
        "Ironclad_E_Fervor_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Fervor.RoguelikeAvatar)),
        "Liquidator_E_Forged_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Liquidator_E_Forged.RoguelikeAvatar)),
        "Emperor_E_Dragon_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_E_Dragon_skin.RoguelikeAvatar)),
        "Lynx_E_Mafia_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_E_Mafia.RoguelikeAvatar)),
        "Ironclad_E_Gladiator_Rec_Holi_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Gladiator_Rec_Holi.RoguelikeAvatar)),
        "HongJoo_E_Equilibrist_skin_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_E_Equilibrist_skin.RoguelikeAvatar)),
        "Monk_E_Moth_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Monk_E_Moth.RoguelikeAvatar)),
        "Feldsher_E_Diver_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_Rec_Star_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain_Rec_Star.RoguelikeAvatar)),
        "Fireguard_E_Porcelain_cyberweek_hero": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["cyberweek_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_Porcelain.RoguelikeAvatar)),
        "Ironclad_E_Gladiator_Day_Laughter": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["dsw_wpn_hero_offer_big"], "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_E_Gladiator.RoguelikeAvatar)),
        "sakura_wpn_Midnight_R_Base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Midnight_R_Base_Rec_Sakura", heroWeapons.wpn_Midnight_R_Base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Ling_R_Samurai_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Ling_R_Samurai_Rec_Sakura", heroWeapons.wpn_Ling_R_Samurai_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Fireguard_R_Base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Fireguard_R_Base_Rec_Sakura", heroWeapons.wpn_Fireguard_R_Base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Kibo_R_Gray_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Kibo_R_Sakura", heroWeapons.wpn_Kibo_R_Gray_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Liquidator_R_Gold_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Liquidator_R_Sakura", heroWeapons.wpn_Liquidator_R_Gold_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Monkey_King_R_base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Monkey_King_R_Sakura", heroWeapons.wpn_Monkey_King_R_base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Marcus_R_Lord_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Marcus_R_Sakura", heroWeapons.wpn_Marcus_R_Lord_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Monk_R_base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Monk_R_Sakura", heroWeapons.wpn_Monk_R_base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Viper_R_base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Viper_R_Sakura", heroWeapons.wpn_Viper_R_base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Jet_R_Golden_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Jet_R_Sakura", heroWeapons.wpn_Jet_R_Golden_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Emperor_R_base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Emperor_R_Sakura", heroWeapons.wpn_Emperor_R_base_Rec_Sakura.Settings.Alias),
        "sakura_wpn_Lynx_R_base_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_weapon_base"], "Sprites/PreviewImages/Events/SakuraEvent/wpn_Lynx_R_Sakura", heroWeapons.wpn_Lynx_R_base_Rec_Sakura.Settings.Alias),
        "sakura_last_day_June_E_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_hero_base"], "Sprites/PreviewImages/Heroes/".concat(skins.June_E_Sakura.RoguelikeAvatar), skins.June_E_Sakura.AliasName),
        "sakura_Helga_E_Vampire_Rec_Sakura": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["sakura_hero_base"], "Sprites/PreviewImages/Heroes/".concat(skins.Helga_E_Vampire_Rec_Sakura.RoguelikeAvatar), skins.Helga_E_Vampire_Rec_Sakura.AliasName),
        "offer_hero_midsommar_Sarge_E_Sunny": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_midsommar"], "Sprites/PreviewImages/Heroes/".concat(skins.Sarge_E_Sunny.RoguelikeAvatar), heroes.Sarge.Alias),
        "gift_hero_Jet_E_Golden": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["gift_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Jet_E_Golden.RoguelikeAvatar), skins.Jet_E_Golden.AliasName),
        "gift_hero_Monkey_King_E_cruel": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["gift_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Monkey_King_E_cruel.RoguelikeAvatar), skins.Monkey_King_E_cruel.AliasName),
        "basic_hero_Yunlin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_with_image_rare_Helga"], "Sprites/PreviewImages/Heroes/".concat(skins.Yunlin_base_skin.RoguelikeAvatar)),
        "offer_with_image_Emperor": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Emperor_base_skin.RoguelikeAvatar)),
        "offer_with_image_Xiang_Tzu": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["105"], "Sprites/PreviewImages/Heroes/".concat(skins.Xiang_Tzu_base_skin.RoguelikeAvatar)),
        "leg_event_hero_Widow_E_Bonemoth_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["leg_event_hero_Gideon"], "Sprites/PreviewImages/Heroes/".concat(skins.Widow_E_Bonemoth.RoguelikeAvatar), heroes.Widow.Alias),
        "offer_hero_feldsher_rework_Feldsher_R_Rusty_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_feldsher_rework"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_R_Rusty_skin.RoguelikeAvatar)),
        "offer_hero_feldsher_rework_Feldsher_E_Suit_skin": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_feldsher_rework"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Suit_skin.RoguelikeAvatar)),
        "offer_hero_feldsher_rework_Feldsher_E_Plague": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_feldsher_rework"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Plague.RoguelikeAvatar)),
        "offer_hero_feldsher_rework_Feldsher_E_Diver": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_feldsher_rework"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver.RoguelikeAvatar)),
        "offer_hero_feldsher_rework_Feldsher_E_Diver_Rec_Heated": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["offer_hero_feldsher_rework"], "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_E_Diver_Rec_Heated.RoguelikeAvatar), 'empty'),
        "april_hero_Midnight_E_Shinobi_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["april_hero"], "Sprites/PreviewImages/Heroes/".concat(skins.Midnight_E_Shinobi.RoguelikeAvatar), heroes.Midnight.Alias),
        "event_viper_Gideon_alias": OffersVisualUtils.createCopyVisualWithReplacedMainImageAndCharacterAlias(PromoOfferVisualPresets.templates["event_viper_hero_offer"], "Sprites/PreviewImages/Heroes/".concat(skins.Gideon_base_skin.RoguelikeAvatar), heroes.Gideon.Alias),
    };
    return PromoOfferVisualPresets;
}());
