var CustomConditionsTemplates = (function () {
    function CustomConditionsTemplates() {
    }
    CustomConditionsTemplates.hasOneOfRoulettesAndNoCustomize = function (skinRouletteID, wpnRouletteID, skinID, wpnID) {
        return function (settings) {
            var _a, _b;
            var hasSkinRoulette = RouletteUtils.hasUnfinishedRoulette({
                id: skinRouletteID,
                generatedRoulettes: settings.generatedRoulette,
                playerProgress: settings.playerProgress,
                mainRewards: (_a = {}, _a[CUSTOMIZATION.SKIN] = [skinID], _a)
            });
            var hasWeaponRoulette = RouletteUtils.hasUnfinishedRoulette({
                id: wpnRouletteID,
                generatedRoulettes: settings.generatedRoulette,
                playerProgress: settings.playerProgress,
                mainRewards: (_b = {}, _b[CUSTOMIZATION.WEAPON] = [wpnID], _b)
            });
            return hasSkinRoulette || hasWeaponRoulette;
        };
    };
    return CustomConditionsTemplates;
}());
