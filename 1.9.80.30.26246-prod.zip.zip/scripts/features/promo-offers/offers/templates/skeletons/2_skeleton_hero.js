offerSkeletons.Unlock_New_Hero_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.New_Unlock_New_Hero_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(6000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Unlock_New_Hero_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Unlock_New_Hero_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Cards_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 750;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 450, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 450;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 750, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
    ]
};
offerSkeletons.Shards_Sale_Epic = {
    offers: [
        { common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP" },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates <= 5;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates == 0;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_HSP"
        },
    ]
};
offerSkeletons.Cards_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 6.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 145;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 95;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HP_HSP"
        },
    ]
};
offerSkeletons.Shards_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 110, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 50;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 30;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Cards_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 8.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 95;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 255, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 45;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
    ]
};
offerSkeletons.Shards_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 || heroState.TalentLevel <= 5 && heroState.Duplicates <= 30;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 || heroState.TalentLevel <= 5 && heroState.Duplicates == 20;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Cards_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 750;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 1200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 7000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 450;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 2000, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
    ]
};
offerSkeletons.Shards_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 50;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 30;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 125, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Unlock_Epic_Hero_Rare_Content = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var player = settings.playerProgress;
                        return player.skins.indexOf(VARS.SKIN_1) !== -1
                            || player.weapons.indexOf(VARS.WEAPON_1) !== -1
                            || player.stances.indexOf(VARS.STANCE_1) !== -1;
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var player = settings.playerProgress;
                        return player.skins.indexOf(VARS.SKIN_1) !== -1
                            || player.weapons.indexOf(VARS.WEAPON_1) !== -1
                            || player.stances.indexOf(VARS.STANCE_1) !== -1;
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var player = settings.playerProgress;
                        return player.skins.indexOf(VARS.SKIN_1) !== -1
                            || player.weapons.indexOf(VARS.WEAPON_1) !== -1
                            || player.stances.indexOf(VARS.STANCE_1) !== -1;
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var player = settings.playerProgress;
                        return player.skins.indexOf(VARS.SKIN_1) !== -1
                            || player.weapons.indexOf(VARS.WEAPON_1) !== -1
                            || player.stances.indexOf(VARS.STANCE_1) !== -1;
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Shards_Mini_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 190;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 185;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 180;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 180;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Shards_Mini_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 90;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 88;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 12, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 85;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 82;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 18, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Shards_Mini_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 70;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 5, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 68;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 7, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 65;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 63;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 12, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Shards_Mini_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 45;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 5, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 43;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 7, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 40;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel < 5 || heroState.TalentLevel == 5 && heroState.Duplicates <= 38;
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 12, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Cards_Mini_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1_49.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 3750;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 250, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 3700;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 300, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 3650;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 350, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 3600;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 400, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Cards_Mini_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1_49.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 1150;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 1140;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 60, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 1115;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 85, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 1100;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Cards_Mini_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 275;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 265;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 35, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 255;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 45, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 250;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Cards_Mini_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 190;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 185;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 180;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level < 12 || heroState.Level == 12 && heroState.Exp <= 170;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Shards_Steam_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_1"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_2"
        },
        {
            common: {
                conditions: {},
                profit: 8.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 56;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_3"
        },
        {
            common: {
                conditions: {},
                profit: 10.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 56;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 125, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 8.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 56;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 56;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 125, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 56;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 56;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 130, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 56;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 80, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 56;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 135, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 35, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 56;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 85, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 56;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 140, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_4"
        },
    ]
};
offerSkeletons.Shards_Steam_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1_49.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_1"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_2"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 30;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_3"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 30;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1_49.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 30;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 30;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 30;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 45, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 30;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 30;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 30;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 80, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 30;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 55, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 30;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 85, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_4"
        },
    ]
};
offerSkeletons.Shards_Steam_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_1"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_2"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 21;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_3"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 21;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 21;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 21;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 17, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 22, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 21;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 32, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 21;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 52, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 24, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 21;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 34, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 21;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 54, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 22, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 2 } },
                            _a),
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 26, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates >= 21;
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 36, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 4 && heroState.Duplicates < 21;
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 56, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_4"
        },
    ]
};
offerSkeletons.Shards_Steam_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                profit: 9.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_1"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 2, less: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_2"
        },
        {
            common: {
                conditions: {},
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    idleTime: [new Time({ Days: 90 }).value, new Time({ Days: 3650 }).value],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_Time_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 2, less: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 4.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 16, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 2, less: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 21, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 31, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 17, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 2, less: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 22, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 32, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1) || heroState.TalentLevel == 1;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 18, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 2, less: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 23, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 4 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 33, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HP_3"
        },
    ]
};
offerSkeletons.Unlock_Leg_Hero_Rare_Content = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
    ]
};
offerSkeletons.Unlock_Leg_Hero_Rare_More_Content = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "VS_Content_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a.checkOnlyForOneOf = true,
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a.checkOnlyForOneOf = true,
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a.checkOnlyForOneOf = true,
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_3,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a.checkOnlyForOneOf = true,
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[2],
                    promoOfferGroup: OFFERS[7],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
    ]
};
offerSkeletons.PROMO_10shards_cart_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 3000, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 6000, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 30, _c) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 7000, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 10000, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 70, _c) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.PROMO_up_cart_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 10 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 5000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 10 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 5000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.00, max: 89.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 10 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_120.ProductID,
                discount: " -10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 10 } },
                            _a),
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 250, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 50000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_120.ProductID,
                discount: " -10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level == 10 || heroState.Level == 11 && heroState.Exp < 161;
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 250, _a) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 50000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
    ]
};
offerSkeletons.sakura_old_skin = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[VARS.CURRENCY_1] = 2000, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[VARS.CURRENCY_1] = 5000, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[VARS.CURRENCY_1] = 10000, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Skin_MP"
        },
    ]
};
