offerSkeletons.Basic_Epic_Skin = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: " -25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Wpn_Dsw_Skin = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Holi = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 8.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 5.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 12.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Wpn_Dsw_Wpn = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 5.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Animation_EpHER_EpSt3_RSt1 = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -65%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -35%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_P"
        },
    ],
};
offerSkeletons.Animation_RaHER_EpSt3_RSt1 = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID,] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -65%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -35%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_P"
        },
    ],
};
offerSkeletons.Animation_EpHEE_EpSt3_RSt1 = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: " Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1, VARS.STANCE_2],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID,] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: " Hero_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -65%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_3],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_3] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_3_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -35%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_4],
                        _a),
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_4] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_4_P"
        },
    ]
};
offerSkeletons.Animation_MiniDouble = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_1_P"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_2],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_2],
                        _a),
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_2] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_2_P"
        },
    ],
};
offerSkeletons.Animation_MiniSingle_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_P"
        },
    ],
};
offerSkeletons.Taunt_MiniSingle_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.TAUNT] = [VARS.TAUNT_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Taunts: [VARS.TAUNT_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "TAUNT_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.TAUNT] = [VARS.TAUNT_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Taunts: [VARS.TAUNT_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "TAUNT_P"
        },
    ],
};
offerSkeletons.Animation_MiniSingle_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 49.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -33%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                customSpTable: PromoOfferConstants.buyChipSpTable,
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "STANCE_P"
        },
    ],
};
offerSkeletons.Skin_Meta_Epic_Skin_Rare_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 7.5,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.8,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.5,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.1,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Epic_Skin_Epic_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 5.9,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 3.7,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.5,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _d) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.1,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _d) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Epic_Skin_Leg_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 5.2,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.8,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.4,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.1,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Epic_Skin_Com_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 8.5,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 3.4,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 2.4,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.1,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Rare_Skin_Rare_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 9.3,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.1,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                profit: 2.4,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.5,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Rare_Skin_Epic_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 6.3,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                profit: 3.6,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 3.1,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _d) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.3,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _d) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Rare_Skin_Leg_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                profit: 5.3,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 3.5,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 2.7,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.3,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Meta_Rare_Skin_Com_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 6.5,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                profit: 3.3,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                profit: 2.3,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                profit: 2.8,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Single_Animation_Meta_Rare_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-60%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-60%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 125, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 75, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 5, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 150, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ],
};
offerSkeletons.Single_Animation_Meta_Epic_Hero = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-70%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-45%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-45%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 65, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-20%",
                triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 5, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 75, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ],
};
offerSkeletons.Skin_Mini_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 75, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 100, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 200, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Skin_Mini_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 12, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Epic_Skin_1111_Hero_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                profit: 17.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 5.6,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 3.4,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                profit: 2.1,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                profit: 16.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[5],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 5.9,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[6],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.7,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[7],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[8],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Epic_Skin_1111_Hero_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 11.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                profit: 5.5,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                profit: 3.1,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 2.1,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                profit: 16.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[5],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 5.9,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[6],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.7,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[7],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[8],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Epic_Skin_1111_Hero_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 10.6,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 5.3,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                profit: 3.5,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.1,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                profit: 16.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[5],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 5.9,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[6],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.7,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[7],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[8],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Epic_Skin_1111_Hero_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                profit: 10.5,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                profit: 6.0,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 3.5,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.3,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                profit: 16.0,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[5],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                profit: 5.9,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[6],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                profit: 3.7,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[7],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[8],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.sakura_weapon_expensive_rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 5000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 1.0,
                discount: "-5%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 1.0,
                discount: "-5%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 1.0,
                discount: "-5%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_expensive_leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_90.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_70.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_expensive_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.8,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 2.5,
                discount: "-60%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 3.0,
                discount: "-65%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 5.0,
                discount: "-80%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_expensive_epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_80.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 30, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 60, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.0,
                discount: "-5%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.0,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.END_DATE,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.1,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 5000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 2.2,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_rare_weapon_vs_rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 30000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 50, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 5000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 35, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 15000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 12000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.1,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 5000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 2.2,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.5,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 2.8,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_rare_weapon_vs_leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 60000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 25, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 10000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 30000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 25000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 2.2,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.5,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 2.8,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 2.0,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_rare_weapon_vs_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 30000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 12000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 40, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 10000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 7500, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 10, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 2.0,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_epic_weapon_vs_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 50000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 40, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 10, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                profit: 1.3,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 1.1,
                discount: "-15%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.2,
                discount: "-20%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 1.3,
                discount: "-25%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.3,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.sakura_weapon_epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 30, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 60, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_rare_weapon_vs_epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 45000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 30, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 60, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 10000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 30000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 25000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 15, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 30, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 60, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 2.1,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.0,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.8,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_epic_weapon_vs_epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 100000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 30, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 60, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 10000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 60000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 50000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 15, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 30, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 60, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.2,
                discount: "-15%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                profit: 1.2,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 1.2,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 1.1,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_skin_vs_rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 60000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 45, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 5000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 30, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 35, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 45, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 5000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 1.1,
                discount: "-10%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                profit: 1.1,
                discount: "-10%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                profit: 1.1,
                discount: "-10%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.2,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.vampire_skin_vs_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 40, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 10, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                profit: 1.5,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 1.6,
                discount: "-35%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                profit: 1.4,
                discount: "-30%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 1.7,
                discount: "-40%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.2,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.Skin_Day_Laughter = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 8.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "No_Skin_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "No_Skin_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "No_Skin_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[4],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "No_Skin_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 12.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[5],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[6],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[7],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[8],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.New_Stance_Full = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        heroesOneOfExist: [VARS.HERO_1],
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_NoHero"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_NoHero"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_NoHero"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.STANCE] = [VARS.STANCE_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [VARS.STANCE_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_NoHero"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 60000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 50, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 5000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 35, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 30000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 25000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 50, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 5000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_rare_compens = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 3100 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 190 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 3100 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 190 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 80000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 30, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 60, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 10000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 60000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 50000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 40000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 15, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_80.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 30, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 60, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_epic_compens = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 870 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 160 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 870 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 160 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 20000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 100, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 10000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 40, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 7500, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 7500, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 10, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                profit: 2.8,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 100, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 2.5,
                discount: "-60%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                profit: 3.0,
                discount: "-65%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                profit: 5.0,
                discount: "-80%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_com_compens = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 9250 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 260 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_token"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 2.8,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 9250 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 260 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f, _g;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 100000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[VARS.HERO_1] = 25, _f) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[VARS.CURRENCY_1] = 10000, _g) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 90000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 75000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 70000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _b),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 20, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: OFFERS[1],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e, _f;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[VARS.HERO_1] = 25, _e) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[VARS.CURRENCY_1] = 10000, _f) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_90.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_70.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: OFFERS[6],
                    promoOfferGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
offerSkeletons.april_rare_weapon_vs_leg_compens = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { more: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d, _e;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    price: (_a = {}, _a[VARS.CURRENCY_2] = 35000, _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 600 }, _b),
                        heroShardsSum: (_c = {}, _c[VARS.HERO_1] = { less_or_equal: 100 }, _c),
                    },
                    noCustomizeExist: (_d = {},
                        _d[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _d),
                    productGroup: VARS.IDS_1[0],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[VARS.CURRENCY_1] = 13000, _e) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp_tokens"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                profit: 1.1,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { less_or_equal: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { more: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999.99, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_2,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroCardsSum: (_a = {}, _a[VARS.HERO_1] = { more: 600 }, _a),
                        heroShardsSum: (_b = {}, _b[VARS.HERO_1] = { less_or_equal: 100 }, _b),
                    },
                    noCustomizeExist: (_c = {},
                        _c[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _c),
                    productGroup: VARS.IDS_1[1],
                    promoOfferGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[VARS.CURRENCY_1] = 13000, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_Comp"
        },
    ]
};
