var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8;
offerSkeletons.BuyChipRoulette_Epic = {
    offers: [
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-55%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-35%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-30%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-45%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-25%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-20%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 3.3,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _a) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_NP_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 6.1,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _b) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_NP_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 2.0,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _c) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_P_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 4.9,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _d) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_P_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 1.9,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_e = {}, _e[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _e) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_NP_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 4.9,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _f) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_NP_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.0,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_g = {}, _g[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _g) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[11], OFFERS[12]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_P_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.4,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_h = {}, _h[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _h) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[9], OFFERS[10]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                };
            },
            offerPrefix: "VS_P_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_offer_levelup_title_2",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-75%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-75%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-60%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_HL",
        },
    ],
};
offerSkeletons.BuyChipRoulette_Leg = {
    offers: [
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-65%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-55%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-45%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 5, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-35%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-45%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-10%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_Hero_P_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-15%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Skin_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 3.3,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _j) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 6.2,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_k = {}, _k[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _k) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_l = {}, _l[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _l) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 5.0,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _m) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_o = {}, _o[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _o) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 5.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_p = {}, _p[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _p) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_q = {}, _q[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _q) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[11], OFFERS[12]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.5,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _r) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[9], OFFERS[10]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_offer_levelup_title_2",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[17],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-65%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_offer_gift",
                conditions: { accountLevel: { more_or_equal: 2 }, },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                everyDayOffer: true,
                price: (_s = {}, _s[CURRENCY.BONUS] = 0, _s),
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-100%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    productGroup: OFFERS[21],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.TICKET_3] = [{ Weight: 1, Amount: new RndFromInterval(20) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Tickets_Gift",
        },
    ],
};
offerSkeletons.BuyChipRoulette_Wpn_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-55%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_LL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_LL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-40%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 5, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_LL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-35%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_LL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-45%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_HL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-30%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_HL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-30%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_HL",
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-30%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    offerNameAlias: VARS.ALIAS_1,
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 3.3,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _t) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 6.2,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_u = {}, _u[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _u) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_v = {}, _v[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _v) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 5.0,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_w = {}, _w[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _w) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_x = {}, _x[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _x) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 5.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_y = {}, _y[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _y) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_NP_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_z = {}, _z[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _z) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[11], OFFERS[12]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.5,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_0 = {}, _0[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _0) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[9], OFFERS[10]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                };
            },
            offerPrefix: "VS_P_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_offer_levelup_title_2",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-65%",
                customSpTable: PromoOfferConstants.buyChipSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_HL",
        },
    ],
};
offerSkeletons.LastDay_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 249.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 249.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID, chests.Animation_chest.ID,] } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 75, _c) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
    ]
};
offerSkeletons.LastDay_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID,] } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID,] } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 249.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 249.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID,] } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 999999 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            }
                        ]
                    },
                };
            },
            offerPrefix: "Hero_HP"
        },
    ]
};
offerSkeletons.Hero_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 6.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 8.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 95;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 255, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 45;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates <= 5;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates == 0;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Hero_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 6.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 145;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 95;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates <= 5;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel == 3 || heroState.TalentLevel == 4 && heroState.Duplicates == 0;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Hero_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LA_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LA_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HA_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HA_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 750;
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 450, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 450;
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 750, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 110, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 50;
                    },
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 30;
                    },
                    productGroup: OFFERS[9],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 70, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Hero_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LA_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_LA_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HA_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NoHero_HA_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 750;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 1200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 9 } },
                            _a),
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 7000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.Level >= 9 && heroState.Level <= 11 || heroState.Level == 12 && heroState.Exp <= 450;
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 2000, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cards_HL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 50;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less: 3 } },
                            _a),
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    customCondition: function (settings) {
                        var heroId = VARS.HERO_1;
                        var heroState = settings.playerProgress.heroes[heroId];
                        if (heroState == undefined) {
                            return false;
                        }
                        heroState = Hero.upLevelIfNecessary(heroState, heroId);
                        return heroState.TalentLevel >= 3 && heroState.TalentLevel <= 4 || heroState.TalentLevel == 5 && heroState.Duplicates <= 30;
                    },
                    productGroup: OFFERS[9],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 125, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Shards_HL_HSP"
        },
    ]
};
offerSkeletons.Basic_Hero_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_HSP"
        },
    ]
};
offerSkeletons.Basic_Hero_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_HSP"
        },
    ]
};
offerSkeletons.New_Basic_Hero_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_HSP"
        },
    ]
};
offerSkeletons.Basic_Wpn_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LL_HSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_LSP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HL_HSP"
        },
    ]
};
offerSkeletons.New_Epic_Hero_Cards = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 4.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                profit: 6.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[4]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[6]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 60, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 85, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[8]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 120, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[9]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[11],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 135, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 249.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 60, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[12]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[13]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 150, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[14]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 250, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[15]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 130, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[17]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 140, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[18]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[19]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 200, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.New_Epic_Hero_Shards = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 6.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 5.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 8.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[4]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[5]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " 65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[8]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: " -55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[11]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
    ]
};
offerSkeletons.New_Epic_Hero_Super = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: " -45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 100,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_2"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Cards = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 35, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                profit: 5.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[4]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[5]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[8]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[9]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 55, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[11]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 65, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_6"
        },
        {
            common: {
                conditions: {},
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[12]],
                    productGroup: OFFERS[13],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 35, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_7"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 249.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[14]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[15]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 60, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[16]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[17]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[18]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 100, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_6"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[19]],
                    productGroup: OFFERS[13],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 45, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_7"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[21]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 65, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[22]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 85, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[23]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 115, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[24]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 135, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Cards_Shogun_Release = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 6, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 9, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 12, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[4]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 18, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[5]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 21, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 16, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[8]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[9]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 24, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 28, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[11]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_6"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[12]],
                    productGroup: OFFERS[13],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_7"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 249.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 14, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[14]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 16, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[15]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[16]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 22, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[17]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 23, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[18]],
                    productGroup: OFFERS[6],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 40, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_6"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[19]],
                    productGroup: OFFERS[13],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_7"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 110,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 24, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[21]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[22]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 43, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[23]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 55, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[24]],
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 60, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Shards = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 5, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 5, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[5]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 11, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[6]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 16, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 23, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 8, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[9]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 14, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[12]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[13]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Shards_Shogun_Release = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.00, max: 19.99 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 3, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 6, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 8, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 12, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 2, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[5]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 4, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[6]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 6, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[7]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 9, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.00, max: 249.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 5, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[9]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 8, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[10]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 11, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 250.00, max: 99999.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 120,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 11, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[12]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 16, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[13]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 26, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Super = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 35, _a) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 85, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 45, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_2"
        },
        {
            common: {
                conditions: {},
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 140, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_3"
        },
    ]
};
offerSkeletons.New_Leg_Hero_Super_Shogun_Release = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 90.00, max: 999999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                inApp: inAppSettings.PRICE_120.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 75, _a) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 33, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_1"
        },
        {
            common: {
                conditions: {},
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[1]],
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 50, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_2"
        },
        {
            common: {
                conditions: {},
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    previousOffers: [OFFERS[2]],
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[VARS.HERO_1] = 133, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_3"
        },
        {
            common: {
                conditions: {},
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
                popupSettings: {
                    popUpId: 95,
                    popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                },
                inApp: inAppSettings.PRICE_120.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        duration: new Time({ Days: 2 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { less_or_equal: 5 } },
                            _a),
                    },
                    previousOffers: [OFFERS[3]],
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 33, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Super_4"
        },
    ]
};
offerSkeletons.Wpn_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 100, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 5, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 175, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 999999 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_HP"
        },
    ]
};
offerSkeletons.BuyEpicWpnRouletteExcludeWpnChips = {
    offers: [
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_LL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_NP_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noHeroExist: [VARS.HERO_1],
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_Hero_P_HL",
        },
        {
            common: {
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-20%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Wpn_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 3.3,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-65%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_1 = {}, _1[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _1) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_NP_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 6.2,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-80%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _2) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[9],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_NP_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-50%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_3 = {}, _3[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _3) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_P_LL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 2, less: 5 }, },
                profit: 5.0,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_4 = {}, _4[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _4) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[11],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_P_LL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _5) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_NP_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 5.0,
                sp: { min: 0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_6 = {}, _6[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _6) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[9], OFFERS[10], OFFERS[15], OFFERS[16]],
                    promoOfferGroup: OFFERS[13],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_NP_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_1",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.1,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_7 = {}, _7[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _7) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[9], OFFERS[10], OFFERS[13], OFFERS[14], OFFERS[11], OFFERS[12]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_P_HL_1",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_vs",
                offerNameAlias: "promo_title_PROMO_STARTER_2",
                conditions: { accountLevel: { more_or_equal: 5 }, },
                profit: 2.5,
                sp: { min: 50.00, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
                lootSettings: { additionalPlaceHolder: [{
                            front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _8) } } }],
                        }] },
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    noActiveOffersNow: [OFFERS[11], OFFERS[12], OFFERS[13], OFFERS[14], OFFERS[9], OFFERS[10]],
                    promoOfferGroup: OFFERS[15],
                    useOfferGroupAsVersus: true,
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                };
            },
            offerPrefix: "VS_P_HL_2",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_offer_levelup_title_2",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _c) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 2, less: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _c) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_LL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 0, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                    productGroup: OFFERS[17],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _c) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_NP_HL",
        },
        {
            common: {
                visualPresetId: "promo_event_offer_big",
                offerNameAlias: "promo_title_INACTIVE_PAY_5",
                conditions: {},
                sp: { min: 50.0, max: 999999.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_2 }).value,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_3 }).value,
                    },
                    conditions: {
                        accountLevel: { more_or_equal: 5 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    customizeExist: (_b = {},
                        _b[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_2],
                        _b),
                    productGroup: OFFERS[17],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.CHIP_3] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _c) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Week_P_HL",
        },
    ],
};
offerSkeletons.Gift_India = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 99999.99 },
                profit: 11.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        countries: ["IN"],
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
        },
    ],
};
offerSkeletons.Gift_Super_Bowl = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
    ],
};
offerSkeletons.Gift_Rar_No_Country = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 7.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ],
};
offerSkeletons.Gift_Whale = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 6.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-25%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
