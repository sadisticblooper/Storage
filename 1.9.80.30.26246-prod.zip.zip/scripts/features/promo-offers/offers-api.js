function getPromoOffers(p) {
    return PromoGenerating.getPromoOffers(p);
}
function generatePromoOffer(p) {
    return PromoGenerating.generatePromoOffer(p);
}
function generatePromoOfferMany(playerSettings) {
    return PromoGenerating.generatePromoOfferMany(playerSettings);
}
function getPromoOfferInfo(params) {
    return PromoOfferInfo.getPromoOfferInfo(params);
}
function getPromoOfferVisualSettings(offerId) {
    return OffersUtils.getPromoOfferVisualSettings(offerId);
}
function getPromoOfferPopUpVisualSettings(offerId) {
    return OffersUtils.getPromoOfferPopUpVisualSettings(offerId);
}
function getAdOfferFromList(settings) {
    return OffersUtils.getAdOfferFromList(settings);
}
function doShowAdOfferPopUp(settings) {
    return OffersUtils.doShowAdOfferPopUp(settings);
}
function updateAdOfferPopUpCounters(settings) {
    return OffersUtils.updateAdOfferPopUpCounters(settings);
}
function getHeroesSalePopupSettingsById(settings) {
    return OffersUtils.getHeroesSalePopupSettingsById(settings);
}
function getHeroesSalePopupVisualSettings(saleId) {
    return OffersUtils.getHeroesSalePopupVisualSettings(saleId);
}
function doShowTodaySalePopUp(settings) {
    return OffersUtils.doShowTodaySalePopUp(settings);
}
function getOfferOldPrice(settings) {
    return OfferPriceCalculations.getOfferOldPrice(settings);
}
function getLimitOfferPopupsPerSession() {
    return PromoOfferConstants.limitOfferPopupsPerSession;
}
function getUnlimitedOfferPopupTriggers() {
    return PromoOfferConstants.unlimitedOfferPopupTriggers;
}
function getPromoOfferPopupLimitPeriodMs() {
    return PromoOfferConstants.promoOfferPopupLimitPeriodMs;
}
