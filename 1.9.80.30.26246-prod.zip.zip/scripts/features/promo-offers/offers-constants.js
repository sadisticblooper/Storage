var PromoOfferConstants = (function () {
    function PromoOfferConstants() {
    }
    PromoOfferConstants.limitOfferPopupsPerSession = 5;
    PromoOfferConstants.promoOfferPopupLimitPeriodHours = 2;
    PromoOfferConstants.promoOfferPopupLimitPeriodMs = PromoOfferConstants.promoOfferPopupLimitPeriodHours * 60 * 60 * 1000;
    PromoOfferConstants.unlimitedOfferPopupTriggers = [
        PROMO_OFFER_POP_UP_TRIGGER.ON_GENERATION,
    ];
    PromoOfferConstants.visualForSmallBadgeWithKibo = {
        glow: "#8E65B88A",
        decor: "#C68CFF",
        blinkGlow: "#FFE2FF",
        titleColor: "#C68CFF",
        lobbyBadgeLabel: {
            isAlias: true,
            value: "lobby_starter_pack_badge_label",
            placeholders: null,
        },
        icon: "Sprites/Assets/PromoOffer/KiboBadge",
        bgGradient: {
            colorKeys: [{ color: "#593F73", time: 0 }, { color: "#47325C", time: 1 }],
            alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
            mode: 0,
        }
    };
    PromoOfferConstants.visualForSmallBadgeUniversalYellow = {
        glow: "#B89B44",
        decor: "#FFD75E",
        blinkGlow: "#FFF8BA",
        titleColor: "#FFD75E",
        lobbyBadgeLabel: {
            isAlias: true,
            value: "lobby_starter_pack_badge_label",
            placeholders: null,
        },
        icon: "Sprites/Assets/StoreFree/icon_universal",
        bgGradient: {
            colorKeys: [{ color: "#5C1A24", time: 0 }, { color: "#5C4D22", time: 1 }],
            alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
            mode: 0,
        }
    };
    PromoOfferConstants.visualForSmallBadgeUniversalBlue = {
        glow: "#6586B8",
        decor: "#8CBAFF",
        blinkGlow: "#D1FFFF",
        titleColor: "#8CBAFF",
        lobbyBadgeLabel: {
            isAlias: true,
            value: "lobby_starter_pack_badge_label",
            placeholders: null,
        },
        icon: "Sprites/Assets/StoreFree/icon_universal",
        bgGradient: {
            colorKeys: [{ color: "#5C1A24", time: 0 }, { color: "#32435C", time: 1 }],
            alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
            mode: 0,
        }
    };
    PromoOfferConstants.visualForSmallBadgeUniversalPurple = {
        glow: "#8E65B8",
        decor: "#C68CFF",
        blinkGlow: "#FFE2FF",
        titleColor: "#C68CFF",
        lobbyBadgeLabel: {
            isAlias: true,
            value: "lobby_starter_pack_badge_label",
            placeholders: null,
        },
        icon: "Sprites/Assets/StoreFree/icon_universal",
        bgGradient: {
            colorKeys: [{ color: "#5C1A24", time: 0 }, { color: "#47325C", time: 1 }],
            alphaKeys: [{ alpha: 1, time: 0 }, { alpha: 1, time: 1 }],
            mode: 0,
        }
    };
    PromoOfferConstants.region20 = ["BY", "BA", "CR", "MV", "AR", "RS", "TH", "DO", "MK", "MX", "VE", "SR",
        "BW", "BR", "LC", "UA", "PY", "PE", "BO", "EC", "TN", "CO", "AZ", "JO", "VN", "MD", "SV", "JM", "MN", "TO", "GA",
        "MA", "NI", "DZ", "AL", "WS", "FJ", "BT", "LK", "GE", "AM", "TV", "GT", "GY", "SY", "TJ", "NA", "HN", "IQ", "BZ",
        "MM", "KG", "GH", "ZA", "PH", "KI", "EG", "FM", "DJ", "KM", "PK", "GM", "VU", "IN", "SD", "CM", "HT", "LS", "NP",
        "YE", "BD", "SZ", "LA", "SB", "CI", "TL", "ZW", "ET", "ST", "CG", "TD", "PG", "KE", "SN", "GN", "NG", "UG", "SS",
        "SL", "LR", "BF", "NE", "TM", "TZ", "BJ", "ML", "TG", "AO", "RW", "UZ", "ZM", "MZ", "CF", "GW", "MW", "BI", "IR",
        "MG", "CD", "MR", "YT", "XK", "WF", "VI", "VG", "VC", "TC", "SX", "SO", "SM", "PW", "PF", "NR", "NC", "MS", "MQ",
        "MP", "MH", "MF", "LY", "KY", "KN", "JE", "IM", "ID", "GU", "GQ", "GL", "GI", "GG", "GF", "ER", "DM", "CW", "CV",
        "CU", "CK", "BV", "BQ", "BM", "BL", "BB", "AX", "AW", "AS", "AI", "AG", "AF", "AD"];
    PromoOfferConstants.region30 = ["LB", "CL", "BG", "ME", "MU", "KZ", "TT", "PL", "SK", "HU", "PA", "RU",
        "SC", "TR", "RO"];
    PromoOfferConstants.region50 = ["CN", "KR", "SI", "ES", "EE", "PT", "LT", "IT", "CZ", "LV", "UY", "MY",
        "HR", "GR"];
    PromoOfferConstants.region70 = ["MT", "CY"];
    PromoOfferConstants.region100 = ["HK", "LI", "MC", "NZ", "SG", "US", "CA", "AT", "DK", "NL", "AU", "IS",
        "DE", "FR", "FI", "BE", "GB", "JP", "TW", "IL", "RE", "QA", "PS", "PR", "OM", "KW", "KH", "GP", "GD", "BS", "BN",
        "BH"];
    PromoOfferConstants.region120 = ["LU", "AE", "NO", "CH", "SE", "IE", "MO", "SA"];
    PromoOfferConstants.defaultSpTable = [
        { currentMinMax: { min: 0, max: 0.49, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 0.49 }, },
            ] },
        { currentMinMax: { min: 0.5, max: 9.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0.5, max: 9.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0.5, max: 9.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0.5, max: 7.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0.5, max: 5.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0.5, max: 3.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0.5, max: 2.99 }, },
            ] },
        { currentMinMax: { min: 10, max: 89.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 8, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 6, max: 64.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 4, max: 39.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 3, max: 24.99 }, },
            ] },
        { currentMinMax: { min: 90, max: 9999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 90, max: 999999 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 90, max: 999999 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 45, max: 999999 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 64, max: 999999 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 40, max: 999999 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 25, max: 999999 }, },
            ] },
        { currentMinMax: { min: 0.5, max: 19.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0.5, max: 9.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0.5, max: 9.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0.5, max: 7.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0.5, max: 5.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0.5, max: 3.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0.5, max: 2.99 }, },
            ] },
        { currentMinMax: { min: 0, max: 19.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 9.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 9.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 7.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 5.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 3.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 2.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 99.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 8, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 6, max: 64.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 4, max: 39.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 3, max: 24.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 249.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 10, max: 89.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 8, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 6, max: 64.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 4, max: 39.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 3, max: 24.99 }, },
            ] },
        { currentMinMax: { min: 0, max: 49.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 89.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 89.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 64.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 39.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 24.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 9999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 90, max: 999999 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 90, max: 999999 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 45, max: 999999 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 64, max: 999999 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 40, max: 999999 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 25, max: 999999 }, },
            ] },
    ];
    PromoOfferConstants.defaultMedianSpentTable = [
        { currentMinMax: { min: 0, max: 2.489, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 2.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 2.489, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 1.748, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 1.249, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 0.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 0.489, } },
            ] },
        { currentMinMax: { min: 2.49, max: 3.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 3, max: 4.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 2.49, max: 3.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 1.75, max: 2.999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 1.25, max: 1.999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 1, max: 1.489, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0.49, max: 0.999, } },
            ] },
        { currentMinMax: { min: 4, max: 6.489, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 5, max: 7.489, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 4, max: 6.489, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 3, max: 4.489, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 2, max: 3.249, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 1.49, max: 1.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 1, max: 1.489, } },
            ] },
        { currentMinMax: { min: 6.49, max: 8.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 7.49, max: 10.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 6.49, max: 8.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 4.49, max: 6.489, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 3.25, max: 4.489, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 2, max: 2.749, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 1.49, max: 1.999, } },
            ] },
        { currentMinMax: { min: 9, max: 11.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 11, max: 14.489, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 9, max: 11.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 6.49, max: 8.489, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 4.49, max: 5.999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 2.75, max: 3.489, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 2, max: 2.489, } },
            ] },
        { currentMinMax: { min: 12, max: 17.489, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 14.49, max: 20.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 12, max: 17.489, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 8.49, max: 12.489, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 6, max: 8.749, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 3.49, max: 5.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 2.49, max: 4.999, } },
            ] },
        { currentMinMax: { min: 17.49, max: 999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 21, max: 999999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 17.49, max: 999999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 12.49, max: 999999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 8.75, max: 999999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 6, max: 999999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 5, max: 999999, } },
            ] },
    ];
    PromoOfferConstants.defaultMaxSpentTable = [
        { currentMinMax: { min: 0, max: 4.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 5.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 4.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 3.499, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 2.499, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 1.499, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 0.999, } },
            ] },
        { currentMinMax: { min: 5, max: 9.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 6, max: 11.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 5, max: 9.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 3.5, max: 6.999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 2.5, max: 4.999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 1.5, max: 2.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 1, max: 1.999, } },
            ] },
        { currentMinMax: { min: 10, max: 14.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 12, max: 17.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 10, max: 14.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 7, max: 10.499, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 5, max: 7.499, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 3, max: 4.499, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 2, max: 2.999, } },
            ] },
        { currentMinMax: { min: 15, max: 19.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 18, max: 23.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 15, max: 19.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 10.5, max: 13.999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 7.5, max: 9.999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 4.5, max: 5.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 3, max: 3.999, } },
            ] },
        { currentMinMax: { min: 20, max: 34.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 24, max: 41.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 20, max: 34.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 14, max: 24.499, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 10, max: 17.499, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 6, max: 10.499, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 4, max: 6.999, } },
            ] },
        { currentMinMax: { min: 35, max: 59.999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 42, max: 71.999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 35, max: 59.999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 24.5, max: 42.999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 17.5, max: 29.999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 10.5, max: 17.999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 7, max: 11.999, } },
            ] },
        { currentMinMax: { min: 60, max: 999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 72, max: 999999, } },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 60, max: 999999, } },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 42, max: 999999, } },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 30, max: 999999, } },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 18, max: 999999, } },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 12, max: 999999, } },
            ] },
    ];
    PromoOfferConstants.wpn1111SpTable = [
        { currentMinMax: { min: 0, max: 19.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 19.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 19.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 14.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 9.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 7.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 4.99 }, },
            ] },
        { currentMinMax: { min: 20, max: 49.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 20, max: 49.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 20, max: 49.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 15, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 10, max: 44.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 8, max: 29.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 5, max: 19.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 249.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 50, max: 249.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 50, max: 249.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 45, max: 149.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 45, max: 129.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 30, max: 109.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 20, max: 89.99 }, },
            ] },
        { currentMinMax: { min: 250, max: 9999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 250, max: 9999999 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 250, max: 9999999 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 150, max: 9999999 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 130, max: 9999999 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 110, max: 9999999 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 90, max: 9999999 }, },
            ] },
    ];
    PromoOfferConstants.chainUpgradeHeroSpTable = [
        { currentMinMax: { min: 0, max: 0.49, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 0.49 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 0.49 }, },
            ] },
        { currentMinMax: { min: 0.5, max: 19.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0.5, max: 19.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0.5, max: 19.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0.5, max: 14.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0.5, max: 9.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0.5, max: 7.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0.5, max: 4.99 }, },
            ] },
        { currentMinMax: { min: 20, max: 49.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 20, max: 49.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 20, max: 49.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 15, max: 44.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 10, max: 44.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 8, max: 29.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 5, max: 19.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 99.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 50, max: 99.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 50, max: 99.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 45, max: 89.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 45, max: 89.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 30, max: 79.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 20, max: 69.99 }, },
            ] },
        { currentMinMax: { min: 100, max: 399.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 100, max: 399.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 100, max: 399.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 90, max: 349.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 90, max: 249.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 80, max: 149.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 70, max: 119.99 }, },
            ] },
        { currentMinMax: { min: 400, max: 9999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 400, max: 9999999 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 400, max: 9999999 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 350, max: 9999999 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 250, max: 9999999 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 150, max: 9999999 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 120, max: 9999999 }, },
            ] },
    ];
    PromoOfferConstants.buyChipSpTable = [
        { currentMinMax: { min: 0, max: 49.99, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 0, max: 49.99 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 0, max: 49.99 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 0, max: 34.99 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 0, max: 24.99 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 0, max: 14.99 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 0, max: 9.99 }, },
            ] },
        { currentMinMax: { min: 50, max: 9999999, }, replace: [
                { countries: PromoOfferConstants.region120, newMinMax: { min: 50, max: 9999999 }, },
                { countries: PromoOfferConstants.region100, newMinMax: { min: 50, max: 9999999 }, },
                { countries: PromoOfferConstants.region70, newMinMax: { min: 35, max: 9999999 }, },
                { countries: PromoOfferConstants.region50, newMinMax: { min: 25, max: 9999999 }, },
                { countries: PromoOfferConstants.region30, newMinMax: { min: 15, max: 9999999 }, },
                { countries: PromoOfferConstants.region20, newMinMax: { min: 10, max: 9999999 }, },
            ] },
    ];
    PromoOfferConstants.adOfferPopUpSchedule = {
        sessionOfferShow: [1, 2, 7],
        lifetimeOfferShow: [0],
    };
    PromoOfferConstants.offersToEndStartQueue = [
        7000,
        7206, 7207, 7210, 7211, 7212, 7213, 7214, 7215, 7216, 7217, 7218,
        7226, 7227, 7230, 7231, 7232, 7233, 7234, 7235, 7236, 7237, 7238,
        7303, 7317,
    ];
    PromoOfferConstants.cycleOffersStartDateFunction = function (generatedOffers, regionalParameter, serverTime) {
        var createdPlayerTime = regionalParameter.createdPlayerTime;
        if (createdPlayerTime < new Date("2024-01-01").getTime()) {
            return new Date("2024-01-11").getTime();
        }
        var startDate = new Date(createdPlayerTime).setUTCHours(0, 0, 0, 0) + new Time({ Days: 4 }).value;
        if (serverTime >= startDate) {
            return startDate;
        }
        return undefined;
    };
    return PromoOfferConstants;
}());
