var _a, _b;
var FriendFightSettings = (function () {
    function FriendFightSettings() {
    }
    FriendFightSettings.rules = [
        {
            battleId: battleSettings.FRIEND_NO_RULES.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: null,
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_VAMPIRE.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: null,
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_ACTIVE_BLOCK.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: null,
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_PORTALS.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: null,
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_WALLS_BURN_3v3.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: [TEAM_MODE._3_VS_3_],
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_WALLS_BURN_1v1.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: [TEAM_MODE._1_VS_1_],
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_ENDLESS_FIGHT.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: [TEAM_MODE._1_VS_1_],
            overrideRoundsToWin: {
                name: "friend_fight_rounds_to_win_selection_label",
                values: [1],
                defaultIndex: 0,
                cycled: false,
                hideText: true
            },
            overrideRoundDurations: {
                name: "friend_fight_round_duration_selection_label",
                values: [999],
                defaultIndex: 0,
                cycled: false,
                hideText: true
            },
        },
        {
            battleId: battleSettings.FRIEND_FRACTIONS.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: [TEAM_MODE._3_VS_3_],
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_LUNAR_PRESENTS.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: null,
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
        {
            battleId: battleSettings.FRIEND_BLACK_MARKET.ID,
            locationsOnlyFromList: null,
            teamModeOnlyFromList: [TEAM_MODE._3_VS_3_],
            overrideRoundsToWin: null,
            overrideRoundDurations: null,
        },
    ];
    FriendFightSettings.stats = [
        { params: { mode: "create_real" }, alias: "draft_window_friend_create_real", teamModeOnlyFromList: null, },
        { params: { mode: "create_min" }, alias: "draft_window_friend_create_min", teamModeOnlyFromList: null, },
        {
            params: { mode: "create_balanced" },
            alias: "draft_window_friend_create_balanced",
            teamModeOnlyFromList: [TEAM_MODE._1_VS_1_],
        },
    ];
    FriendFightSettings.statsForLocalPvP = [
        {
            params: { mode: "create_balanced" },
            alias: "draft_window_friend_create_balanced",
            teamModeOnlyFromList: [TEAM_MODE._1_VS_1_],
        },
        { params: { mode: "create_real" }, alias: "draft_window_friend_create_real", teamModeOnlyFromList: null, },
        { params: { mode: "create_min" }, alias: "draft_window_friend_create_min", teamModeOnlyFromList: null, },
    ];
    FriendFightSettings.roundsToWin = (_a = {},
        _a[TEAM_MODE._1_VS_1_] = {
            name: "friend_fight_rounds_to_win_selection_label",
            values: [1, 2, 3, 4,],
            defaultIndex: 1,
            cycled: false,
            hideText: false,
        },
        _a[TEAM_MODE._3_VS_3_] = null,
        _a);
    FriendFightSettings.roundsDuration = (_b = {},
        _b[TEAM_MODE._1_VS_1_] = {
            name: "friend_fight_round_duration_selection_label",
            values: [40, 100, 500,],
            defaultIndex: 1,
            cycled: true,
            hideText: false,
        },
        _b[TEAM_MODE._3_VS_3_] = {
            name: "friend_fight_round_duration_selection_label",
            values: [40, 100, 500,],
            defaultIndex: 1,
            cycled: true,
            hideText: false,
        },
        _b);
    FriendFightSettings.HOLD_WEAPONS = [
        heroWeapons.wpn_Marcus_R_Ninja_Party.ID,
    ];
    return FriendFightSettings;
}());
