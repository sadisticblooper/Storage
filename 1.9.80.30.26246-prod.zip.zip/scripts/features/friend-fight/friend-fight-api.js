function getFriendFightBattleOptions(settings) {
    return FriendFightUtils.getFriendFightBattleOptions(settings);
}
function getFriendPlayersForBattle(settings) {
    return FriendFightUtils.getFriendPlayersForBattle(settings);
}
