var FriendFightUtils = (function () {
    function FriendFightUtils() {
    }
    FriendFightUtils.getFriendFightBattleOptions = function (settings) {
        var teamMode = settings.teamMode, friendFightType = settings.friendFightType;
        var result = {
            stats: {
                name: "draft_window_friend_ui_parameters",
                values: [],
                cycled: true,
                defaultIndex: 0,
                hideText: false
            },
            fightRules: {
                name: "friend_fight_gameplay_rule_selection_label",
                values: [],
                cycled: true,
                defaultIndex: 0,
                hideText: false
            },
        };
        var statsForSelector = friendFightType == FRIEND_FIGHT_TYPE.LocalPvp
            ? FriendFightSettings.statsForLocalPvP
            : FriendFightSettings.stats;
        for (var _i = 0, statsForSelector_1 = statsForSelector; _i < statsForSelector_1.length; _i++) {
            var stat = statsForSelector_1[_i];
            if (stat.teamModeOnlyFromList && stat.teamModeOnlyFromList.indexOf(teamMode) == -1) {
                continue;
            }
            result.stats.values.push({
                alias: stat.alias,
                params: stat.params,
            });
        }
        var allLocations = Object.keys(LocationConstants.locationsPool).map(Number);
        var allBundleTagsWithoutPvE = BundlesUtils.getAllBundleTags(false);
        for (var _a = 0, _b = FriendFightSettings.rules; _a < _b.length; _a++) {
            var rule = _b[_a];
            if (rule.teamModeOnlyFromList && rule.teamModeOnlyFromList.indexOf(teamMode) == -1) {
                continue;
            }
            var battleId = rule.battleId;
            if (friendFightType == FRIEND_FIGHT_TYPE.LocalPvp) {
                battleId = FriendFightBattleUtils.getLocalFriendFightDuplicateIdByOriginalId(battleId);
                if (battleId == undefined) {
                    continue;
                }
            }
            var locationIds = rule.locationsOnlyFromList || allLocations;
            var locationsSelector = {
                name: "friend_fight_location_selection_label",
                values: [],
                defaultIndex: 0,
                cycled: true,
                hideText: false
            };
            var locationSelectorIds = [];
            var indexForLocations = 0;
            for (var _c = 0, locationIds_1 = locationIds; _c < locationIds_1.length; _c++) {
                var lid = locationIds_1[_c];
                var fightLocation = locationsMap.checkedGet(lid);
                if (allBundleTagsWithoutPvE.indexOf(fightLocation.AssetBundleTag) == -1) {
                    continue;
                }
                locationsSelector.values.push({ id: lid, alias: fightLocation.aliasName });
                locationSelectorIds.push(lid);
                indexForLocations++;
            }
            if (indexForLocations == 0) {
                continue;
            }
            var defaultLocationIndex = locationSelectorIds.indexOf(locations.bamboo_arena.ID);
            locationsSelector.defaultIndex = defaultLocationIndex == -1 ? 0 : defaultLocationIndex;
            var battleSettings_1 = battleSettingsMap.checkedGet(battleId);
            var battleRuleId = battleSettings_1.Rules && battleSettings_1.Rules[0];
            if (!battleRuleId) {
                throw new Error("getFriendFightBattleOptions: no fight rule in battle ".concat(battleId));
            }
            var battleRule = tournamentRulesMap.checkedGet(battleRuleId);
            result.fightRules.values.push({
                title: battleRule.Alias,
                description: battleRule.Description,
                battleId: battleId,
                locations: locationsSelector,
                roundsToWin: rule.overrideRoundsToWin || FriendFightSettings.roundsToWin[teamMode],
                roundDurations: rule.overrideRoundDurations || FriendFightSettings.roundsDuration[teamMode],
            });
        }
        return result;
    };
    FriendFightUtils.getFriendPlayersForBattle = function (settings) {
        var p1 = settings.p1, p2 = settings.p2, statParams = settings.statParams;
        var p1AccLevel = p1.accountLevel;
        var p2AccLevel = p2.accountLevel;
        var minHeroLevel = Infinity;
        var heroLevelBoundByRarity = 0;
        var minTalentLevel = Infinity;
        var modesWithDefaultWeapons = ["create_min", "create_balanced"];
        if (statParams.mode == "create_min") {
            p1AccLevel = p2AccLevel = 1;
        }
        else if (statParams.mode == "create_balanced") {
            p1AccLevel = p2AccLevel = Math.min(p1AccLevel, p2AccLevel);
        }
        var result = {
            p1: { accountLevel: p1AccLevel, warriors: [], },
            p2: { accountLevel: p2AccLevel, warriors: [], },
        };
        var iterator = [
            { resultWarriors: result.p1.warriors, sourceWarriors: p1.warriors },
            { resultWarriors: result.p2.warriors, sourceWarriors: p2.warriors },
        ];
        for (var _i = 0, iterator_1 = iterator; _i < iterator_1.length; _i++) {
            var iteration = iterator_1[_i];
            var resultWarriors = iteration.resultWarriors, sourceWarriors = iteration.sourceWarriors;
            for (var _a = 0, sourceWarriors_1 = sourceWarriors; _a < sourceWarriors_1.length; _a++) {
                var warrior = sourceWarriors_1[_a];
                var hero = heroesMap.checkedGet(warrior.heroId);
                minHeroLevel = Math.min(minHeroLevel, warrior.heroLevel);
                heroLevelBoundByRarity = Math.max(heroLevelBoundByRarity, hero.StartLevel);
                minTalentLevel = Math.min(minTalentLevel, warrior.talents.length);
                var skinId = warrior.skinId;
                skinId = isNumber(skinId) && skinId > 0 ? skinId : hero.DefaultSkinId;
                var skin = skinsMap.checkedGet(skinId);
                var weaponId = warrior.weaponId;
                weaponId = isNumber(weaponId) && weaponId > 0 ? weaponId : skin.WeaponId;
                if (!FriendFightUtils.isHoldWeapon(weaponId)) {
                    weaponId = modesWithDefaultWeapons.indexOf(statParams.mode) > -1
                        ? hero.getCommonWeaponIfNotSelected(skinId)
                        : weaponId;
                }
                resultWarriors.push({
                    heroId: hero.ID,
                    heroLevel: warrior.heroLevel,
                    talents: warrior.talents,
                    skinId: skinId,
                    weaponId: weaponId,
                });
            }
        }
        for (var _b = 0, iterator_2 = iterator; _b < iterator_2.length; _b++) {
            var iteration = iterator_2[_b];
            var resultWarriors = iteration.resultWarriors, _ = iteration.sourceWarriors;
            for (var _c = 0, resultWarriors_1 = resultWarriors; _c < resultWarriors_1.length; _c++) {
                var warrior = resultWarriors_1[_c];
                if (statParams.mode == "create_min") {
                    warrior.talents = [];
                    warrior.heroLevel = Math.max(1, heroLevelBoundByRarity);
                }
                else if (statParams.mode == "create_balanced") {
                    var hero = heroesMap.checkedGet(warrior.heroId);
                    warrior.talents = warrior.talents.slice(0, minTalentLevel);
                    warrior.heroLevel = Math.max(minHeroLevel, heroLevelBoundByRarity);
                }
            }
        }
        return result;
    };
    FriendFightUtils.isHoldWeapon = function (weaponId) {
        return FriendFightSettings.HOLD_WEAPONS.indexOf(weaponId) > -1;
    };
    return FriendFightUtils;
}());
