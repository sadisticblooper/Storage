var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
var MatchingConstants = (function () {
    function MatchingConstants() {
    }
    MatchingConstants.maxAbsStreak = 4;
    MatchingConstants.sandboxUpperRatingBound = (_a = {},
        _a[TEAM_MODE._1_VS_1_] = (_b = {},
            _b[0] = 120,
            _b[301] = 60,
            _b[701] = 30,
            _b),
        _a[TEAM_MODE._3_VS_3_] = (_c = {},
            _c[0] = 200,
            _c),
        _a);
    MatchingConstants.aiOpponentOnLostConnectionRatingLimit = (_d = {},
        _d[TEAM_MODE._1_VS_1_] = 400,
        _d[TEAM_MODE._3_VS_3_] = 0,
        _d);
    MatchingConstants.sandboxBotDelay = new Time({ Seconds: 1 }).value;
    MatchingConstants.strictMatchingSeconds = 3600 * 24;
    MatchingConstants.pvpServerCandidatesCount = 3;
    MatchingConstants.pvpServerCandidatesDistance = 2000000;
    MatchingConstants.winRateHistoryMinSize = 4;
    MatchingConstants.winRateHistoryMaxSize = 10;
    MatchingConstants.maxSumPing = 225;
    MatchingConstants.preferRelayDiff = 999999999;
    MatchingConstants.uniqueEnemySettings = {
        common: {
            uniqueEnemyThreshold1vs1: 2,
            uniqueEnemyThreshold3vs3: 2,
            uniqueEnemyThresholdTournament: 1,
            uniqueEnemyTimeout: 90,
        },
        withLowPriority: {
            uniqueEnemyThreshold1vs1: 2,
            uniqueEnemyThreshold3vs3: 2,
            uniqueEnemyThresholdTournament: 1,
            uniqueEnemyTimeout: 300,
        },
    };
    MatchingConstants.uniqueEnemyMaxThreshold = (function () {
        var excludeField = "uniqueEnemyTimeout";
        var max = 0;
        for (var groupName in MatchingConstants.uniqueEnemySettings) {
            var uniqueSettings = MatchingConstants.uniqueEnemySettings[groupName];
            for (var settingName in uniqueSettings) {
                if (settingName == excludeField) {
                    continue;
                }
                max = Math.max(max, uniqueSettings[settingName]);
            }
        }
        return max;
    })();
    MatchingConstants.sandboxMaxWaitTimeByRating = [
        { range: { start: 0, end: 99 }, items: [{ t1: 1, t2: 3 }] },
        { range: { start: 100, end: 199 }, items: [{ t1: 2, t2: 5 }] }
    ];
    MatchingConstants.matchingZones = (_e = {},
        _e[TEAM_MODE._1_VS_1_] = [
            [[0, 100], [0, -35, 35,]],
            [[101, 150], [0, -35, 35,]],
            [[151, 200], [0, -40, 40,]],
            [[201, 250], [0, -40, 40,]],
            [[251, 300], [0, -40, 40,]],
            [[301, 350], [0, -50, 50,]],
            [[351, 400], [0, -50, 50,]],
            [[401, 450], [0, -50, 50,]],
            [[451, 500], [0, -60, 60,]],
            [[501, 550], [0, -60, 60,]],
            [[551, 600], [0, -60, 60,]],
            [[601, 650], [0, -70, 70,]],
            [[651, 700], [0, -70, 70,]],
            [[701, 750], [0, -70, 70,]],
            [[751, 800], [0, -80, 80,]],
            [[801, 850], [0, -80, 80,]],
            [[851, 900], [0, -80, 80,]],
            [[901, 950], [0, -80, 80,]],
            [[951, 1000], [0, -90, 90,]],
            [[1001, 1100], [0, -90, 90,]],
        ],
        _e[TEAM_MODE._3_VS_3_] = [
            [[0, 175], [0, -105, 105,]],
            [[176, 350], [0, -105, 105,]],
            [[351, 525], [0, -120, 120,]],
            [[526, 700], [0, -120, 120,]],
            [[701, 875], [0, -120, 120,]],
            [[876, 1050], [0, -150, 150,]],
            [[1051, 1225], [0, -150, 150,]],
            [[1226, 1400], [0, -150, 150,]],
            [[1401, 1575], [0, -180, 180,]],
            [[1576, 1750], [0, -180, 180,]],
            [[1751, 1925], [0, -180, 180,]],
            [[1926, 2100], [0, -210, 210,]],
            [[2101, 2275], [0, -210, 210,]],
            [[2276, 2450], [0, -210, 210,]],
            [[2451, 2625], [0, -240, 240,]],
            [[2626, 2800], [0, -240, 240,]],
            [[2801, 2975], [0, -240, 700,]],
            [[2976, 3150], [0, -375, 700,]],
            [[3151, 3325], [0, -525, 700,]],
            [[3326, 3500], [0, -700, 700,]],
            [[3501, 3675], [0, -800, 700,]],
            [[3676, 3850], [0, -900, 700,]],
            [[3851, 4000], [0, -1050, 700,]]
        ],
        _e);
    MatchingConstants.timeFindOpponentsByRating = (_f = {},
        _f[TEAM_MODE._1_VS_1_] = [
            [[0, 200], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[201, 600], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[601, 1000], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1001, 1400], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1401, 1800], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1801, 2200], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[2201, 2600], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[2601, 3000], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[3001, 3400], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[3401, -1,], new Time({ Minutes: 1, Seconds: 30 }).value],
        ],
        _f[TEAM_MODE._3_VS_3_] = [
            [[0, 200], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[201, 600], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[601, 1000], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1001, 1400], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1401, 1800], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[1801, 2200], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[2201, 2600], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[2601, 3000], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[3001, 3400], new Time({ Minutes: 1, Seconds: 30 }).value],
            [[3401, -1,], new Time({ Minutes: 1, Seconds: 30 }).value],
        ],
        _f);
    MatchingConstants.matchmakingShowBotByRating = (_g = {},
        _g[TEAM_MODE._1_VS_1_] = [
            { range: { start: 0, end: 299 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 300, end: 399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 400, end: 499 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 500, end: 599 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 600, end: 999 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1000, end: 1399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1400, end: 1799 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1800, end: 2199 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 2200, end: 2599 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 2600, end: 2999 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 3000, end: 3399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 3400, end: 7000 }, items: [new Time({ Seconds: 46 }).value] },
        ],
        _g[TEAM_MODE._3_VS_3_] = [
            { range: { start: 0, end: 299 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 300, end: 399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 400, end: 499 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 500, end: 599 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 600, end: 999 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1000, end: 1399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1400, end: 1799 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 1800, end: 2199 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 2200, end: 2599 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 2600, end: 2999 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 3000, end: 3399 }, items: [new Time({ Seconds: 46 }).value] },
            { range: { start: 3400, end: 7000 }, items: [new Time({ Seconds: 46 }).value] },
        ],
        _g);
    MatchingConstants.heroAutoSelectTiming = (_h = {},
        _h[TEAM_MODE._1_VS_1_] = [
            { range: { start: 0, end: 599 }, items: [{ firstRound: 5, anotherRound: 5, }] },
            { range: { start: 600, end: 9999 }, items: [{ firstRound: 10, anotherRound: 10, }] },
        ],
        _h[TEAM_MODE._3_VS_3_] = [
            { range: { start: 0, end: 9999 }, items: [{ firstRound: 40, anotherRound: 20, }] },
        ],
        _h);
    MatchingConstants.autoSelectServerTimeout = 90;
    MatchingConstants.replaceButtonAIFightFromRating = (_j = {},
        _j[TEAM_MODE._1_VS_1_] = 700,
        _j[TEAM_MODE._3_VS_3_] = 2400,
        _j);
    MatchingConstants.upperRankRatingBoundForGettingBots = (_k = {},
        _k[TEAM_MODE._1_VS_1_] = MatchingConstants.replaceButtonAIFightFromRating[TEAM_MODE._1_VS_1_] + 0,
        _k[TEAM_MODE._3_VS_3_] = MatchingConstants.replaceButtonAIFightFromRating[TEAM_MODE._3_VS_3_] + 0,
        _k);
    MatchingConstants.relaxDishonestLoseStreakSettings = (_l = {},
        _l[TEAM_MODE._1_VS_1_] = {
            loseStreak: 3,
            powerDelta: 3
        },
        _l[TEAM_MODE._3_VS_3_] = {
            loseStreak: 3,
            powerDelta: 3
        },
        _l);
    MatchingConstants.rematchMaxNotWinsAllowed = 2;
    MatchingConstants.rematchButtonDuration = new Time({ Seconds: 20 }).value;
    MatchingConstants.rematchAutobotDecision = {
        start: new Time({ Seconds: 2 }).value,
        end: new Time({ Seconds: 5 }).value,
    };
    MatchingConstants.rematchAvailableModes = [
        FIGHT_MODE.RANKED,
        FIGHT_MODE.FRIEND,
        FIGHT_MODE.LOCAL_PVP_FRIEND,
        FIGHT_MODE.AI,
    ];
    return MatchingConstants;
}());
