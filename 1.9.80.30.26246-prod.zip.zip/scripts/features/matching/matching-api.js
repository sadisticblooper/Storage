function isMatchWithAutoBot(settings) {
    return MatchingModel.isMatchWithAutoBot(settings);
}
function updateWinRateHistory(settings) {
    return MatchingModel.updateWinRateHistory(settings);
}
function updateWinStreaks(settings) {
    return MatchingModel.updateWinStreaks(settings);
}
function getMatchingSettings3vs3(settings) {
    return MatchingModel.getMatchingSettings3vs3(settings);
}
function getMatchingSettings1vs1(settings) {
    return MatchingModel.getMatchingSettings1vs1(settings);
}
function getSandboxMaxWaitTime(settings) {
    return MatchingModel.getSandboxMaxWaitTime(settings);
}
function getMatchingConstants(teamMode, rating) {
    return MatchingModel.getMatchingConstants(teamMode, rating);
}
function getMatchmakingShowBot(s) {
    return MatchingModel.getMatchmakingShowBot(s);
}
function getTimeFindOpponents(s) {
    return MatchingModel.getTimeFindOpponentsByRating(s);
}
function getHeroAutoSelectTiming(settings) {
    return MatchingModel.getHeroAutoSelectTiming(settings);
}
function getRematchButtonDuration() {
    return MatchingConstants.rematchButtonDuration;
}
function isRematchAvailable(mode) {
    return MatchingModel.isRematchAvailable(mode);
}
function getRematchPermission(settings) {
    return MatchingModel.getRematchPermission(settings);
}
