var _a, _b;
var AutoBotSettings = (function () {
    function AutoBotSettings() {
    }
    AutoBotSettings.intervals = (_a = {},
        _a[TEAM_MODE._1_VS_1_] = [
            { range: { start: 0, end: 99999 },
                items: [
                    { wrMax: 1, botProb: 0.0, delay: new RndFromInterval(new Time({ Seconds: 8 }).value, new Time({ Seconds: 15 }).value), botPower: [{ w: 1, mlPreset: 1, power: 0 }] },
                ] },
        ],
        _a[TEAM_MODE._3_VS_3_] = [
            { range: { start: 0, end: 99999 },
                items: [
                    { wrMax: 1, botProb: 0.0, delay: new RndFromInterval(new Time({ Seconds: 8 }).value, new Time({ Seconds: 15 }).value), botPower: [{ w: 1, mlPreset: 1, power: 0 }] },
                ] },
        ],
        _a);
    AutoBotSettings.autoBotByTimeout = (_b = {},
        _b[TEAM_MODE._1_VS_1_] = [
            { range: { start: 0, end: 100 }, items: [new RndFromInterval(new Time({ Seconds: 15 }).value)] },
            { range: { start: 101, end: 200 }, items: [new RndFromInterval(new Time({ Seconds: 20 }).value)] },
            { range: { start: 201, end: 300 }, items: [new RndFromInterval(new Time({ Seconds: 30 }).value)] },
            { range: { start: 301, end: 400 }, items: [new RndFromInterval(new Time({ Seconds: 45 }).value)] },
            { range: { start: 401, end: 100000 }, items: null },
        ],
        _b[TEAM_MODE._3_VS_3_] = [
            { range: { start: 0, end: 200 }, items: [new RndFromInterval(new Time({ Seconds: 30 }).value)] },
            { range: { start: 201, end: 400 }, items: [new RndFromInterval(new Time({ Seconds: 45 }).value)] },
            { range: { start: 401, end: 600 }, items: [new RndFromInterval(new Time({ Seconds: 60 }).value)] },
            { range: { start: 601, end: 800 }, items: [new RndFromInterval(new Time({ Seconds: 120 }).value)] },
            { range: { start: 801, end: 100000 }, items: null },
        ],
        _b);
    return AutoBotSettings;
}());
