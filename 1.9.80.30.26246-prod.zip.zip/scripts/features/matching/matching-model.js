var MatchingModel = (function () {
    function MatchingModel() {
    }
    MatchingModel.isMatchWithAutoBot = function (settings) {
        var teamMode = settings.teamMode, winRateHistory = settings.winRateHistory, rankedBattleCount = settings.rankedBattleCount, rankRating = settings.rankRating, lowPriorityEnabled = settings.lowPriorityEnabled;
        var result = { isMatchWithAutoBot: false };
        if (lowPriorityEnabled) {
            return result;
        }
        var settingsForForceBotByTimeout = AutoBotSettings.autoBotByTimeout[teamMode];
        var ri = new PcgRandom(CommonUtils.getRandomJSSeed());
        var tableIndex = CommonGameUtils.getNumberIntervalIndex(rankRating, settingsForForceBotByTimeout);
        var timeoutSettings = settingsForForceBotByTimeout[tableIndex];
        if (timeoutSettings && timeoutSettings.items) {
            result = {
                isMatchWithAutoBot: true,
                settings: {
                    allowPvPMatching: true,
                    preset: 0,
                    delay: timeoutSettings.items[0].getRandomValue(ri),
                },
            };
        }
        var tableSettings = AutoBotSettings.intervals[teamMode];
        if (rankedBattleCount < MatchingConstants.winRateHistoryMinSize || !tableSettings) {
            return result;
        }
        var index = CommonGameUtils.getNumberIntervalIndex(rankRating, tableSettings);
        var intervalSettings = tableSettings[index];
        if (!intervalSettings) {
            return result;
        }
        var winRate = this.calcWinRate({
            winRateHistory: winRateHistory,
            rankedBattleCount: rankedBattleCount,
        });
        if (winRate < 0 || winRate > 1) {
            return result;
        }
        var indexWithWinRate = this.findWinRateIndex(intervalSettings, winRate);
        var matchingType = intervalSettings.items[indexWithWinRate];
        if (ri.nextDouble() < matchingType.botProb) {
            var collection = new RandomCollection();
            for (var i = 0; i < matchingType.botPower.length; i++) {
                var preset = matchingType.botPower[i];
                collection.add(new CollectionObjectContainer(i, preset.w));
            }
            if (!collection.size()) {
                return result;
            }
            var indexPreset = collection.next(ri).get();
            result.isMatchWithAutoBot = true;
            result.settings = {
                allowPvPMatching: false,
                preset: indexPreset,
                delay: matchingType.delay.getRandomValue(ri)
            };
        }
        return result;
    };
    MatchingModel.getAutoBotPreset = function (rating, winRate, indexPreset, teamMode) {
        var tableSettings = AutoBotSettings.intervals[teamMode];
        var index = CommonGameUtils.getNumberIntervalIndex(rating, tableSettings);
        var intervalSettings = tableSettings[index];
        var indexWithWinRate = this.findWinRateIndex(intervalSettings, winRate);
        var matchingType = intervalSettings.items[indexWithWinRate];
        return matchingType.botPower[indexPreset];
    };
    MatchingModel.findWinRateIndex = function (intervalSettings, winRate) {
        var diff = Infinity;
        var index = 0;
        for (var i = 0; i < intervalSettings.items.length; i++) {
            var item = intervalSettings.items[i];
            var localDiff = Math.abs(winRate - item.wrMax);
            if (localDiff < diff && winRate <= item.wrMax) {
                diff = localDiff;
                index = i;
            }
        }
        return index;
    };
    MatchingModel.updateWinRateHistory = function (settings) {
        var result = +settings.winRateHistory;
        var cutMask = (1 << MatchingConstants.winRateHistoryMaxSize) - 1;
        result = result << 1;
        if (settings.fightResult == FIGHT_RESULT.WIN || settings.fightResult == FIGHT_RESULT.TECH_WIN) {
            result = result | 1;
        }
        return result & cutMask;
    };
    MatchingModel.calcWinRate = function (settings) {
        var winRateHistory = settings.winRateHistory, rankedBattleCount = settings.rankedBattleCount;
        if (rankedBattleCount < MatchingConstants.winRateHistoryMinSize || rankedBattleCount < 1) {
            return -1;
        }
        var size = Math.min(MatchingConstants.winRateHistoryMaxSize, rankedBattleCount);
        var winCount = BitMaskUtils.getOrderNumbersFromInt(winRateHistory, size).length;
        return winCount / size;
    };
    MatchingModel.updateWinStreaks = function (settings) {
        var streaksPvp = settings.streaksPvp, fightResult = settings.fightResult, heroId = settings.heroId, matchingInfo = settings.matchingInfo, streakTournament = settings.streakTournament;
        var result = { streaksPvp: streaksPvp, streakTournament: streakTournament };
        var isPvpMode = matchingInfo.enemyMode == ENEMY_MODE.AUTO_BOT || matchingInfo.enemyMode == ENEMY_MODE.PVP;
        if (isPvpMode) {
            switch (matchingInfo.mode) {
                case FIGHT_MODE.RANKED:
                    if (heroId) {
                        var streak = streaksPvp.heroesStreak[heroId] || 0;
                        result.streaksPvp.heroesStreak[heroId] = this.calcStreak(streak, settings.fightResult);
                    }
                    else {
                        var streak = streaksPvp.teamStreak || 0;
                        result.streaksPvp.teamStreak = this.calcStreak(streak, settings.fightResult);
                    }
                    break;
                case FIGHT_MODE.TOURNAMENT:
                    result.streakTournament = this.calcStreak(result.streakTournament, settings.fightResult);
                    break;
            }
        }
        return result;
    };
    MatchingModel.calcStreak = function (streak, fightResult) {
        var maxAbsWinStreak = MatchingConstants.maxAbsStreak;
        switch (fightResult) {
            case FIGHT_RESULT.WIN:
            case FIGHT_RESULT.TECH_WIN:
                return streak <= 0 ? 1 : Math.min(maxAbsWinStreak, streak + 1);
            case FIGHT_RESULT.LOSE:
            case FIGHT_RESULT.TECH_LOSE:
            case FIGHT_RESULT.SURRENDER:
                return streak >= 0 ? -1 : Math.max(-maxAbsWinStreak, streak - 1);
            case FIGHT_RESULT.DRAW:
            case FIGHT_RESULT.TECH_DRAW:
                return 0;
            default:
                return streak;
        }
    };
    MatchingModel.getRatingInterval = function (intervals, rankRating) {
        if (!intervals) {
            return null;
        }
        var interval = null;
        for (var _i = 0, intervals_1 = intervals; _i < intervals_1.length; _i++) {
            var ratingInterval = intervals_1[_i];
            var startRankRating = ratingInterval[0][0];
            var endRankRating = ratingInterval[0][1];
            if ((startRankRating == -1 || startRankRating <= rankRating)
                && (endRankRating == -1 || endRankRating >= rankRating)) {
                interval = ratingInterval;
                break;
            }
        }
        return interval;
    };
    MatchingModel.getMatchingSettings3vs3 = function (settings) {
        var mode = TEAM_MODE._3_VS_3_;
        var rating = settings.rating, rankRating = settings.rankRating, accountLevel = settings.accountLevel, streak = settings.streak, maxHeroLevel = settings.maxHeroLevel, lowPriorityEnabled = settings.lowPriorityEnabled;
        var result = [];
        var defaultRatingMin = 0;
        var defaultRatingMax = CalculationRatingSettings.rankRatingCap[mode];
        var defaultLevelMin = 0;
        var defaultLevelMax = MAX_ACCOUNT_LEVEL;
        var defaultStreakMin = -MatchingConstants.maxAbsStreak;
        var defaultStreakMax = MatchingConstants.maxAbsStreak;
        var matchingConstants = getMatchingConstants(mode, rating);
        var uniqueEnemySettings = MatchingModel.getUniqueEnemySettings(lowPriorityEnabled);
        var uniqueEnemyThreshold = uniqueEnemySettings.uniqueEnemyThreshold3vs3;
        var uniqueEnemyTimeout = uniqueEnemySettings.uniqueEnemyTimeout;
        var powerLevel = accountLevel + maxHeroLevel;
        var relaxDelta = MatchingModel.getDeltaPowerToRelaxLoseStreak(mode, streak, powerLevel, rankRating);
        var defaultPowerLevelMin = 0;
        var defaultPowerLevelMax = HeroConstants.maxHeroLevel + MAX_ACCOUNT_LEVEL;
        var defaultResult = {
            zones: [{
                    second: 0,
                    minAccountLevel: defaultLevelMin,
                    maxAccountLevel: defaultLevelMax,
                    minRankRating: defaultRatingMin,
                    maxRankRating: defaultRatingMax,
                    minStreak: defaultStreakMin,
                    maxStreak: defaultStreakMax,
                    minPowerLevel: null,
                    maxPowerLevel: null,
                }],
            uniqueEnemyThreshold: uniqueEnemyThreshold,
            uniqueEnemyTimeout: uniqueEnemyTimeout,
            relaxLoseStreakEnabled: false,
        };
        var zoneSettings = this.getRatingInterval(MatchingConstants.matchingZones[mode], rankRating);
        if (!zoneSettings) {
            return defaultResult;
        }
        for (var index = 1; index < zoneSettings.length; index++) {
            var zone = zoneSettings[index].slice();
            var second = zone[0] == undefined ? 0 : zone[0];
            var minRating = MatchingModel.getZoneValue(zone[1], rankRating, defaultRatingMin, Math.max);
            var maxRating = MatchingModel.getZoneValue(zone[2], rankRating, defaultRatingMax, Math.min);
            var minLevel = MatchingModel.getZoneValue(zone[3], accountLevel, defaultLevelMin, Math.max);
            var maxLevel = MatchingModel.getZoneValue(zone[4], accountLevel, defaultLevelMax, Math.min);
            var minStreak = MatchingModel.getZoneValue(zone[5], streak, defaultStreakMin, Math.max);
            var maxStreak = MatchingModel.getZoneValue(zone[6], streak, defaultStreakMax, Math.min);
            var minPowerLevel = relaxDelta ? MatchingModel.getZoneValue(-relaxDelta, powerLevel, defaultPowerLevelMin, Math.max) : null;
            var maxPowerLevel = relaxDelta ? MatchingModel.getZoneValue(relaxDelta, powerLevel, defaultPowerLevelMax, Math.min) : null;
            if (rankRating > matchingConstants.sandboxUpperRatingBound) {
                minRating = Math.max(minRating, matchingConstants.sandboxUpperRatingBound);
            }
            if (index == zoneSettings.length - 1 && uniqueEnemyTimeout == null) {
                uniqueEnemyTimeout = second;
            }
            result.push({
                second: second,
                minRankRating: minRating,
                maxRankRating: maxRating,
                minAccountLevel: minLevel,
                maxAccountLevel: maxLevel,
                minStreak: minStreak,
                maxStreak: maxStreak,
                minPowerLevel: minPowerLevel,
                maxPowerLevel: maxPowerLevel,
            });
        }
        return {
            zones: result,
            uniqueEnemyTimeout: uniqueEnemyTimeout,
            uniqueEnemyThreshold: uniqueEnemyThreshold,
            relaxLoseStreakEnabled: relaxDelta > 0,
        };
    };
    MatchingModel.getMatchingSettings1vs1 = function (settings) {
        var mode = TEAM_MODE._1_VS_1_;
        var rating = settings.rating, rankRating = settings.rankRating, accountLevel = settings.accountLevel, heroLevel = settings.heroLevel, streak = settings.streak, lowPriorityEnabled = settings.lowPriorityEnabled;
        var result = [];
        var defaultRatingMin = 0;
        var defaultRatingMax = CalculationRatingSettings.rankRatingCap[mode];
        var defaultLevelMin = 0;
        var defaultLevelMax = MAX_ACCOUNT_LEVEL;
        var defaultHeroLevelMin = 0;
        var defaultHeroLevelMax = HeroConstants.maxHeroLevel;
        var matchingConstants = getMatchingConstants(mode, rating);
        var uniqueEnemySettings = MatchingModel.getUniqueEnemySettings(lowPriorityEnabled);
        var uniqueEnemyThreshold = uniqueEnemySettings.uniqueEnemyThreshold1vs1;
        var uniqueEnemyTimeout = uniqueEnemySettings.uniqueEnemyTimeout;
        var powerLevel = accountLevel + heroLevel;
        var relaxDelta = MatchingModel.getDeltaPowerToRelaxLoseStreak(mode, streak, powerLevel, rankRating);
        var defaultPowerLevelMin = 0;
        var defaultPowerLevelMax = HeroConstants.maxHeroLevel + MAX_ACCOUNT_LEVEL;
        var defaultResult = {
            zones: [{
                    second: 0,
                    minAccountLevel: defaultLevelMin,
                    maxAccountLevel: defaultLevelMax,
                    minRankRating: defaultRatingMin,
                    maxRankRating: defaultRatingMax,
                    minHeroLevel: defaultHeroLevelMin,
                    maxHeroLevel: defaultHeroLevelMax,
                    minPowerLevel: null,
                    maxPowerLevel: null,
                }],
            uniqueEnemyThreshold: uniqueEnemyThreshold,
            uniqueEnemyTimeout: uniqueEnemyTimeout,
            relaxLoseStreakEnabled: false,
        };
        var zoneSettings = this.getRatingInterval(MatchingConstants.matchingZones[mode], rankRating);
        if (!zoneSettings) {
            return defaultResult;
        }
        for (var index = 1; index < zoneSettings.length; index++) {
            var zone = zoneSettings[index].slice();
            var second = zone[0] == undefined ? 0 : zone[0];
            var minRating = MatchingModel.getZoneValue(zone[1], rankRating, defaultRatingMin, Math.max);
            var maxRating = MatchingModel.getZoneValue(zone[2], rankRating, defaultRatingMax, Math.min);
            var minLevel = MatchingModel.getZoneValue(zone[3], accountLevel, defaultLevelMin, Math.max);
            var maxLevel = MatchingModel.getZoneValue(zone[4], accountLevel, defaultLevelMax, Math.min);
            var minHeroLevel = MatchingModel.getZoneValue(zone[5], heroLevel, defaultHeroLevelMin, Math.max);
            var maxHeroLevel = MatchingModel.getZoneValue(zone[6], heroLevel, defaultHeroLevelMax, Math.min);
            var minPowerLevel = relaxDelta ? MatchingModel.getZoneValue(-relaxDelta, powerLevel, defaultPowerLevelMin, Math.max) : null;
            var maxPowerLevel = relaxDelta ? MatchingModel.getZoneValue(relaxDelta, powerLevel, defaultPowerLevelMax, Math.min) : null;
            if (rankRating > matchingConstants.sandboxUpperRatingBound) {
                minRating = Math.max(minRating, matchingConstants.sandboxUpperRatingBound);
            }
            if (index == zoneSettings.length - 1 && uniqueEnemyTimeout == null) {
                uniqueEnemyTimeout = second;
            }
            result.push({
                second: second,
                minRankRating: minRating,
                maxRankRating: maxRating,
                minAccountLevel: minLevel,
                maxAccountLevel: maxLevel,
                minHeroLevel: minHeroLevel,
                maxHeroLevel: maxHeroLevel,
                minPowerLevel: minPowerLevel,
                maxPowerLevel: maxPowerLevel,
            });
        }
        return {
            zones: result,
            uniqueEnemyTimeout: uniqueEnemyTimeout,
            uniqueEnemyThreshold: uniqueEnemyThreshold,
            relaxLoseStreakEnabled: relaxDelta > 0,
        };
    };
    MatchingModel.getZoneValue = function (zoneValue, playerValue, clampValue, clampFunction) {
        if (!isNumber(zoneValue)) {
            return null;
        }
        return clampFunction(playerValue + zoneValue, clampValue);
    };
    MatchingModel.getSandboxMaxWaitTime = function (settings) {
        var rankRating = settings.rankRating;
        var index = CommonGameUtils.getNumberIntervalIndex(rankRating, MatchingConstants.sandboxMaxWaitTimeByRating);
        var t1 = MatchingConstants.sandboxMaxWaitTimeByRating[index].items[0].t1;
        var t2 = MatchingConstants.sandboxMaxWaitTimeByRating[index].items[0].t2;
        var interval = new RndFromInterval(t1, t2);
        RandomInstance.setSeed(CommonUtils.getRandomJSSeed());
        return interval.getRandomValue(RandomInstance) * 1000;
    };
    MatchingModel.getMatchingConstants = function (teamMode, rating) {
        return {
            maxAbsStreak: MatchingConstants.maxAbsStreak,
            pvpServerCandidatesCount: MatchingConstants.pvpServerCandidatesCount,
            pvpServerCandidatesDistance: MatchingConstants.pvpServerCandidatesDistance,
            sandboxBotDelay: MatchingConstants.sandboxBotDelay,
            sandboxUpperRatingBound: MatchingModel.getSandboxUpperRatingBound(teamMode, rating),
            strictMatchingSeconds: MatchingConstants.strictMatchingSeconds,
            winRateHistoryMaxSize: MatchingConstants.winRateHistoryMaxSize,
            winRateHistoryMinSize: MatchingConstants.winRateHistoryMinSize,
            maxSumPing: MatchingConstants.maxSumPing,
            aiOpponentOnLostConnectionRatingLimit: MatchingConstants.aiOpponentOnLostConnectionRatingLimit[teamMode],
            replaceButtonAIFightFromRating: MatchingConstants.replaceButtonAIFightFromRating[teamMode],
        };
    };
    MatchingModel.getMatchmakingShowBot = function (s) {
        var settings = MatchingConstants.matchmakingShowBotByRating[s.teamMode];
        if (!settings || settings.length == 0) {
            return new Time({ Seconds: 20 }).value;
        }
        var index = CommonGameUtils.getNumberIntervalIndex(s.rankRating, settings);
        return settings[index].items[0];
    };
    MatchingModel.getTimeFindOpponentsByRating = function (s) {
        var rating = s.rankRating;
        var intervalIndex = -1;
        var start, end;
        var settings = MatchingConstants.timeFindOpponentsByRating[s.teamMode];
        if (settings) {
            for (var index = 0; index < settings.length; index++) {
                start = settings[index][0][0];
                end = settings[index][0][1];
                if ((start == -1 || start <= rating) && (end == -1 || end >= rating)) {
                    intervalIndex = index;
                    break;
                }
            }
        }
        if (!settings || intervalIndex == -1 || settings[intervalIndex][1] == undefined) {
            return new Time({ Minutes: 1, Seconds: 30 }).value;
        }
        return Number(settings[intervalIndex][1]);
    };
    MatchingModel.getHeroAutoSelectTiming = function (settings) {
        var serverTimeout = MatchingConstants.autoSelectServerTimeout;
        var defaultResultForFirstRound = {
            singleModeRound: 10,
            squadModeRound: 40,
            serverTimeout: serverTimeout,
        };
        var defaultResultForAnotherRound = {
            singleModeRound: 10,
            squadModeRound: 20,
            serverTimeout: serverTimeout,
        };
        var defaultResultForFightWithBot = {
            singleModeRound: 9,
            squadModeRound: 9,
            serverTimeout: serverTimeout,
        };
        var result = {
            serverTimeout: serverTimeout,
            singleModeRound: 0,
            squadModeRound: 0,
        };
        var enemyRankRating = settings.enemyRankRating, playerRankRating = settings.playerRankRating, enemyMode = settings.enemyMode, round = settings.round;
        var teamModes = [TEAM_MODE._1_VS_1_, TEAM_MODE._3_VS_3_];
        if (enemyMode == ENEMY_MODE.AUTO_BOT || enemyMode == ENEMY_MODE.COMMON_BOT) {
            return defaultResultForFightWithBot;
        }
        for (var _i = 0, teamModes_1 = teamModes; _i < teamModes_1.length; _i++) {
            var teamMode = teamModes_1[_i];
            var table = MatchingConstants.heroAutoSelectTiming[teamMode];
            if (!table) {
                return round > 1 ? defaultResultForFirstRound : defaultResultForAnotherRound;
            }
            var rating = Math.max(playerRankRating, enemyRankRating);
            var index = CommonGameUtils.getNumberIntervalIndex(rating, table);
            var resultSettings = table[index];
            if (!resultSettings) {
                return round > 1 ? defaultResultForFirstRound : defaultResultForAnotherRound;
            }
            var time = round > 1 ? resultSettings.items[0].anotherRound : resultSettings.items[0].firstRound;
            if (teamMode == TEAM_MODE._1_VS_1_) {
                result.singleModeRound = time;
            }
            else if (teamMode == TEAM_MODE._3_VS_3_) {
                result.squadModeRound = time;
            }
        }
        return result;
    };
    MatchingModel.getSandboxUpperRatingBound = function (teamMode, rating) {
        var result = CommonUtils.getValueFromThresholdMap(MatchingConstants.sandboxUpperRatingBound[teamMode], rating);
        if (result === undefined) {
            throwDebugOrReturnDefault("getSandboxUpperRatingBound: no value in sandbox range\n                \rwith ".concat(teamMode, " mode and ").concat(rating, " rating"));
        }
        return result;
    };
    MatchingModel.getDeltaPowerToRelaxLoseStreak = function (teamMode, streak, powerLevel, rankRating) {
        var settings = MatchingConstants.relaxDishonestLoseStreakSettings[teamMode];
        var table = CalculationRatingSettings.deltaRatingSettings[teamMode];
        var index = CommonGameUtils.getNumberIntervalIndex(rankRating, table);
        var levels = table[index].items[0];
        var tablePowerLevel = levels.accountLevel + levels.maxHeroLevel;
        return streak <= -settings.loseStreak && powerLevel <= tablePowerLevel ? settings.powerDelta : 0;
    };
    MatchingModel.isRankRatingBoundForBotsReached = function (matchingInfo, currentRankRating) {
        var teamMode = matchingInfo.teamMode, enemyMode = matchingInfo.enemyMode;
        return [ENEMY_MODE.COMMON_BOT, ENEMY_MODE.AUTO_BOT].indexOf(enemyMode) > -1
            && currentRankRating > MatchingConstants.replaceButtonAIFightFromRating[teamMode];
    };
    MatchingModel.isRematchAvailable = function (mode) {
        return MatchingConstants.rematchAvailableModes.indexOf(mode) > -1;
    };
    MatchingModel.getRematchPermission = function (settings) {
        var fightMode = settings.fightMode, fights = settings.fights, enemyMode = settings.enemyMode;
        if (!isRematchAvailable(fightMode)) {
            return false;
        }
        if (fightMode == FIGHT_MODE.FRIEND || fightMode == FIGHT_MODE.LOCAL_PVP_FRIEND || fightMode == FIGHT_MODE.AI) {
            return true;
        }
        if (enemyMode == ENEMY_MODE.AUTO_BOT && fights.length >= BotConstants.rematchBotSettings.autobotRematchTimes + 1) {
            return false;
        }
        var p1NotWins = 0;
        var p2NotWins = 0;
        for (var i = 0; i < fights.length; i++) {
            if (fights[i].p1 != FIGHT_RESULT.WIN && fights[i].p1 != FIGHT_RESULT.TECH_WIN) {
                p1NotWins++;
            }
            if (fights[i].p2 != FIGHT_RESULT.WIN && fights[i].p2 != FIGHT_RESULT.TECH_WIN) {
                p2NotWins++;
            }
        }
        return Math.max(p1NotWins, p2NotWins) < MatchingConstants.rematchMaxNotWinsAllowed;
    };
    MatchingModel.getUniqueEnemySettings = function (lowPriorityEnabled) {
        return lowPriorityEnabled
            ? MatchingConstants.uniqueEnemySettings.withLowPriority
            : MatchingConstants.uniqueEnemySettings.common;
    };
    return MatchingModel;
}());
