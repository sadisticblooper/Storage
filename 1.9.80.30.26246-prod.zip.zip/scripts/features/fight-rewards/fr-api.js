function getFightRewardResetLabelInfo(settings) {
    return FightRewards.getFightRewardResetLabelInfo(settings);
}
