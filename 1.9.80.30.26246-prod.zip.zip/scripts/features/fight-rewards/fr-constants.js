var _a;
var FightRewardsConstants = (function () {
    function FightRewardsConstants() {
    }
    FightRewardsConstants.timeCircle = {
        Origin: "2016-01-01T03:00:00+03:00",
        Period: new Time({ Hours: 24 }).value,
    };
    FightRewardsConstants.fightTypesForRewards = [
        FIGHT_MODE.RANKED,
        FIGHT_MODE.PRE_TUTORIAL,
    ];
    FightRewardsConstants.battlePassPointsProgression = {
        initPoints: 50,
        minPoints: 5,
        decDelta: 5,
    };
    FightRewardsConstants.rankedCompensationNotWin = (_a = {}, _a[CURRENCY.COIN] = 20, _a);
    FightRewardsConstants.fightModesForBPProgression = [
        FIGHT_MODE.RANKED,
        FIGHT_MODE.ROGUELIKE_COMMON,
        FIGHT_MODE.ROGUELIKE_SURVIVAL,
        FIGHT_MODE.TOURNAMENT,
    ];
    return FightRewardsConstants;
}());
