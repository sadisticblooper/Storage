var FightRewardsSlots = (function () {
    function FightRewardsSlots() {
    }
    return FightRewardsSlots;
}());
