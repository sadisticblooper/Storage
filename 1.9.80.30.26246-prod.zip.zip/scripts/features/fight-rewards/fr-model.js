var FightRewards = (function () {
    function FightRewards() {
    }
    FightRewards.generateFightRewardForPlayer = function (settings) {
        var _a;
        var fightRewardProgressionCounters = settings.fightRewardProgressionCounters;
        var matchingInfo = settings.matchingInfo;
        if (!FightRewards.isRewardForFightResult(settings.fightResult)) {
            return null;
        }
        if (TutorialModel.isTutorialFight(settings.battleId)) {
            return TutorialModel.getFightRewardForTutorial(settings.fightResult, settings.battleId, settings.seed, fightRewardProgressionCounters);
        }
        if (!FightRewards.isFightRewardAvailableForMode(matchingInfo.mode)
            || MatchingModel.isRankRatingBoundForBotsReached(matchingInfo, settings.rankRating)) {
            return null;
        }
        var isBpConversion = BattlePass.doNeedConvertBattlePassPoints(settings.battlePassProgress);
        var adViewCounterInRanked = settings.adViewCounterInRanked;
        var isWin = ((_a = {}, _a[FIGHT_RESULT.WIN] = true, _a[FIGHT_RESULT.TECH_WIN] = true, _a)[settings.fightResult]);
        var reward;
        if (isWin) {
            reward = FightRewards.getBattlePassPointsLootFromProgression(fightRewardProgressionCounters);
            FightRewards.incFightRewardProgressionCounter(fightRewardProgressionCounters, FIGHT_MODE.RANKED);
        }
        else {
            reward = FightRewards.getRankedCompensationForNotWin();
        }
        if (isBpConversion) {
            reward = BattlePassUtils.convertBattlePassLoot(reward, settings.battlePassProgress);
        }
        var isNotTutorial = matchingInfo.mode != FIGHT_MODE.TUTORIAL && matchingInfo.mode != FIGHT_MODE.PRE_TUTORIAL;
        if (Advertising.isEnable(ADVERTISING_PLACE.FIGHT_REWARD)
            && Advertising.isAvailableByCounter(ADVERTISING_PLACE.FIGHT_REWARD, adViewCounterInRanked)
            && isNotTutorial) {
            reward.setAdvertising({
                Place: ADVERTISING_PLACE.FIGHT_REWARD,
                Quantity: 1,
            });
        }
        if (!reward || (reward.isEmpty() && !reward.isAdvertising())) {
            throw new Error("Loot is empty or null in generateFightRewardForPlayer."
                + JSON.stringify([settings]));
        }
        return {
            loot: reward,
            newSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
            fightRewardProgressionCounters: fightRewardProgressionCounters
        };
    };
    FightRewards.getFightRewardResetLabelInfo = function (settings) {
        var currentServerTime = settings.currentServerTime, hasBattlePassPoints = settings.hasBattlePassPoints, isTutorialActive = settings.isTutorialActive, isAdvertisementLimitReached = settings.isAdvertisementLimitReached, dailyFightWonCount = settings.dailyFightWonCount;
        var scheduleByAdCard = AdvertisingConstants.advertisingSchedule;
        if (isTutorialActive) {
            return { showLabel: false };
        }
        if (isAdvertisementLimitReached) {
            return { showLabel: true, resetTime: CommonUtils.getTimeOfNearestUpdate(scheduleByAdCard, currentServerTime) };
        }
        var _a = FightRewardsConstants.battlePassPointsProgression, minPoints = _a.minPoints, decDelta = _a.decDelta, initPoints = _a.initPoints;
        var points = Math.max(minPoints, Math.ceil(initPoints - decDelta * dailyFightWonCount));
        var scheduleByBattlePassPoints = FightRewardsConstants.timeCircle;
        if (hasBattlePassPoints && points <= minPoints) {
            return {
                showLabel: true,
                resetTime: CommonUtils.getTimeOfNearestUpdate(scheduleByBattlePassPoints, currentServerTime),
            };
        }
        return { showLabel: false };
    };
    FightRewards.isFightRewardAvailableForMode = function (mode) {
        return FightRewardsConstants.fightTypesForRewards.indexOf(mode) > -1;
    };
    FightRewards.isRewardForFightResult = function (fightResult) {
        return [
            FIGHT_RESULT.WIN,
            FIGHT_RESULT.TECH_WIN,
            FIGHT_RESULT.LOSE,
            FIGHT_RESULT.DRAW,
        ].indexOf(fightResult) > -1;
    };
    FightRewards.getBattlePassPointsLootFromProgression = function (fightRewardProgressionCounters) {
        var rewardSetting = FightRewardsConstants.battlePassPointsProgression;
        var dailyFightWonCount = FightRewards.calcFightRewardProgressionCounter(fightRewardProgressionCounters);
        var initPoints = rewardSetting.initPoints, decDelta = rewardSetting.decDelta, minPoints = rewardSetting.minPoints;
        var points = Math.max(minPoints, Math.ceil(initPoints - decDelta * dailyFightWonCount));
        return new Loot({ BattlePassPoints: points });
    };
    FightRewards.getRankedCompensationForNotWin = function () {
        return new Loot({ Currencies: FightRewardsConstants.rankedCompensationNotWin });
    };
    FightRewards.incFightRewardProgressionCounter = function (fightRewardProgressionCounters, mode) {
        fightRewardProgressionCounters[mode] = (fightRewardProgressionCounters[mode] || 0) + 1;
    };
    FightRewards.calcFightRewardProgressionCounter = function (fightRewardProgressionCounters) {
        var result = 0;
        for (var _i = 0, _a = FightRewardsConstants.fightModesForBPProgression; _i < _a.length; _i++) {
            var mode = _a[_i];
            result += fightRewardProgressionCounters[mode] || 0;
        }
        return result;
    };
    return FightRewards;
}());
