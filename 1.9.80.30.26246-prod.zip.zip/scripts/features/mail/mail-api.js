function getMailMessages(settings) {
    return MailMessagesUtils.getMailMessages(settings);
}
function getMailMessage(settings) {
    return MailMessagesUtils.getMailMessage(settings);
}
function isMailMessageExists(id) {
    return Boolean(mailMessagesMap.get(id));
}
function getMailMessageCombinedRewards(settings) {
    return MailMessagesUtils.getMailMessageCombinedRewards(settings);
}
function getAdminMailMessageCombinedRewards(settings) {
    return MailMessagesUtils.getAdminMailMessageCombinedRewards(settings);
}
