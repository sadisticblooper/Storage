var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
var MailConstants = (function () {
    function MailConstants() {
    }
    MailConstants.storageDays = 30;
    MailConstants.messagesLimit = 50;
    MailConstants.maxLengthForHeader = 100;
    MailConstants.maxLengthForSubHeader = 100;
    MailConstants.maxLengthForBody = 2147483647;
    MailConstants.defaultSendMailDateDelayMs = new Time({ Minutes: 15 }).value;
    MailConstants.tier6TalentsReleaseDate = new Date("2024-10-25").getTime();
    MailConstants.heroMessageSettings = (_a = {},
        _a[HeroNames.Ling.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_ling_surprise", body: "mail_body_max_ling_surprise" },
        },
        _a[HeroNames.Monk.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_monk_surprise", body: "mail_body_max_monk_surprise" },
        },
        _a[HeroNames.Liquidator.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_kate_surprise", body: "mail_body_max_kate_surprise" },
        },
        _a[HeroNames.Ironclad.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_ironclad_surprise", body: "mail_body_max_ironclad_surprise" },
        },
        _a[HeroNames.Fireguard.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_fireguard_surprise", body: "mail_body_max_fireguard_surprise" },
        },
        _a[HeroNames.Helga.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_helga_surprise", body: "mail_body_max_helga_surprise" },
        },
        _a[HeroNames.Jet.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_jet_surprise", body: "mail_body_max_jet_surprise" },
        },
        _a[HeroNames.Midnight.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_midnight_surprise", body: "mail_body_max_midnight_surprise" },
        },
        _a[HeroNames.Feldsher.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_adzuma_surprise", body: "mail_body_max_adzuma_surprise" },
        },
        _a[HeroNames.Yukka.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_yukka_surprise", body: "mail_body_max_yukka_surprise" },
        },
        _a[HeroNames.Bulwark.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_bulwark_surprise", body: "mail_body_max_bulwark_surprise" },
        },
        _a[HeroNames.Emperor.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_emperor_surprise", body: "mail_body_max_emperor_surprise" },
        },
        _a[HeroNames.Kibo.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_kibo_surprise", body: "mail_body_max_kibo_surprise" },
        },
        _a[HeroNames.Marcus.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_markus_surprise", body: "mail_body_max_markus_surprise" },
        },
        _a[HeroNames.Sarge.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_sarge_surprise", body: "mail_body_max_sarge_surprise" },
        },
        _a[HeroNames.HongJoo.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_hong_joo_surprise", body: "mail_body_max_hong_joo_surprise" },
        },
        _a[HeroNames.Lynx.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_lynx_surprise", body: "mail_body_max_lynx_surprise" },
        },
        _a[HeroNames.Monkey_King.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_monkey_king_surprise", body: "mail_body_max_monkey_king_surprise" },
        },
        _a[HeroNames.Viper.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_cobra_surprise", body: "mail_body_max_cobra_surprise" },
        },
        _a[HeroNames.Legion_King.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_legion_king_surprise", body: "mail_body_max_legion_king_surprise" },
        },
        _a[HeroNames.Butcher.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_butcher_surprise", body: "mail_body_max_butcher_surprise" },
        },
        _a[HeroNames.Itu.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_itu_surprise", body: "mail_body_max_itu_surprise" },
        },
        _a[HeroNames.Yunlin.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_yunlin_surprise", body: "mail_body_max_yunlin_surprise" },
        },
        _a[HeroNames.Xiang_Tzu.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_xiang_tzu_surprise", body: "mail_body_max_xiang_tzu_surprise" },
        },
        _a[HeroNames.June.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_june_surprise", body: "mail_body_max_june_surprise" },
        },
        _a[HeroNames.Gideon.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_gideon_surprise", body: "mail_body_max_gideon_surprise" },
        },
        _a[HeroNames.Widow.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_widow_surprise", body: "mail_body_max_widow_surprise" },
        },
        _a[HeroNames.Raikichi.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_raikichi_surprise", body: "mail_body_max_raikichi_surprise" },
        },
        _a[HeroNames.Nonna.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_nonna_surprise", body: "mail_body_max_nonna_surprise" },
        },
        _a[HeroNames.Shogun.ID] = {
            maxUpgradeAliases: { title: "mail_title_max_shogun_surprise", body: "mail_body_max_shogun_surprise" },
        },
        _a);
    MailConstants.fightMessagesAliases = {
        501: { title: "mail_title_500_fights_surprise", body: "mail_body_500_fights_surprise" },
        1001: { title: "mail_title_1000_fights_surprise", body: "mail_body_1000_fights_surprise" },
        2001: { title: "mail_title_2000_fights_surprise", body: "mail_body_2000_fights_surprise" },
    };
    MailConstants.seasonMigrationMessageStart = new Date("2025-12-16").getTime();
    MailConstants.seasonReworkMigrationCheck = function (settings) {
        var migrationVersion = "1.9.60";
        var playerMigrationVersion = (settings.migrationData && settings.migrationData.versionBefore) || "";
        if (!playerMigrationVersion) {
            return false;
        }
        return CommonUtils.compareVersions(migrationVersion, playerMigrationVersion) > 0;
    };
    MailConstants.characterIcons = __assign(__assign({}, QuestViewHeroes.heroIcons), { shogunMinion: 'Sprites/PreviewImages/Quests/Shogun/icon_challenge_Shogun_base_minion' });
    return MailConstants;
}());
