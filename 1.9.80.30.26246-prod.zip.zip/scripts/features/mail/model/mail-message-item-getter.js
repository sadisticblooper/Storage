var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var MailMessageToOffersConverter = (function () {
    function MailMessageToOffersConverter() {
    }
    MailMessageToOffersConverter.prototype.Args = function (p) {
        return __assign(__assign({}, p), { generatedOffers: this.generatedMailsToOffers(p.generatedMailMessages, p.closedMailMessagesBitSetIntArray, p.serverCurrentTime), generatedRoulette: [] });
    };
    MailMessageToOffersConverter.prototype.Result = function (p) {
        var result = {};
        var items = p.offers;
        if (items) {
            for (var id in items)
                if (items[id] != undefined) {
                    result[+id] = {
                        expireTime: items[id].expireTime,
                        seed: items[id].seed,
                    };
                }
        }
        return result;
    };
    MailMessageToOffersConverter.prototype.Type = function (p) {
        return p.getPromoOffer();
    };
    MailMessageToOffersConverter.prototype.generatedMailsToOffers = function (items, closedMailMessagesBitSetIntArray, serverTime) {
        var result = {};
        if (items) {
            for (var id in items)
                if (items[id] != undefined) {
                    result[id] = {
                        expireTime: items[id].expireTime,
                        purchaseCount: 0,
                        seed: items[id].seed,
                        universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                    };
                }
        }
        if (closedMailMessagesBitSetIntArray) {
            var expireTime = new Date("2020-01-01").getTime();
            closedMailMessagesBitSetIntArray = BitMaskUtils.getIdsFromBitSetIntArray(closedMailMessagesBitSetIntArray);
            for (var _i = 0, closedMailMessagesBitSetIntArray_1 = closedMailMessagesBitSetIntArray; _i < closedMailMessagesBitSetIntArray_1.length; _i++) {
                var id = closedMailMessagesBitSetIntArray_1[_i];
                result[id] = {
                    expireTime: expireTime,
                    purchaseCount: 1,
                    seed: 1,
                    universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                };
            }
        }
        return result;
    };
    return MailMessageToOffersConverter;
}());
