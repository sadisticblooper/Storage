var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var MailMessage = (function () {
    function MailMessage(settings) {
        this.settings = settings;
    }
    Object.defineProperty(MailMessage.prototype, "ID", {
        get: function () { return this.settings.ID; },
        enumerable: false,
        configurable: true
    });
    ;
    MailMessage.prototype.getPromoOffer = function () {
        if (this.promoOffer == undefined) {
            this.createPromoOffer();
        }
        return this.promoOffer;
    };
    MailMessage.prototype.getRewardSettings = function () {
        return this.settings.reward || null;
    };
    MailMessage.prototype.getContent = function (countryCode) {
        return {
            localized: this.settings.localized,
            body: this.settings.body,
            header: this.settings.header,
            subHeader: this.settings.subHeader || "",
            image: this.settings.image,
            link: this.chooseLink(countryCode),
            linkButtonAlias: this.settings.linkButtonAlias,
            colorState: this.settings.colorState || "Default",
            linkButtonColor: this.settings.linkButtonColor || "White",
            previewIcon: this.settings.previewIcon,
            previewBackgroundState: this.settings.previewBackgroundState,
        };
    };
    MailMessage.prototype.check = function () {
        var linkMap = this.settings.linkMap;
        if (linkMap != undefined && this.settings.reward != undefined) {
            throw new Error("MailMessage ".concat(this.ID, " error: cant create message with LINK and REWARD"));
        }
        if (Boolean(linkMap) != Boolean(this.settings.linkButtonAlias)) {
            throw new Error("MailMessage ".concat(this.ID, " error: incorrect link and linkButtonAlias"));
        }
        if (linkMap != undefined) {
            for (var cc in linkMap) {
                if (cc == "default") {
                    continue;
                }
                if (allRegions.indexOf(cc) == -1) {
                    throw new Error("MailMessage ".concat(this.ID, " error: wrong country code ").concat(cc));
                }
            }
        }
    };
    MailMessage.prototype.createPromoOffer = function () {
        var promoSettings = this.settings.promoSettings;
        var activeTime = promoSettings.activeTime;
        if (activeTime.endGenerationBound == undefined && activeTime.duration == undefined) {
            activeTime = __assign(__assign({}, activeTime), { duration: new Time({ Days: MailConstants.storageDays }).value });
        }
        this.promoOffer = new PromoOffer(__assign(__assign({}, promoSettings), { activeTime: activeTime, ID: this.ID, offerNameAlias: null, lootSettings: null, offerType: PROMO_OFFER_TYPE.DYNAMIC, visualPresetId: null, customCondition: promoSettings.customCondition, productGroup: promoSettings.productGroup, triggers: promoSettings.triggers }));
    };
    MailMessage.prototype.chooseLink = function (countryCode) {
        var linkMap = this.settings.linkMap;
        return linkMap && (linkMap[countryCode] ? linkMap[countryCode] : linkMap["default"]);
    };
    return MailMessage;
}());
