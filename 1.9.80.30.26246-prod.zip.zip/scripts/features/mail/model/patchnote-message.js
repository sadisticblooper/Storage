var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PatchnoteMessage = (function (_super) {
    __extends(PatchnoteMessage, _super);
    function PatchnoteMessage(_a) {
        var ID = _a.ID, header = _a.header, body = _a.body, colorState = _a.colorState, linkButtonAlias = _a.linkButtonAlias, linkMap = _a.linkMap, sendStartDate = _a.sendStartDate, deleteMessageDate = _a.deleteMessageDate;
        var sendStartTimestampMs = Time.convertEuropeanDateToTimestampMs(sendStartDate);
        var deleteTimestampMs = Time.convertEuropeanDateToTimestampMs(deleteMessageDate);
        return _super.call(this, {
            ID: ID,
            header: header,
            body: body,
            colorState: colorState,
            linkButtonAlias: linkButtonAlias,
            linkMap: linkMap,
            localized: true,
            promoSettings: {
                activeTime: {
                    startGenerationBound: sendStartTimestampMs,
                    endGenerationBound: deleteTimestampMs,
                },
                conditions: {
                    createdPlayerTime: { less_or_equal: sendStartTimestampMs },
                },
                autoRepeatAfter: true,
            },
        }) || this;
    }
    return PatchnoteMessage;
}(MailMessage));
