var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var MailMessagesUtils = (function () {
    function MailMessagesUtils() {
    }
    MailMessagesUtils.getMailMessages = function (settings) {
        var converter = new MailMessageToOffersConverter();
        var itemsGetter = new GettingItemsLikeOffers(mailMessagesMap, converter);
        return itemsGetter.getPromos(settings);
    };
    MailMessagesUtils.getMailMessageCombinedRewards = function (settings) {
        var chestQueuePositions = settings.chestQueuePositions, chestSeed = settings.chestSeed, getFullResult = settings.getFullResult, messageId = settings.messageId, seed = settings.seed, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var message = mailMessagesMap.get(messageId);
        if (!message) {
            return null;
        }
        var reward = MailMessagesUtils.getMailMessageReward({
            message: message,
            playerProgress: playerProgress,
            seed: seed,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
        });
        if (!reward) {
            return null;
        }
        return MailMessagesUtils.getCommonCombinedReward({
            playerProgress: playerProgress,
            reward: reward,
            chestQueuePositions: chestQueuePositions,
            chestSeed: chestSeed,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            getFullResult: getFullResult
        });
    };
    MailMessagesUtils.getAdminMailMessageCombinedRewards = function (settings) {
        var chestQueuePositions = settings.chestQueuePositions, chestSeed = settings.chestSeed, getFullResult = settings.getFullResult, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var loot = LootUtils.getLootFromRaw(settings.loot || new Loot());
        var chestIds = settings.chestIds || [];
        if (loot.isEmpty() && chestIds.length == 0) {
            return null;
        }
        var reward = {
            Loot: loot,
            Chests: chestIds,
            NewSeed: 0,
        };
        return MailMessagesUtils.getCommonCombinedReward({
            playerProgress: playerProgress,
            reward: reward,
            chestQueuePositions: chestQueuePositions,
            chestSeed: chestSeed,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            getFullResult: getFullResult
        });
    };
    MailMessagesUtils.getMailMessage = function (settings) {
        var messageId = settings.messageId, seed = settings.seed, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, countryCode = settings.countryCode;
        var message = mailMessagesMap.get(messageId);
        if (!message) {
            return null;
        }
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var reward = MailMessagesUtils.getMailMessageReward({
            message: message,
            playerProgress: playerProgress,
            seed: seed,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
        });
        var messageReward = null;
        if (reward) {
            if (!reward.Loot.isEmpty()) {
                messageReward = { loot: reward.Loot };
            }
            if (reward.Chests.length > 0) {
                messageReward = messageReward ? __assign(__assign({}, messageReward), { chests: reward.Chests }) : { chests: reward.Chests };
            }
        }
        return __assign(__assign({}, message.getContent(countryCode)), { reward: messageReward });
    };
    MailMessagesUtils.getMailMessageReward = function (settings) {
        var message = settings.message, playerProgress = settings.playerProgress, seed = settings.seed, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var rewardContent = message.getRewardSettings();
        if (!rewardContent) {
            return null;
        }
        var ri = new PcgRandom(seed);
        var lootGenerator = LootGeneratorBuilder.getMailMessageLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(startTimeOfCurrentDayMS);
        return lootGenerator.getRewardFromRewardContent(rewardContent, ri);
    };
    MailMessagesUtils.getCommonCombinedReward = function (settings) {
        var reward = settings.reward, playerProgress = settings.playerProgress, getFullResult = settings.getFullResult, chestSeed = settings.chestSeed, chestQueuePositions = settings.chestQueuePositions, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var totalResultLoot = new Loot();
        var fullResult = getFullResult ? {} : null;
        var combinedReward = LootUtils.getGeneratedLootFromRewardResult({
            playerProgress: playerProgress,
            reward: reward,
            chestSeed: chestSeed,
            chestQueuePositions: chestQueuePositions,
            enableCombiningWithPlayer: true,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
        });
        chestSeed = combinedReward.chestSeed;
        chestQueuePositions = combinedReward.chestQueuePositions;
        if (!combinedReward.loot.isEmpty()) {
            totalResultLoot.combineLoot(combinedReward.loot);
            if (getFullResult) {
                fullResult.Loot = new Loot();
                fullResult.Loot.combineLoot(combinedReward.loot);
            }
        }
        if (combinedReward.chests.length > 0) {
            for (var _i = 0, _a = combinedReward.chests; _i < _a.length; _i++) {
                var chest = _a[_i];
                totalResultLoot.combineLoot(chest.loot);
                if (getFullResult) {
                    if (!fullResult.Chests) {
                        fullResult.Chests = [];
                    }
                    fullResult.Chests.push({ ID: chest.id, Loot: chest.loot });
                }
            }
        }
        return {
            totalResultLoot: totalResultLoot,
            chestQueuePositions: chestQueuePositions,
            chestSeed: chestSeed,
            fullResult: fullResult,
        };
    };
    return MailMessagesUtils;
}());
