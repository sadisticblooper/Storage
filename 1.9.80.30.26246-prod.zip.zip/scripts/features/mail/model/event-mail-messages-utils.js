var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var EventMailMessagesUtils = (function () {
    function EventMailMessagesUtils() {
    }
    EventMailMessagesUtils.createEventMessagesMap = function (settings) {
        var result = {};
        var eventId = settings.eventId, messages = settings.messages;
        var startTime = new Date("2010-01-01").getTime();
        var endTime = new Date("2010-01-15").getTime();
        if (eventId) {
            var event_1 = seasonalEventsMap.checkedGet(eventId);
            (startTime = event_1.startTime, endTime = event_1.endTime);
        }
        for (var _i = 0, messages_1 = messages; _i < messages_1.length; _i++) {
            var createMessageSettings = messages_1[_i];
            var daysSettings = createMessageSettings.daysSettings, messageSettings = createMessageSettings.messageSettings;
            var activeTime = EventMailMessagesUtils.createActiveTime(startTime, endTime, daysSettings);
            var promoMailSettings = EventMailMessagesUtils.createPromoSettings(activeTime, messageSettings);
            var mailMessageSettings = __assign(__assign({}, messageSettings), { promoSettings: promoMailSettings });
            result["auto_message_event_".concat(mailMessageSettings.ID)] = new MailMessage(mailMessageSettings);
        }
        return result;
    };
    EventMailMessagesUtils.createActiveTime = function (startTime, endTime, daysSettings) {
        var startGenerationBound = startTime;
        var endGenerationBound = endTime;
        var firstTime = daysSettings.firstTime, sinceDateTime = daysSettings.sinceDateTime, lastTime = daysSettings.lastTime;
        if (lastTime || sinceDateTime) {
            if (lastTime && sinceDateTime) {
                startGenerationBound = Math.min(startTime + sinceDateTime, endTime - lastTime);
            }
            else if (lastTime) {
                startGenerationBound = endTime - lastTime;
            }
            else {
                startGenerationBound = startTime + sinceDateTime;
            }
        }
        if (firstTime) {
            endGenerationBound = startTime + firstTime;
        }
        startGenerationBound = CommonUtils.clamp(startGenerationBound, startTime, endTime);
        endGenerationBound = CommonUtils.clamp(endGenerationBound, startTime, endTime);
        return {
            startGenerationBound: Math.min(startGenerationBound, endGenerationBound),
            endGenerationBound: Math.max(startGenerationBound, endGenerationBound),
        };
    };
    EventMailMessagesUtils.createPromoSettings = function (activeTime, messageSettings) {
        return __assign(__assign({}, messageSettings.promoSettings), { activeTime: activeTime, onceRepeatAfter: activeTime.startGenerationBound });
    };
    return EventMailMessagesUtils;
}());
