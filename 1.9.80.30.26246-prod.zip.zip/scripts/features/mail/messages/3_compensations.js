var _a, _b, _c, _d, _e, _f;
extend(mailMessages, {
    compensation_1: new MailMessage({
        ID: 128,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-03").getTime(),
                endGenerationBound: new Date("2025-11-09").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-11-03").getTime() },
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [
                chests.Halloween_event_chest.ID, chests.Halloween_event_chest.ID, chests.Halloween_event_chest.ID,
                chests.Emoji_chest.ID
            ]
        },
        image: "Sprites/PreviewImages/Mail/mail_art_anniversary",
        localized: true,
        header: "mail_title_news_5th_anniversary",
        subHeader: "mail_subtitle_news_5th_anniversary",
        body: "mail_body_news_5th_anniversary",
        colorState: "Green"
    }),
    compensation_2: new MailMessage({
        ID: 129,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-19").getTime(),
                endGenerationBound: new Date("2025-12-24").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-19").getTime() },
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Weapon_chest.ID],
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 200, _a) })
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_3: new MailMessage({
        ID: 130,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-06-02").getTime(),
                endGenerationBound: new Date("2025-06-10").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-29").getTime() },
                worlds: [SERVER_NAME_ENVIRONMENT.PROD_AS, SERVER_NAME_ENVIRONMENT.PROD_EU, SERVER_NAME_ENVIRONMENT.PROD_US],
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Small_Shard_Chest.ID]
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_4: new MailMessage({
        ID: 131,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-18").getTime(),
                endGenerationBound: new Date("2025-07-26").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-07-18").getTime() },
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Medium_Shard_Chest.ID]
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_5: new MailMessage({
        ID: 132,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-31").getTime(),
                endGenerationBound: new Date("2025-08-07").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_28_07"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Large_Shard_Chest_New_Hero.ID]
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_6: new MailMessage({
        ID: 133,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-08-06").getTime(),
                endGenerationBound: new Date("2025-08-21").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["survey_24_07_2025"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Skin_chest.ID]
        },
        localized: true,
        header: "mail_title_gift_for_you",
        body: "mail_body_survey_24_07_2025",
        colorState: "Green"
    }),
    compensation_7: new MailMessage({
        ID: 136,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-30").getTime(),
                endGenerationBound: new Date("2025-11-07").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-30").getTime() },
            },
            customCondition: function (s) {
                var prevMessage = s.generatedOffers[92];
                return prevMessage && prevMessage.expireTime > new Date("2025-10-29").getTime();
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Large_Shard_Chest_New_Hero.ID]
        },
        localized: true,
        header: "mail_title_gift_for_you",
        subHeader: "mail_subtitle_news_steam_wishlist_challenge",
        body: "mail_body_news_steam_wishlist_challenge_100k",
        colorState: "Green"
    }),
    compensation_8: new MailMessage({
        ID: 137,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-02").getTime(),
                endGenerationBound: new Date("2026-03-01").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_02_02"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.CUSTOMIZATION_TOKEN] = 2000, _b) })
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_9: new MailMessage({
        ID: 138,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-02").getTime(),
                endGenerationBound: new Date("2026-03-01").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_02_02_error"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.CUSTOMIZATION_TOKEN] = 1000, _c) })
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_10_1: new MailMessage({
        ID: 139,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-19").getTime(),
                endGenerationBound: new Date("2026-05-27").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_19_05_26_1"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.CHIP_1] = 100, _d[CURRENCY.BONUS] = 500, _d) })
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_10_2: new MailMessage({
        ID: 140,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-19").getTime(),
                endGenerationBound: new Date("2026-05-27").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_19_05_26_2"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.CHIP_1] = 500, _e[CURRENCY.BONUS] = 1000, _e) }),
            chests: [chests.Weapon_chest.ID],
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
    compensation_10_3: new MailMessage({
        ID: 141,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-19").getTime(),
                endGenerationBound: new Date("2026-05-27").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["compensation_19_05_26_3"]
            },
            autoRepeatAfter: true,
        },
        reward: {
            loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.CHIP_1] = 1500, _f[CURRENCY.BONUS] = 1500, _f) }),
            chests: [chests.Skin_chest.ID],
        },
        localized: true,
        header: "mail_title_compensation_universal",
        body: "mail_body_compensation_universal",
        colorState: "Green"
    }),
}, true);
