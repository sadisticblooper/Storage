var _a, _b, _c;
extend(mailMessages, {
    download_buyndles: new MailMessage({
        ID: 134,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customCondition: function (p) {
                var tutorialPassed = Boolean(p.playerProgress.tutorialPassed);
                var fightsCounter = BundlesUtils.getFightCounterAfterBundles(p.fightCounters);
                return tutorialPassed && fightsCounter == 0;
            },
            triggers: [PROMO_TRIGGER_TYPE.FIRST_LOBBY_ENTRY_COMPLETE]
        },
        reward: {
            loot: new Loot({
                Currencies: (_a = {}, _a[CURRENCY.COIN] = 500, _a),
                Emoji: [emoji.Universal_Heralds.ID, emoji.Universal_Dynasty.ID, emoji.Universal_Legion.ID,],
                Shards: (_b = {}, _b[heroes.Monk.ID] = 1, _b[heroes.Kibo.ID] = 1, _b[heroes.Itu.ID] = 1, _b)
            }),
            chests: [chests.Available_Heroes_Animation_chest.ID],
        },
        localized: true,
        header: "reward_for_bundles",
        body: "reward_for_bundles_body",
        colorState: "Green",
    }),
    email_collecting: new MailMessage({
        ID: 135,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.EMAIL_LINK]
        },
        reward: {
            chests: [chests.Large_Shard_Chest_New_Hero.ID]
        },
        localized: true,
        header: "letter_email_reward_title",
        body: "letter_email_reward_info",
        colorState: "Green",
    }),
    ad_tokens_system: new MailMessage({
        ID: 160,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.INCREASE_CURRENCY_FROM_ZERO],
            customCondition: function (settings) {
                var id = settings.currencyId || 0;
                return id == CURRENCY.AD_TOKEN;
            },
        },
        image: "Sprites/PreviewImages/Mail/mail_art_express_token",
        localized: true,
        header: "ad_tokens_letter_header",
        body: "ad_tokens_letter",
        colorState: "Default",
    }),
    vietnam_notification: new MailMessage({
        ID: 161,
        promoSettings: {
            activeTime: {},
            conditions: {
                countries: ["VN"]
            },
            triggers: [PROMO_TRIGGER_TYPE.LOGIN],
            customCondition: function (settings) {
                var allLinkedAuthTypes = settings.allLinkedAuthTypes || [];
                return allLinkedAuthTypes.indexOf(AuthType.NEKKI) > -1;
            }
        },
        reward: { chests: [chests.Large_Shard_Chest.ID] },
        localized: true,
        header: "mail_title_nekki_id_reward",
        body: "mail_body_nekki_id_reward",
        colorState: "Green",
    }),
    steam_release_permanent: new MailMessage({
        ID: 162,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customCondition: function (settings) {
                var isPcBuild = SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
                var previousMessage = settings.generatedOffers[10];
                return settings.playerProgress.accountLevel >= 2 && previousMessage == undefined && !isPcBuild;
            },
            onceRepeatAfter: new Date("2025-11-12").getTime()
        },
        image: "Sprites/PreviewImages/Mail/mail_art_steam",
        localized: true,
        header: "steam_release_letter_header",
        body: "steam_release_letter_new",
        reward: {
            loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.AD_TOKEN] = 3, _c) })
        },
        colorState: "Gold"
    }),
    vietnam_nekki_id_linking: new MailMessage({
        ID: 163,
        promoSettings: {
            activeTime: {},
            conditions: {
                countries: ["VN"]
            },
            triggers: [PROMO_TRIGGER_TYPE.LOGIN],
            customCondition: function (settings) {
                var allLinkedAuthTypes = settings.allLinkedAuthTypes || [];
                var IsTutorialPassed = Boolean(settings.playerProgress.tutorialPassed);
                return allLinkedAuthTypes.indexOf(AuthType.NEKKI) == -1 && IsTutorialPassed;
            },
        },
        linkMap: { default: "sfa://settings?section=general" },
        linkButtonAlias: "button_connect",
        localized: true,
        header: "mail_title_vietnam_nekki_id",
        body: "mail_body_vietnam_nekki_id",
        colorState: "Red",
    }),
    best_moments_0308: new MailMessage({
        ID: 164,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-08").getTime(),
                endGenerationBound: new Date("2026-03-13").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-08").getTime() },
            },
            autoRepeatAfter: true,
            triggers: [PROMO_TRIGGER_TYPE.LOGIN]
        },
        linkMap: { default: "https://docs.google.com/forms/d/e/1FAIpQLScyhmXHrzza3zybxs4Fq3t_FBrgltnUoW8B_7X5feAtCQTI2Q/viewform?usp=dialog" },
        linkButtonAlias: "mail_button_send",
        localized: true,
        header: "mail_title_best moments_replays",
        body: "mail_body_best moments_replays",
        colorState: "Gold",
    }),
    community_challenge_2: new MailMessage({
        ID: 165,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-20").getTime(),
                endGenerationBound: new Date("2026-04-20").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-20").getTime() },
            },
            autoRepeatAfter: true,
            triggers: [PROMO_TRIGGER_TYPE.LOGIN]
        },
        linkMap: { default: "https://shadowfight.com/news-community-challenge-2" },
        linkButtonAlias: "mail_button_event_invitation",
        localized: true,
        header: "mail_title_news_community_challenge",
        body: "mail_body_news_community_challenge_2",
        colorState: "Gold",
    }),
}, true);
