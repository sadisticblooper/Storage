var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
extend(mailMessages, __assign({}, (function () {
    var _a, _b, _c;
    var ROADMAP = [
        {
            fights: 501,
            reward: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 5, _a) }) },
            preview: "Sprites/PreviewImages/Quests/April/icon_challenge_April_base"
        },
        {
            fights: 1001,
            reward: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 10, _b) }) },
            preview: "Sprites/PreviewImages/Quests/April/icon_challenge_April_base"
        },
        {
            fights: 2001,
            reward: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 20, _c) }) },
            preview: "Sprites/PreviewImages/Quests/ShadowMind/icon_challenge_ShadowMind_base",
            image: "Sprites/PreviewImages/Mail/mail_message_image_template",
        },
    ];
    var INITIAL_ID = 448;
    var MAX_MESSAGES_IN_POOL = 32;
    if (ROADMAP.length > MAX_MESSAGES_IN_POOL) {
        throw new Error("creating messages for fights:"
            + " roadmap size is more then ".concat(MAX_MESSAGES_IN_POOL));
    }
    var result = {};
    var cumulativeRewards = ArrayUtils.createFilled(function () { return {}; }, ROADMAP.length);
    var initialIds = ArrayUtils
        .createFilled(function () { return 0; }, MAX_MESSAGES_IN_POOL)
        .map(function (v, i) { return INITIAL_ID + i; });
    var commonIds = ArrayUtils
        .createFilled(function () { return 0; }, MAX_MESSAGES_IN_POOL)
        .map(function (v, i) { return INITIAL_ID + MAX_MESSAGES_IN_POOL + i; });
    var _loop_1 = function (i) {
        var milestone = ROADMAP[i];
        var initialId = INITIAL_ID + i;
        var commonId = INITIAL_ID + MAX_MESSAGES_IN_POOL + i;
        for (var rewardIndex = i; rewardIndex < cumulativeRewards.length; rewardIndex++) {
            LootUtils.mergeRewardContent(cumulativeRewards[rewardIndex], milestone.reward);
        }
        result["auto_message_initial_fights_".concat(initialId)] = new MailMessage({
            ID: initialId,
            promoSettings: {
                activeTime: {},
                conditions: {},
                triggers: [PROMO_TRIGGER_TYPE.FIGHT_END],
                customCondition: function (settings) {
                    var _a = settings.fightsNumberFromSocial, fightsNumberFromSocial = _a === void 0 ? 0 : _a, generatedMessages = settings.generatedOffers;
                    var generatedIds = Object.keys(generatedMessages).map(Number);
                    if (ArrayUtils.getArraysIntersection(generatedIds, initialIds).length > 0
                        || ArrayUtils.getArraysIntersection(generatedIds, commonIds).length > 0) {
                        return false;
                    }
                    var goalIndex = -1;
                    for (var roadmapIndex = ROADMAP.length - 1; roadmapIndex >= 0; roadmapIndex--) {
                        var fights = ROADMAP[roadmapIndex].fights;
                        if (fightsNumberFromSocial >= fights) {
                            goalIndex = roadmapIndex;
                            break;
                        }
                    }
                    return goalIndex > -1 && initialId == INITIAL_ID + goalIndex;
                }
            },
            reward: cumulativeRewards[i],
            localized: true,
            header: MailConstants.fightMessagesAliases[milestone.fights].title,
            body: MailConstants.fightMessagesAliases[milestone.fights].body,
            image: milestone.image,
            previewIcon: milestone.preview,
            colorState: "Orange",
            previewBackgroundState: "HeroLetter",
        });
        result["auto_message_common_fights_".concat(commonId)] = new MailMessage({
            ID: commonId,
            promoSettings: {
                activeTime: {},
                conditions: {},
                triggers: [PROMO_TRIGGER_TYPE.FIGHT_END],
                customCondition: function (settings) {
                    var _a = settings.fightsNumberFromSocial, fightsNumberFromSocial = _a === void 0 ? 0 : _a, generatedMessages = settings.generatedOffers;
                    var generatedIds = Object.keys(generatedMessages).map(Number);
                    var generatedInitialIds = ArrayUtils.getArraysIntersection(generatedIds, initialIds);
                    if (generatedInitialIds.length == 0) {
                        return false;
                    }
                    var minimumIdToSendMessage = generatedInitialIds[0] + MAX_MESSAGES_IN_POOL;
                    return commonId > minimumIdToSendMessage && fightsNumberFromSocial >= milestone.fights;
                }
            },
            reward: milestone.reward,
            localized: true,
            header: MailConstants.fightMessagesAliases[milestone.fights].title,
            body: MailConstants.fightMessagesAliases[milestone.fights].body,
            image: milestone.image,
            previewIcon: milestone.preview,
            colorState: "Orange",
            previewBackgroundState: "HeroLetter",
        });
    };
    for (var i = 0; i < ROADMAP.length; i++) {
        _loop_1(i);
    }
    return result;
})()), true);
