var _a, _b;
extend(mailMessages, {
    account_level_up_7: new MailMessage({
        ID: 384,
        promoSettings: {
            activeTime: {},
            conditions: {
                accountLevel: { equal: 7 }
            },
            triggers: [PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        },
        localized: true,
        header: "mail_title_level_7_surprise",
        body: "mail_body_level_7_surprise",
        previewIcon: MailConstants.characterIcons[HeroNames.Ling.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 5, _a) })
        },
    }),
    account_level_up_max: new MailMessage({
        ID: 385,
        promoSettings: {
            activeTime: {},
            conditions: {
                accountLevel: { equal: MAX_ACCOUNT_LEVEL }
            },
        },
        localized: true,
        header: "mail_title_level_13_surprise",
        body: "mail_body_level_13_surprise",
        previewIcon: MailConstants.characterIcons[HeroNames.Ling.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 10, _b) })
        },
    }),
}, true);
