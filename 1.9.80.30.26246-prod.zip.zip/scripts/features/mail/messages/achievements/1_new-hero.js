var _a, _b, _c, _d;
extend(mailMessages, {
    Raikichi: new MailMessage({
        ID: 256,
        promoSettings: {
            activeTime: {},
            conditions: {},
            onCombinedHeroes: [heroes.Raikichi.ID],
        },
        localized: true,
        header: "mail_title_new_raikichi_surprise",
        body: "mail_body_new_raikichi_surprise",
        previewIcon: MailConstants.characterIcons[heroes.Raikichi.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 10, _a) })
        },
    }),
    Nonna: new MailMessage({
        ID: 257,
        promoSettings: {
            activeTime: {},
            conditions: {},
            onCombinedHeroes: [heroes.Nonna.ID],
        },
        localized: true,
        header: "mail_title_new_nonna_surprise",
        body: "mail_body_new_nonna_surprise",
        previewIcon: MailConstants.characterIcons[heroes.Nonna.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 10, _b) })
        },
    }),
    ShogunMinion: new MailMessage({
        ID: 258,
        promoSettings: {
            activeTime: {},
            conditions: {},
            onCombinedHeroes: [heroes.Shogun.ID],
        },
        localized: true,
        header: 'mail_title_new_minion_surprise',
        body: 'mail_body_new_minion_surprise',
        previewIcon: MailConstants.characterIcons.shogunMinion,
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 1, _c) })
        },
    }),
    Shogun: new MailMessage({
        ID: 259,
        promoSettings: {
            activeTime: {},
            conditions: {},
            onCombinedHeroes: [heroes.Shogun.ID],
        },
        localized: true,
        header: 'mail_title_new_shogun_surprise',
        body: 'mail_body_new_shogun_surprise',
        previewIcon: MailConstants.characterIcons[heroes.Shogun.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.BONUS] = 10, _d) })
        },
    }),
}, true);
