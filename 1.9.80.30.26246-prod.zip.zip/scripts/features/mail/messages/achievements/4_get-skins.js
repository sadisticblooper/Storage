var _a, _b, _c, _d, _e, _f, _g, _h;
extend(mailMessages, {
    lynx_legendary_surprise: new MailMessage({
        ID: 394,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customizeExist: (_a = {},
                _a[CUSTOMIZATION.SKIN] = [skins.Lynx_L_Hood.ID],
                _a),
        },
        localized: true,
        header: "mail_title_lynx_legendary_surprise",
        body: "mail_body_lynx_legendary_surprise",
        image: "Sprites/PreviewImages/Mail/mail_message_image_Lynx_L_Hood",
        previewIcon: MailConstants.characterIcons[HeroNames.Lynx.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 20, _b) })
        },
    }),
    itu_legendary_surprise: new MailMessage({
        ID: 395,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customizeExist: (_c = {},
                _c[CUSTOMIZATION.SKIN] = [skins.Itu_L_Cosmic.ID],
                _c),
        },
        localized: true,
        header: "mail_title_itu_legendary_surprise",
        body: "mail_body_itu_legendary_surprise",
        image: "Sprites/PreviewImages/Mail/mail_message_image_Itu_L_Cosmic",
        previewIcon: MailConstants.characterIcons[HeroNames.Itu.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.BONUS] = 20, _d) })
        },
    }),
    legion_king_legendary_surprise: new MailMessage({
        ID: 396,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customizeExist: (_e = {},
                _e[CUSTOMIZATION.SKIN] = [skins.Legion_King_L_Castle.ID],
                _e),
        },
        localized: true,
        header: "mail_title_kotl_legendary_surprise",
        body: "mail_body_kotl_legendary_surprise",
        image: "Sprites/PreviewImages/Mail/mail_art_Legion_King_L_Castle",
        previewIcon: MailConstants.characterIcons[HeroNames.Legion_King.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 20, _f) })
        },
    }),
    kibo_legendary_surprise: new MailMessage({
        ID: 397,
        promoSettings: {
            activeTime: {},
            conditions: {},
            customizeExist: (_g = {},
                _g[CUSTOMIZATION.SKIN] = [skins.Kibo_L_Eclipse.ID],
                _g),
        },
        localized: true,
        header: "mail_title_kibo_legendary_surprise",
        body: "mail_body_kibo_legendary_surprise",
        image: "Sprites/PreviewImages/Mail/mail_art_Kibo_L_Eclipse",
        previewIcon: MailConstants.characterIcons[HeroNames.Kibo.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 20, _h) })
        },
    }),
}, true);
