var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
extend(mailMessages, __assign({}, (function () {
    var INIT_ID_IN_POOL = 320;
    var MAX_MESSAGES_IN_POOL = 64;
    var result = {};
    var heroIds = heroesMap.getKeys();
    if (heroIds.length > MAX_MESSAGES_IN_POOL) {
        throw new Error("creating messages for full progress on heroes:"
            + " number of heroes is more then ".concat(MAX_MESSAGES_IN_POOL));
    }
    var _loop_1 = function (i) {
        var _a;
        var heroId = heroIds[i];
        var hero = heroesMap.get(heroId);
        var messageId = INIT_ID_IN_POOL + i;
        result["auto_message_hero_full_progress_".concat(messageId)] = new MailMessage({
            ID: messageId,
            promoSettings: {
                activeTime: {},
                conditions: {},
                customCondition: function (settings) {
                    var heroesInfo = settings.playerProgress.heroes;
                    return heroesInfo[heroId] != undefined
                        && heroesInfo[heroId].Level == HeroConstants.maxHeroLevel
                        && heroesInfo[heroId].TalentLevel == hero.getMaxTalentLevel();
                },
                triggers: [PROMO_TRIGGER_TYPE.HERO_LEVEL_UP, PROMO_TRIGGER_TYPE.HERO_TALENT_LEVEL_UP],
            },
            localized: true,
            header: MailConstants.heroMessageSettings[heroId].maxUpgradeAliases.title,
            body: MailConstants.heroMessageSettings[heroId].maxUpgradeAliases.body,
            previewIcon: MailConstants.characterIcons[heroId],
            colorState: "Orange",
            previewBackgroundState: "HeroLetter",
            reward: {
                loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 15, _a) })
            },
        });
    };
    for (var i = 0; i < heroIds.length; i++) {
        _loop_1(i);
    }
    return result;
})()), true);
