var _a;
extend(mailMessages, {
    anniversary_year: new MailMessage({
        ID: 419,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.LOGIN],
            customCondition: function (settings) {
                var PERIOD = new Time({ Days: 365 }).value;
                var PERIOD_BUFFER = new Time({ Days: 7 }).value;
                var createdPlayerDate = new Date(settings.regionalSettings.createdPlayerTime);
                createdPlayerDate.setUTCHours(0);
                var createdPlayerDateTime = createdPlayerDate.getTime();
                var serverCurrentTime = settings.serverCurrentTime;
                var start = createdPlayerDateTime + PERIOD;
                var end = start + PERIOD_BUFFER;
                return serverCurrentTime > start && serverCurrentTime < end;
            },
        },
        localized: true,
        header: "mail_title_account_anniversary_surprise",
        body: "mail_body_account_anniversary_surprise",
        previewIcon: "Sprites/PreviewImages/Quests/April/icon_challenge_April_base",
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a) })
        },
    }),
}, true);
