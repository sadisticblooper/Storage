var _a;
extend(mailMessages, {
    first_10_fights: new MailMessage({
        ID: 414,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.FIGHT_END],
            customCondition: function (settings) {
                var _a = settings.fightsNumberFromSocial, fightsNumberFromSocial = _a === void 0 ? 0 : _a;
                return fightsNumberFromSocial >= 10 && fightsNumberFromSocial <= 14;
            },
        },
        localized: true,
        header: "mail_title_10_fights_surprise",
        body: "mail_body_10_fights_surprise",
        previewIcon: "Sprites/PreviewImages/Quests/ShadowMind/icon_challenge_ShadowMind_base",
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 5, _a) })
        },
    }),
}, true);
