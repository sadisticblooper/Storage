var _a, _b;
extend(mailMessages, {
    full_pve_book_1: new MailMessage({
        ID: 424,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
            customCondition: function (settings) {
                var HEROES_NUMBER = heroesMap.getKeys().length;
                var _a = settings.roguelikeChaptersProgress, roguelikeChaptersProgress = _a === void 0 ? {} : _a;
                var book = bookMap.checkedGet(1);
                var chaptersToCheck = book.chapters
                    .map(function (ch) { return chaptersMap.checkedGet(ch.id); })
                    .filter(function (ch) { return !ch.isSurvival; });
                for (var _i = 0, chaptersToCheck_1 = chaptersToCheck; _i < chaptersToCheck_1.length; _i++) {
                    var chapter = chaptersToCheck_1[_i];
                    if (roguelikeChaptersProgress[chapter.ID] != HEROES_NUMBER) {
                        return false;
                    }
                }
                return true;
            },
        },
        localized: true,
        header: "mail_title_pve_1_3_surprise",
        body: "mail_body_pve_1_3_surprise",
        previewIcon: MailConstants.characterIcons[HeroNames.Ironclad.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 10, _a) })
        },
    }),
    full_pve_book_3: new MailMessage({
        ID: 425,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
            customCondition: function (settings) {
                var HEROES_NUMBER = heroesMap.getKeys().length;
                var _a = settings.roguelikeChaptersProgress, roguelikeChaptersProgress = _a === void 0 ? {} : _a;
                var book = bookMap.checkedGet(3);
                var chaptersToCheck = book.chapters
                    .map(function (ch) { return chaptersMap.checkedGet(ch.id); })
                    .filter(function (ch) { return !ch.isSurvival; });
                for (var _i = 0, chaptersToCheck_2 = chaptersToCheck; _i < chaptersToCheck_2.length; _i++) {
                    var chapter = chaptersToCheck_2[_i];
                    if (roguelikeChaptersProgress[chapter.ID] != HEROES_NUMBER) {
                        return false;
                    }
                }
                return true;
            },
        },
        localized: true,
        header: "mail_title_pve_6_8_surprise",
        body: "mail_body_pve_6_8_surprise",
        previewIcon: MailConstants.characterIcons[HeroNames.Ironclad.ID],
        colorState: "Orange",
        previewBackgroundState: "HeroLetter",
        reward: {
            loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.BONUS] = 10, _b) })
        },
    }),
}, true);
