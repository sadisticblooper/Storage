var mailMessagesMap = createIDMap(mailMessages);
