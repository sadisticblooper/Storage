var _a;
extend(mailMessages, {
    message_1: new MailMessage({
        ID: 1,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-05").getTime(),
                endGenerationBound: new Date("2025-12-16").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-05").getTime() },
            },
            autoRepeatAfter: true
        },
        localized: true,
        header: "mail_title_season_prolonged",
        body: "mail_body_season_prolonged",
        colorState: "Gold"
    }),
    message_2: new MailMessage({
        ID: 2,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-04").getTime(),
                endGenerationBound: new Date("2026-01-01").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-04").getTime() },
            },
            autoRepeatAfter: true
        },
        linkMap: { default: "https://shadowfight.com/state-of-the-game" },
        linkButtonAlias: "button_more",
        image: "Sprites/PreviewImages/Mail/mail_art_news_sf_month_blog",
        localized: true,
        header: "mail_title_news_sf_month_blog",
        body: "mail_body_news_sf_month_blog",
        colorState: "Gold"
    }),
    message_3: new MailMessage({
        ID: 3,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-08").getTime(),
                endGenerationBound: new Date("2025-12-20").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-08").getTime() },
            },
            autoRepeatAfter: true
        },
        linkMap: { default: "https://shadowfight.com/news-community-challenge" },
        linkButtonAlias: "mail_button_event_invitation",
        localized: true,
        header: "mail_title_news_community_challenge",
        body: "mail_body_news_community_challenge",
        colorState: "Gold"
    }),
    message_4: new MailMessage({
        ID: 4,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-30").getTime(),
                endGenerationBound: new Date("2026-01-13").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-30").getTime() },
            },
            autoRepeatAfter: true
        },
        localized: true,
        header: "mail_title_new_year_2026",
        subHeader: "mail_subtitle_new_year_2026",
        body: "mail_body_new_year_2026",
        colorState: "Gold"
    }),
    message_5: new MailMessage({
        ID: 5,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-16").getTime(),
                endGenerationBound: new Date("2025-10-24").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-16").getTime() },
            },
            customCondition: function (s) {
                var prevMessage = s.generatedOffers[90];
                return prevMessage != undefined &&
                    isNumber(prevMessage.expireTime) &&
                    prevMessage.expireTime > new Date("2025-10-09").getTime();
            },
            autoRepeatAfter: true
        },
        reward: { chests: [chests.Animation_chest.ID] },
        localized: true,
        header: "mail_title_gift_for_you",
        subHeader: "mail_subtitle_news_steam_wishlist_challenge",
        body: "mail_body_news_steam_wishlist_challenge_90k",
        colorState: "Green"
    }),
    message_6: new MailMessage({
        ID: 6,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-01").getTime(),
                endGenerationBound: new Date("2025-12-10").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-16").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_november_season_changes_letter_header",
        body: "mail_november_season_changes_letter",
        colorState: "Gold"
    }),
    message_7: new MailMessage({
        ID: 7,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-05-15").getTime(),
                endGenerationBound: new Date("2025-05-29").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-15").getTime() },
            },
            customCondition: function (s) {
                return s.generatedOffers[71] != undefined;
            },
            autoRepeatAfter: true,
        },
        image: "Sprites/PreviewImages/Mail/mail_art_Legion_King_L_Castle",
        linkMap: { default: "https://www.youtube.com/watch?v=HosgOc3IycA" },
        linkButtonAlias: "button_watch_trailer",
        localized: true,
        header: "mail_title_news_trailer_kotl_castle",
        body: "mail_body_news_trailer_kotl_castle",
        colorState: "Gold"
    }),
    message_8: new MailMessage({
        ID: 8,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-05-22").getTime(),
                endGenerationBound: new Date("2025-05-27").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-22").getTime() },
            },
            autoRepeatAfter: true,
        },
        image: "Sprites/PreviewImages/Mail/mail_art_community_skin_vote",
        linkMap: { default: "https://tinyurl.com/34b5yju8" },
        linkButtonAlias: "button_vote",
        localized: true,
        header: "mail_title_community_skin_2025_vote4",
        subHeader: "mail_subtitle_community_skin_2025_vote4",
        body: "mail_body_community_skin_2025_vote4",
        colorState: "Gold"
    }),
    message_9: new MailMessage({
        ID: 9,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-06-05").getTime(),
                endGenerationBound: new Date("2025-06-11").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-06-05").getTime() },
            },
            autoRepeatAfter: true
        },
        linkMap: { default: "https://bit.ly/3ZPbKdl" },
        linkButtonAlias: "button_vote",
        localized: true,
        header: "mail_title_community_skin_2025_vote5",
        subHeader: "mail_subtitle_community_skin_2025_vote5",
        body: "mail_body_community_skin_2025_vote5",
        image: "Sprites/PreviewImages/Mail/mail_art_community_skin_vote",
        colorState: "Gold"
    }),
    steam_release: new MailMessage({
        ID: 10,
        promoSettings: {
            activeTime: {
                endGenerationBound: new Date("2025-11-13").getTime()
            },
            conditions: {},
            customCondition: function (settings) {
                return settings.playerProgress.accountLevel >= 2;
            },
        },
        image: "Sprites/PreviewImages/Mail/mail_art_steam",
        localized: true,
        header: "steam_release_letter_header",
        body: "steam_release_letter",
        reward: {
            loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.AD_TOKEN] = 3, _a) })
        },
        colorState: "Gold"
    }),
    season_rework_migration_compensation_1: new MailMessage({
        ID: 11,
        promoSettings: {
            activeTime: {},
            conditions: {},
            triggers: [PROMO_TRIGGER_TYPE.MAIL_ON_MIGRATION],
            customCondition: function (settings) {
                var migrationCheck = MailConstants.seasonReworkMigrationCheck(settings);
                var tokens = settings.playerProgress.currencies[CURRENCY.CUSTOMIZATION_TOKEN] || 0;
                return migrationCheck && tokens >= 1 && tokens <= 2999;
            },
            onceRepeatAfter: MailConstants.seasonMigrationMessageStart,
        },
        localized: true,
        header: "mail_title_insignia_compensation",
        body: "mail_body_insignia_compensation",
        reward: {
            chests: [chests.Skin_chest.ID]
        },
        colorState: "Green"
    }),
    season_rework_migration_compensation_2: new MailMessage({
        ID: 12,
        promoSettings: {
            activeTime: {},
            conditions: {
                createdPlayerTime: { less: MailConstants.seasonMigrationMessageStart }
            },
            triggers: [PROMO_TRIGGER_TYPE.MAIL_ON_MIGRATION],
            customCondition: function (settings) {
                var migrationCheck = MailConstants.seasonReworkMigrationCheck(settings);
                var tokens = settings.playerProgress.currencies[CURRENCY.CUSTOMIZATION_TOKEN] || 0;
                return migrationCheck && tokens >= 3000 && tokens <= 9999;
            },
            onceRepeatAfter: MailConstants.seasonMigrationMessageStart,
        },
        localized: true,
        header: "mail_title_insignia_compensation",
        body: "mail_body_insignia_compensation",
        reward: {
            chests: [chests.Skin_chest.ID, chests.Legendary_chest.ID]
        },
        colorState: "Green"
    }),
    season_rework_migration_compensation_3: new MailMessage({
        ID: 13,
        promoSettings: {
            activeTime: {},
            conditions: {
                createdPlayerTime: { less: MailConstants.seasonMigrationMessageStart }
            },
            triggers: [PROMO_TRIGGER_TYPE.MAIL_ON_MIGRATION],
            customCondition: function (settings) {
                var migrationCheck = MailConstants.seasonReworkMigrationCheck(settings);
                var tokens = settings.playerProgress.currencies[CURRENCY.CUSTOMIZATION_TOKEN] || 0;
                return migrationCheck && tokens >= 10000 && tokens <= 49000;
            },
            onceRepeatAfter: MailConstants.seasonMigrationMessageStart,
        },
        localized: true,
        header: "mail_title_insignia_compensation",
        body: "mail_body_insignia_compensation",
        reward: {
            chests: [chests.Skin_chest.ID, chests.Skin_chest.ID, chests.Legendary_chest.ID]
        },
        colorState: "Green"
    }),
    season_rework_migration_compensation_4: new MailMessage({
        ID: 14,
        promoSettings: {
            activeTime: {},
            conditions: {
                createdPlayerTime: { less: MailConstants.seasonMigrationMessageStart }
            },
            triggers: [PROMO_TRIGGER_TYPE.MAIL_ON_MIGRATION],
            customCondition: function (settings) {
                var migrationCheck = MailConstants.seasonReworkMigrationCheck(settings);
                var tokens = settings.playerProgress.currencies[CURRENCY.CUSTOMIZATION_TOKEN] || 0;
                return migrationCheck && tokens >= 49001;
            },
            onceRepeatAfter: MailConstants.seasonMigrationMessageStart,
        },
        localized: true,
        header: "mail_title_insignia_compensation",
        body: "mail_body_insignia_compensation",
        reward: {
            chests: [
                chests.Skin_chest.ID, chests.Skin_chest.ID, chests.Skin_chest.ID,
                chests.Legendary_chest.ID, chests.Legendary_chest.ID
            ]
        },
        colorState: "Green"
    }),
    season_rework_notification: new MailMessage({
        ID: 15,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-16").getTime(),
                endGenerationBound: new Date("2026-01-26").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-13").getTime() },
            },
            autoRepeatAfter: true
        },
        localized: true,
        header: "mail_december_season_changes_letter_header",
        body: "mail_december_season_changes_letter",
        colorState: "Gold"
    }),
    vietnam_nekki_id_linking_reminder: new MailMessage({
        ID: 16,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-01-23").getTime(),
                endGenerationBound: new Date("2026-02-24").getTime()
            },
            conditions: {
                countries: ["VN"],
                createdPlayerTime: { less_or_equal: new Date("2026-01-23").getTime() },
            },
            triggers: [PROMO_TRIGGER_TYPE.LOGIN],
            customCondition: function (settings) {
                var allLinkedAuthTypes = settings.allLinkedAuthTypes || [];
                var IsTutorialPassed = Boolean(settings.playerProgress.tutorialPassed);
                return allLinkedAuthTypes.indexOf(AuthType.NEKKI) == -1 && IsTutorialPassed;
            },
            autoRepeatAfter: true
        },
        linkMap: { default: "sfa://settings?section=general" },
        linkButtonAlias: "button_to_settings",
        localized: true,
        header: "mail_title_vietnam_nekki_id",
        body: "mail_body_vietnam_nekki_id_reminder",
        colorState: "Gold"
    }),
    gift_for_survey_12_02: new MailMessage({
        ID: 17,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-25").getTime(),
                endGenerationBound: new Date("2026-03-15").getTime(),
            },
            conditions: {
                accountTagsOneOf: ["survey_12_02_2026"],
                createdPlayerTime: { less_or_equal: new Date("2026-02-25").getTime() },
            },
            autoRepeatAfter: true,
        },
        reward: {
            chests: [chests.Skin_chest.ID]
        },
        localized: true,
        header: "mail_title_gift_for_you",
        body: "mail_body_survey_12_02_2026",
        colorState: "Green"
    }),
    where_to_find_weapon_shards: new MailMessage({
        ID: 18,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-29").getTime(),
                endGenerationBound: new Date("2026-05-11").getTime()
            },
            conditions: {},
            autoRepeatAfter: true,
        },
        localized: true,
        header: "Legendary_weapon_shard_tooltip_alias",
        body: "information_get_leg_wpn_BP",
        colorState: "Gold"
    }),
    pc_controls_survey_2026: new MailMessage({
        ID: 19,
        header: "mail_title_pc_controls_survey_2026",
        subHeader: "mail_subtitle_pc_controls_survey_2026",
        body: "mail_body_pc_controls_survey_2026",
        colorState: "Default",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-10").getTime(),
                endGenerationBound: new Date("2026-05-11").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-05-10").getTime() },
            },
            autoRepeatAfter: true,
        },
        linkMap: { default: "https://shadowfight.com/pc-controls-survey-2026" },
        linkButtonAlias: "mail_button_survey",
        localized: true,
    }),
    pc_controls_survey_2026_fixed: new MailMessage({
        ID: 20,
        header: "mail_title_pc_controls_survey_2026",
        subHeader: "mail_subtitle_pc_controls_survey_2026",
        body: "mail_body_pc_controls_survey_2026",
        colorState: "Gold",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-16").getTime(),
                endGenerationBound: new Date("2026-05-30").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-05-10").getTime() },
            },
            autoRepeatAfter: true,
        },
        linkMap: { default: "https://shadowfight.com/controls-survey-2026" },
        linkButtonAlias: "mail_button_survey",
        localized: true,
    }),
}, true);
