extend(mailMessages, {
    patchnote_1: new MailMessage({
        ID: 64,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-06").getTime(),
                endGenerationBound: new Date("2025-12-06").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-11-06").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkButtonAlias: "button_more",
        linkMap: { default: "http://shadowfight.com/news-balance-patch-1-9-55-20" },
        header: "mail_title_patchnote_1_9_55_20",
        body: "mail_body_patchnote_1_9_55_20",
        colorState: "Default",
    }),
    patchnote_2: new MailMessage({
        ID: 65,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-13").getTime(),
                endGenerationBound: new Date("2025-12-13").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-11-13").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_30",
        body: "mail_body_patchnote_1_9_55_30",
        colorState: "Default",
    }),
    patchnote_3: new MailMessage({
        ID: 66,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-21").getTime(),
                endGenerationBound: new Date("2025-12-21").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-11-21").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_40",
        body: "mail_body_patchnote_1_9_55_40",
        colorState: "Default",
    }),
    patchnote_4: new MailMessage({
        ID: 67,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-11-27").getTime(),
                endGenerationBound: new Date("2025-12-27").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-11-27").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_50",
        body: "mail_body_patchnote_1_9_55_50",
        colorState: "Default",
    }),
    patchnote_5: new MailMessage({
        ID: 68,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-05").getTime(),
                endGenerationBound: new Date("2026-01-21").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-05").getTime() },
            },
            customCondition: function (s) {
                return SteamPlatformUtils.isPCBuild(s.regionalSettings.platform);
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_50_PC",
        body: "mail_body_patchnote_1_9_50_50_PC",
        colorState: "Default",
    }),
    patchnote_6: new MailMessage({
        ID: 69,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-11").getTime(),
                endGenerationBound: new Date("2026-01-11").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-11").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_70",
        body: "mail_body_patchnote_1_9_55_70",
        colorState: "Default",
    }),
    patchnote_7: new MailMessage({
        ID: 70,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-18").getTime(),
                endGenerationBound: new Date("2026-01-18").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-18").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_10",
        body: "mail_body_patchnote_1_9_60_10",
        colorState: "Default",
    }),
    patchnote_8: new MailMessage({
        ID: 71,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-12-25").getTime(),
                endGenerationBound: new Date("2026-01-25").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-12-25").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkButtonAlias: "button_more",
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-60-20" },
        header: "mail_title_patchnote_1_9_60_20",
        body: "mail_body_patchnote_1_9_60_20",
        colorState: "Default",
    }),
    patchnote_9: new MailMessage({
        ID: 72,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-05-16").getTime(),
                endGenerationBound: new Date("2025-07-16").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-16").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50",
        body: "mail_body_patchnote_1_9_50",
        colorState: "Gold",
    }),
    patchnote_10: new MailMessage({
        ID: 73,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-05-22").getTime(),
                endGenerationBound: new Date("2025-06-22").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-22").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_40_130",
        body: "mail_body_patchnote_1_9_40_130",
        colorState: "Default",
    }),
    patchnote_11: new MailMessage({
        ID: 74,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-05-29").getTime(),
                endGenerationBound: new Date("2025-06-29").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-05-29").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_10",
        body: "mail_body_patchnote_1_9_50_10",
        colorState: "Default",
    }),
    patchnote_12: new MailMessage({
        ID: 75,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-06-05").getTime(),
                endGenerationBound: new Date("2025-07-05").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-06-05").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_20",
        body: "mail_body_patchnote_1_9_50_20",
        colorState: "Default",
    }),
    patchnote_13: new MailMessage({
        ID: 76,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-06-11").getTime(),
                endGenerationBound: new Date("2025-07-11").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-06-11").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-50-30" },
        linkButtonAlias: "button_more",
        header: "mail_title_patchnote_1_9_50_30",
        body: "mail_body_patchnote_1_9_50_30",
        colorState: "Default",
    }),
    patchnote_14: new MailMessage({
        ID: 77,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-06-26").getTime(),
                endGenerationBound: new Date("2025-07-26").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-06-26").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_50",
        body: "mail_body_patchnote_1_9_50_50",
        colorState: "Default",
    }),
    patchnote_15: new MailMessage({
        ID: 78,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-03").getTime(),
                endGenerationBound: new Date("2025-08-03").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-07-03").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_60",
        body: "mail_body_patchnote_1_9_50_60",
        colorState: "Default",
    }),
    patchnote_16: new MailMessage({
        ID: 79,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-17").getTime(),
                endGenerationBound: new Date("2025-08-17").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-07-17").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkMap: { default: "http://shadowfight.com/news-balance-patch-1-9-50-80" },
        linkButtonAlias: "button_more",
        header: "mail_title_patchnote_1_9_50_80",
        body: "mail_body_patchnote_1_9_50_80",
        colorState: "Default",
    }),
    patchnote_17: new MailMessage({
        ID: 80,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-24").getTime(),
                endGenerationBound: new Date("2025-08-24").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-07-24").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_90",
        body: "mail_body_patchnote_1_9_50_90",
        colorState: "Default",
    }),
    patchnote_18: new MailMessage({
        ID: 81,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-07-31").getTime(),
                endGenerationBound: new Date("2025-08-31").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-07-31").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkMap: { default: "https://shadowfight.com/news-marcus-rework" },
        linkButtonAlias: "button_more",
        header: "mail_title_patchnote_1_9_50_100",
        body: "mail_body_patchnote_1_9_50_100",
        colorState: "Default",
    }),
    patchnote_19: new MailMessage({
        ID: 82,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-08-14").getTime(),
                endGenerationBound: new Date("2025-09-14").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-08-14").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_120",
        body: "mail_body_patchnote_1_9_50_120",
        colorState: "Default",
    }),
    patchnote_20: new MailMessage({
        ID: 83,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-08-21").getTime(),
                endGenerationBound: new Date("2025-09-21").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-08-21").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_130",
        body: "mail_body_patchnote_1_9_50_130",
        colorState: "Default",
    }),
    patchnote_21: new MailMessage({
        ID: 84,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-08-29").getTime(),
                endGenerationBound: new Date("2025-09-29").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-08-29").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_140",
        body: "mail_body_patchnote_1_9_50_140",
        colorState: "Default",
    }),
    patchnote_22: new MailMessage({
        ID: 85,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-09-04").getTime(),
                endGenerationBound: new Date("2025-10-04").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-09-04").getTime() },
            },
            autoRepeatAfter: true,
        },
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-50-150" },
        linkButtonAlias: "button_more",
        localized: true,
        header: "mail_title_patchnote_1_9_50_150",
        body: "mail_body_patchnote_1_9_50_150",
        colorState: "Default",
    }),
    patchnote_23: new MailMessage({
        ID: 86,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-09-11").getTime(),
                endGenerationBound: new Date("2025-10-11").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-09-11").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_160",
        body: "mail_body_patchnote_1_9_50_160",
        colorState: "Default",
    }),
    patchnote_24: new MailMessage({
        ID: 87,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-09-18").getTime(),
                endGenerationBound: new Date("2025-10-18").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-09-18").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_170",
        body: "mail_body_patchnote_1_9_50_170",
        colorState: "Default",
    }),
    patchnote_25: new MailMessage({
        ID: 88,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-09-25").getTime(),
                endGenerationBound: new Date("2025-10-25").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-09-25").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_180",
        body: "mail_body_patchnote_1_9_50_180",
        colorState: "Default",
    }),
    patchnote_26: new MailMessage({
        ID: 89,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-09").getTime(),
                endGenerationBound: new Date("2025-11-09").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-09").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_200",
        body: "mail_body_patchnote_1_9_50_200",
        colorState: "Default",
    }),
    patchnote_27: new MailMessage({
        ID: 90,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-16").getTime(),
                endGenerationBound: new Date("2025-11-16").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-16").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_50_210",
        body: "mail_body_patchnote_1_9_50_210",
        colorState: "Default",
    }),
    patchnote_28: new MailMessage({
        ID: 91,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-23").getTime(),
                endGenerationBound: new Date("2025-12-23").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-23").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55",
        body: "mail_body_patchnote_1_9_55",
        colorState: "Gold",
    }),
    patchnote_29: new MailMessage({
        ID: 92,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2025-10-30").getTime(),
                endGenerationBound: new Date("2025-11-30").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2025-10-30").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_55_10",
        body: "mail_body_patchnote_1_9_55_10",
        colorState: "Default",
    }),
    patchnote_30: new MailMessage({
        ID: 93,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-01-29").getTime(),
                endGenerationBound: new Date("2026-03-01").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-01-29").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_50",
        body: "mail_body_patchnote_1_9_60_50",
        colorState: "Default",
    }),
    patchnote_31: new MailMessage({
        ID: 94,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-05").getTime(),
                endGenerationBound: new Date("2026-03-05").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-02-05").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_60",
        body: "mail_body_patchnote_1_9_60_60",
        colorState: "Default",
    }),
    patchnote_32: new MailMessage({
        ID: 95,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-19").getTime(),
                endGenerationBound: new Date("2026-03-19").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-02-19").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_80",
        body: "mail_body_patchnote_1_9_60_80",
        linkButtonAlias: "button_more",
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-60-80" },
        colorState: "Default",
    }),
    patchnote_33: new MailMessage({
        ID: 96,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-02-26").getTime(),
                endGenerationBound: new Date("2026-03-26").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-02-26").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_90",
        body: "mail_body_patchnote_1_9_60_90",
        colorState: "Default",
    }),
    patchnote_34: new MailMessage({
        ID: 97,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-05").getTime(),
                endGenerationBound: new Date("2026-04-05").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-05").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_100",
        body: "mail_body_patchnote_1_9_60_100",
        colorState: "Default",
    }),
    patchnote_35: new MailMessage({
        ID: 98,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-19").getTime(),
                endGenerationBound: new Date("2026-04-19").getTime()
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-19").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-60-120" },
        linkButtonAlias: "button_more",
        header: "mail_title_patchnote_1_9_60_120",
        body: "mail_body_patchnote_1_9_60_120",
        colorState: "Default",
    }),
    patchnote_36: new MailMessage({
        ID: 99,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-26").getTime(),
                endGenerationBound: new Date("2026-04-26").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-26").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_130",
        body: "mail_body_patchnote_1_9_60_130",
        colorState: "Default",
    }),
    patchnote_37: new MailMessage({
        ID: 100,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-03-31").getTime(),
                endGenerationBound: new Date("2026-04-30").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-03-21").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_132",
        body: "mail_body_patchnote_1_9_60_132",
        colorState: "Default",
    }),
    patchnote_38: new MailMessage({
        ID: 101,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-01").getTime(),
                endGenerationBound: new Date("2026-04-02").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-01").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_april_fools_2026",
        body: "mail_body_patchnote_april_fools_2026",
        colorState: "Default",
    }),
    patchnote_39: new MailMessage({
        ID: 102,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-01").getTime(),
                endGenerationBound: new Date("2026-04-04").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-01").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkMap: { default: "https://shadowfight.com/news-new-mechanic-nose-2026" },
        linkButtonAlias: "button_more",
        header: "mail_title_april_fools_2026",
        body: "mail_body_april_fools_2026",
        colorState: "Gold",
    }),
    patchnote_40: new MailMessage({
        ID: 103,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-09").getTime(),
                endGenerationBound: new Date("2026-05-09").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-09").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_60_150",
        body: "mail_body_patchnote_1_9_60_150",
        colorState: "Default",
    }),
    patchnote_41: new MailMessage({
        ID: 104,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-14").getTime(),
                endGenerationBound: new Date("2026-05-14").getTime(),
            },
            conditions: {},
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_70",
        body: "mail_body_patchnote_1_9_70",
        colorState: "Gold",
    }),
    patchnote_42: new MailMessage({
        ID: 105,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-16").getTime(),
                endGenerationBound: new Date("2026-05-16").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-16").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_70_10",
        body: "mail_body_patchnote_1_9_70_10",
        colorState: "Default",
    }),
    patchnote_43: new MailMessage({
        ID: 106,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-23").getTime(),
                endGenerationBound: new Date("2026-05-23").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-23").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_70_20",
        body: "mail_body_patchnote_1_9_70_20",
        colorState: "Default",
    }),
    patchnote_44: new MailMessage({
        ID: 107,
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-04-30").getTime(),
                endGenerationBound: new Date("2026-05-30").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-04-30").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        header: "mail_title_patchnote_1_9_70_30",
        body: "mail_body_patchnote_1_9_70_30",
        colorState: "Default",
    }),
    patchnote_45: new MailMessage({
        ID: 108,
        header: "mail_title_patchnote_1_9_70_40",
        body: "mail_body_patchnote_1_9_70_40",
        colorState: "Default",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-07").getTime(),
                endGenerationBound: new Date("2026-06-07").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-05-07").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkButtonAlias: "button_more",
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-70-40" },
    }),
    patchnote_46: new MailMessage({
        ID: 109,
        header: "mail_title_patchnote_1_9_70_50",
        body: "mail_body_patchnote_1_9_70_50",
        colorState: "Default",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-14").getTime(),
                endGenerationBound: new Date("2026-06-14").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-05-14").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
    }),
    patchnote_47: new MailMessage({
        ID: 110,
        header: "mail_title_patchnote_1_9_70_70",
        body: "mail_body_patchnote_1_9_70_70",
        colorState: "Default",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-05-28").getTime(),
                endGenerationBound: new Date("2026-06-28").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-05-28").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
    }),
    patchnote_48: new MailMessage({
        ID: 111,
        header: "mail_title_patchnote_1_9_70_100",
        body: "mail_body_patchnote_1_9_70_100",
        colorState: "Default",
        promoSettings: {
            activeTime: {
                startGenerationBound: new Date("2026-06-18").getTime(),
                endGenerationBound: new Date("2026-07-18").getTime(),
            },
            conditions: {
                createdPlayerTime: { less_or_equal: new Date("2026-06-18").getTime() },
            },
            autoRepeatAfter: true,
        },
        localized: true,
        linkButtonAlias: "button_more",
        linkMap: { default: "https://shadowfight.com/news-balance-patch-1-9-70-100" },
    }),
    patchnote_49: new PatchnoteMessage({
        ID: 112,
        header: "mail_title_patchnote_1_9_70_110",
        body: "mail_body_patchnote_1_9_70_110",
        sendStartDate: '25.06.2026',
        deleteMessageDate: '25.07.2026',
    }),
    patchnote_50: new PatchnoteMessage({
        ID: 113,
        header: "mail_title_patchnote_1_9_70_120",
        body: "mail_body_patchnote_1_9_70_120",
        sendStartDate: '02.07.2026',
        deleteMessageDate: '02.08.2026',
    }),
    patchnote_51: new PatchnoteMessage({
        ID: 114,
        header: "mail_title_patchnote_1_9_80_10",
        body: "mail_body_patchnote_1_9_80_10",
        sendStartDate: '09.07.2026',
        deleteMessageDate: '09.08.2026',
    }),
}, true);
