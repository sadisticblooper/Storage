var tournaments = {};
var eventTournaments = {};
var tournamentGroups = {};
