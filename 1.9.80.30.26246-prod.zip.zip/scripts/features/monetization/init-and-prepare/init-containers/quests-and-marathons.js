var Quests = {};
var Marathons = {};
var eventQuestsAggregator = {};
var marathonSkeletons = {};
var marathonSkins = {};
