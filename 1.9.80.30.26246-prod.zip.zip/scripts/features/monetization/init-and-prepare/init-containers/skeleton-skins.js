var promoSkeletonsDictionary = {};
var promoSkinsDictionary = {};
