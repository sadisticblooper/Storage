var seasonalEvents = {};
var eventVisualConfigs = {};
