var gachaBanners = {};
