var rouletteVisualConfig = {};
var roulette = {};
var rouletteSkeletons = {};
var rouletteSkins = {};
