var offers = {};
var oneTimeOffers = {};
var offerSkeletons = {};
var offerSkins = {};
