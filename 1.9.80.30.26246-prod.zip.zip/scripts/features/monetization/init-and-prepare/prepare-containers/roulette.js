RouletteSkeletonUtils.createRouletteSkins(roulette, rouletteSkins);
PromoSkinSkeletonUtils.createRoulette(promoSkinsDictionary, roulette);
var rouletteMap = createIDMap(roulette, "rouletteMap");
itemsToShowCurrenciesInGameModule[GAME_MODULE.Roulette] = rouletteMap;
