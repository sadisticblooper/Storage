extend(tournamentGroups, promoTournaments, true);
extend(tournamentGroups, eventTournaments, true);
PromoSkinSkeletonUtils.createTournaments(promoSkinsDictionary, tournamentGroups);
var tournamentGroupsMap = createIDMap(tournamentGroups, 'tournamentGroupsMap');
TournamentUtils.createCycleTournaments(tournamentGroupsMap, cycleTournaments);
TournamentUtils.createLinkedPresets(tournamentGroupsMap);
var draftTournamentsMap = createIDMap(tournaments, "draftTournamentsMap");
