var seasonalEventsMap = createIDMap(seasonalEvents, "seasonalEventsMap");
