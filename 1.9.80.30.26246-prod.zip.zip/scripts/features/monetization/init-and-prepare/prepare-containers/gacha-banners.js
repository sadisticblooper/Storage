PromoSkinSkeletonUtils.createGacha(promoSkinsDictionary, gachaBanners);
var gachaBannersMap = createIDMap(gachaBanners, "gachaBannersMap");
