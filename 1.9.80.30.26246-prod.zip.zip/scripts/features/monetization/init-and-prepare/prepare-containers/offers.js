OfferSkeletonUtils.createOffersFromSkins(offers, offerSkins);
MarathonSkeletonUtils.createOffersFromMarathonSkins(offers, marathonSkins);
RouletteSkeletonUtils.createOffersFromRouletteSkins(offers, rouletteSkins);
PromoSkinSkeletonUtils.createOffers(promoSkinsDictionary, offers);
var offersMap = createIDMap(offers, "offersMap");
