var ActivityTimeConstants = (function () {
    function ActivityTimeConstants() {
    }
    ActivityTimeConstants.FruitNinja_06_2026 = {
        tournament: {
            start: new Date("2026-05-30").getTime(),
            end: new Date("2026-05-30").getTime() + new Time({ Days: 4 }).value,
        },
        marathon: {
            start: new Date("2026-05-30").getTime(),
            end: new Date("2026-05-30").getTime() + new Time({ Days: 4 }).value,
        },
    };
    ActivityTimeConstants.feldsher_rework_06_2026 = {
        start: new Date("2026-06-18").getTime(),
        end: new Date("2026-06-25").getTime(),
    };
    return ActivityTimeConstants;
}());
