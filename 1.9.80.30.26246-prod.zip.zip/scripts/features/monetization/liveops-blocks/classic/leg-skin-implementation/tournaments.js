var _a, _b, _c, _d, _e, _f, _g;
var Leg_Skin_Implementation = {
    TournamentGroup_Leg_Skin_ItuLCosmic: new TournamentGroup({
        ID: 2014,
        StartDate: LegSkinImplementationTimeConstants.ItuLCosmic.start,
        EndDate: LegSkinImplementationTimeConstants.ItuLCosmic.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_leg_Itu',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        SpecialPromoRestrictions: {
            noCustomizeExist: (_a = {}, _a[CUSTOMIZATION.SKIN] = [skins.Itu_L_Cosmic.ID], _a)
        },
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_6,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        GuaranteeDraft: {
            heroId: heroes.Itu.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [HeroNames.Itu.ID],
        },
        BotOpponentByStage: {
            2: [{ id: heroes.Itu.ID, skinId: skins.Itu_L_Cosmic.ID, weaponId: heroWeapons.wpn_Itu_E_Cosmic.ID, level: 6 }],
            5: [{ id: heroes.Itu.ID, skinId: skins.Itu_L_Cosmic.ID, weaponId: heroWeapons.wpn_Itu_E_Cosmic.ID, talents: [2, 1, 1, 1, 2], level: 10 }],
        },
        BotPresetsByStage: [
            { stages: [0, 1], presets: heroesGroupsForTournaments.All_Heroes_4 },
            { stages: [3, 4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 6,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Skin_Legendary,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_ITU_PVE.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.viper_backstreet.ID,
            locations.eldorado.ID,
        ],
        PresetID: 100039,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_leg_Itu',
                    AliasSubName: 'Tournament_subtitle_leg_Itu',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_b = {}, _b[CURRENCY.COIN] = 300, _b)],
                    Rewards: TournamentRewardsLegSkinImplementation.Tournament_Leg_Itu_2,
                    PictureInHub: "Sprites/PreviewImages/Events/Itu_L_Cosmic/bg_tournament_Itu_L_Cosmic",
                    PictureInWindow: "Sprites/PreviewImages/Events/Itu_L_Cosmic/bg_tournament_Itu_L_Cosmic",
                    PictureSmall: "Sprites/PreviewImages/Events/Itu_L_Cosmic/bg_event_banner_Itu_L_Cosmic",
                },
            ]
        },
    }),
    TournamentGroup_Leg_Skin_KiboLEclipse: new TournamentGroup({
        ID: 2015,
        StartDate: LegSkinImplementationTimeConstants.KiboLEclipse.tournament.start,
        EndDate: LegSkinImplementationTimeConstants.KiboLEclipse.tournament.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_leg_Kibo',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_6,
        RestrictionPlayerParams: {},
        GuaranteeDraft: {
            heroId: heroes.Kibo.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [HeroNames.Kibo.ID],
        },
        BotOpponentByStage: {
            2: [{ id: heroes.Kibo.ID, skinId: skins.Kibo_L_Eclipse.ID, weaponId: heroWeapons.wpn_Kibo_E_Eclipse.ID, level: 6 }],
            5: [{ id: heroes.Kibo.ID, skinId: skins.Kibo_L_Eclipse.ID, weaponId: heroWeapons.wpn_Kibo_E_Eclipse.ID, talents: [1, 2, 1, 1, 1], level: 10 }],
        },
        BotPresetsByStage: [
            { stages: [0, 1], presets: heroesGroupsForTournaments.All_Heroes_4 },
            { stages: [3, 4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 6,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Skin_Legendary,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_KIBO_PVE.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.viper_backstreet.ID,
            locations.eldorado.ID,
        ],
        PresetID: 100044,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_leg_Kibo',
                    AliasSubName: 'Tournament_subtitle_leg_Kibo',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_c = {}, _c[CURRENCY.COIN] = 100, _c)],
                    Rewards: TournamentRewardsLegSkinImplementation.Tournament_Leg_Kibo_2,
                    PictureInHub: "Sprites/PreviewImages/Events/Kibo_L_Eclipse/bg_tournament_Kibo_L_Eclipse",
                    PictureInWindow: "Sprites/PreviewImages/Events/Kibo_L_Eclipse/bg_tournament_Kibo_L_Eclipse",
                    PictureSmall: "Sprites/PreviewImages/Events/Kibo_L_Eclipse/event_banner_Kibo_L_Eclipse",
                },
            ]
        },
    }),
    TournamentGroup_Leg_Skin_LynxLHood: new TournamentGroup({
        ID: 2016,
        StartDate: LegSkinImplementationTimeConstants.LynxLegSkinTest.tournament.start,
        EndDate: LegSkinImplementationTimeConstants.LynxLegSkinTest.tournament.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_leg_Lynx',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        SpecialPromoRestrictions: {
            noCustomizeExist: (_d = {}, _d[CUSTOMIZATION.SKIN] = [skins.Lynx_L_Hood.ID], _d)
        },
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_6,
        RestrictionPlayerParams: {},
        GuaranteeDraft: {
            heroId: heroes.Lynx.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [HeroNames.Lynx.ID],
        },
        BotOpponentByStage: {
            2: [{ id: heroes.Lynx.ID, skinId: skins.Lynx_L_Hood.ID, weaponId: heroWeapons.wpn_Lynx_E_Hood.ID, level: 6 }],
            5: [{ id: heroes.Lynx.ID, skinId: skins.Lynx_L_Hood.ID, weaponId: heroWeapons.wpn_Lynx_E_Hood.ID, level: 10 }],
        },
        BotPresetsByStage: [
            { stages: [0, 1], presets: heroesGroupsForTournaments.All_Heroes_4 },
            { stages: [3, 4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 6,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Skin_Legendary,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_LYNX_LEG_SKIN.ID,
        LocationPool: [
            locations.thunder.ID,
            locations.bamboo_arena.ID,
            locations.viper_backstreet.ID,
        ],
        PresetID: 100047,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_leg_Lynx',
                    AliasSubName: 'Tournament_subtitle_leg_Lynx',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_e = {}, _e[CURRENCY.COIN] = 10, _e)],
                    Rewards: TournamentRewardsLegSkinImplementation.Tournament_Leg_Lynx,
                    PictureInHub: "Sprites/PreviewImages/Events/Lynx_L_Hood/bg_tournament_Lynx_L_Hood_hub",
                    PictureInWindow: "Sprites/PreviewImages/Events/Lynx_L_Hood/bg_tournament_Lynx_L_Hood",
                    PictureSmall: "Sprites/PreviewImages/Events/Lynx_L_Hood/bg_event_banner_Lynx_L_Hood",
                },
            ]
        },
        autoRepeatAfter: true,
    }),
    TournamentGroup_Leg_Skin_LegionKingLCastle: new TournamentGroup({
        ID: 2017,
        StartDate: LegSkinImplementationTimeConstants.LegionKingLCastle.start,
        EndDate: LegSkinImplementationTimeConstants.LegionKingLCastle.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_leg_Legion_King',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_6,
        RestrictionPlayerParams: {},
        GuaranteeDraft: {
            heroId: heroes.Legion_King.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [HeroNames.Legion_King.ID],
        },
        SpecialPromoRestrictions: {
            noCustomizeExist: (_f = {}, _f[CUSTOMIZATION.SKIN] = [skins.Legion_King_L_Castle.ID], _f)
        },
        BotOpponentByStage: {
            2: [{ id: heroes.Legion_King.ID, skinId: skins.Legion_King_L_Castle.ID, weaponId: heroWeapons.wpn_Legion_King_E_Castle.ID, level: 6 }],
            5: [{ id: heroes.Legion_King.ID, skinId: skins.Legion_King_L_Castle.ID, weaponId: heroWeapons.wpn_Legion_King_E_Castle.ID, level: 10 }],
        },
        BotPresetsByStage: [
            { stages: [0, 1], presets: heroesGroupsForTournaments.All_Heroes_4 },
            { stages: [4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 6,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Skin_Legendary,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_LEGION_KING_LEG_SKIN_PROMO.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.viper_backstreet.ID,
            locations.pve_5_1.ID,
            locations.thunder.ID
        ],
        PresetID: 100041,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_leg_Legion_King',
                    AliasSubName: 'Tournament_subtitle_leg_Legion_King',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_g = {}, _g[CURRENCY.COIN] = 10, _g)],
                    Rewards: TournamentRewardsLegSkinImplementation.Tournament_Leg_LK,
                    PictureInHub: "Sprites/PreviewImages/Events/Legion_King_L_Castle/bg_tournament_Legion_King_L_Castle",
                    PictureInWindow: "Sprites/PreviewImages/Events/Legion_King_L_Castle/bg_tournament_Legion_King_L_Castle",
                    PictureSmall: "Sprites/PreviewImages/Events/Legion_King_L_Castle/bg_event_banner_Legion_King_L_Castle"
                },
            ]
        },
    }),
};
extend(eventTournaments, Leg_Skin_Implementation, true);
