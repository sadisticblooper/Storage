rouletteSkins.Paid_Kibo_Leg_Apr_2026 = {
    skeleton: rouletteSkeletons.leg_skin_roulette,
    rouletteIdGenerator: function (index) { return 5008 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: LegSkinImplementationTimeConstants.KiboLEclipse.roulette.start,
        endGenerationBound: LegSkinImplementationTimeConstants.KiboLEclipse.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.legendary_Kibo_L_Eclipse,
        HERO_1: heroes.Kibo.ID,
        ALIAS_1: "roulette_title_leg_Kibo",
        SKIN_1: skins.Kibo_L_Eclipse.ID,
        STANCE_1: stances.stance_Kibo_E_Eclipse.ID,
        EMOJI_1: emoji.Kibo_Eclipse.ID,
        NAME_PREFIX: "leg_Kibo",
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.Paid_Ironclad_Leg_05_2026 = {
    skeleton: rouletteSkeletons.new_leg_skin_no_emoji_roulette,
    rouletteIdGenerator: function (index) { return 5009 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: LegSkinImplementationTimeConstants.IroncladMinotaur.roulette.start,
        endGenerationBound: LegSkinImplementationTimeConstants.IroncladMinotaur.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.roulette_Ironclad_L_Minotaur,
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: "roulette_title_leg_Ironclad",
        SKIN_1: skins.Ironclad_L_Minotaur.ID,
        STANCE_1: stances.stance_Ironclad_E_wall.ID,
        NAME_PREFIX: "leg_Ironclad",
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.Paid_Lynx_Leg_June_2026 = {
    skeleton: rouletteSkeletons.leg_skin_roulette,
    rouletteIdGenerator: function (index) { return 5010 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: LegSkinImplementationTimeConstants.LynxLegSkin.roulette.start,
        endGenerationBound: LegSkinImplementationTimeConstants.LynxLegSkin.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.roulette_Lynx_L_Hood,
        HERO_1: heroes.Lynx.ID,
        ALIAS_1: "title_promo_offer_Lynx_L",
        SKIN_1: skins.Lynx_L_Hood.ID,
        STANCE_1: stances.stance_Lynx_E_shadow.ID,
        EMOJI_1: emoji.Lynx_Disappearance.ID,
        NAME_PREFIX: "leg_Lynx",
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.Paid_LK_Leg_July_2026 = {
    skeleton: rouletteSkeletons.new_leg_skin_no_emoji_roulette,
    rouletteIdGenerator: function (index) { return 5011 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_paid_roulette_a_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: LegSkinImplementationTimeConstants.LegionKingLCastle.start,
        endGenerationBound: LegSkinImplementationTimeConstants.LegionKingLCastle.end,
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.legendary_Legion_King_Castle,
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: "skin_hero_Legion_King_L_Castle",
        SKIN_1: skins.Legion_King_L_Castle.ID,
        STANCE_1: stances.win_Legion_King_E_statue.ID,
        NAME_PREFIX: "leg_Legion_King",
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
