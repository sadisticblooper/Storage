var LegSkinImplementationTimeConstants = (function () {
    function LegSkinImplementationTimeConstants() {
    }
    LegSkinImplementationTimeConstants.LynxLHood = {
        start: new Date('2025-04-24').getTime(),
        end: new Date('2025-05-01').getTime()
    };
    LegSkinImplementationTimeConstants.ItuLCosmic = {
        start: new Date('2026-03-19').getTime(),
        end: new Date('2026-03-26').getTime(),
    };
    LegSkinImplementationTimeConstants.KiboLEclipse = {
        tournament: {
            start: new Date('2026-04-07').getTime(),
            end: new Date('2026-04-14').getTime(),
        },
        roulette: {
            start: new Date('2026-04-07').getTime(),
            end: new Date('2026-04-14').getTime(),
        }
    };
    LegSkinImplementationTimeConstants.MKLCrystal = {
        tournament: {
            start: new Date("2025-12-18").getTime(),
            end: new Date("2025-12-31").getTime(),
        },
        roulette: {
            start: new Date('2025-12-18').getTime(),
            end: new Date('2026-01-09').getTime(),
        }
    };
    LegSkinImplementationTimeConstants.IroncladMinotaur = {
        tournament: {
            start: new Date("2026-05-14").getTime(),
            end: new Date("2026-05-27").getTime(),
        },
        roulette: {
            start: new Date("2026-05-14").getTime(),
            end: new Date("2026-06-05").getTime(),
        }
    };
    LegSkinImplementationTimeConstants.LynxLegSkin = {
        tournament: {
            start: new Date('2026-06-18').getTime(),
            end: new Date('2026-06-25').getTime(),
        },
        roulette: {
            start: new Date('2026-06-18').getTime(),
            end: new Date('2026-06-25').getTime(),
        }
    };
    LegSkinImplementationTimeConstants.LynxLegSkinTest = {
        tournament: {
            start: new Date('2026-06-10').getTime(),
            end: new Date('2026-06-11').getTime(),
        },
    };
    LegSkinImplementationTimeConstants.LegionKingLCastle = {
        start: new Date('2026-07-20').getTime(),
        end: new Date('2026-07-27').getTime(),
    };
    return LegSkinImplementationTimeConstants;
}());
