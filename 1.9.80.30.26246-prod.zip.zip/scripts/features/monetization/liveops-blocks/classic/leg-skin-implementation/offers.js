var _a, _b, _c, _d, _e;
extend(offers, {
    PROMO_Leg_Monkey_King_Emoji: new PromoOffer({
        ID: 33739,
        offerNameAlias: "promo_title_MK_leg_emoji_offer",
        visualPresetId: "offer_with_image_leg_Monkey_King",
        conditions: {
            accountLevel: { more_or_equal: 2 },
            heroesOneOfExist: [heroes.Monkey_King.ID],
        },
        noCustomizeExist: (_a = {},
            _a[CUSTOMIZATION.EMOJI] = [emoji.MonkeyKing_Crystal.ID],
            _a),
        onceRepeatAfter: new Date("2025-12-17").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 161,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.MonkeyKing_Crystal.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Monkey_King.ID] = 8, _b) }) } } }],
                },
            ]
        },
        inApp: inAppSettings.PRICE_5.ProductID,
        profit: 2.0,
        discount: "-50%",
        activeTime: {
            startGenerationBound: LegSkinImplementationTimeConstants.MKLCrystal.roulette.start,
            endGenerationBound: LegSkinImplementationTimeConstants.MKLCrystal.roulette.end,
        },
    }),
    PROMO_Leg_Ironclad_Emoji: new PromoOffer({
        ID: 33740,
        offerNameAlias: "promo_title_Ironclad_leg_emoji_offer",
        visualPresetId: "offer_with_image_com_Ironclad",
        conditions: {
            accountLevel: { more_or_equal: 2 },
            heroesOneOfExist: [heroes.Ironclad.ID],
        },
        noCustomizeExist: (_c = {},
            _c[CUSTOMIZATION.EMOJI] = [emoji.Ironclad_Steam.ID],
            _c),
        onceRepeatAfter: new Date("2025-05-13").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 161,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Ironclad_Steam.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[heroes.Ironclad.ID] = 50, _d) }) } } }],
                },
            ]
        },
        inApp: inAppSettings.PRICE_2.ProductID,
        profit: 1.3,
        discount: "-25%",
        activeTime: {
            startGenerationBound: LegSkinImplementationTimeConstants.IroncladMinotaur.roulette.start,
            endGenerationBound: LegSkinImplementationTimeConstants.IroncladMinotaur.roulette.end,
        },
    }),
    PROMO_Leg_Legion_King_Emoji: new PromoOffer({
        ID: 33741,
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.3,
        discount: "-25%",
        offerNameAlias: "promo_title_INACTIVE_PAY_5",
        visualPresetId: "offer_with_image_leg_LK_alias",
        conditions: {
            accountLevel: { more_or_equal: 2 },
            heroesOneOfExist: [heroes.Legion_King.ID],
        },
        noCustomizeExist: (_e = {},
            _e[CUSTOMIZATION.EMOJI] = [emoji.Legion_King_ReachesOut.ID],
            _e),
        onceRepeatAfter: LegSkinImplementationTimeConstants.LegionKingLCastle.start,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 161,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Legion_King_ReachesOut.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: LegSkinImplementationTimeConstants.LegionKingLCastle.start,
            endGenerationBound: LegSkinImplementationTimeConstants.LegionKingLCastle.end,
        },
    }),
}, true);
