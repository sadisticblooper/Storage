var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _t, _u, _v, _w;
var TournamentRewardsLegSkinImplementation = {
    Tournament_Leg_Lynx: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: {
                    loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 10, _a) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 50, _b) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 100, _c) }) },
            },
            3: {
                repeatable: null,
                onetime: { chests: [chests.Common_chest.ID] },
            },
            4: {
                repeatable: null,
                onetime: { chests: [chests.Rare_chest.ID] },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.COIN] = 500, _d) }) },
            },
            6: {
                repeatable: null,
                onetime: { isHidden: false, loot: new Loot({ Shards: (_e = {}, _e[heroes.Lynx.ID] = 1, _e) }) }
            },
        },
    },
    Tournament_Leg_LK: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: {
                    loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 10, _f) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.COIN] = 50, _g) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.COIN] = 100, _h) }) },
            },
            3: {
                repeatable: null,
                onetime: { chests: [chests.Common_chest.ID] },
            },
            4: {
                repeatable: null,
                onetime: { chests: [chests.Rare_chest.ID] },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 500, _j) }) },
            },
            6: {
                repeatable: null,
                onetime: { isHidden: false, loot: new Loot({ Shards: (_k = {}, _k[heroes.Legion_King.ID] = 1, _k) }) }
            },
        },
    },
    Tournament_Leg_Itu_2: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: {
                    loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.COIN] = 10, _l) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.COIN] = 50, _m) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 100, _o) }) },
            },
            3: {
                repeatable: null,
                onetime: { chests: [chests.Common_chest.ID] },
            },
            4: {
                repeatable: null,
                onetime: { chests: [chests.Rare_chest.ID] },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 500, _p) }) },
            },
            6: {
                repeatable: null,
                onetime: { isHidden: false, loot: new Loot({ Shards: (_q = {}, _q[heroes.Itu.ID] = 1, _q) }) }
            },
        },
    },
    Tournament_Leg_Kibo_2: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: {
                    loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.COIN] = 10, _r) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 50, _t) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 100, _u) }) },
            },
            3: {
                repeatable: null,
                onetime: { chests: [chests.Common_chest.ID] },
            },
            4: {
                repeatable: null,
                onetime: { chests: [chests.Rare_chest.ID] },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 500, _v) }) },
            },
            6: {
                repeatable: null,
                onetime: { isHidden: false, loot: new Loot({ Shards: (_w = {}, _w[heroes.Kibo.ID] = 1, _w) }) }
            },
        },
    },
};
