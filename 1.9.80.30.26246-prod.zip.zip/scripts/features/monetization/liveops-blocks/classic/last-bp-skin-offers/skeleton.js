offerSkeletons.Last_Battle_Pass_Skin = {
    offers: [
        {
            common: {
                conditions: {},
                offerType: PROMO_OFFER_TYPE.STATIC,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-55%",
                profit: 2.4,
                hiddenOffer: true,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: CommonUtils.calculateFirstDayOfMonthWithOffset(VARS.START_DATE, 1),
                        endGenerationBound: CommonUtils.calculateLastDayOfMonthWithOffset(VARS.START_DATE, 1),
                        duration: new Time({ Days: VARS.DURATION_DATE_1 }).value
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        var lastLoginTime = settings.lastLoginTime;
                        var startPreviousMonth = CommonUtils.calculateFirstDayOfMonthWithOffset(VARS.START_DATE, 0);
                        var endPreviousMonth = CommonUtils.calculateFirstDayOfMonthWithOffset(VARS.START_DATE, 1);
                        var previousMonthLogin = lastLoginTime >= startPreviousMonth && lastLoginTime < endPreviousMonth;
                        return previousMonthLogin;
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [{
                                front: [{ weight: 1, item: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.GACHA_KEY] = 8, _b) }) } }]
                            }]
                    },
                };
            },
            offerPrefix: "Hidden"
        },
        {
            common: {
                conditions: {},
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                profit: 1.2,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: CommonUtils.calculateFirstDayOfMonthWithOffset(VARS.START_DATE, 1),
                        endGenerationBound: CommonUtils.calculateFirstDayOfMonthWithOffset(VARS.START_DATE, 2),
                        duration: new Time({ Days: VARS.DURATION_DATE_1 }).value
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    customCondition: function (settings) {
                        return OffersUtils.wasOfferIgnored(OFFERS[1], settings);
                    },
                    notBoughtOffers: [OFFERS[2]],
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Visible"
        },
    ]
};
