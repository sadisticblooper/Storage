offerSkins.Last_Battle_Pass_Skin_Oct = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104804 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-10-27").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "HongJoo_E_Cupid_Rec_Dark_skin",
        SKIN_1: skins.HongJoo_E_Cupid_Rec_Dark.ID,
        START_DATE: new Date("2025-10-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Oct_HongJoo_E_Cupid_Rec_Dark"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Nov = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104806 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-11-17").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Viper_E_Mobster_Rec_Glow_skin",
        SKIN_1: skins.Viper_E_Mobster_Rec_Glow.ID,
        START_DATE: new Date("2025-11-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Nov_Viper_E_Mobster_Rec_Glow"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Dec = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104808 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-12-25").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Emperor_E_Dragon_Rec_Orange",
        SKIN_1: skins.Emperor_E_Dragon_Rec_Orange_skin.ID,
        START_DATE: new Date("2025-12-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Dec_Emperor_E_Dragon_Rec_Orange_skin"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Jan = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104810 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-01-27").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Lynx_E_Mafia_Rec_Violet_skin",
        SKIN_1: skins.Lynx_E_Mafia_Rec_Violet.ID,
        START_DATE: new Date("2026-01-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Jan_Lynx_E_Mafia_Rec_Violet"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Feb = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104812 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-25").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Feldsher_E_Diver_Rec_Heated_skin",
        SKIN_1: skins.Feldsher_E_Diver_Rec_Heated.ID,
        START_DATE: new Date("2026-02-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Feb_Feldsher_E_Diver_Rec_Heated_skin"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Mar = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104814 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-19").getTime(),
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Xiang_Tzu_E_Indian_Rec_White_skin",
        SKIN_1: skins.Xiang_Tzu_E_Indian_Rec_White.ID,
        START_DATE: new Date("2026-03-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Xiang_Tzu_E_Indian_Rec_White_skin"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_Apr = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104816 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "last_bp_Butcher_E_Sushi",
        SKIN_1: skins.Butcher_E_Sushi.ID,
        START_DATE: new Date("2026-04-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Butcher_E_Sushi"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_May = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104818 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "Fireguard_E_Cyber_Rec_Green_marathon",
        SKIN_1: skins.Fireguard_E_Cyber_Rec_Green.ID,
        START_DATE: new Date("2026-05-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Fireguard_E_Cyber_Rec_Green"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Last_Battle_Pass_Skin_June = {
    skeleton: offerSkeletons.Last_Battle_Pass_Skin,
    offersIdGenerator: function (index) { return 104820 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BATTLE_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "epic_hero_Marcus_E_Veteran_Rec_Nouveau_skin",
        SKIN_1: skins.Marcus_E_Veteran_Rec_Nouveau_skin.ID,
        START_DATE: new Date("2026-06-01").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "Marcus_E_Veteran_Rec_Nouveau_skin"
    },
    offers: new Array(2).join("0").split("0").map(function (_) { return { common: {} }; }),
};
