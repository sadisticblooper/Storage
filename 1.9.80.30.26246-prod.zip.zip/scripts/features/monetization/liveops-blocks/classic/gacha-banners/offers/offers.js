extend(offers, {}, true);
