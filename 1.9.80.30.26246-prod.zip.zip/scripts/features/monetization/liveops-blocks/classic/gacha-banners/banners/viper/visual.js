GachaBannerVisualConfig.visualPresets.banner1904 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#55e5ba" }, "backgroundColor": "#55e5ba" },
        "title": { "alias": "gacha_title_Viper", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/Viper/rift_promo_art_Viper",
        "description": [
            { "alias": "gacha_subtitle_Viper", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_cobra", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Viper", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": 36, "y": 432 },
                "backgroundColor": "#2a6873",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Viper_E_Mobster", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -648, "y": -184 },
                "backgroundColor": "#2a6873",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Viper_E_Chargeboom", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -378, "y": -360 },
                "backgroundColor": "#2a6873",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#55e5ba",
        "lastMilestoneColor": "#8CC6FF",
        "gradientBgColor": "#2A735D"
    },
    slideConfig: {
        "frameColor": "#55e5ba",
        "discount": null,
        "gradientColor": "#5ee7ff",
        "patternColor": "#55e5ba",
        "backgroundColor": "#2a6873",
        "image": "Sprites/PreviewImages/RiftImages/Viper/riftArt_Viper",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#2A735D",
        "detailsBgImageColor": "#55E5BA",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Viper", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_cobra", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner1902 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#55e5ba" }, "backgroundColor": "#55e5ba" },
        "title": { "alias": "gacha_title_Viper", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/Viper/rift_promo_art_Viper_E_Grafitty",
        "description": [
            { "alias": "gacha_subtitle_Viper", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_cobra", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Viper", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": 88, "y": 432 },
                "backgroundColor": "#2a6873",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Viper_E_Graffiti", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -648, "y": -184 },
                "backgroundColor": "#2a6873",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Viper_E_Chargeboom", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -378, "y": -360 },
                "backgroundColor": "#2a6873",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#55e5ba",
        "lastMilestoneColor": "#8CC6FF",
        "gradientBgColor": "#2A735D"
    },
    slideConfig: {
        "frameColor": "#55e5ba",
        "discount": null,
        "gradientColor": "#5ee7ff",
        "patternColor": "#55e5ba",
        "backgroundColor": "#2a6873",
        "image": "Sprites/PreviewImages/RiftImages/Viper/rift_art_Viper_E_Grafitty",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#2A735D",
        "detailsBgImageColor": "#55E5BA",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Viper", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_cobra", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
