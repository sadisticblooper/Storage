var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner72", new GachaBanner({
    ID: 72,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.GACHA,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 3, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 30, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.Itu.ID] = 10, _c) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 4, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Ironclad.ID] = 10, _d) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Liquidator.ID] = 10, _e) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Monk.ID] = 10, _f) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Kibo.ID] = 10, _g) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Midnight.ID] = 10, _h) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Viper.ID] = 10, _j) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.HongJoo.ID] = 10, _k) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_l = {}, _l[heroes.Jet.ID] = 10, _l) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_E_Shadow_Edge.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Default_Rec_Chess.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Red.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_base_Rec_Black.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Helga_E_Phoenix_skin.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Itu_R_preparation.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Itu_R_chinugui.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.stance_Itu_E_meditation.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Itu_R_Red.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.win_Itu_E_portal.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Legion_King_R_Viny.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Marcus_R_boredom.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 600, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 600 }] }, _m) } } } },
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 120, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 120 }] }, _o) } } } },
                { weight: 5, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _p) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _q) } } } },
                { weight: 8, reward: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.COIN] = 9000, _r) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner56,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner106", new GachaBanner({
    ID: 106,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
        sellHeroSettings: {
            heroId: heroes.Xiang_Tzu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.GACHA
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_s = {}, _s[CURRENCY.GACHA_KEY] = 2, _s)
    },
    multipleRoll: {
        discount: 0,
        price: (_t = {}, _t[CURRENCY.GACHA_KEY] = 20, _t),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_u = {}, _u[heroes.Xiang_Tzu.ID] = 10, _u) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_v = {}, _v[heroes.Bulwark.ID] = 10, _v) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_w = {}, _w[heroes.Fireguard.ID] = 10, _w) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_x = {}, _x[heroes.Ironclad.ID] = 10, _x) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_y = {}, _y[heroes.Liquidator.ID] = 10, _y) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_z = {}, _z[heroes.Monk.ID] = 10, _z) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_0 = {}, _0[heroes.Kibo.ID] = 10, _0) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_1 = {}, _1[heroes.Lynx.ID] = 10, _1) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_E_Puffer.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Snake.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Purple.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_base_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns_Rec_Red.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Viper_E_Grafitti.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Fireguard_E_White_Rec_Void.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Xiang_Tzu_R_Fighter.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Universal_E_candle.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Bulwark_E_campfire.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Taunts: [taunts.Universal_R_Threat.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.Fireguard_L_Flames.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Midnight_E_mark.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Lynx_R_Claws_sparks.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Universal_E_snowball.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_2 = {}, _2[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _2) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_3 = {}, _3[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _3) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_4 = {}, _4[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _4) } } } },
                { weight: 3, reward: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.COIN] = 4000, _5) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner106,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner118", new GachaBanner({
    ID: 118,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.GACHA,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_6 = {}, _6[CURRENCY.GACHA_KEY] = 3, _6)
    },
    multipleRoll: {
        discount: 0,
        price: (_7 = {}, _7[CURRENCY.GACHA_KEY] = 30, _7),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_8 = {}, _8[heroes.June.ID] = 10, _8) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 4, reward: { loot: new Loot({ Shards: (_9 = {}, _9[heroes.Ironclad.ID] = 10, _9) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_10 = {}, _10[heroes.Liquidator.ID] = 10, _10) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_11 = {}, _11[heroes.Monk.ID] = 10, _11) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_12 = {}, _12[heroes.Butcher.ID] = 10, _12) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_13 = {}, _13[heroes.Xiang_Tzu.ID] = 10, _13) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_14 = {}, _14[heroes.Yunlin.ID] = 10, _14) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_15 = {}, _15[heroes.HongJoo.ID] = 10, _15) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_16 = {}, _16[heroes.Jet.ID] = 10, _16) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Legion_King_E_Witchblade.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Default_Rec_Chess.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Red.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_base_Rec_Elegant.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Legion_King_E_Prince.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Butcher_R_bully.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Itu_R_chinugui.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.win_Ling_E_raven.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.June_R_Star.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.win_Itu_E_portal.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Legion_King_R_Viny.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Marcus_R_boredom.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 600, TotalSlots: 1, Rarities: (_17 = {}, _17[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 600 }] }, _17) } } } },
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 120, TotalSlots: 1, Rarities: (_18 = {}, _18[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 120 }] }, _18) } } } },
                { weight: 5, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_19 = {}, _19[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _19) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_20 = {}, _20[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _20) } } } },
                { weight: 8, reward: { loot: new Loot({ Currencies: (_21 = {}, _21[CURRENCY.COIN] = 9000, _21) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner118,
}));
