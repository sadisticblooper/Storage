CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner775", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner1002,
    replaceConfig: {
        ID: 775,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner775.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner775.end,
            },
            sellHeroSettings: {
                heroId: heroes.Bulwark.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner1008,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_E_Pike.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_Golden_Rec_Gray.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Bulwark_E_Clover_Rec_Chill.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Bulwark_R_Rec_Boss_skin.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Bulwark_E_guitar.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Bulwark_R_shield.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Bulwark_R_hand_up.ID] }) } },
            ]
        }
    ],
}));
