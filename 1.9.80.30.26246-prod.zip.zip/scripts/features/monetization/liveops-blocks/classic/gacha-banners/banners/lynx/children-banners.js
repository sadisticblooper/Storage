CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner786", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner1701,
    replaceConfig: {
        ID: 786,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner786.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner786.end,
            },
            sellHeroSettings: {
                heroId: heroes.Lynx.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
    },
}));
