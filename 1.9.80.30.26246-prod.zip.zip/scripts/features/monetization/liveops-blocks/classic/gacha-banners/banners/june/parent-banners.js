var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner2602", new GachaBanner({
    ID: 2602,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.GachaBanner2602.start,
            endGenerationBound: GachaBannerTimeConstants.GachaBanner2602.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 10, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    disableUniqueLootPriority: true,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.June.ID] = 2, _c) }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 6, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Fireguard.ID] = 6, _d) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Liquidator.ID] = 6, _e) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Helga.ID] = 3, _f) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Yukka.ID] = 3, _g) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Widow.ID] = 2, _h) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Itu.ID] = 1, _j) }) } },
                { weight: 12, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.June.ID] = 1, _k) }) } },
            ],
        },
        {
            weight: 1200, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Itu_E_Vortex.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_R_Default_Rec_Guard.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_R_December.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_Gold_Rec_Bronze.ID] }) } },
            ],
        },
        {
            weight: 1370, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.June_E_Empress.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.June_R_Star.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_June_E_planet.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.win_June_R_meditation.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Helga_R_paladin_respect.ID] }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _l) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _m) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 8, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 8 }] }, _o) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 3 }] }, _p) } } } },
                { weight: 12, reward: { lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 4 }] }, _q) } } } },
                { weight: 10, reward: { lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_r = {}, _r[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _r) } } } },
                { weight: 15, reward: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 3000, _s) }) } },
                { weight: 10, reward: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 5000, _t) }) } },
                { weight: 2, reward: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 7500, _u) }) } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 10000, _v) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner2602,
}));
