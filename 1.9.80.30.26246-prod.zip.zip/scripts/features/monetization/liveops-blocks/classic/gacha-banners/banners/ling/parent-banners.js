var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner101", new GachaBanner({
    ID: 101,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 10, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    disableUniqueLootPriority: true,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.Ling.ID] = 6, _c) }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 6, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Bulwark.ID] = 6, _d) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Ironclad.ID] = 6, _e) }) } },
                { weight: 12, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Ling.ID] = 3, _f) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Sarge.ID] = 3, _g) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Yukka.ID] = 3, _h) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Emperor.ID] = 2, _j) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.Itu.ID] = 2, _k) }) } },
            ],
        },
        {
            weight: 1200, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_E_Shadow_Edge.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_base_Rec_Dark.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms.ID] }) } },
            ],
        },
        {
            weight: 1370, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Ling_E_Samurai_skin.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Ling_R_Red_skin.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Ling_R_Qigong.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Ling_E_raven.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Ling_R_swing_hide.ID] }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _l) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _m) } } } },
                { weight: 12, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _o) } } } },
                { weight: 10, reward: { lootSettings: { CardsSlots: { TotalCards: 60, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 60 }] }, _p) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 8, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 8 }] }, _q) } } } },
                { weight: 13, reward: { lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_r = {}, _r[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 3 }] }, _r) } } } },
                { weight: 15, reward: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 3000, _s) }) } },
                { weight: 10, reward: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 5000, _t) }) } },
                { weight: 2, reward: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 7500, _u) }) } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 10000, _v) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner101,
}));
