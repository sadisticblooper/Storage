GachaBannerVisualConfig.visualPresets.banner1101 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#47acff" }, "backgroundColor": "#47acff" },
        "title": { "alias": "gacha_title_Emperor", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/05_Emperor/rift_promo_art_Emperor",
        "description": [
            { "alias": "gacha_subtitle_Emperor", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_emperor", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Emperor", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -45, "y": 387 },
                "backgroundColor": "#1a688a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Emperor_R_Cyan", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -783, "y": -315 },
                "backgroundColor": "#1a688a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Emperor_E_Stone_Gloves", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -90, "y": -414 },
                "backgroundColor": "#1a688a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#47acff",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#2A5273"
    },
    slideConfig: {
        "frameColor": "#8ccbff",
        "discount": null,
        "gradientColor": "#47acff",
        "patternColor": "#75c1ff",
        "backgroundColor": "#5eb7ff",
        "image": "Sprites/PreviewImages/RiftImages/05_Emperor/rift_art_Emperor",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#2A5273",
        "detailsBgImageColor": "#47AEFF",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Emperor", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_emperor", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner1104 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#47acff" }, "backgroundColor": "#47acff" },
        "title": { "alias": "gacha_title_Emperor", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/05_Emperor/rift_promo_art_Emperor_Dragon",
        "description": [
            { "alias": "gacha_subtitle_Emperor", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_emperor", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Emperor", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -45, "y": 387 },
                "backgroundColor": "#1a688a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Emperor_E_Dragon", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -783, "y": -315 },
                "backgroundColor": "#1a688a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Emperor_E_Stone_Gloves", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -90, "y": -414 },
                "backgroundColor": "#1a688a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#47acff",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#2A5273"
    },
    slideConfig: {
        "frameColor": "#8ccbff",
        "discount": null,
        "gradientColor": "#47acff",
        "patternColor": "#75c1ff",
        "backgroundColor": "#5eb7ff",
        "image": "Sprites/PreviewImages/RiftImages/05_Emperor/rift_art_Emperor_Dragon",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#2A5273",
        "detailsBgImageColor": "#47AEFF",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Emperor", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_emperor", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
