CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner780", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner1101,
    replaceConfig: {
        ID: 780,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner780.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner780.end,
            },
            sellHeroSettings: {
                heroId: heroes.Emperor.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner1104,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_R_base_Rec_Silver.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_R_Default_Rec_Red.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_R_Default_Rec_Guard.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Emperor_E_Dragon_skin.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Kibo_R_Rose_skin.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_E_stop_mutation.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_E_beast_roar.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_R_agile_swings_H.ID] }) } },
            ]
        }
    ],
}));
