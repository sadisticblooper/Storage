GachaBannerVisualConfig.visualPresets.banner1002 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#a3ff8c" },
            "backgroundColor": "#a3ff8c"
        },
        "title": { "alias": "gacha_title_Bulwark", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_promo_art_Bulwark_R_Black_skin",
        "description": [
            { "alias": "gacha_subtitle_Bulwark", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jack", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Bulwark", "color": "#fff" },
                "description": {
                    "label1": { "alias": "common", "color": "#97aeb8" },
                    "label2": null
                },
                "coordinates": { "x": 63, "y": 441 },
                "backgroundColor": "#49733f",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Bulwark_R_Black", "color": "#fff" },
                "description": {
                    "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Bulwark_E_Pike", "color": "#fff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#c68cff" }
                },
                "coordinates": { "x": -508, "y": -396 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#718a58",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#588a4c"
    },
    slideConfig: {
        "frameColor": "#588a4c",
        "discount": null,
        "gradientColor": "#67a158",
        "patternColor": "#baff75",
        "backgroundColor": "#317320",
        "image": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_art_Bulwark_R_Black_skin",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_7"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#588a4c",
        "detailsBgImageColor": "#a3ff8c",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_07",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    { "alias": "gacha_contains_Bulwark", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [
                    { "alias": "gacha_10roll_jack", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
GachaBannerVisualConfig.visualPresets.banner1008 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#a3ff8c" }, "backgroundColor": "#a3ff8c" },
        "title": { "alias": "gacha_title_Bulwark", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_promo_art_Bulwark_Clover_Rec",
        "description": [
            { "alias": "gacha_subtitle_Bulwark", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jack", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Bulwark", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": 63, "y": 441 },
                "backgroundColor": "#49733f",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Bulwark_E_Clover_Rec_Chill", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Bulwark_E_Pike", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -350, "y": -396 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#718a58",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#588a4c"
    },
    slideConfig: {
        "frameColor": "#588a4c",
        "discount": null,
        "gradientColor": "#67a158",
        "patternColor": "#baff75",
        "backgroundColor": "#317320",
        "image": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_art_Bulwark_Clover_Rec",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_7"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#588a4c",
        "detailsBgImageColor": "#a3ff8c",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_07",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Bulwark", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_jack", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
