var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner1002", new GachaBanner({
    ID: 1002,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.GachaBanner1002.start,
            endGenerationBound: GachaBannerTimeConstants.GachaBanner1002.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 10, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    disableUniqueLootPriority: true,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.Bulwark.ID] = 12, _c) }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 12, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Bulwark.ID] = 6, _d) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Feldsher.ID] = 6, _e) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Monk.ID] = 6, _f) }) } },
                { weight: 7, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Fireguard.ID] = 6, _g) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Sarge.ID] = 3, _h) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Butcher.ID] = 2, _j) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.Legion_King.ID] = 2, _k) }) } },
            ],
        },
        {
            weight: 1200, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_E_Pike.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_Golden_Rec_Gray.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_Gold_Rec_Bronze.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Default_Rec_Chess.ID] }) } },
            ],
        },
        {
            weight: 1370, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Bulwark_R_Black_skin.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Bulwark_R_Rec_Boss_skin.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Bulwark_E_campfire.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Taunts: [taunts.Bulwark_E_dance.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Bulwark_R_shield_hit_swing.ID] }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _l) } } } },
                { weight: 12, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _m) } } } },
                { weight: 10, reward: { lootSettings: { CardsSlots: { TotalCards: 300, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 300 }] }, _o) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _p) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 8, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 8 }] }, _q) } } } },
                { weight: 13, reward: { lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_r = {}, _r[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 3 }] }, _r) } } } },
                { weight: 15, reward: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 3000, _s) }) } },
                { weight: 10, reward: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 5000, _t) }) } },
                { weight: 2, reward: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 7500, _u) }) } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 10000, _v) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner1002,
}));
