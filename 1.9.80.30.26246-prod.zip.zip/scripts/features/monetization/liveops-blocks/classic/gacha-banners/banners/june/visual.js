GachaBannerVisualConfig.visualPresets.banner2602 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#df6ae5" }, "backgroundColor": "#df6ae5" },
        "title": { "alias": "gacha_title_June", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/27_June/rift_promo_art_June",
        "description": [
            { "alias": "gacha_subtitle_June", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_june", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "June", "color": "#fff" },
                "description": { "label1": { "alias": "legendary", "color": "#ffd75e" }, "label2": null },
                "coordinates": { "x": 54, "y": 378 },
                "backgroundColor": "#863f8a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_June_E_Empress", "color": "#fff" },
                "description": {
                    "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -747, "y": -180 },
                "backgroundColor": "#863f8a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_June_E_Collapse", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -531, "y": -387 },
                "backgroundColor": "#863f8a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#df6ae5",
        "lastMilestoneColor": "#ffd75e",
        "gradientBgColor": "#2d152e"
    },
    slideConfig: {
        "frameColor": "#b354b8",
        "discount": null,
        "gradientColor": "#b354b8",
        "patternColor": "#df6ae5",
        "backgroundColor": "#863f8a",
        "image": "Sprites/PreviewImages/RiftImages/27_June/rift_art_June",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_2"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#863f8a",
        "detailsBgImageColor": "#df6ae5",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_02",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_June_1", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_june", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
