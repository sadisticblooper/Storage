var GachaBannerTimeConstants = (function () {
    function GachaBannerTimeConstants() {
    }
    GachaBannerTimeConstants.default = {
        start: new Date("2022-03-03").getTime(),
        end: new Date("2022-03-10").getTime(),
    };
    GachaBannerTimeConstants.GachaBanner1002 = {
        start: new Date("2025-02-28").getTime(),
        end: new Date("2025-02-28").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner2003 = {
        start: new Date("2025-03-01").getTime(),
        end: new Date("2025-03-01").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner606 = {
        start: new Date("2025-03-02").getTime(),
        end: new Date("2025-03-02").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner406 = {
        start: new Date("2025-03-04").getTime(),
        end: new Date("2025-03-04").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner2502 = {
        start: new Date("2025-03-06").getTime(),
        end: new Date("2025-03-06").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner2602 = {
        start: new Date("2025-03-08").getTime(),
        end: new Date("2025-03-08").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1701 = {
        start: new Date("2025-03-09").getTime(),
        end: new Date("2025-03-09").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1401 = {
        start: new Date("2025-03-10").getTime(),
        end: new Date("2025-03-10").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner902 = {
        start: new Date("2025-03-11").getTime(),
        end: new Date("2025-03-11").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1101 = {
        start: new Date("2025-03-12").getTime(),
        end: new Date("2025-03-12").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1605 = {
        start: new Date("2025-03-14").getTime(),
        end: new Date("2025-03-14").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1201 = {
        start: new Date("2025-03-18").getTime(),
        end: new Date("2025-03-18").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner2202 = {
        start: new Date("2025-03-20").getTime(),
        end: new Date("2025-03-20").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner1003 = {
        start: new Date("2025-03-17").getTime(),
        end: new Date("2025-03-17").getTime() + new Time({ Days: 7 }).value,
    };
    GachaBannerTimeConstants.GachaBanner662 = {
        start: new Date("2026-04-16").getTime(),
        end: new Date("2026-04-16").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner663 = {
        start: new Date("2026-04-17").getTime(),
        end: new Date("2026-04-17").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner664 = {
        start: new Date("2026-04-18").getTime(),
        end: new Date("2026-04-18").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner665 = {
        start: new Date("2026-04-19").getTime(),
        end: new Date("2026-04-19").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner666 = {
        start: new Date("2026-04-20").getTime(),
        end: new Date("2026-04-20").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner667 = {
        start: new Date("2026-04-21").getTime(),
        end: new Date("2026-04-21").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner668 = {
        start: new Date("2026-04-22").getTime(),
        end: new Date("2026-04-22").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner669 = {
        start: new Date("2026-04-23").getTime(),
        end: new Date("2026-04-23").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner670 = {
        start: new Date("2026-04-24").getTime(),
        end: new Date("2026-04-24").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner671 = {
        start: new Date("2026-04-25").getTime(),
        end: new Date("2026-04-25").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner672 = {
        start: new Date("2026-04-26").getTime(),
        end: new Date("2026-04-26").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner673 = {
        start: new Date("2026-04-27").getTime(),
        end: new Date("2026-04-27").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner674 = {
        start: new Date("2026-04-28").getTime(),
        end: new Date("2026-04-28").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner675 = {
        start: new Date("2026-04-29").getTime(),
        end: new Date("2026-04-29").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner676 = {
        start: new Date("2026-04-30").getTime(),
        end: new Date("2026-04-30").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner677 = {
        start: new Date("2026-05-01").getTime(),
        end: new Date("2026-05-01").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner678 = {
        start: new Date("2026-05-02").getTime(),
        end: new Date("2026-05-02").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner679 = {
        start: new Date("2026-05-03").getTime(),
        end: new Date("2026-05-03").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner680 = {
        start: new Date("2026-05-04").getTime(),
        end: new Date("2026-05-04").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner681 = {
        start: new Date("2026-05-05").getTime(),
        end: new Date("2026-05-05").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner682 = {
        start: new Date("2026-05-06").getTime(),
        end: new Date("2026-05-06").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner683 = {
        start: new Date("2026-05-07").getTime(),
        end: new Date("2026-05-07").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner684 = {
        start: new Date("2026-05-08").getTime(),
        end: new Date("2026-05-08").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner685 = {
        start: new Date("2026-05-09").getTime(),
        end: new Date("2026-05-09").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner686 = {
        start: new Date("2026-05-10").getTime(),
        end: new Date("2026-05-10").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner687 = {
        start: new Date("2026-05-11").getTime(),
        end: new Date("2026-05-11").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner688 = {
        start: new Date("2026-05-12").getTime(),
        end: new Date("2026-05-12").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner689 = {
        start: new Date("2026-05-13").getTime(),
        end: new Date("2026-05-13").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner690 = {
        start: new Date("2026-05-14").getTime(),
        end: new Date("2026-05-14").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner691 = {
        start: new Date("2026-05-15").getTime(),
        end: new Date("2026-05-15").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner692 = {
        start: new Date("2026-05-16").getTime(),
        end: new Date("2026-05-16").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner693 = {
        start: new Date("2026-05-17").getTime(),
        end: new Date("2026-05-17").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner694 = {
        start: new Date("2026-05-18").getTime(),
        end: new Date("2026-05-18").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner695 = {
        start: new Date("2026-05-19").getTime(),
        end: new Date("2026-05-19").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner696 = {
        start: new Date("2026-05-20").getTime(),
        end: new Date("2026-05-20").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner697 = {
        start: new Date("2026-05-21").getTime(),
        end: new Date("2026-05-21").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner698 = {
        start: new Date("2026-05-22").getTime(),
        end: new Date("2026-05-22").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner699 = {
        start: new Date("2026-05-23").getTime(),
        end: new Date("2026-05-23").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner720 = {
        start: new Date("2026-05-24").getTime(),
        end: new Date("2026-05-24").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner721 = {
        start: new Date("2026-05-25").getTime(),
        end: new Date("2026-05-25").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner722 = {
        start: new Date("2026-05-26").getTime(),
        end: new Date("2026-05-26").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner723 = {
        start: new Date("2026-05-27").getTime(),
        end: new Date("2026-05-27").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner724 = {
        start: new Date("2026-05-28").getTime(),
        end: new Date("2026-05-28").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner725 = {
        start: new Date("2026-05-29").getTime(),
        end: new Date("2026-05-29").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner726 = {
        start: new Date("2026-05-30").getTime(),
        end: new Date("2026-05-30").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner727 = {
        start: new Date("2026-05-31").getTime(),
        end: new Date("2026-05-31").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner728 = {
        start: new Date("2026-06-01").getTime(),
        end: new Date("2026-06-01").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner729 = {
        start: new Date("2026-06-02").getTime(),
        end: new Date("2026-06-02").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner730 = {
        start: new Date("2026-06-03").getTime(),
        end: new Date("2026-06-03").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner731 = {
        start: new Date("2026-06-04").getTime(),
        end: new Date("2026-06-04").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner732 = {
        start: new Date("2026-06-05").getTime(),
        end: new Date("2026-06-05").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner733 = {
        start: new Date("2026-06-06").getTime(),
        end: new Date("2026-06-06").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner734 = {
        start: new Date("2026-06-07").getTime(),
        end: new Date("2026-06-07").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner735 = {
        start: new Date("2026-06-08").getTime(),
        end: new Date("2026-06-08").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner736 = {
        start: new Date("2026-06-09").getTime(),
        end: new Date("2026-06-09").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner737 = {
        start: new Date("2026-06-10").getTime(),
        end: new Date("2026-06-10").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner738 = {
        start: new Date("2026-06-11").getTime(),
        end: new Date("2026-06-11").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner739 = {
        start: new Date("2026-06-12").getTime(),
        end: new Date("2026-06-12").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner740 = {
        start: new Date("2026-06-13").getTime(),
        end: new Date("2026-06-13").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner741 = {
        start: new Date("2026-06-14").getTime(),
        end: new Date("2026-06-14").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner742 = {
        start: new Date("2026-06-15").getTime(),
        end: new Date("2026-06-15").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner743 = {
        start: new Date("2026-06-16").getTime(),
        end: new Date("2026-06-16").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner744 = {
        start: new Date("2026-06-17").getTime(),
        end: new Date("2026-06-17").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner745 = {
        start: new Date("2026-06-18").getTime(),
        end: new Date("2026-06-18").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner746 = {
        start: new Date("2026-06-19").getTime(),
        end: new Date("2026-06-19").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner747 = {
        start: new Date("2026-06-20").getTime(),
        end: new Date("2026-06-20").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner748 = {
        start: new Date("2026-06-21").getTime(),
        end: new Date("2026-06-21").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner749 = {
        start: new Date("2026-06-22").getTime(),
        end: new Date("2026-06-22").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner750 = {
        start: new Date("2026-06-23").getTime(),
        end: new Date("2026-06-23").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner751 = {
        start: new Date("2026-06-24").getTime(),
        end: new Date("2026-06-24").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner752 = {
        start: new Date("2026-06-25").getTime(),
        end: new Date("2026-06-25").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner753 = {
        start: new Date("2026-06-26").getTime(),
        end: new Date("2026-06-26").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner754 = {
        start: new Date("2026-06-27").getTime(),
        end: new Date("2026-06-27").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner755 = {
        start: new Date("2026-06-28").getTime(),
        end: new Date("2026-06-28").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner756 = {
        start: new Date("2026-06-29").getTime(),
        end: new Date("2026-06-29").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner757 = {
        start: new Date("2026-06-30").getTime(),
        end: new Date("2026-06-30").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner758 = {
        start: new Date("2026-07-01").getTime(),
        end: new Date("2026-07-01").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner759 = {
        start: new Date("2026-07-02").getTime(),
        end: new Date("2026-07-02").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner760 = {
        start: new Date("2026-07-03").getTime(),
        end: new Date("2026-07-03").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner761 = {
        start: new Date("2026-07-04").getTime(),
        end: new Date("2026-07-04").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner762 = {
        start: new Date("2026-07-05").getTime(),
        end: new Date("2026-07-05").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner763 = {
        start: new Date("2026-07-06").getTime(),
        end: new Date("2026-07-06").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner764 = {
        start: new Date("2026-07-07").getTime(),
        end: new Date("2026-07-07").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner765 = {
        start: new Date("2026-07-08").getTime(),
        end: new Date("2026-07-08").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner766 = {
        start: new Date("2026-07-09").getTime(),
        end: new Date("2026-07-09").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner767 = {
        start: new Date("2026-07-10").getTime(),
        end: new Date("2026-07-10").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner768 = {
        start: new Date("2026-07-11").getTime(),
        end: new Date("2026-07-11").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner769 = {
        start: new Date("2026-07-12").getTime(),
        end: new Date("2026-07-12").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner770 = {
        start: new Date("2026-07-13").getTime(),
        end: new Date("2026-07-13").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner771 = {
        start: new Date("2026-07-14").getTime(),
        end: new Date("2026-07-14").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner772 = {
        start: new Date("2026-07-15").getTime(),
        end: new Date("2026-07-15").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner773 = {
        start: new Date("2026-07-16").getTime(),
        end: new Date("2026-07-16").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner774 = {
        start: new Date("2026-07-17").getTime(),
        end: new Date("2026-07-17").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner775 = {
        start: new Date("2026-07-18").getTime(),
        end: new Date("2026-07-18").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner776 = {
        start: new Date("2026-07-19").getTime(),
        end: new Date("2026-07-19").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner777 = {
        start: new Date("2026-07-20").getTime(),
        end: new Date("2026-07-20").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner778 = {
        start: new Date("2026-07-21").getTime(),
        end: new Date("2026-07-21").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner779 = {
        start: new Date("2026-07-22").getTime(),
        end: new Date("2026-07-22").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner780 = {
        start: new Date("2026-07-23").getTime(),
        end: new Date("2026-07-23").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner781 = {
        start: new Date("2026-07-24").getTime(),
        end: new Date("2026-07-24").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner782 = {
        start: new Date("2026-07-25").getTime(),
        end: new Date("2026-07-25").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner783 = {
        start: new Date("2026-07-26").getTime(),
        end: new Date("2026-07-26").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner784 = {
        start: new Date("2026-07-27").getTime(),
        end: new Date("2026-07-27").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner785 = {
        start: new Date("2026-07-28").getTime(),
        end: new Date("2026-07-28").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner786 = {
        start: new Date("2026-07-29").getTime(),
        end: new Date("2026-07-29").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner787 = {
        start: new Date("2026-07-30").getTime(),
        end: new Date("2026-07-30").getTime() + new Time({ Days: 3 }).value,
    };
    GachaBannerTimeConstants.GachaBanner788 = {
        start: new Date("2026-07-31").getTime(),
        end: new Date("2026-07-31").getTime() + new Time({ Days: 3 }).value,
    };
    return GachaBannerTimeConstants;
}());
