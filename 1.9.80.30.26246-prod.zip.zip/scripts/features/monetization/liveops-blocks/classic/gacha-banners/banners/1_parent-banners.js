var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner4", new GachaBanner({
    ID: 4,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 10, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.HongJoo.ID] = 10, _c) }) } },
            ],
        },
        {
            weight: 5, rewards: [
                { weight: 3, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Bulwark.ID] = 10, _d) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Fireguard.ID] = 10, _e) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Ironclad.ID] = 10, _f) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Liquidator.ID] = 10, _g) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Monk.ID] = 10, _h) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Viper.ID] = 10, _j) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.Jet.ID] = 10, _k) }) } },
            ],
        },
        {
            weight: 7, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_E_FireShow.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Red.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Equilibrist_Rec_Gold.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Snake.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Purple.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_Golden_Rec_Black.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_base_Rec_Brown.ID] }) } },
            ],
        },
        {
            weight: 7, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.HongJoo_E_Equilibrist_skin.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.HongJoo_E_Equilibrist_Rec_Sakura_skin.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.HongJoo_R_base_Rec_Flame.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.win_HongJoo_E_take_a_bow.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.win_HongJoo_R_autograph.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Taunts: [taunts.Jet_E_drums.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Taunts: [taunts.Jet_E_tenderness.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.Ironclad_R_wave.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_HongJoo_R_agility.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_HongJoo_R_triple_staff_combine_shoulder.ID] }) } },
            ],
        },
        {
            weight: 35, rewards: [
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 125, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 125 }] }, _l) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _m) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _o) } } } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 2000, _p) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner4,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner5", new GachaBanner({
    ID: 5,
    promoSettings: {
        conditions: {
            heroes: (_q = {}, _q[heroes.Emperor.ID] = { Level: { more_or_equal: 3 } }, _q)
        },
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_r = {}, _r[CURRENCY.GACHA_KEY] = 2, _r)
    },
    multipleRoll: {
        discount: 0,
        price: (_s = {}, _s[CURRENCY.GACHA_KEY] = 20, _s),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_t = {}, _t[heroes.Emperor.ID] = 10, _t) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_u = {}, _u[heroes.Bulwark.ID] = 10, _u) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_v = {}, _v[heroes.Fireguard.ID] = 10, _v) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_w = {}, _w[heroes.Ironclad.ID] = 10, _w) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_x = {}, _x[heroes.Liquidator.ID] = 10, _x) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_y = {}, _y[heroes.Monk.ID] = 10, _y) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_z = {}, _z[heroes.Lynx.ID] = 10, _z) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_0 = {}, _0[heroes.Midnight.ID] = 10, _0) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_R_Default_Rec_Red.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_R_base_Rec_Silver.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms_Rec_Antique.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_base_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_Default_Rec_GoldenDark.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Emperor_R_Cyan_skin.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Emperor_E_Doomed_skin.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Emperor_E_rage_scream.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Emperor_E_Frozen_Throne.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_E_beast_roar.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_R_I_know_kung_fu.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_E_stop_mutation.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_R_agile_swings_H.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Emperor_R_agile_swings_M.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.win_Emperor_R_deft_swings_M.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.win_Emperor_R_deft_swings_H.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_clap.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_yawn.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_cry_baby.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_1 = {}, _1[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _1) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_2 = {}, _2[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _2) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_3 = {}, _3[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _3) } } } },
                { weight: 3, reward: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.COIN] = 4000, _4) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner5,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner6", new GachaBanner({
    ID: 6,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_5 = {}, _5[CURRENCY.GACHA_KEY] = 1, _5)
    },
    multipleRoll: {
        discount: 0,
        price: (_6 = {}, _6[CURRENCY.GACHA_KEY] = 10, _6),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_7 = {}, _7[heroes.Jet.ID] = 10, _7) }) } },
            ],
        },
        {
            weight: 5, rewards: [
                { weight: 3, reward: { loot: new Loot({ Shards: (_8 = {}, _8[heroes.Bulwark.ID] = 10, _8) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_9 = {}, _9[heroes.Fireguard.ID] = 10, _9) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_10 = {}, _10[heroes.Ironclad.ID] = 10, _10) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_11 = {}, _11[heroes.Liquidator.ID] = 10, _11) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_12 = {}, _12[heroes.Monk.ID] = 10, _12) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_13 = {}, _13[heroes.HongJoo.ID] = 10, _13) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_14 = {}, _14[heroes.Helga.ID] = 10, _14) }) } },
            ],
        },
        {
            weight: 7, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_base_Rec_Brown.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_Golden_Rec_Sakura.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_Golden_Rec_Black.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_base_Rec_Red.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_R_Paladin_Rec_Blue.ID] }) } },
            ],
        },
        {
            weight: 7, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Jet_E_Golden.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Jet_E_Water.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Jet_R_base_Rec_Purple.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.stance_Jet_R_twists_staff_apart.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Taunts: [taunts.Jet_E_drums.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Taunts: [taunts.Jet_E_tenderness.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.win_Jet_E_Hammock.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.win_Jet_E_pretty_nails.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Jet_R_swing_look.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Yukka_R_Flow.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.stance_Jet_E_iceskates.ID] }) } },
            ],
        },
        {
            weight: 35, rewards: [
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 125, TotalSlots: 1, Rarities: (_15 = {}, _15[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 125 }] }, _15) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_16 = {}, _16[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _16) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_17 = {}, _17[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _17) } } } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_18 = {}, _18[CURRENCY.COIN] = 2000, _18) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner6,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner10", new GachaBanner({
    ID: 10,
    promoSettings: {
        conditions: { heroes: (_19 = {}, _19[heroes.Yukka.ID] = { Level: { more_or_equal: 2 } }, _19) },
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_20 = {}, _20[CURRENCY.GACHA_KEY] = 1, _20)
    },
    multipleRoll: {
        discount: 0,
        price: (_21 = {}, _21[CURRENCY.GACHA_KEY] = 10, _21),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 2, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_22 = {}, _22[heroes.Yukka.ID] = 10, _22) }) } },
            ],
        },
        {
            weight: 2, rewards: [
                { weight: 3, reward: { loot: new Loot({ Shards: (_23 = {}, _23[heroes.Bulwark.ID] = 10, _23) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_24 = {}, _24[heroes.Fireguard.ID] = 10, _24) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_25 = {}, _25[heroes.Ironclad.ID] = 10, _25) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_26 = {}, _26[heroes.Liquidator.ID] = 10, _26) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_27 = {}, _27[heroes.Monk.ID] = 10, _27) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_28 = {}, _28[heroes.HongJoo.ID] = 10, _28) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_29 = {}, _29[heroes.Jet.ID] = 10, _29) }) } },
            ],
        },
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_E_Wind.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms_Rec_Antique.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade_Rec_Red.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_R_base_Rec_Purple.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_R_December.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
            ],
        },
        {
            weight: 3, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Yukka_E_Cat.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Yukka_R_Flow.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Yukka_E_cat_hugs.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Fireguard_R_respect.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Yukka_R_swing_bend.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Yukka_R_long_swing.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Helga_R_bow.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Ironclad_R_wave.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Yukka_R_Red.ID] }) } },
            ],
        },
        {
            weight: 20, rewards: [
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 125, TotalSlots: 1, Rarities: (_30 = {}, _30[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 125 }] }, _30) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_31 = {}, _31[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _31) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_32 = {}, _32[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _32) } } } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_33 = {}, _33[CURRENCY.COIN] = 2000, _33) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner10,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner11", new GachaBanner({
    ID: 11,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_34 = {}, _34[CURRENCY.GACHA_KEY] = 3, _34)
    },
    multipleRoll: {
        discount: 0,
        price: (_35 = {}, _35[CURRENCY.GACHA_KEY] = 30, _35),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_36 = {}, _36[heroes.Monkey_King.ID] = 10, _36) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 4, reward: { loot: new Loot({ Shards: (_37 = {}, _37[heroes.Ironclad.ID] = 10, _37) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_38 = {}, _38[heroes.Liquidator.ID] = 10, _38) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_39 = {}, _39[heroes.Monk.ID] = 10, _39) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_40 = {}, _40[heroes.Kibo.ID] = 10, _40) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_41 = {}, _41[heroes.Midnight.ID] = 10, _41) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_42 = {}, _42[heroes.Viper.ID] = 10, _42) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_43 = {}, _43[heroes.HongJoo.ID] = 10, _43) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_44 = {}, _44[heroes.Jet.ID] = 10, _44) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_E_Nephritis.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_R_Default_Rec_Blue.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_R_base_Rec_Purple.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_E_White_Star.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_E_FireShow.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Monkey_King_E_Stranger.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.win_MonkeyKing_E_Cloud.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Monkey_King_E_cruel.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Marcus_E_Royal_skin.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Monk_E_Cursed.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.stance_Monkeyking_E_fruits.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Stances: [stances.stance_Monkeyking_E_toothpick.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Taunts: [taunts.Bulwark_E_dance.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Monkey_King_R_base_Rec_Blaze.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 600, TotalSlots: 1, Rarities: (_45 = {}, _45[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 600 }] }, _45) } } } },
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 120, TotalSlots: 1, Rarities: (_46 = {}, _46[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 120 }] }, _46) } } } },
                { weight: 5, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_47 = {}, _47[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _47) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_48 = {}, _48[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _48) } } } },
                { weight: 8, reward: { loot: new Loot({ Currencies: (_49 = {}, _49[CURRENCY.COIN] = 9000, _49) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner11,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner13", new GachaBanner({
    ID: 13,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_50 = {}, _50[CURRENCY.GACHA_KEY] = 2, _50)
    },
    multipleRoll: {
        discount: 0,
        price: (_51 = {}, _51[CURRENCY.GACHA_KEY] = 20, _51),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_52 = {}, _52[heroes.Midnight.ID] = 10, _52) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_53 = {}, _53[heroes.Bulwark.ID] = 10, _53) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_54 = {}, _54[heroes.Fireguard.ID] = 10, _54) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_55 = {}, _55[heroes.Ironclad.ID] = 10, _55) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_56 = {}, _56[heroes.Liquidator.ID] = 10, _56) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_57 = {}, _57[heroes.Monk.ID] = 10, _57) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_58 = {}, _58[heroes.Kibo.ID] = 10, _58) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_59 = {}, _59[heroes.Lynx.ID] = 10, _59) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_E_RedVampire.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_base_Rec_Red.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_Default_Rec_GoldenDark.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Snake.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Purple.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_base_Rec_Dark.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Midnight_E_Ghost.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Midnight_E_Witch.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Midnight_R_Blue.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Midnight_R_ninja.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_E_absorb_energy.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Taunts: [taunts.Marcus_R_boredom.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.Fireguard_L_Flames.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Midnight_E_mark.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Lynx_R_Claws_sparks.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_R_pull_out_spin.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_60 = {}, _60[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _60) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_61 = {}, _61[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _61) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_62 = {}, _62[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _62) } } } },
                { weight: 3, reward: { loot: new Loot({ Currencies: (_63 = {}, _63[CURRENCY.COIN] = 4000, _63) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner13,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner15", new GachaBanner({
    ID: 15,
    promoSettings: {
        conditions: { heroes: (_64 = {}, _64[heroes.Sarge.ID] = { Level: { more_or_equal: 2 } }, _64) },
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_65 = {}, _65[CURRENCY.GACHA_KEY] = 1, _65)
    },
    multipleRoll: {
        discount: 0,
        price: (_66 = {}, _66[CURRENCY.GACHA_KEY] = 10, _66),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 2, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_67 = {}, _67[heroes.Sarge.ID] = 10, _67) }) } },
            ],
        },
        {
            weight: 2, rewards: [
                { weight: 3, reward: { loot: new Loot({ Shards: (_68 = {}, _68[heroes.Bulwark.ID] = 10, _68) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_69 = {}, _69[heroes.Fireguard.ID] = 10, _69) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_70 = {}, _70[heroes.Ironclad.ID] = 10, _70) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_71 = {}, _71[heroes.Liquidator.ID] = 10, _71) }) } },
                { weight: 3, reward: { loot: new Loot({ Shards: (_72 = {}, _72[heroes.Monk.ID] = 10, _72) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_73 = {}, _73[heroes.HongJoo.ID] = 10, _73) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_74 = {}, _74[heroes.Viper.ID] = 10, _74) }) } },
            ],
        },
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_E_Burn.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns_Rec_Red.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Equilibrist_Rec_Gold.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_base_Rec_Black.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_Gold_Rec_Bronze.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_base_Rec_Red.ID] }) } },
            ],
        },
        {
            weight: 3, rewards: [
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Sarge_R_Dark.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Sarge_E_Jailer.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Yukka_R_Flow.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Sarge_E_pain_plan.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Sarge_R_sharp_knife.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Sarge_R_Thor.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Sarge_R_hooah.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Sarge_R_hammer_flip.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Ironclad_R_punches.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Helga_R_bow.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Taunts: [taunts.Sarge_R_push_up.ID] }) } },
            ],
        },
        {
            weight: 20, rewards: [
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 125, TotalSlots: 1, Rarities: (_75 = {}, _75[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 125 }] }, _75) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_76 = {}, _76[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _76) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_77 = {}, _77[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _77) } } } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_78 = {}, _78[CURRENCY.COIN] = 2000, _78) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner15,
}));
