GachaBannerVisualConfig.visualPresets.banner101 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#ffbf5e" },
            "backgroundColor": "#ffbf5e"
        },
        "title": { "alias": "gacha_title_Ling", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/14_Ling/rift_promo_art_Ling",
        "description": [
            { "alias": "gacha_subtitle_Ling", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_ling", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Ling", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "rare", "color": "#8cbaff" },
                    "label2": null
                },
                "coordinates": { "x": -639, "y": 450 },
                "backgroundColor": "#a1783b",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Ling_E_Samurai", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -639, "y": -225 },
                "backgroundColor": "#a1783b",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Ling_E_Shadow_Edge", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#C68CFFB8" }
                },
                "coordinates": { "x": -310, "y": -369 },
                "backgroundColor": "#a1783b",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#ffb647",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#8a580e"
    },
    slideConfig: {
        "frameColor": "#ffb647",
        "discount": null,
        "gradientColor": "#ffbf5e",
        "patternColor": "#ffb647",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/14_Ling/rift_art_Ling",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_9"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#73562A",
        "detailsBgImageColor": "#FFBF5E",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    { "alias": "gacha_contains_Ling", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [
                    { "alias": "gacha_10roll_ling", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner103 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#ffbf5e" },
            "backgroundColor": "#ffbf5e"
        },
        "title": { "alias": "gacha_title_Ling", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/14_Ling/rift_promo_art_Ling_Samurai_Rec_Gold",
        "description": [
            { "alias": "gacha_subtitle_Ling", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_ling", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Ling", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "rare", "color": "#8cbaff" },
                    "label2": null
                },
                "coordinates": { "x": 70, "y": 400 },
                "backgroundColor": "#a1783b",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Ling_R_Gold", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -570, "y": -190 },
                "backgroundColor": "#a1783b",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Ling_E_Shadow_Edge", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#C68CFFB8" }
                },
                "coordinates": { "x": -310, "y": -369 },
                "backgroundColor": "#a1783b",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#ffb647",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#8a580e"
    },
    slideConfig: {
        "frameColor": "#ffb647",
        "discount": null,
        "gradientColor": "#ffbf5e",
        "patternColor": "#ffb647",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/14_Ling/rift_art_Ling_Samurai_Rec_Gold",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_9"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#73562A",
        "detailsBgImageColor": "#FFBF5E",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Ling", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_ling", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
