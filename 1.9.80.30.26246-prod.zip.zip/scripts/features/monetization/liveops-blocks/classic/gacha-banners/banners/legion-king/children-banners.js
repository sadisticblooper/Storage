CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner784", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner2003,
    replaceConfig: {
        ID: 784,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner784.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner784.end,
            },
            sellHeroSettings: {
                heroId: heroes.Legion_King.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner2005,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Legion_King_E_Abyssblade.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Legion_King_R_Default_Rec_Vampire.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_R_Default_Rec_Guard.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Snake.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_base_Rec_Elegant.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Legion_King_E_Prince.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Legion_King_R_Viny.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Legion_King_R_fient.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Legion_King_E_horse.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Feldsher_R_bow.ID] }) } },
            ]
        }
    ],
}));
