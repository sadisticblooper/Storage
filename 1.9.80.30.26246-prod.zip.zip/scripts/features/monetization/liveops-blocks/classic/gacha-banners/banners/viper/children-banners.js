CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner776", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner1904,
    replaceConfig: {
        ID: 776,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner776.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner776.end,
            },
            sellHeroSettings: {
                heroId: heroes.Viper.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner1902,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_E_Chargeboom.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Purple.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Snake.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_R_December.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_R_Red.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Viper_E_Grafitti.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Viper_R_base_Rec_Brat.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Viper_R_slide.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Viper_R_glasses.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_HongJoo_R_agility.ID] }) } },
            ]
        }
    ],
}));
