GachaBannerVisualConfig.visualPresets.banner1605 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#a575ff" }, "backgroundColor": "#a575ff" },
        "title": { "alias": "gacha_title_Midnight", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/13_Midnight/rift_promo_art_Midnight",
        "description": [
            { "alias": "gacha_subtitle_Midnight", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_midnight", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Midnight", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": 20, "y": 414 },
                "backgroundColor": "#49278a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Midnight_E_Assassin", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -666, "y": -189 },
                "backgroundColor": "#49278a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Midnight_E_Cold", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -288, "y": -396 },
                "backgroundColor": "#49278a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#8847ff",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#3d2073"
    },
    slideConfig: {
        "frameColor": "#8265b8",
        "discount": null,
        "gradientColor": "#8847ff",
        "patternColor": "#8847ff",
        "backgroundColor": "#3d2073",
        "image": "Sprites/PreviewImages/RiftImages/13_Midnight/rift_art_Midnight",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_2"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#3D2073",
        "detailsBgImageColor": "#A575FF",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_02",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Midnight", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_midnight", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner1603 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#a575ff" }, "backgroundColor": "#a575ff" },
        "title": { "alias": "gacha_title_Midnight", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/13_Midnight/rift_promo_art_Midnight_Witch",
        "description": [
            { "alias": "gacha_subtitle_Midnight", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_midnight", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Midnight", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": 20, "y": 414 },
                "backgroundColor": "#49278a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Midnight_E_Witch", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -666, "y": -189 },
                "backgroundColor": "#49278a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Midnight_E_Cold", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -288, "y": -396 },
                "backgroundColor": "#49278a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#8847ff",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#3d2073"
    },
    slideConfig: {
        "frameColor": "#8265b8",
        "discount": null,
        "gradientColor": "#8847ff",
        "patternColor": "#8847ff",
        "backgroundColor": "#3d2073",
        "image": "Sprites/PreviewImages/RiftImages/13_Midnight/rift_art_Midnight_Witch",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_2"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#3D2073",
        "detailsBgImageColor": "#A575FF",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_02",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Midnight", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_midnight", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
