GachaBannerVisualConfig.visualPresets.banner704 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#ffb647" }, "backgroundColor": "#ffb647" },
        "title": { "alias": "gacha_title_Jet", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/06_Jet/rift_promo_art_Jet",
        "description": [
            { "alias": "gacha_subtitle_Jet", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jet", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Jet", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": -585, "y": 279 },
                "backgroundColor": "#a1612d",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Jet_E_Water_Rec_Pink", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Jet_E_Prism", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -320, "y": -387 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#b86e00",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#73490b"
    },
    slideConfig: {
        "frameColor": "#b87c23",
        "discount": null,
        "gradientColor": "#ffa31a",
        "patternColor": "#e5bc40",
        "backgroundColor": "#734520",
        "image": "Sprites/PreviewImages/RiftImages/06_Jet/rift_art_Jet",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#735220",
        "detailsBgImageColor": "#ffb647",
        "detailsBgImage": "Sprites/Assets/Decor/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner705 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#ffb647" }, "backgroundColor": "#ffb647" },
        "title": { "alias": "gacha_title_Jet", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/06_Jet/rift_promo_art_Jet_Nomad",
        "description": [
            { "alias": "gacha_subtitle_Jet", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jet", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Jet", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": -585, "y": 279 },
                "backgroundColor": "#a1612d",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Jet_E_Nomad", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Jet_E_Prism", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -320, "y": -387 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#b86e00",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#73490b"
    },
    slideConfig: {
        "frameColor": "#b87c23",
        "discount": null,
        "gradientColor": "#ffa31a",
        "patternColor": "#e5bc40",
        "backgroundColor": "#734520",
        "image": "Sprites/PreviewImages/RiftImages/06_Jet/rift_art_Jet_Nomad",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#735220",
        "detailsBgImageColor": "#ffb647",
        "detailsBgImage": "Sprites/Assets/Decor/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
GachaBannerVisualConfig.visualPresets.banner703 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#ffb647" }, "backgroundColor": "#ffb647" },
        "title": { "alias": "gacha_title_Jet", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/06_Jet/rift_promo_art_Jet_E_Water",
        "description": [
            { "alias": "gacha_subtitle_Jet", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jet", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Jet", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": -585, "y": 279 },
                "backgroundColor": "#a1612d",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Jet_E_Water", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Jet_E_Prism", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -320, "y": -387 },
                "backgroundColor": "#a1612d",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#b86e00",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#73490b"
    },
    slideConfig: {
        "frameColor": "#b87c23",
        "discount": null,
        "gradientColor": "#ffa31a",
        "patternColor": "#e5bc40",
        "backgroundColor": "#734520",
        "image": "Sprites/PreviewImages/RiftImages/06_Jet/rift_art_Jet_E_Water",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#735220",
        "detailsBgImageColor": "#ffb647",
        "detailsBgImage": "Sprites/Assets/Decor/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_jet", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
