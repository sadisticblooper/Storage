GachaBannerVisualConfig.visualPresets.banner303 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#b8af97" }, "backgroundColor": "#b8af97" },
        "title": { "alias": "gacha_title_Liquidator", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_promo_art_Liquidator",
        "description": [
            { "alias": "gacha_subtitle_Liquidator", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_kate", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Liquidator", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": -765, "y": 405 },
                "backgroundColor": "#736e5e",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Liquidator_E_White", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -801, "y": -216 },
                "backgroundColor": "#736e5e",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Liquidator_E_Obsidians", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -369, "y": -396 },
                "backgroundColor": "#736e5e",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#b8af97",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#736E5E"
    },
    slideConfig: {
        "frameColor": "#b8a776",
        "discount": null,
        "gradientColor": "#b8af97",
        "patternColor": "#b8af97",
        "backgroundColor": "#736e5e",
        "image": "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_art_Liquidator",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#736E5F",
        "detailsBgImageColor": "#B8B097",
        "detailsBgImage": "Sprites/Assets/Decor/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Liquidator", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_kate", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner302 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#b8af97" }, "backgroundColor": "#b8af97" },
        "title": { "alias": "gacha_title_Liquidator", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_promo_art_Liquidator_Gold",
        "description": [
            { "alias": "gacha_subtitle_Liquidator", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_kate", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Liquidator", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": 86, "y": 405 },
                "backgroundColor": "#736e5e",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Liquidator_E_Gold", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -801, "y": -216 },
                "backgroundColor": "#736e5e",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Liquidator_E_Obsidians", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -369, "y": -396 },
                "backgroundColor": "#736e5e",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#b8af97",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#736E5E"
    },
    slideConfig: {
        "frameColor": "#b8a776",
        "discount": null,
        "gradientColor": "#b8af97",
        "patternColor": "#b8af97",
        "backgroundColor": "#736e5e",
        "image": "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_art_Liquidator_Gold",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_1"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#736E5F",
        "detailsBgImageColor": "#B8B097",
        "detailsBgImage": "Sprites/Assets/Decor/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Liquidator", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_kate", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
