var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner1605", new GachaBanner({
    ID: 1605,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.GachaBanner1605.start,
            endGenerationBound: GachaBannerTimeConstants.GachaBanner1605.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 10, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    disableUniqueLootPriority: true,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.Midnight.ID] = 3, _c) }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 6, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Monk.ID] = 6, _d) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Bulwark.ID] = 6, _e) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Jet.ID] = 3, _f) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Sarge.ID] = 3, _g) }) } },
                { weight: 10, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Midnight.ID] = 2, _h) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Butcher.ID] = 2, _j) }) } },
                { weight: 6, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.June.ID] = 1, _k) }) } },
            ],
        },
        {
            weight: 1200, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_base_Rec_Red.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_Default_Rec_GoldenDark.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Xiang_Tzu_R_Default_Rec_Guard.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Viper_R_base_Rec_Purple.ID] }) } },
            ],
        },
        {
            weight: 1370, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Midnight_E_Assassin.ID] }) } },
                { weight: 2, reward: { loot: new Loot({ Skins: [skins.Midnight_R_Blue.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Midnight_E_ghost.ID] }) } },
                { weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Midnight_E_silence.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Sarge_R_hammer_flip.ID] }) } },
            ],
        },
        {
            weight: 3000, rewards: [
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _l) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _m) } } } },
                { weight: 15, reward: { lootSettings: { CardsSlots: { TotalCards: 8, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 8 }] }, _o) } } } },
                { weight: 12, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _p) } } } },
                { weight: 10, reward: { lootSettings: { CardsSlots: { TotalCards: 12, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 12 }] }, _q) } } } },
                { weight: 13, reward: { lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_r = {}, _r[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 3 }] }, _r) } } } },
                { weight: 15, reward: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 3000, _s) }) } },
                { weight: 10, reward: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 5000, _t) }) } },
                { weight: 2, reward: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 7500, _u) }) } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 10000, _v) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner1605,
}));
