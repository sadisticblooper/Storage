GachaBannerVisualConfig.visualPresets.banner1701 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#9175ff" }, "backgroundColor": "#9175ff" },
        "title": { "alias": "gacha_title_Lynx", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/20_Lynx/rift_promo_art_Lynx",
        "description": [
            { "alias": "gacha_subtitle_Lynx", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_lynx", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Lynx", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": 162, "y": 441 },
                "backgroundColor": "#433f8a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Lynx_E_Original", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -801, "y": -225 },
                "backgroundColor": "#433f8a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Lynx_E_Legacy", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -262, "y": -396 },
                "backgroundColor": "#433f8a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#6c44b8",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#3d2073"
    },
    slideConfig: {
        "frameColor": "#6854b8",
        "discount": null,
        "gradientColor": "#6c47ff",
        "patternColor": "#6c47ff",
        "backgroundColor": "#312073",
        "image": "Sprites/PreviewImages/RiftImages/20_Lynx/rift_art_Lynx",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#3d2073",
        "detailsBgImageColor": "#a38cff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_05",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Lynx", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_lynx", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner1704 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#9175ff" }, "backgroundColor": "#9175ff" },
        "title": { "alias": "gacha_title_Lynx", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/20_Lynx/rift_promo_art_Lynx_E_Mafia",
        "description": [
            { "alias": "gacha_subtitle_Lynx", "color": "rgba(255,255,255,0.72)" },
            { "alias": "gacha_10roll_lynx", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Lynx", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": 162, "y": 441 },
                "backgroundColor": "#433f8a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Lynx_E_Mafia", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -801, "y": -225 },
                "backgroundColor": "#433f8a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Lynx_E_Legacy", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -262, "y": -396 },
                "backgroundColor": "#433f8a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#6c44b8",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#3d2073"
    },
    slideConfig: {
        "frameColor": "#6854b8",
        "discount": null,
        "gradientColor": "#6c47ff",
        "patternColor": "#6c47ff",
        "backgroundColor": "#312073",
        "image": "Sprites/PreviewImages/RiftImages/20_Lynx/rift_art_Lynx_E_Mafia",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#3d2073",
        "detailsBgImageColor": "#a38cff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_05",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Lynx", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_lynx", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
