GachaBannerVisualConfig.visualPresets.banner502 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#ff811a" }, "backgroundColor": "#ff811a" },
        "title": { "alias": "gacha_title_Fireguard", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_promo_art_Fireguard_23",
        "description": [
            { "alias": "gacha_subtitle_Fireguard", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_fireguard", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Fireguard", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": -3, "y": 486 },
                "backgroundColor": "#A15110",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Fireguard_E_White", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -627, "y": -252 },
                "backgroundColor": "#A15110",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Fireguard_E_Bones", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -400, "y": -390 },
                "backgroundColor": "#A15110",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#ff811a",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#8a4c1a"
    },
    slideConfig: {
        "frameColor": "#cf7327",
        "discount": null,
        "gradientColor": "#b88154",
        "patternColor": "#b86f33",
        "backgroundColor": "#734520",
        "image": "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_art_Fireguard_23",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#734520",
        "detailsBgImageColor": "#ff7e47",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_05",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Fireguard", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_fireguard", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner504 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#ff811a" }, "backgroundColor": "#ff811a" },
        "title": { "alias": "gacha_title_Fireguard", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_promo_art_Fireguard_E_Cyber",
        "description": [
            { "alias": "gacha_subtitle_Fireguard", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_fireguard", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Fireguard", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": -3, "y": 395 },
                "backgroundColor": "#A15110",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Fireguard_E_Cyber", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -620, "y": -200 },
                "backgroundColor": "#A15110",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Fireguard_E_Bones", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -400, "y": -390 },
                "backgroundColor": "#A15110",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#ff811a",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#8a4c1a"
    },
    slideConfig: {
        "frameColor": "#cf7327",
        "discount": null,
        "gradientColor": "#b88154",
        "patternColor": "#b86f33",
        "backgroundColor": "#734520",
        "image": "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_art_Fireguard_E_Cyber",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#734520",
        "detailsBgImageColor": "#ff7e47",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_05",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Fireguard", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_fireguard", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
