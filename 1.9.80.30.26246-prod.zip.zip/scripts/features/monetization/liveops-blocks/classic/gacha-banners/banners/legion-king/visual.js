GachaBannerVisualConfig.visualPresets.banner2003 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#a3ffe3" },
            "backgroundColor": "#a3ffe3"
        },
        "title": { "alias": "gacha_title_LegionKing", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_promo_art_LegionKing",
        "description": [
            { "alias": "gacha_subtitle_LegionKing", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_king_of_the_legion", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Legion_King", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "legendary", "color": "#ffd75e" },
                    "label2": null
                },
                "coordinates": { "x": -747, "y": -150 },
                "backgroundColor": "#3f8a73",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Legion_King_E_Bone", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -85, "y": 460 },
                "backgroundColor": "#3f8a73",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Legion_King_E_Witchblade", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#C68CFFB8" }
                },
                "coordinates": { "x": -360, "y": -330 },
                "backgroundColor": "#3f8a73",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#76b8a4",
        "lastMilestoneColor": "#ffd75e",
        "gradientBgColor": "#588a7b"
    },
    slideConfig: {
        "frameColor": "#588a7b",
        "discount": null,
        "gradientColor": "#76b8a4",
        "patternColor": "#337d8a",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_art_LegionKing",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_8"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#497366",
        "detailsBgImageColor": "#76b8a4",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_8",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    {
                        "alias": "gacha_contains_LegionKing",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [
                    { "alias": "gacha_10roll_king_of_the_legion", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner2005 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#a3ffe3" },
            "backgroundColor": "#a3ffe3"
        },
        "title": { "alias": "gacha_title_LegionKing", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_promo_art_LegionKing_Prince",
        "description": [
            { "alias": "gacha_subtitle_LegionKing", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_king_of_the_legion", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Legion_King", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "legendary", "color": "#ffd75e" },
                    "label2": { "alias": "rarity_other", "color": "#ffd75eB8" }
                },
                "coordinates": { "x": -450, "y": -400 },
                "backgroundColor": "#3f8a73",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Legion_King_E_Prince", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -600, "y": -200 },
                "backgroundColor": "#3f8a73",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Legion_King_E_Abyssblade", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": 110, "y": 240 },
                "backgroundColor": "#3f8a73",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#76b8a4",
        "lastMilestoneColor": "#ffd75e",
        "gradientBgColor": "#588a7b"
    },
    slideConfig: {
        "frameColor": "#588a7b",
        "discount": null,
        "gradientColor": "#76b8a4",
        "patternColor": "#337d8a",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_art_LegionKing_Prince",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_8"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#497366",
        "detailsBgImageColor": "#76b8a4",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_8",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    {
                        "alias": "gacha_contains_LegionKing",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_king_of_the_legion", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
