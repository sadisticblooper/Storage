CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner785", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner802,
    replaceConfig: {
        ID: 785,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner785.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner785.end,
            },
            sellHeroSettings: {
                heroId: heroes.Feldsher.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner804,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_E_RedVampire.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_SpicyBlade.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_base_Rec_Elegant.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_Gold_Rec_Bronze.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_SpicyBlade_Rec_Star.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Feldsher_E_Plague.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Feldsher_R_Rusty_skin.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Feldsher_R_hat_off.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Taunts: [taunts.Feldsher_E_respect.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.stance_Feldsher_R_polearm_swing.ID] }) } },
            ]
        }
    ],
}));
