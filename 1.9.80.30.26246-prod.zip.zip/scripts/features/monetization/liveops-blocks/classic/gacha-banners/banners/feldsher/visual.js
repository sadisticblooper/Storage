GachaBannerVisualConfig.visualPresets.banner802 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#b1a9cf" },
            "backgroundColor": "#b1a9cf"
        },
        "title": { "alias": "gacha_title_Feldsher", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_promo_art_Feldsher",
        "description": [
            { "alias": "gacha_subtitle_Feldsher", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_azuma", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Feldsher", "color": "#fff" },
                "description": {
                    "label1": { "alias": "common", "color": "#97aeb8" },
                    "label2": null
                },
                "coordinates": { "x": -801, "y": 216 },
                "backgroundColor": "#5a5473",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Feldsher_E_Suit", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -720, "y": -264 },
                "backgroundColor": "#5a5473",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Feldsher_E_RedVampire", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#c68cffb8" }
                },
                "coordinates": { "x": -227, "y": -420 },
                "backgroundColor": "#5a5473",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#9086b8",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#6c658a"
    },
    slideConfig: {
        "frameColor": "#5a5473",
        "discount": null,
        "gradientColor": "#7665b8",
        "patternColor": "#c8baff",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_art_Feldsher",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_10"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#5a5473",
        "detailsBgImageColor": "#a38cff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_10",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    {
                        "alias": "gacha_contains_Feldsher",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [
                    { "alias": "gacha_10roll_azuma", "color": "rgba(255,255,255,0.81)" }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
GachaBannerVisualConfig.visualPresets.banner804 = {
    viewConfig: {
        "subTitle": {
            "label": { "alias": "gacha_label_hero_event", "color": "#b1a9cf" },
            "backgroundColor": "#b1a9cf"
        },
        "title": { "alias": "gacha_title_Feldsher", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_promo_art_Feldsher_Plague",
        "description": [
            { "alias": "gacha_subtitle_Feldsher", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_azuma", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Feldsher", "color": "#fff" },
                "description": {
                    "label1": { "alias": "common", "color": "#97aeb8" },
                    "label2": null
                },
                "coordinates": { "x": 100, "y": 390 },
                "backgroundColor": "#5a5473",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Feldsher_E_Plague", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" },
                    "label2": null
                },
                "coordinates": { "x": -606, "y": -220 },
                "backgroundColor": "#5a5473",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Feldsher_E_RedVampire", "color": "#ffffff" },
                "description": {
                    "label1": { "alias": "epic", "color": "#c68cff" },
                    "label2": { "alias": "rarity_other", "color": "#c68cffb8" }
                },
                "coordinates": { "x": -227, "y": -383 },
                "backgroundColor": "#5a5473",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#9086b8",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#6c658a"
    },
    slideConfig: {
        "frameColor": "#5a5473",
        "discount": null,
        "gradientColor": "#7665b8",
        "patternColor": "#c8baff",
        "backgroundColor": "#8a6227",
        "image": "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_art_Feldsher_Plague",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_10"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#5a5473",
        "detailsBgImageColor": "#a38cff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_10",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [
                    {
                        "alias": "gacha_contains_Feldsher",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_azuma", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "rgba(255,255,255,0.81)"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
