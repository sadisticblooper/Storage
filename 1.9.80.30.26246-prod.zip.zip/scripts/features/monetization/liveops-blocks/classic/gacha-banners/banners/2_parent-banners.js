var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33;
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner16", new GachaBanner({
    ID: 16,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_a = {}, _a[CURRENCY.GACHA_KEY] = 2, _a)
    },
    multipleRoll: {
        discount: 0,
        price: (_b = {}, _b[CURRENCY.GACHA_KEY] = 20, _b),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_c = {}, _c[heroes.Kibo.ID] = 10, _c) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_d = {}, _d[heroes.Bulwark.ID] = 10, _d) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_e = {}, _e[heroes.Fireguard.ID] = 10, _e) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_f = {}, _f[heroes.Ironclad.ID] = 10, _f) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_g = {}, _g[heroes.Liquidator.ID] = 10, _g) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_h = {}, _h[heroes.Monk.ID] = 10, _h) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_j = {}, _j[heroes.Midnight.ID] = 10, _j) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_k = {}, _k[heroes.Lynx.ID] = 10, _k) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_E_Druid.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_base_Rec_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_Rich.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Fireguard_R_Simplified.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_R_Paladin_Rec_Blue.ID] }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Kibo_E_Gray_skin.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Kibo_E_Oriental_skin.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Kibo_R_Rose_skin.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Kibo_E_mind_slash.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_E_absorb_energy.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_R_pull_out_spin.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Kibo_R_brutal.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.Kibo_E_force_supremacy.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_R_fient.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Kibo_E_bandage.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _l) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _m) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _o) } } } },
                { weight: 3, reward: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 4000, _p) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner16,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner20", new GachaBanner({
    ID: 20,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_q = {}, _q[CURRENCY.GACHA_KEY] = 2, _q)
    },
    multipleRoll: {
        discount: 0,
        price: (_r = {}, _r[CURRENCY.GACHA_KEY] = 20, _r),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_s = {}, _s[heroes.Lynx.ID] = 10, _s) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_t = {}, _t[heroes.Bulwark.ID] = 10, _t) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_u = {}, _u[heroes.Fireguard.ID] = 10, _u) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_v = {}, _v[heroes.Ironclad.ID] = 10, _v) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_w = {}, _w[heroes.Liquidator.ID] = 10, _w) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_x = {}, _x[heroes.Monk.ID] = 10, _x) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_y = {}, _y[heroes.Midnight.ID] = 10, _y) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_z = {}, _z[heroes.Kibo.ID] = 10, _z) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_E_Legacy.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_E_Shadow_Edge.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_base_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_Rich.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_R_Default_Rec_Blue.ID] }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Lynx_R_base_Rec_Fancy.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Marcus_R_Winy_skin.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Lynx_E_claws_release.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Lynx_E_smoke.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Ironclad_E_kicked_out.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Ling_R_restore.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_yawn.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Butcher_R_bully.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Lynx_R_Claws_sparks.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 250, TotalSlots: 1, Rarities: (_0 = {}, _0[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 250 }] }, _0) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 50, TotalSlots: 1, Rarities: (_1 = {}, _1[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 50 }] }, _1) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_2 = {}, _2[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _2) } } } },
                { weight: 3, reward: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.COIN] = 4000, _3) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner20,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner24", new GachaBanner({
    ID: 24,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_4 = {}, _4[CURRENCY.GACHA_KEY] = 3, _4)
    },
    multipleRoll: {
        discount: 0,
        price: (_5 = {}, _5[CURRENCY.GACHA_KEY] = 30, _5),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_6 = {}, _6[heroes.Legion_King.ID] = 10, _6) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 4, reward: { loot: new Loot({ Shards: (_7 = {}, _7[heroes.Ironclad.ID] = 10, _7) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_8 = {}, _8[heroes.Liquidator.ID] = 10, _8) }) } },
                { weight: 4, reward: { loot: new Loot({ Shards: (_9 = {}, _9[heroes.Monk.ID] = 10, _9) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_10 = {}, _10[heroes.Kibo.ID] = 10, _10) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_11 = {}, _11[heroes.Midnight.ID] = 10, _11) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_12 = {}, _12[heroes.Viper.ID] = 10, _12) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_13 = {}, _13[heroes.HongJoo.ID] = 10, _13) }) } },
                { weight: 2, reward: { loot: new Loot({ Shards: (_14 = {}, _14[heroes.Jet.ID] = 10, _14) }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_E_Legacy.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_Rich.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_R_base_Rec_Silver.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_R_Gray_Rec_Purple.ID] }) } },
                { weight: 4, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_SpicyBlade.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Helga_E_White_Star.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_HongJoo_E_FireShow.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 3, reward: { loot: new Loot({ Skins: [skins.Legion_King_R_Viny.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.stance_Legion_King_R_sword_up.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Feldsher_E_Suit_skin.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Yukka_R_Red.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Monk_E_Cursed.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Legion_King_E_Bone.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Stances: [stances.win_Legion_King_E_Army.ID] }) } },
                { weight: 6, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_rage.ID] }) } },
            ],
        },
        {
            weight: 25, rewards: [
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 600, TotalSlots: 1, Rarities: (_15 = {}, _15[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 600 }] }, _15) } } } },
                { weight: 7, reward: { lootSettings: { CardsSlots: { TotalCards: 120, TotalSlots: 1, Rarities: (_16 = {}, _16[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 120 }] }, _16) } } } },
                { weight: 5, reward: { lootSettings: { CardsSlots: { TotalCards: 25, TotalSlots: 1, Rarities: (_17 = {}, _17[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 25 }] }, _17) } } } },
                { weight: 3, reward: { lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_18 = {}, _18[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _18) } } } },
                { weight: 8, reward: { loot: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.COIN] = 9000, _19) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner24,
}));
CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner55", new GachaBanner({
    ID: 55,
    promoSettings: {
        conditions: {},
        activeTime: {
            startGenerationBound: GachaBannerTimeConstants.default.start,
            endGenerationBound: GachaBannerTimeConstants.default.end,
        },
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.GACHA,
        },
    },
    totalNumberOfRolls: 0,
    singleRoll: {
        price: (_20 = {}, _20[CURRENCY.GACHA_KEY] = 2, _20)
    },
    multipleRoll: {
        discount: 0,
        price: (_21 = {}, _21[CURRENCY.GACHA_KEY] = 20, _21),
        rollQuantity: 10,
    },
    weightForSlider: 10,
    bannerGroupRewards: [
        {
            weight: 1, rewards: [
                { weight: 1, reward: { loot: new Loot({ Shards: (_22 = {}, _22[heroes.Butcher.ID] = 10, _22) }) } },
            ],
        },
        {
            weight: 10, rewards: [
                { weight: 5, reward: { loot: new Loot({ Shards: (_23 = {}, _23[heroes.Bulwark.ID] = 10, _23) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_24 = {}, _24[heroes.Fireguard.ID] = 10, _24) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_25 = {}, _25[heroes.Ironclad.ID] = 10, _25) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_26 = {}, _26[heroes.Liquidator.ID] = 10, _26) }) } },
                { weight: 5, reward: { loot: new Loot({ Shards: (_27 = {}, _27[heroes.Monk.ID] = 10, _27) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_28 = {}, _28[heroes.Midnight.ID] = 10, _28) }) } },
                { weight: 1, reward: { loot: new Loot({ Shards: (_29 = {}, _29[heroes.Kibo.ID] = 10, _29) }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_E_Pike.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_base_Black.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_R_Rich.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_R_Default_Rec_Blue.ID] }) } },
            ],
        },
        {
            weight: 30, rewards: [
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Butcher_R_Purple.ID] }) } },
                { weight: 1, reward: { loot: new Loot({ Skins: [skins.Butcher_E_Mogwai.ID] }) } },
                { weight: 5, reward: { loot: new Loot({ Skins: [skins.Monk_R_Blue.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Feldsher_R_hat_off.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Butcher_E_cage_warrior.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.stance_Ironclad_E_kicked_out.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Stances: [stances.win_Ling_R_restore.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.win_Helga_R_paladin_respect.ID] }) } },
                { weight: 20, reward: { loot: new Loot({ Stances: [stances.stance_Butcher_R_bully.ID] }) } },
                { weight: 10, reward: { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_what.ID] }) } },
            ],
        },
        {
            weight: 40, rewards: [
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 150, TotalSlots: 1, Rarities: (_30 = {}, _30[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 150 }] }, _30) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_31 = {}, _31[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 30 }] }, _31) } } } },
                { weight: 1, reward: { lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_32 = {}, _32[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 6 }] }, _32) } } } },
                { weight: 1, reward: { loot: new Loot({ Currencies: (_33 = {}, _33[CURRENCY.COIN] = 2500, _33) }) } },
            ],
        },
    ],
    additionalBannerSettings: {
        guarantee: {
            rollsNumber: 10,
            consistentRewardGroupIndex: 0,
        }
    },
    visualPreset: GachaBannerVisualConfig.visualPresets.banner55,
}));
