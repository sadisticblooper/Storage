GachaBannerVisualConfig.visualPresets.banner2402 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#baf5ff" }, "backgroundColor": "#baf5ff" },
        "title": { "alias": "gacha_title_Yunlin", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/28_Yunlin/rift_promo_art_Yunlin",
        "description": [
            { "alias": "gacha_subtitle_Yunlin", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_yunlin", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Yunlin", "color": "#fff" },
                "description": { "label1": { "alias": "rare", "color": "#8cbaff" }, "label2": null },
                "coordinates": { "x": 0, "y": 405 },
                "backgroundColor": "#3f688a",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Yunlin_E_Bride", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -660, "y": -216 },
                "backgroundColor": "#3f688a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_YunLin_E_Golden_Red_Alias", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -359, "y": -396 },
                "backgroundColor": "#3f688a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#6aaee5",
        "lastMilestoneColor": "#8cbaff",
        "gradientBgColor": "#2a5273"
    },
    slideConfig: {
        "frameColor": "#8cddff",
        "discount": null,
        "gradientColor": "#8cddff",
        "patternColor": "#baf5ff",
        "backgroundColor": "#2a5273",
        "image": "Sprites/PreviewImages/RiftImages/28_Yunlin/rift_art_Yunlin",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#2a5273",
        "detailsBgImageColor": "#baf5ff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Yunlin", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_yunlin", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
