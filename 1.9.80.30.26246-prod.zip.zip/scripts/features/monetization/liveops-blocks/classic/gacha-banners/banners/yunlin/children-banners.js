CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner779", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner2402,
    replaceConfig: {
        ID: 779,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner779.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner779.end,
            },
            sellHeroSettings: {
                heroId: heroes.Yunlin.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
    },
}));
