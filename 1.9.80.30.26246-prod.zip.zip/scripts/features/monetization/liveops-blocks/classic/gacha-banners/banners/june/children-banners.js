CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner778", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner2602,
    replaceConfig: {
        ID: 778,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner778.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner778.end,
            },
            sellHeroSettings: {
                heroId: heroes.June.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
    },
}));
