CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner777", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner2701,
    replaceConfig: {
        ID: 777,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner777.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner777.end,
            },
            sellHeroSettings: {
                heroId: heroes.Gideon.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
    },
}));
