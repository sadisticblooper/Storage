CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner787", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner704,
    replaceConfig: {
        ID: 787,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner787.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner787.end,
            },
            sellHeroSettings: {
                heroId: heroes.Jet.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner705,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_base_Rec_Brown.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Jet_R_Golden_Rec_Black.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Sarge_R_Patterns_Rec_Red.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Jet_E_Nomad.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Butcher_R_Purple.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Jet_E_Hammock.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Jet_E_pretty_nails.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Jet_R_swing_look.ID] }) } },
            ]
        }
    ],
}));
