CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner782", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner1605,
    replaceConfig: {
        ID: 782,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner782.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner782.end,
            },
            sellHeroSettings: {
                heroId: heroes.Midnight.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
        visualPreset: GachaBannerVisualConfig.visualPresets.banner1603,
    },
    rewardReplacer: [
        {
            rewardIndex: 2,
            weight: 1200,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } },
                { rewardIndex: 1, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_base_Rec_Red.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_R_Default_Rec_GoldenDark.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Marcus_R_Lord_Rec_Brown.ID] }) } },
                { rewardIndex: 4, weight: 3, reward: { loot: new Loot({ Weapons: [heroWeapons.wpn_Yukka_R_Monograms.ID] }) } },
            ]
        },
        {
            rewardIndex: 3,
            weight: 1370,
            items: [
                { rewardIndex: 0, weight: 1, reward: { loot: new Loot({ Skins: [skins.Midnight_E_Witch.ID] }) } },
                { rewardIndex: 1, weight: 2, reward: { loot: new Loot({ Skins: [skins.Midnight_R_Blue.ID] }) } },
                { rewardIndex: 2, weight: 3, reward: { loot: new Loot({ Stances: [stances.win_Midnight_E_mark.ID] }) } },
                { rewardIndex: 3, weight: 3, reward: { loot: new Loot({ Stances: [stances.stance_Midnight_R_ninja.ID] }) } },
                { rewardIndex: 4, weight: 5, reward: { loot: new Loot({ Stances: [stances.win_Jet_R_swing_look.ID] }) } },
            ]
        }
    ],
}));
