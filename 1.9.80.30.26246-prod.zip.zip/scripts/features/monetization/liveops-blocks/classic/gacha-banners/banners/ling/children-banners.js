CommonUtils.addObjectAndCheckReplace(gachaBanners, "banner783", GachaBannerUtils.reuseGacha({
    origin: gachaBanners.banner101,
    replaceConfig: {
        ID: 783,
        promoSettings: {
            conditions: {},
            activeTime: {
                startGenerationBound: GachaBannerTimeConstants.GachaBanner783.start,
                endGenerationBound: GachaBannerTimeConstants.GachaBanner783.end,
            },
            sellHeroSettings: {
                heroId: heroes.Ling.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.GACHA
            },
        },
    },
}));
