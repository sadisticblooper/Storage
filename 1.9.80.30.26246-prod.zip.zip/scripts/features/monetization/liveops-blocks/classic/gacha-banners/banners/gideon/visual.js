GachaBannerVisualConfig.visualPresets.banner2701 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#75acff" }, "backgroundColor": "#75acff" },
        "title": { "alias": "gacha_title_Gideon", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/30_Gideon/rift_promo_art_Gideon",
        "description": [
            { "alias": "gacha_subtitle_Gideon", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_gideon", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Gideon", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": 45, "y": 405 },
                "backgroundColor": "#33568a",
                "isHighChance": false
            },
            {
                "title": { "alias": "skin_hero_Gideon_E_Mask", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -712, "y": -157 },
                "backgroundColor": "#33568a",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Gideon_E_Fiery_name", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -445, "y": -370 },
                "backgroundColor": "#33568a",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#5e9fff",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#33568a"
    },
    slideConfig: {
        "frameColor": "#5e9fff",
        "discount": null,
        "gradientColor": "#8cddff",
        "patternColor": "#a3c8ff",
        "backgroundColor": "#22395c",
        "image": "Sprites/PreviewImages/RiftImages/30_Gideon/rift_art_Gideon",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_5"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#33568a",
        "detailsBgImageColor": "#5e9fff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_05",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Gideon", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_gideon", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "#ffffffce" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "#ffffffce" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
