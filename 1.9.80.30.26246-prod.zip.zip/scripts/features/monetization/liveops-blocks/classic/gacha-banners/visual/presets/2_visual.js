GachaBannerVisualConfig.visualPresets.banner11 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#FF7E47" }, backgroundColor: "#FF7E47" },
        title: { alias: "gacha_title_MonkeyKing", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/11_MonkeyKing/rift_promo_art_MonkeyKing",
        description: [
            { alias: "gacha_subtitle_MonkeyKing", color: "#ffffffb7" },
            { alias: "gacha_10roll_legendary", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Monkey_King", color: "#fff" },
                description: { label1: { alias: "legendary", color: "#ffd75e" }, label2: null, },
                coordinates: { x: -54, y: 387, },
                backgroundColor: "#8a4427",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_monkeyking_E_stranger", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -801, y: -171, },
                backgroundColor: "#8a4427",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Monkey_King_E_Nephritis", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -216, y: -387, },
                backgroundColor: "#8a4427",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff5e1a",
        lastMilestoneColor: "#ffd75e",
        gradientBgColor: "#733920",
    },
    slideConfig: {
        frameColor: "#e57240",
        discount: null,
        gradientColor: "#B85B33",
        patternColor: "#b85b33",
        backgroundColor: "#733920",
        image: "Sprites/PreviewImages/RiftImages/11_MonkeyKing/rift_art_MonkeyKing",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_8",
    },
    detailsConfig: {
        detailsGradientBgColor: "#733920",
        detailsBgImageColor: "#ff9f75",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_8",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_MonkeyKing", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_legendary", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner12 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#47FFFF" }, backgroundColor: "#47FFFF" },
        title: { alias: "gacha_title_Monk", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/12_Shang/rift_promo_art_Shang",
        description: [
            { alias: "gacha_subtitle_Monk", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Monk", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: -783, y: 162, },
                backgroundColor: "#2a7373",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Monk_E_Cursed", color: "#fff" },
                description: { label1: { alias: "rarity_season", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -690, y: -225, },
                backgroundColor: "#2a7373",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Monk_E_Druid", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -162, y: -384, },
                backgroundColor: "#2a7373",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#11A1A1",
        lastMilestoneColor: "#97AEB8",
        gradientBgColor: "#206673",
    },
    slideConfig: {
        frameColor: "#33b8b8",
        discount: null,
        gradientColor: "#54b8b8",
        patternColor: "#33b8b8",
        backgroundColor: "#207373",
        image: "Sprites/PreviewImages/RiftImages/12_Shang/rift_art_Shang",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_8",
    },
    detailsConfig: {
        detailsGradientBgColor: "#207373",
        detailsBgImageColor: "#47ffff",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_8",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Monk", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner13 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#a575ff" }, backgroundColor: "#a575ff" },
        title: { alias: "gacha_title_Midnight", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/13_Midnight/rift_promo_art_Midnight",
        description: [
            { alias: "gacha_subtitle_Midnight", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Midnight", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -756, y: -189, },
                backgroundColor: "#49278a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Midnight_E_Ghost", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -198, y: -396, },
                backgroundColor: "#49278a",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Midnight_R_base_Rec_Red", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -45, y: 414, },
                backgroundColor: "#49278a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#8847ff",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#3d2073",
    },
    slideConfig: {
        frameColor: "#8265b8",
        discount: null,
        gradientColor: "#8847ff",
        patternColor: "#8847ff",
        backgroundColor: "#3d2073",
        image: "Sprites/PreviewImages/RiftImages/13_Midnight/rift_art_Midnight",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_2",
    },
    detailsConfig: {
        detailsGradientBgColor: "#3D2073",
        detailsBgImageColor: "#A575FF",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_02",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Midnight", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner14 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ffbf5e" }, backgroundColor: "#ffbf5e" },
        title: { alias: "gacha_title_Ling", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/14_Ling/rift_promo_art_Ling",
        description: [
            { alias: "gacha_subtitle_Ling", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Ling", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -639, y: 450, },
                backgroundColor: "#a1783b",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Ling_R_Gold", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -792, y: -225, },
                backgroundColor: "#a1783b",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Ling_R_RedBlade", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -306, y: -369, },
                backgroundColor: "#a1783b",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ffb647",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#8a580e",
    },
    slideConfig: {
        frameColor: "#ffb647",
        discount: null,
        gradientColor: "#ffbf5e",
        patternColor: "#ffb647",
        backgroundColor: "#8a6227",
        image: "Sprites/PreviewImages/RiftImages/14_Ling/rift_art_Ling",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_9",
    },
    detailsConfig: {
        detailsGradientBgColor: "#73562A",
        detailsBgImageColor: "#FFBF5E",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Ling", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner15 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff4747" }, backgroundColor: "#ff4747" },
        title: { alias: "gacha_title_Sarge", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/15_Sarge/rift_promo_art_Sarge",
        description: [
            { alias: "gacha_subtitle_Sarge", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Sarge", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -711, y: 363, },
                backgroundColor: "#8a2727",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Sarge_R_dark", color: "#fff" },
                description: { label1: { alias: "Rare_skin_tooltip_alias", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -777, y: -231, },
                backgroundColor: "#8a2727",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Sarge_R_Patterns", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -114, y: -387, },
                backgroundColor: "#8a2727",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff4848",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#732020",
    },
    slideConfig: {
        frameColor: "#b83333",
        discount: null,
        gradientColor: "#b85454",
        patternColor: "#b83333",
        backgroundColor: "#732020",
        image: "Sprites/PreviewImages/RiftImages/15_Sarge/rift_art_Sarge",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_2",
    },
    detailsConfig: {
        detailsGradientBgColor: "#732020",
        detailsBgImageColor: "#b83333",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_02",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Sarge", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner16 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#7598ff" }, backgroundColor: "#7598ff" },
        title: { alias: "gacha_title_Kibo", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/16_Kibo/rift_promo_art_Kibo",
        description: [
            { alias: "gacha_subtitle_Kibo", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Kibo", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -660, y: 450, },
                backgroundColor: "#273f8a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Kibo_E_Gray", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -771, y: -162, },
                backgroundColor: "#273f8a",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Kibo_E_RedVampire", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -255, y: -396, },
                backgroundColor: "#273f8a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#4775ff",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#203573",
    },
    slideConfig: {
        frameColor: "#657ab8",
        discount: null,
        gradientColor: "#4775ff",
        patternColor: "#4775ff",
        backgroundColor: "#203573",
        image: "Sprites/PreviewImages/RiftImages/16_Kibo/rift_art_Kibo",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#203573",
        detailsBgImageColor: "#4775ff",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Kibo", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner17 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff5e1a" }, backgroundColor: "#ff5e1a" },
        title: { alias: "gacha_title_Ironclad", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/17_Ironclad/rift_promo_art_Ironclad",
        description: [
            { alias: "gacha_subtitle_Ironclad", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Ironclad", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: -93, y: 486, },
                backgroundColor: "#8A3C1A",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Ironclad_E_Rust", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -777, y: -252, },
                backgroundColor: "#8A3C1A",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Ironclad_R_Pattern", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -234, y: -387, },
                backgroundColor: "#8A3C1A",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff5e1a",
        lastMilestoneColor: "#97aeb8",
        gradientBgColor: "#8a3c1a",
    },
    slideConfig: {
        frameColor: "#cf5927",
        discount: null,
        gradientColor: "#b87254",
        patternColor: "#b85b33",
        backgroundColor: "#733920",
        image: "Sprites/PreviewImages/RiftImages/17_Ironclad/rift_art_Ironclad",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_4",
    },
    detailsConfig: {
        detailsGradientBgColor: "#733920",
        detailsBgImageColor: "#b85b33",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_04",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Ironclad", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner18 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#fff8ba" }, backgroundColor: "#fff8ba" },
        title: { alias: "gacha_title_Helga", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/18_Helga/rift_promo_art_Helga",
        description: [
            { alias: "gacha_subtitle_Helga", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Helga", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -720, y: 369, },
                backgroundColor: "#8a8558",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Helga_E_Paladin", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -810, y: -171, },
                backgroundColor: "#8a8558",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Helga_R_December", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -198, y: -369, },
                backgroundColor: "#8a8558",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#fff8ba",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#73612a",
    },
    slideConfig: {
        frameColor: "#fff8ba",
        discount: null,
        gradientColor: "#ffd75e",
        patternColor: "#fff8ba",
        backgroundColor: "#4b575c",
        image: "Sprites/PreviewImages/RiftImages/18_Helga/rift_art_Helga",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_9",
    },
    detailsConfig: {
        detailsGradientBgColor: "#73612a",
        detailsBgImageColor: "#fff8ba",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Helga", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner19 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#b1a9cf" }, backgroundColor: "#b1a9cf" },
        title: { alias: "gacha_title_Feldsher", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_promo_art_Feldsher",
        description: [
            { alias: "gacha_subtitle_Feldsher", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Feldsher", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: -801, y: 216, },
                backgroundColor: "#5a5473",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Feldsher_E_Suit", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -738, y: -324, },
                backgroundColor: "#5a5473",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Feldsher_R_SpicyBlade", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -36, y: -432, },
                backgroundColor: "#5a5473",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#9086b8",
        lastMilestoneColor: "#97aeb8",
        gradientBgColor: "#6c658a",
    },
    slideConfig: {
        frameColor: "#5a5473",
        discount: null,
        gradientColor: "#7665b8",
        patternColor: "#c8baff",
        backgroundColor: "#8a6227",
        image: "Sprites/PreviewImages/RiftImages/19_Feldsher/rift_art_Feldsher",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_10",
    },
    detailsConfig: {
        detailsGradientBgColor: "#5a5473",
        detailsBgImageColor: "#a38cff",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_10",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Feldsher", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner20 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#9175ff" }, backgroundColor: "#9175ff" },
        title: { alias: "gacha_title_Lynx", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/20_Lynx/rift_promo_art_Lynx",
        description: [
            { alias: "gacha_subtitle_Lynx", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Lynx", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: 162, y: 441, },
                backgroundColor: "#433f8a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Lynx_E_Original", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -801, y: -225, },
                backgroundColor: "#433f8a",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Lynx_E_Legacy", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -262, y: -396, },
                backgroundColor: "#433f8a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#6c44b8",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#3d2073",
    },
    slideConfig: {
        frameColor: "#6854b8",
        discount: null,
        gradientColor: "#6c47ff",
        patternColor: "#6c47ff",
        backgroundColor: "#312073",
        image: "Sprites/PreviewImages/RiftImages/20_Lynx/rift_art_Lynx",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_5",
    },
    detailsConfig: {
        detailsGradientBgColor: "#3d2073",
        detailsBgImageColor: "#a38cff",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_05",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Lynx", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
