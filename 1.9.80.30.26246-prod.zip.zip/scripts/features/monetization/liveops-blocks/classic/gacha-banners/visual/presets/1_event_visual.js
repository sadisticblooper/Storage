GachaBannerVisualConfig.visualPresets.banner5000eventFire = {
    viewConfig: {
        "subTitle": {
            "label": {
                "alias": "gacha_label_event",
                "color": "#a575ff"
            },
            "backgroundColor": "#a575ff"
        },
        "title": {
            "alias": "gacha_title_cyberweek",
            "color": "#ffffff"
        },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/Cyberweek/rift_promo_art_cyberweek",
        "description": [
            {
                "alias": "gacha_subtitle_cyberweek",
                "color": "#ffffffb7"
            },
            {
                "alias": "gacha_10roll_Fireguard_2",
                "color": "#e5c493"
            }
        ],
        "rewards": [
            {
                "title": {
                    "alias": "skin_hero_Fireguard_E_Cyber",
                    "color": "#ffffff"
                },
                "description": {
                    "label1": {
                        "alias": "Season_skin_tooltip_alias",
                        "color": "#ff765e"
                    },
                    "label2": null
                },
                "coordinates": {
                    "x": -730,
                    "y": -237
                },
                "backgroundColor": "#2F1945BF",
                "isHighChance": false
            },
            {
                "title": {
                    "alias": "skin_hero_Fireguard_E_White",
                    "color": "#ffffff"
                },
                "description": {
                    "label1": {
                        "alias": "Season_skin_tooltip_alias",
                        "color": "#ff765e"
                    },
                    "label2": null
                },
                "coordinates": {
                    "x": -318,
                    "y": -356
                },
                "backgroundColor": "#2F1945BF",
                "isHighChance": false
            },
            {
                "title": {
                    "alias": "skin_hero_Fireguard_E_Porcelain",
                    "color": "#ffffff"
                },
                "description": {
                    "label1": {
                        "alias": "Epic_skin_tooltip_alias",
                        "color": "#c68cff"
                    },
                    "label2": null
                },
                "coordinates": {
                    "x": 97,
                    "y": -307
                },
                "backgroundColor": "#2F1945BF",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#00ffbb",
        "lastMilestoneColor": "#c68cff",
        "gradientBgColor": "#390073"
    },
    slideConfig: {
        "frameColor": "#c68cff",
        "discount": null,
        "gradientColor": "#c68cff",
        "patternColor": "#5ee7ff",
        "backgroundColor": "#593f73",
        "image": "Sprites/PreviewImages/RiftImages/Cyberweek/rift_art_cyberweek",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_9"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#593f73",
        "detailsBgImageColor": "#c68cff",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_9",
        "blocks": [
            {
                "header": {
                    "alias": "gacha_rule_title",
                    "color": "#e5c493"
                },
                "description": [
                    {
                        "alias": "gacha_rule_event",
                        "color": "#ffffff"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_contains_title_1",
                    "color": "#ffffff"
                },
                "description": [
                    {
                        "alias": "gacha_contains_Fireguard_2_cyber",
                        "color": "#ffffffce"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_10roll_title_epic_hero",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_10roll_Fireguard_2",
                        "color": "#ffffffce"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "banner_drop_probabilities",
                    "color": "#e5c493"
                },
                "description": null,
                "showDrop": true
            },
            {
                "header": {
                    "alias": "gacha_compensation_title_hero",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_hero_2",
                        "color": "#ffffffce"
                    }
                ],
                "showDrop": false
            },
            {
                "header": {
                    "alias": "gacha_compensation_custom_title_1",
                    "color": "#fff"
                },
                "description": [
                    {
                        "alias": "gacha_compensation_custom_1",
                        "color": "#ffffffce"
                    }
                ],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            },
        ]
    },
};
GachaBannerVisualConfig.visualPresets.banner1003 = {
    viewConfig: {
        "subTitle": { "label": { "alias": "gacha_label_hero_event", "color": "#a3ff8c" }, "backgroundColor": "#a3ff8c" },
        "title": { "alias": "gacha_title_2", "color": "#ffffff" },
        "backgroundImage": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_promo_art_Bulwark",
        "description": [
            { "alias": "gacha_subtitle_2", "color": "#ffffffb7" },
            { "alias": "gacha_10roll_jack", "color": "#e5c493" }
        ],
        "rewards": [
            {
                "title": { "alias": "Bulwark", "color": "#fff" },
                "description": { "label1": { "alias": "common", "color": "#97aeb8" }, "label2": null },
                "coordinates": { "x": 63, "y": 441 },
                "backgroundColor": "#49733f",
                "isHighChance": true
            },
            {
                "title": { "alias": "skin_hero_Bulwark_E_Clover", "color": "#fff" },
                "description": { "label1": { "alias": "Epic_skin_tooltip_alias", "color": "#c68cff" }, "label2": null },
                "coordinates": { "x": -774, "y": -225 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            },
            {
                "title": { "alias": "wpn_Bulwark_E_Pike", "color": "#fff" },
                "description": { "label1": { "alias": "epic", "color": "#c68cff" }, "label2": { "alias": "rarity_other", "color": "#c68cff" } },
                "coordinates": { "x": -260, "y": -396 },
                "backgroundColor": "#49733f",
                "isHighChance": false
            }
        ],
        "flowEffectColor": "#718a58",
        "lastMilestoneColor": "#97aeb8",
        "gradientBgColor": "#588a4c"
    },
    slideConfig: {
        "frameColor": "#588a4c",
        "discount": null,
        "gradientColor": "#67a158",
        "patternColor": "#baff75",
        "backgroundColor": "#317320",
        "image": "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_art_Bulwark",
        "location": "Sprites/Assets/ShadowRift/rift_location",
        "pattern": "Sprites/Assets/ShadowRift/rift_pattern_7"
    },
    detailsConfig: {
        "detailsGradientBgColor": "#588a4c",
        "detailsBgImageColor": "#a3ff8c",
        "detailsBgImage": "Sprites/Assets/ShadowRift/decor_lines_07",
        "blocks": [
            {
                "header": { "alias": "gacha_rule_title", "color": "#e5c493" },
                "description": [{ "alias": "gacha_rule", "color": "#ffffff" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": true,
                        "bottomSeparator": false,
                        "separatorColor": "#e5c49389"
                    }
                },
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_contains_title_1", "color": "#ffffff" },
                "description": [{ "alias": "gacha_contains_Bulwark", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_10roll_title_epic_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_10roll_jack", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "banner_drop_probabilities", "color": "#e5c493" },
                "description": null,
                "showDrop": true
            },
            {
                "header": { "alias": "gacha_compensation_title_hero", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_hero_2", "color": "rgba(255,255,255,0.81)" }],
                "showDrop": false
            },
            {
                "header": { "alias": "gacha_compensation_custom_title_1", "color": "#fff" },
                "description": [{ "alias": "gacha_compensation_custom_1", "color": "rgba(255,255,255,0.81)" }],
                "decorationElements": {
                    "separators": {
                        "topSeparator": false,
                        "bottomSeparator": true,
                        "separatorColor": "#e5c4932d"
                    }
                },
                "showDrop": false
            }
        ]
    },
};
