GachaBannerVisualConfig.visualPresets.banner1 = {
    viewConfig: {
        subTitle: { label: { alias: 'gacha_label_hero_event', color: '#c68cff' }, backgroundColor: '#c68cff' },
        title: { alias: 'gacha_title_1', color: '#ffffff' },
        backgroundImage: 'Sprites/PreviewImages/RiftImages/default/rift_promo_art_default',
        description: [
            { alias: 'gacha_subtitle_1', color: '#ffffffb7' },
            { alias: 'gacha_10roll_epic_hero', color: '#e5c493' },
            { alias: 'gacha_roll_discount', color: '#ffffffb7' },
        ],
        rewards: [
            {
                title: { alias: 'Lynx', color: '#fff' },
                description: { label1: { alias: 'epic', color: '#c68cff' }, label2: null, },
                coordinates: { x: -123, y: 57, },
                backgroundColor: '#593f73',
                isHighChance: true,
            },
            {
                title: { alias: 'Midnight', color: '#fff' },
                description: { label1: { alias: 'epic', color: '#c68cff' }, label2: null, },
                coordinates: { x: -771, y: -225, },
                backgroundColor: '#593f73',
                isHighChance: false,
            },
            {
                title: { alias: 'wpn_Lynx_R_Rich', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: { alias: 'rarity_other', color: '#8cbaff' }, },
                coordinates: { x: -111, y: -384, },
                backgroundColor: '#593f73',
                isHighChance: false,
            },
        ],
        flowEffectColor: "#c68cff",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#593f738a",
    },
    slideConfig: {
        frameColor: '#c68cff',
        discount: 10,
        gradientColor: "#c68cff",
        patternColor: "#5ee7ff",
        backgroundColor: "#593f73",
        image: 'Sprites/PreviewImages/RiftImages/default/riftArt_default',
        location: 'Sprites/Assets/ShadowRift/rift_location',
        pattern: 'Sprites/Assets/ShadowRift/rift_pattern_1',
    },
    detailsConfig: {
        detailsGradientBgColor: "#593f735c",
        detailsBgImageColor: "#c68cff17",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: 'gacha_rule_title', color: '#e5c493' },
                description: [
                    { alias: 'gacha_rule', color: '#ffffff' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: '#e5c49389',
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: 'gacha_contains_title_1', color: '#ffffff' },
                description: [
                    { alias: 'gacha_contains_1', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_10roll_title_epic_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_10roll_description_epic_hero', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_roll_discount_title', color: '#fff' },
                description: [
                    { alias: 'gacha_roll_discount_description', color: '#ffffffce' },
                ],
                showDrop: false
            },
            {
                header: { alias: 'banner_drop_probabilities', color: '#e5c493' },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: 'gacha_compensation_title_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_hero_2', color: '#ffffffce' },
                ],
                showDrop: false
            },
            {
                header: { alias: 'gacha_compensation_custom_title_1', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_custom_1', color: '#ffffffce' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: '#e5c4932d',
                    }
                },
                showDrop: false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner3 = {
    viewConfig: {
        subTitle: { label: { alias: 'gacha_label_hero_event', color: '#55e5ba' }, backgroundColor: '#55e5ba' },
        title: { alias: 'gacha_title_3', color: '#ffffff' },
        backgroundImage: 'Sprites/PreviewImages/RiftImages/Viper/rift_promo_art_Viper',
        description: [
            { alias: 'gacha_subtitle_3', color: '#ffffffb7' },
            { alias: 'gacha_10roll_rare', color: '#e5c493' },
        ],
        rewards: [
            {
                title: { alias: 'wpn_Viper_R_base_Rec_Snake', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: null, },
                coordinates: { x: -123, y: 57, },
                backgroundColor: '#2a6873',
                isHighChance: true,
            },
            {
                title: { alias: 'skin_hero_Viper_R_base_Rec_Brat', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: null, },
                coordinates: { x: -771, y: -225, },
                backgroundColor: '#2a6873',
                isHighChance: true,
            },
            {
                title: { alias: 'wpn_Viper_R_base_Rec_Purple', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: { alias: 'rarity_other', color: '#8cbaff' }, },
                coordinates: { x: -111, y: -384, },
                backgroundColor: '#2a6873',
                isHighChance: false,
            },
        ],
        flowEffectColor: "#55e5ba",
        lastMilestoneColor: "#8CC6FF",
        gradientBgColor: "#2a735d8a",
    },
    slideConfig: {
        frameColor: '#55e5ba',
        discount: null,
        gradientColor: "#5ee7ff",
        patternColor: "#55e5ba",
        backgroundColor: "#2a6873",
        image: 'Sprites/PreviewImages/RiftImages/Viper/riftArt_Viper',
        location: 'Sprites/Assets/ShadowRift/rift_location',
        pattern: 'Sprites/Assets/ShadowRift/rift_pattern_1',
    },
    detailsConfig: {
        detailsGradientBgColor: "#2a735d5c",
        detailsBgImageColor: "#55e5ba16",
        detailsBgImage: "Sprites/Assets/Decor/rift_pattern_1",
        blocks: [
            {
                header: { alias: 'gacha_rule_title', color: '#e5c493' },
                description: [
                    { alias: 'gacha_rule', color: '#ffffff' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: '#e5c49389',
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: 'gacha_contains_title_1', color: '#ffffff' },
                description: [
                    { alias: 'gacha_contains_3', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_10roll_title_epic_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_10roll_rare', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'banner_drop_probabilities', color: '#e5c493' },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: 'gacha_compensation_title_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_hero_2', color: '#ffffffce' },
                ],
                showDrop: false
            },
            {
                header: { alias: 'gacha_compensation_custom_title_1', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_custom_1', color: '#ffffffce' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: '#e5c4932d',
                    }
                },
                showDrop: false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner4 = {
    viewConfig: {
        subTitle: { label: { alias: 'gacha_label_hero_event', color: '#ff6347' }, backgroundColor: '#ff6347' },
        title: { alias: 'gacha_title_HongJoo', color: '#ffffff' },
        backgroundImage: 'Sprites/PreviewImages/RiftImages/04_HongJoo/rift_promo_art_HongJoo',
        description: [
            { alias: 'gacha_subtitle_HongJoo', color: '#ffffffb7' },
            { alias: 'gacha_10roll_rare', color: '#e5c493' },
        ],
        rewards: [
            {
                title: { alias: 'HongJoo', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: null, },
                coordinates: { x: -744, y: -9, },
                backgroundColor: '#a12610',
                isHighChance: true,
            },
            {
                title: { alias: 'skin_hero_HongJoo_E_Equilibrist', color: '#fff' },
                description: { label1: { alias: 'Epic_skin_tooltip_alias', color: '#c68cff' }, label2: null, },
                coordinates: { x: -774, y: -270, },
                backgroundColor: '#a12610',
                isHighChance: false,
            },
            {
                title: { alias: 'wpn_HongJoo_E_FireShow', color: '#fff' },
                description: { label1: { alias: 'epic', color: '#c68cff' }, label2: { alias: 'rarity_other', color: '#c68cff' }, },
                coordinates: { x: -81, y: -366, },
                backgroundColor: '#a12610',
                isHighChance: false,
            },
        ],
        flowEffectColor: '#b83923',
        lastMilestoneColor: '#8cbaff',
        gradientBgColor: "#8a1500",
    },
    slideConfig: {
        frameColor: '#ff7e47',
        discount: null,
        gradientColor: '#ff765e',
        patternColor: '#ff765e',
        backgroundColor: '#ff2600',
        image: 'Sprites/PreviewImages/RiftImages/04_HongJoo/rift_art_HongJoo',
        location: 'Sprites/Assets/ShadowRift/rift_location',
        pattern: 'Sprites/Assets/ShadowRift/rift_pattern_9',
    },
    detailsConfig: {
        detailsGradientBgColor: "#73352a",
        detailsBgImageColor: "#ff6347",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: 'gacha_rule_title', color: '#e5c493' },
                description: [
                    { alias: 'gacha_rule', color: '#ffffff' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: '#e5c49389',
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: 'gacha_contains_title_1', color: '#ffffff' },
                description: [
                    { alias: 'gacha_contains_HongJoo', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_10roll_title_epic_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_10roll_rare', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'banner_drop_probabilities', color: '#e5c493' },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: 'gacha_compensation_title_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_hero_2', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_compensation_custom_title_1', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_custom_1', color: '#ffffffce' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: '#e5c4932d',
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner5 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#47acff" }, backgroundColor: "#47acff" },
        title: { alias: "gacha_title_Emperor", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/05_Emperor/rift_promo_art_Emperor",
        description: [
            { alias: "gacha_subtitle_Emperor", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Emperor", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -45, y: 387, },
                backgroundColor: "#1a688a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Emperor_R_Cyan", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -783, y: -315, },
                backgroundColor: "#1a688a",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Emperor_R_Default_Rec_Red", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -90, y: -414, },
                backgroundColor: "#1a688a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#47acff",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#2A5273",
    },
    slideConfig: {
        frameColor: "#8ccbff",
        discount: null,
        gradientColor: "#47acff",
        patternColor: "#75c1ff",
        backgroundColor: "#5eb7ff",
        image: "Sprites/PreviewImages/RiftImages/05_Emperor/rift_art_Emperor",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#2A5273",
        detailsBgImageColor: "#47AEFF",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Emperor", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "#ffffffce" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner6 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ffb647" }, backgroundColor: "#ffb647" },
        title: { alias: "gacha_title_Jet", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/06_Jet/rift_promo_art_Jet",
        description: [
            { alias: "gacha_subtitle_Jet", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Jet", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -585, y: 279, },
                backgroundColor: "#a1612d",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Jet_E_Golden", color: "#fff" },
                description: { label1: { alias: "Epic_skin_tooltip_alias", color: "#c68cff" }, label2: null, },
                coordinates: { x: -774, y: -225, },
                backgroundColor: "#a1612d",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Jet_R_base_Rec_Brown", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -189, y: -387, },
                backgroundColor: "#a1612d",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#b86e00",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#73490b",
    },
    slideConfig: {
        frameColor: "#b87c23",
        discount: null,
        gradientColor: "#ffa31a",
        patternColor: "#e5bc40",
        backgroundColor: "#734520",
        image: "Sprites/PreviewImages/RiftImages/06_Jet/rift_art_Jet",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#735220",
        detailsBgImageColor: "#ffb647",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Jet", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "#ffffffce" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner7 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#b8af97" }, backgroundColor: "#b8af97" },
        title: { alias: "gacha_title_Liquidator", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_promo_art_Liquidator",
        description: [
            { alias: "gacha_subtitle_Liquidator", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Liquidator", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: -765, y: 405, },
                backgroundColor: "#736e5e",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Liquidator_E_White", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -801, y: -216, },
                backgroundColor: "#736e5e",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Liquidator_R_Gold_Rec_Bronze", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -369, y: -396, },
                backgroundColor: "#736e5e",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#b8af97",
        lastMilestoneColor: "#97aeb8",
        gradientBgColor: "#736E5E",
    },
    slideConfig: {
        frameColor: "#b8a776",
        discount: null,
        gradientColor: "#b8af97",
        patternColor: "#b8af97",
        backgroundColor: "#736e5e",
        image: "Sprites/PreviewImages/RiftImages/07_Liquidator/rift_art_Liquidator",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#736E5F",
        detailsBgImageColor: "#B8B097",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Liquidator", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "#ffffffce" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner8 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "fff8ba" }, backgroundColor: "fff8ba" },
        title: { alias: "gacha_title_8", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/08_Helga/rift_promo_art_Helga",
        description: [
            { alias: "gacha_subtitle_8", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "skin_hero_Helga_R_base_Rec_Unsight", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -732, y: 0, },
                backgroundColor: "#8a8558",
                isHighChance: true,
            },
            {
                title: { alias: "wpn_Helga_E_White_Star", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -786, y: -246, },
                backgroundColor: "#8a8558",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Helga_R_Paladin_Rec_Blue", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -6, y: -387, },
                backgroundColor: "#8a8558",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#fff8ba",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#73612a8a",
    },
    slideConfig: {
        frameColor: "#fff8ba",
        discount: null,
        gradientColor: "#ffd75e",
        patternColor: "#fff8ba",
        backgroundColor: "#4b575c",
        image: "Sprites/PreviewImages/RiftImages/08_Helga/rift_art_Helga",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#73612a5c",
        detailsBgImageColor: "#2e2d22ff",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_8", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "#ffffffce" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "#ffffffce" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner9 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff765e" }, backgroundColor: "#ff765e" },
        title: { alias: "gacha_title_Marcus", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/09_Marcus/rift_promo_art_Marcus",
        description: [
            { alias: "gacha_subtitle_Marcus", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Marcus", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -711, y: 423, },
                backgroundColor: "#a13e2d",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Marcus_E_Royal", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -783, y: -126, },
                backgroundColor: "#a13e2d",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Marcus_E_Knight", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -126, y: -366, },
                backgroundColor: "#a13e2d",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff8a75",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#8a200e",
    },
    slideConfig: {
        frameColor: "#ff6347",
        discount: null,
        gradientColor: "#ff765e",
        patternColor: "#ff6347",
        backgroundColor: "#8a3527",
        image: "Sprites/PreviewImages/RiftImages/09_Marcus/rift_art_Marcus",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_9",
    },
    detailsConfig: {
        detailsGradientBgColor: "#73352a",
        detailsBgImageColor: "#ff765e",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Marcus", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner10 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#5ee7ff" }, backgroundColor: "#5ee7ff" },
        title: { alias: "gacha_title_Yukka", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/10_Yukka/rift_promo_art_Yukka",
        description: [
            { alias: "gacha_subtitle_Yukka", color: "#ffffffb7" },
            { alias: "gacha_10roll_rare", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Yukka", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -576, y: 54, },
                backgroundColor: "#2a6873",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Yukka_E_Cat", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: -774, y: -282, },
                backgroundColor: "#2a6873",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Yukka_R_Monograms_Rec_Antique", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -36, y: -405, },
                backgroundColor: "#2a6873",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#2a6873",
        lastMilestoneColor: "#8cbaff",
        gradientBgColor: "#2a6873",
    },
    slideConfig: {
        frameColor: "#5ee7ff",
        discount: null,
        gradientColor: "#5ee7ff",
        patternColor: "#5ee7ff",
        backgroundColor: "#2a6873",
        image: "Sprites/PreviewImages/RiftImages/10_Yukka/rift_art_Yukka",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_1",
    },
    detailsConfig: {
        detailsGradientBgColor: "#2a6873",
        detailsBgImageColor: "#5ee7ff",
        detailsBgImage: "Sprites/Assets/Decor/decor_lines",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Yukka", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_rare", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
