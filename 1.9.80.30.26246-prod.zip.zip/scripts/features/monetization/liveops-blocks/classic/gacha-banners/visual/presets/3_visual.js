GachaBannerVisualConfig.visualPresets.banner22 = {
    viewConfig: {
        subTitle: { label: { alias: 'gacha_label_hero_event', color: '#55e5ba' }, backgroundColor: '#55e5ba' },
        title: { alias: 'gacha_title_Viper', color: '#ffffff' },
        backgroundImage: 'Sprites/PreviewImages/RiftImages/Viper/rift_promo_art_Viper',
        description: [
            { alias: 'gacha_subtitle_Viper', color: '#ffffffb7' },
            { alias: 'gacha_10roll_rare', color: '#e5c493' },
        ],
        rewards: [
            {
                title: { alias: 'Viper', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: null, },
                coordinates: { x: -123, y: 57, },
                backgroundColor: '#2a6873',
                isHighChance: true,
            },
            {
                title: { alias: 'skin_hero_Viper_R_base_Rec_Brat', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: null, },
                coordinates: { x: -771, y: -225, },
                backgroundColor: '#2a6873',
                isHighChance: false,
            },
            {
                title: { alias: 'wpn_Viper_R_base_Rec_Purple', color: '#fff' },
                description: { label1: { alias: 'rare', color: '#8cbaff' }, label2: { alias: 'rarity_other', color: '#8cbaff' }, },
                coordinates: { x: -111, y: -384, },
                backgroundColor: '#2a6873',
                isHighChance: false,
            },
        ],
        flowEffectColor: "#55e5ba",
        lastMilestoneColor: "#8CC6FF",
        gradientBgColor: "#2A735D",
    },
    slideConfig: {
        frameColor: '#55e5ba',
        discount: null,
        gradientColor: "#5ee7ff",
        patternColor: "#55e5ba",
        backgroundColor: "#2a6873",
        image: 'Sprites/PreviewImages/RiftImages/Viper/riftArt_Viper',
        location: 'Sprites/Assets/ShadowRift/rift_location',
        pattern: 'Sprites/Assets/ShadowRift/rift_pattern_1',
    },
    detailsConfig: {
        detailsGradientBgColor: "#2A735D",
        detailsBgImageColor: "#55E5BA",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: 'gacha_rule_title', color: '#e5c493' },
                description: [
                    { alias: 'gacha_rule', color: '#ffffff' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: '#e5c49389',
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: 'gacha_contains_title_1', color: '#ffffff' },
                description: [
                    { alias: 'gacha_contains_Viper', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'gacha_10roll_title_epic_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_10roll_rare', color: '#ffffffce' },
                ],
                showDrop: false,
            },
            {
                header: { alias: 'banner_drop_probabilities', color: '#e5c493' },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: 'gacha_compensation_title_hero', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_hero_2', color: '#ffffffce' },
                ],
                showDrop: false
            },
            {
                header: { alias: 'gacha_compensation_custom_title_1', color: '#fff' },
                description: [
                    { alias: 'gacha_compensation_custom_1', color: '#ffffffce' },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: '#e5c4932d',
                    }
                },
                showDrop: false
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner24 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#a3ffe3" }, backgroundColor: "#a3ffe3" },
        title: { alias: "gacha_title_LegionKing", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_promo_art_LegionKing",
        description: [
            { alias: "gacha_subtitle_LegionKing", color: "#ffffffb7" },
            { alias: "gacha_10roll_legendary", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Legion_King", color: "#fff" },
                description: { label1: { alias: "legendary", color: "#ffd75e" }, label2: { alias: "rarity_other", color: "#ffd75e" }, },
                coordinates: { x: -522, y: -405, },
                backgroundColor: "#3f8a73",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Legion_King_R_Viny", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -747, y: -198, },
                backgroundColor: "#3f8a73",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#76b8a4",
        lastMilestoneColor: "#ffd75e",
        gradientBgColor: "#588a7b",
    },
    slideConfig: {
        frameColor: "#588a7b",
        discount: null,
        gradientColor: "#76b8a4",
        patternColor: "#337d8a",
        backgroundColor: "#8a6227",
        image: "Sprites/PreviewImages/RiftImages/22_LegionKing/rift_art_LegionKing",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_8",
    },
    detailsConfig: {
        detailsGradientBgColor: "#497366",
        detailsBgImageColor: "#76b8a4",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_8",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_LegionKing", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_legendary", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner25 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#a3ff8c" }, backgroundColor: "#a3ff8c" },
        title: { alias: "gacha_title_Bulwark", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_promo_art_Bulwark",
        description: [
            { alias: "gacha_subtitle_Bulwark", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Bulwark", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: 63, y: 441, },
                backgroundColor: "#49733f",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Bulwark_R_Black", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -774, y: -225, },
                backgroundColor: "#49733f",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Bulwark_E_Pike", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -198, y: -396, },
                backgroundColor: "#49733f",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#718a58",
        lastMilestoneColor: "#97aeb8",
        gradientBgColor: "#588a4c",
    },
    slideConfig: {
        frameColor: "#588a4c",
        discount: null,
        gradientColor: "#67a158",
        patternColor: "#baff75",
        backgroundColor: "#317320",
        image: "Sprites/PreviewImages/RiftImages/21_Bulwark/rift_art_Bulwark",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_7",
    },
    detailsConfig: {
        detailsGradientBgColor: "#588a4c",
        detailsBgImageColor: "#a3ff8c",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_07",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Bulwark", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner49 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff811a" }, backgroundColor: "#ff811a" },
        title: { alias: "gacha_title_Fireguard", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_promo_art_Fireguard_23",
        description: [
            { alias: "gacha_subtitle_Fireguard", color: "#ffffffb7" },
            { alias: "gacha_10roll_common", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Fireguard", color: "#fff" },
                description: { label1: { alias: "common", color: "#97aeb8" }, label2: null, },
                coordinates: { x: -3, y: 486, },
                backgroundColor: "#A15110",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Fireguard_E_White", color: "#fff" },
                description: { label1: { alias: "Season_skin_tooltip_alias", color: "#ff5e76" }, label2: null, },
                coordinates: { x: -627, y: -252, },
                backgroundColor: "#A15110",
                isHighChance: false,
            },
            {
                title: { alias: "wpn_Fireguard_E_Bones", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -153, y: -390, },
                backgroundColor: "#A15110",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff811a",
        lastMilestoneColor: "#97aeb8",
        gradientBgColor: "#8a4c1a",
    },
    slideConfig: {
        frameColor: "#cf7327",
        discount: null,
        gradientColor: "#b88154",
        patternColor: "#b86f33",
        backgroundColor: "#734520",
        image: "Sprites/PreviewImages/RiftImages/23_Fireguard/rift_art_Fireguard_23",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_5",
    },
    detailsConfig: {
        detailsGradientBgColor: "#734520",
        detailsBgImageColor: "#ff7e47",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_05",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Fireguard", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_common", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner56 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#75ffff" }, backgroundColor: "#75ffff" },
        title: { alias: "gacha_title_Itu", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/25_Itu/rift_promo_art_Itu",
        description: [
            { alias: "gacha_subtitle_Itu", color: "#ffffffb7" },
            { alias: "gacha_10roll_Itu", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Itu", color: "#fff" },
                description: { label1: { alias: "legendary", color: "#ffd75e" }, label2: null, },
                coordinates: { x: 45, y: 450, },
                backgroundColor: "#3f8a8a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Itu_R_Red", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -144, y: -396, },
                backgroundColor: "#3f8a8a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#75ffff",
        lastMilestoneColor: "#ffd75e",
        gradientBgColor: "#207373",
    },
    slideConfig: {
        frameColor: "#65b8b8",
        discount: null,
        gradientColor: "#47ffff",
        patternColor: "#47ffff",
        backgroundColor: "#207373",
        image: "Sprites/PreviewImages/RiftImages/25_Itu/rift_art",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_9",
    },
    detailsConfig: {
        detailsGradientBgColor: "#207373",
        detailsBgImageColor: "#75ffff",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Itu_1", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_Itu", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner55 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff4747" }, backgroundColor: "#ff4747" },
        title: { alias: "gacha_title_Butcher", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/24_Butcher/rift_promo_art_Butcher",
        description: [
            { alias: "gacha_subtitle_Butcher", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Butcher", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: 36, y: 486, },
                backgroundColor: "#8a2727",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Butcher_R_Purple", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: null, },
                coordinates: { x: -636, y: -414, },
                backgroundColor: "#8a2727",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#e54040",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#732a35",
    },
    slideConfig: {
        frameColor: "#b83333",
        discount: null,
        gradientColor: "#b83333",
        patternColor: "#b83333",
        backgroundColor: "#8a2727",
        image: "Sprites/PreviewImages/RiftImages/24_Butcher/rift_art_Butcher",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_10",
    },
    detailsConfig: {
        detailsGradientBgColor: "#732a35",
        detailsBgImageColor: "#b84444",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_10",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Butcher", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner77 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#75ffff" }, backgroundColor: "#75ffff" },
        title: { alias: "gacha_title_Itu", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/25_Itu/rift_promo_art_Itu",
        description: [
            { alias: "gacha_subtitle_Itu", color: "#ffffffb7" },
            { alias: "gacha_10roll_Itu", color: "#e5c493" },
            { alias: "gacha_roll_discount", color: "#ffffffb7" },
        ],
        rewards: [
            {
                title: { alias: "Itu", color: "#fff" },
                description: { label1: { alias: "legendary", color: "#ffd75e" }, label2: null, },
                coordinates: { x: 45, y: 450, },
                backgroundColor: "#3f8a8a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Itu_R_Red", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -144, y: -396, },
                backgroundColor: "#3f8a8a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#75ffff",
        lastMilestoneColor: "#ffd75e",
        gradientBgColor: "#207373",
    },
    slideConfig: {
        frameColor: "#65b8b8",
        discount: 10,
        gradientColor: "#47ffff",
        patternColor: "#47ffff",
        backgroundColor: "#207373",
        image: "Sprites/PreviewImages/RiftImages/25_Itu/rift_art",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_9",
    },
    detailsConfig: {
        detailsGradientBgColor: "#207373",
        detailsBgImageColor: "#75ffff",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_9",
        blocks: [
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_Itu_1", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_Itu", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner106 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#ff6347" }, backgroundColor: "#ff6347" },
        title: { alias: "gacha_title_XiangTzu", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/26_XiangTzu/rift_promo_art_XiangTzu",
        description: [
            { alias: "gacha_subtitle_XiangTzu", color: "#ffffffb7" },
            { alias: "gacha_10roll_epic", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "Xiang_Tzu", color: "#fff" },
                description: { label1: { alias: "epic", color: "#c68cff" }, label2: null, },
                coordinates: { x: 65, y: 396, },
                backgroundColor: "#8a3527",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_Xiang_Tzu_R_Fighter", color: "#fff" },
                description: { label1: { alias: "rare", color: "#8cbaff" }, label2: { alias: "rarity_other", color: "#8cbaff" }, },
                coordinates: { x: -477, y: -360, },
                backgroundColor: "#8a3527",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#ff6347",
        lastMilestoneColor: "#c68cff",
        gradientBgColor: "#732d20",
    },
    slideConfig: {
        frameColor: "#cf503a",
        discount: null,
        gradientColor: "#b84733",
        patternColor: "#ff765e",
        backgroundColor: "#8a2b1a",
        image: "Sprites/PreviewImages/RiftImages/26_XiangTzu/rift_art_XiangTzu",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_5",
    },
    detailsConfig: {
        detailsGradientBgColor: "#732D20",
        detailsBgImageColor: "#FF8A75",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_05",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_XiangTzu", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_epic", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
GachaBannerVisualConfig.visualPresets.banner118 = {
    viewConfig: {
        subTitle: { label: { alias: "gacha_label_hero_event", color: "#df6ae5" }, backgroundColor: "#df6ae5" },
        title: { alias: "gacha_title_June", color: "#ffffff" },
        backgroundImage: "Sprites/PreviewImages/RiftImages/27_June/rift_promo_art_June",
        description: [
            { alias: "gacha_subtitle_June", color: "#ffffffb7" },
            { alias: "gacha_10roll_June", color: "#e5c493" },
        ],
        rewards: [
            {
                title: { alias: "June", color: "#fff" },
                description: { label1: { alias: "legendary", color: "#ffd75e" }, label2: null, },
                coordinates: { x: 9, y: 396, },
                backgroundColor: "#863f8a",
                isHighChance: true,
            },
            {
                title: { alias: "skin_hero_June_R_Star", color: "#fff" },
                description: { label1: { alias: "rare", color: "#c68cff" }, label2: { alias: "rarity_other", color: "#c68cff" }, },
                coordinates: { x: -576, y: -360, },
                backgroundColor: "#863f8a",
                isHighChance: false,
            },
        ],
        flowEffectColor: "#df6ae5",
        lastMilestoneColor: "#ffd75e",
        gradientBgColor: "#2d152e",
    },
    slideConfig: {
        frameColor: "#b354b8",
        discount: null,
        gradientColor: "#b354b8",
        patternColor: "#df6ae5",
        backgroundColor: "#863f8a",
        image: "Sprites/PreviewImages/RiftImages/27_June/rift_art_June",
        location: "Sprites/Assets/ShadowRift/rift_location",
        pattern: "Sprites/Assets/ShadowRift/rift_pattern_2",
    },
    detailsConfig: {
        detailsGradientBgColor: "#863f8a",
        detailsBgImageColor: "#df6ae5",
        detailsBgImage: "Sprites/Assets/ShadowRift/decor_lines_02",
        blocks: [
            {
                header: { alias: "gacha_rule_title", color: "#e5c493" },
                description: [
                    { alias: "gacha_rule", color: "#ffffff" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: true,
                        bottomSeparator: false,
                        separatorColor: "#e5c49389",
                    }
                },
                showDrop: false,
            },
            {
                header: { alias: "gacha_contains_title_1", color: "#ffffff" },
                description: [
                    { alias: "gacha_contains_June_1", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_10roll_title_epic_hero", color: "#fff" },
                description: [
                    { alias: "gacha_10roll_June", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "banner_drop_probabilities", color: "#e5c493" },
                description: null,
                showDrop: true,
            },
            {
                header: { alias: "gacha_compensation_title_hero", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_hero_2", color: "rgba(255,255,255,0.81)" },
                ],
                showDrop: false,
            },
            {
                header: { alias: "gacha_compensation_custom_title_1", color: "#fff" },
                description: [
                    { alias: "gacha_compensation_custom_1", color: "rgba(255,255,255,0.81)" },
                ],
                decorationElements: {
                    separators: {
                        topSeparator: false,
                        bottomSeparator: true,
                        separatorColor: "#e5c4932d",
                    }
                },
                showDrop: false,
            },
        ],
    },
};
