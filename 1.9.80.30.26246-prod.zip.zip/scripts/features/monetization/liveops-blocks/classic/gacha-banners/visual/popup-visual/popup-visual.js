var gachaPopupVisualConfigs = CommonPopUpUtils.setActivityPopupsOverMap(activityPopupsMap, [
    {
        data: {
            "ID": 2000,
            "priority": 3,
            "navigation": POPUP_NAVIGATION.GACHA,
            "navigationArg": 10004,
            "activeTime": EventTimeConstants.defaultEventMock.popups._1,
            "countryCode": ["RU", "KZ"],
            "endDate": new Date("2023-03-27").getTime() + new Time({ Days: 10 }).value,
        },
        visual: {
            "displayedCurrencies": [CURRENCY.GACHA_KEY],
            "iconId": 5,
            "rulesDescription": {
                "alias": "popup_rules_event5",
                "color": "#C68CFF"
            },
            "rulesHeader": {
                "alias": "popup_event_rules_title",
                "color": "#FFFFFF"
            },
            "header": {
                "alias": "popup_title_event5",
                "color": "#FFD75E"
            },
            "subHeader": {
                "alias": "event_popup_currency_title",
                "color": "#FFD75E"
            },
            "timer": {
                "alias": "quest_ends_timer",
                "color": "#FFD75E"
            },
            "button": {
                "alias": "button_shop",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Events/AprilEvent/art_event_April",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Events/AprilEvent/bg_event_April",
                "color": "#5ECFFF"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#C68CFF"
            },
            "particles": {
                "maxColor": "#C68CFF",
                "minColor": "#C68CFF"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#493f73"
                    },
                    {
                        "time": 0.98,
                        "color": "#493f73"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#c68cff"
                    },
                    {
                        "time": 0.99,
                        "color": "#2a5d73"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": [
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_ACTIVITIES",
                    "alias": "event1_benefit_desc_1",
                    "color": "#C68CFF"
                },
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_EVENT_TOKEN",
                    "alias": "event1_benefit_desc_2",
                    "color": "#C68CFF"
                },
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_TICKET",
                    "alias": "event1_benefit_desc_3",
                    "color": "#C68CFF"
                }
            ],
            "pattern": {
                "sprite": "",
                "color": "#ffffff00"
            },
        },
    },
]);
