var GachaBannerVisualConfig = (function () {
    function GachaBannerVisualConfig() {
    }
    GachaBannerVisualConfig.checkShardsInRewardContent = function (content, rarity) {
        if (content && content.loot) {
            var shards = content.loot.Shards;
            var ids = Object.keys(shards);
            if (ids.length > 0) {
                var hero = heroesMap.get(ids[0]);
                return hero && hero.Rarity == rarity;
            }
        }
        return false;
    };
    GachaBannerVisualConfig.checkCustomizeInRewardContent = function (content, type, rarity, map) {
        if (content && content.loot && content.loot[type]) {
            var customizations = content.loot[type];
            if (Array.isArray(customizations)) {
                var customization = map.get(customizations[0]);
                return customization && customization.rarity == rarity;
            }
        }
        return false;
    };
    GachaBannerVisualConfig.checkStanceInRewardContent = function (content, rarity, type) {
        if (content && content.loot && content.loot.Stances) {
            var customizations = content.loot.Stances;
            if (Array.isArray(customizations)) {
                var stance = stancesMap.get(customizations[0]);
                return stance && stance.rarity == rarity && stance.Settings.StanceType == type;
            }
        }
        return false;
    };
    GachaBannerVisualConfig.checkLegendaryWeaponCustomizationShardInRewardContent = function (content) {
        var _a;
        if (!((_a = content.loot) === null || _a === void 0 ? void 0 : _a.CustomizationShards)) {
            return false;
        }
        var customizationShardId = Object.keys(content.loot.CustomizationShards)[0];
        var customizationShard = customizationShardsMap.get(customizationShardId);
        return Boolean(customizationShard);
    };
    GachaBannerVisualConfig.chanceDigit = 2;
    GachaBannerVisualConfig.visualPresets = {};
    GachaBannerVisualConfig.colorRarityPresets = {
        legendary: '#ffd75e',
        epic: '#c68cff',
        rare: '#8cbaff',
        common: '#97aeb8',
        season: '#ff4763',
    };
    GachaBannerVisualConfig.colorRarityBackgroundPresets = {
        legendary: '#ffd75e17',
        epic: '#c68cff17',
        rare: '#8cbaff17',
        common: '#97aeb817',
        season: '#ff476317',
    };
    GachaBannerVisualConfig.detailsGroupsSettings = [
        {
            alias: 'gacha_legendary_shard',
            color: GachaBannerVisualConfig.colorRarityPresets.legendary,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.legendary,
            check: function (content) { return GachaBannerVisualConfig.checkShardsInRewardContent(content, HERO_RARITY.LEGENDARY); },
        },
        {
            alias: 'gacha_epic_shard',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkShardsInRewardContent(content, HERO_RARITY.EPIC); },
        },
        {
            alias: 'gacha_rare_shard',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkShardsInRewardContent(content, HERO_RARITY.RARE); },
        },
        {
            alias: 'gacha_common_shard',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkShardsInRewardContent(content, HERO_RARITY.COMMON); },
        },
        {
            alias: 'gacha_epic_weapon',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Weapons", HERO_WEAPON_RARITY.EPIC, weaponsMap); },
        },
        {
            alias: 'gacha_rare_weapon',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Weapons", HERO_WEAPON_RARITY.RARE, weaponsMap); },
        },
        {
            alias: 'gacha_common_weapon',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Weapons", HERO_WEAPON_RARITY.COMMON, weaponsMap); },
        },
        {
            alias: 'gacha_seasonal_skin',
            color: GachaBannerVisualConfig.colorRarityPresets.season,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.season,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "HeroSkins", SKIN_RARITY.SEASON, skinsMap); },
        },
        {
            alias: 'gacha_epic_skin',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "HeroSkins", SKIN_RARITY.EPIC, skinsMap); },
        },
        {
            alias: 'gacha_rare_skin',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "HeroSkins", SKIN_RARITY.RARE, skinsMap); },
        },
        {
            alias: 'gacha_common_skin',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "HeroSkins", SKIN_RARITY.COMMON, skinsMap); },
        },
        {
            alias: 'gacha_seasonal_stance',
            color: GachaBannerVisualConfig.colorRarityPresets.season,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.season,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.SEASON, STANCE_TYPE.START_POSE); },
        },
        {
            alias: 'gacha_epic_stance',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.EPIC, STANCE_TYPE.START_POSE); },
        },
        {
            alias: 'gacha_rare_stance',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.RARE, STANCE_TYPE.START_POSE); },
        },
        {
            alias: 'gacha_common_stance',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.COMMON, STANCE_TYPE.START_POSE); },
        },
        {
            alias: 'gacha_seasonal_win_pose',
            color: GachaBannerVisualConfig.colorRarityPresets.season,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.season,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.SEASON, STANCE_TYPE.WIN_POSE); },
        },
        {
            alias: 'gacha_epic_win_pose',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.EPIC, STANCE_TYPE.WIN_POSE); },
        },
        {
            alias: 'gacha_rare_win_pose',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.RARE, STANCE_TYPE.WIN_POSE); },
        },
        {
            alias: 'gacha_common_win_pose',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkStanceInRewardContent(content, STANCE_RARITY.COMMON, STANCE_TYPE.WIN_POSE); },
        },
        {
            alias: 'gacha_seasonal_taunt',
            color: GachaBannerVisualConfig.colorRarityPresets.season,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.season,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Taunts", TAUNT_RARITY.SEASON, tauntsMap); },
        },
        {
            alias: 'gacha_epic_taunt',
            color: GachaBannerVisualConfig.colorRarityPresets.epic,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.epic,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Taunts", TAUNT_RARITY.EPIC, tauntsMap); },
        },
        {
            alias: 'gacha_rare_taunt',
            color: GachaBannerVisualConfig.colorRarityPresets.rare,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.rare,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Taunts", TAUNT_RARITY.RARE, tauntsMap); },
        },
        {
            alias: 'gacha_common_taunt',
            color: GachaBannerVisualConfig.colorRarityPresets.common,
            backgroundColor: GachaBannerVisualConfig.colorRarityBackgroundPresets.common,
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Taunts", TAUNT_RARITY.COMMON, tauntsMap); },
        },
        {
            alias: 'emoji_gacha',
            color: '#55e5ba5C',
            backgroundColor: '#55e5ba17',
            check: function (content) { return GachaBannerVisualConfig.checkCustomizeInRewardContent(content, "Emoji", EMOJI_RARITY.ANY, emojiMap); },
        },
        {
            alias: 'gacha_other_reward', color: '#e5c493', backgroundColor: '#e5c49317', mixSameLoot: true,
            check: function (content) { return true; },
        },
    ];
    return GachaBannerVisualConfig;
}());
