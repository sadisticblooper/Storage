offerSkins.Boss_Skin_Monk = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104747 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Monk_E_Cursed_Rec_Creepy.ID,
        HERO_1: heroes.Monk.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boos_Monk_E_Cursed_Rec_Creepy",
        START_DATE: new Date("2026-07-17").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Monk",
    },
    offers: [
        { common: {
                profit: 1.8,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Helga = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104750 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Helga_E_Phoenix_Rec_Boss_skin.ID,
        HERO_1: heroes.Helga.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Helga_E_Phoenix_Rec_Boss_skin",
        START_DATE: new Date("2026-07-18").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Helga",
    },
    offers: [
        { common: {
                profit: 1.5,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Bulwark = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104753 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Bulwark_E_Gold_skin.ID,
        HERO_1: heroes.Bulwark.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Bulwark_E_Gold_skin",
        START_DATE: new Date("2026-07-19").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Bulwark"
    },
    offers: [
        { common: {
                profit: 1.8,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Emperor = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104756 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Emperor_E_Doomed_Rec_Enlighten_skin.ID,
        HERO_1: heroes.Emperor.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Emperor_E_Doomed_Rec_Enlighten_skin",
        START_DATE: new Date("2026-07-20").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Emperor"
    },
    offers: [
        { common: {
                profit: 1.6,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-35%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Legion_King = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104759 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Legion_King_E_Bone_Rec_Lich.ID,
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Legion_King_E_Bone_Rec_Lich",
        START_DATE: new Date("2026-07-21").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Legion_King"
    },
    offers: [
        { common: {
                profit: 1.7,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-40%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Sarge = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104762 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Sarge_E_Jailer_Rec_Boss.ID,
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Sarge_E_Jailer_Rec_Boss",
        START_DATE: new Date("2026-07-22").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Sarge"
    },
    offers: [
        { common: {
                profit: 1.5,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
offerSkins.Boss_Skin_Ironclad = {
    skeleton: offerSkeletons.Boss_Skin,
    offersIdGenerator: function (index) { return 104765 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_BOSS_SKIN_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Ironclad_E_Rust_Rec_Boss.ID,
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: "offer_boss_skin_pve",
        VISUAL_PRESET_1: "boss_Ironclad_E_Rust_Rec_Boss",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Ironclad"
    },
    offers: [
        { common: {
                profit: 1.8,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-45%",
            },
        },
        { common: {}, },
        { common: {}, },
    ],
};
