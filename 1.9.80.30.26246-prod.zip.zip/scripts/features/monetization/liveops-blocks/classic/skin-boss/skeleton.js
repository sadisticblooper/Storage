offerSkeletons.Boss_Skin = {
    offers: [
        {
            common: {
                conditions: {},
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[1],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    noHeroExist: [VARS.HERO_1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.ROGUELIKE_ENERGY] = [{ Weight: 1, Amount: new RndFromInterval(50) }], _c) } } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Hero"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 89.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-65%",
                profit: 3.2,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[2],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.ROGUELIKE_ENERGY] = [{ Weight: 1, Amount: new RndFromInterval(50) }], _b) } } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Cheap"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-25%",
                profit: 1.3,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    popupSettings: {
                        popUpId: OFFERS[3],
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.ROGUELIKE_ENERGY] = [{ Weight: 1, Amount: new RndFromInterval(75) }], _b) } } }]
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID, chests.Small_Shard_Chest.ID] } }]
                            },
                        ]
                    },
                };
            },
            offerPrefix: "Expensive"
        },
    ]
};
