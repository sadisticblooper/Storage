rouletteSkins.roulette_wpn_Viper_E_Chargeboom = {
    skeleton: rouletteSkeletons.classic_weapons_roulette,
    rouletteIdGenerator: function (index) { return 3025 + index; },
    rouletteNameGenerator: function (rouletteId) { return "roulette_wpn_Viper_E_Chargeboom_".concat(rouletteId); },
    offersNameGenerator: function (offerId) { return "PROMO_roulette_wpn_Viper_E_Chargeboom_".concat(offerId); },
    activeTime: {
        startGenerationBound: RouletteTimeConstants.roulette_wpn_Viper_E_Chargeboom.roulette.start,
        endGenerationBound: RouletteTimeConstants.roulette_wpn_Viper_E_Chargeboom.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.viperChargeboom,
        ALIAS_1: 'Boosters_roulette',
        WEAPON_1: heroWeapons.wpn_Viper_E_Chargeboom.ID
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.roulette_wpn_Helga_E_White_Star = {
    skeleton: rouletteSkeletons.classic_weapons_roulette,
    rouletteIdGenerator: function (index) { return 3026 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "roulette_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_roulette_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: RouletteTimeConstants.roulette_wpn_Helga_E_White_Star.roulette.start,
        endGenerationBound: RouletteTimeConstants.roulette_wpn_Helga_E_White_Star.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.helgaWhiteStarWpnRoulette,
        ALIAS_1: 'Boosters_roulette',
        WEAPON_1: heroWeapons.wpn_Helga_E_White_Star.ID,
        NAME_PREFIX: "wpn_Helga_E_White_Star"
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.roulette_wpn_Liquidator_E_Obsidians = {
    skeleton: rouletteSkeletons.classic_weapons_roulette,
    rouletteIdGenerator: function (index) { return 3027 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "roulette_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_roulette_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: RouletteTimeConstants.roulette_wpn_Liquidator_E_Obsidians.roulette.start,
        endGenerationBound: RouletteTimeConstants.roulette_wpn_Liquidator_E_Obsidians.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.liquidatorObsidiansWpnRoulette,
        ALIAS_1: 'Boosters_roulette',
        WEAPON_1: heroWeapons.wpn_Liquidator_E_Obsidians.ID,
        NAME_PREFIX: "wpn_Liquidator_E_Obsidians"
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
rouletteSkins.roulette_wpn_marcus_lava = {
    skeleton: rouletteSkeletons.classic_weapons_roulette,
    rouletteIdGenerator: function (index) { return 3028 + index; },
    rouletteNameGenerator: function (rouletteId, vars) { return "roulette_".concat(vars.NAME_PREFIX, "_").concat(rouletteId); },
    offersNameGenerator: function (offerId, _, vars) { return "PROMO_roulette_".concat(vars.NAME_PREFIX, "_").concat(offerId); },
    activeTime: {
        startGenerationBound: RouletteTimeConstants.roulette_wpn_marcus_lava.roulette.start,
        endGenerationBound: RouletteTimeConstants.roulette_wpn_marcus_lava.roulette.end
    },
    vars: {
        ROULETTE_VISUAL_1: rouletteVisualConfig.marcusLava_wpn,
        ALIAS_1: 'Boosters_roulette',
        WEAPON_1: heroWeapons.wpn_Marcus_E_Lava.ID,
        NAME_PREFIX: "wpn_Marcus_E_Lava"
    },
    roulettes: [
        {
            common: {},
        },
    ],
    offers: [],
};
