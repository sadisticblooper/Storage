var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77;
extend(offers, {
    PROMO_Steam_Release_All_Platforms: new PromoOffer({
        ID: 81010,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_subtitle_steam_release_1",
        inApp: inAppSettings.PRICE_2.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-06").getTime(),
        },
        profit: 4.0,
        discount: "-75%",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        productGroup: 81010,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 19,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-10-21").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.TICKET_3] = 1, _a) }) } } }],
                },
            ]
        },
    }),
    PROMO_Steam_Release_Steam_Platform_1: new PromoOffer({
        ID: 81011,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_subtitle_steam_release_2",
        inApp: inAppSettings.PRICE_1.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-06").getTime(),
        },
        profit: 3.6,
        discount: "-70%",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            var isPcBuild = SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
            var wasPreviousOfferBought = OffersUtils.wasOfferBought(81010, settings);
            return isPcBuild && wasPreviousOfferBought;
        },
        productGroup: 81011,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 20,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-10-21").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_b = {}, _b[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _b) } } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.GACHA_KEY] = 1, _c) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.TICKET_3] = 1, _d) }) } } }],
                },
            ]
        },
    }),
    PROMO_Steam_Release_Steam_Platform_2: new PromoOffer({
        ID: 81012,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_subtitle_steam_release_3",
        inApp: inAppSettings.PRICE_5.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-06").getTime(),
        },
        profit: 2.8,
        discount: "-60%",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            var isPcBuild = SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
            var wasPreviousOfferBought = OffersUtils.wasOfferBought(81011, settings);
            return isPcBuild && wasPreviousOfferBought;
        },
        productGroup: 81012,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 21,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-10-21").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 1 },
                types: [CUSTOMIZATION.STANCE],
                rarities: [CUSTOMIZATION_RARITY.EPIC_STANCE],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[HeroNames.Monkey_King.ID] = 3, _e) }) } } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.TICKET_3] = 1, _f) }) } } }],
                },
            ]
        },
    }),
    PROMO_Steam_Release_Steam_Platform_3: new PromoOffer({
        ID: 81013,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_subtitle_steam_release_4",
        inApp: inAppSettings.PRICE_7.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-06").getTime(),
        },
        profit: 2.0,
        discount: "-50%",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            var isPcBuild = SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
            var wasPreviousOfferBought = OffersUtils.wasOfferBought(81012, settings);
            return isPcBuild && wasPreviousOfferBought;
        },
        productGroup: 81013,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 22,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-10-21").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 1 },
                types: [CUSTOMIZATION.WEAPON],
                rarities: [CUSTOMIZATION_RARITY.RARE_WEAPON],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.TICKET_3] = 1, _g) }) } } }],
                },
            ]
        },
    }),
    PROMO_Steam_Release_Steam_Platform_4: new PromoOffer({
        ID: 81014,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_subtitle_steam_release_5",
        inApp: inAppSettings.PRICE_2.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-06").getTime(),
        },
        profit: 5.1,
        discount: "-80%",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            var isPcBuild = SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
            var wasPreviousOfferBought = OffersUtils.wasOfferBought(81013, settings);
            return isPcBuild && wasPreviousOfferBought;
        },
        productGroup: 81014,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 23,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-10-21").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.EPIC_TAUNT],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_h = {}, _h[HeroNames.Monkey_King.ID] = 5, _h) }) } } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.TICKET_3] = 1, _j) }) } } }],
                },
            ]
        },
    }),
    PROMO_Free_Currencies_Steam_Login: new PromoOffer({
        ID: 81015,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_steam_release_gift",
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        customCondition: function (settings) {
            return SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        enablePopup: true,
        popupSettings: {
            popUpId: 35,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.CHIP_1] = 500, _k) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.TOKEN_1] = 1000, _l) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.TICKET_1] = 15, _m) }) } } }],
                },
            ]
        },
        price: (_o = {}, _o[CURRENCY.BONUS] = 0, _o),
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-11-07").getTime(),
        },
    }),
    PROMO_Gift_Skitch_Store_Ling: new PromoOffer({
        ID: 81016,
        offerNameAlias: "Offers_gift_Skich_Store",
        visualPresetId: "promo_offer_Skich_Store",
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 1 },
            createdPlayerTime: { more_or_equal: new Date("2022-11-29T16:35:00Z").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 1 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        companies: ["20251127_sfa_skich_invite"],
        triggers: [],
        enablePopup: true,
        popupSettings: {
            popUpId: 99,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ling_E_Samurai_skin.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_p = {}, _p[heroes.Ling.ID] = 15, _p) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_q = {}, _q[heroes.Ling.ID] = 25, _q) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _r) } } }],
                }
            ]
        },
        price: (_s = {}, _s[CURRENCY.BONUS] = 0, _s),
        activeTime: {
            startGenerationBound: new Date("2025-12-04").getTime(),
            endGenerationBound: new Date("2026-12-31").getTime(),
        },
    }),
    PROMO_GIFT_NY25_2412: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81017,
        offerNameAlias: "promo_offer_gift_cycle_1_11",
        price: (_t = {}, _t[CURRENCY.BONUS] = 0, _t),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_u = {}, _u[CURRENCY.TICKET_2] = [{ Weight: 1, Amount: new RndFromInterval(25) }], _u) } } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-24').getTime(),
            endGenerationBound: new Date('2025-12-25').getTime(),
        },
    }),
    PROMO_GIFT_NY25_2512: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81018,
        offerNameAlias: "promo_offer_gift_cycle_2_11",
        price: (_v = {}, _v[CURRENCY.BONUS] = 0, _v),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-25').getTime(),
            endGenerationBound: new Date('2025-12-26').getTime(),
        },
    }),
    PROMO_GIFT_NY25_2612: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81019,
        offerNameAlias: "promo_offer_gift_cycle_3_11",
        price: (_w = {}, _w[CURRENCY.BONUS] = 0, _w),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_x = {}, _x[CURRENCY.CHIP_2] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _x) } } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-26').getTime(),
            endGenerationBound: new Date('2025-12-27').getTime(),
        },
    }),
    PROMO_GIFT_NY25_2712: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81020,
        offerNameAlias: "promo_offer_gift_cycle_4_11",
        price: (_y = {}, _y[CURRENCY.BONUS] = 0, _y),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID, chests.Rare_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-27').getTime(),
            endGenerationBound: new Date('2025-12-28').getTime(),
        },
    }),
    PROMO_GIFT_NY25_2812: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81021,
        offerNameAlias: "promo_offer_gift_cycle_5_11",
        price: (_z = {}, _z[CURRENCY.BONUS] = 0, _z),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_0 = {}, _0[CURRENCY.TOKEN_2] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _0) } } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-28').getTime(),
            endGenerationBound: new Date('2025-12-29').getTime(),
        },
    }),
    PROMO_GIFT_NY25_2912: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81022,
        offerNameAlias: "promo_offer_gift_cycle_6_11",
        price: (_1 = {}, _1[CURRENCY.BONUS] = 0, _1),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-29').getTime(),
            endGenerationBound: new Date('2025-12-30').getTime(),
        },
    }),
    PROMO_GIFT_NY25_3012: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81023,
        offerNameAlias: "promo_offer_gift_cycle_7_11",
        price: (_2 = {}, _2[CURRENCY.BONUS] = 0, _2),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_3 = {}, _3[CURRENCY.TOKEN_2] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _3) } } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-30').getTime(),
            endGenerationBound: new Date('2025-12-31').getTime(),
        },
    }),
    PROMO_GIFT_NY25_3112: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81024,
        offerNameAlias: "promo_offer_gift_cycle_8_11",
        price: (_4 = {}, _4[CURRENCY.BONUS] = 0, _4),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2025-12-31').getTime(),
            endGenerationBound: new Date('2026-01-01').getTime(),
        },
    }),
    PROMO_GIFT_NY26_0101: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81025,
        offerNameAlias: "promo_offer_gift_cycle_9_11",
        price: (_5 = {}, _5[CURRENCY.BONUS] = 0, _5),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2026-01-01').getTime(),
            endGenerationBound: new Date('2026-01-02').getTime(),
        },
    }),
    PROMO_GIFT_NY25_0201: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81026,
        offerNameAlias: "promo_offer_gift_cycle_10_11",
        price: (_6 = {}, _6[CURRENCY.BONUS] = 0, _6),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Observatory_chest.ID, chests.Observatory_chest.ID] } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2026-01-02').getTime(),
            endGenerationBound: new Date('2026-01-03').getTime(),
        },
    }),
    PROMO_GIFT_NY25_0301: new PromoOffer({
        visualPresetId: "gift_NY",
        ID: 81027,
        offerNameAlias: "promo_offer_gift_cycle_11_11",
        price: (_7 = {}, _7[CURRENCY.BONUS] = 0, _7),
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        onceRepeatAfter: new Date("2025-12-11").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 40,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.TICKET_1] = [{ Weight: 1, Amount: new RndFromInterval(25) }], _8) } } }],
                },
            ]
        },
        activeTime: {
            startGenerationBound: new Date('2026-01-03').getTime(),
            endGenerationBound: new Date('2026-01-04').getTime(),
        },
    }),
    PROMO_Offer_67_1: new PromoOffer({
        ID: 81028,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_six",
        inApp: inAppSettings.PRICE_1.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 2.5,
        discount: "-60%",
        country: ["US"],
        sp: { min: 0.0, max: 0.49 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-18").getTime() },
        },
        productGroup: 81028,
        promoOfferGroup: 81028,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 41,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_9 = {}, _9[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(666) }], _9) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_2: new PromoOffer({
        ID: 81029,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_six",
        inApp: inAppSettings.PRICE_6.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 1.9,
        discount: "-45%",
        country: ["US"],
        sp: { min: 0.50, max: 9.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81029,
        promoOfferGroup: 81029,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 42,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_10 = {}, _10[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(6666) }], _10) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_3: new PromoOffer({
        ID: 81030,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_six",
        inApp: inAppSettings.PRICE_6.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 1.9,
        discount: "-45%",
        country: ["US"],
        sp: { min: 10.0, max: 89.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81030,
        promoOfferGroup: 81030,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 43,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_11 = {}, _11[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(6666) }], _11) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_4: new PromoOffer({
        ID: 81031,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_six",
        inApp: inAppSettings.PRICE_60_2.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 1.1,
        discount: "-10%",
        country: ["US"],
        sp: { min: 90.0, max: 999999.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81031,
        promoOfferGroup: 81031,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 44,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_12 = {}, _12[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(66666) }], _12) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_5: new PromoOffer({
        ID: 81032,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_seven",
        inApp: inAppSettings.PRICE_2.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 1.9,
        discount: "-45%",
        country: ["US"],
        sp: { min: 0.0, max: 0.49 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81032,
        promoOfferGroup: 81028,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 41,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Common_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_13 = {}, _13[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(777) }], _13) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_14 = {}, _14[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(777) }], _14) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_6: new PromoOffer({
        ID: 81033,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_seven",
        inApp: inAppSettings.PRICE_7.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 2.1,
        discount: "-50%",
        country: ["US"],
        sp: { min: 0.50, max: 9.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81033,
        promoOfferGroup: 81029,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 42,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_15 = {}, _15[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7777) }], _15) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_7: new PromoOffer({
        ID: 81034,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_seven",
        inApp: inAppSettings.PRICE_7.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 2.1,
        discount: "-50%",
        country: ["US"],
        sp: { min: 10.0, max: 89.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81034,
        promoOfferGroup: 81030,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 43,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_16 = {}, _16[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7777) }], _16) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_67_8: new PromoOffer({
        ID: 81035,
        visualPresetId: "meme_67",
        offerNameAlias: "promo_offer_seven",
        inApp: inAppSettings.PRICE_75.ProductID,
        activeTime: {
            startGenerationBound: new Date("2025-12-18").getTime(),
            endGenerationBound: new Date("2025-12-25").getTime(),
        },
        profit: 1.2,
        discount: "-15%",
        country: ["US"],
        sp: { min: 90.0, max: 999999.99 },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-12-17").getTime() },
        },
        productGroup: 81035,
        promoOfferGroup: 81031,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 44,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_17 = {}, _17[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(77777) }], _17) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Year_End_Deals_2025: new PromoOffer({
        ID: 81036,
        visualPresetId: "promo_event_offer",
        offerNameAlias: "promo_offer_newYear1",
        inApp: inAppSettings.PRICE_1.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-01-02").getTime(),
            endGenerationBound: new Date("2026-01-09").getTime(),
        },
        profit: 10.0,
        discount: "-90%",
        country: ["IN"],
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 45,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-25").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_18 = {}, _18[CURRENCY.TOKEN_1] = 5000, _18) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.CHIP_1] = 250, _19) }) } } }],
                },
            ]
        },
    }),
    PROMO_Nonna_Ads_1: new PromoOffer({
        ID: 81037,
        visualPresetId: "promo_nonna",
        offerNameAlias: "promo_offer_Nonna",
        inApp: inAppSettings.PRICE_3.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-01-02").getTime(),
            endGenerationBound: new Date("2026-01-10").getTime(),
        },
        profit: 2.0,
        discount: "-50%",
        companies: ["GA_SF4_AP_Andr_WW_CPA_RetargetQ5_AllLang_251225"],
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 46,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-26").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_20 = {}, _20[heroes.Nonna.ID] = 2, _20) }) } } }],
                },
            ]
        },
    }),
    PROMO_Nonna_Ads_2: new PromoOffer({
        ID: 81038,
        visualPresetId: "promo_nonna",
        offerNameAlias: "promo_offer_Nonna",
        inApp: inAppSettings.PRICE_4.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-01-02").getTime(),
            endGenerationBound: new Date("2026-01-10").getTime(),
        },
        profit: 1.5,
        discount: "-30%",
        companies: ["GA_SF4_AP_Andr_WW_CPA_RetargetQ5_AllLang_251225"],
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(81037, settings);
        },
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 47,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-26").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_21 = {}, _21[heroes.Nonna.ID] = 2, _21) }) } } }],
                },
            ]
        },
    }),
    PROMO_Nonna_Ads_3: new PromoOffer({
        ID: 81039,
        visualPresetId: "promo_nonna_no_sale",
        offerNameAlias: "promo_offer_Nonna",
        inApp: inAppSettings.PRICE_9.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-01-02").getTime(),
            endGenerationBound: new Date("2026-01-10").getTime(),
        },
        profit: 1.0,
        companies: ["GA_SF4_AP_Andr_WW_CPA_RetargetQ5_AllLang_251225"],
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(81038, settings);
        },
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 47,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        onceRepeatAfter: new Date("2025-12-26").getTime(),
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_22 = {}, _22[heroes.Nonna.ID] = 3, _22) }) } } }],
                },
            ]
        },
    }),
    PROMO_8_March_2026_1: new PromoOffer({
        ID: 81044,
        visualPresetId: "8_march_2026",
        offerNameAlias: "Women_day_W_DLG",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-03-08").getTime(),
            endGenerationBound: new Date("2026-03-12").getTime(),
        },
        profit: 4.2,
        discount: "-75%",
        sp: { min: 0.0, max: 0.49 },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        productGroup: 81044,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_23 = {}, _23[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2500) }], _23) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                },
            ]
        },
    }),
    PROMO_8_March_2026_2: new PromoOffer({
        ID: 81045,
        visualPresetId: "8_march_2026",
        offerNameAlias: "Women_day_W_DLG",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-03-08").getTime(),
            endGenerationBound: new Date("2026-03-12").getTime(),
        },
        profit: 2.6,
        discount: "-60%",
        sp: { min: 0.50, max: 9.99 },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        productGroup: 81045,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                },
            ]
        },
    }),
    PROMO_8_March_2026_3: new PromoOffer({
        ID: 81046,
        visualPresetId: "8_march_2026",
        offerNameAlias: "Women_day_W_DLG",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-03-08").getTime(),
            endGenerationBound: new Date("2026-03-12").getTime(),
        },
        profit: 2.4,
        discount: "-55%",
        sp: { min: 10.0, max: 89.99 },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        productGroup: 81046,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                },
            ]
        },
    }),
    PROMO_8_March_2026_4: new PromoOffer({
        ID: 81047,
        visualPresetId: "8_march_2026",
        offerNameAlias: "Women_day_W_DLG",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-03-08").getTime(),
            endGenerationBound: new Date("2026-03-12").getTime(),
        },
        profit: 1.4,
        discount: "-30%",
        sp: { min: 90.0, max: 999999.99 },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        productGroup: 81047,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_MK_2026: new PromoOffer({
        ID: 81048,
        visualPresetId: "hero_offer_MK",
        offerNameAlias: "promo_title_INACTIVE_PAY_5",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_100.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-03-06").getTime(),
            endGenerationBound: new Date('2026-03-11').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_24 = {},
            _24[CUSTOMIZATION.SKIN] = [skins.Monkey_King_L_Crystal.ID],
            _24),
        productGroup: 81048,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monkey_King_L_Crystal.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_25 = {}, _25[HeroNames.Monkey_King.ID] = 10, _25) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_26 = {}, _26[HeroNames.Monkey_King.ID] = 10, _26) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Lynx_2026: new PromoOffer({
        ID: 81049,
        visualPresetId: "expensive_lynx_leg_skin",
        offerNameAlias: "promo_title_INACTIVE_PAY_5",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_100.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-04-05").getTime(),
            endGenerationBound: new Date('2026-04-10').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_27 = {},
            _27[CUSTOMIZATION.SKIN] = [skins.Lynx_L_Hood.ID],
            _27),
        productGroup: 81049,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_L_Hood.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_28 = {}, _28[HeroNames.Lynx.ID] = 10, _28) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_29 = {}, _29[HeroNames.Lynx.ID] = 35, _29) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Itu_2026: new PromoOffer({
        ID: 81050,
        visualPresetId: "leg_itu_cosmic_big",
        offerNameAlias: "Itu",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_100.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-04-10").getTime(),
            endGenerationBound: new Date('2026-04-15').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_30 = {},
            _30[CUSTOMIZATION.SKIN] = [skins.Itu_L_Cosmic.ID],
            _30),
        productGroup: 81050,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_L_Cosmic.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_31 = {}, _31[HeroNames.Itu.ID] = 10, _31) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_32 = {}, _32[HeroNames.Itu.ID] = 10, _32) }) } } }],
                },
            ]
        },
    }),
    hidden_for_marathon_EarthDay_2026: new PromoOffer({
        ID: 81051,
        hiddenOffer: true,
        visualPresetId: "1348",
        offerNameAlias: "challenges_marathons_tab",
        inApp: inAppSettings.PRICE_5.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: PROMO_DURATION.TO_MARATHON_END },
        conditions: {},
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: { additionalPlaceHolder: [] },
        additionalSettings: {
            unlockRewardCollectingForMarathons: [30021],
        }
    }),
    PROMO_Offer_Expensive_Kibo_E_Gray_skin: new PromoOffer({
        ID: 81052,
        visualPresetId: "Kibo_E_Gray_skin_epic_hero",
        offerNameAlias: "Kibo",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-05-01").getTime(),
            endGenerationBound: new Date('2026-05-04').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_33 = {},
            _33[CUSTOMIZATION.SKIN] = [skins.Kibo_E_Gray_skin.ID],
            _33),
        productGroup: 81052,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Kibo_E_Gray_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_34 = {}, _34[HeroNames.Kibo.ID] = 20, _34) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_35 = {}, _35[HeroNames.Kibo.ID] = 50, _35) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_HongJoo_R_base_Rec_Flame: new PromoOffer({
        ID: 81053,
        visualPresetId: "HongJoo_R_base_Rec_Flame_rare_hero",
        offerNameAlias: "HongJoo",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_45.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-05-04").getTime(),
            endGenerationBound: new Date('2026-05-07').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_36 = {},
            _36[CUSTOMIZATION.SKIN] = [skins.HongJoo_R_base_Rec_Flame.ID],
            _36),
        productGroup: 81053,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.HongJoo_R_base_Rec_Flame.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_37 = {}, _37[HeroNames.HongJoo.ID] = 25, _37) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_38 = {}, _38[HeroNames.HongJoo.ID] = 50, _38) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Bulwark_R_Black_skin: new PromoOffer({
        ID: 81054,
        visualPresetId: "Bulwark_R_Black_skin_com_hero",
        offerNameAlias: heroes.Bulwark.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-05-07").getTime(),
            endGenerationBound: new Date('2026-05-10').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_39 = {},
            _39[CUSTOMIZATION.SKIN] = [skins.Bulwark_R_Black_skin.ID],
            _39),
        productGroup: 81054,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_R_Black_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_40 = {}, _40[HeroNames.Bulwark.ID] = 30, _40) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_41 = {}, _41[HeroNames.Bulwark.ID] = 100, _41) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Marcus_E_Lord_skin: new PromoOffer({
        ID: 81055,
        visualPresetId: "Marcus_E_Lord_skin_last_day_epic",
        offerNameAlias: heroes.Marcus.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-05-10").getTime(),
            endGenerationBound: new Date('2026-05-13').getTime(),
        },
        profit: 1.0,
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_42 = {},
            _42[CUSTOMIZATION.SKIN] = [skins.Marcus_E_Lord_skin.ID],
            _42),
        productGroup: 81055,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Marcus_E_Lord_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_43 = {}, _43[HeroNames.Marcus.ID] = 20, _43) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_44 = {}, _44[HeroNames.Marcus.ID] = 50, _44) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Lynx_E_Original: new PromoOffer({
        ID: 81056,
        visualPresetId: "epic_hero_Lynx_E_Original",
        offerNameAlias: heroes.Lynx.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-08").getTime(),
            endGenerationBound: new Date('2026-06-11').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_45 = {},
            _45[CUSTOMIZATION.SKIN] = [skins.Lynx_E_Original.ID],
            _45),
        productGroup: 81056,
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_46 = {}, _46[HeroNames.Lynx.ID] = 20, _46) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_47 = {}, _47[HeroNames.Lynx.ID] = 50, _47) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Yukka_R_Red: new PromoOffer({
        ID: 81057,
        visualPresetId: "rare_hero_Yukka_R_Red",
        offerNameAlias: heroes.Yukka.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-05").getTime(),
            endGenerationBound: new Date('2026-06-08').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_48 = {},
            _48[CUSTOMIZATION.SKIN] = [skins.Yukka_R_Red.ID],
            _48),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Yukka_R_Red.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_49 = {}, _49[HeroNames.Yukka.ID] = 10, _49) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_50 = {}, _50[HeroNames.Yukka.ID] = 100, _50) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Liquidator_E_White: new PromoOffer({
        ID: 81058,
        visualPresetId: "offer_with_image_com_Liquidator_E_White",
        offerNameAlias: heroes.Liquidator.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-11").getTime(),
            endGenerationBound: new Date('2026-06-14').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_51 = {},
            _51[CUSTOMIZATION.SKIN] = [skins.Liquidator_E_White.ID],
            _51),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Liquidator_E_White.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_52 = {}, _52[HeroNames.Liquidator.ID] = 30, _52) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_53 = {}, _53[HeroNames.Liquidator.ID] = 100, _53) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Helga_R_base_Rec_Unsight: new PromoOffer({
        ID: 81059,
        visualPresetId: "offer_with_image_rare_Helga_R_base_Rec_Unsight",
        offerNameAlias: heroes.Helga.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_45.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-14").getTime(),
            endGenerationBound: new Date('2026-06-17').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_54 = {},
            _54[CUSTOMIZATION.SKIN] = [skins.Helga_R_base_Rec_Unsight.ID],
            _54),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Helga_R_base_Rec_Unsight.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_55 = {}, _55[HeroNames.Helga.ID] = 25, _55) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_56 = {}, _56[HeroNames.Helga.ID] = 50, _56) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Ling_E_Ronin: new PromoOffer({
        ID: 81060,
        visualPresetId: "offer_with_image_rare_Ling_E_Ronin",
        offerNameAlias: heroes.Ling.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-17").getTime(),
            endGenerationBound: new Date('2026-06-20').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_57 = {},
            _57[CUSTOMIZATION.SKIN] = [skins.Ling_E_Ronin.ID],
            _57),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ling_E_Ronin.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_58 = {}, _58[HeroNames.Ling.ID] = 10, _58) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_59 = {}, _59[HeroNames.Ling.ID] = 100, _59) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Feldsher_E_Plague_Rec_Vampire: new PromoOffer({
        ID: 81061,
        visualPresetId: "offer_with_image_com_Feldsher_E_Plague_Rec_Vampire",
        offerNameAlias: heroes.Feldsher.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-20").getTime(),
            endGenerationBound: new Date('2026-06-23').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_60 = {},
            _60[CUSTOMIZATION.SKIN] = [skins.Feldsher_E_Plague_Rec_Vampire.ID],
            _60),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Feldsher_E_Plague_Rec_Vampire.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_61 = {}, _61[HeroNames.Feldsher.ID] = 30, _61) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_62 = {}, _62[HeroNames.Feldsher.ID] = 100, _62) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Midnight_R_Blue: new PromoOffer({
        ID: 81062,
        visualPresetId: "epic_hero_Midnight_R_Blue",
        offerNameAlias: heroes.Midnight.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_45.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-23").getTime(),
            endGenerationBound: new Date('2026-06-26').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_63 = {},
            _63[CUSTOMIZATION.SKIN] = [skins.Midnight_R_Blue.ID],
            _63),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Midnight_R_Blue.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_64 = {}, _64[HeroNames.Midnight.ID] = 10, _64) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_65 = {}, _65[HeroNames.Midnight.ID] = 35, _65) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Feldsher_E_Diver_Rec_Heated: new PromoOffer({
        ID: 81063,
        visualPresetId: "offer_hero_feldsher_rework_Feldsher_E_Diver_Rec_Heated",
        offerNameAlias: heroes.Feldsher.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-18").getTime(),
            endGenerationBound: new Date('2026-06-22').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_66 = {},
            _66[CUSTOMIZATION.SKIN] = [skins.Feldsher_E_Diver_Rec_Heated.ID],
            _66),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Feldsher_E_Diver_Rec_Heated.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_67 = {}, _67[HeroNames.Feldsher.ID] = 30, _67) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_68 = {}, _68[HeroNames.Feldsher.ID] = 100, _68) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Sarge_E_Jailer: new PromoOffer({
        ID: 81064,
        visualPresetId: "offer_with_image_rare_Sarge_E_Jailer",
        offerNameAlias: heroes.Sarge.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-26").getTime(),
            endGenerationBound: new Date('2026-06-29').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_69 = {},
            _69[CUSTOMIZATION.SKIN] = [skins.Sarge_E_Jailer.ID],
            _69),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Sarge_E_Jailer.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_70 = {}, _70[HeroNames.Sarge.ID] = 10, _70) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_71 = {}, _71[HeroNames.Sarge.ID] = 100, _71) }) } } }],
                },
            ]
        },
    }),
    PROMO_Offer_Expensive_Legion_King_R_Viny: new PromoOffer({
        ID: 81065,
        visualPresetId: "offer_with_image_leg_Legion_King_R_Viny",
        offerNameAlias: heroes.Legion_King.Alias,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_45.ProductID,
        activeTime: {
            startGenerationBound: new Date("2026-06-29").getTime(),
            endGenerationBound: new Date('2026-07-02').getTime(),
        },
        conditions: { accountLevel: { more_or_equal: 2 }, },
        noCustomizeExist: (_72 = {},
            _72[CUSTOMIZATION.SKIN] = [skins.Legion_King_R_Viny.ID],
            _72),
        enablePopup: true,
        popupSettings: {
            popUpId: 48,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_R_Viny.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_73 = {}, _73[HeroNames.Legion_King.ID] = 10, _73) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_74 = {}, _74[HeroNames.Legion_King.ID] = 10, _74) }) } } }],
                },
            ]
        },
    }),
    PROMO_Free_Toffee_5: new PromoOffer({
        ID: 81066,
        visualPresetId: "offer_toffee_pay",
        offerNameAlias: "promo_title_toffee_pay",
        profit: 10.0,
        inApp: inAppSettings.PRICE_5.ProductID,
        discount: "-90%",
        activeTime: {
            startGenerationBound: new Date("2026-07-02").getTime(),
            endGenerationBound: new Date('2026-08-02').getTime(),
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            accountTagsOneOf: ["free_toffee_not_p"],
        },
        customCondition: function (args) {
            return useToffeeInsteadOfDefaultPayment({
                settings: args.regionalSettings,
                worldContainer: args.world,
            });
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_75 = {}, _75[CURRENCY.GACHA_KEY] = 5, _75) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_76 = {}, _76[CURRENCY.BONUS] = 650, _76) }) } } }],
                },
            ]
        },
    }),
    PROMO_Free_Toffee_10: new PromoOffer({
        ID: 81067,
        visualPresetId: "offer_toffee_pay",
        offerNameAlias: "promo_title_toffee_pay",
        profit: 2.1,
        inApp: inAppSettings.PRICE_10.ProductID,
        discount: "-50%",
        activeTime: {
            startGenerationBound: new Date("2026-07-02").getTime(),
            endGenerationBound: new Date('2026-08-02').getTime(),
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
            accountTagsOneOf: ["free_toffee_p"],
        },
        customCondition: function (args) {
            return useToffeeInsteadOfDefaultPayment({
                settings: args.regionalSettings,
                worldContainer: args.world,
            });
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_77 = {}, _77[CURRENCY.BONUS] = 300, _77) }) } } }],
                },
            ]
        },
    }),
}, true);
