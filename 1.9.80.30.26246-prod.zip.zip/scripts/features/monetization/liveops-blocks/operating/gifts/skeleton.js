var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
offerSkeletons.Gift_Carnaval_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 7.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRY_1 ? [VARS.COUNTRY_1] : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Gift_Easter_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-35%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 7.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-10%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Gift_Easter_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 10.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _a) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 9.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-45%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_2,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[2],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        noHeroExist: [VARS.HERO_1],
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.SKIN] = [VARS.SKIN_1],
                        _a),
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [VARS.SKIN_1] }) } } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
    ]
};
offerSkeletons.Gift_International_Customize_Chests = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0, max: 0.49 },
                profit: 12.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.50, max: 9.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Small_Shard_Chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 10, max: 89.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Medium_Shard_Chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP",
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 99999.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    productGroup: OFFERS[1],
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    country: VARS.COUNTRIES_1 ? __spreadArray([], VARS.COUNTRIES_1, true) : undefined,
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { chests: [chests.Mythic_chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                            },
                            {
                                front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                                back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP",
        },
    ],
};
