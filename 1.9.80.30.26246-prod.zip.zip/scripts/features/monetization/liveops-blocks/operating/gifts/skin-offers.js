offerSkins.Gift_Easter_Jet_E_Golden_EU = {
    skeleton: offerSkeletons.Gift_Easter_Rare,
    offersIdGenerator: function (index) { return 104561 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        SKIN_1: skins.Jet_E_Golden.ID,
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        VISUAL_PRESET_2: "gift_hero_Jet_E_Golden",
        START_DATE: new Date("2026-04-05").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Gift_Easter_EU",
        COUNTRIES_1: [
            "AD", 'AM', "AT", "BE",
            "CH", "CZ", "DE", "DK",
            "EE", "ES", "FI", "FR",
            "GB", "GI", "HR", "HU",
            "IE", "IM", "IS", "IT",
            "JE", "LT", "LU", "LV",
            "MC", "MT", "NL", "NO",
            "PL", "PT", "SE", "SI",
            "SK", "SM"
        ]
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_Cinmin_Monkey_King_E_Cruel_CN = {
    skeleton: offerSkeletons.Gift_Easter_Leg,
    offersIdGenerator: function (index) { return 104573 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Monkey_King.ID,
        SKIN_1: skins.Monkey_King_E_cruel.ID,
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        VISUAL_PRESET_2: "gift_hero_Monkey_King_E_cruel",
        START_DATE: new Date("2026-04-05").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Gift_Cinmin_CN",
        COUNTRIES_1: ["CN"],
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_Easter_Jet_E_Golden_CIS = {
    skeleton: offerSkeletons.Gift_Easter_Rare,
    offersIdGenerator: function (index) { return 104585 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        SKIN_1: skins.Jet_E_Golden.ID,
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        VISUAL_PRESET_2: "gift_hero_Jet_E_Golden",
        START_DATE: new Date("2026-04-12").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Gift_Easter_CIS",
        COUNTRIES_1: [
            "BG", "BY", "CY", "GR",
            "MD", "RO", "RU", "UA",
        ]
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_Witch_Night = {
    skeleton: offerSkeletons.Gift_Super_Bowl,
    offersIdGenerator: function (index) { return 104400 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        START_DATE: new Date("2026-04-29").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Witch_Night",
        COUNTRIES_1: [
            "DE", "SE", 'FI',
            "CZ", "EE",
        ],
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_Witch_Night = {
    skeleton: offerSkeletons.Gift_Super_Bowl,
    offersIdGenerator: function (index) { return 104404 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        START_DATE: new Date("2026-05-17").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "WTICT",
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_Memorial_2026 = {
    skeleton: offerSkeletons.Gift_International_Customize_Chests,
    offersIdGenerator: function (index) { return 104408 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        COUNTRIES_1: ["US", "CA"],
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        START_DATE: new Date("2026-05-25").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Memorial"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_EidAl_2026 = {
    skeleton: offerSkeletons.Gift_International_Customize_Chests,
    offersIdGenerator: function (index) { return 104412 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        COUNTRIES_1: [
            "SA", "AE", "QA",
            "KW", "OM", "TR",
            "EG", "PK", "BD",
            "ID", "IR",
        ],
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        START_DATE: new Date("2026-05-26").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "EidAl"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gift_July_2026 = {
    skeleton: offerSkeletons.Gift_International_Customize_Chests,
    offersIdGenerator: function (index) { return 104416 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Gift_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        ALIAS_1: "title_promo_offer_labour_day",
        VISUAL_PRESET_1: "cycle_weekly_epic",
        START_DATE: new Date("2026-07-19").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "July"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
