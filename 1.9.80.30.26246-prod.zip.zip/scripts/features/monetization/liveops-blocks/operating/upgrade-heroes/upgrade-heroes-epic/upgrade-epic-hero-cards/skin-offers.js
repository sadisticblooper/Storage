offerSkins.Butcher_Cards_Sale_Epic = {
    skeleton: offerSkeletons.Cards_Sale_Epic,
    offersIdGenerator: function (index) { return 104008 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Cards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-03-10").getTime(),
    vars: {
        HERO_1: heroes.Butcher.ID,
        ALIAS_1: "Butcher",
        VISUAL_PRESET_1: "5120",
        START_DATE: new Date("2026-03-19").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Butcher_03_19"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Lynx_Cards_Sale_Epic = {
    skeleton: offerSkeletons.Cards_Sale_Epic,
    offersIdGenerator: function (index) { return 104012 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Cards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-03-10").getTime(),
    vars: {
        HERO_1: heroes.Lynx.ID,
        ALIAS_1: "Lynx",
        VISUAL_PRESET_1: "5136",
        START_DATE: new Date("2026-03-22").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Lynx_03_22"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Butcher_Promo_up_28_Mar = {
    skeleton: offerSkeletons.PROMO_up_cart_Epic,
    offersIdGenerator: function (index) { return 104016 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_up_cart_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-03-26").getTime(),
    vars: {
        HERO_1: heroes.Butcher.ID,
        ALIAS_1: "Butcher",
        VISUAL_PRESET_1: "5120",
        START_DATE: new Date("2026-03-28").getTime(),
        DURATION_DATE_1: 5,
        NAME_PREFIX: "Butcher_28_Mar"
    },
    offers: new Array(5).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Widow_Cards_Mini_Sale_12_Apr = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Epic,
    offersIdGenerator: function (index) { return 104021 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Cards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Widow.ID,
        ALIAS_1: "Widow",
        VISUAL_PRESET_1: "5138",
        START_DATE: new Date("2026-04-11").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Mini_Widow"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Butcher_Cards_Mini_Sale_Epic = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Epic,
    offersIdGenerator: function (index) { return 104029 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        ALIAS_1: heroes.Butcher.Alias,
        VISUAL_PRESET_1: "epic_hero_butcher",
        START_DATE: new Date("2026-06-17").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Butcher"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Gideon_Cards_Mini_Sale_Epic = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Epic,
    offersIdGenerator: function (index) { return 104033 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        ALIAS_1: heroes.Gideon.Alias,
        VISUAL_PRESET_1: "epic_hero_Gideon",
        START_DATE: new Date("2026-06-19").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Gideon"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Xiang_Tzu_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Epic,
    offersIdGenerator: function (index) { return 104037 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Xiang_Tzu.ID,
        ALIAS_1: heroes.Xiang_Tzu.Alias,
        VISUAL_PRESET_1: "xiang_Tzu_epic_hero",
        START_DATE: new Date("2026-07-25").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Xiang_Tzu"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
