offerSkins.Hero_Sale_Shards_Ironclad = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 100496 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_L_Bull_Ironclad_alias",
        START_DATE: new Date("2026-05-16").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "Ironclad"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Ironclad_Re = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 100520 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_L_Bull_Ironclad_alias",
        START_DATE: new Date("2026-05-29").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "Ironclad"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Kibo = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100544 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Kibo.ID,
        ALIAS_1: "Kibo",
        VISUAL_PRESET_1: "epic_hero_kibo",
        START_DATE: new Date("2026-06-05").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Kibo"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Emperor = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100568 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Emperor.ID,
        ALIAS_1: heroes.Emperor.Alias,
        VISUAL_PRESET_1: "epic_hero_emperor",
        START_DATE: new Date("2026-06-07").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Emperor"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Butcher = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100400 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        ALIAS_1: heroes.Butcher.Alias,
        VISUAL_PRESET_1: "epic_hero_butcher",
        START_DATE: new Date("2026-06-09").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Butcher"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Lynx = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100424 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Lynx.ID,
        ALIAS_1: heroes.Lynx.Alias,
        VISUAL_PRESET_1: "lynx_1111",
        START_DATE: new Date("2026-06-18").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "Lynx"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Midnight = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100448 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        ALIAS_1: heroes.Midnight.Alias,
        VISUAL_PRESET_1: "epic_hero_Midnight",
        START_DATE: new Date("2026-07-03").getTime(),
        DURATION_DATE_1: 5,
        NAME_PREFIX: "Midnight"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Gideon = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100472 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "epic_hero_Gideon_alias",
        START_DATE: new Date("2026-07-27").getTime(),
        DURATION_DATE_1: 5,
        NAME_PREFIX: "Gideon"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
