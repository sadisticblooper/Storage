offerSkins.Hero_Sale_Cards_Midnight = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100200 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        ALIAS_1: heroes.Midnight.Alias,
        VISUAL_PRESET_1: "epic_hero_Midnight",
        START_DATE: new Date("2026-07-03").getTime(),
        DURATION_DATE_1: 5,
        NAME_PREFIX: "Midnight"
    },
    offers: new Array(30).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Gideon = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Epic,
    offersIdGenerator: function (index) { return 100230 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "epic_hero_Gideon_alias",
        START_DATE: new Date("2026-07-27").getTime(),
        DURATION_DATE_1: 5,
        NAME_PREFIX: "Gideon"
    },
    offers: new Array(30).join("0").split("0").map(function (_) { return { common: {} }; }),
};
