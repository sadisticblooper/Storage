offerSkins.Ling_Shards_Sale_Rare = {
    skeleton: offerSkeletons.Shards_Sale_Rare,
    offersIdGenerator: function (index) { return 34112 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Shards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-02").getTime(),
    vars: {
        HERO_1: heroes.Ling.ID,
        ALIAS_1: "Ling",
        VISUAL_PRESET_1: "offer_with_image_rare_Ling",
        START_DATE: new Date("2026-02-11").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Ling"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Sarge_Shards_Sale_Rare = {
    skeleton: offerSkeletons.Shards_Sale_Rare,
    offersIdGenerator: function (index) { return 34116 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Shards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-02").getTime(),
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "Sarge",
        VISUAL_PRESET_1: "5011",
        START_DATE: new Date("2026-02-13").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Helga_Shards_Sale_Rare = {
    skeleton: offerSkeletons.Shards_Sale_Rare,
    offersIdGenerator: function (index) { return 34124 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_".concat(vars.NAME_PREFIX, "_Shards_Sale_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-20").getTime(),
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: "Helga",
        VISUAL_PRESET_1: "offer_with_image_rare_Helga",
        START_DATE: new Date("2026-03-07").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Helga_Mar"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Helga_Shards_Mini_Sale = {
    skeleton: offerSkeletons.Shards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34132 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: heroes.Helga.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Helga",
        START_DATE: new Date("2026-05-14").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Helga"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Jet_Shards_Mini_Sale = {
    skeleton: offerSkeletons.Shards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34140 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        ALIAS_1: heroes.Jet.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Jet",
        START_DATE: new Date("2026-06-21").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Jet",
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Viper_Shards_Mini_Sale = {
    skeleton: offerSkeletons.Shards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34144 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Viper.ID,
        ALIAS_1: heroes.Viper.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Viper",
        START_DATE: new Date("2026-07-21").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Viper"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.HongJoo_Shards_Mini_Sale = {
    skeleton: offerSkeletons.Shards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34148 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.HongJoo.ID,
        ALIAS_1: heroes.HongJoo.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_HongJoo",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "HongJoo",
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Yunlin_Shards_Mini_Sale = {
    skeleton: offerSkeletons.Shards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34152 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Yunlin.ID,
        ALIAS_1: heroes.Yunlin.Alias,
        VISUAL_PRESET_1: "basic_hero_Yunlin",
        START_DATE: new Date("2026-07-27").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Yunlin"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
