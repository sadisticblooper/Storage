offerSkins.Ling_Cards_Sale_Rare = {
    skeleton: offerSkeletons.Cards_Sale_Rare,
    offersIdGenerator: function (index) { return 34001 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Cards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-02").getTime(),
    vars: {
        HERO_1: heroes.Ling.ID,
        ALIAS_1: "Ling",
        VISUAL_PRESET_1: "offer_with_image_rare_Ling",
        START_DATE: new Date("2026-02-11").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Ling"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Sarge_Cards_Sale_Rare = {
    skeleton: offerSkeletons.Cards_Sale_Rare,
    offersIdGenerator: function (index) { return 34005 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Cards_Sale_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-02").getTime(),
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "Sarge",
        VISUAL_PRESET_1: "5011",
        START_DATE: new Date("2026-02-13").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Helga_Cards_Sale_Rare = {
    skeleton: offerSkeletons.Cards_Sale_Rare,
    offersIdGenerator: function (index) { return 34013 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_".concat(vars.NAME_PREFIX, "_Cards_Sale_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-02-20").getTime(),
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: "Helga",
        VISUAL_PRESET_1: "offer_with_image_rare_Helga",
        START_DATE: new Date("2026-03-07").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Helga_Mar"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Helga_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34021 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: heroes.Helga.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Helga",
        START_DATE: new Date("2026-05-14").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Helga"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Jet_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34029 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        ALIAS_1: heroes.Jet.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Jet",
        START_DATE: new Date("2026-06-21").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Jet"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Viper_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34033 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Viper.ID,
        ALIAS_1: heroes.Viper.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_Viper",
        START_DATE: new Date("2026-07-21").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Viper"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hongjoo_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34037 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.HongJoo.ID,
        ALIAS_1: heroes.HongJoo.Alias,
        VISUAL_PRESET_1: "offer_with_image_rare_HongJoo",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "HongJoo"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Yunlin_Cards_Mini_Sale = {
    skeleton: offerSkeletons.Cards_Mini_Sale_Rare,
    offersIdGenerator: function (index) { return 34041 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Mini_Up_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Yunlin.ID,
        ALIAS_1: heroes.Yunlin.Alias,
        VISUAL_PRESET_1: "basic_hero_Yunlin",
        START_DATE: new Date("2026-07-27").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Yunlin"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
