offerSkins.Hero_Sale_Shards_Jet = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Rare,
    offersIdGenerator: function (index) { return 107948 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Rare_Up_Chain_".concat(vars.NAME_PREFIX, "_Shards_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Jet",
        START_DATE: new Date("2026-04-27").getTime(),
        DURATION_DATE_1: 4,
        NAME_PREFIX: "Jet"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Sarge = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Rare_Leg_Event,
    offersIdGenerator: function (index) { return 107972 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Up_Chain_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_midsommar_Sarge_alias",
        START_DATE: new Date("2026-06-15").getTime(),
        DURATION_DATE_1: 6,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Helga = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Rare_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 107996 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Helga",
        START_DATE: new Date("2026-07-14").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Helga"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Sarge_exp = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Rare_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 108020 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Up_Chain_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Sarge",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
