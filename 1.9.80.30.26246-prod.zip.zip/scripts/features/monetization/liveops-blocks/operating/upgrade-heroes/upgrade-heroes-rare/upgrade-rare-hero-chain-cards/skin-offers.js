offerSkins.Hero_Sale_Cards_Jet = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Rare,
    offersIdGenerator: function (index) { return 107656 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Rare_Up_Chain_".concat(vars.NAME_PREFIX, "_Cards_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Jet.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Jet",
        START_DATE: new Date("2026-04-27").getTime(),
        DURATION_DATE_1: 4,
        NAME_PREFIX: "Jet"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Sarge = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Rare_Leg_Event,
    offersIdGenerator: function (index) { return 107684 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Up_Chain_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_midsommar_Sarge_alias",
        START_DATE: new Date("2026-06-15").getTime(),
        DURATION_DATE_1: 6,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Helga = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Rare_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 107712 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Helga.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Helga",
        START_DATE: new Date("2026-07-14").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Helga"
    },
    offers: new Array(30).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Sarge_new = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Rare_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 107742 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Sarge",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Sarge"
    },
    offers: new Array(30).join("0").split("0").map(function (_) { return { common: {} }; }),
};
