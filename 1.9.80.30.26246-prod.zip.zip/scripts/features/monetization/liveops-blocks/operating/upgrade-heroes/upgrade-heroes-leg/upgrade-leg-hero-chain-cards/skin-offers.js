offerSkins.June_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg,
    offersIdGenerator: function (index) { return 103200 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.June.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_June_alias",
        START_DATE: new Date("2026-06-29").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "June"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Monkey_King_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg,
    offersIdGenerator: function (index) { return 103228 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Monkey_King.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_Monkey_King_alias",
        START_DATE: new Date("2026-07-01").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Monkey_King"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Itu_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg,
    offersIdGenerator: function (index) { return 103256 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Itu.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_Itu_alias",
        START_DATE: new Date("2026-07-03").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Itu"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Legion_King_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg,
    offersIdGenerator: function (index) { return 103284 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_LK_alias",
        START_DATE: new Date("2026-07-05").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Legion_King"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Nonna_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg,
    offersIdGenerator: function (index) { return 103312 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Nonna.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_Nonna_alias",
        START_DATE: new Date("2026-07-07").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Nonna"
    },
    offers: new Array(28).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.LK_Cards_Sale_Leg = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Leg_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 103340 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_leg_LK_alias",
        START_DATE: new Date("2026-07-20").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "LK"
    },
    offers: new Array(30).join("0").split("0").map(function (_) { return { common: {} }; }),
};
