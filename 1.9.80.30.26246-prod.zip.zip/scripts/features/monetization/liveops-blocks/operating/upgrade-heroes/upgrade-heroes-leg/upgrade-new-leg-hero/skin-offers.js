offerSkins.Upgrade_New_Shogun_Cards = {
    skeleton: offerSkeletons.New_Leg_Hero_Cards_Shogun_Release,
    offersIdGenerator: function (index) { return 106439 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_New_Hero_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Shogun.ID,
        START_DATE: new Date("2026-07-09").getTime(),
        DURATION_DATE_1: 21,
        ALIAS_1: "promo_offer_Shogun",
        VISUAL_PRESET_1: "offer_hero_Shogun_2",
        NAME_PREFIX: "Shogun_Cards",
    },
    offers: new Array(25).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Upgrade_New_Shogun_Shards = {
    skeleton: offerSkeletons.New_Leg_Hero_Shards_Shogun_Release,
    offersIdGenerator: function (index) { return 106464 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_New_Hero_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Shogun.ID,
        START_DATE: new Date("2026-07-09").getTime(),
        DURATION_DATE_1: 21,
        ALIAS_1: "promo_offer_Shogun",
        VISUAL_PRESET_1: "offer_hero_Shogun_2",
        NAME_PREFIX: "Shogun_Shards",
    },
    offers: new Array(14).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Upgrade_New_Shogun_Super = {
    skeleton: offerSkeletons.New_Leg_Hero_Super_Shogun_Release,
    offersIdGenerator: function (index) { return 106478 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_New_Hero_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Shogun.ID,
        START_DATE: new Date("2026-07-09").getTime(),
        DURATION_DATE_1: 21,
        ALIAS_1: "promo_offer_Shogun",
        VISUAL_PRESET_1: "offer_hero_Shogun_2",
        NAME_PREFIX: "Shogun_Super",
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
