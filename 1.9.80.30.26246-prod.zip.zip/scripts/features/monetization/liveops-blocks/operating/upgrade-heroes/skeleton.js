offerSkeletons.Cards_Chain_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 85, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 120, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 130, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 130, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 140, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 140, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 20.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-95%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 13.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 11.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 15.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 8.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 7.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 7.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 120, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 175, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 120, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 175, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 5, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 5, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 15.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 9.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 8.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 9.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: " -80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: " -80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: " -65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: " -50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: " -50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: " -55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: " -50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 1, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 400, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 1, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 1, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 1, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 850, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90.0, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 70, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 9.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-85%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 20, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-75%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 9.99 },
                profit: 6.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 185, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 25, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-55%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 10.0, max: 89.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 190, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 30, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 85, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 90, max: 9999999 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ],
};
offerSkeletons.Shards_Chain_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(20000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(20000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(20000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_55.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(40000) }], _c) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 550, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 650, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 850, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 400, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 650, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 950, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Com_Leg_Event = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 450, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 6, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_6"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 4000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 4000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 2500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 7, less: 8 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 3500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 4000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less: 13 } },
                            _a)
                    },
                    productGroup: OFFERS[6],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 4000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Rare_Leg_Event = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 550, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 650, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 850, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 150, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 400, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 3, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_14.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 600, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 900, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 11 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 350, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 650, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 950, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 1250, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Rare_Leg_Event_Expensive = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 222, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 333, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 555, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 888, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 222, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 222, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 222, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 333, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 333, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 353, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 353, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 135, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 2.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 333, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 555, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 707, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 550, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 550, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 200, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 303, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 505, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 700, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 555, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 333, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 88, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 88, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 333, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 555, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-35%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 888, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 11 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 888, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 333, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 2, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 80, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 300, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 500, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 9 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-30%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 10, less_or_equal: 11 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 800, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 800, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Com_Leg_Event = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 11.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 7.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 1.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-30%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-30%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 220, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Com_Leg_Event_Expensive = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 45, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 77, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 110, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 88, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 115, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 1.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 88, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 77, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 33, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 99, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 66, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 15, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 46, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 88, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 88, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Rare_Leg_Event = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_1.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 6.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 7.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 8.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-80%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 6.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 10000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 20000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 15000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 20000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 5000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 20000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_55.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 40000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Rare_Leg_Event_Expensive = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-60%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 2.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 22, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 10000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 15000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-40%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 20000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-40%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 5000, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-30%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 10000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-30%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 50, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 10000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_55.ProductID,
                discount: "-30%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 30000, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
offerSkeletons.Cards_Chain_Sale_Leg_Leg_Event_Expensive = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_3.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 12, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 5.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 75, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 888, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 22, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 33, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 80, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.9,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 111, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 17, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_12.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 85, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 115, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 90, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 120, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 37, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 95, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 60, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 60, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_5"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 4, less_or_equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 27, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 6 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { equal: 7 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_100.ProductID,
                discount: "-1%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 8, less_or_equal: 10 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 55, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 55, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400, max: 99999.99 },
                profit: 1.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_120.ProductID,
                discount: "-10%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { Level: { more_or_equal: 11, less_or_equal: 12 } },
                            _a)
                    },
                    productGroup: OFFERS[5],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[VARS.HERO_1] = 65, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 65, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_5"
        },
    ]
};
offerSkeletons.Shards_Chain_Sale_Leg_Leg_Event_Expensive = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_7.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 0.49 },
                profit: 4.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 30, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-70%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_13.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 16, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 24, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.5, max: 19.99 },
                profit: 3.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 32, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-65%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 26, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.0, max: 49.99 },
                profit: 3.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 45, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-50%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 22, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 28, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 99.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 36, _b) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-30%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_35.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 8, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 8, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_45.ProductID,
                discount: "-25%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 100.0, max: 399.99 },
                profit: 1.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-20%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 11, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HMP_4"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-15%",
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    customCondition: function (settings) {
                        return HeroUtils.checkIfNoHeroOrNoTalents(settings.playerProgress.heroes, VARS.HERO_1);
                    },
                    productGroup: OFFERS[1],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[VARS.HERO_1] = 10, _a) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_1"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
                discount: "-15%"
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 1, less: 3 } },
                            _a)
                    },
                    productGroup: OFFERS[2],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_2"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { more_or_equal: 3, less: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[3],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 12, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 12, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_3"
        },
        {
            common: {
                conditions: {},
                sp: { min: 400.0, max: 99999.99 },
                profit: 1.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_75.ProductID,
                discount: "-15%",
                customSpTable: PromoOfferConstants.chainUpgradeHeroSpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                        heroesOneOfExist: [VARS.HERO_1],
                        heroes: (_a = {},
                            _a[VARS.HERO_1] = { TalentLevel: { equal: 5 } },
                            _a)
                    },
                    productGroup: OFFERS[4],
                    sellHeroSettings: {
                        heroId: VARS.HERO_1,
                        sortingWeight: 1,
                        sellingPromoType: GAME_ENTITY.OFFER,
                    },
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP_4"
        },
    ]
};
