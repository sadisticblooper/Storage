offerSkins.Hero_Sale_Shards_Fireguard = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com,
    offersIdGenerator: function (index) { return 105416 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-10-06").getTime(),
    vars: {
        HERO_1: heroes.Fireguard.ID,
        ALIAS_1: "Fireguard",
        VISUAL_PRESET_1: "offer_with_image_com_Fireguard",
        START_DATE: new Date("2025-10-17").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Fireguard_17_10"
    },
    offers: new Array(16).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Ironclad = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com,
    offersIdGenerator: function (index) { return 105432 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-10-06").getTime(),
    vars: {
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: "Ironclad",
        VISUAL_PRESET_1: "offer_with_image_com_Ironclad",
        START_DATE: new Date("2025-10-19").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Fireguard_19_10"
    },
    offers: new Array(16).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Monk = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com,
    offersIdGenerator: function (index) { return 105448 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2025-10-06").getTime(),
    vars: {
        HERO_1: heroes.Monk.ID,
        ALIAS_1: "Monk",
        VISUAL_PRESET_1: "offer_with_image_com_Monk",
        START_DATE: new Date("2025-10-21").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Monk_21_10"
    },
    offers: new Array(16).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Feldsher = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 105464 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_feldsher_rework",
        START_DATE: new Date("2026-06-18").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "Feldsher"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Feldsher_exp = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 105488 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_com_alias_Feldsher",
        START_DATE: new Date("2026-07-11").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Feldsher"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Liquidator = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 105512 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Liquidator.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Liquidator",
        START_DATE: new Date("2026-07-17").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Liquidator"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Shards_Bulwark = {
    skeleton: offerSkeletons.Shards_Chain_Sale_Com_Leg_Event_Expensive,
    offersIdGenerator: function (index) { return 105536 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Shards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Bulwark.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Bulwark",
        START_DATE: new Date("2026-07-20").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Bulwark"
    },
    offers: new Array(24).join("0").split("0").map(function (_) { return { common: {} }; }),
};
