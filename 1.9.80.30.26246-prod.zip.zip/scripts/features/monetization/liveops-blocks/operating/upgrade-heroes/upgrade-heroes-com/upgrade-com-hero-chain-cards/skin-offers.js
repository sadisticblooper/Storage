offerSkins.Hero_Sale_Cards_Feldsher = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 105276 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_hero_feldsher_rework",
        START_DATE: new Date("2026-06-18").getTime(),
        DURATION_DATE_1: 7,
        NAME_PREFIX: "Feldsher"
    },
    offers: new Array(34).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Feldsher_exp = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 105310 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_com_alias_Feldsher",
        START_DATE: new Date("2026-07-11").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Feldsher"
    },
    offers: new Array(34).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Liquidator = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 105344 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Liquidator.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Liquidator",
        START_DATE: new Date("2026-07-17").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Liquidator"
    },
    offers: new Array(34).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Hero_Sale_Cards_Bulwark = {
    skeleton: offerSkeletons.Cards_Chain_Sale_Com_Leg_Event,
    offersIdGenerator: function (index) { return 105200 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Hero_Sale_Cards_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Bulwark.ID,
        ALIAS_1: "promo_title_INACTIVE_PAY_5",
        VISUAL_PRESET_1: "offer_with_image_alias_Bulwark",
        START_DATE: new Date("2026-07-20").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Bulwark"
    },
    offers: new Array(34).join("0").split("0").map(function (_) { return { common: {} }; }),
};
