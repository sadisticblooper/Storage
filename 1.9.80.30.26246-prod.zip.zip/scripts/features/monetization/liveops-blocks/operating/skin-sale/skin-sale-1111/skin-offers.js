offerSkins.Epic_Skin_1111_Itu_E_Demon = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Leg,
    offersIdGenerator: function (index) { return 105600 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Itu_E_Demon.ID,
        HERO_1: heroes.Itu.ID,
        ALIAS_1: heroes.Itu.Alias,
        VISUAL_PRESET_1: "Itu_E_Demon_cyberweek_hero",
        START_DATE: new Date("2026-01-09").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Itu_E_Demon"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Ling_E_Ronin_Rec_Black = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Rare,
    offersIdGenerator: function (index) { return 105616 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Ling_E_Ronin_Rec_Black.ID,
        HERO_1: heroes.Ling.ID,
        ALIAS_1: heroes.Ling.Alias,
        VISUAL_PRESET_1: "Ling_E_Ronin_Rec_Black_cyberweek_hero",
        START_DATE: new Date("2026-05-11").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Ling_E_Ronin_Rec_Black"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Feldsher_E_Suit_skin = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Com,
    offersIdGenerator: function (index) { return 105624 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Feldsher_E_Suit_skin.ID,
        HERO_1: heroes.Feldsher.ID,
        ALIAS_1: heroes.Feldsher.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Feldsher_E_Suit_skin",
        START_DATE: new Date("2026-06-04").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Feldsher_E_Suit_skin"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Monk_E_Cursed = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Com,
    offersIdGenerator: function (index) { return 105632 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Monk_E_Cursed.ID,
        HERO_1: heroes.Monk.ID,
        ALIAS_1: heroes.Monk.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Monk_E_Cursed",
        START_DATE: new Date("2026-06-06").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Monk_E_Cursed"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Itu_R_Star = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Leg,
    offersIdGenerator: function (index) { return 105640 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Itu_R_Star.ID,
        HERO_1: heroes.Itu.ID,
        ALIAS_1: heroes.Itu.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Itu_R_Star",
        START_DATE: new Date("2026-06-08").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Itu_R_Star"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Sarge_R_Dark = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Rare,
    offersIdGenerator: function (index) { return 105648 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Sarge_R_Dark.ID,
        HERO_1: heroes.Sarge.ID,
        ALIAS_1: heroes.Sarge.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Sarge_R_Dark",
        START_DATE: new Date("2026-06-10").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Sarge_R_Dark"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Gideon_E_Forwarder = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105664 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Gideon_E_Forwarder.ID,
        HERO_1: heroes.Gideon.ID,
        ALIAS_1: heroes.Gideon.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Gideon_E_Forwarder",
        START_DATE: new Date("2026-06-17").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Gideon_E_Forwarder"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Jet_E_Burglar = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Rare,
    offersIdGenerator: function (index) { return 105672 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Jet_E_Burglar.ID,
        HERO_1: heroes.Jet.ID,
        ALIAS_1: heroes.Jet.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Jet_E_Burglar",
        START_DATE: new Date("2026-06-20").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Jet_E_Burglar"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Ironclad_E_Rust = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Com,
    offersIdGenerator: function (index) { return 105680 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Ironclad_E_Rust.ID,
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: heroes.Ironclad.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Ironclad_E_Rust",
        START_DATE: new Date("2026-06-22").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "Ironclad_E_Rust"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Ironclad_E_Fervor = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Com,
    offersIdGenerator: function (index) { return 105688 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Ironclad_E_Fervor.ID,
        HERO_1: heroes.Ironclad.ID,
        ALIAS_1: heroes.Ironclad.Alias,
        VISUAL_PRESET_1: "Ironclad_E_Fervor_cyberweek_hero",
        START_DATE: new Date("2026-07-04").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Ironclad_E_Fervor"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Bulwark_E_Ivy = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Com,
    offersIdGenerator: function (index) { return 105696 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Bulwark_E_Ivy.ID,
        HERO_1: heroes.Bulwark.ID,
        ALIAS_1: heroes.Bulwark.Alias,
        VISUAL_PRESET_1: "Bulwark_E_Ivy_cyberweek_hero",
        START_DATE: new Date("2026-07-07").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Bulwark_E_Ivy"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Kibo_E_Crane_skin = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105704 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Kibo_E_Crane_skin.ID,
        HERO_1: heroes.Kibo.ID,
        ALIAS_1: heroes.Kibo.Alias,
        VISUAL_PRESET_1: "Kibo_E_Crane_skin_cyberweek_hero",
        START_DATE: new Date("2026-07-10").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Kibo_E_Crane_skin"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return ({ common: {} }); }),
};
offerSkins.Epic_Skin_1111_Raikichi_E_Burned = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105712 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Raikichi_E_Burned.ID,
        HERO_1: heroes.Raikichi.ID,
        ALIAS_1: heroes.Raikichi.Alias,
        VISUAL_PRESET_1: "Raikichi_E_Burned_cyberweek_hero",
        START_DATE: new Date("2026-07-13").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Raikichi_E_Burned"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Gideon_E_Cowboy = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105720 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Gideon_E_Cowboy.ID,
        HERO_1: heroes.Gideon.ID,
        ALIAS_1: heroes.Gideon.Alias,
        VISUAL_PRESET_1: "Gideon_E_Cowboy_cyberweek_hero",
        START_DATE: new Date("2026-07-26").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Gideon_E_Cowboy"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Emperor_R_Cyan_skin = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105728 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skins_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Emperor_R_Cyan_skin.ID,
        HERO_1: heroes.Emperor.ID,
        ALIAS_1: heroes.Emperor.Alias,
        VISUAL_PRESET_1: "Emperor_R_Cyan_skin_cyberweek_hero",
        START_DATE: new Date("2026-07-29").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Emperor_R_Cyan_skin"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Legion_King_E_Prince = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Leg,
    offersIdGenerator: function (index) { return 105736 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Legion_King_E_Prince.ID,
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: heroes.Legion_King.Alias,
        VISUAL_PRESET_1: "Legion_King_E_Prince_cyberweek_hero",
        START_DATE: new Date("2026-08-01").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Legion_King_E_Prince"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Epic_Skin_1111_Butcher_E_Khan = {
    skeleton: offerSkeletons.Epic_Skin_1111_Hero_Epic,
    offersIdGenerator: function (index) { return 105744 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Epic_Skin_1111_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        SKIN_1: skins.Butcher_E_Khan.ID,
        HERO_1: heroes.Butcher.ID,
        ALIAS_1: heroes.Butcher.Alias,
        VISUAL_PRESET_1: "cyberweek_hero_Butcher_E_Khan",
        START_DATE: new Date("2026-08-04").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Butcher_E_Khan"
    },
    offers: new Array(8).join("0").split("0").map(function (_) { return { common: {} }; }),
};
