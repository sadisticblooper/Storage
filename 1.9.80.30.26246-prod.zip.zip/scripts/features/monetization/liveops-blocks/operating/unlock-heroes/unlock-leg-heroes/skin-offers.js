offerSkins.Nonna_Unlock = {
    skeleton: offerSkeletons.Unlock_New_Hero_Leg,
    offersIdGenerator: function (index) { return 101460 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Sale_Unlock_Up_Fat_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    onceRepeatAfter: new Date("2026-03-10").getTime(),
    vars: {
        HERO_1: heroes.Nonna.ID,
        ALIAS_1: "promo_offer_Nonna",
        VISUAL_PRESET_1: "offer_with_image_leg_Nonna",
        START_DATE: new Date("2026-03-20").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Nonna_03_20"
    },
    offers: new Array(4).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.LK_Unlock_22_04 = {
    skeleton: offerSkeletons.Hero_Sale_Leg,
    offersIdGenerator: function (index) { return 101464 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Sale_Unlock_Up_Fat_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Legion_King.ID,
        ALIAS_1: heroes.Legion_King.Alias,
        VISUAL_PRESET_1: "offer_with_image_leg_LK",
        START_DATE: new Date("2026-04-22").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "LK"
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.Nonna_unlock_fat = {
    skeleton: offerSkeletons.Hero_Sale_Leg,
    offersIdGenerator: function (index) { return 101476 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Sale_Unlock_Up_Fat_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Nonna.ID,
        ALIAS_1: heroes.Nonna.Alias,
        VISUAL_PRESET_1: "offer_with_image_leg_Nonna",
        START_DATE: new Date("2026-06-27").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "Nonna"
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
offerSkins.shogun_unlock_with_content = {
    skeleton: offerSkeletons.Unlock_Leg_Hero_Rare_More_Content,
    offersIdGenerator: function (index) { return 101488 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_HeroSale_Unlock_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Shogun.ID,
        SKIN_1: skins.Shogun_R_Red.ID,
        WEAPON_1: heroWeapons.wpn_Shogun_R_Base_Rec_Vassal.ID,
        STANCE_1: stances.win_Shogun_R_Stomp.ID,
        ALIAS_1: "promo_title_PROMO_STARTER_1",
        ALIAS_2: "promo_title_PROMO_STARTER_2",
        ALIAS_3: "promo_offer_Shogun",
        VISUAL_PRESET_1: "legendary_hero_vs",
        VISUAL_PRESET_2: "offer_hero_Shogun_2",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 21,
        NAME_PREFIX: "Shogun"
    },
    offers: new Array(12).join("0").split("0").map(function (_) { return { common: {} }; }),
};
