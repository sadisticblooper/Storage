offerSkins.Single_Animation_Meta_stance_Marcus_E_workout_02_04 = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101136 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Meta_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Marcus.ID,
        STANCE_1: stances.stance_Marcus_E_workout.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-04-02").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Marcus_E_workout"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Single_Animation_Meta_stance_Yukka_R_arrow_02_04 = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101140 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Meta_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Yukka.ID,
        STANCE_1: stances.stance_Yukka_R_arrow.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-04-02").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Yukka_R_arrow"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Single_Animation_Meta_stance_Monkey_King_E_baboon_05_04 = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101144 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Meta_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Monkey_King.ID,
        STANCE_1: stances.stance_Monkey_King_E_baboon.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-04-05").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Monkey_King_E_baboon"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Single_Animation_Meta_win_Kibo_R_blood_05_04 = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101148 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Meta_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Kibo.ID,
        STANCE_1: stances.win_Kibo_R_blood.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-04-05").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "win_Kibo_R_blood"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Single_Animation_Meta_win_Lynx_R_Remove_claws_07_04 = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101152 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Meta_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Lynx.ID,
        STANCE_1: stances.win_Lynx_R_Remove_claws.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-04-07").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "win_Lynx_R_Remove_claws"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Butcher_R_bully_23_04 = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101156 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Butcher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        STANCE_1: stances.stance_Butcher_R_bully.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-04-23").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Butcher_R_bully"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Butcher_E_cage_warrior_25_04 = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101158 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Butcher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        STANCE_1: stances.stance_Butcher_E_cage_warrior.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-04-25").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Butcher_E_cage_warrior"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Butcher_R_sharp_knives_27_04 = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101160 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Butcher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        STANCE_1: stances.win_Butcher_R_sharp_knives.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-04-27").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Butcher_R_sharp_knives"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Butcher_E_Hook_29_04 = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101162 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Butcher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Butcher.ID,
        STANCE_1: stances.stance_Butcher_E_Hook.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-04-29").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Butcher_E_Hook"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_Sale_stance_Lynx_E_claws_release_win_Fireguard_E_firefly = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101164 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Lynx.ID,
        HERO_2: heroes.Fireguard.ID,
        STANCE_1: stances.stance_Lynx_E_claws_release.ID,
        STANCE_2: stances.win_Fireguard_E_firefly.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-05-09").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Lynx_E_claws_release_win_Fireguard_E_firefly"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_Sale_stance_Emperor_E_golden_throne_win_Emperor_monster_E_cage = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101168 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Emperor.ID,
        HERO_2: heroes.Emperor.ID,
        STANCE_1: stances.stance_Emperor_E_golden_throne.ID,
        STANCE_2: stances.win_Emperor_monster_E_cage.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-05-12").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Emperor_E_golden_throne_win_Emperor_monster_E_cage"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_Sale_stance_Monk_E_disguise_win_Viper_R_bye_bye = {
    skeleton: offerSkeletons.Animation_MiniDouble,
    offersIdGenerator: function (index) { return 101172 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Monk.ID,
        HERO_2: heroes.Viper.ID,
        STANCE_1: stances.stance_Monk_E_disguise.ID,
        STANCE_2: stances.win_Viper_R_bye_bye.ID,
        ALIAS_2: "shop_offers_sale",
        VISUAL_PRESET_2: "Customize_small",
        START_DATE: new Date("2026-05-15").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "stance_Monk_E_disguise_win_Viper_R_bye_bye"
    },
    offers: new Array(4).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Ironclad_R_punches = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101176 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.stance_Ironclad_R_punches.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-22").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "stance_Ironclad_R_punches"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Ironclad_E_kicked_out = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101178 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.stance_Ironclad_E_kicked_out.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-23").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "stance_Ironclad_E_kicked_out"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Ironclad_R_me_you = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101180 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.stance_Ironclad_R_me_you.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-24").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "stance_Ironclad_R_me_you"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Ironclad_E_boxing = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101182 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.stance_Ironclad_E_boxing.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-25").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "stance_Ironclad_E_boxing"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Ironclad_R_hell_yeah = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101184 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.win_Ironclad_R_hell_yeah.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-26").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "win_Ironclad_R_hell_yeah"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Ironclad_E_disappointment = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101186 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.win_Ironclad_E_disappointment.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-27").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "win_Ironclad_E_disappointment"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Ironclad_R_finger_up = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101188 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.win_Ironclad_R_finger_up.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-28").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "win_Ironclad_R_finger_up"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Ironclad_R_dance = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101190 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Ironclad.ID,
        STANCE_1: stances.win_Ironclad_R_dance.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-05-29").getTime(),
        DURATION_DATE_1: 1,
        NAME_PREFIX: "win_Ironclad_R_dance"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Sarge_R_hammer_flip = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101000 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.stance_Sarge_R_hammer_flip.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-11").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Sarge_R_hammer_flip"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Sarge_R_hooah = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101002 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.win_Sarge_R_hooah.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-13").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Sarge_R_hooah"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Sarge_E_pain_plan = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101004 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.stance_Sarge_E_pain_plan.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-15").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Sarge_E_pain_plan"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Sarge_R_Thor = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101006 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.win_Sarge_R_Thor.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-17").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Sarge_R_Thor"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Sarge_R_sharp_knife = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101008 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.stance_Sarge_R_sharp_knife.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-19").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Sarge_R_sharp_knife"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Sarge_E_smash = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101010 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.stance_Sarge_E_smash.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-20").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Sarge_E_smash"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Sarge_E_banner = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101012 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Sarge_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Sarge.ID,
        STANCE_1: stances.stance_Sarge_E_banner.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-22").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Sarge_E_banner"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Feldsher_R_polearm_swing = {
    skeleton: offerSkeletons.Animation_MiniSingle_Rare,
    offersIdGenerator: function (index) { return 101014 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.stance_Feldsher_R_polearm_swing.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-18").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Feldsher_R_polearm_swing"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Feldsher_R_bow = {
    skeleton: offerSkeletons.Animation_MiniSingle_Rare,
    offersIdGenerator: function (index) { return 101016 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.win_Feldsher_R_bow.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-20").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Feldsher_R_bow"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Feldsher_E_battle_chest = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101018 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.stance_Feldsher_E_battle_chest.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-22").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Feldsher_E_battle_chest"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Feldsher_E_Rose = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101020 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.win_Feldsher_E_Rose.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-24").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Feldsher_E_Rose"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Feldsher_R_hat_off = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101022 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.stance_Feldsher_R_hat_off.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-26").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Feldsher_R_hat_off"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Feldsher_E_explosion = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101024 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.stance_Feldsher_E_explosion.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-28").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Feldsher_E_explosion"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Feldsher_R_fient = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101026 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.win_Feldsher_R_fient.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-30").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Feldsher_R_fient"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Feldsher_E_friendship = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101028 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        STANCE_1: stances.stance_Feldsher_E_friendship.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-07-02").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Feldsher_E_friendship"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_Feldsher_E_respect = {
    skeleton: offerSkeletons.Taunt_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101030 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Feldsher_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Feldsher.ID,
        TAUNT_1: taunts.Feldsher_E_respect.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "offer_narrow_feldsher_rework",
        START_DATE: new Date("2026-06-18").getTime(),
        DURATION_DATE_1: 4,
        NAME_PREFIX: "Feldsher_E_respect"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Midnight_R_ninja = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101032 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        STANCE_1: stances.stance_Midnight_R_ninja.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-25").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Midnight_R_ninja"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Midnight_E_mark = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101034 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        STANCE_1: stances.win_Midnight_E_mark.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-27").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Midnight_E_mark"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Midnight_E_silence = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101036 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        STANCE_1: stances.win_Midnight_E_silence.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-06-29").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "win_Midnight_E_silence"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Midnight_E_ghost = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101038 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Midnight.ID,
        STANCE_1: stances.stance_Midnight_E_ghost.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-07-01").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Midnight_E_ghost"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_win_Gideon_E_screen_shoot = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101040 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        STANCE_1: stances.win_Gideon_E_screen_shoot.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-07-23").getTime(),
        DURATION_DATE_1: 3,
        NAME_PREFIX: "win_Gideon_E_screen_shoot"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Gideon_E_clear = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101042 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        STANCE_1: stances.stance_Gideon_E_clear.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-07-26").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Gideon_E_clear"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
offerSkins.Animation_stance_Gideon_R_fient = {
    skeleton: offerSkeletons.Animation_MiniSingle_Epic,
    offersIdGenerator: function (index) { return 101044 + index; },
    offersNameGenerator: function (offerId, offerPrefix, vars) { return "PROMO_Anim_Midnight_".concat(vars.NAME_PREFIX, "_").concat(offerPrefix, "_").concat(offerId); },
    activeTime: null,
    vars: {
        HERO_1: heroes.Gideon.ID,
        STANCE_1: stances.stance_Gideon_R_fient.ID,
        ALIAS_1: "shop_offers_sale",
        VISUAL_PRESET_1: "Customize_small",
        START_DATE: new Date("2026-07-28").getTime(),
        DURATION_DATE_1: 2,
        NAME_PREFIX: "stance_Gideon_R_fient"
    },
    offers: new Array(2).join("0").split("0").map(function (_) {
        return { common: {} };
    }),
};
