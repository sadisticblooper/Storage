offerSkeletons.Wpn_Sale_1111_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 5.7,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 8.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 30, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 60, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 3.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 6.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 8.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 5.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 9.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-85%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 3.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 100, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 3.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_10.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_5_broken.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 10.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_2.ProductID,
                discount: "-90%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Rebalance_Com = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.2,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 100, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 100, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 2.3,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 40, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 40, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_8.ProductID,
                discount: "-65%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 5.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_4.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 25,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 10, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 10, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Rebalance_Rare = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 1.8,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-45%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 50, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 100, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 2.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_20.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 35, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 35, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 4.6,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 6.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_6.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 20,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Rebalance_Epic = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_50.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 30, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 60, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 2.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_30.ProductID,
                discount: "-55%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 25, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 4.1,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-75%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 5.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_9.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 15,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 15, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
offerSkeletons.Wpn_Sale_1111_Rebalance_Leg = {
    offers: [
        {
            common: {
                conditions: {},
                sp: { min: 250.0, max: 99999.99 },
                profit: 2.0,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_60_2.ProductID,
                discount: "-50%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c, _d;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _b) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[VARS.HERO_1] = 25, _d) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "HP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 50.0, max: 249.99 },
                profit: 2.5,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_40.ProductID,
                discount: "-60%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 20, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "MP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 20.00, max: 49.99 },
                profit: 3.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_25.ProductID,
                discount: "-70%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 25, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "LP"
        },
        {
            common: {
                conditions: {},
                sp: { min: 0.0, max: 19.99 },
                profit: 5.4,
                offerType: PROMO_OFFER_TYPE.STATIC,
                enablePopup: true,
                inApp: inAppSettings.PRICE_15.ProductID,
                discount: "-80%",
                customSpTable: PromoOfferConstants.wpn1111SpTable,
            },
            commonWithVars: function (VARS, OFFERS) {
                var _a, _b, _c;
                return {
                    activeTime: {
                        startGenerationBound: VARS.START_DATE,
                        endGenerationBound: VARS.START_DATE + new Time({ Days: VARS.DURATION_DATE_1 }).value,
                    },
                    visualPresetId: VARS.VISUAL_PRESET_1,
                    offerNameAlias: VARS.ALIAS_1,
                    conditions: {
                        accountLevel: { more_or_equal: 2 },
                    },
                    noCustomizeExist: (_a = {},
                        _a[CUSTOMIZATION.WEAPON] = [VARS.WEAPON_1],
                        _a),
                    popupSettings: {
                        popUpId: 10,
                        popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
                    },
                    productGroup: OFFERS[1],
                    lootSettings: {
                        additionalPlaceHolder: [
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [VARS.WEAPON_1] }) } } }],
                            },
                            {
                                front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[VARS.HERO_1] = 15, _b) }) } } }],
                                back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_c = {}, _c[VARS.HERO_1] = 20, _c) }) } } }],
                            },
                        ]
                    },
                };
            },
            offerPrefix: "NP"
        },
    ]
};
