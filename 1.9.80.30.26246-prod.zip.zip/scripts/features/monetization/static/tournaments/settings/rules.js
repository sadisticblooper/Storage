var tournamentRules = {
    Rule_Royale_Walls_Burn: {
        ID: 1,
        Tags: ['EVENT_WALLS_BURN'],
        Alias: 'Tornament_event_rule_title_br',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_event_royale_walls',
        Description: 'Tornament_event_rule_description_br'
    },
    Rule_More_Heal_For_Walls: {
        ID: 2,
        Tags: ['EVENT_MORE_HEAL_FOR_WALLS'],
        Alias: 'Tornament_event_rule_title_event2_3',
        Icon: 'Sprites/Assets/Abilities/icon_ability_healing',
        Description: 'Tornament_event_rule_description_event2_3'
    },
    Rule_More_Heal_For_Damage: {
        ID: 3,
        Tags: ['EVENT_MORE_HEAL_FOR_DAMAGE'],
        Alias: 'Tornament_event_rule_title_heal',
        Icon: 'Sprites/Assets/Abilities/icon_ability_healing',
        Description: 'Tornament_event_rule_description_heal'
    },
    Rule_More_Mana: {
        ID: 4,
        Tags: ['EVENT_MORE_MANA'],
        Alias: 'Tornament_event_rule_title_shadow',
        Icon: 'Sprites/Assets/Abilities/icon_attribute_magic',
        Description: 'Tornament_event_rule_description_shadow'
    },
    Rule_More_Damage: {
        ID: 5,
        Tags: ['EVENT_MORE_DAMAGE'],
        Alias: 'Tornament_event_rule_title_damage',
        Icon: 'Sprites/Assets/Abilities/icon_ability_DamageBonus',
        Description: 'Tornament_event_rule_description_damage'
    },
    Rule_No_Rules: {
        ID: 7,
        Tags: [],
        Alias: 'Tornament_event_rule_title_grandeur',
        Icon: 'Sprites/Assets/Abilities/icon_attribute_light',
        Description: 'Tornament_event_rule_description_grandeur'
    },
    Rule_Faction_Buffs_Legion: {
        ID: 8,
        Tags: ['LOCK_EVENT_FACTION_BUFFS'],
        Alias: 'Tornament_event_rule_title_legion',
        Icon: 'Sprites/Assets/Abilities/icon_ability_Legion',
        Description: 'Tornament_event_rule_description_legion'
    },
    Rule_Faction_Buffs_Dynasty: {
        ID: 9,
        Tags: [],
        Alias: 'Tornament_event_rule_title_dynasty',
        Icon: 'Sprites/Assets/Abilities/icon_ability_Dynasty',
        Description: 'Tornament_event_rule_description_dynasty'
    },
    Rule_Faction_Buffs_Heralds: {
        ID: 10,
        Tags: [],
        Alias: 'Tornament_event_rule_title_heralds',
        Icon: 'Sprites/Assets/Abilities/icon_ability_Heralds',
        Description: 'Tornament_event_rule_description_heralds'
    },
    Rule_Sacura_Leaf: {
        ID: 11,
        Tags: ['EVENT_SACURA'],
        Alias: 'Tornament_event_rule_title_sakura',
        Icon: 'Sprites/Assets/Abilities/icon_Sakura',
        Description: 'Tornament_event_rule_description_sakura'
    },
    Rule_Event_Taunts: {
        ID: 12,
        Tags: ['EVENT_TAUNTS'],
        Alias: 'Tornament_event_rule_title_monkey',
        Icon: 'Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Special',
        Description: 'Tornament_event_rule_description_monkey'
    },
    Rule_Event_Weather: {
        ID: 13,
        Tags: ['EVENT_WEATHER'],
        Alias: 'Tornament_event_rule_title_event1_2',
        Icon: 'Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Enemy_Style_Bonus',
        Description: 'Tornament_event_rule_description_event1_2'
    },
    Rule_Event_One_Faction: {
        ID: 14,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event1_3',
        Icon: 'Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Fair_Fight',
        Description: 'Tornament_event_rule_description_event1_3'
    },
    Rule_Event_Lava: {
        ID: 15,
        Tags: ['EVENT_LAVA'],
        Alias: 'Tornament_event_rule_title_event1_4',
        Icon: "Sprites/Assets/Abilities/icon_ability_SE_burning",
        Description: 'Tornament_event_rule_description_event1_4'
    },
    Rule_Event_MK: {
        ID: 16,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event1_5',
        Icon: 'Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Special',
        Description: 'Tornament_event_rule_description_event1_5'
    },
    Rule_Event_Freezing: {
        ID: 17,
        Tags: ["LOCK_EVENT_FREEZING", "ACTIVATE_FREEZING"],
        Alias: 'Tornament_event_rule_title_event2_2',
        Icon: 'Sprites/Assets/Abilities/icon_freezed',
        Description: 'Tornament_event_rule_description_event2_2'
    },
    Rule_Kicks: {
        ID: 18,
        Tags: ['EVENT_KICKS'],
        Alias: 'Tornament_event_rule_title_event2_1',
        Icon: 'Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Heavy_Kick_Upgrade',
        Description: 'Tornament_event_rule_description_event2_1',
    },
    Rule_Royale_Walls_Freeze: {
        ID: 19,
        Tags: ['EVENT_WALLS_FREEZE'],
        Alias: 'Tornament_event_rule_title_event2_3',
        Icon: 'Sprites/Assets/Abilities/icon_ability_snow',
        Description: 'Tornament_event_rule_description_event2_3'
    },
    Rule_Event_Lunar_Presents: {
        ID: 20,
        Tags: ['LOCK_EVENT_LUNAR_PRESENTS'],
        Alias: 'Tornament_event_rule_title_event3_1',
        Icon: 'Sprites/Assets/Abilities/icon_present',
        Description: 'Tornament_event_rule_description_event3_1'
    },
    Rule_AB_Sarge: {
        ID: 21,
        Tags: [],
        Alias: 'Tornament_event_rule_title_sarge',
        Icon: 'Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Explosion',
        Description: 'Tornament_event_rule_description_sarge'
    },
    Rule_LegionKingPickRule: {
        ID: 22,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event6',
        Icon: 'Sprites/Assets/Abilities/Legion_King/icon_ability_wpn_Legion_King_E_Abyssblade',
        Description: 'Tornament_event_rule_description_event6'
    },
    Rule_Summer_feather: {
        ID: 23,
        Tags: ['LOCK_EVENT_FEATHER'],
        Alias: 'Tournament_rule_title_event8',
        Icon: 'Sprites/Assets/Abilities/icon_event_summer',
        Description: 'Tournament_rule_description_event8'
    },
    Rule_Active_block: {
        ID: 24,
        Tags: ['LOCK_EVENT_ACTIVE_BLOCK'],
        Alias: 'Tournament_rule_title_active_block',
        Icon: 'Sprites/Assets/Abilities/icon_active_block',
        Description: 'Tournament_rule_description_active_block'
    },
    Rule_Viper_Event: {
        ID: 25,
        Tags: [],
        Alias: 'Tournament_rule_title_event12',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_VIPER',
        Description: 'Tournament_rule_description_event12'
    },
    Rule_Butcher_Event: {
        ID: 26,
        Tags: [],
        Alias: 'Tournament_rule_title_event13',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_EVENT_BUTCHER',
        Description: 'Tournament_rule_description_event13'
    },
    Rule_Portals: {
        ID: 27,
        Tags: ['LOCK_EVENT_PORTALS'],
        Alias: 'Tournament_rule_title_event12_1',
        Icon: 'Sprites/Assets/Abilities/icon_portals',
        Description: 'Tournament_rule_description_event12_1'
    },
    Rule_Itu_Event: {
        ID: 28,
        Tags: [],
        Alias: 'Tournament_rule_title_event17',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_ITU',
        Description: 'Tournament_rule_description_event17'
    },
    Rule_Itu_Event_PVE: {
        ID: 29,
        Tags: [],
        Alias: 'Tournament_rule_title_event17_1',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_ITU',
        Description: 'Tournament_rule_description_event17_1'
    },
    Rule_Yunlin_Event: {
        ID: 30,
        Tags: ["EVENT_YUNLIN_FOG"],
        Alias: 'Tournament_rule_title_event23',
        Icon: 'Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Shadow_Parts_More',
        Description: 'Tournament_rule_description_event23'
    },
    Rule_Vampire_Event: {
        ID: 31,
        Tags: ["EVENT_VAMPIRE"],
        Alias: 'Tournament_rule_title_event25',
        Icon: 'Sprites/Assets/Abilities/icon_anathema_debuff',
        Description: 'Tournament_rule_description_event25'
    },
    Rule_Sunstrikes_Event: {
        ID: 32,
        Tags: ["EVENT_SUNSTRIKES"],
        Alias: 'Tournament_rule_title_event28',
        Icon: 'Sprites/Assets/Abilities/icon_event_sunstrikes',
        Description: 'Tournament_rule_description_event28'
    },
    Rule_XiangTzu_Event_PVE: {
        ID: 33,
        Tags: [],
        Alias: 'Tournament_rule_title_event30_2',
        Icon: 'Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Form',
        Description: 'Tournament_rule_description_event30_2'
    },
    Rule_XiangTzu_Event: {
        ID: 34,
        Tags: [],
        Alias: 'Tournament_rule_title_event30_1',
        Icon: 'Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Form',
        Description: 'Tournament_rule_description_event30_1'
    },
    Rule_Newbie_tournament: {
        ID: 35,
        Tags: [],
        Alias: 'tournament_rule_tittle_new_players',
        Icon: 'Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Time_Bomb',
        Description: 'tournament_rule_description_new_players'
    },
    Rule_Leafs_ZKS_tournament: {
        ID: 36,
        Tags: ["EVENT_LEAFS_ZKS"],
        Alias: 'Tournament_rule_title_event33',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_event_leafs_ZKS',
        Description: 'Tournament_rule_description_event33'
    },
    Rule_Fireworks_Birthday: {
        ID: 37,
        Tags: ["EVENT_SFA_FIREWORKS"],
        Alias: 'Tournament_rule_title_event_HB',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fireworks',
        Description: 'Tournament_rule_description_event_HB'
    },
    Rule_Freezestrike_Event: {
        ID: 38,
        Tags: ["EVENT_FREEZESTRIKES", "ACTIVATE_FREEZING"],
        Alias: 'Tornament_event_rule_title_event36_1',
        Icon: 'Sprites/Assets/Abilities/icon_freezed',
        Description: 'Tornament_event_rule_description_event36_1'
    },
    Rule_June_Tournament: {
        ID: 39,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event36_2',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_June',
        Description: 'Tornament_event_rule_description_event36_2'
    },
    Rule_Emperor_Strong_Tournament: {
        ID: 40,
        Tags: [],
        Alias: 'Tournament_rule_title_gacha_Emperor',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_Emperor',
        Description: 'Tournament_rule_description_gacha_Emperor'
    },
    Rule_Lynx_Legend_Skin_Tournament: {
        ID: 41,
        Tags: [],
        Alias: 'Tournament_rule_title_Lynx_legendary_skin',
        Icon: 'Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Time_Bomb',
        Description: 'Tournament_rule_description_Lynx_legendary_skin'
    },
    Rule_Itu_Fruit_Ninja_Iteration_One_Round_One: {
        ID: 42,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_ONE_ROUND_ONE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_One_Round_Two: {
        ID: 43,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_ONE_ROUND_TWO", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_One_Round_Three: {
        ID: 44,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_ONE_ROUND_THREE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_One_Round_Four: {
        ID: 45,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_ONE_ROUND_FOUR", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_One_Round_Five: {
        ID: 46,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_ONE_ROUND_FIVE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Black_Market_Tournament: {
        ID: 47,
        Tags: ["EVENT_BLACK_MARKET"],
        Alias: 'Tournament_rule_title_black_market',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_coin',
        Description: 'Tournament_rule_description_black_market'
    },
    Rule_Gideon_vs_AI_Tournament: {
        ID: 48,
        Tags: [],
        Alias: 'Tournament_event_rule_title_promo_gideon',
        Icon: 'Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_mark',
        Description: 'Tournament_event_rule_description_promo_gideon'
    },
    Rule_Butcher_vs_AI_Tournament: {
        ID: 49,
        Tags: [],
        Alias: 'Tournament_event_rule_title_promo_butcher',
        Icon: 'Sprites/Assets/Abilities/Butcher/icon_ability_Butcher_Walls',
        Description: 'Tournament_event_rule_description_promo_butcher'
    },
    Rule_Idle_Tournament: {
        ID: 50,
        Tags: ["EVENT_IDLE_TOURNAMENT", "ACTIVATE_FREEZING"],
        Alias: 'Tournament_event_rule_title_idle',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_idle_tournament',
        Description: 'Tournament_event_rule_description_idle'
    },
    Rule_Idle_Tournament_Medium: {
        ID: 51,
        Tags: ["EVENT_IDLE_TOURNAMENT", "ACTIVATE_FREEZING", "IDLE_TOURNAMENT_MEDIUM"],
        Alias: 'Tournament_event_rule_title_idle',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_idle_tournament',
        Description: 'Tournament_event_rule_description_idle'
    },
    Rule_Widow_vs_AI_Tournament: {
        ID: 52,
        Tags: [],
        Alias: 'Tournament_event_rule_title_promo_widow',
        Icon: 'Sprites/Assets/Abilities/Widow/icon_ability_Widow_corruption',
        Description: 'Tournament_event_rule_description_promo_widow'
    },
    Rule_LegionKingLegSkinPromo: {
        ID: 53,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event6',
        Icon: 'Sprites/Assets/Abilities/Legion_King/icon_ability_wpn_Legion_King_E_Abyssblade',
        Description: 'Tornament_event_rule_description_legion_king_skin_promo'
    },
    Rule_Raikichi_vs_AI_Tournament: {
        ID: 54,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event66_Raikichi',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rules_Raikichi',
        Description: 'Tornament_event_rule_description_event66_Raikichi_Strong'
    },
    Rule_Marcus_vs_Marcus_tournament: {
        ID: 55,
        Tags: [],
        Alias: 'Tournament_rule_title_Marcus_vs_Marcus',
        Icon: 'Sprites/Assets/PVE/BuffsIcon/HeroesIconPVE/icon_Marcus_buff',
        Description: 'Tournament_rule_description_Marcus_vs_Marcus'
    },
    Rule_Angry_Birds_Easy_1: {
        ID: 56,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_EASY_1", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Easy_2: {
        ID: 57,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_EASY_2", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Easy_3: {
        ID: 58,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_EASY_3", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Easy_4: {
        ID: 59,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_EASY_4", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Hard_1: {
        ID: 60,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_HARD_1", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Hard_2: {
        ID: 61,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_HARD_2", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Hard_3: {
        ID: 62,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_HARD_3", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Angry_Birds_Hard_4: {
        ID: 63,
        Tags: ["EVENT_ANGRY_BIRDS", "EVENT_ANGRY_BIRDS_HARD_4", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_event69_peace',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_angry_birds',
        Description: 'Tornament_event_rule_description_event69_peace'
    },
    Rule_Nonna_vs_AI_Tournament: {
        ID: 64,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event76_Nonna',
        Icon: 'Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_bear',
        Description: 'Tornament_event_rule_description_event76_Nonna_Strong'
    },
    Rule_MonkeyKing_LegSkin_Promo: {
        ID: 65,
        Tags: [],
        Alias: 'Tornament_event_rule_title_MK_skin_promo',
        Icon: 'Sprites/Assets/Abilities/Monkey_King/icon_ability_wpn_E_Crystal_Monkey_King',
        Description: 'Tornament_event_rule_description_MK_skin_promo'
    },
    Rule_Bulwark_vs_AI_Tournament: {
        ID: 66,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event80_Bulwark',
        Icon: 'Sprites/Assets/PVE/BuffsIcon/HeroesIconPVE/icon_Bulwark_buff',
        Description: 'Tornament_event_rule_description_event80_Bulwark_Strong'
    },
    Rule_Astronautics_Kibo: {
        ID: 67,
        Tags: [],
        Alias: 'Tornament_event_rule_title_astronautics_kibo',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_KIBO',
        Description: 'Tornament_event_rule_description_astronautics_kibo'
    },
    Rule_Astronautics_Itu: {
        ID: 68,
        Tags: [],
        Alias: 'Tornament_event_rule_title_astronautics_Itu',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_ITU',
        Description: 'Tornament_event_rule_description_astronautics_Itu'
    },
    Rule_Butcher_LegWpn_Promo: {
        ID: 69,
        Tags: [],
        Alias: 'Tournament_event_rule_title_Butcher_leg_wpn_promo',
        Icon: 'Sprites/Assets/PVE/BuffsIcon/HeroesIconPVE/icon_Butcher_buff',
        Description: 'Tournament_event_rule_description_Butcher_leg_wpn_promo'
    },
    Rule_Ironclad_LegSkin_Promo: {
        ID: 70,
        Tags: [],
        Alias: 'Tornament_event_rule_title_Ironclad_skin_promo',
        Icon: 'Sprites/Assets/Abilities/Ironclad/icon_ability_wpn_E_Minotaur',
        Description: 'Tornament_event_rule_description_Ironclad_skin_promo'
    },
    Rule_Midnight_Epic_Wpn_Promo: {
        ID: 71,
        Tags: [],
        Alias: 'Tournament_event_rule_title_promo_Midnight',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_MIDNIGHT',
        Description: 'Tournament_event_rule_description_promo_Midnight'
    },
    Rule_Feldsher_vs_AI_Tournament: {
        ID: 72,
        Tags: [],
        Alias: 'Tornament_event_rule_title_Feldsher',
        Icon: 'Sprites/Assets/PVE/BuffsIcon/HeroesIconPVE/icon_Feldsher_buff',
        Description: 'Tornament_event_rule_description_Feldsher_Strong'
    },
    Rule_Feldsher_Epic_Wpn_Promo: {
        ID: 73,
        Tags: [],
        Alias: 'Tournament_event_rule_title_promo_Feldsher',
        Icon: 'Sprites/Assets/Abilities/Feldsher/icon_wpn_ability_E_Diver',
        Description: 'Tournament_event_rule_description_promo_Feldsher'
    },
    Rule_Shogun_vs_AI_Promo: {
        ID: 74,
        Tags: [],
        Alias: 'Tornament_event_rule_title_event91_Shogun',
        Icon: 'Sprites/Assets/Abilities/Shogun/icon_ability_Shogun_demon_form',
        Description: 'Tornament_event_rule_description_event91_Shogun_Strong'
    },
    Rule_No_Rules_1x1: {
        ID: 75,
        Tags: [],
        Alias: 'Tournament_rule_title_no_rule',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_basic',
        Description: 'Tournament_rule_description_no_rule'
    },
    Friend_No_Rules: {
        ID: 201,
        Tags: ["FRIEND_FIGHT"],
        Alias: 'fight_mode_classic',
        Icon: 'Sprites/Assets/Abilities/icon_attribute_light',
        Description: 'fight_mode_classic_description'
    },
    Friend_Vampire: {
        ID: 202,
        Tags: ["EVENT_VAMPIRE", "FRIEND_FIGHT"],
        Alias: 'Tournament_rule_title_event25',
        Icon: 'Sprites/Assets/Abilities/Fireguard/icon_ability_Fireguard_02',
        Description: 'Tournament_rule_description_event25'
    },
    Friend_Active_block: {
        ID: 203,
        Tags: ['LOCK_EVENT_ACTIVE_BLOCK', "FRIEND_FIGHT"],
        Alias: 'Tournament_rule_title_active_block',
        Icon: 'Sprites/Assets/Abilities/icon_active_block',
        Description: 'Tournament_rule_description_active_block'
    },
    Friend_Portals: {
        ID: 204,
        Tags: ['LOCK_EVENT_PORTALS', "FRIEND_FIGHT"],
        Alias: 'Tournament_rule_title_event12_1_vs_friend',
        Icon: 'Sprites/Assets/Abilities/icon_portals',
        Description: 'Tournament_rule_description_event12_1'
    },
    Friend_Walls_Burn_3v3: {
        ID: 205,
        Tags: ['EVENT_WALLS_BURN', "FRIEND_FIGHT"],
        Alias: 'Tornament_event_rule_title_special',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_event_royale_walls',
        Description: 'Tornament_event_rule_description_special'
    },
    Friend_Walls_Burn_1v1: {
        ID: 206,
        Tags: ['EVENT_WALLS_BURN', "FRIEND_FIGHT"],
        Alias: 'Tornament_event_rule_title_special',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_event_royale_walls',
        Description: 'Tornament_event_rule_description_special_1'
    },
    Friend_Endless: {
        ID: 207,
        Tags: ["ENDLESS_FIGHT", "FRIEND_FIGHT"],
        Alias: 'fight_mode_endless',
        Icon: 'Sprites/Assets/Abilities/icon_attribute_light',
        Description: 'fight_mode_endless_description'
    },
    Friend_Fractions: {
        ID: 208,
        Tags: ["LOCK_EVENT_FACTION_BUFFS", "FRIEND_FIGHT"],
        Alias: 'Tornament_event_rule_title_fractions',
        Icon: 'Sprites/Assets/Abilities/icon_attribute_light',
        Description: 'Tornament_event_rule_description_fractions'
    },
    Friend_Lunar_Presents: {
        ID: 209,
        Tags: ['LOCK_EVENT_LUNAR_PRESENTS', "FRIEND_FIGHT"],
        Alias: 'Tornament_event_rule_title_event3_1',
        Icon: 'Sprites/Assets/Abilities/icon_present',
        Description: 'Tornament_event_rule_description_event3_1'
    },
    Friend_Black_Market_Tournament: {
        ID: 210,
        Tags: ["EVENT_BLACK_MARKET", "FRIEND_FIGHT"],
        Alias: 'Tournament_rule_title_black_market',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_coin',
        Description: 'Tournament_rule_description_black_market'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Easy_Round_One: {
        ID: 211,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_ONE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Easy_Round_Two: {
        ID: 212,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_TWO", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Easy_Round_Three: {
        ID: 213,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_THREE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Hard_Round_One: {
        ID: 214,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_ONE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Hard_Round_Two: {
        ID: 215,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_TWO", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Itu_Fruit_Ninja_Iteration_Two_Hard_Round_Three: {
        ID: 216,
        Tags: ["EVENT_ITU_FRUIT_NINJA", "EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_THREE", "FIGHT_CUSTOM_CAMERA"],
        Alias: 'Tornament_event_rule_title_itu_fruit_ninja',
        Icon: 'Sprites/PreviewImages/Events/Rule/icon_rule_event_fruit_ninja',
        Description: 'Tornament_event_rule_description_itu_fruit_ninja'
    },
    Rule_Kibo_Event_PVE: {
        ID: 217,
        Tags: [],
        Alias: 'Tornament_event_title_description_kibo_skin_promo',
        Icon: 'Sprites/Assets/Challenges/Icons/icon_KIBO',
        Description: 'Tornament_event_rule_description_kibo_skin_promo'
    },
    Rule_Active_block_Rework: {
        ID: 218,
        Tags: ['LOCK_EVENT_ACTIVE_BLOCK_REWORK'],
        Alias: 'Tournament_rule_title_active_block_rework',
        Icon: 'Sprites/Assets/Abilities/icon_active_block',
        Description: 'Tournament_rule_description_active_block_rework'
    },
};
var tournamentRulesMap = createIDMap(tournamentRules, "tournamentRulesMap");
