var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3;
var TournamentRewards = (function () {
    function TournamentRewards() {
    }
    TournamentRewards.defaultRewardForRemovedTournament = new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 50, _a) });
    TournamentRewards.defaultLooseReward = {
        loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 25, _b) })
    };
    TournamentRewards.defaultAdWinReward = {
        chests: [chests.Upgrade_chest.ID]
    };
    TournamentRewards.defaultAdLooseReward = {
        chests: [chests.Upgrade_chest.ID]
    };
    TournamentRewards.cumulativeTemplate = {
        CardsSlots: {
            TotalCards: 5, TotalSlots: 1,
            Rarities: (_c = {},
                _c[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 1, Weight: 1 }, { Amount: 2, Weight: 1 },] },
                _c[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 1, Weight: 1 }, { Amount: 2, Weight: 1 },] },
                _c[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 0, Weight: 3 }, { Amount: 1, Weight: 1 },] },
                _c[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Amount: 0, Weight: 5 }, { Amount: 1, Weight: 1 },] },
                _c),
        },
    };
    TournamentRewards.heroesQuantity = 5;
    TournamentRewards.Tournament_Olympic_2024 = {
        rewards: {
            0: {
                repeatable: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.COIN] = 10, _d) }) },
                onetime: null
            },
            1: {
                repeatable: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.COIN] = 50, _e) }) },
                onetime: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.CHIP_3] = 50, _f) }) },
            },
            2: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 1,
                            TotalSlots: 1,
                            Rarities: (_g = {}, _g[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 1 }] }, _g)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.CHIP_3] = 100, _h) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 100, _j) }) },
                onetime: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.CHIP_3] = 150, _k) }) },
            },
            4: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 1,
                            TotalSlots: 1,
                            Rarities: (_l = {}, _l[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _l)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.CHIP_3] = 200, _m) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 250, _o) }) },
                onetime: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.CHIP_3] = 300, _p) }) },
            }
        },
    };
    TournamentRewards.Tournament_Gideon_wpn_2024 = {
        rewards: {
            0: {
                repeatable: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 10, _q) }) },
                onetime: null
            },
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.CHIP_3] = 50, _r) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.CHIP_3] = 100, _s) }) },
            },
            3: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.CHIP_3] = 150, _t) }) },
            },
            4: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.CHIP_3] = 500, _u) }) },
            },
            5: {
                repeatable: null,
                onetime: { isHidden: false, loot: new Loot({ Shards: (_v = {}, _v[heroes.Gideon.ID] = 2, _v) }) },
            }
        },
    };
    TournamentRewards.CustomizationTokenTournament = {
        easy: {
            rewards: {
                1: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.CUSTOMIZATION_TOKEN] = 150, _w) }) },
                },
                2: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.CUSTOMIZATION_TOKEN] = 165, _x) }) },
                },
                3: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.CUSTOMIZATION_TOKEN] = 195, _y) }) },
                },
                4: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.CUSTOMIZATION_TOKEN] = 240, _z) }) },
                },
            },
        },
        hard: {
            rewards: {
                1: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.CUSTOMIZATION_TOKEN] = 500, _0) }) },
                },
                2: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.CUSTOMIZATION_TOKEN] = 550, _1) }) },
                },
                3: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.CUSTOMIZATION_TOKEN] = 650, _2) }) },
                },
                4: {
                    repeatable: null,
                    onetime: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.CUSTOMIZATION_TOKEN] = 800, _3) }) },
                },
            },
        },
    };
    return TournamentRewards;
}());
