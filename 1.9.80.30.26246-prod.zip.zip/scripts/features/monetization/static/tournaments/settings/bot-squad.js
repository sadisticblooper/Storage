var TournamentBotSquad = (function () {
    function TournamentBotSquad() {
    }
    TournamentBotSquad.commonBotDifficulty = {
        0: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_9] },
        ],
    };
    TournamentBotSquad.BotSquad_Skin_Legendary = {
        0: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_7] },
        ],
        1: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_7] },
        ],
        2: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_7] },
        ],
        3: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_8] },
        ],
        4: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_8] },
        ],
        5: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_8] },
        ],
        6: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.PRESET_9] },
        ]
    };
    TournamentBotSquad.BotSquad_Idle_Tournament = {
        0: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.EASY] },
        ],
        1: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        2: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        3: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.HARD] },
        ],
        4: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.HARD] },
        ],
    };
    TournamentBotSquad.BotSquad_goldMine = {
        0: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_9] },
        ],
        1: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_9] },
        ],
        2: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_9] },
        ],
        3: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_9] },
        ],
        4: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        5: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_6] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        6: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        7: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        8: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        9: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        10: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
        11: [
            { range: { start: 0, end: 350 }, items: [MLBOT_MODE.PRESET_7] },
            { range: { start: 351, end: 600 }, items: [MLBOT_MODE.PRESET_8] },
            { range: { start: 601, end: 110 }, items: [MLBOT_MODE.PRESET_10] },
        ],
    };
    TournamentBotSquad.BotSquad_Events_Six_Stages = {
        0: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.EASY] },
        ],
        1: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        2: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.HARD] },
        ],
        3: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        4: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.HARD] },
        ],
        5: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MAX] },
        ],
    };
    TournamentBotSquad.BotSquad_Events_Five_Stages = {
        0: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.EASY] },
        ],
        1: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        2: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MEDIUM] },
        ],
        3: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.HARD] },
        ],
        4: [
            { range: { start: 0, end: 1000000 }, items: [MLBOT_MODE.MAX] },
        ],
    };
    return TournamentBotSquad;
}());
(function () {
    for (var stage = 1; stage <= 12; stage++) {
        TournamentBotSquad.commonBotDifficulty[stage] = TournamentBotSquad.commonBotDifficulty[0];
    }
})();
