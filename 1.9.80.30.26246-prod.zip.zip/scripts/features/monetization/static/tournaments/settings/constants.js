var _a;
var TournamentConstants = (function () {
    function TournamentConstants() {
    }
    TournamentConstants.maxDailyWonTournamentsWithBot = 20;
    TournamentConstants.tournamentPoolRestrictedLevel = 0;
    TournamentConstants.tournamentPoolRestrictedArenaNumber = 2;
    TournamentConstants.randomCardsTooltipDecimalPlaces = 2;
    TournamentConstants.UITimerBeforeEnd = {
        warning: new Time({ Hours: 4 }).value,
        attention: new Time({ Hours: 24 }).value,
    };
    TournamentConstants.defaultTooltipSettings = {
        tooltipHeaderAlias: "tooltip_possibly_contains",
        guaranteedTitleAlias: "tournament_tooltip_guaranteed_title_alias",
    };
    TournamentConstants.unavailableTournamentReasons = (_a = {},
        _a[TOURNAMENT_UNAVAILABLE_REASON.ACCOUNT_LEVEL] = {
            reasonAlias: "tournament_event_requires_account_level",
            toastAlias: "tournament_event_toast_requires_account_level",
        },
        _a[TOURNAMENT_UNAVAILABLE_REASON.RATING] = {
            reasonAlias: "tournament_event_requires_rating",
            toastAlias: "tournament_event_toast_requires_rating",
        },
        _a[TOURNAMENT_UNAVAILABLE_REASON.ARENA] = {
            reasonAlias: "tournament_event_requires_arena",
            toastAlias: "tournament_event_toast_requires_arena",
        },
        _a[TOURNAMENT_UNAVAILABLE_REASON.LOW_PRIORITY] = {
            reasonAlias: "tournament_event_lp",
            toastAlias: "tournament_event_toast_lp",
        },
        _a);
    TournamentConstants.tournamentRatingSettings = {
        initialTournamentRating: 50,
        ratingCap: 1100,
        eloCoefficient: 20,
        eloDistance: 400,
        coefficientMap: [
            { range: { start: 0, end: 300 }, items: [{ incRating: 1, decRating: 0.5 }] },
            { range: { start: 301, end: 800 }, items: [{ incRating: 1, decRating: 1 }] },
            { range: { start: 801, end: 1100 }, items: [{ incRating: 1, decRating: 1.5 }] },
        ],
    };
    return TournamentConstants;
}());
