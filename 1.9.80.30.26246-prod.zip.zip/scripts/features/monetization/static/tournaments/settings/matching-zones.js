var TournamentMatchingZones = (function () {
    function TournamentMatchingZones() {
    }
    TournamentMatchingZones.MatcherZones_total = {
        0: [
            {
                range: { start: 0, end: 145 }, items: [
                    { Second: 0, MinRating: -5, MaxRating: 5, MinStage: 0, MaxStage: 0, MinStreak: -1, MaxStreak: 1 },
                    { Second: 10, MinRating: -15, MaxRating: 15, MinStage: -1, MaxStage: 1, MinStreak: -2, MaxStreak: 2 },
                    { Second: 30, MinRating: -20, MaxRating: 20, MinStage: -2, MaxStage: 2, MinStreak: -3, MaxStreak: 3 },
                    { Second: 60, MinRating: -30, MaxRating: 30, MinStage: -3, MaxStage: 3, MinStreak: -6, MaxStreak: 6 },
                    { Second: 90, MinRating: -999999, MaxRating: 999999, MinStage: -999999, MaxStage: 999999, MinStreak: -999999, MaxStreak: 999999 },
                ]
            },
            {
                range: { start: 146, end: 365 }, items: [
                    { Second: 0, MinRating: -15, MaxRating: 15, MinStage: 0, MaxStage: 0, MinStreak: -1, MaxStreak: 1 },
                    { Second: 10, MinRating: -35, MaxRating: 35, MinStage: -1, MaxStage: 1, MinStreak: -2, MaxStreak: 2 },
                    { Second: 30, MinRating: -50, MaxRating: 50, MinStage: -2, MaxStage: 2, MinStreak: -3, MaxStreak: 3 },
                    { Second: 60, MinRating: -75, MaxRating: 75, MinStage: -3, MaxStage: 3, MinStreak: -6, MaxStreak: 6 },
                    { Second: 90, MinRating: -999999, MaxRating: 999999, MinStage: -999999, MaxStage: 999999, MinStreak: -999999, MaxStreak: 999999 },
                ]
            },
            {
                range: { start: 366, end: 735 }, items: [
                    { Second: 0, MinRating: -20, MaxRating: 20, MinStage: 0, MaxStage: 0, MinStreak: -1, MaxStreak: 1 },
                    { Second: 10, MinRating: -50, MaxRating: 50, MinStage: -1, MaxStage: 1, MinStreak: -2, MaxStreak: 2 },
                    { Second: 30, MinRating: -75, MaxRating: 75, MinStage: -2, MaxStage: 2, MinStreak: -3, MaxStreak: 3 },
                    { Second: 60, MinRating: -110, MaxRating: 110, MinStage: -3, MaxStage: 3, MinStreak: -6, MaxStreak: 6 },
                    { Second: 90, MinRating: -999999, MaxRating: 999999, MinStage: -999999, MaxStage: 999999, MinStreak: -999999, MaxStreak: 999999 },
                ]
            },
            {
                range: { start: 736, end: 1100 }, items: [
                    { Second: 0, MinRating: -35, MaxRating: 35, MinStage: 0, MaxStage: 0, MinStreak: -1, MaxStreak: 1 },
                    { Second: 10, MinRating: -75, MaxRating: 75, MinStage: -1, MaxStage: 1, MinStreak: -2, MaxStreak: 2 },
                    { Second: 30, MinRating: -145, MaxRating: 145, MinStage: -2, MaxStage: 2, MinStreak: -3, MaxStreak: 3 },
                    { Second: 60, MinRating: -220, MaxRating: 220, MinStage: -3, MaxStage: 3, MinStreak: -6, MaxStreak: 6 },
                    { Second: 90, MinRating: -999999, MaxRating: 999999, MinStage: -999999, MaxStage: 999999, MinStreak: -999999, MaxStreak: 999999 },
                ]
            },
        ],
    };
    TournamentMatchingZones.MatcherZones_PVE_12_stages = (function () {
        var result = {};
        for (var stage = 0; stage <= 12; stage++) {
            result[stage] = [
                {
                    range: { start: 0, end: 99999 }, items: [
                        { Second: 0, MinRating: 999999, MaxRating: 999999, MinStage: 0, MaxStage: 0, MinStreak: 99, MaxStreak: 99 }
                    ]
                },
            ];
        }
        return result;
    })();
    return TournamentMatchingZones;
}());
(function () {
    for (var stage = 1; stage <= 12; stage++) {
        TournamentMatchingZones.MatcherZones_total[stage] = TournamentMatchingZones.MatcherZones_total[0];
    }
})();
