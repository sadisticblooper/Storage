var TournamentVisualSettings = (function () {
    function TournamentVisualSettings() {
    }
    TournamentVisualSettings.presets = [
        {
            "visualPreset": "100001",
            "lobbyAndHubItemArtColor": "#ff765e",
            "draftAndEventWindowArtColor": "#a14b3b",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": -387, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ff9d8c",
            "icon": null,
        },
        {
            "visualPreset": "100003",
            "lobbyAndHubItemArtColor": "#ff765e",
            "draftAndEventWindowArtColor": "#a14b3b",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": -387, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#FFD75E",
            "eventSubTitleColorDefault": "#FF9D8C",
            "icon": null,
        },
        {
            "visualPreset": "100004",
            "lobbyAndHubItemArtColor": "#5ee7ff",
            "draftAndEventWindowArtColor": "#3b91a1",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": -450, "y": 0 },
            "hubItemPositionDefault": { "x": 324, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null,
        },
        {
            "visualPreset": "100005",
            "lobbyAndHubItemArtColor": "#ff5e76",
            "draftAndEventWindowArtColor": "#a13b4b",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#593f73",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#593f73",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#593f73",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": 36, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ff5e76",
            "eventSubTitleColorDefault": "#ff5e76",
            "icon": null,
        },
        {
            "visualPreset": "100006",
            "lobbyAndHubItemArtColor": "#ff5e76",
            "draftAndEventWindowArtColor": "#a13b4b",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#593f73",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#593f73",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#593f73",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": 36, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ff5e76",
            "eventSubTitleColorDefault": "#ff5e76",
            "icon": null,
        },
        {
            "visualPreset": "100008",
            "lobbyAndHubItemArtColor": "#ffa3bf",
            "draftAndEventWindowArtColor": "#a1586e",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": -387, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ffa3bf",
            "icon": null,
        },
        {
            "visualPreset": "100012",
            "lobbyAndHubItemArtColor": "#ff7e47",
            "draftAndEventWindowArtColor": "#a1502d",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#733e35",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#73352a",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#73352a",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#73352a",
            "hubItemPositionPremium": { "x": -387, "y": 0 },
            "hubItemPositionDefault": { "x": 387, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ff7e5e",
            "icon": null,
        },
        {
            "visualPreset": "100013",
            "lobbyAndHubItemArtColor": "#30E0FF",
            "draftAndEventWindowArtColor": "#5ECFFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#2a7332",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#FFB647",
            "draftAndEventWindowGradientColorDefault": "#35733b",
            "eventWindowGlowPremium": "#A1722D",
            "eventWindowGlowDefault": "#2a7332",
            "eventWindowRightGradientPremium": "#A1722D",
            "eventWindowRightGradientDefault": "#2a7332",
            "hubItemPositionPremium": { "x": 350, "y": 0 },
            "hubItemPositionDefault": { "x": 350, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#FFB647",
            "eventSubTitleColorDefault": "#68ff77",
            "icon": icons.event_summer_white.ID,
        },
        {
            "visualPreset": "100014",
            "lobbyAndHubItemArtColor": "#5ee7ff",
            "draftAndEventWindowArtColor": "#3b91a1",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#495a73",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#3f5473",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#3f5473",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#3f5473",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": -315, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null,
        },
        {
            "visualPreset": "100007",
            "lobbyAndHubItemArtColor": "#30FFFF",
            "draftAndEventWindowArtColor": "#30FFFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8A7127B7",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#73612A",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612A",
            "draftAndEventWindowGradientColorDefault": "#8A7127B7",
            "eventWindowGlowPremium": "#73612A",
            "eventWindowGlowDefault": "#A1842D",
            "eventWindowRightGradientPremium": "#73612A",
            "eventWindowRightGradientDefault": "#8A7127",
            "hubItemPositionPremium": { "x": -450, "y": 0 },
            "hubItemPositionDefault": { "x": -450, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#30FFA2",
            "icon": 4,
        },
        {
            "visualPreset": "100009",
            "lobbyAndHubItemArtColor": "",
            "draftAndEventWindowArtColor": "#32495C",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#730b11B7",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#73612A",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612A",
            "draftAndEventWindowGradientColorDefault": "#e517212D",
            "eventWindowGlowPremium": "#73612A",
            "eventWindowGlowDefault": "#8a272c89",
            "eventWindowRightGradientPremium": "#73612A",
            "eventWindowRightGradientDefault": "#8a272cB7",
            "hubItemPositionPremium": {
                "x": -10,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -10,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#E64049",
            "icon": null,
        },
        {
            "visualPreset": "100010",
            "lobbyAndHubItemArtColor": "#5ee7ff",
            "draftAndEventWindowArtColor": "#3b91a1",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": 0, "y": 0 },
            "hubItemPositionDefault": { "x": 180, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null,
        },
        {
            "visualPreset": "100011",
            "lobbyAndHubItemArtColor": "#5ee7ff",
            "draftAndEventWindowArtColor": "#3b91a1",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5e4973",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#593f73",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#593f73",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#593f73",
            "hubItemPositionPremium": { "x": 0, "y": 0 },
            "hubItemPositionDefault": { "x": -290, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null,
        },
        {
            "visualPreset": "100015",
            "lobbyAndHubItemArtColor": "#1AFF98",
            "draftAndEventWindowArtColor": "#1aff98",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#166573",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#3f5473",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#166573",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#166573",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": -420, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#1AFF98",
            "icon": 6,
        },
        {
            "visualPreset": "100016",
            "lobbyAndHubItemArtColor": "#47ffff",
            "draftAndEventWindowArtColor": "#47ffff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#1a5c5c",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#33a4b8",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#207373",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#207373",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": -420, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#47ffff",
            "icon": 7,
        },
        {
            "visualPreset": "100017",
            "lobbyAndHubItemArtColor": "#ffd75e",
            "draftAndEventWindowArtColor": "#ffd75e",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#732020",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#8a2727",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#8a2727",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#8a2727",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": -420, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ff5e5e",
            "icon": 9,
        },
        {
            "visualPreset": "100018",
            "lobbyAndHubItemArtColor": "#3F688A",
            "draftAndEventWindowArtColor": "#3f688a",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#B887B3",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#6ae5d3",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#3f8a7f",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#3f8a7f",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": -420, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#e5a8df",
            "icon": 10,
        },
        {
            "visualPreset": "100019",
            "lobbyAndHubItemArtColor": "#8CBAFF",
            "draftAndEventWindowArtColor": "#8CBAFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#733F4F",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#A1586E",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#A1586E",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#A1586E",
            "hubItemPositionPremium": { "x": 324, "y": 0 },
            "hubItemPositionDefault": { "x": -324, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#FF8CAF",
            "icon": 11,
        },
        {
            "visualPreset": "100020",
            "lobbyAndHubItemArtColor": "#656db8",
            "draftAndEventWindowArtColor": "#3f4473",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#730b11",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#E51721",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#B8333A",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#8a272c",
            "hubItemPositionPremium": { "x": -315, "y": 0 },
            "hubItemPositionDefault": { "x": 315, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#E64049",
            "icon": 12,
        },
        {
            "visualPreset": "100021",
            "lobbyAndHubItemArtColor": "#FFF0C2",
            "draftAndEventWindowArtColor": "#CFB974",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#82a14a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#64842B",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#708a3f",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#708a3f",
            "hubItemPositionPremium": {
                "x": -398,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 376,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#bae66a",
            "icon": 13,
        },
        {
            "visualPreset": "100022",
            "lobbyAndHubItemArtColor": "#7d7f8a",
            "draftAndEventWindowArtColor": "#7d7f8a",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#b84412",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#ff5e1a",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#8a563f",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#b84412",
            "hubItemPositionPremium": {
                "x": -450,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 324,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ff5e1a",
            "icon": 15
        },
        {
            "visualPreset": "100023",
            "lobbyAndHubItemArtColor": "#7d7f8a",
            "draftAndEventWindowArtColor": "#7d7f8a",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#b84412",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#ff5e1a",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#8a563f",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#b84412",
            "hubItemPositionPremium": {
                "x": -450,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -470,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ff5e1a",
            "icon": 15
        },
        {
            "visualPreset": "100024",
            "lobbyAndHubItemArtColor": "#8ca9ff",
            "draftAndEventWindowArtColor": "#657ab8",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#3acf75",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#3acf75",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#7e98e5",
            "draftAndEventWindowGradientColorDefault": "#7e98e5",
            "eventWindowGlowPremium": "#33b868",
            "eventWindowGlowDefault": "#33b868",
            "eventWindowRightGradientPremium": "#278a4e",
            "eventWindowRightGradientDefault": "#278a4e",
            "hubItemPositionPremium": {
                "x": -390,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -390,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#3acf75",
            "eventSubTitleColorDefault": "#3acf75",
            "icon": null,
        },
        {
            "visualPreset": "100025",
            "lobbyAndHubItemArtColor": "#b87c23",
            "draftAndEventWindowArtColor": "#b87c23",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#6f732a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#b2b844",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#b85d12",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#a1591f",
            "hubItemPositionPremium": {
                "x": -360,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 360,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ffac30",
            "icon": 17
        },
        {
            "visualPreset": "100026",
            "lobbyAndHubItemArtColor": "#b8658a",
            "draftAndEventWindowArtColor": "#ff75b3",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#b89765",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#b89765",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#b8afa7",
            "draftAndEventWindowGradientColorDefault": "#b8afa7",
            "eventWindowGlowPremium": "#B897654C",
            "eventWindowGlowDefault": "#B897654C",
            "eventWindowRightGradientPremium": "#b89765",
            "eventWindowRightGradientDefault": "#b89765",
            "hubItemPositionPremium": {
                "x": -382,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 382,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#ffa3cd",
            "icon": 34,
        },
        {
            "visualPreset": "100027",
            "lobbyAndHubItemArtColor": "#BA75FF",
            "draftAndEventWindowArtColor": "#7633b8",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#384145",
                        "time": 0
                    },
                    {
                        "color": "#5e6073",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#868bb8",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#757aa1",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#65688a",
            "hubItemPositionPremium": {
                "x": -360,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 360,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#af5eff",
            "icon": 22
        },
        {
            "visualPreset": "100028",
            "lobbyAndHubItemArtColor": "#FFFFFF",
            "draftAndEventWindowArtColor": "#b354b8",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#9c4aa1",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#9c4aa1",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#863f8a",
            "draftAndEventWindowGradientColorDefault": "#863f8a",
            "eventWindowGlowPremium": "#b354b8",
            "eventWindowGlowDefault": "#b354b8",
            "eventWindowRightGradientPremium": "#b354b8",
            "eventWindowRightGradientDefault": "#b354b8",
            "hubItemPositionPremium": {
                "x": -315,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -315,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#f875ff",
            "eventSubTitleColorDefault": "#f875ff",
            "icon": null
        },
        {
            "visualPreset": "100029",
            "lobbyAndHubItemArtColor": "#5ee7ff",
            "draftAndEventWindowArtColor": "#3b91a1",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#2d8fa1",
                        "time": 0
                    },
                    {
                        "color": "#e5a340",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#2d8fa1",
                        "time": 0
                    },
                    {
                        "color": "#e5a340",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#44a6b8",
            "draftAndEventWindowGradientColorDefault": "#44a6b8",
            "eventWindowGlowPremium": "#B8894466",
            "eventWindowGlowDefault": "#B8894466",
            "eventWindowRightGradientPremium": "#b88944",
            "eventWindowRightGradientDefault": "#b88944",
            "hubItemPositionPremium": {
                "x": -312,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -312,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#6bddff",
            "icon": null
        },
        {
            "visualPreset": "100030",
            "lobbyAndHubItemArtColor": "#8654b8",
            "draftAndEventWindowArtColor": "#8654b8",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#642a73",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#a044b8",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#A044B88A",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#9712B8B8",
            "hubItemPositionPremium": {
                "x": -450,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 324,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#df5eff",
            "icon": 28
        },
        {
            "visualPreset": "100031",
            "lobbyAndHubItemArtColor": "#FFFFFF",
            "draftAndEventWindowArtColor": "#524973",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8a201a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#b82a23",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#5c1511",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#8a201a",
            "hubItemPositionPremium": {
                "x": -15,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -15,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#e6352c",
            "icon": null
        },
        {
            "visualPreset": "100032",
            "lobbyAndHubItemArtColor": "#5fcfcf",
            "draftAndEventWindowArtColor": "#5fcfcf",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#33568a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#7c75ff",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#4472b8",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#4472b8",
            "hubItemPositionPremium": {
                "x": -450,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 324,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5f8dcf",
            "icon": 26
        },
        {
            "visualPreset": "100033",
            "lobbyAndHubItemArtColor": "#5fcfcf",
            "draftAndEventWindowArtColor": "#5fcfcf",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#33568a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#7c75ff",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#4472b8",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#4472b8",
            "hubItemPositionPremium": {
                "x": -450,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -450,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5f8dcf",
            "icon": 26
        },
        {
            "visualPreset": "100034",
            "lobbyAndHubItemArtColor": "#FFD75E",
            "draftAndEventWindowArtColor": "#FFD75E",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8A200E",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0,
                        "time": 0
                    },
                    {
                        "alpha": 0,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#8A200E",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#E546022E",
            "draftAndEventWindowGradientColorDefault": "#E546022E",
            "eventWindowGlowPremium": "#8A200E8A",
            "eventWindowGlowDefault": "#8A200E8A",
            "eventWindowRightGradientPremium": "#b83923",
            "eventWindowRightGradientDefault": "#b83923",
            "hubItemPositionPremium": {
                "x": -27,
                "y": 75
            },
            "hubItemPositionDefault": {
                "x": -27,
                "y": 75
            },
            "hubItemScalePremium": 0.9,
            "hubItemScaleDefault": 0.9,
            "eventSubTitleColorPremium": "#e69b2c",
            "eventSubTitleColorDefault": "#e69b2c",
            "icon": null
        },
        {
            "visualPreset": "100035",
            "lobbyAndHubItemArtColor": "#30FFFF",
            "draftAndEventWindowArtColor": "#30FFFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8A7127B7",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#73612A",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612A",
            "draftAndEventWindowGradientColorDefault": "#8A7127B7",
            "eventWindowGlowPremium": "#73612A",
            "eventWindowGlowDefault": "#A1842D",
            "eventWindowRightGradientPremium": "#73612A",
            "eventWindowRightGradientDefault": "#8A7127",
            "hubItemPositionPremium": { "x": 324, "y": 0 },
            "hubItemPositionDefault": { "x": 324, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#30FFA2",
            "icon": 4,
        },
        {
            "visualPreset": "100036",
            "lobbyAndHubItemArtColor": "#a3ffe3",
            "draftAndEventWindowArtColor": "#37A6B98A",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#76b8a4",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#76b8a4",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#a3ffe3",
            "draftAndEventWindowGradientColorDefault": "#a3ffe3",
            "eventWindowGlowPremium": "#497366",
            "eventWindowGlowDefault": "#497366",
            "eventWindowRightGradientPremium": "#497366",
            "eventWindowRightGradientDefault": "#497366",
            "hubItemPositionPremium": {
                "x": -323,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -323,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#a3ffe3",
            "eventSubTitleColorDefault": "#a3ffe3",
            "icon": null
        },
        {
            "visualPreset": "100037",
            "lobbyAndHubItemArtColor": "#ffffff",
            "draftAndEventWindowArtColor": "#ffffff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#4c778a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#7ec7e5",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#4c778a",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#659fb8",
            "hubItemPositionPremium": {
                "x": -420,
                "y": 15
            },
            "hubItemPositionDefault": {
                "x": 420,
                "y": 15
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#e52c2c",
            "icon": 32
        },
        {
            "visualPreset": "100038",
            "lobbyAndHubItemArtColor": "#D2D2D2",
            "draftAndEventWindowArtColor": "#5fcfcf",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#33568a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#7c75ff",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#4472b8",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#4472b8",
            "hubItemPositionPremium": {
                "x": -300,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -300,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5fcfcf",
            "icon": null
        },
        {
            "visualPreset": "100039",
            "lobbyAndHubItemArtColor": "#FFFFFF",
            "draftAndEventWindowArtColor": "#3354b8",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#5c5243",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#b833aa",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#b833aa",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#b833aa",
            "hubItemPositionPremium": {
                "x": -178,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -178,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#cf3ac0",
            "icon": null
        },
        {
            "visualPreset": "100040",
            "lobbyAndHubItemArtColor": "#5ECFFF",
            "draftAndEventWindowArtColor": "#5ECFFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#593F73",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612A",
            "draftAndEventWindowGradientColorDefault": "#3F5473",
            "eventWindowGlowPremium": "#73612A",
            "eventWindowGlowDefault": "#593F73",
            "eventWindowRightGradientPremium": "#73612A",
            "eventWindowRightGradientDefault": "#593F73",
            "hubItemPositionPremium": { "x": -513, "y": 0 },
            "hubItemPositionDefault": { "x": 262, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#FFD75E",
            "eventSubTitleColorDefault": "#C38BFC",
            "icon": 0,
        },
        {
            "visualPreset": "100041",
            "lobbyAndHubItemArtColor": "#FFFFFFA1",
            "draftAndEventWindowArtColor": "#586C8A8A",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#586c8a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#586c8a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#495a73",
            "draftAndEventWindowGradientColorDefault": "#495a73",
            "eventWindowGlowPremium": "#262b2e",
            "eventWindowGlowDefault": "#262b2e",
            "eventWindowRightGradientPremium": "#495a73",
            "eventWindowRightGradientDefault": "#495a73",
            "hubItemPositionPremium": {
                "x": 210,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 210,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#a3c8ff",
            "eventSubTitleColorDefault": "#a3c8ff",
            "icon": null
        },
        {
            "visualPreset": "100042",
            "lobbyAndHubItemArtColor": "#e6c493",
            "draftAndEventWindowArtColor": "#e6c493",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#337d8a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#5ee7ff",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#8a76588A",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#b89c76B8",
            "hubItemPositionPremium": {
                "x": -190,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -190,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null
        },
        {
            "visualPreset": "100043",
            "lobbyAndHubItemArtColor": "#f41aff",
            "draftAndEventWindowArtColor": "#f41aff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#0e8a8a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#0e8a8a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#12b8b8",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#b812128A",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#ff1a1aB8",
            "hubItemPositionPremium": {
                "x": -30,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -30,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#1affff",
            "icon": null
        },
        {
            "visualPreset": "100044",
            "lobbyAndHubItemArtColor": "#ffffff",
            "draftAndEventWindowArtColor": "#ffffff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8a201a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#8a201a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#170a04",
            "draftAndEventWindowGradientColorDefault": "#170a04",
            "eventWindowGlowPremium": "#e54051",
            "eventWindowGlowDefault": "#e54051",
            "eventWindowRightGradientPremium": "#e54051",
            "eventWindowRightGradientDefault": "#e54051",
            "hubItemPositionPremium": {
                "x": 198,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 198,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#e5c493",
            "eventSubTitleColorDefault": "#e5c493",
            "icon": null
        },
        {
            "visualPreset": "100045",
            "lobbyAndHubItemArtColor": "#8CA9FF",
            "draftAndEventWindowArtColor": "#5e87ff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#384145",
                        "time": 0
                    },
                    {
                        "color": "#676da1",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#384145",
                        "time": 0
                    },
                    {
                        "color": "#676da1",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#a3acff",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#384145",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#676da1",
            "hubItemPositionPremium": {
                "x": -398,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 376,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#a3acff",
            "icon": 40
        },
        {
            "visualPreset": "100046",
            "lobbyAndHubItemArtColor": "#546db8ff",
            "draftAndEventWindowArtColor": "#92ADFF",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#513f73",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#513f73",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#273f8a",
            "draftAndEventWindowGradientColorDefault": "#273f8a",
            "eventWindowGlowPremium": "#51338a",
            "eventWindowGlowDefault": "#51338a",
            "eventWindowRightGradientPremium": "#51338a",
            "eventWindowRightGradientDefault": "#51338a",
            "hubItemPositionPremium": {
                "x": 0,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": 0,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#a3baff",
            "eventSubTitleColorDefault": "#a3baff",
            "icon": null
        },
        {
            "visualPreset": "100047",
            "lobbyAndHubItemArtColor": "#FFFFFF",
            "draftAndEventWindowArtColor": "#524973",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#8a201a",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#736335",
                        "time": 0
                    },
                    {
                        "color": "#384145",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#73612a",
            "draftAndEventWindowGradientColorDefault": "#b82a23",
            "eventWindowGlowPremium": "#73612a",
            "eventWindowGlowDefault": "#5c1511",
            "eventWindowRightGradientPremium": "#73612a",
            "eventWindowRightGradientDefault": "#8a201a",
            "hubItemPositionPremium": {
                "x": -15,
                "y": 0
            },
            "hubItemPositionDefault": {
                "x": -15,
                "y": 0
            },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#ffd75e",
            "eventSubTitleColorDefault": "#e6352c",
            "icon": null
        },
        {
            "visualPreset": "100048",
            "lobbyAndHubItemArtColor": "#44a6b8C1",
            "draftAndEventWindowArtColor": "#47acff",
            "lobbyAndHubItemGradientDefault": {
                "colorKeys": [
                    {
                        "color": "#47acff",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "lobbyAndHubItemGradientPremium": {
                "colorKeys": [
                    {
                        "color": "#47acff",
                        "time": 0.0
                    },
                    {
                        "color": "#384145",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1.0,
                        "time": 0.0
                    },
                    {
                        "alpha": 1.0,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "draftAndEventWindowGradientColorPremium": "#275d8a",
            "draftAndEventWindowGradientColorDefault": "#275d8a",
            "eventWindowGlowPremium": "#337d8a",
            "eventWindowGlowDefault": "#337d8a",
            "eventWindowRightGradientPremium": "#337d8a",
            "eventWindowRightGradientDefault": "#337d8a",
            "hubItemPositionPremium": { "x": 0, "y": 0 },
            "hubItemPositionDefault": { "x": 0, "y": 0 },
            "hubItemScalePremium": 1,
            "hubItemScaleDefault": 1,
            "eventSubTitleColorPremium": "#5ee7ff",
            "eventSubTitleColorDefault": "#5ee7ff",
            "icon": null
        },
    ];
    TournamentVisualSettings.cardsPreset = [
        {
            Alias: "DraftCardAlias",
            Description: "DraftCardDescription",
            Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
            ImageColor: "#ffffff"
        },
        {
            Alias: "DraftCardAlias",
            Description: "DraftCardDescription",
            Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
            ImageColor: "#ffffff"
        },
        {
            Alias: "DraftCardAlias",
            Description: "DraftCardDescription",
            Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
            ImageColor: "#ffffff"
        }
    ];
    return TournamentVisualSettings;
}());
