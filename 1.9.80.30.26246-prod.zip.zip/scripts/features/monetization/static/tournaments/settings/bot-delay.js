var TournamentBotDelay = (function () {
    function TournamentBotDelay() {
    }
    TournamentBotDelay.BotDelay_12_stages = {
        0: new RndFromInterval(new Time({ Seconds: 40 }).value, new Time({ Seconds: 50 }).value),
        1: new RndFromInterval(new Time({ Seconds: 55 }).value, new Time({ Seconds: 65 }).value),
        2: new RndFromInterval(new Time({ Seconds: 85 }).value, new Time({ Seconds: 95 }).value),
        3: new RndFromInterval(new Time({ Seconds: 100 }).value, new Time({ Seconds: 110 }).value),
        4: new RndFromInterval(new Time({ Seconds: 120 }).value, new Time({ Seconds: 130 }).value),
        5: new RndFromInterval(new Time({ Seconds: 120 }).value, new Time({ Seconds: 130 }).value),
        6: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
        7: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
        8: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
        9: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
        10: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
        11: new RndFromInterval(new Time({ Seconds: 180 }).value, new Time({ Seconds: 190 }).value),
    };
    TournamentBotDelay.BotDelay_noDelay = {
        0: new RndFromInterval(new Time({ Seconds: 0 }).value),
        1: new RndFromInterval(new Time({ Seconds: 0 }).value),
        2: new RndFromInterval(new Time({ Seconds: 0 }).value),
        3: new RndFromInterval(new Time({ Seconds: 0 }).value),
        4: new RndFromInterval(new Time({ Seconds: 0 }).value),
        5: new RndFromInterval(new Time({ Seconds: 0 }).value),
        6: new RndFromInterval(new Time({ Seconds: 0 }).value),
        7: new RndFromInterval(new Time({ Seconds: 0 }).value),
        8: new RndFromInterval(new Time({ Seconds: 0 }).value),
        9: new RndFromInterval(new Time({ Seconds: 0 }).value),
        10: new RndFromInterval(new Time({ Seconds: 0 }).value),
        11: new RndFromInterval(new Time({ Seconds: 0 }).value),
        12: new RndFromInterval(new Time({ Seconds: 0 }).value),
    };
    return TournamentBotDelay;
}());
