var tournamentsPopupVisualConfigs = CommonPopUpUtils.setActivityPopupsOverMap(activityPopupsMap, [
    {
        data: {
            "ID": 4000,
            "priority": 2,
            "navigation": POPUP_NAVIGATION.TOURNAMENTS,
            "navigationArg": 10004,
            "activeTime": EventTimeConstants.defaultEventMock.popups._1,
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 5,
            "rulesDescription": {
                "alias": "popup_rules_event5",
                "color": "#C68CFF"
            },
            "rulesHeader": {
                "alias": "popup_event_rules_title",
                "color": "#FFFFFF"
            },
            "header": {
                "alias": "popup_title_event5",
                "color": "#FFD75E"
            },
            "subHeader": {
                "alias": "event_popup_currency_title",
                "color": "#FFD75E"
            },
            "timer": {
                "alias": "quest_ends_timer",
                "color": "#FFD75E"
            },
            "button": {
                "alias": "button_shop",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Events/AprilEvent/art_event_April",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Events/AprilEvent/bg_event_April",
                "color": "#5ECFFF"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#C68CFF"
            },
            "particles": {
                "maxColor": "#C68CFF",
                "minColor": "#C68CFF"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#493f73"
                    },
                    {
                        "time": 0.98,
                        "color": "#493f73"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#c68cff"
                    },
                    {
                        "time": 0.99,
                        "color": "#2a5d73"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": [
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_ACTIVITIES",
                    "alias": "event1_benefit_desc_1",
                    "color": "#C68CFF"
                },
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_EVENT_TOKEN",
                    "alias": "event1_benefit_desc_2",
                    "color": "#C68CFF"
                },
                {
                    "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_TICKET",
                    "alias": "event1_benefit_desc_3",
                    "color": "#C68CFF"
                }
            ],
            "pattern": {
                "sprite": "",
                "color": "#ffffff00"
            },
        },
    },
    {
        data: {
            "ID": 4001,
            "priority": 2,
            "navigation": POPUP_NAVIGATION.TOURNAMENTS,
            "navigationArg": 134,
            "activeTime": CommonUtils.getStartEndByDays(new Date("2024-08-29").getTime(), [2, 6]),
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 26,
            "rulesDescription": {
                "alias": "popup_rules_social_gideon",
                "color": "#558fe5"
            },
            "rulesHeader": {
                "alias": "popup_event_rules_title",
                "color": "#FFFFFF"
            },
            "header": {
                "alias": "popup_title_social_gideon",
                "color": "#5e9fff"
            },
            "subHeader": null,
            "timer": {
                "alias": "quest_ends_timer",
                "color": "#5fcfcf"
            },
            "button": {
                "alias": "button_tournament",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Events/GideonEvent/art_event_gideon",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Events/GideonEvent/bg_activity_gideon",
                "color": "#93e5e5"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#5e9fff"
            },
            "particles": {
                "maxColor": "#5e9fff",
                "minColor": "#5e9fff"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#22395c"
                    },
                    {
                        "time": 0.98,
                        "color": "#22395c"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#4472b8"
                    },
                    {
                        "time": 0.99,
                        "color": "#0f1717"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": null,
            "pattern": {
                "sprite": "Sprites/PreviewImages/Events/MidsommarEvent/pattern_midsommar",
                "color": "#22395c"
            },
        },
    },
    {
        data: {
            "ID": 4002,
            "priority": 2,
            "navigation": POPUP_NAVIGATION.TOURNAMENTS,
            "navigationArg": 152,
            "activeTime": CommonUtils.getStartEndByDays(new Date("2025-01-16").getTime(), [2, 6]),
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 32,
            "rulesDescription": {
                "alias": "popup_rules_social_widow",
                "color": "#7ec7e6"
            },
            "rulesHeader": {
                "alias": "popup_event_rules_title",
                "color": "#FFFFFF"
            },
            "header": {
                "alias": "popup_title_social_widow",
                "color": "#e62c2c"
            },
            "subHeader": null,
            "timer": {
                "alias": "quest_ends_timer",
                "color": "#7ec7e6"
            },
            "button": {
                "alias": "button_tournament",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Events/WidowEvent/art_event_widow",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Events/WidowEvent/bg_tournament_widow",
                "color": "#ffffff"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#7EC7E565"
            },
            "particles": {
                "maxColor": "#7ec7e5",
                "minColor": "#7ec7e5"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#4D7080"
                    },
                    {
                        "time": 0.98,
                        "color": "#4D7080"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#4c778a"
                    },
                    {
                        "time": 0.99,
                        "color": "#8a1a1a"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": null,
            "pattern": {
                "sprite": "Sprites/PreviewImages/Events/WidowEvent/pattern_widow",
                "color": "#0000002E"
            },
        },
    },
]);
