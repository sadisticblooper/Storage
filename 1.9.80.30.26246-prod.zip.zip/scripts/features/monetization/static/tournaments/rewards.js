var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35;
var StaticTournamentsRewards = {
    factions: {
        loseRewards: [
            {
                check: function (s) { return true; }, reward: {
                    loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 25, _a) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 115, _b) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 4,
                            TotalSlots: 1,
                            Rarities: (_c = {}, _c[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 4 }] }, _c)
                        }
                    }, isHidden: true,
                },
            },
            2: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 5,
                            TotalSlots: 1,
                            Rarities: (_d = {}, _d[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _d)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.COIN] = 200, _e) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 300, _f) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 7,
                            TotalSlots: 1,
                            Rarities: (_g = {}, _g[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 7 }] }, _g)
                        }
                    }, isHidden: true,
                },
            },
            4: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 13,
                            TotalSlots: 1,
                            Rarities: (_h = {}, _h[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 13 }] }, _h)
                        }
                    }, isHidden: true,
                },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 10,
                            TotalSlots: 1,
                            Rarities: (_j = {}, _j[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _j)
                        }
                    }, isHidden: true,
                },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.COIN] = 500, _k) }) },
                onetime: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.COIN] = 500, _l) }) },
            },
            6: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 30,
                            TotalSlots: 1,
                            Rarities: (_m = {}, _m[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 30 }] }, _m)
                        }
                    }, isHidden: true,
                },
                onetime: { chests: [chests.Rare_chest.ID] },
            }
        },
    },
    Tournament_pve: {
        loseRewards: [
            {
                check: function (s) { return true; }, reward: {
                    loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 25, _o) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 115, _p) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 4,
                            TotalSlots: 1,
                            Rarities: (_q = {}, _q[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 4 }] }, _q)
                        }
                    }, isHidden: true,
                },
            },
            2: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 5,
                            TotalSlots: 1,
                            Rarities: (_r = {}, _r[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 }] }, _r)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 200, _s) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.COIN] = 300, _t) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 7,
                            TotalSlots: 1,
                            Rarities: (_u = {}, _u[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 7 }] }, _u)
                        }
                    }, isHidden: true,
                },
            },
            4: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 13,
                            TotalSlots: 1,
                            Rarities: (_v = {}, _v[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 13 }] }, _v)
                        }
                    }, isHidden: true,
                },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 10,
                            TotalSlots: 1,
                            Rarities: (_w = {}, _w[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _w)
                        }
                    }, isHidden: true,
                },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.COIN] = 500, _x) }) },
                onetime: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.COIN] = 500, _y) }) },
            },
            6: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 30,
                            TotalSlots: 1,
                            Rarities: (_z = {}, _z[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 30 }] }, _z)
                        }
                    }, isHidden: true,
                },
                onetime: { chests: [chests.Rare_chest.ID] },
            }
        },
    },
    Tournament_weather: {
        loseRewards: [
            {
                check: function (s) { return true; }, reward: {
                    loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.COIN] = 25, _0) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.COIN] = 115, _1) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 10,
                            TotalSlots: 1,
                            Rarities: (_2 = {}, _2[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _2)
                        }
                    }, isHidden: true,
                },
            },
            2: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 1,
                            TotalSlots: 1,
                            Rarities: (_3 = {}, _3[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 1 }] }, _3)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.COIN] = 200, _4) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.COIN] = 300, _5) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 20,
                            TotalSlots: 1,
                            Rarities: (_6 = {}, _6[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _6)
                        }
                    }, isHidden: true,
                },
            },
            4: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 35,
                            TotalSlots: 1,
                            Rarities: (_7 = {}, _7[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 35 }] }, _7)
                        }
                    }, isHidden: true,
                },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 30,
                            TotalSlots: 1,
                            Rarities: (_8 = {}, _8[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 30 }] }, _8)
                        }
                    }, isHidden: true,
                },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.COIN] = 500, _9) }) },
                onetime: { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.COIN] = 500, _10) }) },
            },
            6: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 12,
                            TotalSlots: 1,
                            Rarities: (_11 = {}, _11[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 12 }] }, _11)
                        }
                    }, isHidden: true,
                },
                onetime: { chests: [chests.Rare_chest.ID] },
            }
        },
    },
    Tournament_walls: {
        loseRewards: [
            {
                check: function (s) { return true; }, reward: {
                    loot: new Loot({ Currencies: (_12 = {}, _12[CURRENCY.COIN] = 25, _12) })
                }
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.COIN] = 115, _13) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 10,
                            TotalSlots: 1,
                            Rarities: (_14 = {}, _14[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 10 }] }, _14)
                        }
                    }, isHidden: true,
                },
            },
            2: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 1,
                            TotalSlots: 1,
                            Rarities: (_15 = {}, _15[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 1 }] }, _15)
                        }
                    }, isHidden: true,
                },
                onetime: { loot: new Loot({ Currencies: (_16 = {}, _16[CURRENCY.COIN] = 200, _16) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_17 = {}, _17[CURRENCY.COIN] = 300, _17) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 20,
                            TotalSlots: 1,
                            Rarities: (_18 = {}, _18[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _18)
                        }
                    }, isHidden: true,
                },
            },
            4: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 35,
                            TotalSlots: 1,
                            Rarities: (_19 = {}, _19[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 35 }] }, _19)
                        }
                    }, isHidden: true,
                },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 30,
                            TotalSlots: 1,
                            Rarities: (_20 = {}, _20[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 30 }] }, _20)
                        }
                    }, isHidden: true,
                },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_21 = {}, _21[CURRENCY.COIN] = 500, _21) }) },
                onetime: { loot: new Loot({ Currencies: (_22 = {}, _22[CURRENCY.COIN] = 500, _22) }) },
            },
            6: {
                repeatable: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 12,
                            TotalSlots: 1,
                            Rarities: (_23 = {}, _23[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 12 }] }, _23)
                        }
                    }, isHidden: true,
                },
                onetime: { chests: [chests.Rare_chest.ID] },
            }
        },
    },
    Tournament_newbie: {
        rewards: {
            0: {
                repeatable: { loot: new Loot({ Currencies: (_24 = {}, _24[CURRENCY.COIN] = 5, _24) }) },
                onetime: null
            },
            1: {
                repeatable: { loot: new Loot({ Currencies: (_25 = {}, _25[CURRENCY.COIN] = 10, _25) }) },
                onetime: { loot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.COIN] = 100, _26) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_27 = {}, _27[CURRENCY.COIN] = 10, _27) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 25,
                            TotalSlots: 1,
                            Rarities: (_28 = {}, _28[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 1 }] }, _28)
                        }
                    }, isHidden: true,
                },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.COIN] = 15, _29) }) },
                onetime: { chests: [chests.Upgrade_chest.ID] },
            },
            4: {
                repeatable: { loot: new Loot({ Currencies: (_30 = {}, _30[CURRENCY.COIN] = 20, _30) }) },
                onetime: { loot: new Loot({ Currencies: (_31 = {}, _31[CURRENCY.COIN] = 300, _31) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.COIN] = 25, _32) }) },
                onetime: {
                    lootSettings: {
                        CardsSlots: {
                            TotalCards: 5,
                            TotalSlots: 1,
                            Rarities: (_33 = {}, _33[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 1 }] }, _33)
                        }
                    }, isHidden: true,
                },
            },
            6: {
                repeatable: { loot: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.COIN] = 25, _34) }) },
                onetime: { isHidden: false, loot: new Loot({ Shards: (_35 = {}, _35[heroes.Lynx.ID] = 3, _35) }) },
            },
        },
    }
};
