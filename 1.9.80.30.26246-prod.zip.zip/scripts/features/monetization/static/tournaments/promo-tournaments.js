var _a, _b, _c, _d;
var promoTournaments = (function () {
    function promoTournaments() {
    }
    promoTournaments.NewbieTournament = new TournamentGroup({
        ID: 1000,
        Duration: new Time({ Days: 3 }).value,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'tournament_description_new_players',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.NewbieTournamentHeroes,
        RestrictionPlayerParams: {
            Rating: { min: 40, max: 120 }
        },
        GuaranteeDraft: {
            heroId: heroes.Lynx.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [HeroNames.Lynx.ID],
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 6,
        DefeatsNumberToExit: 3,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.NEWBIE_TOURNAMENT.ID,
        LocationPool: [
            locations.eldorado.ID,
            locations.viper_backstreet.ID,
            locations.thunder.ID
        ],
        PresetID: 100024,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'tournament_title_new_players',
                    AliasSubName: 'tournament_subtitle_new_players',
                    CardAliasSubName: 'tournament_new_players_lowercase',
                    Prices: [(_a = {}, _a[CURRENCY.COIN] = 10, _a)],
                    Rewards: StaticTournamentsRewards.Tournament_newbie,
                    PictureInHub: "Sprites/PreviewImages/Events/Starter/event_art_StarterTournament",
                    PictureInWindow: "Sprites/PreviewImages/Events/Starter/event_art_StarterTournament",
                    PictureSmall: "Sprites/PreviewImages/Events/Starter/event_banner_art_StarterTournament",
                },
            ]
        },
    });
    promoTournaments.CustomizationTokenTournament = new TournamentGroup({
        ID: 1001,
        TeamMode: TEAM_MODE._1_VS_1_,
        isDefeatBotBlocked: true,
        StartDate: Time.convertEuropeanDateToTimestampMs('23.07.26'),
        EndDate: Time.convertEuropeanDateToTimestampMs('23.07.26') + new Time({ Days: 3 }).value,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_pit_desc',
        InfoCards: TournamentVisualSettings.cardsPreset.slice(0, 1),
        AccountLevel: 6,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_6,
        RestrictionPlayerParams: {},
        SpecialPromoRestrictions: {
            currencies: (_b = {}, _b[CURRENCY.CUSTOMIZATION_TOKEN] = { more_or_equal: 300 }, _b),
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 4,
        DefeatsNumberToExit: 2,
        MatchingZones: TournamentMatchingZones.MatcherZones_total,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MaxDailyWonTournamentsWithBot: 0,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        BattleID: battleSettings.EVENT_NO_RULES_1x1.ID,
        heroesQuantityToChoice: 5,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.castle.ID,
            locations.viper_backstreet.ID,
            locations.pve_5_1.ID,
        ],
        PresetID: 100048,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_pit_easy_title',
                    AliasSubName: 'Tournament_pit_easy_subtitle',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_c = {}, _c[CURRENCY.CUSTOMIZATION_TOKEN] = 300, _c)],
                    Rewards: TournamentRewards.CustomizationTokenTournament.easy,
                    PictureInHub: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_hub_1",
                    PictureInWindow: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_window_1",
                    PictureSmall: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_banner_1",
                },
                {
                    AliasName: 'Tournament_pit_hard_title',
                    AliasSubName: 'Tournament_pit_hard_subtitle',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_d = {}, _d[CURRENCY.CUSTOMIZATION_TOKEN] = 1000, _d)],
                    Rewards: TournamentRewards.CustomizationTokenTournament.hard,
                    PictureInHub: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_hub_2",
                    PictureInWindow: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_window_2",
                    PictureSmall: "Sprites/PreviewImages/Events/Insignias/tournament_art_insignias_banner_2",
                    PremiumType: {
                        IsPremium: true,
                        Alias: 'tournament_event_high_stakes'
                    },
                },
            ]
        },
    });
    return promoTournaments;
}());
