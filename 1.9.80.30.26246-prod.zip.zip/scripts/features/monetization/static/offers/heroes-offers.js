var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41;
extend(offers, {
    PROMO_HERO_SET_1: new PromoOffer({
        ID: 5100,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_a = {}, _a[heroes.Monkey_King.ID] = { Level: { more_or_equal: 4 }, Exp: { more_or_equal: 0 } }, _a)
        },
        noCustomizeExist: (_b = {},
            _b[CUSTOMIZATION.SKIN] = [1801],
            _b),
        customizeExist: (_c = {},
            _c[CUSTOMIZATION.WEAPON] = [30119],
            _c),
        enablePopup: true,
        popupSettings: {
            popUpId: 95100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monkey_King_E_Stranger.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_2: new PromoOffer({
        ID: 5101,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_d = {}, _d[heroes.Midnight.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _d)
        },
        noCustomizeExist: (_e = {},
            _e[CUSTOMIZATION.SKIN] = [1601],
            _e),
        customizeExist: (_f = {},
            _f[CUSTOMIZATION.WEAPON] = [30108],
            _f),
        enablePopup: true,
        popupSettings: {
            popUpId: 95101,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Midnight_E_Ghost.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_3: new PromoOffer({
        ID: 5102,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_g = {}, _g[heroes.Ling.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _g)
        },
        noCustomizeExist: (_h = {},
            _h[CUSTOMIZATION.SKIN] = [104],
            _h),
        customizeExist: (_j = {},
            _j[CUSTOMIZATION.WEAPON] = [30101],
            _j),
        enablePopup: true,
        popupSettings: {
            popUpId: 95102,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ling_E_Raven.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_4: new PromoOffer({
        ID: 5103,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_k = {}, _k[heroes.Fireguard.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _k)
        },
        noCustomizeExist: (_l = {},
            _l[CUSTOMIZATION.SKIN] = [502],
            _l),
        customizeExist: (_m = {},
            _m[CUSTOMIZATION.WEAPON] = [30105],
            _m),
        enablePopup: true,
        popupSettings: {
            popUpId: 95103,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Fireguard_E_White.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_5: new PromoOffer({
        ID: 5104,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_o = {}, _o[heroes.Monk.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _o)
        },
        noCustomizeExist: (_p = {},
            _p[CUSTOMIZATION.SKIN] = [202],
            _p),
        customizeExist: (_q = {},
            _q[CUSTOMIZATION.WEAPON] = [30102],
            _q),
        enablePopup: true,
        popupSettings: {
            popUpId: 95104,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monk_E_Cursed.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_6: new PromoOffer({
        ID: 5105,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_r = {}, _r[heroes.Helga.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _r)
        },
        noCustomizeExist: (_s = {},
            _s[CUSTOMIZATION.SKIN] = [603],
            _s),
        customizeExist: (_t = {},
            _t[CUSTOMIZATION.WEAPON] = [30106],
            _t),
        enablePopup: true,
        popupSettings: {
            popUpId: 95105,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Helga_E_Phoenix_skin.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_7: new PromoOffer({
        ID: 5106,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_u = {}, _u[heroes.Marcus.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _u)
        },
        noCustomizeExist: (_v = {},
            _v[CUSTOMIZATION.SKIN] = [1303],
            _v),
        customizeExist: (_w = {},
            _w[CUSTOMIZATION.WEAPON] = [30214],
            _w),
        enablePopup: true,
        popupSettings: {
            popUpId: 95106,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Marcus_E_Royal_skin.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_8: new PromoOffer({
        ID: 5107,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_x = {}, _x[heroes.Bulwark.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _x)
        },
        noCustomizeExist: (_y = {},
            _y[CUSTOMIZATION.SKIN] = [1001],
            _y),
        customizeExist: (_z = {},
            _z[CUSTOMIZATION.WEAPON] = [30111],
            _z),
        enablePopup: true,
        popupSettings: {
            popUpId: 95107,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_E_Gold_skin.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_9: new PromoOffer({
        ID: 5108,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_0 = {}, _0[heroes.Emperor.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _0)
        },
        noCustomizeExist: (_1 = {},
            _1[CUSTOMIZATION.SKIN] = [1102],
            _1),
        customizeExist: (_2 = {},
            _2[CUSTOMIZATION.WEAPON] = [30112],
            _2),
        enablePopup: true,
        popupSettings: {
            popUpId: 95108,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Emperor_E_Doomed_skin.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_10: new PromoOffer({
        ID: 5109,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_3 = {}, _3[heroes.Kibo.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _3)
        },
        noCustomizeExist: (_4 = {},
            _4[CUSTOMIZATION.SKIN] = [1203],
            _4),
        customizeExist: (_5 = {},
            _5[CUSTOMIZATION.WEAPON] = [30113],
            _5),
        enablePopup: true,
        popupSettings: {
            popUpId: 95109,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Kibo_E_Oriental_skin.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_11: new PromoOffer({
        ID: 5130,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_6 = {}, _6[heroes.Jet.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _6)
        },
        noCustomizeExist: (_7 = {},
            _7[CUSTOMIZATION.SKIN] = [703],
            _7),
        customizeExist: (_8 = {},
            _8[CUSTOMIZATION.WEAPON] = [30107],
            _8),
        enablePopup: true,
        popupSettings: {
            popUpId: 95130,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Jet_E_Water.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_1_2: new PromoOffer({
        ID: 5110,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_9 = {}, _9[heroes.Monkey_King.ID] = { Level: { more_or_equal: 4 }, Exp: { more_or_equal: 0 } }, _9)
        },
        noCustomizeExist: (_10 = {},
            _10[CUSTOMIZATION.WEAPON] = [30119],
            _10),
        customizeExist: (_11 = {},
            _11[CUSTOMIZATION.SKIN] = [1801],
            _11),
        enablePopup: true,
        popupSettings: {
            popUpId: 95110,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_E_Nephritis.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_2_2: new PromoOffer({
        ID: 5111,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_12 = {}, _12[heroes.Midnight.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _12)
        },
        noCustomizeExist: (_13 = {},
            _13[CUSTOMIZATION.WEAPON] = [30108],
            _13),
        customizeExist: (_14 = {},
            _14[CUSTOMIZATION.SKIN] = [1601],
            _14),
        enablePopup: true,
        popupSettings: {
            popUpId: 95111,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_3_2: new PromoOffer({
        ID: 5112,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_15 = {}, _15[heroes.Ling.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _15)
        },
        noCustomizeExist: (_16 = {},
            _16[CUSTOMIZATION.WEAPON] = [30101],
            _16),
        customizeExist: (_17 = {},
            _17[CUSTOMIZATION.SKIN] = [104],
            _17),
        enablePopup: true,
        popupSettings: {
            popUpId: 95112,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Ling_E_Shadow_Edge.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_4_2: new PromoOffer({
        ID: 5113,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_18 = {}, _18[heroes.Fireguard.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _18)
        },
        noCustomizeExist: (_19 = {},
            _19[CUSTOMIZATION.WEAPON] = [30105],
            _19),
        customizeExist: (_20 = {},
            _20[CUSTOMIZATION.SKIN] = [502],
            _20),
        enablePopup: true,
        popupSettings: {
            popUpId: 95113,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Fireguard_E_Bones.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_5_2: new PromoOffer({
        ID: 5114,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_21 = {}, _21[heroes.Monk.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _21)
        },
        noCustomizeExist: (_22 = {},
            _22[CUSTOMIZATION.WEAPON] = [30102],
            _22),
        customizeExist: (_23 = {},
            _23[CUSTOMIZATION.SKIN] = [202],
            _23),
        enablePopup: true,
        popupSettings: {
            popUpId: 95114,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Monk_E_Druid.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_6_2: new PromoOffer({
        ID: 5115,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_24 = {}, _24[heroes.Helga.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _24)
        },
        noCustomizeExist: (_25 = {},
            _25[CUSTOMIZATION.WEAPON] = [30106],
            _25),
        customizeExist: (_26 = {},
            _26[CUSTOMIZATION.SKIN] = [603],
            _26),
        enablePopup: true,
        popupSettings: {
            popUpId: 95115,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Helga_E_White_Star.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_7_2: new PromoOffer({
        ID: 5116,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_27 = {}, _27[heroes.Marcus.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _27)
        },
        noCustomizeExist: (_28 = {},
            _28[CUSTOMIZATION.WEAPON] = [30214],
            _28),
        customizeExist: (_29 = {},
            _29[CUSTOMIZATION.SKIN] = [1303],
            _29),
        enablePopup: true,
        popupSettings: {
            popUpId: 95116,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Marcus_E_Knight.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_8_2: new PromoOffer({
        ID: 5117,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_30 = {}, _30[heroes.Bulwark.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _30)
        },
        noCustomizeExist: (_31 = {},
            _31[CUSTOMIZATION.WEAPON] = [30111],
            _31),
        customizeExist: (_32 = {},
            _32[CUSTOMIZATION.SKIN] = [1001],
            _32),
        enablePopup: true,
        popupSettings: {
            popUpId: 95117,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_E_Pike.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_9_2: new PromoOffer({
        ID: 5118,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_33 = {}, _33[heroes.Emperor.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _33)
        },
        noCustomizeExist: (_34 = {},
            _34[CUSTOMIZATION.WEAPON] = [30112],
            _34),
        customizeExist: (_35 = {},
            _35[CUSTOMIZATION.SKIN] = [1102],
            _35),
        enablePopup: true,
        popupSettings: {
            popUpId: 95118,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_10_2: new PromoOffer({
        ID: 5119,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_36 = {}, _36[heroes.Kibo.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _36)
        },
        noCustomizeExist: (_37 = {},
            _37[CUSTOMIZATION.WEAPON] = [30113],
            _37),
        customizeExist: (_38 = {},
            _38[CUSTOMIZATION.SKIN] = [1203],
            _38),
        enablePopup: true,
        popupSettings: {
            popUpId: 95119,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } } }],
                },
            ]
        },
    }),
    PROMO_HERO_SET_11_2: new PromoOffer({
        ID: 5131,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "wpn_Jet_E_Prism_Alias",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            heroes: (_39 = {}, _39[heroes.Jet.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _39)
        },
        noCustomizeExist: (_40 = {},
            _40[CUSTOMIZATION.WEAPON] = [30107],
            _40),
        customizeExist: (_41 = {},
            _41[CUSTOMIZATION.SKIN] = [703],
            _41),
        enablePopup: true,
        popupSettings: {
            popUpId: 95131,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Jet_E_Prism.ID] }) } } }],
                },
            ]
        },
    }),
}, true);
