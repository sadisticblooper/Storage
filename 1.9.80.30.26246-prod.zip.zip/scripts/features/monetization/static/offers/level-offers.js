var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7;
extend(offers, {
    PROGRESS_LYNX_SET_01: new PromoOffer({
        visualPresetId: "1348",
        ID: 5200,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5200,
        conditions: {
            accountLevel: { equal: 6 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Lynx.ID],
        noCustomizeExist: (_a = {},
            _a[CUSTOMIZATION.WEAPON] = [30118],
            _a[CUSTOMIZATION.SKIN] = [1701],
            _a),
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.3,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5200,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[heroes.Lynx.ID] = 10, _b) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_E_Legacy.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-60%",
    }),
    PROGRESS_LYNX_SET_01_1: new PromoOffer({
        visualPresetId: "1348",
        ID: 5201,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5200,
        conditions: {
            accountLevel: { equal: 6 },
            heroes: (_c = {}, _c[heroes.Lynx.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _c)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_d = {},
            _d[CUSTOMIZATION.WEAPON] = [30118],
            _d[CUSTOMIZATION.SKIN] = [1701],
            _d),
        profit: 1.8,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5201,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_E_Legacy.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-45%",
    }),
    PROGRESS_KIBO_SET_01: new PromoOffer({
        visualPresetId: "1349",
        ID: 5202,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5202,
        conditions: {
            accountLevel: { equal: 3 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Kibo.ID],
        noCustomizeExist: (_e = {},
            _e[CUSTOMIZATION.WEAPON] = [30113],
            _e[CUSTOMIZATION.SKIN] = [1203],
            _e),
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.3,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5202,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_f = {}, _f[heroes.Kibo.ID] = 10, _f) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Kibo_E_Oriental_skin.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.AD_TOKEN] = 100, _g) }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-60%",
    }),
    PROGRESS_KIBO_SET_01_1: new PromoOffer({
        visualPresetId: "1349",
        ID: 5203,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5202,
        conditions: {
            accountLevel: { equal: 3 },
            heroes: (_h = {}, _h[heroes.Kibo.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _h)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_j = {},
            _j[CUSTOMIZATION.WEAPON] = [30113],
            _j[CUSTOMIZATION.SKIN] = [1203],
            _j),
        profit: 1.8,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5203,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Kibo_E_Oriental_skin.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.AD_TOKEN] = 75, _k) }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-45%",
    }),
    PROGRESS_BUTCHER_SET_01: new PromoOffer({
        visualPresetId: "1354",
        ID: 5204,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5204,
        conditions: {
            accountLevel: { equal: 8 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Butcher.ID],
        noCustomizeExist: (_l = {},
            _l[CUSTOMIZATION.EMOJI] = [2200],
            _l[CUSTOMIZATION.SKIN] = [2202],
            _l),
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.3,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5204,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_m = {}, _m[heroes.Butcher.ID] = 10, _m) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Butcher_E_Mogwai.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Butcher_WatchingYou.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-55%",
    }),
    PROGRESS_BUTCHER_SET_01_1: new PromoOffer({
        visualPresetId: "1354",
        ID: 5205,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5204,
        conditions: {
            accountLevel: { equal: 8 },
            heroes: (_o = {}, _o[heroes.Butcher.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _o)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_p = {},
            _p[CUSTOMIZATION.EMOJI] = [2200],
            _p[CUSTOMIZATION.SKIN] = [2202],
            _p),
        profit: 1.7,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5205,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Butcher_E_Mogwai.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Butcher_WatchingYou.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_8.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-45%",
    }),
    PROGRESS_MIDNIGHT_SET_01: new PromoOffer({
        visualPresetId: "1351",
        ID: 5206,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5206,
        conditions: {
            accountLevel: { equal: 5 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Midnight.ID],
        noCustomizeExist: (_q = {},
            _q[CUSTOMIZATION.WEAPON] = [30108],
            _q[CUSTOMIZATION.SKIN] = [1601],
            _q),
        sellHeroSettings: {
            heroId: heroes.Midnight.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.3,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5206,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_r = {}, _r[heroes.Midnight.ID] = 10, _r) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Midnight_E_Ghost.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-60%",
    }),
    PROGRESS_MIDNIGHT_SET_01_1: new PromoOffer({
        visualPresetId: "1351",
        ID: 5207,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5206,
        conditions: {
            accountLevel: { equal: 5 },
            heroes: (_s = {}, _s[heroes.Midnight.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _s)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_t = {},
            _t[CUSTOMIZATION.WEAPON] = [30108],
            _t[CUSTOMIZATION.SKIN] = [1601],
            _t),
        profit: 1.8,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5207,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Midnight_E_Ghost.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Midnight_E_Trident.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-45%",
    }),
    PROGRESS_EMPEROR_SET_01: new PromoOffer({
        visualPresetId: "1352",
        ID: 5208,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5208,
        conditions: {
            accountLevel: { equal: 7 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Emperor.ID],
        noCustomizeExist: (_u = {},
            _u[CUSTOMIZATION.WEAPON] = [30112],
            _u[CUSTOMIZATION.SKIN] = [1102],
            _u),
        sellHeroSettings: {
            heroId: heroes.Emperor.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.3,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5208,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_v = {}, _v[heroes.Emperor.ID] = 10, _v) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Emperor_E_Doomed_skin.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-60%",
    }),
    PROGRESS_EMPEROR_SET_01_1: new PromoOffer({
        visualPresetId: "1352",
        ID: 5209,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5208,
        conditions: {
            accountLevel: { equal: 5 },
            heroes: (_w = {}, _w[heroes.Emperor.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _w)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_x = {},
            _x[CUSTOMIZATION.WEAPON] = [30112],
            _x[CUSTOMIZATION.SKIN] = [1102],
            _x),
        profit: 1.8,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5209,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Emperor_E_Doomed_skin.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Emperor_E_Stone_Gloves.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-45%",
    }),
    PROGRESS_ITU_SET_01: new PromoOffer({
        visualPresetId: "1389",
        ID: 5214,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5214,
        conditions: {
            accountLevel: { equal: 9 }
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noHeroExist: [heroes.Itu.ID],
        noCustomizeExist: (_y = {},
            _y[CUSTOMIZATION.SKIN] = [2301],
            _y[CUSTOMIZATION.EMOJI] = [2300],
            _y),
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.0,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5214,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_z = {}, _z[heroes.Itu.ID] = 10, _z) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_R_Red.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Itu_GlassBreaking.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-50%",
    }),
    PROGRESS_ITU_SET_01_1: new PromoOffer({
        visualPresetId: "1389",
        ID: 5215,
        offerNameAlias: "promo_offer_heroset",
        productGroup: 5214,
        conditions: {
            accountLevel: { equal: 9 },
            heroes: (_0 = {}, _0[heroes.Itu.ID] = { Level: { more_or_equal: 4 }, Exp: { more_or_equal: 0 } }, _0)
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        noCustomizeExist: (_1 = {},
            _1[CUSTOMIZATION.SKIN] = [2301],
            _1[CUSTOMIZATION.EMOJI] = [2300],
            _1),
        profit: 2.0,
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        popupSettings: {
            popUpId: 5215,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_R_Red.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Itu_GlassBreaking.ID] }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        discount: "-50%",
    }),
    PROGRESS_GOLD_01: new PromoOffer({
        ID: 5210,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { equal: 4 },
        },
        promoOfferGroup: 5210,
        enablePopup: true,
        popupSettings: {
            popUpId: 5210,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _2) } } }]
                },
            ]
        },
    }),
    PROGRESS_GOLD_01_1: new PromoOffer({
        ID: 5211,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.8,
        discount: "-45%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { equal: 4 },
        },
        promoOfferGroup: 5210,
        enablePopup: true,
        popupSettings: {
            popUpId: 5211,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_3 = {}, _3[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _3) } } }]
                },
            ]
        },
    }),
    PROGRESS_GOLD_02: new PromoOffer({
        ID: 5212,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.8,
        discount: "-45%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { equal: 7 },
        },
        promoOfferGroup: 5212,
        enablePopup: true,
        popupSettings: {
            popUpId: 5212,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_4 = {}, _4[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(20000) }], _4) } } }]
                },
            ]
        },
    }),
    PROGRESS_GOLD_02_1: new PromoOffer({
        ID: 5213,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_35.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { equal: 7 },
        },
        promoOfferGroup: 5212,
        enablePopup: true,
        popupSettings: {
            popUpId: 5213,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100000) }], _5) } } }]
                },
            ]
        },
    }),
    PROGRESS_FP_BOOST: new PromoOffer({
        visualPresetId: "1246",
        ID: 5279,
        offerNameAlias: "progress_fp_ruby",
        conditions: {},
        battlePass: {
            level: { more_or_equal: 50 },
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.CHANGE_BATTLE_PASS_LEVEL],
        popupSettings: {
            popUpId: 5279,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_6 = {}, _6[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _6) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_7 = {}, _7[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _7) } } }]
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        profit: 1.3,
        discount: "-25%",
    }),
}, true);
