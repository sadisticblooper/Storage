var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95;
extend(offers, {
    STARTER_KIBO_HERO_1_3: new PromoOffer({
        ID: 7000,
        disableGeneratingSince: 1,
        visualPresetId: "starter_pack_Kibo",
        offerNameAlias: "starter_pack",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 1 },
            createdPlayerTime: { more_or_equal: new Date("2022-11-29T16:35:00Z").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 1 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        noHeroExist: [heroes.Kibo.ID],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeWithKibo,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 5,
        discount: "-80%",
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[heroes.Kibo.ID] = 10, _a) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Kibo.ID] = 5, _b) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _c) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(350) }], _d) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_KIBO_HERO: new PromoOffer({
        ID: 7200,
        disableGeneratingSince: null,
        visualPresetId: "starter_pack_Kibo",
        offerNameAlias: "starter_pack",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 1 },
            createdPlayerTime: { more_or_equal: new Date("2022-11-29T16:35:00Z").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 1 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        noHeroExist: [heroes.Kibo.ID],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeWithKibo,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 5,
        discount: "-80%",
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Kibo.ID] = 10, _e) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[heroes.Kibo.ID] = 5, _f) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.AD_TOKEN] = 25, _g) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_h = {}, _h[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _h) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(350) }], _j) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_KIBO_CARDS: new PromoOffer({
        ID: 7201,
        disableGeneratingSince: null,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7200, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 2.5,
        discount: "-60%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_k = {}, _k[heroes.Kibo.ID] = 5, _k) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_l = {}, _l[heroes.Kibo.ID] = 30, _l) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.AD_TOKEN] = 50, _m) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_o = {}, _o[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(260) }], _o) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_p = {}, _p[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2600) }], _p) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_FIREGUARD_HERO: new PromoOffer({
        ID: 7202,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7200, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 7.2,
        discount: "-85%",
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_q = {}, _q[heroes.Fireguard.ID] = 10, _q) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_r = {}, _r[heroes.Fireguard.ID] = 40, _r) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.AD_TOKEN] = 5, _s) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _t) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_u = {}, _u[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(700) }], _u) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_KIBO_CUSTOMIZE: new PromoOffer({
        ID: 7203,
        disableGeneratingSince: null,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7201, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_20.ProductID,
        disableRegionalPrices: false,
        profit: 2.1,
        discount: "-50%",
        sellHeroSettings: null,
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                hero: HeroNames.Kibo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_v = {}, _v[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(950) }], _v) } } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_w = {}, _w[heroes.Kibo.ID] = 30, _w) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_x = {}, _x[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _x) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION,],
    }),
    STARTER_ITU_HERO: new PromoOffer({
        ID: 7204,
        disableGeneratingSince: null,
        visualPresetId: "5125",
        offerNameAlias: "shop_offers_sale",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7201, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 3.7,
        discount: "-70%",
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_y = {}, _y[heroes.Itu.ID] = 10, _y) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_z = {}, _z[heroes.Itu.ID] = 5, _z) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.AD_TOKEN] = 50, _0) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_1 = {}, _1[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _1) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _2) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_FIREGUARD_CARDS: new PromoOffer({
        ID: 7205,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7202, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 2,
        discount: "-50%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_3 = {}, _3[heroes.Fireguard.ID] = 150, _3) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.AD_TOKEN] = 15, _4) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(150) }], _5) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_6 = {}, _6[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2600) }], _6) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_1v5_1: new PromoOffer({
        ID: 7206,
        disableGeneratingSince: null,
        promoOfferGroup: 7206,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7202, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 2.5,
        discount: "-60%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_7 = {}, _7[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(250) }], _7) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_1v5_5: new PromoOffer({
        ID: 7207,
        disableGeneratingSince: null,
        promoOfferGroup: 7206,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7202, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 7.1,
        discount: "-85%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _8) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.AD_TOKEN] = 25, _9) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_10 = {}, _10[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _10) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_LK_HERO: new PromoOffer({
        ID: 7208,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7203, settings) || OffersUtils.wasOfferBought(7209, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_50.ProductID,
        disableRegionalPrices: false,
        profit: 1.7,
        discount: "-40%",
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_11 = {}, _11[heroes.Legion_King.ID] = 10, _11) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_12 = {}, _12[heroes.Legion_King.ID] = 35, _12) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_13 = {}, _13[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _13) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_14 = {}, _14[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7600) }], _14) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_ITU_CARDS: new PromoOffer({
        ID: 7209,
        disableGeneratingSince: null,
        visualPresetId: "5125",
        offerNameAlias: "shop_offers_sale",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7204, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_20.ProductID,
        disableRegionalPrices: false,
        profit: 2.9,
        discount: "-65%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_15 = {}, _15[heroes.Itu.ID] = 5, _15) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_16 = {}, _16[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7000) }], _16) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_17 = {}, _17[heroes.Itu.ID] = 30, _17) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_18 = {}, _18[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _18) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v15_5: new PromoOffer({
        ID: 7210,
        disableGeneratingSince: null,
        promoOfferGroup: 7210,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7203, settings) || OffersUtils.wasOfferIgnored(7204, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 1.6,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_19 = {}, _19[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _19) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v15_15: new PromoOffer({
        ID: 7211,
        disableGeneratingSince: null,
        promoOfferGroup: 7210,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7203, settings) || OffersUtils.wasOfferIgnored(7204, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_15.ProductID,
        disableRegionalPrices: false,
        profit: 3.1,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_20 = {}, _20[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _20) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Mythic_chest_shop.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_21 = {}, _21[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7500) }], _21) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v10_5: new PromoOffer({
        ID: 7212,
        disableGeneratingSince: null,
        promoOfferGroup: 7212,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7205, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 1.6,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_22 = {}, _22[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _22) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v10_10: new PromoOffer({
        ID: 7213,
        disableGeneratingSince: null,
        promoOfferGroup: 7212,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7205, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 3.1,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_23 = {}, _23[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _23) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_24 = {}, _24[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _24) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_3v5_3: new PromoOffer({
        ID: 7214,
        disableGeneratingSince: null,
        promoOfferGroup: 7214,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7205, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.7,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_25 = {}, _25[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _25) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_3v5_5: new PromoOffer({
        ID: 7215,
        disableGeneratingSince: null,
        promoOfferGroup: 7214,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7205, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 4.6,
        discount: "-80%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_26 = {}, _26[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _26) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_27 = {}, _27[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2500) }], _27) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_LK_CARDS: new PromoOffer({
        ID: 7216,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7208, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_100.ProductID,
        disableRegionalPrices: false,
        profit: 2.8,
        discount: "-65%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_28 = {}, _28[heroes.Legion_King.ID] = 15, _28) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_29 = {}, _29[heroes.Legion_King.ID] = 160, _29) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_30 = {}, _30[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _30) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_31 = {}, _31[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(60000) }], _31) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_10v25_10: new PromoOffer({
        ID: 7217,
        disableGeneratingSince: null,
        promoOfferGroup: 7217,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7208, settings) || OffersUtils.wasOfferIgnored(7209, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 2,
        discount: "-50%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_32 = {}, _32[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _32) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_10v25_25: new PromoOffer({
        ID: 7218,
        disableGeneratingSince: null,
        promoOfferGroup: 7217,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7208, settings) || OffersUtils.wasOfferIgnored(7209, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_25.ProductID,
        disableRegionalPrices: false,
        profit: 3.1,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_33 = {}, _33[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _33) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_34 = {}, _34[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _34) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_KIBO_HERO_T20: new PromoOffer({
        ID: 7219,
        disableGeneratingSince: null,
        visualPresetId: "starter_pack_Kibo",
        offerNameAlias: "starter_pack",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 1 },
            createdPlayerTime: { more_or_equal: new Date("2022-11-29T16:35:00Z").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 1 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        noHeroExist: [heroes.Kibo.ID],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeWithKibo,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 4,
        discount: "-80%",
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_35 = {}, _35[heroes.Kibo.ID] = 10, _35) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_36 = {}, _36[heroes.Kibo.ID] = 35, _36) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.AD_TOKEN] = 10, _37) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_38 = {}, _38[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _38) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_39 = {}, _39[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _39) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_KIBO_CARDS_T20: new PromoOffer({
        ID: 7220,
        disableGeneratingSince: null,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7219, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 2.5,
        discount: "-60%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_40 = {}, _40[heroes.Kibo.ID] = 5, _40) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_41 = {}, _41[heroes.Kibo.ID] = 80, _41) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_42 = {}, _42[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(250) }], _42) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_43 = {}, _43[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _43) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_FIREGUARD_HERO_T20: new PromoOffer({
        ID: 7221,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7219, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 3.2,
        discount: "-70%",
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_44 = {}, _44[heroes.Fireguard.ID] = 10, _44) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_45 = {}, _45[heroes.Fireguard.ID] = 190, _45) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.AD_TOKEN] = 5, _46) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_47 = {}, _47[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _47) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_48 = {}, _48[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3500) }], _48) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_KIBO_CUSTOMIZE_T20: new PromoOffer({
        ID: 7222,
        disableGeneratingSince: null,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7220, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: true,
        profit: 2.7,
        discount: "-65%",
        sellHeroSettings: null,
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                hero: HeroNames.Kibo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_49 = {}, _49[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(950) }], _49) } } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_50 = {}, _50[heroes.Kibo.ID] = 175, _50) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Kibo_E_RedVampire.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_51 = {}, _51[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(50000) }], _51) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION,],
    }),
    STARTER_ITU_HERO_T20: new PromoOffer({
        ID: 7223,
        disableGeneratingSince: null,
        visualPresetId: "5125",
        offerNameAlias: "shop_offers_sale",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7220, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 2.5,
        discount: "-60%",
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_52 = {}, _52[heroes.Itu.ID] = 10, _52) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_53 = {}, _53[heroes.Itu.ID] = 15, _53) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_54 = {}, _54[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _54) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_55 = {}, _55[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2600) }], _55) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_FIREGUARD_CARDS_T20: new PromoOffer({
        ID: 7224,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7221, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 2.4,
        discount: "-60%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_56 = {}, _56[heroes.Fireguard.ID] = 600, _56) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_57 = {}, _57[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _57) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_58 = {}, _58[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _58) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_1v5_1_T20: new PromoOffer({
        ID: 7225,
        disableGeneratingSince: null,
        promoOfferGroup: 7225,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7221, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.6,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_59 = {}, _59[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _59) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_1v5_5_T20: new PromoOffer({
        ID: 7226,
        disableGeneratingSince: null,
        promoOfferGroup: 7225,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7221, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 3.4,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_60 = {}, _60[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2500) }], _60) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_61 = {}, _61[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _61) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_LK_HERO_T20: new PromoOffer({
        ID: 7227,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7222, settings) || OffersUtils.wasOfferBought(7228, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_20.ProductID,
        disableRegionalPrices: true,
        profit: 2.3,
        discount: "-55%",
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_62 = {}, _62[heroes.Legion_King.ID] = 15, _62) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_63 = {}, _63[heroes.Legion_King.ID] = 115, _63) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_64 = {}, _64[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2500) }], _64) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_65 = {}, _65[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(40000) }], _65) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_ITU_CARDS_T20: new PromoOffer({
        ID: 7228,
        disableGeneratingSince: null,
        visualPresetId: "5125",
        offerNameAlias: "shop_offers_sale",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7223, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: true,
        profit: 2.9,
        discount: "-65%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_66 = {}, _66[heroes.Itu.ID] = 15, _66) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_67 = {}, _67[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _67) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_68 = {}, _68[heroes.Itu.ID] = 50, _68) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_69 = {}, _69[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _69) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v15_5_T20: new PromoOffer({
        ID: 7229,
        disableGeneratingSince: null,
        promoOfferGroup: 7229,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7222, settings) || OffersUtils.wasOfferIgnored(7223, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.7,
        discount: "-45%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_70 = {}, _70[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1750) }], _70) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v15_15_T20: new PromoOffer({
        ID: 7230,
        disableGeneratingSince: null,
        promoOfferGroup: 7229,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7222, settings) || OffersUtils.wasOfferIgnored(7223, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 3.3,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_71 = {}, _71[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _71) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Mythic_chest_shop.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_72 = {}, _72[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7500) }], _72) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v10_5_T20: new PromoOffer({
        ID: 7231,
        disableGeneratingSince: null,
        promoOfferGroup: 7231,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7224, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.7,
        discount: "-45%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_73 = {}, _73[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1750) }], _73) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_5v10_10_T20: new PromoOffer({
        ID: 7232,
        disableGeneratingSince: null,
        promoOfferGroup: 7231,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7224, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 3.3,
        discount: "-70%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_74 = {}, _74[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _74) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_75 = {}, _75[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _75) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_3v5_3_T20: new PromoOffer({
        ID: 7233,
        disableGeneratingSince: null,
        promoOfferGroup: 7233,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7224, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.6,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_76 = {}, _76[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _76) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_3v5_5_T20: new PromoOffer({
        ID: 7234,
        disableGeneratingSince: null,
        promoOfferGroup: 7233,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7224, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalYellow,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 2.5,
        discount: "-60%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_77 = {}, _77[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _77) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_78 = {}, _78[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7500) }], _78) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_LK_CARDS_T20: new PromoOffer({
        ID: 7235,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7227, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_50.ProductID,
        disableRegionalPrices: true,
        profit: 2.1,
        discount: "-55%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_79 = {}, _79[heroes.Legion_King.ID] = 20, _79) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_80 = {}, _80[heroes.Legion_King.ID] = 325, _80) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_81 = {}, _81[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _81) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_82 = {}, _82[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(120000) }], _82) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_10v25_10_T20: new PromoOffer({
        ID: 7236,
        disableGeneratingSince: null,
        promoOfferGroup: 7236,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7227, settings) || OffersUtils.wasOfferIgnored(7228, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 1.8,
        discount: "-40%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_83 = {}, _83[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(3500) }], _83) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_RUBY_10v25_25_T20: new PromoOffer({
        ID: 7237,
        disableGeneratingSince: null,
        promoOfferGroup: 7236,
        visualPresetId: "cycle_weekly_epic_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7227, settings) || OffersUtils.wasOfferIgnored(7228, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalBlue,
        activeTime: {
            duration: new Time({ Hours: 8 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: true,
        profit: 4,
        discount: "-75%",
        sellHeroSettings: null,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_84 = {}, _84[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(7000) }], _84) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID,
                                    chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID,
                                    chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID,] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_85 = {}, _85[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _85) } } }],
                }
            ]
        },
        rules: [],
    }),
    STARTER_MK_HERO_T20: new PromoOffer({
        ID: 7238,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_Monkey_King",
        offerNameAlias: "Monkey_King",
        triggers: [],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {},
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        customCondition: function (settings) {
            return OffersUtils.wasOfferBought(7235, settings);
        },
        previousOffers: [],
        ignoredOffers: [],
        isStarterPack: true,
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeUniversalPurple,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 100,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_100.ProductID,
        disableRegionalPrices: true,
        profit: 1.7,
        discount: "-40%",
        sellHeroSettings: {
            heroId: heroes.Monkey_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_86 = {}, _86[heroes.Monkey_King.ID] = 65, _86) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_87 = {}, _87[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(165000) }], _87) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_88 = {}, _88[heroes.Monkey_King.ID] = 450, _88) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_89 = {}, _89[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _89) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES,],
    }),
    STARTER_RU0_IRONCLAD_Pack: new PromoOffer({
        ID: 7400,
        disableGeneratingSince: null,
        visualPresetId: "Ironclad_E_Rust_com_hero",
        offerNameAlias: "Ironclad",
        inApp: inAppSettings.PRICE_1_49.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 14.6,
        discount: "-90%",
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 2 },
            createdPlayerTime: { more_or_equal: new Date("2025-10-23").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 2 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7400,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 60,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Ironclad.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_90 = {}, _90[heroes.Ironclad.ID] = 10, _90) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ironclad_E_Rust.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Ironclad_R_Pattern.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_RU0_BULWARK_Pack: new PromoOffer({
        ID: 7401,
        disableGeneratingSince: null,
        visualPresetId: "Bulwark_E_Snow_skin_com_hero",
        offerNameAlias: "Bulwark",
        inApp: inAppSettings.PRICE_1_49.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 14.6,
        discount: "-90%",
        conditions: {},
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7400, settings);
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7401,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 61,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Bulwark.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_91 = {}, _91[heroes.Bulwark.ID] = 10, _91) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_E_Snow_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_base_Rec_Black.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_RU0_FELDSHER_Pack: new PromoOffer({
        ID: 7402,
        disableGeneratingSince: null,
        visualPresetId: "Feldsher_E_Suit_skin_com_hero",
        offerNameAlias: "Feldsher",
        inApp: inAppSettings.PRICE_1_49.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 14.6,
        discount: "-90%",
        conditions: {},
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7401, settings);
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7402,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 62,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Feldsher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_92 = {}, _92[heroes.Feldsher.ID] = 10, _92) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Feldsher_E_Suit_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Feldsher_R_SpicyBlade.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_RU0_FIREGUARD_Pack: new PromoOffer({
        ID: 7403,
        disableGeneratingSince: null,
        visualPresetId: "Fireguard_E_Cyber_com_hero",
        offerNameAlias: "Fireguard",
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 22.0,
        discount: "-95%",
        conditions: {},
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7402, settings);
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7403,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 63,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_93 = {}, _93[heroes.Fireguard.ID] = 10, _93) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Fireguard_E_Cyber.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Fireguard_R_Simplified.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_RU0_MONK_Pack: new PromoOffer({
        ID: 7404,
        disableGeneratingSince: null,
        visualPresetId: "Monk_E_Royal_com_hero",
        offerNameAlias: "Monk",
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 22.0,
        discount: "-95%",
        conditions: {},
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7403, settings);
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7404,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 64,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Monk.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_94 = {}, _94[heroes.Monk.ID] = 10, _94) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monk_E_Royal.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Monk_R_NeatBlade_Rec_Red.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
    STARTER_RU0_LIQUIDATOR_Pack: new PromoOffer({
        ID: 7405,
        disableGeneratingSince: null,
        visualPresetId: "Liquidator_E_Forged_com_hero",
        offerNameAlias: "Liquidator",
        inApp: inAppSettings.PRICE_0_49.ProductID,
        disableRegionalPrices: true,
        activeTime: { duration: new Time({ Minutes: 15 }).value },
        profit: 44.0,
        discount: "-95%",
        conditions: {},
        customCondition: function (settings) {
            return OffersUtils.wasOfferIgnored(7404, settings);
        },
        isStarterPack: true,
        companies: ["AL_SFA_AP_iOS_WW_BLND_D7_AllLang_150725",
            "AL_SFA_AP_iOS_WW_ROAS_D28_AllLang_071025",
            "UN_SFA_AP_Andr_RU_tROAS_AllLang_071025",
            "AL_SFA_AP_Andr_CIS_ROAS_AllLang_190825",
            "MTG_asfa_BAA_Cpe_RU_200825",
            "MTG_asfa_BAA_tRoas_d7_RU_230925",
            "Avow_asfa_BAA_RU_Val_tRoas_150725"],
        country: ["RU"],
        productGroup: 7405,
        enablePopup: true,
        triggers: [],
        popupSettings: {
            popUpId: 65,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Liquidator.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_95 = {}, _95[heroes.Liquidator.ID] = 10, _95) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Liquidator_E_Forged.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Liquidator_R_Gold_Rec_Bronze.ID] }) } } }],
                }
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
    }),
}, true);
