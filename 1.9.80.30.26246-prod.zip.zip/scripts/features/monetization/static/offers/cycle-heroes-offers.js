var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155, _156, _157, _158, _159, _160, _161, _162, _163, _164, _165, _166, _167, _168, _169, _170, _171, _172, _173, _174, _175, _176, _177, _178, _179, _180, _181, _182, _183, _184, _185, _186, _187, _188, _189, _190, _191, _192, _193, _194, _195, _196, _197, _198, _199, _200, _201, _202, _203, _204, _205, _206, _207, _208, _209, _210, _211, _212, _213, _214, _215, _216, _217, _218, _219, _220, _221, _222, _223, _224, _225, _226, _227, _228, _229, _230, _231, _232, _233, _234, _235, _236, _237, _238, _239, _240, _241, _242, _243, _244, _245, _246, _247, _248, _249, _250, _251, _252, _253, _254, _255, _256, _257, _258, _259, _260, _261, _262, _263, _264, _265, _266, _267;
extend(offers, {
    CYCLE_HERO_BULWARK_2: new PromoOffer({
        ID: 5138,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Bulwark",
        offerNameAlias: "Bulwark",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5164, 5165, 5176, 5177]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 15,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Bulwark.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5138,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[heroes.Bulwark.ID] = 10, _a) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Bulwark.ID] = 40, _b) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _c) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_LYNX_2: new PromoOffer({
        ID: 5139,
        disableGeneratingSince: null,
        visualPresetId: "105",
        offerNameAlias: "Lynx",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5234, 5241, 5248, 5255]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 9,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5139,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Lynx.ID] = 10, _d) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[heroes.Lynx.ID] = 5, _e) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _f) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_HELGA_2: new PromoOffer({
        ID: 5140,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_rare_Helga",
        offerNameAlias: "Helga",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5192, 5216, 5224, 5232]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 12,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Helga.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5140,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Helga.ID] = 10, _g) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_h = {}, _h[heroes.Helga.ID] = 15, _h) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _j) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_MIDNIGHT_2: new PromoOffer({
        ID: 5141,
        disableGeneratingSince: null,
        visualPresetId: "5003",
        offerNameAlias: "Midnight",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5235, 5242, 5249, 5256]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 16,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Midnight.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5141,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_k = {}, _k[heroes.Midnight.ID] = 10, _k) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_l = {}, _l[heroes.Midnight.ID] = 5, _l) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _m) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_LIQUIDATOR_2: new PromoOffer({
        ID: 5142,
        disableGeneratingSince: null,
        visualPresetId: "5004",
        offerNameAlias: "Liquidator",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5168, 5169, 5180, 5181]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 24,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Liquidator.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5142,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_o = {}, _o[heroes.Liquidator.ID] = 10, _o) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_p = {}, _p[heroes.Liquidator.ID] = 40, _p) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_q = {}, _q[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _q) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_MARCUS_2: new PromoOffer({
        ID: 5143,
        disableGeneratingSince: null,
        visualPresetId: "5005",
        offerNameAlias: "Marcus",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5237, 5244, 5251, 5258]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 3,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Marcus.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5143,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_r = {}, _r[heroes.Marcus.ID] = 10, _r) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_s = {}, _s[heroes.Marcus.ID] = 5, _s) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _t) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_VIPER_2: new PromoOffer({
        ID: 5144,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_rare_Viper",
        offerNameAlias: "Viper",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5189, 5197, 5221, 5229]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 14,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Viper.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5144,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_u = {}, _u[heroes.Viper.ID] = 10, _u) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_v = {}, _v[heroes.Viper.ID] = 15, _v) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_w = {}, _w[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _w) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_IRONCLAD_2: new PromoOffer({
        ID: 5145,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Ironclad",
        offerNameAlias: "Ironclad",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5162, 5163, 5174, 5175]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 17,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Ironclad.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5145,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_x = {}, _x[heroes.Ironclad.ID] = 10, _x) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_y = {}, _y[heroes.Ironclad.ID] = 40, _y) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_z = {}, _z[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _z) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_LEGIONKING_2: new PromoOffer({
        ID: 5146,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        noActiveOffers: [3933, 3934, 3935, 3936, 3937, 3938],
        forgetOffers: {
            offers: [5263, 5266, 5269, 5272]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 6,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5146,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_0 = {}, _0[heroes.Legion_King.ID] = 10, _0) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_1 = {}, _1[heroes.Legion_King.ID] = 4, _1) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _2) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_JET_2: new PromoOffer({
        ID: 5147,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_rare_Jet",
        offerNameAlias: "Jet",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5191, 5199, 5223, 5231]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 7,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Jet.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5147,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_3 = {}, _3[heroes.Jet.ID] = 10, _3) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_4 = {}, _4[heroes.Jet.ID] = 15, _4) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _5) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_FELDSHER_2: new PromoOffer({
        ID: 5148,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Feldsher",
        offerNameAlias: "Feldsher",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5172, 5173, 5184, 5185]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 25,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Feldsher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5148,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_6 = {}, _6[heroes.Feldsher.ID] = 10, _6) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_7 = {}, _7[heroes.Feldsher.ID] = 40, _7) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _8) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_SARGE_2: new PromoOffer({
        ID: 5149,
        disableGeneratingSince: null,
        visualPresetId: "5011",
        offerNameAlias: "Sarge",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5186, 5194, 5218, 5226]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 19,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Sarge.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5149,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_9 = {}, _9[heroes.Sarge.ID] = 10, _9) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_10 = {}, _10[heroes.Sarge.ID] = 15, _10) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_11 = {}, _11[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _11) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_KIBO_2: new PromoOffer({
        ID: 5150,
        disableGeneratingSince: null,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5238, 5245, 5252, 5259]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 10,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5150,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_12 = {}, _12[heroes.Kibo.ID] = 10, _12) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_13 = {}, _13[heroes.Kibo.ID] = 5, _13) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_14 = {}, _14[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _14) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_YUKKA_2: new PromoOffer({
        ID: 5151,
        disableGeneratingSince: null,
        visualPresetId: "5013",
        offerNameAlias: "Yukka",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5188, 5196, 5220, 5228]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 22,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Yukka.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5151,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_15 = {}, _15[heroes.Yukka.ID] = 10, _15) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_16 = {}, _16[heroes.Yukka.ID] = 15, _16) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_17 = {}, _17[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _17) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_MONK_2: new PromoOffer({
        ID: 5152,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Monk",
        offerNameAlias: "Monk",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5166, 5167, 5178, 5179]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 21,
        },
        sellHeroSettings: {
            heroId: heroes.Monk.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5152,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_18 = {}, _18[heroes.Monk.ID] = 10, _18) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_19 = {}, _19[heroes.Monk.ID] = 40, _19) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_20 = {}, _20[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _20) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_MONKEYKING_2: new PromoOffer({
        ID: 5153,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_Monkey_King",
        offerNameAlias: "Monkey_King",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5262, 5265, 5268, 5271]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Monkey_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5153,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_21 = {}, _21[heroes.Monkey_King.ID] = 10, _21) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_22 = {}, _22[heroes.Monkey_King.ID] = 4, _22) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_23 = {}, _23[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _23) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_LING_2: new PromoOffer({
        ID: 5154,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_rare_Ling",
        offerNameAlias: "Ling",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5187, 5195, 5219, 5227]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 23,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Ling.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5154,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_24 = {}, _24[heroes.Ling.ID] = 10, _24) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_25 = {}, _25[heroes.Ling.ID] = 15, _25) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_26 = {}, _26[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _26) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_EMPEROR_2: new PromoOffer({
        ID: 5155,
        disableGeneratingSince: null,
        visualPresetId: "5017",
        offerNameAlias: "Emperor",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5236, 5243, 5250, 5257]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 13,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Emperor.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5155,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_27 = {}, _27[heroes.Emperor.ID] = 10, _27) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_28 = {}, _28[heroes.Emperor.ID] = 5, _28) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_29 = {}, _29[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _29) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_FIREGUARD_2: new PromoOffer({
        ID: 5156,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: {},
        forgetOffers: {
            offers: [5170, 5171, 5182, 5183]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 20,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5156,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_30 = {}, _30[heroes.Fireguard.ID] = 10, _30) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_31 = {}, _31[heroes.Fireguard.ID] = 40, _31) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_32 = {}, _32[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _32) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_HONGJOO_2: new PromoOffer({
        ID: 5157,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_rare_HongJoo",
        offerNameAlias: "HongJoo",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5190, 5198, 5222, 5230]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 18,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.HongJoo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5157,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_33 = {}, _33[heroes.HongJoo.ID] = 10, _33) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_34 = {}, _34[heroes.HongJoo.ID] = 15, _34) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_35 = {}, _35[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _35) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_BUTCHER_2: new PromoOffer({
        ID: 5158,
        disableGeneratingSince: null,
        visualPresetId: "5120",
        offerNameAlias: "Butcher",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5239, 5246, 5253, 5260]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 11,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5158,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_36 = {}, _36[heroes.Butcher.ID] = 10, _36) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_37 = {}, _37[heroes.Butcher.ID] = 5, _37) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_38 = {}, _38[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _38) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_ITU_2: new PromoOffer({
        ID: 5159,
        disableGeneratingSince: null,
        visualPresetId: "5125",
        offerNameAlias: "Itu",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5264, 5267, 5270, 5273]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 4,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5159,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_39 = {}, _39[heroes.Itu.ID] = 10, _39) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_40 = {}, _40[heroes.Itu.ID] = 4, _40) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_41 = {}, _41[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _41) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_YUNLIN_2: new PromoOffer({
        ID: 5160,
        disableGeneratingSince: null,
        visualPresetId: "5132",
        offerNameAlias: "Yunlin",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5193, 5217, 5225, 5233]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 8,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Yunlin.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5160,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_42 = {}, _42[heroes.Yunlin.ID] = 10, _42) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_43 = {}, _43[heroes.Yunlin.ID] = 15, _43) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_44 = {}, _44[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _44) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_XIANGTZU_2: new PromoOffer({
        ID: 5161,
        disableGeneratingSince: null,
        visualPresetId: "5135",
        offerNameAlias: "Xiang_Tzu",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5240, 5247, 5254, 5261]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Xiang_Tzu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5161,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_45 = {}, _45[heroes.Xiang_Tzu.ID] = 10, _45) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_46 = {}, _46[heroes.Xiang_Tzu.ID] = 5, _46) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_47 = {}, _47[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(400) }], _47) } } }]
                },
            ]
        },
    }),
    CYCLE_HERO_JUNE_2: new PromoOffer({
        ID: 5274,
        disableGeneratingSince: null,
        visualPresetId: "offer_with_image_leg_June",
        offerNameAlias: "June",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {},
        forgetOffers: {
            offers: [5275, 5276]
        },
        weeklySettings: {
            startDateFunction: PromoOfferConstants.cycleOffersStartDateFunction,
            period: new Time({ Days: 25 }).value,
            activeDay: 5,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5274,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_48 = {}, _48[heroes.June.ID] = 10, _48) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_49 = {}, _49[heroes.June.ID] = 4, _49) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_50 = {}, _50[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _50) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_IRONCLAD_3: new PromoOffer({
        ID: 5162,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5145],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5162,
        enablePopup: true,
        popupSettings: {
            popUpId: 5162,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_51 = {}, _51[heroes.Ironclad.ID] = 10, _51) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_52 = {}, _52[heroes.Ironclad.ID] = 50, _52) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_53 = {}, _53[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _53) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_IRONCLAD_4: new PromoOffer({
        ID: 5163,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5145],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5162,
        enablePopup: true,
        popupSettings: {
            popUpId: 5163,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_54 = {}, _54[heroes.Ironclad.ID] = 30, _54) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_55 = {}, _55[heroes.Ironclad.ID] = 400, _55) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_56 = {}, _56[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _56) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_BULWARK_3: new PromoOffer({
        ID: 5164,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5138],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5164,
        enablePopup: true,
        popupSettings: {
            popUpId: 5164,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_57 = {}, _57[heroes.Bulwark.ID] = 10, _57) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_58 = {}, _58[heroes.Bulwark.ID] = 50, _58) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_59 = {}, _59[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _59) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_BULWARK_4: new PromoOffer({
        ID: 5165,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5138],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5164,
        enablePopup: true,
        popupSettings: {
            popUpId: 5165,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_60 = {}, _60[heroes.Bulwark.ID] = 30, _60) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_61 = {}, _61[heroes.Bulwark.ID] = 400, _61) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_62 = {}, _62[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _62) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MONK_3: new PromoOffer({
        ID: 5166,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5152],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5166,
        enablePopup: true,
        popupSettings: {
            popUpId: 5166,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_63 = {}, _63[heroes.Monk.ID] = 10, _63) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_64 = {}, _64[heroes.Monk.ID] = 50, _64) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_65 = {}, _65[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _65) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MONK_4: new PromoOffer({
        ID: 5167,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5152],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5166,
        enablePopup: true,
        popupSettings: {
            popUpId: 5167,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_66 = {}, _66[heroes.Monk.ID] = 30, _66) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_67 = {}, _67[heroes.Monk.ID] = 400, _67) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_68 = {}, _68[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _68) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LIQUIDATOR_3: new PromoOffer({
        ID: 5168,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5142],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5168,
        enablePopup: true,
        popupSettings: {
            popUpId: 5168,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_69 = {}, _69[heroes.Liquidator.ID] = 10, _69) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_70 = {}, _70[heroes.Liquidator.ID] = 50, _70) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_71 = {}, _71[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _71) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LIQUIDATOR_4: new PromoOffer({
        ID: 5169,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5142],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5168,
        enablePopup: true,
        popupSettings: {
            popUpId: 5169,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_72 = {}, _72[heroes.Liquidator.ID] = 30, _72) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_73 = {}, _73[heroes.Liquidator.ID] = 400, _73) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_74 = {}, _74[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _74) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_FIREGUARD_3: new PromoOffer({
        ID: 5170,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5156],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5170,
        enablePopup: true,
        popupSettings: {
            popUpId: 5170,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_75 = {}, _75[heroes.Fireguard.ID] = 10, _75) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_76 = {}, _76[heroes.Fireguard.ID] = 50, _76) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_77 = {}, _77[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _77) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_FIREGUARD_4: new PromoOffer({
        ID: 5171,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5156],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5170,
        enablePopup: true,
        popupSettings: {
            popUpId: 5171,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_78 = {}, _78[heroes.Fireguard.ID] = 30, _78) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_79 = {}, _79[heroes.Fireguard.ID] = 400, _79) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_80 = {}, _80[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _80) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_FELDSHER_3: new PromoOffer({
        ID: 5172,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.2,
        discount: "-20%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5148],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5172,
        enablePopup: true,
        popupSettings: {
            popUpId: 5172,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_81 = {}, _81[heroes.Feldsher.ID] = 10, _81) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_82 = {}, _82[heroes.Feldsher.ID] = 50, _82) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_83 = {}, _83[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _83) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_FELDSHER_4: new PromoOffer({
        ID: 5173,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5148],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5172,
        enablePopup: true,
        popupSettings: {
            popUpId: 5173,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_84 = {}, _84[heroes.Feldsher.ID] = 30, _84) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_85 = {}, _85[heroes.Feldsher.ID] = 400, _85) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_86 = {}, _86[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4500) }], _86) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_SARGE_3: new PromoOffer({
        ID: 5186,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5149],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5186,
        enablePopup: true,
        popupSettings: {
            popUpId: 5186,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_87 = {}, _87[heroes.Sarge.ID] = 10, _87) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_88 = {}, _88[heroes.Sarge.ID] = 25, _88) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_89 = {}, _89[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _89) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_SARGE_4: new PromoOffer({
        ID: 5194,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5149],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5186,
        enablePopup: true,
        popupSettings: {
            popUpId: 5194,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_90 = {}, _90[heroes.Sarge.ID] = 30, _90) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_91 = {}, _91[heroes.Sarge.ID] = 75, _91) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_92 = {}, _92[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _92) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LING_3: new PromoOffer({
        ID: 5187,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5154],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5187,
        enablePopup: true,
        popupSettings: {
            popUpId: 5187,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_93 = {}, _93[heroes.Ling.ID] = 10, _93) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_94 = {}, _94[heroes.Ling.ID] = 25, _94) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_95 = {}, _95[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _95) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LING_4: new PromoOffer({
        ID: 5195,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5154],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5187,
        enablePopup: true,
        popupSettings: {
            popUpId: 5195,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_96 = {}, _96[heroes.Ling.ID] = 30, _96) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_97 = {}, _97[heroes.Ling.ID] = 75, _97) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_98 = {}, _98[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _98) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_YUKKA_3: new PromoOffer({
        ID: 5188,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5151],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5188,
        enablePopup: true,
        popupSettings: {
            popUpId: 5188,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_99 = {}, _99[heroes.Yukka.ID] = 10, _99) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_100 = {}, _100[heroes.Yukka.ID] = 25, _100) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_101 = {}, _101[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _101) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_YUKKA_4: new PromoOffer({
        ID: 5196,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5151],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5188,
        enablePopup: true,
        popupSettings: {
            popUpId: 5196,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_102 = {}, _102[heroes.Yukka.ID] = 30, _102) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_103 = {}, _103[heroes.Yukka.ID] = 75, _103) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_104 = {}, _104[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _104) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_VIPER_3: new PromoOffer({
        ID: 5189,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5144],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5189,
        enablePopup: true,
        popupSettings: {
            popUpId: 5189,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_105 = {}, _105[heroes.Viper.ID] = 10, _105) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_106 = {}, _106[heroes.Viper.ID] = 25, _106) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_107 = {}, _107[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _107) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_VIPER_4: new PromoOffer({
        ID: 5197,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5144],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5189,
        enablePopup: true,
        popupSettings: {
            popUpId: 5197,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_108 = {}, _108[heroes.Viper.ID] = 30, _108) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_109 = {}, _109[heroes.Viper.ID] = 75, _109) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_110 = {}, _110[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _110) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_HONGJOO_3: new PromoOffer({
        ID: 5190,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5157],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5190,
        enablePopup: true,
        popupSettings: {
            popUpId: 5190,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_111 = {}, _111[heroes.HongJoo.ID] = 10, _111) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_112 = {}, _112[heroes.HongJoo.ID] = 25, _112) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_113 = {}, _113[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _113) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_HONGJOO_4: new PromoOffer({
        ID: 5198,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5157],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5190,
        enablePopup: true,
        popupSettings: {
            popUpId: 5198,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_114 = {}, _114[heroes.HongJoo.ID] = 30, _114) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_115 = {}, _115[heroes.HongJoo.ID] = 75, _115) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_116 = {}, _116[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _116) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_JET_3: new PromoOffer({
        ID: 5191,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5147],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5191,
        enablePopup: true,
        popupSettings: {
            popUpId: 5191,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_117 = {}, _117[heroes.Jet.ID] = 10, _117) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_118 = {}, _118[heroes.Jet.ID] = 25, _118) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_119 = {}, _119[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _119) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_JET_4: new PromoOffer({
        ID: 5199,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5147],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5191,
        enablePopup: true,
        popupSettings: {
            popUpId: 5199,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_120 = {}, _120[heroes.Jet.ID] = 30, _120) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_121 = {}, _121[heroes.Jet.ID] = 75, _121) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_122 = {}, _122[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _122) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_HELGA_3: new PromoOffer({
        ID: 5192,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5140],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5192,
        enablePopup: true,
        popupSettings: {
            popUpId: 5192,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_123 = {}, _123[heroes.Helga.ID] = 10, _123) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_124 = {}, _124[heroes.Helga.ID] = 25, _124) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_125 = {}, _125[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _125) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_HELGA_4: new PromoOffer({
        ID: 5216,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5140],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5192,
        enablePopup: true,
        popupSettings: {
            popUpId: 5216,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_126 = {}, _126[heroes.Helga.ID] = 30, _126) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_127 = {}, _127[heroes.Helga.ID] = 75, _127) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_128 = {}, _128[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _128) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_YUNLIN_3: new PromoOffer({
        ID: 5193,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.6,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5160],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5193,
        enablePopup: true,
        popupSettings: {
            popUpId: 5193,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_129 = {}, _129[heroes.Yunlin.ID] = 10, _129) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_130 = {}, _130[heroes.Yunlin.ID] = 25, _130) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_131 = {}, _131[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _131) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_YUNLIN_4: new PromoOffer({
        ID: 5217,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5160],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5193,
        enablePopup: true,
        popupSettings: {
            popUpId: 5217,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_132 = {}, _132[heroes.Yunlin.ID] = 30, _132) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_133 = {}, _133[heroes.Yunlin.ID] = 75, _133) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_134 = {}, _134[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _134) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LYNX_3: new PromoOffer({
        ID: 5234,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5139],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5234,
        enablePopup: true,
        popupSettings: {
            popUpId: 5234,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_135 = {}, _135[heroes.Lynx.ID] = 10, _135) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_136 = {}, _136[heroes.Lynx.ID] = 10, _136) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_137 = {}, _137[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _137) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LYNX_4: new PromoOffer({
        ID: 5241,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5139],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5234,
        enablePopup: true,
        popupSettings: {
            popUpId: 5241,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_138 = {}, _138[heroes.Lynx.ID] = 30, _138) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_139 = {}, _139[heroes.Lynx.ID] = 30, _139) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_140 = {}, _140[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _140) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MIDNIGHT_3: new PromoOffer({
        ID: 5235,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5141],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5235,
        enablePopup: true,
        popupSettings: {
            popUpId: 5235,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_141 = {}, _141[heroes.Midnight.ID] = 10, _141) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_142 = {}, _142[heroes.Midnight.ID] = 10, _142) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_143 = {}, _143[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _143) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MIDNIGHT_4: new PromoOffer({
        ID: 5242,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5141],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5235,
        enablePopup: true,
        popupSettings: {
            popUpId: 5242,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_144 = {}, _144[heroes.Midnight.ID] = 30, _144) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_145 = {}, _145[heroes.Midnight.ID] = 30, _145) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_146 = {}, _146[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _146) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_EMPEROR_3: new PromoOffer({
        ID: 5236,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5155],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5236,
        enablePopup: true,
        popupSettings: {
            popUpId: 5236,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_147 = {}, _147[heroes.Emperor.ID] = 10, _147) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_148 = {}, _148[heroes.Emperor.ID] = 10, _148) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_149 = {}, _149[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _149) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_EMPEROR_4: new PromoOffer({
        ID: 5243,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5155],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5236,
        enablePopup: true,
        popupSettings: {
            popUpId: 5243,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_150 = {}, _150[heroes.Emperor.ID] = 30, _150) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_151 = {}, _151[heroes.Emperor.ID] = 30, _151) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_152 = {}, _152[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _152) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MARCUS_3: new PromoOffer({
        ID: 5237,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5143],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5237,
        enablePopup: true,
        popupSettings: {
            popUpId: 5237,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_153 = {}, _153[heroes.Marcus.ID] = 10, _153) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_154 = {}, _154[heroes.Marcus.ID] = 10, _154) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_155 = {}, _155[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _155) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MARCUS_4: new PromoOffer({
        ID: 5244,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5143],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5237,
        enablePopup: true,
        popupSettings: {
            popUpId: 5244,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_156 = {}, _156[heroes.Marcus.ID] = 30, _156) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_157 = {}, _157[heroes.Marcus.ID] = 30, _157) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_158 = {}, _158[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _158) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_KIBO_3: new PromoOffer({
        ID: 5238,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5150],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5238,
        enablePopup: true,
        popupSettings: {
            popUpId: 5238,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_159 = {}, _159[heroes.Kibo.ID] = 10, _159) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_160 = {}, _160[heroes.Kibo.ID] = 10, _160) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_161 = {}, _161[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _161) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_KIBO_4: new PromoOffer({
        ID: 5245,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5150],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5238,
        enablePopup: true,
        popupSettings: {
            popUpId: 5245,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_162 = {}, _162[heroes.Kibo.ID] = 30, _162) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_163 = {}, _163[heroes.Kibo.ID] = 30, _163) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_164 = {}, _164[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _164) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_BUTCHER_3: new PromoOffer({
        ID: 5239,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5158],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5239,
        enablePopup: true,
        popupSettings: {
            popUpId: 5239,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_165 = {}, _165[heroes.Butcher.ID] = 10, _165) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_166 = {}, _166[heroes.Butcher.ID] = 10, _166) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_167 = {}, _167[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _167) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_BUTCHER_4: new PromoOffer({
        ID: 5246,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5158],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5239,
        enablePopup: true,
        popupSettings: {
            popUpId: 5246,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_168 = {}, _168[heroes.Butcher.ID] = 30, _168) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_169 = {}, _169[heroes.Butcher.ID] = 30, _169) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_170 = {}, _170[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _170) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_XIANGTZU_3: new PromoOffer({
        ID: 5240,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5161],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5240,
        enablePopup: true,
        popupSettings: {
            popUpId: 5240,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_171 = {}, _171[heroes.Xiang_Tzu.ID] = 10, _171) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_172 = {}, _172[heroes.Xiang_Tzu.ID] = 10, _172) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_173 = {}, _173[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(600) }], _173) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_XIANGTZU_4: new PromoOffer({
        ID: 5247,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_50.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5161],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5240,
        enablePopup: true,
        popupSettings: {
            popUpId: 5247,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_174 = {}, _174[heroes.Xiang_Tzu.ID] = 30, _174) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_175 = {}, _175[heroes.Xiang_Tzu.ID] = 30, _175) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_176 = {}, _176[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _176) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MONKEYKING_3: new PromoOffer({
        ID: 5262,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5153],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5262,
        enablePopup: true,
        popupSettings: {
            popUpId: 5262,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_177 = {}, _177[heroes.Monkey_King.ID] = 10, _177) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_178 = {}, _178[heroes.Monkey_King.ID] = 5, _178) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_179 = {}, _179[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _179) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_MONKEYKING_4: new PromoOffer({
        ID: 5265,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5153],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5262,
        enablePopup: true,
        popupSettings: {
            popUpId: 5265,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_180 = {}, _180[heroes.Monkey_King.ID] = 30, _180) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_181 = {}, _181[heroes.Monkey_King.ID] = 10, _181) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_182 = {}, _182[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _182) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LEGIONKING_3: new PromoOffer({
        ID: 5263,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5146],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5263,
        enablePopup: true,
        popupSettings: {
            popUpId: 5263,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_183 = {}, _183[heroes.Legion_King.ID] = 10, _183) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_184 = {}, _184[heroes.Legion_King.ID] = 5, _184) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_185 = {}, _185[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _185) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_LEGIONKING_4: new PromoOffer({
        ID: 5266,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5146],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5263,
        enablePopup: true,
        popupSettings: {
            popUpId: 5266,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_186 = {}, _186[heroes.Legion_King.ID] = 30, _186) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_187 = {}, _187[heroes.Legion_King.ID] = 10, _187) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_188 = {}, _188[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _188) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_ITU_3: new PromoOffer({
        ID: 5264,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5159],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5264,
        enablePopup: true,
        popupSettings: {
            popUpId: 5264,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_189 = {}, _189[heroes.Itu.ID] = 10, _189) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_190 = {}, _190[heroes.Itu.ID] = 5, _190) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_191 = {}, _191[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _191) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_ITU_4: new PromoOffer({
        ID: 5267,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5159],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5264,
        enablePopup: true,
        popupSettings: {
            popUpId: 5267,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_192 = {}, _192[heroes.Itu.ID] = 30, _192) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_193 = {}, _193[heroes.Itu.ID] = 10, _193) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_194 = {}, _194[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _194) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_JUNE_3: new PromoOffer({
        ID: 5275,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5274],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5275,
        enablePopup: true,
        popupSettings: {
            popUpId: 5275,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_195 = {}, _195[heroes.June.ID] = 10, _195) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_196 = {}, _196[heroes.June.ID] = 5, _196) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_197 = {}, _197[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _197) } } }]
                },
            ]
        },
    }),
    PROGRESS_META_JUNE_4: new PromoOffer({
        ID: 5276,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_75.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5274],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5275,
        enablePopup: true,
        popupSettings: {
            popUpId: 5276,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_198 = {}, _198[heroes.June.ID] = 30, _198) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_199 = {}, _199[heroes.June.ID] = 10, _199) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_200 = {}, _200[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _200) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_IRONCLAD_3: new PromoOffer({
        ID: 5174,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5162, 5163],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5174,
        enablePopup: true,
        popupSettings: {
            popUpId: 5174,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Ironclad.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_201 = {}, _201[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _201) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_202 = {}, _202[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _202) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_IRONCLAD_4: new PromoOffer({
        ID: 5175,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5162, 5163],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5174,
        enablePopup: true,
        popupSettings: {
            popUpId: 5175,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Ironclad.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_203 = {}, _203[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _203) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_BULWARK_3: new PromoOffer({
        ID: 5176,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5164, 5165],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5176,
        enablePopup: true,
        popupSettings: {
            popUpId: 5176,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Bulwark.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_204 = {}, _204[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _204) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_205 = {}, _205[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _205) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_BULWARK_4: new PromoOffer({
        ID: 5177,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5164, 5165],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5176,
        enablePopup: true,
        popupSettings: {
            popUpId: 5177,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Bulwark.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_206 = {}, _206[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _206) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MONK_3: new PromoOffer({
        ID: 5178,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5166, 5167],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5178,
        enablePopup: true,
        popupSettings: {
            popUpId: 5178,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Monk.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_207 = {}, _207[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _207) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_208 = {}, _208[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _208) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MONK_4: new PromoOffer({
        ID: 5179,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5166, 5167],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5178,
        enablePopup: true,
        popupSettings: {
            popUpId: 5179,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Monk.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_209 = {}, _209[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _209) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LIQUIDATOR_3: new PromoOffer({
        ID: 5180,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5168, 5169],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5180,
        enablePopup: true,
        popupSettings: {
            popUpId: 5180,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Liquidator.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_210 = {}, _210[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _210) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_211 = {}, _211[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _211) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LIQUIDATOR_4: new PromoOffer({
        ID: 5181,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5168, 5169],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5180,
        enablePopup: true,
        popupSettings: {
            popUpId: 5181,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Liquidator.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_212 = {}, _212[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _212) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_FIREGUARD_3: new PromoOffer({
        ID: 5182,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5170, 5171],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5182,
        enablePopup: true,
        popupSettings: {
            popUpId: 5182,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Fireguard.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_213 = {}, _213[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _213) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_214 = {}, _214[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _214) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_FIREGUARD_4: new PromoOffer({
        ID: 5183,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5170, 5171],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5182,
        enablePopup: true,
        popupSettings: {
            popUpId: 5183,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Fireguard.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_215 = {}, _215[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _215) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_FELDSHER_3: new PromoOffer({
        ID: 5184,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5172, 5173],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5184,
        enablePopup: true,
        popupSettings: {
            popUpId: 5184,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Feldsher.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_216 = {}, _216[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _216) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_217 = {}, _217[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _217) } } }]
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_FELDSHER_4: new PromoOffer({
        ID: 5185,
        disableGeneratingSince: null,
        visualPresetId: "5020",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5172, 5173],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5184,
        enablePopup: true,
        popupSettings: {
            popUpId: 5185,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Feldsher.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_218 = {}, _218[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _218) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_SARGE_3: new PromoOffer({
        ID: 5218,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5186, 5194],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5218,
        enablePopup: true,
        popupSettings: {
            popUpId: 5218,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Sarge.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_219 = {}, _219[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _219) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_220 = {}, _220[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _220) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_SARGE_4: new PromoOffer({
        ID: 5226,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5186, 5194],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5218,
        enablePopup: true,
        popupSettings: {
            popUpId: 5226,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.RARE_SKIN],
                hero: HeroNames.Sarge.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_221 = {}, _221[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _221) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LING_3: new PromoOffer({
        ID: 5219,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5187, 5195],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5219,
        enablePopup: true,
        popupSettings: {
            popUpId: 5219,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Ling.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_222 = {}, _222[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _222) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_223 = {}, _223[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _223) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LING_4: new PromoOffer({
        ID: 5227,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5187, 5195],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5219,
        enablePopup: true,
        popupSettings: {
            popUpId: 5227,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Ling.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_224 = {}, _224[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _224) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_YUKKA_3: new PromoOffer({
        ID: 5220,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5188, 5196],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5220,
        enablePopup: true,
        popupSettings: {
            popUpId: 5220,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Yukka.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_225 = {}, _225[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _225) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_226 = {}, _226[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _226) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_YUKKA_4: new PromoOffer({
        ID: 5228,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5188, 5196],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5220,
        enablePopup: true,
        popupSettings: {
            popUpId: 5228,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Yukka.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_227 = {}, _227[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _227) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_VIPER_3: new PromoOffer({
        ID: 5221,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5189, 5197],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5221,
        enablePopup: true,
        popupSettings: {
            popUpId: 5221,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Viper.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_228 = {}, _228[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _228) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_229 = {}, _229[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _229) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_VIPER_4: new PromoOffer({
        ID: 5229,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5189, 5197],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5221,
        enablePopup: true,
        popupSettings: {
            popUpId: 5229,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.RARE_SKIN],
                hero: HeroNames.Viper.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_230 = {}, _230[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _230) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_HONGJOO_3: new PromoOffer({
        ID: 5222,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5190, 5198],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5222,
        enablePopup: true,
        popupSettings: {
            popUpId: 5222,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.HongJoo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_231 = {}, _231[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _231) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_232 = {}, _232[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _232) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_HONGJOO_4: new PromoOffer({
        ID: 5230,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5190, 5198],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5222,
        enablePopup: true,
        popupSettings: {
            popUpId: 5230,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.HongJoo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_233 = {}, _233[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _233) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_JET_3: new PromoOffer({
        ID: 5223,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5191, 5199],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5223,
        enablePopup: true,
        popupSettings: {
            popUpId: 5223,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Jet.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_234 = {}, _234[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _234) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_235 = {}, _235[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _235) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_JET_4: new PromoOffer({
        ID: 5231,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5191, 5199],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5223,
        enablePopup: true,
        popupSettings: {
            popUpId: 5231,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Jet.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_236 = {}, _236[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _236) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_HELGA_3: new PromoOffer({
        ID: 5224,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5192, 5216],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5224,
        enablePopup: true,
        popupSettings: {
            popUpId: 5224,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Helga.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_237 = {}, _237[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _237) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_238 = {}, _238[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _238) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_HELGA_4: new PromoOffer({
        ID: 5232,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5192, 5216],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5224,
        enablePopup: true,
        popupSettings: {
            popUpId: 5232,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Helga.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_239 = {}, _239[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _239) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_YUNLIN_3: new PromoOffer({
        ID: 5225,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5193, 5217],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5225,
        enablePopup: true,
        popupSettings: {
            popUpId: 5225,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_240 = {}, _240[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _240) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_YUNLIN_4: new PromoOffer({
        ID: 5233,
        disableGeneratingSince: null,
        visualPresetId: "5032",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5193, 5217],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5225,
        enablePopup: true,
        popupSettings: {
            popUpId: 5233,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LYNX_3: new PromoOffer({
        ID: 5248,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5234, 5241],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5248,
        enablePopup: true,
        popupSettings: {
            popUpId: 5248,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Lynx.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_241 = {}, _241[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _241) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_242 = {}, _242[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _242) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LYNX_4: new PromoOffer({
        ID: 5255,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5234, 5241],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5248,
        enablePopup: true,
        popupSettings: {
            popUpId: 5255,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Lynx.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_243 = {}, _243[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _243) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MIDNIGHT_3: new PromoOffer({
        ID: 5249,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5235, 5242],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5249,
        enablePopup: true,
        popupSettings: {
            popUpId: 5249,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Midnight.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_244 = {}, _244[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _244) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_245 = {}, _245[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _245) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MIDNIGHT_4: new PromoOffer({
        ID: 5256,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5235, 5242],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5249,
        enablePopup: true,
        popupSettings: {
            popUpId: 5256,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Midnight.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_246 = {}, _246[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _246) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_EMPEROR_3: new PromoOffer({
        ID: 5250,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5236, 5243],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5250,
        enablePopup: true,
        popupSettings: {
            popUpId: 95090,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Emperor.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_247 = {}, _247[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _247) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_248 = {}, _248[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _248) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_EMPEROR_4: new PromoOffer({
        ID: 5257,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5236, 5243],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5250,
        enablePopup: true,
        popupSettings: {
            popUpId: 5257,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Emperor.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_249 = {}, _249[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _249) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MARCUS_3: new PromoOffer({
        ID: 5251,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5237, 5244],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5251,
        enablePopup: true,
        popupSettings: {
            popUpId: 5251,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Marcus.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_250 = {}, _250[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _250) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_251 = {}, _251[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _251) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MARCUS_4: new PromoOffer({
        ID: 5258,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5237, 5244],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5251,
        enablePopup: true,
        popupSettings: {
            popUpId: 5258,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Marcus.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_252 = {}, _252[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _252) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_KIBO_3: new PromoOffer({
        ID: 5252,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5238, 5245],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5252,
        enablePopup: true,
        popupSettings: {
            popUpId: 5252,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Kibo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_253 = {}, _253[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _253) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_254 = {}, _254[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _254) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_KIBO_4: new PromoOffer({
        ID: 5259,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5238, 5245],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5252,
        enablePopup: true,
        popupSettings: {
            popUpId: 5259,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Kibo.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_255 = {}, _255[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _255) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_BUTCHER_3: new PromoOffer({
        ID: 5253,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5239, 5246],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5253,
        enablePopup: true,
        popupSettings: {
            popUpId: 5253,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_256 = {}, _256[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _256) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_BUTCHER_4: new PromoOffer({
        ID: 5260,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5239, 5246],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5253,
        enablePopup: true,
        popupSettings: {
            popUpId: 5260,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Butcher_E_Mogwai.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_XIANGTZU_3: new PromoOffer({
        ID: 5254,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5240, 5247],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5254,
        enablePopup: true,
        popupSettings: {
            popUpId: 5254,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_257 = {}, _257[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _257) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_XIANGTZU_4: new PromoOffer({
        ID: 5261,
        disableGeneratingSince: null,
        visualPresetId: "5046",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.8,
        discount: "-45%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5240, 5247],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5254,
        enablePopup: true,
        popupSettings: {
            popUpId: 5261,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MONKEYKING_3: new PromoOffer({
        ID: 5268,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5262, 5265],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5268,
        enablePopup: true,
        popupSettings: {
            popUpId: 5268,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Monkey_King.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_258 = {}, _258[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _258) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_259 = {}, _259[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _259) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_MONKEYKING_4: new PromoOffer({
        ID: 5271,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5262, 5265],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5268,
        enablePopup: true,
        popupSettings: {
            popUpId: 5271,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.SEASON_SKIN, CUSTOMIZATION_RARITY.EPIC_SKIN],
                hero: HeroNames.Monkey_King.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_260 = {}, _260[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1200) }], _260) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LEGIONKING_3: new PromoOffer({
        ID: 5269,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5263, 5266],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5269,
        enablePopup: true,
        popupSettings: {
            popUpId: 5269,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Legion_King.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_261 = {}, _261[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _261) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_262 = {}, _262[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _262) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_LEGIONKING_4: new PromoOffer({
        ID: 5272,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5263, 5266],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5269,
        enablePopup: true,
        popupSettings: {
            popUpId: 5272,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.RARE_SKIN],
                hero: HeroNames.Legion_King.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_263 = {}, _263[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _263) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_ITU_3: new PromoOffer({
        ID: 5270,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5264, 5267],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5270,
        enablePopup: true,
        popupSettings: {
            popUpId: 5270,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.STANCE, CUSTOMIZATION.TAUNT],
                rarities: [CUSTOMIZATION_RARITY.SEASON_STANCE, CUSTOMIZATION_RARITY.EPIC_STANCE, CUSTOMIZATION_RARITY.EPIC_TAUNT, CUSTOMIZATION_RARITY.SEASON_TAUNT],
                hero: HeroNames.Itu.ID,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_264 = {}, _264[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _264) } } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_265 = {}, _265[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _265) } } }],
                },
            ]
        },
    }),
    PROGRESS_CUSTOM_ITU_4: new PromoOffer({
        ID: 5273,
        disableGeneratingSince: null,
        visualPresetId: "5056",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {},
        previousOffers: [5264, 5267],
        forgetOffers: {
            forgetPrevious: false,
        },
        promoOfferGroup: 5270,
        enablePopup: true,
        popupSettings: {
            popUpId: 5273,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_E_Demon.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
            ]
        },
    }),
    PROGRESS_INDICATION_JUNE: new PromoOffer({
        ID: 5277,
        visualPresetId: "5277",
        offerNameAlias: "title_promo_0.3.1",
        triggers: [PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_30.ProductID,
        noHeroExist: [heroes.June.ID],
        profit: 1.5,
        discount: "-30%",
        companies: ["GA_SFA_Andr_MT_WW_Eng_tRoas #1 051023", "GA_SFA_Andr_MT_WW_Eng_tRoas #2 051023",
            "FB_SFA_Andr_MT_AA_WW_LAL_Val #1 051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val #2 051023",
            "TT_SFA_Andr_MT_WW_Val #1 051023", "TT_SFA_Andr_MT_WW_Val #2 051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val_1_051023",
            "TT_SFA_Andr_MT_WW_Val_1_051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val_1_070224"],
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5277,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_266 = {}, _266[heroes.June.ID] = 10, _266) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.June_R_Star.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }]
                },
            ]
        },
    }),
    PROGRESS_INDICATION_ITU: new PromoOffer({
        ID: 5278,
        visualPresetId: "5278",
        offerNameAlias: "title_promo_0.3.1",
        triggers: [PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        inApp: inAppSettings.PRICE_30.ProductID,
        noHeroExist: [heroes.Itu.ID],
        profit: 1.8,
        discount: "-45%",
        companies: ["GA_SFA_Andr_MT_WW_Eng_tRoas #1 051023", "GA_SFA_Andr_MT_WW_Eng_tRoas #2 051023",
            "FB_SFA_Andr_MT_AA_WW_LAL_Val #1 051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val #2 051023",
            "TT_SFA_Andr_MT_WW_Val #1 051023", "TT_SFA_Andr_MT_WW_Val #2 051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val_1_051023",
            "TT_SFA_Andr_MT_WW_Val_1_051023", "FB_SFA_Andr_MT_AA_WW_LAL_Val_1_070224"],
        activeTime: { duration: new Time({ Days: 2 }).value },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 5277,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_267 = {}, _267[heroes.Itu.ID] = 10, _267) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_E_Demon.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Itu_E_Vortex.ID] }) } } }],
                },
            ]
        },
    }),
}, true);
