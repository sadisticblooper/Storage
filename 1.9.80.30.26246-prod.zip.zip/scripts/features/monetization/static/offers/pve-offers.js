var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64;
extend(offers, {
    PROGRESS_BOSS_SKIN_1: new PromoOffer({
        ID: 50,
        visualPresetId: "boss_Ironclad_E_Rust_Rec_Boss",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_a = {}, _a[heroes.Ironclad.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _a)
        },
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 1 },
        productGroup: 50,
        enablePopup: true,
        popupSettings: {
            popUpId: 950,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ironclad_E_Rust_Rec_Boss.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _b) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _c) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_1_1: new PromoOffer({
        ID: 51,
        visualPresetId: "boss_Ironclad_E_Rust_Rec_Boss",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 1 },
        noHeroExist: [heroes.Ironclad.ID],
        productGroup: 50,
        enablePopup: true,
        popupSettings: {
            popUpId: 951,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ironclad_E_Rust_Rec_Boss.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Ironclad.ID] = 10, _d) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_e = {}, _e[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _e) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _f) } } }]
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.AD_TOKEN] = 75, _g) }) } } }],
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_2: new PromoOffer({
        ID: 52,
        visualPresetId: "boss_Sarge_E_Jailer_Rec_Boss",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_h = {}, _h[heroes.Sarge.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _h)
        },
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 2 },
        productGroup: 52,
        enablePopup: true,
        popupSettings: {
            popUpId: 952,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Sarge_E_Jailer_Rec_Boss.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _j) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_k = {}, _k[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _k) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_2_1: new PromoOffer({
        ID: 53,
        visualPresetId: "boss_Sarge_E_Jailer_Rec_Boss",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 2 },
        noHeroExist: [heroes.Sarge.ID],
        productGroup: 52,
        enablePopup: true,
        popupSettings: {
            popUpId: 953,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Sarge_E_Jailer_Rec_Boss.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_l = {}, _l[heroes.Sarge.ID] = 10, _l) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _m) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_o = {}, _o[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _o) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_3: new PromoOffer({
        ID: 54,
        visualPresetId: "boss_Helga_E_Phoenix_Rec_Boss_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_p = {}, _p[heroes.Helga.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _p)
        },
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 3 },
        productGroup: 54,
        enablePopup: true,
        popupSettings: {
            popUpId: 954,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Helga_E_Phoenix_Rec_Boss_skin.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_q = {}, _q[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _q) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _r) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_3_1: new PromoOffer({
        ID: 55,
        visualPresetId: "boss_Helga_E_Phoenix_Rec_Boss_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 3 },
        noHeroExist: [heroes.Helga.ID],
        productGroup: 54,
        enablePopup: true,
        popupSettings: {
            popUpId: 955,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Helga_E_Phoenix_Rec_Boss_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_s = {}, _s[heroes.Helga.ID] = 10, _s) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _t) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_u = {}, _u[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _u) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_4: new PromoOffer({
        ID: 40,
        visualPresetId: "40",
        offerNameAlias: "skin_hero_Liquidator_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 50 },
            heroes: (_v = {}, _v[heroes.Liquidator.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _v)
        },
        productGroup: 40,
        enablePopup: true,
        popupSettings: {
            popUpId: 940,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Liquidator_R_Rec_Boss.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_w = {}, _w[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _w) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_x = {}, _x[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _x) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_4_1: new PromoOffer({
        ID: 41,
        visualPresetId: "40",
        offerNameAlias: "skin_hero_Liquidator_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 50 },
        },
        noHeroExist: [heroes.Liquidator.ID],
        productGroup: 40,
        enablePopup: true,
        popupSettings: {
            popUpId: 941,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Liquidator_R_Rec_Boss.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_y = {}, _y[heroes.Liquidator.ID] = 10, _y) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_z = {}, _z[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _z) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_0 = {}, _0[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _0) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_5: new PromoOffer({
        ID: 42,
        visualPresetId: "42",
        offerNameAlias: "skin_hero_Bulwark_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 80 },
            heroes: (_1 = {}, _1[heroes.Bulwark.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _1)
        },
        productGroup: 42,
        enablePopup: true,
        popupSettings: {
            popUpId: 942,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_R_Rec_Boss_skin.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _2) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_3 = {}, _3[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _3) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_5_1: new PromoOffer({
        ID: 43,
        visualPresetId: "42",
        offerNameAlias: "skin_hero_Bulwark_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 80 },
        },
        noHeroExist: [heroes.Bulwark.ID],
        productGroup: 42,
        enablePopup: true,
        popupSettings: {
            popUpId: 943,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_R_Rec_Boss_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_4 = {}, _4[heroes.Bulwark.ID] = 10, _4) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _5) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_6 = {}, _6[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _6) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_6: new PromoOffer({
        ID: 44,
        visualPresetId: "44",
        offerNameAlias: "skin_hero_Legion_King_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 120 },
            heroes: (_7 = {}, _7[heroes.Legion_King.ID] = { Level: { more_or_equal: 4 }, Exp: { more_or_equal: 0 } }, _7)
        },
        productGroup: 44,
        enablePopup: true,
        popupSettings: {
            popUpId: 944,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_R_Rec_Boss.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _8) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_9 = {}, _9[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _9) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_6_1: new PromoOffer({
        ID: 45,
        visualPresetId: "44",
        offerNameAlias: "skin_hero_Legion_King_R_Rec_Boss",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_35.ProductID,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            playerRating: { more_or_equal: 120 },
        },
        noHeroExist: [heroes.Legion_King.ID],
        productGroup: 44,
        enablePopup: true,
        popupSettings: {
            popUpId: 945,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_R_Rec_Boss.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_10 = {}, _10[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _10) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_11 = {}, _11[heroes.Legion_King.ID] = 10, _11) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_12 = {}, _12[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _12) } } }]
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.AD_TOKEN] = 175, _13) }) } } }],
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_8: new PromoOffer({
        ID: 1058,
        visualPresetId: "boss_Legion_King_E_Bone_Rec_Lich",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_14 = {}, _14[heroes.Legion_King.ID] = { Level: { more_or_equal: 4 }, Exp: { more_or_equal: 0 } }, _14)
        },
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 5 },
        productGroup: 1058,
        enablePopup: true,
        popupSettings: {
            popUpId: 91058,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_E_Bone_Rec_Lich.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_15 = {}, _15[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _15) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_16 = {}, _16[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _16) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_8_1: new PromoOffer({
        ID: 1059,
        visualPresetId: "boss_Legion_King_E_Bone_Rec_Lich",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_40.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 5 },
        noHeroExist: [heroes.Legion_King.ID],
        productGroup: 1058,
        enablePopup: true,
        popupSettings: {
            popUpId: 91059,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_E_Bone_Rec_Lich.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_17 = {}, _17[heroes.Legion_King.ID] = 10, _17) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_18 = {}, _18[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _18) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_19 = {}, _19[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _19) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_9: new PromoOffer({
        ID: 1410,
        visualPresetId: "boos_Monk_E_Cursed_Rec_Creepy",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_20 = {}, _20[heroes.Monk.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _20)
        },
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 6 },
        productGroup: 1410,
        enablePopup: true,
        popupSettings: {
            popUpId: 1410,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monk_E_Cursed_Rec_Creepy.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_21 = {}, _21[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _21) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_22 = {}, _22[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _22) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_9_1: new PromoOffer({
        ID: 1411,
        visualPresetId: "boos_Monk_E_Cursed_Rec_Creepy",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        profit: 1.3,
        discount: "-25%",
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 6 },
        noHeroExist: [heroes.Monk.ID],
        productGroup: 1410,
        enablePopup: true,
        popupSettings: {
            popUpId: 1411,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Monk_E_Cursed_Rec_Creepy.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_23 = {}, _23[heroes.Monk.ID] = 10, _23) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_24 = {}, _24[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _24) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_25 = {}, _25[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _25) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_11: new PromoOffer({
        ID: 1627,
        visualPresetId: "1600",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_26 = {}, _26[heroes.Yunlin.ID] = { Level: { more_or_equal: 2 }, Exp: { more_or_equal: 0 } }, _26),
        },
        noCustomizeExist: (_27 = {},
            _27[CUSTOMIZATION.SKIN] = [2401],
            _27[CUSTOMIZATION.EMOJI] = [900],
            _27),
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 7 },
        productGroup: 1627,
        enablePopup: true,
        popupSettings: {
            popUpId: 1627,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Yunlin_R_Hazy.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_28 = {}, _28[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _28) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_29 = {}, _29[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _29) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Yunlin_Hiding.ID] }) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_11_1: new PromoOffer({
        ID: 1628,
        visualPresetId: "1600",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        profit: 1.2,
        discount: "-20%",
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 7 },
        noHeroExist: [heroes.Yunlin.ID],
        noCustomizeExist: (_30 = {},
            _30[CUSTOMIZATION.SKIN] = [2401],
            _30[CUSTOMIZATION.EMOJI] = [900],
            _30),
        productGroup: 1627,
        enablePopup: true,
        popupSettings: {
            popUpId: 1628,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Yunlin_R_Hazy.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_31 = {}, _31[heroes.Yunlin.ID] = 10, _31) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_32 = {}, _32[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _32) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_33 = {}, _33[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _33) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Yunlin_Hiding.ID] }) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_12: new PromoOffer({
        ID: 1629,
        visualPresetId: "boss_Emperor_E_Doomed_Rec_Enlighten_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_34 = {}, _34[heroes.Emperor.ID] = { Level: { more_or_equal: 3 }, Exp: { more_or_equal: 0 } }, _34),
        },
        noCustomizeExist: (_35 = {},
            _35[CUSTOMIZATION.SKIN] = [1103],
            _35),
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 8 },
        productGroup: 1629,
        enablePopup: true,
        popupSettings: {
            popUpId: 1629,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Emperor_E_Doomed_Rec_Enlighten_skin.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_36 = {}, _36[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _36) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_37 = {}, _37[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _37) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_12_1: new PromoOffer({
        ID: 1630,
        visualPresetId: "boss_Emperor_E_Doomed_Rec_Enlighten_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        profit: 1.8,
        discount: "-40%",
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 8 },
        noHeroExist: [heroes.Emperor.ID],
        noCustomizeExist: (_38 = {},
            _38[CUSTOMIZATION.SKIN] = [1103],
            _38),
        productGroup: 1629,
        enablePopup: true,
        popupSettings: {
            popUpId: 1630,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Emperor_E_Doomed_Rec_Enlighten_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_39 = {}, _39[heroes.Emperor.ID] = 10, _39) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_40 = {}, _40[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _40) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_41 = {}, _41[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _41) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_13: new PromoOffer({
        ID: 1631,
        visualPresetId: "boss_Bulwark_E_Gold_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            heroes: (_42 = {}, _42[heroes.Bulwark.ID] = { Level: { more_or_equal: 1 }, Exp: { more_or_equal: 0 } }, _42),
        },
        noCustomizeExist: (_43 = {},
            _43[CUSTOMIZATION.SKIN] = [1001],
            _43),
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 4 },
        productGroup: 1631,
        enablePopup: true,
        popupSettings: {
            popUpId: 1631,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_E_Gold_skin.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_44 = {}, _44[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _44) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_45 = {}, _45[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _45) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_13_1: new PromoOffer({
        ID: 1632,
        visualPresetId: "boss_Bulwark_E_Gold_skin",
        offerNameAlias: "offer_boss_skin_pve",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        inApp: inAppSettings.PRICE_15.ProductID,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {},
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 4 },
        noHeroExist: [heroes.Bulwark.ID],
        noCustomizeExist: (_46 = {},
            _46[CUSTOMIZATION.SKIN] = [1103],
            _46),
        productGroup: 1631,
        enablePopup: true,
        popupSettings: {
            popUpId: 1632,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_E_Gold_skin.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_47 = {}, _47[heroes.Bulwark.ID] = 10, _47) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_48 = {}, _48[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(200) }], _48) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_49 = {}, _49[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _49) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_1_RU: new PromoOffer({
        ID: 32,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        price: (_50 = {}, _50[CURRENCY.BONUS] = 1200, _50),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_51 = {},
            _51[CUSTOMIZATION.SKIN] = [403],
            _51),
        country: ["RU"],
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 1 },
        productGroup: 32,
        enablePopup: true,
        popupSettings: {
            popUpId: 932,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ironclad_E_Rust_Rec_Boss.ID] }) } } }]
                },
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_2_RU: new PromoOffer({
        ID: 33,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        price: (_52 = {}, _52[CURRENCY.BONUS] = 1200, _52),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_53 = {},
            _53[CUSTOMIZATION.SKIN] = [1503],
            _53),
        country: ["RU"],
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 2 },
        productGroup: 33,
        enablePopup: true,
        popupSettings: {
            popUpId: 933,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Sarge_E_Jailer_Rec_Boss.ID] }) } } }]
                }
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_3_RU: new PromoOffer({
        ID: 34,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER],
        price: (_54 = {}, _54[CURRENCY.BONUS] = 1200, _54),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_55 = {},
            _55[CUSTOMIZATION.SKIN] = [604],
            _55),
        country: ["RU"],
        passRoguelikeConditions: { chapterStars: { equal: 1 }, chapterId: 3 },
        productGroup: 34,
        enablePopup: true,
        popupSettings: {
            popUpId: 934,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Helga_E_Phoenix_Rec_Boss_skin.ID] }) } } }]
                }
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_4_RU: new PromoOffer({
        ID: 35,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        price: (_56 = {}, _56[CURRENCY.BONUS] = 800, _56),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_57 = {},
            _57[CUSTOMIZATION.SKIN] = [304],
            _57),
        country: ["RU"],
        productGroup: 35,
        enablePopup: true,
        popupSettings: {
            popUpId: 935,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Liquidator_R_Rec_Boss.ID] }) } } }]
                }
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_5_RU: new PromoOffer({
        ID: 36,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        price: (_58 = {}, _58[CURRENCY.BONUS] = 800, _58),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_59 = {},
            _59[CUSTOMIZATION.SKIN] = [1004],
            _59),
        country: ["RU"],
        productGroup: 36,
        enablePopup: true,
        popupSettings: {
            popUpId: 936,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Bulwark_R_Rec_Boss_skin.ID] }) } } }]
                }
            ]
        },
    }),
    PROGRESS_BOSS_SKIN_6_RU: new PromoOffer({
        ID: 37,
        visualPresetId: "71",
        offerNameAlias: "video_subtitles_season4_2",
        triggers: [PROMO_TRIGGER_TYPE.RATING_CHANGE, PROMO_TRIGGER_TYPE.LOGIN],
        price: (_60 = {}, _60[CURRENCY.BONUS] = 800, _60),
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: { playerRating: { less_or_equal: -1 }, },
        noCustomizeExist: (_61 = {},
            _61[CUSTOMIZATION.SKIN] = [2002],
            _61),
        country: ["RU"],
        productGroup: 37,
        enablePopup: true,
        popupSettings: {
            popUpId: 937,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_R_Rec_Boss.ID] }) } } }]
                }
            ]
        },
    }),
    PROGRESS_ENERGY_01: new PromoOffer({
        visualPresetId: "70",
        ID: 70,
        offerNameAlias: "roguelike_energy",
        inApp: inAppSettings.PRICE_1.ProductID,
        conditions: {
            playerRating: { more_or_equal: 50 },
            currencies: (_62 = {}, _62[CURRENCY.ROGUELIKE_ENERGY] = { less_or_equal: 9 }, _62)
        },
        weeklySettings: {
            startDate: new Date("2022-08-15").getTime(),
            period: new Time({ Days: 1 }).value,
            activeDay: 1,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        popupSettings: {
            popUpId: 970,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_63 = {}, _63[CURRENCY.ROGUELIKE_ENERGY] = [{ Weight: 1, Amount: new RndFromInterval(60) }], _63) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_64 = {}, _64[CURRENCY.AD_TOKEN] = 5, _64) }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        activeTime: {},
        profit: 1.5,
        discount: "-35%",
    }),
}, true);
