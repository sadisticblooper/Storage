var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
extend(offers, {
    INACTIVE_LOGIN_20: new PromoOffer({
        ID: 701,
        visualPresetId: "411",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 5 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 20 }).value,
        productGroup: 701,
        sp: { min: 0, max: 0.99 },
        enablePopup: true,
        popupSettings: {
            popUpId: 9701,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest_shop.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _a) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _b) } } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_LYNX: new PromoOffer({
        ID: 702,
        visualPresetId: "702",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 10 }).value,
        productGroup: 702,
        sp: { min: 1, max: 99999 },
        noHeroExist: [heroes.Lynx.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 9702,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[heroes.Lynx.ID] = 10, _c) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[heroes.Lynx.ID] = 35, _d) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_E_Original.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Lynx_Sharpening.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_MK: new PromoOffer({
        ID: 703,
        visualPresetId: "703",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 13 }).value,
        productGroup: 703,
        sp: { min: 1, max: 99999 },
        noHeroExist: [heroes.Monkey_King.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 9703,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        sellHeroSettings: {
            heroId: heroes.Monkey_King.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Monkey_King.ID] = 10, _e) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[heroes.Monkey_King.ID] = 15, _f) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Monkey_King_E_Nephritis.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.MonkeyKing_Oooh.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_LK: new PromoOffer({
        ID: 704,
        visualPresetId: "704",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 13 }).value,
        productGroup: 704,
        sp: { min: 1, max: 99999 },
        noHeroExist: [heroes.Legion_King.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 9704,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Legion_King.ID] = 10, _g) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_h = {}, _h[heroes.Legion_King.ID] = 15, _h) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Legion_King_E_Bone.ID] }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Legion_King_ThumbsDown.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_BUTCHER: new PromoOffer({
        ID: 705,
        visualPresetId: "705",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 10 }).value,
        productGroup: 705,
        sp: { min: 1, max: 99999 },
        noHeroExist: [heroes.Butcher.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 9705,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_j = {}, _j[heroes.Butcher.ID] = 10, _j) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_k = {}, _k[heroes.Butcher.ID] = 35, _k) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Butcher_R_Purple.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Butcher_WatchingYou.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_ITU: new PromoOffer({
        ID: 706,
        visualPresetId: "706",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_30.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 13 }).value,
        productGroup: 706,
        noHeroExist: [heroes.Itu.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 706,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_l = {}, _l[heroes.Itu.ID] = 50, _l) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_m = {}, _m[heroes.Itu.ID] = 15, _m) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Itu_R_Red.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [stances.stance_Itu_R_preparation.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Itu_GlassBreaking.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                }
            ]
        }
    }),
    INACTIVE_LOGIN_RETARGET_JUNE: new PromoOffer({
        ID: 707,
        visualPresetId: "707",
        offerNameAlias: "promo_title_INACTIVE_LOGIN_20",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_30.ProductID,
        profit: 1,
        discount: "",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        timeFromLastLogin: new Time({ Days: 10 }).value,
        productGroup: 707,
        noHeroExist: [heroes.June.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 707,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_o = {}, _o[heroes.June.ID] = 50, _o) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_p = {}, _p[heroes.June.ID] = 15, _p) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.June_R_Star.ID] }) } } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Emoji_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                }
            ]
        }
    }),
}, true);
