var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
extend(offers, {
    PROMO_KIBO_STARTER: new PromoOffer({
        ID: 104,
        disableGeneratingSince: 1,
        isStarterPack: true,
        visualPresetId: "starter_pack_Kibo",
        offerNameAlias: "starter_pack",
        triggers: [PROMO_TRIGGER_TYPE.REWARD],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 5,
        discount: "-80%",
        smallBadgeVisual: PromoOfferConstants.visualForSmallBadgeWithKibo,
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        conditions: {
            accountLevel: { less_or_equal: 3 },
            playerArenaId: { more_or_equal: 1 },
            createdPlayerTime: { more_or_equal: new Date("2022-11-29T16:35:00Z").getTime() },
            fightCounters: {
                modesSum: {
                    total: { more_or_equal: 1 },
                    modes: [
                        FIGHT_MODE.RANKED,
                        FIGHT_MODE.AI,
                        FIGHT_MODE.TOURNAMENT,
                        FIGHT_MODE.FRIEND,
                        FIGHT_MODE.LOCAL_PVP_FRIEND,
                        FIGHT_MODE.ROGUELIKE_COMMON,
                        FIGHT_MODE.ROGUELIKE_SURVIVAL,
                    ],
                },
            },
        },
        noHeroExist: [heroes.Kibo.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 9104,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[heroes.Kibo.ID] = 10, _a) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Kibo.ID] = 5, _b) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _c) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(350) }], _d) } } }],
                }
            ]
        },
    }),
    PROGRESS_LYNX_NEWBIE_01: new PromoOffer({
        ID: 105,
        visualPresetId: "105",
        offerNameAlias: "epic_hero_title",
        triggers: [PROMO_TRIGGER_TYPE.FIRST_TIME_COMPLETE_TOURNAMENT],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 5,
        discount: "-80%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        firstTimeCompletedTournaments: [10001],
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 2,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        conditions: {},
        noHeroExist: [heroes.Lynx.ID],
        enablePopup: true,
        popupSettings: {
            popUpId: 105,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Lynx.ID] = 10, _e) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[heroes.Lynx.ID] = 15, _f) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_g = {}, _g[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _g) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.AD_TOKEN] = 25, _h) }) } } }],
                }
            ]
        },
    }),
    PROGRESS_LYNX_NEWBIE_02: new PromoOffer({
        ID: 106,
        visualPresetId: "105",
        offerNameAlias: "talents_attributes_tooltip_header",
        triggers: [PROMO_TRIGGER_TYPE.REWARD],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 6,
        discount: "-85%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        previousOffers: [105],
        conditions: {},
        enablePopup: true,
        popupSettings: {
            popUpId: 106,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_j = {}, _j[heroes.Lynx.ID] = 20, _j) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_k = {}, _k[heroes.Lynx.ID] = 20, _k) }) } } }],
                },
                {
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_l = {}, _l[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _l) } } }],
                }
            ]
        },
    }),
}, true);
