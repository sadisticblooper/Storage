var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62;
extend(offers, {
    CYCLE_WEEKLY_1_1_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4802,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 10, max: 89.99 },
        productGroup: 4802,
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.6,
        discount: "-40%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94802,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.BONUS] = 900, _a) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _b) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_1_2_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4803,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0, max: 0.49 },
        productGroup: 4802,
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 4.2,
        discount: "-75%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94803,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 900, _c) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _d) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.AD_TOKEN] = 15, _e) }) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_1_3_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4804,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0.50, max: 9.99 },
        productGroup: 4802,
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94804,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 900, _f) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_g = {}, _g[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _g) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_1_4_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4805,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 90, max: 999999 },
        productGroup: 4802,
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.7,
        discount: "-40%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94805,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.SKIN],
                rarities: [CUSTOMIZATION_RARITY.EPIC_SKIN, CUSTOMIZATION_RARITY.SEASON_SKIN],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 900, _h) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(20000) }], _j) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_2_1_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4929,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 10, max: 89.99 },
        productGroup: 4929,
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.3,
        discount: "-20%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94929,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.WEAPON],
                rarities: [CUSTOMIZATION_RARITY.EPIC_WEAPON],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.BONUS] = 1200, _k) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_l = {}, _l[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _l) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_2_2_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4930,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0, max: 0.49 },
        productGroup: 4929,
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 5.1,
        discount: "-80%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94930,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.WEAPON],
                rarities: [CUSTOMIZATION_RARITY.EPIC_WEAPON],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.BONUS] = 1200, _m) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_o = {}, _o[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _o) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.AD_TOKEN] = 15, _p) }) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_2_3_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4931,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0.50, max: 9.99 },
        productGroup: 4929,
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 3.0,
        discount: "-65%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94931,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.WEAPON],
                rarities: [CUSTOMIZATION_RARITY.EPIC_WEAPON],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.BONUS] = 1200, _q) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _r) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_2_4_2023: new PromoOffer({
        visualPresetId: "cycle_weekly_epic",
        ID: 4932,
        offerNameAlias: "promo_offer_style",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 90, max: 999999 },
        productGroup: 4929,
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 1.75,
        discount: "-45%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2023-10-28").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94932,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        rules: [OFFERS_RULES_GENERATE.RANDOM_CUSTOMIZATION],
        offerRandomCustomization: [
            {
                place: { placeHolder: "additionalPlaceHolder", side: "front", additionalIndex: 0 },
                types: [CUSTOMIZATION.WEAPON],
                rarities: [CUSTOMIZATION_RARITY.EPIC_WEAPON],
                generateOnlyForOpenedHeroes: true,
            },
        ],
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.BONUS] = 1200, _s) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(30000) }], _t) } } }],
                }
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_TUE_1: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4933,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 10, max: 89.99 },
        productGroup: 4933,
        inApp: inAppSettings.PRICE_6.ProductID,
        profit: 2.0,
        discount: "-50%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94933,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_u = {}, _u[buffModifiers.epicBuffs.ID] = 8, _u) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_v = {}, _v[buffModifiers.timerBuff.ID] = 8, _v) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_w = {}, _w[buffModifiers.twoBuffPerChoice.ID] = 8, _w) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_TUE_2: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4934,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0, max: 0.49 },
        productGroup: 4933,
        inApp: inAppSettings.PRICE_1.ProductID,
        profit: 4.5,
        discount: "-80%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94934,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_x = {}, _x[buffModifiers.epicBuffs.ID] = 3, _x) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_y = {}, _y[buffModifiers.timerBuff.ID] = 3, _y) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_z = {}, _z[buffModifiers.twoBuffPerChoice.ID] = 3, _z) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_TUE_3: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4935,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0.50, max: 9.99 },
        productGroup: 4933,
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94935,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_0 = {}, _0[buffModifiers.epicBuffs.ID] = 5, _0) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_1 = {}, _1[buffModifiers.timerBuff.ID] = 5, _1) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_2 = {}, _2[buffModifiers.twoBuffPerChoice.ID] = 5, _2) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_TUE_4: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4936,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 90, max: 999999 },
        productGroup: 4933,
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94936,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_3 = {}, _3[buffModifiers.epicBuffs.ID] = 10, _3) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_4 = {}, _4[buffModifiers.timerBuff.ID] = 10, _4) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_5 = {}, _5[buffModifiers.twoBuffPerChoice.ID] = 10, _5) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_WEN_1: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4937,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 10, max: 89.99 },
        productGroup: 4937,
        inApp: inAppSettings.PRICE_6.ProductID,
        profit: 2.0,
        discount: "-50%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94937,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_6 = {}, _6[buffModifiers.epicBuffs.ID] = 8, _6) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_7 = {}, _7[buffModifiers.timerBuff.ID] = 8, _7) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_8 = {}, _8[buffModifiers.twoBuffPerChoice.ID] = 8, _8) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_WEN_2: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4938,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0, max: 0.49 },
        productGroup: 4937,
        inApp: inAppSettings.PRICE_1.ProductID,
        profit: 4.5,
        discount: "-80%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94938,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_9 = {}, _9[buffModifiers.epicBuffs.ID] = 3, _9) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_10 = {}, _10[buffModifiers.timerBuff.ID] = 3, _10) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_11 = {}, _11[buffModifiers.twoBuffPerChoice.ID] = 3, _11) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_WEN_3: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4939,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 0.50, max: 9.99 },
        productGroup: 4937,
        inApp: inAppSettings.PRICE_3.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94939,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_12 = {}, _12[buffModifiers.epicBuffs.ID] = 5, _12) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_13 = {}, _13[buffModifiers.timerBuff.ID] = 5, _13) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_14 = {}, _14[buffModifiers.twoBuffPerChoice.ID] = 5, _14) }) } } }],
                },
            ]
        },
    }),
    CYCLE_WEEKLY_PVE_WEN_4: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4940,
        offerNameAlias: "shop_offers_sale",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        sp: { min: 90, max: 999999 },
        productGroup: 4937,
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: {},
        weeklySettings: {
            startDate: new Date("2024-06-25").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 2,
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 94940,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_15 = {}, _15[buffModifiers.epicBuffs.ID] = 10, _15) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_16 = {}, _16[buffModifiers.timerBuff.ID] = 10, _16) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_17 = {}, _17[buffModifiers.twoBuffPerChoice.ID] = 10, _17) }) } } }],
                },
            ]
        },
    }),
    PROGRESS_CURRENCY_01: new PromoOffer({
        visualPresetId: "cycle_currency",
        ID: 4902,
        offerNameAlias: "currency_cards",
        inApp: inAppSettings.PRICE_15.ProductID,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        weeklySettings: {
            startDate: new Date("2022-08-26").getTime(),
            period: new Time({ Days: 7 }).value,
            activeDay: 1,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        popupSettings: {
            popUpId: 94902,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_18 = {}, _18[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _18) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_19 = {}, _19[CURRENCY.GACHA_KEY] = [{ Weight: 1, Amount: new RndFromInterval(5) }], _19) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_20 = {}, _20[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _20) } } }]
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        activeTime: {},
        profit: 1.8,
        discount: "-45%",
    }),
    CYCLE_CARD_1_2023: new PromoOffer({
        ID: 4913,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4913,
        popupSettings: {
            popUpId: 94913,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 1,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 100, TotalSlots: 1, Rarities: (_21 = {}, _21[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 100 }] }, _21) } } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_22 = {}, _22[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _22) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_23 = {}, _23[CURRENCY.AD_TOKEN] = 5, _23) }) } } }],
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_2_2023: new PromoOffer({
        ID: 4914,
        visualPresetId: "promo_cards_rare",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4914,
        popupSettings: {
            popUpId: 94914,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 2,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 60, TotalSlots: 1, Rarities: (_24 = {}, _24[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 60 }] }, _24) } } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_25 = {}, _25[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _25) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.AD_TOKEN] = 15, _26) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_3_2023: new PromoOffer({
        ID: 4915,
        visualPresetId: "promo_cards_epic",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4915,
        popupSettings: {
            popUpId: 94915,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 3,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 12, TotalSlots: 1, Rarities: (_27 = {}, _27[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 12 }] }, _27) } } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_28 = {}, _28[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _28) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.AD_TOKEN] = 15, _29) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_4_2023: new PromoOffer({
        ID: 4916,
        visualPresetId: "promo_cards_legendary",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4916,
        popupSettings: {
            popUpId: 94916,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.LEGENDARY]),
        },
        weeklySettings: {
            startDate: new Date("2022-10-17").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 4,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_30 = {}, _30[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 4 }] }, _30) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_31 = {}, _31[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _31) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.AD_TOKEN] = 15, _32) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_5_2023: new PromoOffer({
        ID: 4917,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4913,
        popupSettings: {
            popUpId: 94917,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 1,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 400, TotalSlots: 1, Rarities: (_33 = {}, _33[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 400 }] }, _33) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_34 = {}, _34[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _34) } } }]
                },
            ],
        },
        profit: 1.3,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-25%",
    }),
    CYCLE_CARD_6_2023: new PromoOffer({
        ID: 4918,
        visualPresetId: "promo_cards_rare",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4914,
        popupSettings: {
            popUpId: 94918,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 2,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_35 = {}, _35[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _35) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_36 = {}, _36[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _36) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_7_2023: new PromoOffer({
        ID: 4919,
        visualPresetId: "promo_cards_epic",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4915,
        popupSettings: {
            popUpId: 94919,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-23").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 3,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_37 = {}, _37[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _37) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_38 = {}, _38[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _38) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_8_2023: new PromoOffer({
        ID: 4920,
        visualPresetId: "promo_cards_legendary",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4916,
        popupSettings: {
            popUpId: 94920,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.BEST_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.LEGENDARY]),
        },
        weeklySettings: {
            startDate: new Date("2022-10-17").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 4,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 20, TotalSlots: 1, Rarities: (_39 = {}, _39[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _39) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_40 = {}, _40[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _40) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_9_2023: new PromoOffer({
        ID: 4921,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4921,
        popupSettings: {
            popUpId: 94921,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 1,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 100, TotalSlots: 1, Rarities: (_41 = {}, _41[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 100 }] }, _41) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_42 = {}, _42[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _42) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.AD_TOKEN] = 5, _43) }) } } }],
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_10_2023: new PromoOffer({
        ID: 4922,
        visualPresetId: "promo_cards_rare",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4922,
        popupSettings: {
            popUpId: 94922,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 2,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 60, TotalSlots: 1, Rarities: (_44 = {}, _44[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 60 }] }, _44) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_45 = {}, _45[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _45) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.AD_TOKEN] = 15, _46) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_11_2023: new PromoOffer({
        ID: 4923,
        visualPresetId: "promo_cards_epic",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4923,
        popupSettings: {
            popUpId: 94923,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 3,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 12, TotalSlots: 1, Rarities: (_47 = {}, _47[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 12 }] }, _47) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_48 = {}, _48[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _48) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_49 = {}, _49[CURRENCY.AD_TOKEN] = 15, _49) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_12_2023: new PromoOffer({
        ID: 4924,
        visualPresetId: "promo_cards_legendary",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 0, max: 99 },
        productGroup: 4924,
        popupSettings: {
            popUpId: 94924,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.LEGENDARY]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 4,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_50 = {}, _50[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 4 }] }, _50) } } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_51 = {}, _51[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _51) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_52 = {}, _52[CURRENCY.AD_TOKEN] = 15, _52) }) } } }],
                },
            ],
        },
        profit: 1.4,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_13_2023: new PromoOffer({
        ID: 4925,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4921,
        popupSettings: {
            popUpId: 94925,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 1,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 400, TotalSlots: 1, Rarities: (_53 = {}, _53[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 400 }] }, _53) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_54 = {}, _54[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _54) } } }]
                },
            ],
        },
        profit: 1.3,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-25%",
    }),
    CYCLE_CARD_14_2023: new PromoOffer({
        ID: 4926,
        visualPresetId: "promo_cards_rare",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4922,
        popupSettings: {
            popUpId: 94926,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 2,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_55 = {}, _55[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _55) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_56 = {}, _56[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _56) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_15_2023: new PromoOffer({
        ID: 4927,
        visualPresetId: "promo_cards_epic",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4923,
        popupSettings: {
            popUpId: 94927,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 3,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_57 = {}, _57[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _57) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_58 = {}, _58[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _58) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_CARD_16_2023: new PromoOffer({
        ID: 4928,
        visualPresetId: "promo_cards_legendary",
        offerNameAlias: "promo_offer_levelup_title_2",
        enablePopup: true,
        sp: { min: 100, max: 99999 },
        productGroup: 4924,
        popupSettings: {
            popUpId: 94928,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        rules: [OFFERS_RULES_GENERATE.LOSER_HERO],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.LEGENDARY]),
        },
        weeklySettings: {
            startDate: new Date("2023-01-30").getTime(),
            period: new Time({ Days: 14 }).value,
            activeDay: 4,
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 20, TotalSlots: 1, Rarities: (_59 = {}, _59[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _59) } } } }
                    ]
                },
                { front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_60 = {}, _60[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _60) } } }]
                },
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    CYCLE_GOLD_01: new PromoOffer({
        visualPresetId: "cycle_daily_big",
        ID: 4912,
        offerNameAlias: "title_Patrik_W",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        conditions: {
            currencies: (_61 = {}, _61[CURRENCY.COIN] = { less_or_equal: 99 }, _61),
            accountLevel: { more_or_equal: 2 }
        },
        noActiveOffers: [5210, 5211, 5212, 5213],
        weeklySettings: {
            startDate: new Date("2022-11-28").getTime(),
            period: new Time({ Days: 1 }).value,
            activeDay: 1,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP],
        popupSettings: {
            popUpId: 94912,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_62 = {}, _62[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }], _62) } } }]
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        activeTime: {},
        profit: 1.8,
        discount: "-45%",
    }),
}, true);
