var _a, _b, _c, _d, _e, _f, _g, _h, _j;
extend(offers, {
    premium_battle_pass_caregame: new PromoOffer({
        ID: 1,
        visualPresetId: "caregame",
        offerNameAlias: "title_promo_offer_caregame",
        onceRepeatAfter: new Date("2024-04-20").getTime(),
        activeTime: { duration: new Time({ Days: 30 }).value },
        conditions: {},
        customCondition: function (settings) {
            var playerProgress = settings.playerProgress;
            var platform = settings.regionalSettings.platform;
            return platform == PLATFORM.CARE_GAME
                && playerProgress.tutorialPassed
                && isBattlePassAvailable(playerProgress).available;
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{ front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ BattlePassPoints: 17000 }) } } }] }]
        },
        additionalSettings: {
            unlockBattlePassPremiumSeason: true,
        },
        price: (_a = {}, _a[CURRENCY.BONUS] = 0, _a),
        enablePopup: true,
        popupSettings: {
            popUpId: 90,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
    }),
    caregame_marcus: new PromoOffer({
        visualPresetId: "caregame_marcus",
        ID: 2,
        offerNameAlias: "Marcus",
        productGroup: 2,
        conditions: {
            currencies: (_b = {}, _b[CURRENCY.CUSTOMIZATION_TOKEN] = { more_or_equal: 10000 }, _b),
        },
        platforms: [PLATFORM.CARE_GAME],
        noHeroExist: [heroes.Marcus.ID],
        sellHeroSettings: {
            heroId: heroes.Marcus.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 2,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[heroes.Marcus.ID] = 10, _c) }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        price: (_d = {}, _d[CURRENCY.CUSTOMIZATION_TOKEN] = 10000, _d),
        activeTime: { duration: PROMO_DURATION.ENDLESS },
    }),
    tokens_for_login_on_steam: new PromoOffer({
        ID: 3,
        visualPresetId: "tokens_for_login_on_steam",
        offerNameAlias: "ad_tokens_offer_title",
        conditions: {},
        customCondition: function (settings) {
            return SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        enablePopup: true,
        popupSettings: {
            popUpId: 3,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.AD_TOKEN] = 5, _e) }) } } }],
                },
            ]
        },
        price: (_f = {}, _f[CURRENCY.BONUS] = 0, _f),
        activeTime: {},
        weeklySettings: {
            startDate: steamReleaseDateOnPC,
            period: new Time({ Days: 1 }).value,
            activeDay: 1,
        },
    }),
    free_wpn_steam_login: new PromoOffer({
        ID: 4,
        visualPresetId: "free_wpn_steam",
        offerNameAlias: "promo_title_steam_download_offer",
        conditions: {},
        noCustomizeExist: (_g = {},
            _g[CUSTOMIZATION.WEAPON] = [heroWeapons.wpn_Bulwark_R_Base_Rec_Steam.ID],
            _g),
        customCondition: function (settings) {
            return SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        enablePopup: true,
        popupSettings: {
            popUpId: 4,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Bulwark_R_Base_Rec_Steam.ID] }) } }, }],
                },
            ]
        },
        price: (_h = {}, _h[CURRENCY.BONUS] = 0, _h),
        activeTime: {
            startGenerationBound: steamReleaseDateOnPC,
            endGenerationBound: steamReleaseDateOnPC + new Time({ Days: 15 }).value,
        },
    }),
    free_chest_steam_login: new PromoOffer({
        ID: 5,
        visualPresetId: "steam_arena_offer",
        offerNameAlias: "promo_offer_gift_short",
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        customCondition: function (settings) {
            return SteamPlatformUtils.isPCBuild(settings.regionalSettings.platform);
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        enablePopup: true,
        popupSettings: {
            popUpId: 5,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest_New_Hero.ID] } }],
                },
            ]
        },
        price: (_j = {}, _j[CURRENCY.BONUS] = 0, _j),
        autoRepeatAfter: true,
        activeTime: {
            startGenerationBound: new Date("2025-10-30").getTime(),
            endGenerationBound: new Date("2025-10-30").getTime() + new Time({ Days: 365 }).value
        },
    }),
}, true);
