extend(offers, {
    no_ad_offer: new PromoOffer({
        ID: 8000,
        disableGeneratingSince: 1,
        visualPresetId: "no_ad_offer",
        offerNameAlias: "no_ads_headline",
        inApp: inAppSettings.PRICE_5_5.ProductID,
        profit: 1.5,
        discount: "-35%",
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        customCondition: function (settings) {
            var regionalSettings = settings.regionalSettings, serverCurrentTime = settings.serverCurrentTime;
            var timeCheck = serverCurrentTime > regionalSettings.createdPlayerTime + new Time({ Days: 7 }).value;
            var platformCheck = [
                PLATFORM.ANDROID_EGS,
                PLATFORM.IOS_EGS,
                PLATFORM.CARE_GAME
            ].indexOf(regionalSettings.platform) == -1;
            return timeCheck && platformCheck;
        },
        additionalSettings: {
            freeOfAdsAfterPurchaseTimeMillis: new Time({ Days: 14 }).value
        },
        tryRegenerateOfferAfterBought: true,
        enablePopup: true,
        popupSettings: {
            popUpId: 6000,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: []
        },
        smallBadgeVisual: {
            "glow": "#68b85484",
            "decor": "#82e56a",
            "blinkGlow": "#ddffbb",
            "titleColor": "#FFD75E",
            "lobbyBadgeLabel": {
                "isAlias": true,
                "value": "no_ads_shortcut",
                "placeholders": null
            },
            "icon": "Sprites/Assets/NoAds/icon_NoAds",
            "bgGradient": {
                "colorKeys": [
                    {
                        "color": "#345c2a",
                        "time": 0
                    },
                    {
                        "color": "#5c1a24",
                        "time": 1
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 1,
                        "time": 0
                    },
                    {
                        "alpha": 1,
                        "time": 1
                    }
                ],
                "mode": 0
            }
        }
    }),
}, true);
