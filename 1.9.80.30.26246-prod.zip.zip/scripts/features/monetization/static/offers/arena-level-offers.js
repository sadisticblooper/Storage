var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;
extend(offers, {
    PROGRESS_ARENA_2_1_1: new PromoOffer({
        ID: 411,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_2_title",
        productGroup: 411,
        enablePopup: true,
        popupSettings: {
            popUpId: 9411,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_1.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
            playerArenaId: { equal: 3 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 100, TotalSlots: 1, Rarities: (_a = {}, _a[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 100 }] }, _a) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(100) }], _b) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.AD_TOKEN] = 5, _c) }) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_3_1_1: new PromoOffer({
        ID: 412,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_3_title",
        productGroup: 412,
        enablePopup: true,
        popupSettings: {
            popUpId: 9412,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_3.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.COMMON]),
            playerArenaId: { equal: 4 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 300, TotalSlots: 1, Rarities: (_d = {}, _d[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 300 }] }, _d) } } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_e = {}, _e[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }], _e) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.AD_TOKEN] = 15, _f) }) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_4_1_1: new PromoOffer({
        ID: 413,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_4_title",
        productGroup: 413,
        enablePopup: true,
        popupSettings: {
            popUpId: 9413,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
            playerArenaId: { equal: 5 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 100, TotalSlots: 1, Rarities: (_g = {}, _g[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 100 }] }, _g) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_h = {}, _h[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _h) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_5_1_1: new PromoOffer({
        ID: 414,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_5_title",
        productGroup: 414,
        enablePopup: true,
        popupSettings: {
            popUpId: 9414,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_8.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
            playerArenaId: { equal: 6 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 160, TotalSlots: 1, Rarities: (_j = {}, _j[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 160 }] }, _j) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_k = {}, _k[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(700) }], _k) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_6_1_1: new PromoOffer({
        ID: 415,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_6_title",
        productGroup: 415,
        enablePopup: true,
        popupSettings: {
            popUpId: 9415,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.RARE]),
            playerArenaId: { equal: 7 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 200, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 200 }] }, _l) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(850) }], _m) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_7_1_1: new PromoOffer({
        ID: 416,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_7_title",
        productGroup: 416,
        enablePopup: true,
        popupSettings: {
            popUpId: 9416,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_10.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
            playerArenaId: { equal: 8 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 40, TotalSlots: 1, Rarities: (_o = {}, _o[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 40 }] }, _o) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_p = {}, _p[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _p) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_8_1_1: new PromoOffer({
        ID: 417,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_8_title",
        productGroup: 417,
        enablePopup: true,
        popupSettings: {
            popUpId: 9417,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_15.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.EPIC]),
            playerArenaId: { equal: 9 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 60, TotalSlots: 1, Rarities: (_q = {}, _q[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 60 }] }, _q) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _r) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
    PROGRESS_ARENA_9_1_1: new PromoOffer({
        ID: 418,
        visualPresetId: "411",
        offerNameAlias: "promo_offer_arena_9_title",
        productGroup: 418,
        enablePopup: true,
        popupSettings: {
            popUpId: 9418,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        inApp: inAppSettings.PRICE_15.ProductID,
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        triggers: [PROMO_TRIGGER_TYPE.ARENA_CHANGE],
        conditions: {
            heroesOneOfExist: getAllHeroIdsInRarities([HERO_RARITY.LEGENDARY]),
            playerArenaId: { equal: 10 }
        },
        lootSettings: {
            additionalPlaceHolder: [
                { front: [
                        { weight: 1, item: { lootSettings: { CardsSlots: { TotalCards: 20, TotalSlots: 1, Rarities: (_s = {}, _s[HERO_RARITY.LEGENDARY] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _s) } } } }
                    ]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _t) } } }],
                }
            ],
        },
        profit: 1.5,
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        discount: "-30%",
    }),
}, true);
