var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31;
extend(offers, {
    CYCLE_DAILY_MON_1: new PromoOffer({
        ID: 7239,
        disableGeneratingSince: null,
        productGroup: 7239,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97239,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 3.8,
        discount: "-74%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _a) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_2: new PromoOffer({
        ID: 7240,
        disableGeneratingSince: null,
        productGroup: 7239,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97240,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 1.4,
        discount: "-26%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _b) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_3: new PromoOffer({
        ID: 7241,
        disableGeneratingSince: null,
        productGroup: 7239,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97241,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.3,
        discount: "-21%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _c) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_4: new PromoOffer({
        ID: 7242,
        disableGeneratingSince: null,
        productGroup: 7239,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97242,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.3,
        discount: "-21%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _d) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_1_T20: new PromoOffer({
        ID: 7271,
        disableGeneratingSince: null,
        productGroup: 7271,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97271,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_e = {}, _e[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _e) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_2_T20: new PromoOffer({
        ID: 7272,
        disableGeneratingSince: null,
        productGroup: 7271,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97272,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _f) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_3_T20: new PromoOffer({
        ID: 7273,
        disableGeneratingSince: null,
        productGroup: 7271,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97273,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_g = {}, _g[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _g) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_MON_4_T20: new PromoOffer({
        ID: 7274,
        disableGeneratingSince: null,
        productGroup: 7271,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97274,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Monday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-13%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_h = {}, _h[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(17000) }], _h) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_TUE_1: new PromoOffer({
        ID: 7243,
        disableGeneratingSince: null,
        productGroup: 7243,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97243,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 8,
        discount: "-85%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_2: new PromoOffer({
        ID: 7244,
        disableGeneratingSince: null,
        productGroup: 7243,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97244,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 4.0,
        discount: "-75%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_3: new PromoOffer({
        ID: 7245,
        disableGeneratingSince: null,
        productGroup: 7243,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97245,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_6.ProductID,
        disableRegionalPrices: false,
        profit: 2.7,
        discount: "-60%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_4: new PromoOffer({
        ID: 7246,
        disableGeneratingSince: null,
        productGroup: 7243,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97246,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_13.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-35%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID, chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_1_T20: new PromoOffer({
        ID: 7275,
        disableGeneratingSince: null,
        productGroup: 7275,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97275,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 8.0,
        discount: "-85%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_2_T20: new PromoOffer({
        ID: 7276,
        disableGeneratingSince: null,
        productGroup: 7275,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97276,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 4.0,
        discount: "-75%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_3_T20: new PromoOffer({
        ID: 7277,
        disableGeneratingSince: null,
        productGroup: 7275,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97277,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 3.2,
        discount: "-70%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_TUE_4_T20: new PromoOffer({
        ID: 7278,
        disableGeneratingSince: null,
        productGroup: 7275,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97278,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Tuesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 1.7,
        discount: "-40%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Weapon_chest.ID, chests.Weapon_chest.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_1: new PromoOffer({
        ID: 7247,
        disableGeneratingSince: null,
        promoOfferGroup: 7247,
        noActiveOffersNow: [7248, 7252, 7249, 7253, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97247,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 3.8,
        discount: "-74%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _j) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_2: new PromoOffer({
        ID: 7248,
        disableGeneratingSince: null,
        promoOfferGroup: 7248,
        noActiveOffersNow: [7247, 7251, 7249, 7253, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97248,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: false,
        profit: 1.4,
        discount: "-26%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_k = {}, _k[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _k) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_3: new PromoOffer({
        ID: 7249,
        disableGeneratingSince: null,
        promoOfferGroup: 7249,
        noActiveOffersNow: [7247, 7251, 7248, 7252, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97249,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.3,
        discount: "-21%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_l = {}, _l[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _l) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_4: new PromoOffer({
        ID: 7250,
        disableGeneratingSince: null,
        promoOfferGroup: 7250,
        noActiveOffersNow: [7247, 7251, 7248, 7252, 7249, 7253],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97250,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.3,
        discount: "-21%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _m) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_1_T20: new PromoOffer({
        ID: 7279,
        disableGeneratingSince: null,
        promoOfferGroup: 7279,
        noActiveOffersNow: [7280, 7284, 7281, 7285, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97279,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_o = {}, _o[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _o) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_2_T20: new PromoOffer({
        ID: 7280,
        disableGeneratingSince: null,
        promoOfferGroup: 7280,
        noActiveOffersNow: [7279, 7283, 7281, 7285, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97280,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_p = {}, _p[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _p) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_3_T20: new PromoOffer({
        ID: 7281,
        disableGeneratingSince: null,
        promoOfferGroup: 7281,
        noActiveOffersNow: [7279, 7283, 7280, 7284, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97281,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-18%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_q = {}, _q[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8000) }], _q) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V1_4_T20: new PromoOffer({
        ID: 7282,
        disableGeneratingSince: null,
        promoOfferGroup: 7282,
        noActiveOffersNow: [7279, 7283, 7280, 7284, 7281, 7285],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_1",
        enablePopup: true,
        popupSettings: {
            popUpId: 97282,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-13%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_r = {}, _r[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(17000) }], _r) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_1: new PromoOffer({
        ID: 7251,
        disableGeneratingSince: null,
        promoOfferGroup: 7247,
        noActiveOffersNow: [7248, 7252, 7249, 7253, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97251,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 4,
        discount: "-75%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_s = {}, _s[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _s) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _t) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_2: new PromoOffer({
        ID: 7252,
        disableGeneratingSince: null,
        promoOfferGroup: 7248,
        noActiveOffersNow: [7247, 7251, 7249, 7253, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97252,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 2.1,
        discount: "-52%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_u = {}, _u[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _u) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_v = {}, _v[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(700) }], _v) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_3: new PromoOffer({
        ID: 7253,
        disableGeneratingSince: null,
        promoOfferGroup: 7249,
        noActiveOffersNow: [7247, 7251, 7248, 7252, 7250, 7254],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97253,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_15.ProductID,
        disableRegionalPrices: false,
        profit: 1.3,
        discount: "-26%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_w = {}, _w[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _w) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_x = {}, _x[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _x) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_4: new PromoOffer({
        ID: 7254,
        disableGeneratingSince: null,
        promoOfferGroup: 7250,
        noActiveOffersNow: [7247, 7251, 7248, 7252, 7249, 7253],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97254,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_20.ProductID,
        disableRegionalPrices: false,
        profit: 2,
        discount: "-50%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_y = {}, _y[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _y) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_z = {}, _z[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _z) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_1_T20: new PromoOffer({
        ID: 7283,
        disableGeneratingSince: null,
        promoOfferGroup: 7279,
        noActiveOffersNow: [7280, 7284, 7281, 7285, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97283,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 2.5,
        discount: "-60%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_0 = {}, _0[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _0) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_1 = {}, _1[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _1) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_2_T20: new PromoOffer({
        ID: 7284,
        disableGeneratingSince: null,
        promoOfferGroup: 7280,
        noActiveOffersNow: [7279, 7283, 7281, 7285, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97284,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.5,
        discount: "-34%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(15000) }], _2) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_3 = {}, _3[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _3) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_3_T20: new PromoOffer({
        ID: 7285,
        disableGeneratingSince: null,
        promoOfferGroup: 7281,
        noActiveOffersNow: [7279, 7283, 7280, 7284, 7282, 7286],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97285,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 1.7,
        discount: "-42%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_4 = {}, _4[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(16000) }], _4) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1500) }], _5) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_WED_V2_4_T20: new PromoOffer({
        ID: 7286,
        disableGeneratingSince: null,
        promoOfferGroup: 7282,
        noActiveOffersNow: [7279, 7283, 7280, 7284, 7281, 7285],
        visualPresetId: "cycle_daily_vs",
        offerNameAlias: "promo_title_PROMO_STARTER_2",
        enablePopup: true,
        popupSettings: {
            popUpId: 97286,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Wednesday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: true,
        profit: 2,
        discount: "-50%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_6 = {}, _6[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(33000) }], _6) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_7 = {}, _7[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _7) } } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_1: new PromoOffer({
        ID: 7255,
        disableGeneratingSince: null,
        productGroup: 7255,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97255,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 3.7,
        discount: "-73%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_2: new PromoOffer({
        ID: 7256,
        disableGeneratingSince: null,
        productGroup: 7255,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97256,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 3.7,
        discount: "-73%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_3: new PromoOffer({
        ID: 7257,
        disableGeneratingSince: null,
        productGroup: 7255,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97257,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_4: new PromoOffer({
        ID: 7258,
        disableGeneratingSince: null,
        productGroup: 7255,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97258,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_1_T20: new PromoOffer({
        ID: 7287,
        disableGeneratingSince: null,
        productGroup: 7287,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97287,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 2.6,
        discount: "-62%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_2_T20: new PromoOffer({
        ID: 7288,
        disableGeneratingSince: null,
        productGroup: 7287,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97288,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_3_T20: new PromoOffer({
        ID: 7289,
        disableGeneratingSince: null,
        productGroup: 7287,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97289,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_THU_4_T20: new PromoOffer({
        ID: 7290,
        disableGeneratingSince: null,
        productGroup: 7287,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97290,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Thursday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: true,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID, chests.Large_Shard_Chest.ID,] } }]
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_1: new PromoOffer({
        ID: 7259,
        disableGeneratingSince: null,
        productGroup: 7259,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97259,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 3.7,
        discount: "-73%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_2: new PromoOffer({
        ID: 7260,
        disableGeneratingSince: null,
        productGroup: 7259,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97260,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_3: new PromoOffer({
        ID: 7261,
        disableGeneratingSince: null,
        productGroup: 7259,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97261,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_8.ProductID,
        disableRegionalPrices: false,
        profit: 1.4,
        discount: "-27%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_4: new PromoOffer({
        ID: 7262,
        disableGeneratingSince: null,
        productGroup: 7259,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97262,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_15.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-32%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID, chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_1_T20: new PromoOffer({
        ID: 7291,
        disableGeneratingSince: null,
        productGroup: 7291,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97291,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_2_T20: new PromoOffer({
        ID: 7292,
        disableGeneratingSince: null,
        productGroup: 7291,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97292,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 2.2,
        discount: "-55%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_3_T20: new PromoOffer({
        ID: 7293,
        disableGeneratingSince: null,
        productGroup: 7291,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97293,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 1.3,
        discount: "-21%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_FRI_4_T20: new PromoOffer({
        ID: 7294,
        disableGeneratingSince: null,
        productGroup: 7291,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97294,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Friday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: true,
        profit: 1.2,
        discount: "-17%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Skin_chest.ID, chests.Skin_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SAT_1: new PromoOffer({
        ID: 7263,
        disableGeneratingSince: null,
        productGroup: 7263,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97263,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 2.5,
        discount: "-60%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_8 = {}, _8[buffModifiers.epicBuffs.ID] = 5, _8) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_9 = {}, _9[buffModifiers.timerBuff.ID] = 5, _9) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_10 = {}, _10[buffModifiers.twoBuffPerChoice.ID] = 5, _10) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_2: new PromoOffer({
        ID: 7264,
        disableGeneratingSince: null,
        productGroup: 7263,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97264,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_11 = {}, _11[buffModifiers.epicBuffs.ID] = 3, _11) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_12 = {}, _12[buffModifiers.timerBuff.ID] = 3, _12) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_13 = {}, _13[buffModifiers.twoBuffPerChoice.ID] = 3, _13) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_3: new PromoOffer({
        ID: 7265,
        disableGeneratingSince: null,
        productGroup: 7263,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97265,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_14 = {}, _14[buffModifiers.epicBuffs.ID] = 5, _14) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_15 = {}, _15[buffModifiers.timerBuff.ID] = 5, _15) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_16 = {}, _16[buffModifiers.twoBuffPerChoice.ID] = 5, _16) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_4: new PromoOffer({
        ID: 7266,
        disableGeneratingSince: null,
        productGroup: 7263,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97266,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_17 = {}, _17[buffModifiers.epicBuffs.ID] = 10, _17) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_18 = {}, _18[buffModifiers.timerBuff.ID] = 10, _18) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_19 = {}, _19[buffModifiers.twoBuffPerChoice.ID] = 10, _19) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_1_T20: new PromoOffer({
        ID: 7295,
        disableGeneratingSince: null,
        productGroup: 7295,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97295,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 3,
        discount: "-67%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_20 = {}, _20[buffModifiers.epicBuffs.ID] = 10, _20) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_21 = {}, _21[buffModifiers.timerBuff.ID] = 10, _21) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_22 = {}, _22[buffModifiers.twoBuffPerChoice.ID] = 10, _22) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_2_T20: new PromoOffer({
        ID: 7296,
        disableGeneratingSince: null,
        productGroup: 7295,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97296,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_23 = {}, _23[buffModifiers.epicBuffs.ID] = 5, _23) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_24 = {}, _24[buffModifiers.timerBuff.ID] = 5, _24) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_25 = {}, _25[buffModifiers.twoBuffPerChoice.ID] = 5, _25) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_3_T20: new PromoOffer({
        ID: 7297,
        disableGeneratingSince: null,
        productGroup: 7295,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97297,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_26 = {}, _26[buffModifiers.epicBuffs.ID] = 10, _26) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_27 = {}, _27[buffModifiers.timerBuff.ID] = 10, _27) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_28 = {}, _28[buffModifiers.twoBuffPerChoice.ID] = 10, _28) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SAT_4_T20: new PromoOffer({
        ID: 7298,
        disableGeneratingSince: null,
        productGroup: 7295,
        visualPresetId: "cycle_daily_big",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97298,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Saturday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: true,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_29 = {}, _29[buffModifiers.epicBuffs.ID] = 15, _29) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_30 = {}, _30[buffModifiers.timerBuff.ID] = 15, _30) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Modifiers: (_31 = {}, _31[buffModifiers.twoBuffPerChoice.ID] = 15, _31) }) } } }],
                },
            ]
        },
    }),
    CYCLE_DAILY_SUN_1: new PromoOffer({
        ID: 7267,
        disableGeneratingSince: null,
        productGroup: 7267,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97267,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 3.7,
        discount: "-73%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_2: new PromoOffer({
        ID: 7268,
        disableGeneratingSince: null,
        productGroup: 7267,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97268,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_3.ProductID,
        disableRegionalPrices: false,
        profit: 1.8,
        discount: "-45%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_3: new PromoOffer({
        ID: 7269,
        disableGeneratingSince: null,
        productGroup: 7267,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97269,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_8.ProductID,
        disableRegionalPrices: false,
        profit: 1.4,
        discount: "-27%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_4: new PromoOffer({
        ID: 7270,
        disableGeneratingSince: null,
        productGroup: 7267,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97270,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: [],
        ignoredCountry: PromoOfferConstants.region20,
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_10.ProductID,
        disableRegionalPrices: false,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_1_T20: new PromoOffer({
        ID: 7299,
        disableGeneratingSince: null,
        productGroup: 7299,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97299,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0, max: 0.49 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 2.6,
        discount: "-61%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_2_T20: new PromoOffer({
        ID: 7300,
        disableGeneratingSince: null,
        productGroup: 7299,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97300,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 0.5, max: 9.99 },
        inApp: inAppSettings.PRICE_1.ProductID,
        disableRegionalPrices: true,
        profit: 1.5,
        discount: "-33%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_3_T20: new PromoOffer({
        ID: 7301,
        disableGeneratingSince: null,
        productGroup: 7299,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97301,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 10, max: 89.99 },
        inApp: inAppSettings.PRICE_2.ProductID,
        disableRegionalPrices: true,
        profit: 1.3,
        discount: "-23%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID] } }],
                    back: [{ weight: 1, item: { chests: [chests.Rare_chest.ID] } }],
                }
            ]
        },
    }),
    CYCLE_DAILY_SUN_4_T20: new PromoOffer({
        ID: 7302,
        disableGeneratingSince: null,
        productGroup: 7299,
        visualPresetId: "cycle_daily_1",
        offerNameAlias: "shop_offers_sale",
        enablePopup: true,
        popupSettings: {
            popUpId: 97302,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        activeTime: {},
        dailySettings: {
            day: DayOfWeek.Sunday,
        },
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        offerType: PROMO_OFFER_TYPE.STATIC,
        conditions: {
            accountLevel: { more_or_equal: 2 }
        },
        country: PromoOfferConstants.region20,
        ignoredCountry: [],
        sp: { min: 90, max: 99999 },
        inApp: inAppSettings.PRICE_4.ProductID,
        disableRegionalPrices: true,
        profit: 1.4,
        discount: "-30%",
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Animation_chest.ID, chests.Animation_chest.ID, chests.Animation_chest.ID,] } }],
                    back: [{ weight: 1, item: { chests: [chests.Epic_chest.ID, chests.Epic_chest.ID, chests.Epic_chest.ID,] } }],
                }
            ]
        },
    }),
}, true);
