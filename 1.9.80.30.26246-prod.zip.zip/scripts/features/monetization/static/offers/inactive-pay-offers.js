var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
extend(offers, {
    INACTIVE_PAY_3: new PromoOffer({
        visualPresetId: "411",
        ID: 600,
        offerNameAlias: "promo_title_INACTIVE_PAY_5",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        idleTime: [new Time({ Days: 3 }).value, new Time({ Days: 5 }).value],
        regenerationDelay: new Time({ Days: 5 }).value,
        productGroup: 600,
        enablePopup: true,
        popupSettings: {
            popUpId: 9600,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_a = {}, _a[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(650) }], _a) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_b = {}, _b[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _b) } } }],
                }
            ]
        }
    }),
    INACTIVE_PAY_5: new PromoOffer({
        ID: 601,
        visualPresetId: "411",
        offerNameAlias: "promo_title_INACTIVE_PAY_5",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.45,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        idleTime: [new Time({ Days: 5 }).value, new Time({ Days: 12 }).value],
        regenerationDelay: new Time({ Days: 5 }).value,
        productGroup: 601,
        enablePopup: true,
        popupSettings: {
            popUpId: 9601,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest_shop.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(500) }], _c) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_d = {}, _d[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _d) } } }],
                }
            ]
        }
    }),
    INACTIVE_PAY_12: new PromoOffer({
        ID: 602,
        visualPresetId: "411",
        offerNameAlias: "promo_title_INACTIVE_PAY_12",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2,
        discount: "-50%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        idleTime: [new Time({ Days: 12 }).value, new Time({ Days: 18 }).value],
        regenerationDelay: new Time({ Days: 12 }).value,
        productGroup: 602,
        enablePopup: true,
        popupSettings: {
            popUpId: 9602,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest_shop.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Epic_chest.ID] } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_e = {}, _e[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _e) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _f) } } }],
                }
            ]
        }
    }),
    INACTIVE_PAY_18: new PromoOffer({
        ID: 603,
        visualPresetId: "411",
        offerNameAlias: "promo_title_INACTIVE_PAY_18",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 2.68,
        discount: "-65%",
        activeTime: {
            duration: new Time({ Days: 2 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        idleTime: [new Time({ Days: 18 }).value, new Time({ Days: 25 }).value],
        regenerationDelay: new Time({ Days: 12 }).value,
        productGroup: 603,
        enablePopup: true,
        popupSettings: {
            popUpId: 9603,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest_shop.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { chests: [chests.Legendary_chest_shop.ID] } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_g = {}, _g[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(800) }], _g) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_h = {}, _h[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3000) }], _h) } } }],
                }
            ]
        }
    }),
    INACTIVE_PAY_25: new PromoOffer({
        ID: 604,
        visualPresetId: "cycle_currency",
        offerNameAlias: "promo_title_INACTIVE_PAY_25",
        triggers: [PROMO_TRIGGER_TYPE.LOGIN],
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 7,
        discount: "-85%",
        activeTime: {
            duration: new Time({ Days: 3 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 3 }
        },
        idleTime: [new Time({ Days: 25 }).value, new Time({ Days: 200 }).value],
        regenerationDelay: new Time({ Days: 7 }).value,
        productGroup: 604,
        enablePopup: true,
        popupSettings: {
            popUpId: 9604,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_LOGIN,
        },
        offerType: PROMO_OFFER_TYPE.DYNAMIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { chests: [chests.Mythic_chest_shop.ID] } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(1000) }], _j) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_k = {}, _k[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5000) }], _k) } } }],
                }
            ]
        }
    }),
}, true);
