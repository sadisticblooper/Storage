var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3;
extend(offers, {
    Monk_direct_sale: new PromoOffer({
        ID: 9001,
        visualPresetId: "1440_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Monk.ID],
        directSaleForHeroId: heroes.Monk.ID,
        sellHeroSettings: { heroId: heroes.Monk.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[heroes.Monk.ID] = heroes.Monk.ShardsNeeded, _a) }) } } }]
                },]
        },
    }),
    Liquidator_direct_sale: new PromoOffer({
        ID: 9002,
        visualPresetId: "1446_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Liquidator.ID],
        directSaleForHeroId: heroes.Liquidator.ID,
        sellHeroSettings: { heroId: heroes.Liquidator.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[heroes.Liquidator.ID] = heroes.Liquidator.ShardsNeeded, _b) }) } } }]
                },]
        },
    }),
    Ironclad_direct_sale: new PromoOffer({
        ID: 9003,
        visualPresetId: "1573_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Ironclad.ID],
        directSaleForHeroId: heroes.Ironclad.ID,
        sellHeroSettings: { heroId: heroes.Ironclad.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[heroes.Ironclad.ID] = heroes.Ironclad.ShardsNeeded, _c) }) } } }]
                },]
        },
    }),
    Fireguard_direct_sale: new PromoOffer({
        ID: 9004,
        visualPresetId: "5018_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Fireguard.ID],
        directSaleForHeroId: heroes.Fireguard.ID,
        sellHeroSettings: { heroId: heroes.Fireguard.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Fireguard.ID] = heroes.Fireguard.ShardsNeeded, _d) }) } } }]
                },]
        },
    }),
    Helga_direct_sale: new PromoOffer({
        ID: 9005,
        visualPresetId: "127_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Helga.ID],
        directSaleForHeroId: heroes.Helga.ID,
        sellHeroSettings: { heroId: heroes.Helga.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Helga.ID] = heroes.Helga.ShardsNeeded, _e) }) } } }]
                },]
        },
    }),
    Jet_direct_sale: new PromoOffer({
        ID: 9006,
        visualPresetId: "207_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Jet.ID],
        directSaleForHeroId: heroes.Jet.ID,
        sellHeroSettings: { heroId: heroes.Jet.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_f = {}, _f[heroes.Jet.ID] = heroes.Jet.ShardsNeeded, _f) }) } } }]
                },]
        },
    }),
    Midnight_direct_sale: new PromoOffer({
        ID: 9007,
        visualPresetId: "1356_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Midnight.ID],
        directSaleForHeroId: heroes.Midnight.ID,
        sellHeroSettings: { heroId: heroes.Midnight.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Midnight.ID] = heroes.Midnight.ShardsNeeded, _g) }) } } }]
                },]
        },
    }),
    Feldsher_direct_sale: new PromoOffer({
        ID: 9008,
        visualPresetId: "1524_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Feldsher.ID],
        directSaleForHeroId: heroes.Feldsher.ID,
        sellHeroSettings: { heroId: heroes.Feldsher.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_h = {}, _h[heroes.Feldsher.ID] = heroes.Feldsher.ShardsNeeded, _h) }) } } }]
                },]
        },
    }),
    Yukka_direct_sale: new PromoOffer({
        ID: 9009,
        visualPresetId: "5013_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Yukka.ID],
        directSaleForHeroId: heroes.Yukka.ID,
        sellHeroSettings: { heroId: heroes.Yukka.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_j = {}, _j[heroes.Yukka.ID] = heroes.Yukka.ShardsNeeded, _j) }) } } }]
                },]
        },
    }),
    Bulwark_direct_sale: new PromoOffer({
        ID: 9010,
        visualPresetId: "134_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Bulwark.ID],
        directSaleForHeroId: heroes.Bulwark.ID,
        sellHeroSettings: { heroId: heroes.Bulwark.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_k = {}, _k[heroes.Bulwark.ID] = heroes.Bulwark.ShardsNeeded, _k) }) } } }]
                },]
        },
    }),
    Emperor_direct_sale: new PromoOffer({
        ID: 9011,
        visualPresetId: "208_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Emperor.ID],
        directSaleForHeroId: heroes.Emperor.ID,
        sellHeroSettings: { heroId: heroes.Emperor.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_l = {}, _l[heroes.Emperor.ID] = heroes.Emperor.ShardsNeeded, _l) }) } } }]
                },]
        },
    }),
    Kibo_direct_sale: new PromoOffer({
        ID: 9012,
        visualPresetId: "1037_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Kibo.ID],
        directSaleForHeroId: heroes.Kibo.ID,
        sellHeroSettings: { heroId: heroes.Kibo.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_m = {}, _m[heroes.Kibo.ID] = heroes.Kibo.ShardsNeeded, _m) }) } } }]
                },]
        },
    }),
    Sarge_direct_sale: new PromoOffer({
        ID: 9014,
        visualPresetId: "5011_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Sarge.ID],
        directSaleForHeroId: heroes.Sarge.ID,
        sellHeroSettings: { heroId: heroes.Sarge.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_o = {}, _o[heroes.Sarge.ID] = heroes.Sarge.ShardsNeeded, _o) }) } } }]
                },]
        },
    }),
    HongJoo_direct_sale: new PromoOffer({
        ID: 9015,
        visualPresetId: "5019_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.HongJoo.ID],
        directSaleForHeroId: heroes.HongJoo.ID,
        sellHeroSettings: { heroId: heroes.HongJoo.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_p = {}, _p[heroes.HongJoo.ID] = heroes.HongJoo.ShardsNeeded, _p) }) } } }]
                },]
        },
    }),
    Lynx_direct_sale: new PromoOffer({
        ID: 9016,
        visualPresetId: "1336_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Lynx.ID],
        directSaleForHeroId: heroes.Lynx.ID,
        sellHeroSettings: { heroId: heroes.Lynx.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_q = {}, _q[heroes.Lynx.ID] = heroes.Lynx.ShardsNeeded, _q) }) } } }]
                },]
        },
    }),
    Monkey_King_direct_sale: new PromoOffer({
        ID: 9017,
        visualPresetId: "1359_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_30.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Monkey_King.ID],
        directSaleForHeroId: heroes.Monkey_King.ID,
        sellHeroSettings: { heroId: heroes.Monkey_King.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_r = {}, _r[heroes.Monkey_King.ID] = heroes.Monkey_King.ShardsNeeded, _r) }) } } }]
                },]
        },
    }),
    Viper_direct_sale: new PromoOffer({
        ID: 9018,
        visualPresetId: "1347_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Viper.ID],
        directSaleForHeroId: heroes.Viper.ID,
        sellHeroSettings: { heroId: heroes.Viper.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_s = {}, _s[heroes.Viper.ID] = heroes.Viper.ShardsNeeded, _s) }) } } }]
                },]
        },
    }),
    Legion_King_direct_sale: new PromoOffer({
        ID: 9019,
        visualPresetId: "1394_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_30.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Legion_King.ID],
        directSaleForHeroId: heroes.Legion_King.ID,
        sellHeroSettings: { heroId: heroes.Legion_King.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_t = {}, _t[heroes.Legion_King.ID] = heroes.Legion_King.ShardsNeeded, _t) }) } } }]
                },]
        },
    }),
    Butcher_direct_sale: new PromoOffer({
        ID: 9020,
        visualPresetId: "5120_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Butcher.ID],
        directSaleForHeroId: heroes.Butcher.ID,
        sellHeroSettings: { heroId: heroes.Butcher.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_u = {}, _u[heroes.Butcher.ID] = heroes.Butcher.ShardsNeeded, _u) }) } } }]
                },]
        },
    }),
    Itu_direct_sale: new PromoOffer({
        ID: 9021,
        visualPresetId: "5125_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_30.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Itu.ID],
        directSaleForHeroId: heroes.Itu.ID,
        sellHeroSettings: { heroId: heroes.Itu.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_v = {}, _v[heroes.Itu.ID] = heroes.Itu.ShardsNeeded, _v) }) } } }]
                },]
        },
    }),
    Yunlin_direct_sale: new PromoOffer({
        ID: 9022,
        visualPresetId: "5132_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_10.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Yunlin.ID],
        directSaleForHeroId: heroes.Yunlin.ID,
        sellHeroSettings: { heroId: heroes.Yunlin.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_w = {}, _w[heroes.Yunlin.ID] = heroes.Yunlin.ShardsNeeded, _w) }) } } }]
                },]
        },
    }),
    Xiang_Tzu_direct_sale: new PromoOffer({
        ID: 9023,
        visualPresetId: "5135_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Xiang_Tzu.ID],
        directSaleForHeroId: heroes.Xiang_Tzu.ID,
        sellHeroSettings: { heroId: heroes.Xiang_Tzu.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_x = {}, _x[heroes.Xiang_Tzu.ID] = heroes.Xiang_Tzu.ShardsNeeded, _x) }) } } }]
                },]
        },
    }),
    June_direct_sale: new PromoOffer({
        ID: 9024,
        visualPresetId: "june_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_30.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.June.ID],
        directSaleForHeroId: heroes.June.ID,
        sellHeroSettings: { heroId: heroes.June.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_y = {}, _y[heroes.June.ID] = heroes.June.ShardsNeeded, _y) }) } } }]
                },]
        },
    }),
    Marcus_direct_sale: new PromoOffer({
        ID: 9025,
        visualPresetId: "5135_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Marcus.ID],
        directSaleForHeroId: heroes.Marcus.ID,
        sellHeroSettings: { heroId: heroes.Marcus.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_z = {}, _z[heroes.Marcus.ID] = heroes.Marcus.ShardsNeeded, _z) }) } } }]
                },]
        },
    }),
    Gideon_direct_sale: new PromoOffer({
        ID: 9026,
        visualPresetId: "Gideon_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Gideon.ID],
        directSaleForHeroId: heroes.Gideon.ID,
        sellHeroSettings: { heroId: heroes.Gideon.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_0 = {}, _0[heroes.Gideon.ID] = heroes.Gideon.ShardsNeeded, _0) }) } } }]
                },]
        },
    }),
    Widow_direct_sale: new PromoOffer({
        ID: 9027,
        visualPresetId: "Widow_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Widow.ID],
        directSaleForHeroId: heroes.Widow.ID,
        sellHeroSettings: { heroId: heroes.Widow.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_1 = {}, _1[heroes.Widow.ID] = heroes.Widow.ShardsNeeded, _1) }) } } }]
                },]
        },
    }),
    Raikichi_direct_sale: new PromoOffer({
        ID: 9050,
        visualPresetId: "Raikichi_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_20.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Raikichi.ID],
        directSaleForHeroId: heroes.Raikichi.ID,
        sellHeroSettings: { heroId: heroes.Raikichi.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_2 = {}, _2[heroes.Raikichi.ID] = heroes.Raikichi.ShardsNeeded, _2) }) } } }]
                },]
        },
    }),
    Nonna_direct_sale: new PromoOffer({
        ID: 9051,
        visualPresetId: "Nonna_no_sale",
        offerNameAlias: "shop_offers_sale",
        inApp: inAppSettings.PRICE_30.ProductID,
        activeTime: { duration: PROMO_DURATION.ENDLESS },
        conditions: {},
        hiddenOffer: true,
        noHeroExist: [heroes.Nonna.ID],
        directSaleForHeroId: heroes.Nonna.ID,
        sellHeroSettings: { heroId: heroes.Nonna.ID, sortingWeight: -1, sellingPromoType: GAME_ENTITY.OFFER, },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [{
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_3 = {}, _3[heroes.Nonna.ID] = heroes.Nonna.ShardsNeeded, _3) }) } } }]
                },]
        },
    }),
}, true);
