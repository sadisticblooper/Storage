var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155;
extend(offers, {
    HERO_OFFER_Monk_Expensive: new PromoOffer({
        ID: 59501,
        visualPresetId: "offer_with_image_com_Monk",
        offerNameAlias: "Monk",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59001, 59002, 59003],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Monk.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59501,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_a = {}, _a[heroes.Monk.ID] = 35, _a) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Monk.ID] = 200, _b) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_c = {}, _c[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _c) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Monk_Cheap: new PromoOffer({
        ID: 59502,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Monk",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59001, 59002, 59003],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Monk.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59502,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Monk.ID] = 10, _d) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_e = {}, _e[heroes.Monk.ID] = 50, _e) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_f = {}, _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _f) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Liquidator_Expensive: new PromoOffer({
        ID: 59503,
        visualPresetId: "5004",
        offerNameAlias: "Liquidator",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59004, 59005, 59006],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Liquidator.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59503,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Liquidator.ID] = 35, _g) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_h = {}, _h[heroes.Liquidator.ID] = 200, _h) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_j = {}, _j[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _j) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Liquidator_Cheap: new PromoOffer({
        ID: 59504,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Liquidator",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59004, 59005, 59006],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Liquidator.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59504,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_k = {}, _k[heroes.Liquidator.ID] = 10, _k) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_l = {}, _l[heroes.Liquidator.ID] = 50, _l) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_m = {}, _m[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _m) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Ironclad_Expensive: new PromoOffer({
        ID: 59505,
        visualPresetId: "offer_with_image_com_Ironclad",
        offerNameAlias: "Ironclad",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59007, 59008, 59009],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Ironclad.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59505,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_o = {}, _o[heroes.Ironclad.ID] = 35, _o) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_p = {}, _p[heroes.Ironclad.ID] = 200, _p) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_q = {}, _q[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _q) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Ironclad_Cheap: new PromoOffer({
        ID: 59506,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Ironclad",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59007, 59008, 59009],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Ironclad.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59506,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_r = {}, _r[heroes.Ironclad.ID] = 10, _r) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_s = {}, _s[heroes.Ironclad.ID] = 50, _s) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_t = {}, _t[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _t) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Fireguard_Expensive: new PromoOffer({
        ID: 59507,
        visualPresetId: "offer_with_image_com_Fireguard",
        offerNameAlias: "Fireguard",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59010, 59011, 59012],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59507,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_u = {}, _u[heroes.Fireguard.ID] = 35, _u) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_v = {}, _v[heroes.Fireguard.ID] = 200, _v) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_w = {}, _w[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _w) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Fireguard_Cheap: new PromoOffer({
        ID: 59508,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Fireguard",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59010, 59011, 59012],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Fireguard.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59508,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_x = {}, _x[heroes.Fireguard.ID] = 10, _x) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_y = {}, _y[heroes.Fireguard.ID] = 50, _y) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_z = {}, _z[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _z) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Helga_Expensive: new PromoOffer({
        ID: 59509,
        visualPresetId: "offer_with_image_rare_Helga",
        offerNameAlias: "Helga",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59013, 59014, 59015],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Helga.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59509,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_0 = {}, _0[heroes.Helga.ID] = 20, _0) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_1 = {}, _1[heroes.Helga.ID] = 100, _1) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_2 = {}, _2[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _2) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Helga_Cheap: new PromoOffer({
        ID: 59510,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Helga",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59013, 59014, 59015],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Helga.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59510,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_3 = {}, _3[heroes.Helga.ID] = 10, _3) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_4 = {}, _4[heroes.Helga.ID] = 40, _4) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_5 = {}, _5[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _5) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Jet_Expensive: new PromoOffer({
        ID: 59511,
        visualPresetId: "offer_with_image_rare_Jet",
        offerNameAlias: "Jet",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59016, 59017, 59018],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Jet.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59511,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_6 = {}, _6[heroes.Jet.ID] = 20, _6) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_7 = {}, _7[heroes.Jet.ID] = 100, _7) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_8 = {}, _8[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _8) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Jet_Cheap: new PromoOffer({
        ID: 59512,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Jet",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59016, 59017, 59018],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Jet.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59512,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_9 = {}, _9[heroes.Jet.ID] = 10, _9) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_10 = {}, _10[heroes.Jet.ID] = 40, _10) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_11 = {}, _11[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _11) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Feldsher_Expensive: new PromoOffer({
        ID: 59513,
        visualPresetId: "offer_with_image_com_Feldsher",
        offerNameAlias: "Feldsher",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59019, 59020, 59021],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Feldsher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59513,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_12 = {}, _12[heroes.Feldsher.ID] = 35, _12) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_13 = {}, _13[heroes.Feldsher.ID] = 200, _13) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_14 = {}, _14[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _14) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Feldsher_Cheap: new PromoOffer({
        ID: 59514,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Feldsher",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59019, 59020, 59021],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Feldsher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59514,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_15 = {}, _15[heroes.Feldsher.ID] = 10, _15) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_16 = {}, _16[heroes.Feldsher.ID] = 50, _16) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_17 = {}, _17[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _17) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Yukka_Expensive: new PromoOffer({
        ID: 59515,
        visualPresetId: "5013",
        offerNameAlias: "Yukka",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59022, 59023, 59024],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Yukka.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59515,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_18 = {}, _18[heroes.Yukka.ID] = 20, _18) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_19 = {}, _19[heroes.Yukka.ID] = 100, _19) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_20 = {}, _20[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _20) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Yukka_Cheap: new PromoOffer({
        ID: 59516,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Yukka",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59022, 59023, 59024],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Yukka.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59516,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_21 = {}, _21[heroes.Yukka.ID] = 10, _21) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_22 = {}, _22[heroes.Yukka.ID] = 40, _22) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_23 = {}, _23[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _23) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Bulwark_Expensive: new PromoOffer({
        ID: 59517,
        visualPresetId: "offer_with_image_com_Bulwark",
        offerNameAlias: "Bulwark",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59025, 59026, 59027],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Bulwark.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59517,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_24 = {}, _24[heroes.Bulwark.ID] = 35, _24) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_25 = {}, _25[heroes.Bulwark.ID] = 200, _25) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_26 = {}, _26[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _26) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Bulwark_Cheap: new PromoOffer({
        ID: 59518,
        visualPresetId: "promo_cards_common",
        offerNameAlias: "Bulwark",
        inApp: inAppSettings.PRICE_5_broken.ProductID,
        profit: 1.4,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59025, 59026, 59027],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Bulwark.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59518,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_27 = {}, _27[heroes.Bulwark.ID] = 10, _27) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_28 = {}, _28[heroes.Bulwark.ID] = 50, _28) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_29 = {}, _29[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _29) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Emperor_Expensive: new PromoOffer({
        ID: 59519,
        visualPresetId: "5017",
        offerNameAlias: "Emperor",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59028, 59029, 59030],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Emperor.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59519,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_30 = {}, _30[heroes.Emperor.ID] = 15, _30) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_31 = {}, _31[heroes.Emperor.ID] = 50, _31) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_32 = {}, _32[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _32) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Emperor_Cheap: new PromoOffer({
        ID: 59520,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Emperor",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59028, 59029, 59030],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Emperor.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59520,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_33 = {}, _33[heroes.Emperor.ID] = 5, _33) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_34 = {}, _34[heroes.Emperor.ID] = 10, _34) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_35 = {}, _35[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _35) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Kibo_Expensive: new PromoOffer({
        ID: 59521,
        visualPresetId: "5012",
        offerNameAlias: "Kibo",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59031, 59032, 59033],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59521,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_36 = {}, _36[heroes.Kibo.ID] = 15, _36) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_37 = {}, _37[heroes.Kibo.ID] = 50, _37) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_38 = {}, _38[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _38) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Kibo_Cheap: new PromoOffer({
        ID: 59522,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Kibo",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59031, 59032, 59033],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Kibo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59522,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_39 = {}, _39[heroes.Kibo.ID] = 5, _39) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_40 = {}, _40[heroes.Kibo.ID] = 10, _40) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_41 = {}, _41[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _41) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Marcus_Expensive: new PromoOffer({
        ID: 59523,
        visualPresetId: "5005",
        offerNameAlias: "Marcus",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59034, 59035, 59036],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Marcus.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59523,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_42 = {}, _42[heroes.Marcus.ID] = 15, _42) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_43 = {}, _43[heroes.Marcus.ID] = 50, _43) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_44 = {}, _44[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _44) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Marcus_Cheap: new PromoOffer({
        ID: 59524,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Marcus",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59034, 59035, 59036],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Marcus.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59524,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_45 = {}, _45[heroes.Marcus.ID] = 5, _45) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_46 = {}, _46[heroes.Marcus.ID] = 10, _46) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_47 = {}, _47[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _47) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_HongJoo_Expensive: new PromoOffer({
        ID: 59525,
        visualPresetId: "offer_with_image_rare_HongJoo",
        offerNameAlias: "HongJoo",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59037, 59038, 59039],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.HongJoo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59525,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_48 = {}, _48[heroes.HongJoo.ID] = 20, _48) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_49 = {}, _49[heroes.HongJoo.ID] = 100, _49) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_50 = {}, _50[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _50) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_HongJoo_Cheap: new PromoOffer({
        ID: 59526,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "HongJoo",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59037, 59038, 59039],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.HongJoo.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59526,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_51 = {}, _51[heroes.HongJoo.ID] = 10, _51) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_52 = {}, _52[heroes.HongJoo.ID] = 40, _52) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_53 = {}, _53[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _53) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Midnight_Expensive: new PromoOffer({
        ID: 59527,
        visualPresetId: "5003",
        offerNameAlias: "Midnight",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59040, 59041, 59042],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Midnight.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59527,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_54 = {}, _54[heroes.Midnight.ID] = 15, _54) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_55 = {}, _55[heroes.Midnight.ID] = 50, _55) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_56 = {}, _56[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _56) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Midnight_Cheap: new PromoOffer({
        ID: 59528,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Midnight",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59040, 59041, 59042],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Midnight.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59528,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_57 = {}, _57[heroes.Midnight.ID] = 5, _57) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_58 = {}, _58[heroes.Midnight.ID] = 10, _58) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_59 = {}, _59[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _59) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Sarge_Expensive: new PromoOffer({
        ID: 59529,
        visualPresetId: "5011",
        offerNameAlias: "Sarge",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59043, 59044, 59045],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Sarge.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59529,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_60 = {}, _60[heroes.Sarge.ID] = 20, _60) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_61 = {}, _61[heroes.Sarge.ID] = 100, _61) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_62 = {}, _62[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _62) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Sarge_Cheap: new PromoOffer({
        ID: 59530,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Sarge",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59043, 59044, 59045],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Sarge.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59530,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_63 = {}, _63[heroes.Sarge.ID] = 10, _63) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_64 = {}, _64[heroes.Sarge.ID] = 40, _64) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_65 = {}, _65[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _65) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Lynx_Expensive: new PromoOffer({
        ID: 59531,
        visualPresetId: "5136",
        offerNameAlias: "Lynx",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59046, 59047, 59048],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59531,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_66 = {}, _66[heroes.Lynx.ID] = 15, _66) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_67 = {}, _67[heroes.Lynx.ID] = 50, _67) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_68 = {}, _68[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _68) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Lynx_Cheap: new PromoOffer({
        ID: 59532,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Lynx",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59046, 59047, 59048],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59532,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_69 = {}, _69[heroes.Lynx.ID] = 5, _69) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_70 = {}, _70[heroes.Lynx.ID] = 10, _70) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_71 = {}, _71[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _71) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Viper_Expensive: new PromoOffer({
        ID: 59533,
        visualPresetId: "offer_with_image_rare_Viper",
        offerNameAlias: "Viper",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59049, 59050, 59051],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Viper.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59533,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_72 = {}, _72[heroes.Viper.ID] = 20, _72) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_73 = {}, _73[heroes.Viper.ID] = 100, _73) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_74 = {}, _74[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _74) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Viper_Cheap: new PromoOffer({
        ID: 59534,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Viper",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59049, 59050, 59051],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Viper.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59534,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_75 = {}, _75[heroes.Viper.ID] = 10, _75) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_76 = {}, _76[heroes.Viper.ID] = 40, _76) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_77 = {}, _77[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _77) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Monkey_King_Expensive: new PromoOffer({
        ID: 59535,
        visualPresetId: "offer_with_image_leg_Monkey_King",
        offerNameAlias: "Monkey_King",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59052, 59053, 59054],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Monkey_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59535,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_78 = {}, _78[heroes.Monkey_King.ID] = 15, _78) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_79 = {}, _79[heroes.Monkey_King.ID] = 15, _79) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_80 = {}, _80[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _80) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Monkey_King_Cheap: new PromoOffer({
        ID: 59536,
        visualPresetId: "411",
        offerNameAlias: "Monkey_King",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59052, 59053, 59054],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Monkey_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59536,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_81 = {}, _81[heroes.Monkey_King.ID] = 5, _81) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_82 = {}, _82[heroes.Monkey_King.ID] = 5, _82) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_83 = {}, _83[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _83) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Legion_King_Expensive: new PromoOffer({
        ID: 59537,
        visualPresetId: "offer_with_image_leg_LK",
        offerNameAlias: "Legion_King",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59055, 59056, 59057],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59537,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_84 = {}, _84[heroes.Legion_King.ID] = 15, _84) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_85 = {}, _85[heroes.Legion_King.ID] = 15, _85) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_86 = {}, _86[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _86) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Legion_King_Cheap: new PromoOffer({
        ID: 59538,
        visualPresetId: "411",
        offerNameAlias: "Legion_King",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59055, 59056, 59057],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Legion_King.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59538,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_87 = {}, _87[heroes.Legion_King.ID] = 5, _87) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_88 = {}, _88[heroes.Legion_King.ID] = 5, _88) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_89 = {}, _89[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _89) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Butcher_Expensive: new PromoOffer({
        ID: 59539,
        visualPresetId: "5120",
        offerNameAlias: "Butcher",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59058, 59059, 59060],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59539,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_90 = {}, _90[heroes.Butcher.ID] = 15, _90) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_91 = {}, _91[heroes.Butcher.ID] = 50, _91) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_92 = {}, _92[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _92) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Butcher_Cheap: new PromoOffer({
        ID: 59540,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Butcher",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59058, 59059, 59060],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Butcher.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59540,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_93 = {}, _93[heroes.Butcher.ID] = 5, _93) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_94 = {}, _94[heroes.Butcher.ID] = 10, _94) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_95 = {}, _95[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _95) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Itu_Expensive: new PromoOffer({
        ID: 59541,
        visualPresetId: "5125",
        offerNameAlias: "Itu",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59061, 59062, 59063],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59541,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_96 = {}, _96[heroes.Itu.ID] = 15, _96) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_97 = {}, _97[heroes.Itu.ID] = 15, _97) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_98 = {}, _98[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _98) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Itu_Cheap: new PromoOffer({
        ID: 59542,
        visualPresetId: "411",
        offerNameAlias: "Itu",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59061, 59062, 59063],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Itu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59542,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_99 = {}, _99[heroes.Itu.ID] = 5, _99) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_100 = {}, _100[heroes.Itu.ID] = 5, _100) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_101 = {}, _101[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _101) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Yunlin_Expensive: new PromoOffer({
        ID: 59543,
        visualPresetId: "5132",
        offerNameAlias: "Yunlin",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59064, 59065, 59066],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Yunlin.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59543,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_102 = {}, _102[heroes.Yunlin.ID] = 20, _102) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_103 = {}, _103[heroes.Yunlin.ID] = 100, _103) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_104 = {}, _104[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _104) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Yunlin_Cheap: new PromoOffer({
        ID: 59544,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Yunlin",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59064, 59065, 59066],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Yunlin.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59544,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_105 = {}, _105[heroes.Yunlin.ID] = 10, _105) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_106 = {}, _106[heroes.Yunlin.ID] = 40, _106) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_107 = {}, _107[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _107) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Xiang_Tzu_Expensive: new PromoOffer({
        ID: 59545,
        visualPresetId: "5135",
        offerNameAlias: "Xiang_Tzu",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59067, 59068, 59069],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Xiang_Tzu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59545,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_108 = {}, _108[heroes.Xiang_Tzu.ID] = 15, _108) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_109 = {}, _109[heroes.Xiang_Tzu.ID] = 50, _109) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_110 = {}, _110[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _110) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Xiang_Tzu_Cheap: new PromoOffer({
        ID: 59546,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Xiang_Tzu",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59067, 59068, 59069],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Xiang_Tzu.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59546,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_111 = {}, _111[heroes.Xiang_Tzu.ID] = 5, _111) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_112 = {}, _112[heroes.Xiang_Tzu.ID] = 10, _112) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_113 = {}, _113[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _113) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_June_Expensive: new PromoOffer({
        ID: 59547,
        visualPresetId: "offer_with_image_leg_June",
        offerNameAlias: "June",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59070, 59071, 59072],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59547,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_114 = {}, _114[heroes.June.ID] = 15, _114) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_115 = {}, _115[heroes.June.ID] = 15, _115) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_116 = {}, _116[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _116) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_June_Cheap: new PromoOffer({
        ID: 59548,
        visualPresetId: "411",
        offerNameAlias: "June",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59070, 59071, 59072],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.June.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59548,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_117 = {}, _117[heroes.June.ID] = 5, _117) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_118 = {}, _118[heroes.June.ID] = 5, _118) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_119 = {}, _119[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _119) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Ling_Expensive: new PromoOffer({
        ID: 59549,
        visualPresetId: "offer_with_image_rare_Ling",
        offerNameAlias: "Ling",
        inApp: inAppSettings.PRICE_13.ProductID,
        profit: 2.4,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59073, 59074, 59075],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Ling.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59549,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_120 = {}, _120[heroes.Ling.ID] = 20, _120) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_121 = {}, _121[heroes.Ling.ID] = 100, _121) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_122 = {}, _122[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _122) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Ling_Cheap: new PromoOffer({
        ID: 59550,
        visualPresetId: "cycle_weekly_rare",
        offerNameAlias: "Ling",
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59073, 59074, 59075],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Ling.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59550,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_123 = {}, _123[heroes.Ling.ID] = 10, _123) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_124 = {}, _124[heroes.Ling.ID] = 40, _124) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_125 = {}, _125[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _125) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Gideon_Expensive: new PromoOffer({
        ID: 59551,
        visualPresetId: "5137",
        offerNameAlias: "Gideon",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59076, 59077, 59078],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Gideon.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59551,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_126 = {}, _126[heroes.Gideon.ID] = 15, _126) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_127 = {}, _127[heroes.Gideon.ID] = 50, _127) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_128 = {}, _128[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _128) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Gideon_Cheap: new PromoOffer({
        ID: 59552,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Gideon",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59076, 59077, 59078],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Gideon.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59552,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_129 = {}, _129[heroes.Gideon.ID] = 5, _129) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_130 = {}, _130[heroes.Gideon.ID] = 10, _130) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_131 = {}, _131[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _131) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Widow_Expensive: new PromoOffer({
        ID: 59553,
        visualPresetId: "5138",
        offerNameAlias: "Widow",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59079, 59080, 59081],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Widow.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59553,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_132 = {}, _132[heroes.Widow.ID] = 15, _132) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_133 = {}, _133[heroes.Widow.ID] = 50, _133) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_134 = {}, _134[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _134) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Widow_Cheap: new PromoOffer({
        ID: 59554,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Widow",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59079, 59080, 59081],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Widow.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59554,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_135 = {}, _135[heroes.Widow.ID] = 5, _135) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_136 = {}, _136[heroes.Widow.ID] = 10, _136) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_137 = {}, _137[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _137) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Raikichi_Expensive: new PromoOffer({
        ID: 59555,
        visualPresetId: "5139",
        offerNameAlias: "Raikichi",
        inApp: inAppSettings.PRICE_20.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59082, 59083, 59084],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Raikichi.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59555,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_138 = {}, _138[heroes.Raikichi.ID] = 15, _138) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_139 = {}, _139[heroes.Raikichi.ID] = 50, _139) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_140 = {}, _140[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _140) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Raikichi_Cheap: new PromoOffer({
        ID: 59556,
        visualPresetId: "cycle_weekly_epic",
        offerNameAlias: "Raikichi",
        inApp: inAppSettings.PRICE_10.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59082, 59083, 59084],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Raikichi.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59556,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_141 = {}, _141[heroes.Raikichi.ID] = 5, _141) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_142 = {}, _142[heroes.Raikichi.ID] = 10, _142) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_143 = {}, _143[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _143) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Nonna_Expensive: new PromoOffer({
        ID: 59557,
        visualPresetId: "offer_with_image_leg_Nonna",
        offerNameAlias: "Nonna",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59085, 59086, 59087],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Nonna.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59557,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_144 = {}, _144[heroes.Nonna.ID] = 15, _144) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_145 = {}, _145[heroes.Nonna.ID] = 15, _145) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_146 = {}, _146[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _146) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Nonna_Cheap: new PromoOffer({
        ID: 59558,
        visualPresetId: "411",
        offerNameAlias: "Nonna",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59085, 59086, 59087],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Nonna.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59558,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_147 = {}, _147[heroes.Nonna.ID] = 5, _147) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_148 = {}, _148[heroes.Nonna.ID] = 5, _148) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_149 = {}, _149[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _149) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Shogun_Expensive: new PromoOffer({
        ID: 59559,
        visualPresetId: "offer_with_image_leg_Shogun",
        offerNameAlias: "Shogun",
        inApp: inAppSettings.PRICE_25.ProductID,
        profit: 2.5,
        discount: "-60%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59088, 59089, 59090],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Shogun.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59559,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_150 = {}, _150[heroes.Shogun.ID] = 15, _150) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_151 = {}, _151[heroes.Shogun.ID] = 15, _151) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_152 = {}, _152[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4000) }], _152) } } }]
                },
            ]
        },
    }),
    HERO_OFFER_Shogun_Cheap: new PromoOffer({
        ID: 59560,
        visualPresetId: "411",
        offerNameAlias: "Shogun",
        inApp: inAppSettings.PRICE_15.ProductID,
        profit: 1.5,
        discount: "-30%",
        activeTime: {
            duration: new Time({ Days: 1 }).value
        },
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        marathonProgress: {
            marathonIds: [59088, 59089, 59090],
            progress: { more_or_equal: 110 }
        },
        sellHeroSettings: {
            heroId: heroes.Shogun.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        enablePopup: true,
        popupSettings: {
            popUpId: 59560,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        offerType: PROMO_OFFER_TYPE.STATIC,
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_153 = {}, _153[heroes.Shogun.ID] = 5, _153) }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_154 = {}, _154[heroes.Shogun.ID] = 5, _154) }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { CurrencySlots: (_155 = {}, _155[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2000) }], _155) } } }]
                },
            ]
        },
    }),
}, true);
