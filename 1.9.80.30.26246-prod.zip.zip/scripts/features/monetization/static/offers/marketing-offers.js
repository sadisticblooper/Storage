var _a, _b, _c, _d;
extend(offers, {
    Marketing_Legendary_Lynx: new PromoOffer({
        ID: 33296,
        visualPresetId: "leg_lynx_big",
        offerNameAlias: "promo_title_demon_offer",
        companies: ["GA_SFA_AP_Andr_WW_Retarget_skin_040724", "GA_SFA_AP_Andr_WW_Retarget_skin_110724"],
        activeTime: { duration: new Time({ Days: 14 }).value },
        productGroup: 33135,
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        sellHeroSettings: {
            heroId: heroes.Lynx.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        noCustomizeExist: (_a = {},
            _a[CUSTOMIZATION.SKIN] = [1705],
            _a),
        profit: 1.7,
        discount: "-40%",
        sp: { min: 0.00, max: 999999 },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 33296,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Lynx_L_Hood.ID] }) } } }],
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Weapons: [heroWeapons.wpn_Lynx_E_Hood.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[heroes.Lynx.ID] = 10, _b) }) } } }]
                },
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Emoji: [emoji.Lynx_Disappearance.ID] }) } } }],
                    back: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Stances: [stances.stance_Lynx_E_shadow.ID] }) } } }],
                }
            ]
        },
        inApp: inAppSettings.PRICE_50.ProductID,
    }),
    Marketing_Gideon: new PromoOffer({
        visualPresetId: "promo_gideon",
        ID: 4941,
        offerNameAlias: "promo_offer_gideon",
        productGroup: 4941,
        onceRepeatAfter: new Date("2024-08-15").getTime(),
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        noActiveOffersNow: [33570, 33571, 33572, 33573],
        noHeroExist: [heroes.Gideon.ID],
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 4941,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        sellHeroSettings: {
            heroId: heroes.Gideon.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[heroes.Gideon.ID] = 10, _c) }) } } }],
                },
            ]
        },
        rules: [OFFERS_RULES_GENERATE.UNLOCK_HEROES],
        inApp: inAppSettings.PRICE_8.ProductID,
        profit: 2.5,
        companies: ["GA_SFA_AP_Andr_WW_Retarget_Gideon_140824"],
        activeTime: {
            startGenerationBound: new Date('2024-08-18').getTime(),
            duration: new Time({ Days: 14 }).value
        },
        discount: "-60%",
    }),
    Marketing_Widow: new PromoOffer({
        ID: 4942,
        visualPresetId: "promo_widow",
        offerNameAlias: "promo_offer_widow",
        companies: ["GA_SFA_AP_Andr_WW_Retarget_Widow_201124"],
        activeTime: {
            startGenerationBound: new Date('2024-12-09').getTime(),
            duration: new Time({ Days: 14 }).value
        },
        onceRepeatAfter: new Date("2024-12-09").getTime(),
        productGroup: 4942,
        conditions: {
            accountLevel: { more_or_equal: 2 },
        },
        noHeroExist: [heroes.Widow.ID],
        sellHeroSettings: {
            heroId: heroes.Widow.ID,
            sortingWeight: 1,
            sellingPromoType: GAME_ENTITY.OFFER,
        },
        profit: 2.5,
        discount: "-60%",
        sp: { min: 0.00, max: 999999 },
        offerType: PROMO_OFFER_TYPE.STATIC,
        enablePopup: true,
        triggers: [PROMO_TRIGGER_TYPE.COMBINE_HERO, PROMO_TRIGGER_TYPE.LOGIN, PROMO_TRIGGER_TYPE.REWARD, PROMO_TRIGGER_TYPE.SERIAL, PROMO_TRIGGER_TYPE.SEASON_END, PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP, PROMO_TRIGGER_TYPE.ARENA_CHANGE, PROMO_TRIGGER_TYPE.TUTORIAL_PASS, PROMO_TRIGGER_TYPE.HERO_LEVEL_UP],
        popupSettings: {
            popUpId: 4942,
            popUpTrigger: PROMO_OFFER_POP_UP_TRIGGER.ON_ENTER_LOBBY,
        },
        lootSettings: {
            additionalPlaceHolder: [
                {
                    front: [{ weight: 1, item: { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Widow.ID] = 10, _d) }) } } }],
                },
            ]
        },
        inApp: inAppSettings.PRICE_8.ProductID,
    }),
}, true);
