var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155, _156, _157, _158, _159, _160, _161, _162, _163, _164, _165, _166, _167, _168, _169, _170, _171, _172, _173, _174, _175, _176, _177, _178, _179, _180, _181, _182, _183, _184, _185, _186, _187, _188, _189, _190, _191, _192, _193, _194, _195, _196, _197, _198, _199, _200;
extend(Marathons, {
    ShardMarathon_Ling: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_a = {}, _a[heroes.Ling.ID] = { Level: { less_or_equal: 3 } }, _a),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50017,
        Alias: "talent_marathone_ling",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Ling.ID] = 2, _b) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_c = {}, _c[heroes.Ling.ID] = 2, _c) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[heroes.Ling.ID] = 5, _d) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Ling.ID] = 3, _e) }) } },
            320: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 500, _f) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Ling.ID] = 5, _g) }) } },
            600: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 50, _h) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_j = {}, _j[heroes.Ling.ID] = 5, _j) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ling.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_1 = roundsStats; _i < roundsStats_1.length; _i++) {
                    var round = roundsStats_1[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Monk: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_k = {}, _k[heroes.Monk.ID] = { Level: { less_or_equal: 3 } }, _k),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50018,
        Alias: "talent_marathone_monk",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MonkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_l = {}, _l[heroes.Monk.ID] = 2, _l) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_m = {}, _m[heroes.Monk.ID] = 5, _m) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_o = {}, _o[heroes.Monk.ID] = 5, _o) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_p = {}, _p[heroes.Monk.ID] = 5, _p) }) } },
            320: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 250, _q) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_r = {}, _r[heroes.Monk.ID] = 10, _r) }) } },
            600: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.BONUS] = 50, _s) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_t = {}, _t[heroes.Monk.ID] = 10, _t) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monk.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_2 = roundsStats; _i < roundsStats_2.length; _i++) {
                    var round = roundsStats_2[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Liquidator: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_u = {}, _u[heroes.Liquidator.ID] = { Level: { less_or_equal: 3 } }, _u),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50019,
        Alias: "talent_marathone_kate",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LiquidatorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_v = {}, _v[heroes.Liquidator.ID] = 2, _v) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_w = {}, _w[heroes.Liquidator.ID] = 5, _w) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_x = {}, _x[heroes.Liquidator.ID] = 5, _x) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_y = {}, _y[heroes.Liquidator.ID] = 5, _y) }) } },
            320: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.COIN] = 250, _z) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_0 = {}, _0[heroes.Liquidator.ID] = 10, _0) }) } },
            600: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.BONUS] = 50, _1) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_2 = {}, _2[heroes.Liquidator.ID] = 10, _2) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Liquidator.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_3 = roundsStats; _i < roundsStats_3.length; _i++) {
                    var round = roundsStats_3[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Ironclad: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_3 = {}, _3[heroes.Ironclad.ID] = { Level: { less_or_equal: 3 } }, _3),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50020,
        Alias: "talent_marathone_ironclad",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.IroncladSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_4 = {}, _4[heroes.Ironclad.ID] = 2, _4) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_5 = {}, _5[heroes.Ironclad.ID] = 5, _5) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_6 = {}, _6[heroes.Ironclad.ID] = 5, _6) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_7 = {}, _7[heroes.Ironclad.ID] = 5, _7) }) } },
            320: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.COIN] = 250, _8) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_9 = {}, _9[heroes.Ironclad.ID] = 10, _9) }) } },
            600: { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.BONUS] = 50, _10) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_11 = {}, _11[heroes.Ironclad.ID] = 10, _11) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ironclad.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_4 = roundsStats; _i < roundsStats_4.length; _i++) {
                    var round = roundsStats_4[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Fireguard: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_12 = {}, _12[heroes.Fireguard.ID] = { Level: { less_or_equal: 3 } }, _12),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50021,
        Alias: "talent_marathone_fireguard",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FireguardSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_13 = {}, _13[heroes.Fireguard.ID] = 2, _13) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_14 = {}, _14[heroes.Fireguard.ID] = 5, _14) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_15 = {}, _15[heroes.Fireguard.ID] = 5, _15) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_16 = {}, _16[heroes.Fireguard.ID] = 5, _16) }) } },
            320: { loot: new Loot({ Currencies: (_17 = {}, _17[CURRENCY.COIN] = 250, _17) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_18 = {}, _18[heroes.Fireguard.ID] = 10, _18) }) } },
            600: { loot: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.BONUS] = 50, _19) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_20 = {}, _20[heroes.Fireguard.ID] = 10, _20) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Fireguard.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_5 = roundsStats; _i < roundsStats_5.length; _i++) {
                    var round = roundsStats_5[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Helga: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_21 = {}, _21[heroes.Helga.ID] = { Level: { less_or_equal: 3 } }, _21),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50022,
        Alias: "talent_marathone_helga",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HelgaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_22 = {}, _22[heroes.Helga.ID] = 2, _22) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_23 = {}, _23[heroes.Helga.ID] = 2, _23) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_24 = {}, _24[heroes.Helga.ID] = 5, _24) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_25 = {}, _25[heroes.Helga.ID] = 3, _25) }) } },
            320: { loot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.COIN] = 500, _26) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_27 = {}, _27[heroes.Helga.ID] = 5, _27) }) } },
            600: { loot: new Loot({ Currencies: (_28 = {}, _28[CURRENCY.BONUS] = 50, _28) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_29 = {}, _29[heroes.Helga.ID] = 5, _29) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Helga.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_6 = roundsStats; _i < roundsStats_6.length; _i++) {
                    var round = roundsStats_6[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Jet: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_30 = {}, _30[heroes.Jet.ID] = { Level: { less_or_equal: 3 } }, _30),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50023,
        Alias: "talent_marathone_jet",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JetSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_31 = {}, _31[heroes.Jet.ID] = 2, _31) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_32 = {}, _32[heroes.Jet.ID] = 2, _32) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_33 = {}, _33[heroes.Jet.ID] = 5, _33) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_34 = {}, _34[heroes.Jet.ID] = 3, _34) }) } },
            320: { loot: new Loot({ Currencies: (_35 = {}, _35[CURRENCY.COIN] = 500, _35) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_36 = {}, _36[heroes.Jet.ID] = 5, _36) }) } },
            600: { loot: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.BONUS] = 50, _37) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_38 = {}, _38[heroes.Jet.ID] = 5, _38) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Jet.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_7 = roundsStats; _i < roundsStats_7.length; _i++) {
                    var round = roundsStats_7[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Feldsher: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_39 = {}, _39[heroes.Feldsher.ID] = { Level: { less_or_equal: 3 } }, _39),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50024,
        Alias: "talent_marathone_feldsher",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FeldsherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_40 = {}, _40[heroes.Feldsher.ID] = 2, _40) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_41 = {}, _41[heroes.Feldsher.ID] = 5, _41) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_42 = {}, _42[heroes.Feldsher.ID] = 5, _42) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_43 = {}, _43[heroes.Feldsher.ID] = 5, _43) }) } },
            320: { loot: new Loot({ Currencies: (_44 = {}, _44[CURRENCY.COIN] = 250, _44) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_45 = {}, _45[heroes.Feldsher.ID] = 10, _45) }) } },
            600: { loot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.BONUS] = 50, _46) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_47 = {}, _47[heroes.Feldsher.ID] = 10, _47) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Feldsher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_8 = roundsStats; _i < roundsStats_8.length; _i++) {
                    var round = roundsStats_8[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Yukka: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_48 = {}, _48[heroes.Yukka.ID] = { Level: { less_or_equal: 3 } }, _48),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50025,
        Alias: "talent_marathone_yukka",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YukkaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_49 = {}, _49[heroes.Yukka.ID] = 2, _49) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_50 = {}, _50[heroes.Yukka.ID] = 2, _50) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_51 = {}, _51[heroes.Yukka.ID] = 5, _51) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_52 = {}, _52[heroes.Yukka.ID] = 3, _52) }) } },
            320: { loot: new Loot({ Currencies: (_53 = {}, _53[CURRENCY.COIN] = 500, _53) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_54 = {}, _54[heroes.Yukka.ID] = 5, _54) }) } },
            600: { loot: new Loot({ Currencies: (_55 = {}, _55[CURRENCY.BONUS] = 50, _55) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_56 = {}, _56[heroes.Yukka.ID] = 5, _56) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yukka.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_9 = roundsStats; _i < roundsStats_9.length; _i++) {
                    var round = roundsStats_9[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Bulwark: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_57 = {}, _57[heroes.Bulwark.ID] = { Level: { less_or_equal: 3 } }, _57),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50026,
        Alias: "talent_marathone_bulwark",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.BulwarkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_58 = {}, _58[heroes.Bulwark.ID] = 2, _58) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_59 = {}, _59[heroes.Bulwark.ID] = 5, _59) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_60 = {}, _60[heroes.Bulwark.ID] = 5, _60) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_61 = {}, _61[heroes.Bulwark.ID] = 5, _61) }) } },
            320: { loot: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.COIN] = 500, _62) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_63 = {}, _63[heroes.Bulwark.ID] = 10, _63) }) } },
            600: { loot: new Loot({ Currencies: (_64 = {}, _64[CURRENCY.BONUS] = 50, _64) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_65 = {}, _65[heroes.Bulwark.ID] = 10, _65) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Bulwark.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_10 = roundsStats; _i < roundsStats_10.length; _i++) {
                    var round = roundsStats_10[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Emperor: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_66 = {}, _66[heroes.Emperor.ID] = { Level: { less_or_equal: 3 } }, _66),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50027,
        Alias: "talent_marathone_emperor",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.EmperorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_67 = {}, _67[heroes.Emperor.ID] = 2, _67) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_68 = {}, _68[heroes.Emperor.ID] = 2, _68) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_69 = {}, _69[heroes.Emperor.ID] = 5, _69) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_70 = {}, _70[heroes.Emperor.ID] = 3, _70) }) } },
            320: { loot: new Loot({ Currencies: (_71 = {}, _71[CURRENCY.COIN] = 1500, _71) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_72 = {}, _72[heroes.Emperor.ID] = 5, _72) }) } },
            600: { loot: new Loot({ Currencies: (_73 = {}, _73[CURRENCY.BONUS] = 50, _73) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_74 = {}, _74[heroes.Emperor.ID] = 5, _74) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Emperor.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_11 = roundsStats; _i < roundsStats_11.length; _i++) {
                    var round = roundsStats_11[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Kibo: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_75 = {}, _75[heroes.Kibo.ID] = { Level: { less_or_equal: 3 } }, _75),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50028,
        Alias: "talent_marathone_kibo",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.KiboSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_76 = {}, _76[heroes.Kibo.ID] = 2, _76) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_77 = {}, _77[heroes.Kibo.ID] = 2, _77) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_78 = {}, _78[heroes.Kibo.ID] = 5, _78) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_79 = {}, _79[heroes.Kibo.ID] = 3, _79) }) } },
            320: { loot: new Loot({ Currencies: (_80 = {}, _80[CURRENCY.COIN] = 1500, _80) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_81 = {}, _81[heroes.Kibo.ID] = 5, _81) }) } },
            600: { loot: new Loot({ Currencies: (_82 = {}, _82[CURRENCY.BONUS] = 50, _82) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_83 = {}, _83[heroes.Kibo.ID] = 5, _83) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Kibo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_12 = roundsStats; _i < roundsStats_12.length; _i++) {
                    var round = roundsStats_12[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Marcus: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_84 = {}, _84[heroes.Marcus.ID] = { Level: { less_or_equal: 3 } }, _84),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50029,
        Alias: "talent_marathone_marcus",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MarcusSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_85 = {}, _85[heroes.Marcus.ID] = 2, _85) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_86 = {}, _86[heroes.Marcus.ID] = 2, _86) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_87 = {}, _87[heroes.Marcus.ID] = 5, _87) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_88 = {}, _88[heroes.Marcus.ID] = 3, _88) }) } },
            320: { loot: new Loot({ Currencies: (_89 = {}, _89[CURRENCY.COIN] = 1500, _89) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_90 = {}, _90[heroes.Marcus.ID] = 5, _90) }) } },
            600: { loot: new Loot({ Currencies: (_91 = {}, _91[CURRENCY.BONUS] = 50, _91) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_92 = {}, _92[heroes.Marcus.ID] = 5, _92) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Marcus.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_13 = roundsStats; _i < roundsStats_13.length; _i++) {
                    var round = roundsStats_13[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_HongJoo: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_93 = {}, _93[heroes.HongJoo.ID] = { Level: { less_or_equal: 3 } }, _93),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50030,
        Alias: "talent_marathone_hongjoo",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HongJooSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_94 = {}, _94[heroes.HongJoo.ID] = 2, _94) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_95 = {}, _95[heroes.HongJoo.ID] = 2, _95) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_96 = {}, _96[heroes.HongJoo.ID] = 5, _96) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_97 = {}, _97[heroes.HongJoo.ID] = 3, _97) }) } },
            320: { loot: new Loot({ Currencies: (_98 = {}, _98[CURRENCY.COIN] = 500, _98) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_99 = {}, _99[heroes.HongJoo.ID] = 5, _99) }) } },
            600: { loot: new Loot({ Currencies: (_100 = {}, _100[CURRENCY.BONUS] = 50, _100) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_101 = {}, _101[heroes.HongJoo.ID] = 5, _101) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.HongJoo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_14 = roundsStats; _i < roundsStats_14.length; _i++) {
                    var round = roundsStats_14[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Midnight: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_102 = {}, _102[heroes.Midnight.ID] = { Level: { less_or_equal: 3 } }, _102),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50031,
        Alias: "talent_marathone_midnight",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MidnightSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_103 = {}, _103[heroes.Midnight.ID] = 2, _103) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_104 = {}, _104[heroes.Midnight.ID] = 2, _104) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_105 = {}, _105[heroes.Midnight.ID] = 5, _105) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_106 = {}, _106[heroes.Midnight.ID] = 3, _106) }) } },
            320: { loot: new Loot({ Currencies: (_107 = {}, _107[CURRENCY.COIN] = 1500, _107) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_108 = {}, _108[heroes.Midnight.ID] = 5, _108) }) } },
            600: { loot: new Loot({ Currencies: (_109 = {}, _109[CURRENCY.BONUS] = 50, _109) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_110 = {}, _110[heroes.Midnight.ID] = 5, _110) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Midnight.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_15 = roundsStats; _i < roundsStats_15.length; _i++) {
                    var round = roundsStats_15[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Sarge: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_111 = {}, _111[heroes.Sarge.ID] = { Level: { less_or_equal: 3 } }, _111),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50032,
        Alias: "talent_marathone_sarge",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.SargeSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_112 = {}, _112[heroes.Sarge.ID] = 2, _112) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_113 = {}, _113[heroes.Sarge.ID] = 2, _113) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_114 = {}, _114[heroes.Sarge.ID] = 5, _114) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_115 = {}, _115[heroes.Sarge.ID] = 3, _115) }) } },
            320: { loot: new Loot({ Currencies: (_116 = {}, _116[CURRENCY.COIN] = 500, _116) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_117 = {}, _117[heroes.Sarge.ID] = 5, _117) }) } },
            600: { loot: new Loot({ Currencies: (_118 = {}, _118[CURRENCY.BONUS] = 50, _118) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_119 = {}, _119[heroes.Sarge.ID] = 5, _119) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Sarge.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_16 = roundsStats; _i < roundsStats_16.length; _i++) {
                    var round = roundsStats_16[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Lynx: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_120 = {}, _120[heroes.Lynx.ID] = { Level: { less_or_equal: 3 } }, _120),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50033,
        Alias: "talent_marathone_lynx",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LynxSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_121 = {}, _121[heroes.Lynx.ID] = 2, _121) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_122 = {}, _122[heroes.Lynx.ID] = 2, _122) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_123 = {}, _123[heroes.Lynx.ID] = 5, _123) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_124 = {}, _124[heroes.Lynx.ID] = 3, _124) }) } },
            320: { loot: new Loot({ Currencies: (_125 = {}, _125[CURRENCY.COIN] = 1500, _125) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_126 = {}, _126[heroes.Lynx.ID] = 5, _126) }) } },
            600: { loot: new Loot({ Currencies: (_127 = {}, _127[CURRENCY.BONUS] = 50, _127) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_128 = {}, _128[heroes.Lynx.ID] = 5, _128) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Lynx.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_17 = roundsStats; _i < roundsStats_17.length; _i++) {
                    var round = roundsStats_17[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Viper: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_129 = {}, _129[heroes.Viper.ID] = { Level: { less_or_equal: 3 } }, _129),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50034,
        Alias: "talent_marathone_cobra",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ViperSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_130 = {}, _130[heroes.Viper.ID] = 2, _130) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_131 = {}, _131[heroes.Viper.ID] = 2, _131) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_132 = {}, _132[heroes.Viper.ID] = 5, _132) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_133 = {}, _133[heroes.Viper.ID] = 3, _133) }) } },
            320: { loot: new Loot({ Currencies: (_134 = {}, _134[CURRENCY.COIN] = 500, _134) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_135 = {}, _135[heroes.Viper.ID] = 5, _135) }) } },
            600: { loot: new Loot({ Currencies: (_136 = {}, _136[CURRENCY.BONUS] = 50, _136) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_137 = {}, _137[heroes.Viper.ID] = 5, _137) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Viper.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_18 = roundsStats; _i < roundsStats_18.length; _i++) {
                    var round = roundsStats_18[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Monkey_King: new Marathon({
        PromoSettings: {
            conditions: {
                heroes: (_138 = {}, _138[heroes.Monkey_King.ID] = { Level: { less_or_equal: heroes.Monkey_King.StartLevel } }, _138),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50035,
        Alias: "talent_marathone_monkeyking",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Monkey_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_139 = {}, _139[heroes.Monkey_King.ID] = 2, _139) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_140 = {}, _140[heroes.Monkey_King.ID] = 2, _140) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_141 = {}, _141[heroes.Monkey_King.ID] = 5, _141) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_142 = {}, _142[heroes.Monkey_King.ID] = 3, _142) }) } },
            320: { loot: new Loot({ Currencies: (_143 = {}, _143[CURRENCY.COIN] = 2500, _143) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_144 = {}, _144[heroes.Monkey_King.ID] = 5, _144) }) } },
            600: { loot: new Loot({ Currencies: (_145 = {}, _145[CURRENCY.BONUS] = 50, _145) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_146 = {}, _146[heroes.Monkey_King.ID] = 5, _146) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monkey_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_19 = roundsStats; _i < roundsStats_19.length; _i++) {
                    var round = roundsStats_19[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Legion_King: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_147 = {}, _147[heroes.Legion_King.ID] = { Level: { less_or_equal: 4 } }, _147),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50036,
        Alias: "talent_marathone_legionking",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Legion_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_148 = {}, _148[heroes.Legion_King.ID] = 2, _148) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_149 = {}, _149[heroes.Legion_King.ID] = 2, _149) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_150 = {}, _150[heroes.Legion_King.ID] = 5, _150) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_151 = {}, _151[heroes.Legion_King.ID] = 3, _151) }) } },
            320: { loot: new Loot({ Currencies: (_152 = {}, _152[CURRENCY.COIN] = 2500, _152) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_153 = {}, _153[heroes.Legion_King.ID] = 5, _153) }) } },
            600: { loot: new Loot({ Currencies: (_154 = {}, _154[CURRENCY.BONUS] = 50, _154) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_155 = {}, _155[heroes.Legion_King.ID] = 5, _155) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Legion_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_20 = roundsStats; _i < roundsStats_20.length; _i++) {
                    var round = roundsStats_20[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Butcher: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_156 = {}, _156[heroes.Butcher.ID] = { Level: { more_or_equal: heroes.Butcher.StartLevel } }, _156),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50037,
        Alias: "talent_marathone_butcher",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ButcherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_157 = {}, _157[heroes.Butcher.ID] = 2, _157) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_158 = {}, _158[heroes.Butcher.ID] = 2, _158) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_159 = {}, _159[heroes.Butcher.ID] = 5, _159) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_160 = {}, _160[heroes.Butcher.ID] = 3, _160) }) } },
            320: { loot: new Loot({ Currencies: (_161 = {}, _161[CURRENCY.COIN] = 1500, _161) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_162 = {}, _162[heroes.Butcher.ID] = 5, _162) }) } },
            600: { loot: new Loot({ Currencies: (_163 = {}, _163[CURRENCY.BONUS] = 50, _163) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_164 = {}, _164[heroes.Butcher.ID] = 5, _164) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Butcher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_21 = roundsStats; _i < roundsStats_21.length; _i++) {
                    var round = roundsStats_21[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Itu: new Marathon({
        PromoSettings: {
            conditions: {
                heroes: (_165 = {}, _165[heroes.Itu.ID] = { Level: { less_or_equal: heroes.Itu.StartLevel } }, _165),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50039,
        Alias: "talent_marathone_itu",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ItuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_166 = {}, _166[heroes.Itu.ID] = 2, _166) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_167 = {}, _167[heroes.Itu.ID] = 2, _167) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_168 = {}, _168[heroes.Itu.ID] = 5, _168) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_169 = {}, _169[heroes.Itu.ID] = 3, _169) }) } },
            320: { loot: new Loot({ Currencies: (_170 = {}, _170[CURRENCY.COIN] = 2500, _170) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_171 = {}, _171[heroes.Itu.ID] = 5, _171) }) } },
            600: { loot: new Loot({ Currencies: (_172 = {}, _172[CURRENCY.BONUS] = 50, _172) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_173 = {}, _173[heroes.Itu.ID] = 5, _173) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Itu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_22 = roundsStats; _i < roundsStats_22.length; _i++) {
                    var round = roundsStats_22[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Yunlin: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_174 = {}, _174[heroes.Yunlin.ID] = { Level: { less_or_equal: 3 } }, _174),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50042,
        Alias: "talent_marathone_Yunlin",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YunlinSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_175 = {}, _175[heroes.Yunlin.ID] = 2, _175) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_176 = {}, _176[heroes.Yunlin.ID] = 2, _176) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_177 = {}, _177[heroes.Yunlin.ID] = 5, _177) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_178 = {}, _178[heroes.Yunlin.ID] = 3, _178) }) } },
            320: { loot: new Loot({ Currencies: (_179 = {}, _179[CURRENCY.COIN] = 500, _179) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_180 = {}, _180[heroes.Yunlin.ID] = 5, _180) }) } },
            600: { loot: new Loot({ Currencies: (_181 = {}, _181[CURRENCY.BONUS] = 50, _181) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_182 = {}, _182[heroes.Yunlin.ID] = 5, _182) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yunlin.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_23 = roundsStats; _i < roundsStats_23.length; _i++) {
                    var round = roundsStats_23[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_Xiang_Tzu: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_183 = {}, _183[heroes.Xiang_Tzu.ID] = { Level: { less_or_equal: heroes.Xiang_Tzu.StartLevel } }, _183),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50044,
        Alias: "talent_marathone_xiang_tzu",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Xiang_TzuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_184 = {}, _184[heroes.Xiang_Tzu.ID] = 2, _184) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_185 = {}, _185[heroes.Xiang_Tzu.ID] = 2, _185) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_186 = {}, _186[heroes.Xiang_Tzu.ID] = 5, _186) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_187 = {}, _187[heroes.Xiang_Tzu.ID] = 3, _187) }) } },
            320: { loot: new Loot({ Currencies: (_188 = {}, _188[CURRENCY.COIN] = 1500, _188) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_189 = {}, _189[heroes.Xiang_Tzu.ID] = 5, _189) }) } },
            600: { loot: new Loot({ Currencies: (_190 = {}, _190[CURRENCY.BONUS] = 50, _190) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_191 = {}, _191[heroes.Xiang_Tzu.ID] = 5, _191) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Xiang_Tzu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_24 = roundsStats; _i < roundsStats_24.length; _i++) {
                    var round = roundsStats_24[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    ShardMarathon_June: new Marathon({
        PromoSettings: {
            conditions: {
                heroes: (_192 = {}, _192[heroes.June.ID] = { Level: { less_or_equal: heroes.June.StartLevel } }, _192),
                playerRating: {
                    less_or_equal: -1,
                }
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50045,
        Alias: "talent_marathone_june",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JuneSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            30: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_193 = {}, _193[heroes.June.ID] = 2, _193) }) } },
            80: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_194 = {}, _194[heroes.June.ID] = 2, _194) }) } },
            160: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_195 = {}, _195[heroes.June.ID] = 5, _195) }) } },
            240: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_196 = {}, _196[heroes.June.ID] = 3, _196) }) } },
            320: { loot: new Loot({ Currencies: (_197 = {}, _197[CURRENCY.COIN] = 2500, _197) }) },
            410: { chests: [chests.Rare_chest.ID] },
            500: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_198 = {}, _198[heroes.June.ID] = 5, _198) }) } },
            600: { loot: new Loot({ Currencies: (_199 = {}, _199[CURRENCY.BONUS] = 50, _199) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_200 = {}, _200[heroes.June.ID] = 5, _200) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.June.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_25 = roundsStats; _i < roundsStats_25.length; _i++) {
                    var round = roundsStats_25[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
}, true);
