var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
extend(Marathons, {
    activityMarathonFirstTime: new Marathon({
        ID: 70000,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {
                accountLevel: { less: -1 }
            },
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'referral_returning_marathon_info',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            20: { chests: [chests.Rare_chest.ID] },
            40: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a) }) },
            60: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 1000, _b) }) },
            80: { chests: [chests.Rare_chest.ID] },
            100: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.GACHA_KEY] = 1, _c) }) },
            120: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.COIN] = 2000, _d) }) },
            140: { chests: [chests.Epic_chest.ID] },
            160: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.GACHA_KEY] = 1, _e) }) },
            180: { chests: [chests.Epic_chest.ID] },
            200: { chests: [chests.Large_Shard_Chest_Duplicate.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var points = 0;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                if (battleStats.FightResult == FIGHT_RESULT.TECH_WIN || battleStats.FightResult == FIGHT_RESULT.WIN) {
                    points += 10;
                }
            }
            return args.Progress + points;
        }
    }),
    activityMarathonRegular: new Marathon({
        ID: 70001,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            regenerationDelay: new Time({ Days: 14 }).value,
            conditions: {
                accountLevel: { less: -1 }
            },
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            completedPreviousMarathons: [70000],
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'referral_returning_marathon_info',
        ViewConfig: MarathonView.ReferralActivity,
        MultiplePass: true,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            30: { chests: [chests.Common_chest.ID] },
            80: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 200, _f) }) },
            160: { chests: [chests.Rare_chest.ID] },
            240: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.COIN] = 400, _g) }) },
            320: { chests: [chests.Rare_chest.ID] },
            410: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.COIN] = 500, _h) }) },
            500: { chests: [chests.Epic_chest.ID] },
            600: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 600, _j) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { chests: [chests.Legendary_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var points = 0;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                if (battleStats.FightResult == FIGHT_RESULT.TECH_WIN || battleStats.FightResult == FIGHT_RESULT.WIN) {
                    points += 10;
                }
            }
            return args.Progress + points;
        }
    }),
    referralMarathon: new Marathon({
        ID: 70002,
        PromoSettings: {
            activeTime: {
                duration: PROMO_DURATION.ENDLESS
            },
            conditions: {
                playerRating: { more_or_equal: 30 }
            },
            sellHeroSettings: {
                heroId: heroes.Marcus.ID,
                sortingWeight: 1,
                sellingPromoType: GAME_ENTITY.MARATHON,
            },
            platforms: allPlatforms.filter(function (p) { return p != PLATFORM.CARE_GAME; }),
            customCondition: function (settings) {
                var isVietnamBuild = settings.regionalSettings.platform == PLATFORM.IOS_VIETNAM
                    || settings.regionalSettings.platform == PLATFORM.ANDROID_VIETNAM;
                return !isVietnamBuild;
            },
        },
        Alias: "referral_initial_marathon_title",
        Description: "referral_initial_marathon_desc",
        PointsDescription: 'referral_initial_marathon_info',
        ViewConfig: MarathonView.ReferralMarcus,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.REFERRAL,
        MarathonType: MARATHON_TYPE.REFERRAL,
        UseRewardsPopUp: true,
        Rewards: {
            1: { isHidden: false, loot: new Loot({ Shards: (_k = {}, _k[heroes.Marcus.ID] = heroes.Marcus.ShardsNeeded, _k) }) },
            2: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.BONUS] = 200, _l) }) },
            3: { isHidden: false, loot: new Loot({ Shards: (_m = {}, _m[heroes.Marcus.ID] = 10, _m) }) },
            4: { isHidden: false, loot: new Loot({ Skins: [skins.Marcus_E_Royal_skin.ID] }) },
            5: { isHidden: false, loot: new Loot({ Shards: (_o = {}, _o[heroes.Marcus.ID] = 10, _o) }) },
            6: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.GACHA_KEY] = 3, _p) }) },
            7: { isHidden: false, loot: new Loot({ Weapons: [heroWeapons.wpn_Marcus_E_Knight.ID] }) },
        },
        UpdateEvents: [QUEST_EVENT.REFERRAL_PLAYER],
        SortingOrder: 2,
        Update: function (args) {
            return args.ReferralSettings
                && args.ReferralSettings.guestType == REFERRAL_GUEST_TYPE.NEW_PLAYER
                && args.ReferralSettings.referralOption == REFERRAL_OPTION.RATING
                ? args.Progress + 1
                : args.Progress;
        }
    }),
}, true);
