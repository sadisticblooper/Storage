var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5;
extend(Marathons, {
    reactivation_1_1: new Marathon({
        ID: 90000,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.one,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Rare_chest.ID] },
            80: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 3000, _a) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 1000, _b) }) },
            320: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.GACHA_KEY] = 1, _c) }) },
            400: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.COIN] = 1000, _d) }) },
            500: { chests: [chests.Epic_chest.ID] },
            600: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.COIN] = 1000, _e) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { chests: [chests.Skin_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
    reactivation_1_2: new Marathon({
        ID: 90001,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.one,
            completedOrEndsPreviousMarathons: [90000],
            regenerationDelay: new Time({ Days: 14 }).value,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Rare_chest.ID] },
            80: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 3000, _f) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.COIN] = 1000, _g) }) },
            320: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.GACHA_KEY] = 1, _h) }) },
            400: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 1000, _j) }) },
            500: { chests: [chests.Epic_chest.ID] },
            600: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.COIN] = 1000, _k) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { chests: [chests.Legendary_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
    reactivation_2_1: new Marathon({
        ID: 90002,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.two,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Legendary_chest.ID] },
            80: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.COIN] = 5000, _l) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.COIN] = 2000, _m) }) },
            320: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.GACHA_KEY] = 2, _o) }) },
            400: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 2000, _p) }) },
            500: { chests: [chests.Large_Shard_Chest.ID] },
            600: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 2000, _q) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { chests: [chests.Skin_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
    reactivation_2_2: new Marathon({
        ID: 90003,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.two,
            completedOrEndsPreviousMarathons: [90002],
            regenerationDelay: new Time({ Days: 14 }).value,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Legendary_chest.ID] },
            80: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.COIN] = 5000, _r) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 2000, _s) }) },
            320: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.GACHA_KEY] = 2, _t) }) },
            400: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 2000, _u) }) },
            500: { chests: [chests.Large_Shard_Chest.ID] },
            600: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 2000, _v) }) },
            700: { chests: [chests.Epic_chest.ID] },
            800: { chests: [chests.Legendary_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
    reactivation_3_1: new Marathon({
        ID: 90004,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.three,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Legendary_chest.ID] },
            80: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.COIN] = 8000, _w) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.COIN] = 3000, _x) }) },
            320: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.GACHA_KEY] = 3, _y) }) },
            400: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.COIN] = 3000, _z) }) },
            480: { chests: [chests.Large_Shard_Chest.ID] },
            560: { chests: [chests.Legendary_chest.ID] },
            640: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.COIN] = 3000, _0) }) },
            720: { chests: [chests.Large_Shard_Chest.ID] },
            800: { chests: [chests.Skin_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
    reactivation_3_2: new Marathon({
        ID: 90005,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 14 }).value
            },
            conditions: {},
            triggersToGenerate: [PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER],
            timeFromLastLogout: MarathonConstants.marathonsReactivationPeriods.three,
            completedOrEndsPreviousMarathons: [90004],
            regenerationDelay: new Time({ Days: 14 }).value,
            checkTutorialPassed: true,
        },
        Alias: "referral_returning_marathon_title",
        Description: "referral_returning_marathon_desc",
        PointsDescription: 'marathon_descPoints_returning',
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.EVENT,
        Rewards: {
            40: { chests: [chests.Legendary_chest.ID] },
            80: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.COIN] = 8000, _1) }) },
            160: { chests: [chests.Large_Shard_Chest.ID] },
            240: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.COIN] = 3000, _2) }) },
            320: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.GACHA_KEY] = 3, _3) }) },
            400: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.COIN] = 3000, _4) }) },
            480: { chests: [chests.Large_Shard_Chest.ID] },
            560: { chests: [chests.Legendary_chest.ID] },
            640: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.COIN] = 3000, _5) }) },
            720: { chests: [chests.Large_Shard_Chest.ID] },
            800: { chests: [chests.Mythic_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var mode = battleStats.MatchingInfo.mode;
            var points = 0;
            var delta = 0;
            if ([FIGHT_MODE.AI, FIGHT_MODE.ROGUELIKE_COMMON, FIGHT_MODE.ROGUELIKE_SURVIVAL].indexOf(mode) > -1) {
                delta = 10;
            }
            else if (mode == FIGHT_MODE.RANKED) {
                delta = 20;
            }
            if (battleStats.Rounds) {
                points = delta * battleStats.Rounds.length;
            }
            return args.Progress + points;
        }
    }),
});
