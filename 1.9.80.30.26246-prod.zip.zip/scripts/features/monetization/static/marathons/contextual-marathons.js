var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155, _156, _157, _158, _159, _160, _161, _162, _163, _164, _165, _166, _167, _168, _169, _170, _171, _172, _173, _174, _175, _176, _177, _178, _179, _180, _181, _182, _183, _184, _185, _186, _187, _188, _189, _190, _191, _192, _193, _194, _195, _196, _197, _198, _199, _200, _201, _202, _203, _204, _205, _206, _207, _208, _209, _210, _211, _212, _213, _214, _215, _216, _217, _218, _219, _220, _221, _222, _223, _224, _225, _226, _227, _228, _229, _230, _231, _232, _233, _234, _235, _236, _237, _238, _239, _240, _241, _242, _243, _244, _245, _246, _247, _248, _249, _250, _251, _252, _253, _254, _255, _256, _257, _258, _259, _260, _261, _262, _263, _264, _265, _266, _267, _268, _269, _270, _271, _272, _273, _274, _275, _276, _277, _278, _279, _280, _281, _282, _283, _284, _285, _286, _287, _288, _289, _290, _291, _292, _293, _294, _295, _296, _297, _298, _299, _300, _301, _302, _303, _304, _305, _306, _307, _308, _309, _310, _311, _312, _313, _314, _315, _316, _317, _318, _319, _320, _321, _322, _323, _324, _325, _326, _327, _328, _329, _330, _331, _332, _333, _334, _335, _336, _337, _338, _339, _340, _341, _342, _343, _344, _345, _346, _347, _348, _349, _350, _351, _352, _353, _354, _355, _356, _357, _358, _359, _360, _361, _362, _363, _364, _365, _366, _367, _368, _369, _370, _371, _372, _373, _374, _375, _376, _377, _378, _379, _380, _381, _382, _383, _384, _385, _386, _387, _388, _389, _390, _391, _392, _393, _394, _395, _396, _397, _398, _399, _400, _401, _402, _403, _404, _405, _406, _407, _408, _409, _410, _411, _412, _413, _414, _415, _416, _417, _418, _419, _420, _421, _422, _423, _424, _425, _426, _427, _428, _429, _430, _431, _432, _433, _434, _435, _436, _437, _438, _439, _440, _441, _442, _443, _444, _445, _446, _447, _448, _449, _450, _451, _452, _453, _454, _455, _456, _457, _458, _459, _460, _461, _462, _463, _464, _465, _466, _467, _468, _469, _470, _471, _472, _473, _474, _475, _476, _477, _478, _479, _480, _481, _482, _483, _484, _485, _486, _487, _488, _489, _490, _491, _492, _493;
extend(Marathons, {
    Contextual_ShardMarathon_Monk_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50518, 50018],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59001,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59001,
        Alias: "contextual_talent_marathone_monk",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MonkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59001,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_a = {}, _a[heroes.Monk.ID] = 20, _a) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_b = {}, _b[heroes.Monk.ID] = 10, _b) }) } },
            80: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 1500, _c) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_d = {}, _d[heroes.Monk.ID] = 40, _d) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_e = {}, _e[heroes.Monk.ID] = 10, _e) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[heroes.Monk.ID] = 50, _f) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monk.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_1 = roundsStats; _i < roundsStats_1.length; _i++) {
                    var round = roundsStats_1[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Monk_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50518, 50018],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59001,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59002,
        Alias: "contextual_talent_marathone_monk",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MonkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59002,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_g = {}, _g[heroes.Monk.ID] = 30, _g) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_h = {}, _h[heroes.Monk.ID] = 10, _h) }) } },
            70: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 3000, _j) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_k = {}, _k[heroes.Monk.ID] = 50, _k) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_l = {}, _l[heroes.Monk.ID] = 100, _l) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_m = {}, _m[heroes.Monk.ID] = 10, _m) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monk.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_2 = roundsStats; _i < roundsStats_2.length; _i++) {
                    var round = roundsStats_2[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Monk_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50518, 50018],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59001,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59003,
        Alias: "contextual_talent_marathone_monk",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MonkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59003,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_o = {}, _o[heroes.Monk.ID] = 80, _o) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_p = {}, _p[heroes.Monk.ID] = 15, _p) }) } },
            70: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 8000, _q) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_r = {}, _r[heroes.Monk.ID] = 120, _r) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_s = {}, _s[heroes.Monk.ID] = 180, _s) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_t = {}, _t[heroes.Monk.ID] = 35, _t) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monk.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_3 = roundsStats; _i < roundsStats_3.length; _i++) {
                    var round = roundsStats_3[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Liquidator_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50519, 50019],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59004,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59004,
        Alias: "contextual_talent_marathone_kate",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LiquidatorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59004,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_u = {}, _u[heroes.Liquidator.ID] = 20, _u) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_v = {}, _v[heroes.Liquidator.ID] = 10, _v) }) } },
            80: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.COIN] = 1500, _w) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_x = {}, _x[heroes.Liquidator.ID] = 40, _x) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_y = {}, _y[heroes.Liquidator.ID] = 10, _y) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_z = {}, _z[heroes.Liquidator.ID] = 50, _z) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Liquidator.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_4 = roundsStats; _i < roundsStats_4.length; _i++) {
                    var round = roundsStats_4[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Liquidator_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50519, 50019],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59004,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59005,
        Alias: "contextual_talent_marathone_kate",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LiquidatorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59005,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_0 = {}, _0[heroes.Liquidator.ID] = 30, _0) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_1 = {}, _1[heroes.Liquidator.ID] = 10, _1) }) } },
            70: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.COIN] = 3000, _2) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_3 = {}, _3[heroes.Liquidator.ID] = 50, _3) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_4 = {}, _4[heroes.Liquidator.ID] = 100, _4) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_5 = {}, _5[heroes.Liquidator.ID] = 10, _5) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Liquidator.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_5 = roundsStats; _i < roundsStats_5.length; _i++) {
                    var round = roundsStats_5[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Liquidator_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50519, 50019],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59004,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59006,
        Alias: "contextual_talent_marathone_kate",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LiquidatorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59006,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_6 = {}, _6[heroes.Liquidator.ID] = 80, _6) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_7 = {}, _7[heroes.Liquidator.ID] = 15, _7) }) } },
            70: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.COIN] = 8000, _8) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_9 = {}, _9[heroes.Liquidator.ID] = 120, _9) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_10 = {}, _10[heroes.Liquidator.ID] = 180, _10) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_11 = {}, _11[heroes.Liquidator.ID] = 35, _11) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Liquidator.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_6 = roundsStats; _i < roundsStats_6.length; _i++) {
                    var round = roundsStats_6[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ironclad_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50520, 50020],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59007,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59007,
        Alias: "contextual_talent_marathone_ironclad",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.IroncladSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59007,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_12 = {}, _12[heroes.Ironclad.ID] = 20, _12) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_13 = {}, _13[heroes.Ironclad.ID] = 10, _13) }) } },
            80: { loot: new Loot({ Currencies: (_14 = {}, _14[CURRENCY.COIN] = 1500, _14) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_15 = {}, _15[heroes.Ironclad.ID] = 40, _15) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_16 = {}, _16[heroes.Ironclad.ID] = 10, _16) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_17 = {}, _17[heroes.Ironclad.ID] = 50, _17) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ironclad.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_7 = roundsStats; _i < roundsStats_7.length; _i++) {
                    var round = roundsStats_7[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ironclad_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50520, 50020],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59007,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59008,
        Alias: "contextual_talent_marathone_ironclad",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.IroncladSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59008,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_18 = {}, _18[heroes.Ironclad.ID] = 30, _18) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_19 = {}, _19[heroes.Ironclad.ID] = 10, _19) }) } },
            70: { loot: new Loot({ Currencies: (_20 = {}, _20[CURRENCY.COIN] = 3000, _20) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_21 = {}, _21[heroes.Ironclad.ID] = 50, _21) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_22 = {}, _22[heroes.Ironclad.ID] = 100, _22) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_23 = {}, _23[heroes.Ironclad.ID] = 10, _23) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ironclad.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_8 = roundsStats; _i < roundsStats_8.length; _i++) {
                    var round = roundsStats_8[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ironclad_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50520, 50020],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59007,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59009,
        Alias: "contextual_talent_marathone_ironclad",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.IroncladSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59009,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_24 = {}, _24[heroes.Ironclad.ID] = 80, _24) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_25 = {}, _25[heroes.Ironclad.ID] = 15, _25) }) } },
            70: { loot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.COIN] = 8000, _26) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_27 = {}, _27[heroes.Ironclad.ID] = 120, _27) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_28 = {}, _28[heroes.Ironclad.ID] = 180, _28) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_29 = {}, _29[heroes.Ironclad.ID] = 35, _29) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ironclad.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_9 = roundsStats; _i < roundsStats_9.length; _i++) {
                    var round = roundsStats_9[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Fireguard_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50521, 50021],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59010,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59010,
        Alias: "contextual_talent_marathone_fireguard",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FireguardSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59010,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_30 = {}, _30[heroes.Fireguard.ID] = 20, _30) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_31 = {}, _31[heroes.Fireguard.ID] = 10, _31) }) } },
            80: { loot: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.COIN] = 1500, _32) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_33 = {}, _33[heroes.Fireguard.ID] = 40, _33) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_34 = {}, _34[heroes.Fireguard.ID] = 10, _34) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_35 = {}, _35[heroes.Fireguard.ID] = 50, _35) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Fireguard.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_10 = roundsStats; _i < roundsStats_10.length; _i++) {
                    var round = roundsStats_10[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Fireguard_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50521, 50021],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59010,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59011,
        Alias: "contextual_talent_marathone_fireguard",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FireguardSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59011,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_36 = {}, _36[heroes.Fireguard.ID] = 30, _36) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_37 = {}, _37[heroes.Fireguard.ID] = 10, _37) }) } },
            70: { loot: new Loot({ Currencies: (_38 = {}, _38[CURRENCY.COIN] = 3000, _38) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_39 = {}, _39[heroes.Fireguard.ID] = 50, _39) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_40 = {}, _40[heroes.Fireguard.ID] = 100, _40) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_41 = {}, _41[heroes.Fireguard.ID] = 10, _41) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Fireguard.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_11 = roundsStats; _i < roundsStats_11.length; _i++) {
                    var round = roundsStats_11[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Fireguard_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50521, 50021],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59010,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59012,
        Alias: "contextual_talent_marathone_fireguard",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FireguardSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59012,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_42 = {}, _42[heroes.Fireguard.ID] = 80, _42) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_43 = {}, _43[heroes.Fireguard.ID] = 15, _43) }) } },
            70: { loot: new Loot({ Currencies: (_44 = {}, _44[CURRENCY.COIN] = 8000, _44) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_45 = {}, _45[heroes.Fireguard.ID] = 120, _45) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_46 = {}, _46[heroes.Fireguard.ID] = 180, _46) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_47 = {}, _47[heroes.Fireguard.ID] = 35, _47) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Fireguard.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_12 = roundsStats; _i < roundsStats_12.length; _i++) {
                    var round = roundsStats_12[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Helga_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50522, 50022],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59013,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59013,
        Alias: "contextual_talent_marathone_helga",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HelgaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59013,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_48 = {}, _48[heroes.Helga.ID] = 11, _48) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_49 = {}, _49[heroes.Helga.ID] = 5, _49) }) } },
            80: { loot: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.COIN] = 1500, _50) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_51 = {}, _51[heroes.Helga.ID] = 15, _51) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_52 = {}, _52[heroes.Helga.ID] = 5, _52) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_53 = {}, _53[heroes.Helga.ID] = 30, _53) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Helga.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_13 = roundsStats; _i < roundsStats_13.length; _i++) {
                    var round = roundsStats_13[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Helga_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50522, 50022],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59013,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59014,
        Alias: "contextual_talent_marathone_helga",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HelgaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59014,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_54 = {}, _54[heroes.Helga.ID] = 20, _54) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_55 = {}, _55[heroes.Helga.ID] = 5, _55) }) } },
            70: { loot: new Loot({ Currencies: (_56 = {}, _56[CURRENCY.COIN] = 3000, _56) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_57 = {}, _57[heroes.Helga.ID] = 25, _57) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_58 = {}, _58[heroes.Helga.ID] = 36, _58) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_59 = {}, _59[heroes.Helga.ID] = 5, _59) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Helga.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_14 = roundsStats; _i < roundsStats_14.length; _i++) {
                    var round = roundsStats_14[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Helga_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50522, 50022],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59013,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59015,
        Alias: "contextual_talent_marathone_helga",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HelgaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59015,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_60 = {}, _60[heroes.Helga.ID] = 31, _60) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_61 = {}, _61[heroes.Helga.ID] = 5, _61) }) } },
            70: { loot: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.COIN] = 8000, _62) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_63 = {}, _63[heroes.Helga.ID] = 50, _63) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_64 = {}, _64[heroes.Helga.ID] = 100, _64) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_65 = {}, _65[heroes.Helga.ID] = 15, _65) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Helga.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_15 = roundsStats; _i < roundsStats_15.length; _i++) {
                    var round = roundsStats_15[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Jet_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50523, 50023],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59016,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59016,
        Alias: "contextual_talent_marathone_jet",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JetSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59016,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_66 = {}, _66[heroes.Jet.ID] = 11, _66) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_67 = {}, _67[heroes.Jet.ID] = 5, _67) }) } },
            80: { loot: new Loot({ Currencies: (_68 = {}, _68[CURRENCY.COIN] = 1500, _68) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_69 = {}, _69[heroes.Jet.ID] = 15, _69) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_70 = {}, _70[heroes.Jet.ID] = 5, _70) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_71 = {}, _71[heroes.Jet.ID] = 30, _71) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Jet.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_16 = roundsStats; _i < roundsStats_16.length; _i++) {
                    var round = roundsStats_16[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Jet_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50523, 50023],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59016,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59017,
        Alias: "contextual_talent_marathone_jet",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JetSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59017,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_72 = {}, _72[heroes.Jet.ID] = 20, _72) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_73 = {}, _73[heroes.Jet.ID] = 5, _73) }) } },
            70: { loot: new Loot({ Currencies: (_74 = {}, _74[CURRENCY.COIN] = 3000, _74) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_75 = {}, _75[heroes.Jet.ID] = 25, _75) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_76 = {}, _76[heroes.Jet.ID] = 36, _76) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_77 = {}, _77[heroes.Jet.ID] = 5, _77) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Jet.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_17 = roundsStats; _i < roundsStats_17.length; _i++) {
                    var round = roundsStats_17[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Jet_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50523, 50023],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59016,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59018,
        Alias: "contextual_talent_marathone_jet",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JetSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59018,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_78 = {}, _78[heroes.Jet.ID] = 31, _78) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_79 = {}, _79[heroes.Jet.ID] = 5, _79) }) } },
            70: { loot: new Loot({ Currencies: (_80 = {}, _80[CURRENCY.COIN] = 8000, _80) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_81 = {}, _81[heroes.Jet.ID] = 50, _81) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_82 = {}, _82[heroes.Jet.ID] = 100, _82) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_83 = {}, _83[heroes.Jet.ID] = 15, _83) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Jet.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_18 = roundsStats; _i < roundsStats_18.length; _i++) {
                    var round = roundsStats_18[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Feldsher_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50524, 50024],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59019,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59019,
        Alias: "contextual_talent_marathone_feldsher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FeldsherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59019,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_84 = {}, _84[heroes.Feldsher.ID] = 20, _84) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_85 = {}, _85[heroes.Feldsher.ID] = 10, _85) }) } },
            80: { loot: new Loot({ Currencies: (_86 = {}, _86[CURRENCY.COIN] = 1500, _86) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_87 = {}, _87[heroes.Feldsher.ID] = 40, _87) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_88 = {}, _88[heroes.Feldsher.ID] = 10, _88) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_89 = {}, _89[heroes.Feldsher.ID] = 50, _89) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Feldsher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_19 = roundsStats; _i < roundsStats_19.length; _i++) {
                    var round = roundsStats_19[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Feldsher_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50524, 50024],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59019,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59020,
        Alias: "contextual_talent_marathone_feldsher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FeldsherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59020,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_90 = {}, _90[heroes.Feldsher.ID] = 30, _90) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_91 = {}, _91[heroes.Feldsher.ID] = 10, _91) }) } },
            70: { loot: new Loot({ Currencies: (_92 = {}, _92[CURRENCY.COIN] = 3000, _92) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_93 = {}, _93[heroes.Feldsher.ID] = 50, _93) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_94 = {}, _94[heroes.Feldsher.ID] = 100, _94) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_95 = {}, _95[heroes.Feldsher.ID] = 10, _95) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Feldsher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_20 = roundsStats; _i < roundsStats_20.length; _i++) {
                    var round = roundsStats_20[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Feldsher_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50524, 50024],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59019,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59021,
        Alias: "contextual_talent_marathone_feldsher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FeldsherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59021,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_96 = {}, _96[heroes.Feldsher.ID] = 80, _96) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_97 = {}, _97[heroes.Feldsher.ID] = 15, _97) }) } },
            70: { loot: new Loot({ Currencies: (_98 = {}, _98[CURRENCY.COIN] = 8000, _98) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_99 = {}, _99[heroes.Feldsher.ID] = 120, _99) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_100 = {}, _100[heroes.Feldsher.ID] = 180, _100) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_101 = {}, _101[heroes.Feldsher.ID] = 35, _101) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Feldsher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_21 = roundsStats; _i < roundsStats_21.length; _i++) {
                    var round = roundsStats_21[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yukka_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50525, 50025],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59022,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59022,
        Alias: "contextual_talent_marathone_yukka",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YukkaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59022,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_102 = {}, _102[heroes.Yukka.ID] = 11, _102) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_103 = {}, _103[heroes.Yukka.ID] = 5, _103) }) } },
            80: { loot: new Loot({ Currencies: (_104 = {}, _104[CURRENCY.COIN] = 1500, _104) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_105 = {}, _105[heroes.Yukka.ID] = 15, _105) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_106 = {}, _106[heroes.Yukka.ID] = 5, _106) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_107 = {}, _107[heroes.Yukka.ID] = 30, _107) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yukka.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_22 = roundsStats; _i < roundsStats_22.length; _i++) {
                    var round = roundsStats_22[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yukka_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50525, 50025],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59022,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59023,
        Alias: "contextual_talent_marathone_yukka",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YukkaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59023,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_108 = {}, _108[heroes.Yukka.ID] = 20, _108) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_109 = {}, _109[heroes.Yukka.ID] = 5, _109) }) } },
            70: { loot: new Loot({ Currencies: (_110 = {}, _110[CURRENCY.COIN] = 3000, _110) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_111 = {}, _111[heroes.Yukka.ID] = 25, _111) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_112 = {}, _112[heroes.Yukka.ID] = 36, _112) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_113 = {}, _113[heroes.Yukka.ID] = 5, _113) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yukka.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_23 = roundsStats; _i < roundsStats_23.length; _i++) {
                    var round = roundsStats_23[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yukka_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50525, 50025],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59022,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59024,
        Alias: "contextual_talent_marathone_yukka",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YukkaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59024,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_114 = {}, _114[heroes.Yukka.ID] = 31, _114) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_115 = {}, _115[heroes.Yukka.ID] = 5, _115) }) } },
            70: { loot: new Loot({ Currencies: (_116 = {}, _116[CURRENCY.COIN] = 8000, _116) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_117 = {}, _117[heroes.Yukka.ID] = 50, _117) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_118 = {}, _118[heroes.Yukka.ID] = 100, _118) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_119 = {}, _119[heroes.Yukka.ID] = 15, _119) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yukka.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_24 = roundsStats; _i < roundsStats_24.length; _i++) {
                    var round = roundsStats_24[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Bulwark_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50526, 50026],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59025,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59025,
        Alias: "contextual_talent_marathone_bulwark",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.BulwarkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59025,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_120 = {}, _120[heroes.Bulwark.ID] = 20, _120) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_121 = {}, _121[heroes.Bulwark.ID] = 10, _121) }) } },
            80: { loot: new Loot({ Currencies: (_122 = {}, _122[CURRENCY.COIN] = 1500, _122) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_123 = {}, _123[heroes.Bulwark.ID] = 40, _123) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_124 = {}, _124[heroes.Bulwark.ID] = 10, _124) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_125 = {}, _125[heroes.Bulwark.ID] = 50, _125) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Bulwark.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_25 = roundsStats; _i < roundsStats_25.length; _i++) {
                    var round = roundsStats_25[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Bulwark_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50526, 50026],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59025,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59026,
        Alias: "contextual_talent_marathone_bulwark",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.BulwarkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59026,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_126 = {}, _126[heroes.Bulwark.ID] = 30, _126) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_127 = {}, _127[heroes.Bulwark.ID] = 10, _127) }) } },
            70: { loot: new Loot({ Currencies: (_128 = {}, _128[CURRENCY.COIN] = 3000, _128) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_129 = {}, _129[heroes.Bulwark.ID] = 50, _129) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_130 = {}, _130[heroes.Bulwark.ID] = 100, _130) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_131 = {}, _131[heroes.Bulwark.ID] = 10, _131) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Bulwark.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_26 = roundsStats; _i < roundsStats_26.length; _i++) {
                    var round = roundsStats_26[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Bulwark_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50526, 50026],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59025,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59027,
        Alias: "contextual_talent_marathone_bulwark",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.BulwarkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59027,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_132 = {}, _132[heroes.Bulwark.ID] = 80, _132) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_133 = {}, _133[heroes.Bulwark.ID] = 15, _133) }) } },
            70: { loot: new Loot({ Currencies: (_134 = {}, _134[CURRENCY.COIN] = 8000, _134) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_135 = {}, _135[heroes.Bulwark.ID] = 120, _135) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_136 = {}, _136[heroes.Bulwark.ID] = 180, _136) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_137 = {}, _137[heroes.Bulwark.ID] = 35, _137) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Bulwark.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_27 = roundsStats; _i < roundsStats_27.length; _i++) {
                    var round = roundsStats_27[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Emperor_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50527, 50027],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59028,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59028,
        Alias: "contextual_talent_marathone_emperor",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.EmperorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59028,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_138 = {}, _138[heroes.Emperor.ID] = 5, _138) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_139 = {}, _139[heroes.Emperor.ID] = 5, _139) }) } },
            120: { loot: new Loot({ Currencies: (_140 = {}, _140[CURRENCY.COIN] = 1500, _140) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_141 = {}, _141[heroes.Emperor.ID] = 8, _141) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_142 = {}, _142[heroes.Emperor.ID] = 5, _142) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Emperor.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_28 = roundsStats; _i < roundsStats_28.length; _i++) {
                    var round = roundsStats_28[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Emperor_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50527, 50027],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59028,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59029,
        Alias: "contextual_talent_marathone_emperor",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.EmperorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59029,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_143 = {}, _143[heroes.Emperor.ID] = 5, _143) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_144 = {}, _144[heroes.Emperor.ID] = 5, _144) }) } },
            70: { loot: new Loot({ Currencies: (_145 = {}, _145[CURRENCY.COIN] = 3000, _145) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_146 = {}, _146[heroes.Emperor.ID] = 8, _146) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_147 = {}, _147[heroes.Emperor.ID] = 15, _147) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_148 = {}, _148[heroes.Emperor.ID] = 5, _148) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Emperor.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_29 = roundsStats; _i < roundsStats_29.length; _i++) {
                    var round = roundsStats_29[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Emperor_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50527, 50027],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59028,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59030,
        Alias: "contextual_talent_marathone_emperor",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.EmperorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59030,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_149 = {}, _149[heroes.Emperor.ID] = 13, _149) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_150 = {}, _150[heroes.Emperor.ID] = 5, _150) }) } },
            70: { loot: new Loot({ Currencies: (_151 = {}, _151[CURRENCY.COIN] = 8000, _151) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_152 = {}, _152[heroes.Emperor.ID] = 15, _152) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_153 = {}, _153[heroes.Emperor.ID] = 30, _153) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_154 = {}, _154[heroes.Emperor.ID] = 15, _154) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Emperor.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_30 = roundsStats; _i < roundsStats_30.length; _i++) {
                    var round = roundsStats_30[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Kibo_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50528, 50028],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59031,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59031,
        Alias: "contextual_talent_marathone_kibo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.KiboSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59031,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_155 = {}, _155[heroes.Kibo.ID] = 5, _155) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_156 = {}, _156[heroes.Kibo.ID] = 5, _156) }) } },
            120: { loot: new Loot({ Currencies: (_157 = {}, _157[CURRENCY.COIN] = 1500, _157) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_158 = {}, _158[heroes.Kibo.ID] = 8, _158) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_159 = {}, _159[heroes.Kibo.ID] = 5, _159) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Kibo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_31 = roundsStats; _i < roundsStats_31.length; _i++) {
                    var round = roundsStats_31[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Kibo_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50528, 50028],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59031,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59032,
        Alias: "contextual_talent_marathone_kibo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.KiboSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59032,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_160 = {}, _160[heroes.Kibo.ID] = 5, _160) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_161 = {}, _161[heroes.Kibo.ID] = 5, _161) }) } },
            70: { loot: new Loot({ Currencies: (_162 = {}, _162[CURRENCY.COIN] = 3000, _162) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_163 = {}, _163[heroes.Kibo.ID] = 8, _163) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_164 = {}, _164[heroes.Kibo.ID] = 15, _164) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_165 = {}, _165[heroes.Kibo.ID] = 5, _165) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Kibo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_32 = roundsStats; _i < roundsStats_32.length; _i++) {
                    var round = roundsStats_32[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Kibo_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50528, 50028],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59031,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59033,
        Alias: "contextual_talent_marathone_kibo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.KiboSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59033,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_166 = {}, _166[heroes.Kibo.ID] = 13, _166) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_167 = {}, _167[heroes.Kibo.ID] = 5, _167) }) } },
            70: { loot: new Loot({ Currencies: (_168 = {}, _168[CURRENCY.COIN] = 8000, _168) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_169 = {}, _169[heroes.Kibo.ID] = 15, _169) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_170 = {}, _170[heroes.Kibo.ID] = 30, _170) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_171 = {}, _171[heroes.Kibo.ID] = 15, _171) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Kibo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_33 = roundsStats; _i < roundsStats_33.length; _i++) {
                    var round = roundsStats_33[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Marcus_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50529, 50029],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59034,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59034,
        Alias: "contextual_talent_marathone_marcus",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MarcusSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59034,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_172 = {}, _172[heroes.Marcus.ID] = 5, _172) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_173 = {}, _173[heroes.Marcus.ID] = 5, _173) }) } },
            120: { loot: new Loot({ Currencies: (_174 = {}, _174[CURRENCY.COIN] = 1500, _174) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_175 = {}, _175[heroes.Marcus.ID] = 8, _175) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_176 = {}, _176[heroes.Marcus.ID] = 5, _176) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Marcus.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_34 = roundsStats; _i < roundsStats_34.length; _i++) {
                    var round = roundsStats_34[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Marcus_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50529, 50029],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59034,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59035,
        Alias: "contextual_talent_marathone_marcus",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MarcusSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59035,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_177 = {}, _177[heroes.Marcus.ID] = 5, _177) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_178 = {}, _178[heroes.Marcus.ID] = 5, _178) }) } },
            70: { loot: new Loot({ Currencies: (_179 = {}, _179[CURRENCY.COIN] = 3000, _179) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_180 = {}, _180[heroes.Marcus.ID] = 8, _180) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_181 = {}, _181[heroes.Marcus.ID] = 15, _181) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_182 = {}, _182[heroes.Marcus.ID] = 5, _182) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Marcus.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_35 = roundsStats; _i < roundsStats_35.length; _i++) {
                    var round = roundsStats_35[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Marcus_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50529, 50029],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59034,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59036,
        Alias: "contextual_talent_marathone_marcus",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MarcusSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59036,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_183 = {}, _183[heroes.Marcus.ID] = 13, _183) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_184 = {}, _184[heroes.Marcus.ID] = 5, _184) }) } },
            70: { loot: new Loot({ Currencies: (_185 = {}, _185[CURRENCY.COIN] = 8000, _185) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_186 = {}, _186[heroes.Marcus.ID] = 15, _186) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_187 = {}, _187[heroes.Marcus.ID] = 30, _187) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_188 = {}, _188[heroes.Marcus.ID] = 15, _188) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Marcus.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_36 = roundsStats; _i < roundsStats_36.length; _i++) {
                    var round = roundsStats_36[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_HongJoo_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50530, 50030],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59037,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59037,
        Alias: "contextual_talent_marathone_hongjoo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HongJooSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59037,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_189 = {}, _189[heroes.HongJoo.ID] = 11, _189) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_190 = {}, _190[heroes.HongJoo.ID] = 5, _190) }) } },
            80: { loot: new Loot({ Currencies: (_191 = {}, _191[CURRENCY.COIN] = 1500, _191) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_192 = {}, _192[heroes.HongJoo.ID] = 15, _192) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_193 = {}, _193[heroes.HongJoo.ID] = 5, _193) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_194 = {}, _194[heroes.HongJoo.ID] = 30, _194) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.HongJoo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_37 = roundsStats; _i < roundsStats_37.length; _i++) {
                    var round = roundsStats_37[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_HongJoo_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50530, 50030],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59037,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59038,
        Alias: "contextual_talent_marathone_hongjoo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HongJooSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59038,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_195 = {}, _195[heroes.HongJoo.ID] = 20, _195) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_196 = {}, _196[heroes.HongJoo.ID] = 5, _196) }) } },
            70: { loot: new Loot({ Currencies: (_197 = {}, _197[CURRENCY.COIN] = 3000, _197) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_198 = {}, _198[heroes.HongJoo.ID] = 25, _198) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_199 = {}, _199[heroes.HongJoo.ID] = 36, _199) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_200 = {}, _200[heroes.HongJoo.ID] = 5, _200) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.HongJoo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_38 = roundsStats; _i < roundsStats_38.length; _i++) {
                    var round = roundsStats_38[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_HongJoo_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50530, 50030],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59037,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59039,
        Alias: "contextual_talent_marathone_hongjoo",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HongJooSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59039,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_201 = {}, _201[heroes.HongJoo.ID] = 31, _201) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_202 = {}, _202[heroes.HongJoo.ID] = 5, _202) }) } },
            70: { loot: new Loot({ Currencies: (_203 = {}, _203[CURRENCY.COIN] = 8000, _203) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_204 = {}, _204[heroes.HongJoo.ID] = 50, _204) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_205 = {}, _205[heroes.HongJoo.ID] = 100, _205) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_206 = {}, _206[heroes.HongJoo.ID] = 15, _206) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.HongJoo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_39 = roundsStats; _i < roundsStats_39.length; _i++) {
                    var round = roundsStats_39[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Midnight_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50531, 50031],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59040,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59040,
        Alias: "contextual_talent_marathone_midnight",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MidnightSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59040,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_207 = {}, _207[heroes.Midnight.ID] = 5, _207) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_208 = {}, _208[heroes.Midnight.ID] = 5, _208) }) } },
            120: { loot: new Loot({ Currencies: (_209 = {}, _209[CURRENCY.COIN] = 1500, _209) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_210 = {}, _210[heroes.Midnight.ID] = 8, _210) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_211 = {}, _211[heroes.Midnight.ID] = 5, _211) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Midnight.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_40 = roundsStats; _i < roundsStats_40.length; _i++) {
                    var round = roundsStats_40[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Midnight_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50531, 50031],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59040,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59041,
        Alias: "contextual_talent_marathone_midnight",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MidnightSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59041,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_212 = {}, _212[heroes.Midnight.ID] = 5, _212) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_213 = {}, _213[heroes.Midnight.ID] = 5, _213) }) } },
            70: { loot: new Loot({ Currencies: (_214 = {}, _214[CURRENCY.COIN] = 3000, _214) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_215 = {}, _215[heroes.Midnight.ID] = 8, _215) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_216 = {}, _216[heroes.Midnight.ID] = 15, _216) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_217 = {}, _217[heroes.Midnight.ID] = 5, _217) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Midnight.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_41 = roundsStats; _i < roundsStats_41.length; _i++) {
                    var round = roundsStats_41[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Midnight_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50531, 50031],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59040,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59042,
        Alias: "contextual_talent_marathone_midnight",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MidnightSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59042,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_218 = {}, _218[heroes.Midnight.ID] = 13, _218) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_219 = {}, _219[heroes.Midnight.ID] = 5, _219) }) } },
            70: { loot: new Loot({ Currencies: (_220 = {}, _220[CURRENCY.COIN] = 8000, _220) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_221 = {}, _221[heroes.Midnight.ID] = 15, _221) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_222 = {}, _222[heroes.Midnight.ID] = 30, _222) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_223 = {}, _223[heroes.Midnight.ID] = 15, _223) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Midnight.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_42 = roundsStats; _i < roundsStats_42.length; _i++) {
                    var round = roundsStats_42[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Sarge_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50532, 50032],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59043,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59043,
        Alias: "contextual_talent_marathone_sarge",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.SargeSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59043,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_224 = {}, _224[heroes.Sarge.ID] = 11, _224) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_225 = {}, _225[heroes.Sarge.ID] = 5, _225) }) } },
            80: { loot: new Loot({ Currencies: (_226 = {}, _226[CURRENCY.COIN] = 1500, _226) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_227 = {}, _227[heroes.Sarge.ID] = 15, _227) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_228 = {}, _228[heroes.Sarge.ID] = 5, _228) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_229 = {}, _229[heroes.Sarge.ID] = 30, _229) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Sarge.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_43 = roundsStats; _i < roundsStats_43.length; _i++) {
                    var round = roundsStats_43[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Sarge_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50532, 50032],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59043,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59044,
        Alias: "contextual_talent_marathone_sarge",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.SargeSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59044,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_230 = {}, _230[heroes.Sarge.ID] = 20, _230) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_231 = {}, _231[heroes.Sarge.ID] = 5, _231) }) } },
            70: { loot: new Loot({ Currencies: (_232 = {}, _232[CURRENCY.COIN] = 3000, _232) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_233 = {}, _233[heroes.Sarge.ID] = 25, _233) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_234 = {}, _234[heroes.Sarge.ID] = 36, _234) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_235 = {}, _235[heroes.Sarge.ID] = 5, _235) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Sarge.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_44 = roundsStats; _i < roundsStats_44.length; _i++) {
                    var round = roundsStats_44[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Sarge_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50532, 50032],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59043,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59045,
        Alias: "contextual_talent_marathone_sarge",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.SargeSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59045,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_236 = {}, _236[heroes.Sarge.ID] = 31, _236) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_237 = {}, _237[heroes.Sarge.ID] = 5, _237) }) } },
            70: { loot: new Loot({ Currencies: (_238 = {}, _238[CURRENCY.COIN] = 8000, _238) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_239 = {}, _239[heroes.Sarge.ID] = 50, _239) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_240 = {}, _240[heroes.Sarge.ID] = 100, _240) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_241 = {}, _241[heroes.Sarge.ID] = 15, _241) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Sarge.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_45 = roundsStats; _i < roundsStats_45.length; _i++) {
                    var round = roundsStats_45[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Lynx_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50533, 50033],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59046,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59046,
        Alias: "contextual_talent_marathone_lynx",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LynxSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59046,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_242 = {}, _242[heroes.Lynx.ID] = 5, _242) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_243 = {}, _243[heroes.Lynx.ID] = 5, _243) }) } },
            120: { loot: new Loot({ Currencies: (_244 = {}, _244[CURRENCY.COIN] = 1500, _244) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_245 = {}, _245[heroes.Lynx.ID] = 8, _245) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_246 = {}, _246[heroes.Lynx.ID] = 5, _246) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Lynx.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_46 = roundsStats; _i < roundsStats_46.length; _i++) {
                    var round = roundsStats_46[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Lynx_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50533, 50033],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59046,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59047,
        Alias: "contextual_talent_marathone_lynx",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LynxSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59047,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_247 = {}, _247[heroes.Lynx.ID] = 5, _247) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_248 = {}, _248[heroes.Lynx.ID] = 5, _248) }) } },
            70: { loot: new Loot({ Currencies: (_249 = {}, _249[CURRENCY.COIN] = 3000, _249) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_250 = {}, _250[heroes.Lynx.ID] = 8, _250) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_251 = {}, _251[heroes.Lynx.ID] = 15, _251) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_252 = {}, _252[heroes.Lynx.ID] = 5, _252) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Lynx.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_47 = roundsStats; _i < roundsStats_47.length; _i++) {
                    var round = roundsStats_47[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Lynx_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50533, 50033],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59046,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59048,
        Alias: "contextual_talent_marathone_lynx",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LynxSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59048,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_253 = {}, _253[heroes.Lynx.ID] = 13, _253) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_254 = {}, _254[heroes.Lynx.ID] = 5, _254) }) } },
            70: { loot: new Loot({ Currencies: (_255 = {}, _255[CURRENCY.COIN] = 8000, _255) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_256 = {}, _256[heroes.Lynx.ID] = 15, _256) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_257 = {}, _257[heroes.Lynx.ID] = 30, _257) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_258 = {}, _258[heroes.Lynx.ID] = 15, _258) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Lynx.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_48 = roundsStats; _i < roundsStats_48.length; _i++) {
                    var round = roundsStats_48[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Viper_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50534, 50034],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59049,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59049,
        Alias: "contextual_talent_marathone_cobra",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ViperSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59049,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_259 = {}, _259[heroes.Viper.ID] = 11, _259) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_260 = {}, _260[heroes.Viper.ID] = 5, _260) }) } },
            80: { loot: new Loot({ Currencies: (_261 = {}, _261[CURRENCY.COIN] = 1500, _261) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_262 = {}, _262[heroes.Viper.ID] = 15, _262) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_263 = {}, _263[heroes.Viper.ID] = 5, _263) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_264 = {}, _264[heroes.Viper.ID] = 30, _264) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Viper.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_49 = roundsStats; _i < roundsStats_49.length; _i++) {
                    var round = roundsStats_49[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Viper_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50534, 50034],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59049,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59050,
        Alias: "contextual_talent_marathone_cobra",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ViperSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59050,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_265 = {}, _265[heroes.Viper.ID] = 20, _265) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_266 = {}, _266[heroes.Viper.ID] = 5, _266) }) } },
            70: { loot: new Loot({ Currencies: (_267 = {}, _267[CURRENCY.COIN] = 3000, _267) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_268 = {}, _268[heroes.Viper.ID] = 25, _268) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_269 = {}, _269[heroes.Viper.ID] = 36, _269) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_270 = {}, _270[heroes.Viper.ID] = 5, _270) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Viper.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_50 = roundsStats; _i < roundsStats_50.length; _i++) {
                    var round = roundsStats_50[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Viper_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50534, 50034],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59049,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59051,
        Alias: "contextual_talent_marathone_cobra",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ViperSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59051,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_271 = {}, _271[heroes.Viper.ID] = 31, _271) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_272 = {}, _272[heroes.Viper.ID] = 5, _272) }) } },
            70: { loot: new Loot({ Currencies: (_273 = {}, _273[CURRENCY.COIN] = 8000, _273) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_274 = {}, _274[heroes.Viper.ID] = 50, _274) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_275 = {}, _275[heroes.Viper.ID] = 100, _275) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_276 = {}, _276[heroes.Viper.ID] = 15, _276) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Viper.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_51 = roundsStats; _i < roundsStats_51.length; _i++) {
                    var round = roundsStats_51[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Monkey_King_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50535, 50035],
            conditions: {},
            incompatibilityGroup: 59052,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59052,
        Alias: "contextual_talent_marathone_monkeyking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Monkey_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59052,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_277 = {}, _277[heroes.Monkey_King.ID] = 2, _277) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_278 = {}, _278[heroes.Monkey_King.ID] = 5, _278) }) } },
            120: { loot: new Loot({ Currencies: (_279 = {}, _279[CURRENCY.COIN] = 1500, _279) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_280 = {}, _280[heroes.Monkey_King.ID] = 3, _280) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_281 = {}, _281[heroes.Monkey_King.ID] = 5, _281) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monkey_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_52 = roundsStats; _i < roundsStats_52.length; _i++) {
                    var round = roundsStats_52[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Monkey_King_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50535, 50035],
            conditions: {},
            incompatibilityGroup: 59052,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59053,
        Alias: "contextual_talent_marathone_monkeyking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Monkey_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59053,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_282 = {}, _282[heroes.Monkey_King.ID] = 5, _282) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_283 = {}, _283[heroes.Monkey_King.ID] = 5, _283) }) } },
            100: { loot: new Loot({ Currencies: (_284 = {}, _284[CURRENCY.COIN] = 3000, _284) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_285 = {}, _285[heroes.Monkey_King.ID] = 5, _285) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_286 = {}, _286[heroes.Monkey_King.ID] = 5, _286) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monkey_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_53 = roundsStats; _i < roundsStats_53.length; _i++) {
                    var round = roundsStats_53[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Monkey_King_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50535, 50035],
            conditions: {},
            incompatibilityGroup: 59052,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59054,
        Alias: "contextual_talent_marathone_monkeyking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Monkey_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59054,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_287 = {}, _287[heroes.Monkey_King.ID] = 5, _287) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_288 = {}, _288[heroes.Monkey_King.ID] = 10, _288) }) } },
            70: { loot: new Loot({ Currencies: (_289 = {}, _289[CURRENCY.COIN] = 8000, _289) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_290 = {}, _290[heroes.Monkey_King.ID] = 10, _290) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_291 = {}, _291[heroes.Monkey_King.ID] = 15, _291) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_292 = {}, _292[heroes.Monkey_King.ID] = 15, _292) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monkey_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_54 = roundsStats; _i < roundsStats_54.length; _i++) {
                    var round = roundsStats_54[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Legion_King_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50536, 50036],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59055,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59055,
        Alias: "contextual_talent_marathone_legionking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Legion_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59055,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_293 = {}, _293[heroes.Legion_King.ID] = 2, _293) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_294 = {}, _294[heroes.Legion_King.ID] = 5, _294) }) } },
            120: { loot: new Loot({ Currencies: (_295 = {}, _295[CURRENCY.COIN] = 1500, _295) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_296 = {}, _296[heroes.Legion_King.ID] = 3, _296) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_297 = {}, _297[heroes.Legion_King.ID] = 5, _297) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Legion_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_55 = roundsStats; _i < roundsStats_55.length; _i++) {
                    var round = roundsStats_55[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Legion_King_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50536, 50036],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59055,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59056,
        Alias: "contextual_talent_marathone_legionking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Legion_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59056,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_298 = {}, _298[heroes.Legion_King.ID] = 5, _298) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_299 = {}, _299[heroes.Legion_King.ID] = 5, _299) }) } },
            100: { loot: new Loot({ Currencies: (_300 = {}, _300[CURRENCY.COIN] = 3000, _300) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_301 = {}, _301[heroes.Legion_King.ID] = 5, _301) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_302 = {}, _302[heroes.Legion_King.ID] = 5, _302) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Legion_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_56 = roundsStats; _i < roundsStats_56.length; _i++) {
                    var round = roundsStats_56[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Legion_King_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50536, 50036],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59055,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59057,
        Alias: "contextual_talent_marathone_legionking",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Legion_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59057,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_303 = {}, _303[heroes.Legion_King.ID] = 5, _303) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_304 = {}, _304[heroes.Legion_King.ID] = 10, _304) }) } },
            70: { loot: new Loot({ Currencies: (_305 = {}, _305[CURRENCY.COIN] = 8000, _305) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_306 = {}, _306[heroes.Legion_King.ID] = 10, _306) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_307 = {}, _307[heroes.Legion_King.ID] = 15, _307) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_308 = {}, _308[heroes.Legion_King.ID] = 15, _308) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Legion_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_57 = roundsStats; _i < roundsStats_57.length; _i++) {
                    var round = roundsStats_57[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Butcher_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50537, 50037],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59058,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59058,
        Alias: "contextual_talent_marathone_butcher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ButcherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59058,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_309 = {}, _309[heroes.Butcher.ID] = 5, _309) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_310 = {}, _310[heroes.Butcher.ID] = 5, _310) }) } },
            120: { loot: new Loot({ Currencies: (_311 = {}, _311[CURRENCY.COIN] = 1500, _311) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_312 = {}, _312[heroes.Butcher.ID] = 8, _312) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_313 = {}, _313[heroes.Butcher.ID] = 5, _313) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Butcher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_58 = roundsStats; _i < roundsStats_58.length; _i++) {
                    var round = roundsStats_58[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Butcher_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50537, 50037],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59058,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59059,
        Alias: "contextual_talent_marathone_butcher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ButcherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59059,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_314 = {}, _314[heroes.Butcher.ID] = 5, _314) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_315 = {}, _315[heroes.Butcher.ID] = 5, _315) }) } },
            70: { loot: new Loot({ Currencies: (_316 = {}, _316[CURRENCY.COIN] = 3000, _316) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_317 = {}, _317[heroes.Butcher.ID] = 8, _317) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_318 = {}, _318[heroes.Butcher.ID] = 15, _318) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_319 = {}, _319[heroes.Butcher.ID] = 5, _319) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Butcher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_59 = roundsStats; _i < roundsStats_59.length; _i++) {
                    var round = roundsStats_59[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Butcher_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50537, 50037],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59058,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59060,
        Alias: "contextual_talent_marathone_butcher",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ButcherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59060,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_320 = {}, _320[heroes.Butcher.ID] = 13, _320) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_321 = {}, _321[heroes.Butcher.ID] = 5, _321) }) } },
            70: { loot: new Loot({ Currencies: (_322 = {}, _322[CURRENCY.COIN] = 8000, _322) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_323 = {}, _323[heroes.Butcher.ID] = 15, _323) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_324 = {}, _324[heroes.Butcher.ID] = 30, _324) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_325 = {}, _325[heroes.Butcher.ID] = 15, _325) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Butcher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_60 = roundsStats; _i < roundsStats_60.length; _i++) {
                    var round = roundsStats_60[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Itu_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50539, 50039],
            conditions: {},
            incompatibilityGroup: 59061,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59061,
        Alias: "contextual_talent_marathone_itu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ItuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59061,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_326 = {}, _326[heroes.Itu.ID] = 2, _326) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_327 = {}, _327[heroes.Itu.ID] = 5, _327) }) } },
            120: { loot: new Loot({ Currencies: (_328 = {}, _328[CURRENCY.COIN] = 1500, _328) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_329 = {}, _329[heroes.Itu.ID] = 3, _329) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_330 = {}, _330[heroes.Itu.ID] = 5, _330) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Itu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_61 = roundsStats; _i < roundsStats_61.length; _i++) {
                    var round = roundsStats_61[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Itu_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50539, 50039],
            conditions: {},
            incompatibilityGroup: 59061,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59062,
        Alias: "contextual_talent_marathone_itu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ItuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59062,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_331 = {}, _331[heroes.Itu.ID] = 5, _331) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_332 = {}, _332[heroes.Itu.ID] = 5, _332) }) } },
            100: { loot: new Loot({ Currencies: (_333 = {}, _333[CURRENCY.COIN] = 3000, _333) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_334 = {}, _334[heroes.Itu.ID] = 5, _334) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_335 = {}, _335[heroes.Itu.ID] = 5, _335) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Itu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_62 = roundsStats; _i < roundsStats_62.length; _i++) {
                    var round = roundsStats_62[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Itu_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50539, 50039],
            conditions: {},
            incompatibilityGroup: 59061,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59063,
        Alias: "contextual_talent_marathone_itu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ItuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59063,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_336 = {}, _336[heroes.Itu.ID] = 5, _336) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_337 = {}, _337[heroes.Itu.ID] = 10, _337) }) } },
            70: { loot: new Loot({ Currencies: (_338 = {}, _338[CURRENCY.COIN] = 8000, _338) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_339 = {}, _339[heroes.Itu.ID] = 10, _339) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_340 = {}, _340[heroes.Itu.ID] = 15, _340) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_341 = {}, _341[heroes.Itu.ID] = 15, _341) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Itu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_63 = roundsStats; _i < roundsStats_63.length; _i++) {
                    var round = roundsStats_63[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yunlin_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50542, 50042],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59064,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59064,
        Alias: "contextual_talent_marathone_Yunlin",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YunlinSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59064,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_342 = {}, _342[heroes.Yunlin.ID] = 11, _342) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_343 = {}, _343[heroes.Yunlin.ID] = 5, _343) }) } },
            80: { loot: new Loot({ Currencies: (_344 = {}, _344[CURRENCY.COIN] = 1500, _344) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_345 = {}, _345[heroes.Yunlin.ID] = 15, _345) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_346 = {}, _346[heroes.Yunlin.ID] = 5, _346) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_347 = {}, _347[heroes.Yunlin.ID] = 30, _347) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yunlin.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_64 = roundsStats; _i < roundsStats_64.length; _i++) {
                    var round = roundsStats_64[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yunlin_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50542, 50042],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59064,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59065,
        Alias: "contextual_talent_marathone_Yunlin",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YunlinSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59065,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_348 = {}, _348[heroes.Yunlin.ID] = 20, _348) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_349 = {}, _349[heroes.Yunlin.ID] = 5, _349) }) } },
            70: { loot: new Loot({ Currencies: (_350 = {}, _350[CURRENCY.COIN] = 3000, _350) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_351 = {}, _351[heroes.Yunlin.ID] = 25, _351) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_352 = {}, _352[heroes.Yunlin.ID] = 36, _352) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_353 = {}, _353[heroes.Yunlin.ID] = 5, _353) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yunlin.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_65 = roundsStats; _i < roundsStats_65.length; _i++) {
                    var round = roundsStats_65[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Yunlin_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50542, 50042],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59064,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59066,
        Alias: "contextual_talent_marathone_Yunlin",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YunlinSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59066,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_354 = {}, _354[heroes.Yunlin.ID] = 31, _354) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_355 = {}, _355[heroes.Yunlin.ID] = 5, _355) }) } },
            70: { loot: new Loot({ Currencies: (_356 = {}, _356[CURRENCY.COIN] = 8000, _356) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_357 = {}, _357[heroes.Yunlin.ID] = 50, _357) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_358 = {}, _358[heroes.Yunlin.ID] = 100, _358) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_359 = {}, _359[heroes.Yunlin.ID] = 15, _359) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yunlin.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_66 = roundsStats; _i < roundsStats_66.length; _i++) {
                    var round = roundsStats_66[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Xiang_Tzu_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50544, 50044],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59067,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59067,
        Alias: "contextual_talent_marathone_xiang_tzu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Xiang_TzuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59067,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_360 = {}, _360[heroes.Xiang_Tzu.ID] = 5, _360) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_361 = {}, _361[heroes.Xiang_Tzu.ID] = 5, _361) }) } },
            120: { loot: new Loot({ Currencies: (_362 = {}, _362[CURRENCY.COIN] = 1500, _362) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_363 = {}, _363[heroes.Xiang_Tzu.ID] = 8, _363) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_364 = {}, _364[heroes.Xiang_Tzu.ID] = 5, _364) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Xiang_Tzu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_67 = roundsStats; _i < roundsStats_67.length; _i++) {
                    var round = roundsStats_67[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Xiang_Tzu_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50544, 50044],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59067,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59068,
        Alias: "contextual_talent_marathone_xiang_tzu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Xiang_TzuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59068,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_365 = {}, _365[heroes.Xiang_Tzu.ID] = 5, _365) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_366 = {}, _366[heroes.Xiang_Tzu.ID] = 5, _366) }) } },
            70: { loot: new Loot({ Currencies: (_367 = {}, _367[CURRENCY.COIN] = 3000, _367) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_368 = {}, _368[heroes.Xiang_Tzu.ID] = 8, _368) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_369 = {}, _369[heroes.Xiang_Tzu.ID] = 15, _369) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_370 = {}, _370[heroes.Xiang_Tzu.ID] = 5, _370) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Xiang_Tzu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_68 = roundsStats; _i < roundsStats_68.length; _i++) {
                    var round = roundsStats_68[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Xiang_Tzu_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50544, 50044],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59067,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59069,
        Alias: "contextual_talent_marathone_xiang_tzu",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Xiang_TzuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59069,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_371 = {}, _371[heroes.Xiang_Tzu.ID] = 13, _371) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_372 = {}, _372[heroes.Xiang_Tzu.ID] = 5, _372) }) } },
            70: { loot: new Loot({ Currencies: (_373 = {}, _373[CURRENCY.COIN] = 8000, _373) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_374 = {}, _374[heroes.Xiang_Tzu.ID] = 15, _374) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_375 = {}, _375[heroes.Xiang_Tzu.ID] = 30, _375) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_376 = {}, _376[heroes.Xiang_Tzu.ID] = 15, _376) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Xiang_Tzu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_69 = roundsStats; _i < roundsStats_69.length; _i++) {
                    var round = roundsStats_69[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_June_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50545, 50045],
            conditions: {},
            incompatibilityGroup: 59070,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59070,
        Alias: "contextual_talent_marathone_june",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JuneSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59070,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_377 = {}, _377[heroes.June.ID] = 2, _377) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_378 = {}, _378[heroes.June.ID] = 5, _378) }) } },
            120: { loot: new Loot({ Currencies: (_379 = {}, _379[CURRENCY.COIN] = 1500, _379) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_380 = {}, _380[heroes.June.ID] = 3, _380) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_381 = {}, _381[heroes.June.ID] = 5, _381) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.June.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_70 = roundsStats; _i < roundsStats_70.length; _i++) {
                    var round = roundsStats_70[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_June_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50545, 50045],
            conditions: {},
            incompatibilityGroup: 59070,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59071,
        Alias: "contextual_talent_marathone_june",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JuneSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59071,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_382 = {}, _382[heroes.June.ID] = 5, _382) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_383 = {}, _383[heroes.June.ID] = 5, _383) }) } },
            100: { loot: new Loot({ Currencies: (_384 = {}, _384[CURRENCY.COIN] = 3000, _384) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_385 = {}, _385[heroes.June.ID] = 5, _385) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_386 = {}, _386[heroes.June.ID] = 5, _386) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.June.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_71 = roundsStats; _i < roundsStats_71.length; _i++) {
                    var round = roundsStats_71[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_June_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50545, 50045],
            conditions: {},
            incompatibilityGroup: 59070,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59072,
        Alias: "contextual_talent_marathone_june",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JuneSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59072,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_387 = {}, _387[heroes.June.ID] = 5, _387) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_388 = {}, _388[heroes.June.ID] = 10, _388) }) } },
            70: { loot: new Loot({ Currencies: (_389 = {}, _389[CURRENCY.COIN] = 8000, _389) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_390 = {}, _390[heroes.June.ID] = 10, _390) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_391 = {}, _391[heroes.June.ID] = 15, _391) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_392 = {}, _392[heroes.June.ID] = 15, _392) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.June.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_72 = roundsStats; _i < roundsStats_72.length; _i++) {
                    var round = roundsStats_72[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ling_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50517, 50017],
            conditions: {},
            incompatibilityGroup: 59073,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59073,
        Alias: "contextual_talent_marathone_ling",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59073,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_393 = {}, _393[heroes.Ling.ID] = 11, _393) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_394 = {}, _394[heroes.Ling.ID] = 5, _394) }) } },
            80: { loot: new Loot({ Currencies: (_395 = {}, _395[CURRENCY.COIN] = 1500, _395) }) },
            130: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_396 = {}, _396[heroes.Ling.ID] = 15, _396) }) } },
            190: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_397 = {}, _397[heroes.Ling.ID] = 5, _397) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_398 = {}, _398[heroes.Ling.ID] = 30, _398) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ling.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_73 = roundsStats; _i < roundsStats_73.length; _i++) {
                    var round = roundsStats_73[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ling_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50517, 50017],
            conditions: {},
            incompatibilityGroup: 59073,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59074,
        Alias: "contextual_talent_marathone_ling",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59074,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_399 = {}, _399[heroes.Ling.ID] = 20, _399) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_400 = {}, _400[heroes.Ling.ID] = 5, _400) }) } },
            70: { loot: new Loot({ Currencies: (_401 = {}, _401[CURRENCY.COIN] = 3000, _401) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_402 = {}, _402[heroes.Ling.ID] = 25, _402) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_403 = {}, _403[heroes.Ling.ID] = 36, _403) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_404 = {}, _404[heroes.Ling.ID] = 5, _404) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ling.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_74 = roundsStats; _i < roundsStats_74.length; _i++) {
                    var round = roundsStats_74[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Ling_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50517, 50017],
            conditions: {},
            incompatibilityGroup: 59073,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59075,
        Alias: "contextual_talent_marathone_ling",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59075,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_405 = {}, _405[heroes.Ling.ID] = 31, _405) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_406 = {}, _406[heroes.Ling.ID] = 5, _406) }) } },
            70: { loot: new Loot({ Currencies: (_407 = {}, _407[CURRENCY.COIN] = 8000, _407) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_408 = {}, _408[heroes.Ling.ID] = 50, _408) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_409 = {}, _409[heroes.Ling.ID] = 100, _409) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_410 = {}, _410[heroes.Ling.ID] = 15, _410) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ling.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_75 = roundsStats; _i < roundsStats_75.length; _i++) {
                    var round = roundsStats_75[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Gideon_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50546],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59076,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59076,
        Alias: "contextual_talent_marathone_gideon",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.GideonSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59076,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_411 = {}, _411[heroes.Gideon.ID] = 5, _411) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_412 = {}, _412[heroes.Gideon.ID] = 5, _412) }) } },
            120: { loot: new Loot({ Currencies: (_413 = {}, _413[CURRENCY.COIN] = 1500, _413) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_414 = {}, _414[heroes.Gideon.ID] = 8, _414) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_415 = {}, _415[heroes.Gideon.ID] = 5, _415) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Gideon.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_76 = roundsStats; _i < roundsStats_76.length; _i++) {
                    var round = roundsStats_76[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Gideon_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50546],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59076,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59077,
        Alias: "contextual_talent_marathone_gideon",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.GideonSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59077,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_416 = {}, _416[heroes.Gideon.ID] = 5, _416) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_417 = {}, _417[heroes.Gideon.ID] = 5, _417) }) } },
            70: { loot: new Loot({ Currencies: (_418 = {}, _418[CURRENCY.COIN] = 3000, _418) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_419 = {}, _419[heroes.Gideon.ID] = 8, _419) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_420 = {}, _420[heroes.Gideon.ID] = 15, _420) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_421 = {}, _421[heroes.Gideon.ID] = 5, _421) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Gideon.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_77 = roundsStats; _i < roundsStats_77.length; _i++) {
                    var round = roundsStats_77[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Gideon_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50546],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59076,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59078,
        Alias: "contextual_talent_marathone_gideon",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.GideonSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonSettings: {
            offerId: 59078,
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_422 = {}, _422[heroes.Gideon.ID] = 13, _422) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_423 = {}, _423[heroes.Gideon.ID] = 5, _423) }) } },
            70: { loot: new Loot({ Currencies: (_424 = {}, _424[CURRENCY.COIN] = 8000, _424) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_425 = {}, _425[heroes.Gideon.ID] = 15, _425) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_426 = {}, _426[heroes.Gideon.ID] = 30, _426) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_427 = {}, _427[heroes.Gideon.ID] = 15, _427) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Gideon.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_78 = roundsStats; _i < roundsStats_78.length; _i++) {
                    var round = roundsStats_78[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Widow_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50547],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59079,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59079,
        Alias: "contextual_talent_marathone_Widow",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.WidowSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{ points: 0, offer: { offerId: 59079, inApp: inAppSettings.PRICE_6.ProductID, offerName: "paid_marathon_contextual_widow_cheap" } }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_428 = {}, _428[heroes.Widow.ID] = 5, _428) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_429 = {}, _429[heroes.Widow.ID] = 5, _429) }) } },
            120: { loot: new Loot({ Currencies: (_430 = {}, _430[CURRENCY.COIN] = 1500, _430) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_431 = {}, _431[heroes.Widow.ID] = 8, _431) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_432 = {}, _432[heroes.Widow.ID] = 5, _432) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Widow.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_79 = roundsStats; _i < roundsStats_79.length; _i++) {
                    var round = roundsStats_79[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Widow_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50547],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59079,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59080,
        Alias: "contextual_talent_marathone_Widow",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.WidowSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{ points: 0, offer: { offerId: 59080, inApp: inAppSettings.PRICE_15.ProductID, offerName: "paid_marathon_contextual_widow_medium" } }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_433 = {}, _433[heroes.Widow.ID] = 5, _433) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_434 = {}, _434[heroes.Widow.ID] = 5, _434) }) } },
            70: { loot: new Loot({ Currencies: (_435 = {}, _435[CURRENCY.COIN] = 3000, _435) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_436 = {}, _436[heroes.Widow.ID] = 8, _436) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_437 = {}, _437[heroes.Widow.ID] = 15, _437) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_438 = {}, _438[heroes.Widow.ID] = 5, _438) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Widow.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_80 = roundsStats; _i < roundsStats_80.length; _i++) {
                    var round = roundsStats_80[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Widow_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50547],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59079,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59081,
        Alias: "contextual_talent_marathone_Widow",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.WidowSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{ points: 0, offer: { offerId: 59081, inApp: inAppSettings.PRICE_25.ProductID, offerName: "paid_marathon_contextual_widow_expensive" } }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_439 = {}, _439[heroes.Widow.ID] = 13, _439) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_440 = {}, _440[heroes.Widow.ID] = 5, _440) }) } },
            70: { loot: new Loot({ Currencies: (_441 = {}, _441[CURRENCY.COIN] = 8000, _441) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_442 = {}, _442[heroes.Widow.ID] = 15, _442) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_443 = {}, _443[heroes.Widow.ID] = 30, _443) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_444 = {}, _444[heroes.Widow.ID] = 15, _444) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Widow.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_81 = roundsStats; _i < roundsStats_81.length; _i++) {
                    var round = roundsStats_81[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Raikichi_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50548],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59082,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59082,
        Alias: "contextual_talent_marathone_raikichi",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.RaikichiSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59082,
                        inApp: inAppSettings.PRICE_6.ProductID,
                        offerName: "paid_marathon_contextual_raikichi_cheap"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_445 = {}, _445[heroes.Raikichi.ID] = 5, _445) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_446 = {}, _446[heroes.Raikichi.ID] = 5, _446) }) } },
            120: { loot: new Loot({ Currencies: (_447 = {}, _447[CURRENCY.COIN] = 1500, _447) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_448 = {}, _448[heroes.Raikichi.ID] = 8, _448) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_449 = {}, _449[heroes.Raikichi.ID] = 5, _449) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Raikichi.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_82 = roundsStats; _i < roundsStats_82.length; _i++) {
                    var round = roundsStats_82[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Raikichi_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50548],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59082,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59083,
        Alias: "contextual_talent_marathone_raikichi",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.RaikichiSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59083,
                        inApp: inAppSettings.PRICE_15.ProductID,
                        offerName: "paid_marathon_contextual_raikichi_medium"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_450 = {}, _450[heroes.Raikichi.ID] = 5, _450) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_451 = {}, _451[heroes.Raikichi.ID] = 5, _451) }) } },
            70: { loot: new Loot({ Currencies: (_452 = {}, _452[CURRENCY.COIN] = 3000, _452) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_453 = {}, _453[heroes.Raikichi.ID] = 8, _453) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_454 = {}, _454[heroes.Raikichi.ID] = 15, _454) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_455 = {}, _455[heroes.Raikichi.ID] = 5, _455) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Raikichi.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_83 = roundsStats; _i < roundsStats_83.length; _i++) {
                    var round = roundsStats_83[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Raikichi_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50548],
            conditions: {
                accountLevel: { more_or_equal: 1 },
            },
            incompatibilityGroup: 59082,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59084,
        Alias: "contextual_talent_marathone_raikichi",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.RaikichiSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59084,
                        inApp: inAppSettings.PRICE_25.ProductID,
                        offerName: "paid_marathon_contextual_raikichi_expensive"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_456 = {}, _456[heroes.Raikichi.ID] = 13, _456) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_457 = {}, _457[heroes.Raikichi.ID] = 5, _457) }) } },
            70: { loot: new Loot({ Currencies: (_458 = {}, _458[CURRENCY.COIN] = 8000, _458) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_459 = {}, _459[heroes.Raikichi.ID] = 15, _459) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_460 = {}, _460[heroes.Raikichi.ID] = 30, _460) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_461 = {}, _461[heroes.Raikichi.ID] = 15, _461) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Raikichi.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_84 = roundsStats; _i < roundsStats_84.length; _i++) {
                    var round = roundsStats_84[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Nonna_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50549],
            conditions: {},
            incompatibilityGroup: 59085,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59085,
        Alias: "contextual_talent_marathone_Nonna",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.NonnaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59085,
                        inApp: inAppSettings.PRICE_7.ProductID,
                        offerName: "paid_marathon_contextual_nonna_cheap"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_462 = {}, _462[heroes.Nonna.ID] = 2, _462) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_463 = {}, _463[heroes.Nonna.ID] = 5, _463) }) } },
            120: { loot: new Loot({ Currencies: (_464 = {}, _464[CURRENCY.COIN] = 1500, _464) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_465 = {}, _465[heroes.Nonna.ID] = 3, _465) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_466 = {}, _466[heroes.Nonna.ID] = 5, _466) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Nonna.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_85 = roundsStats; _i < roundsStats_85.length; _i++) {
                    var round = roundsStats_85[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Nonna_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50549],
            conditions: {},
            incompatibilityGroup: 59085,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59086,
        Alias: "contextual_talent_marathone_Nonna",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.NonnaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59086,
                        inApp: inAppSettings.PRICE_20.ProductID,
                        offerName: "paid_marathon_contextual_nonna_medium"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_467 = {}, _467[heroes.Nonna.ID] = 5, _467) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_468 = {}, _468[heroes.Nonna.ID] = 5, _468) }) } },
            100: { loot: new Loot({ Currencies: (_469 = {}, _469[CURRENCY.COIN] = 3000, _469) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_470 = {}, _470[heroes.Nonna.ID] = 5, _470) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_471 = {}, _471[heroes.Nonna.ID] = 5, _471) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Nonna.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_86 = roundsStats; _i < roundsStats_86.length; _i++) {
                    var round = roundsStats_86[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Nonna_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50549],
            conditions: {},
            incompatibilityGroup: 59085,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59087,
        Alias: "contextual_talent_marathone_Nonna",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.NonnaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59087,
                        inApp: inAppSettings.PRICE_40.ProductID,
                        offerName: "paid_marathon_contextual_nonna_expensive"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_472 = {}, _472[heroes.Nonna.ID] = 5, _472) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_473 = {}, _473[heroes.Nonna.ID] = 10, _473) }) } },
            70: { loot: new Loot({ Currencies: (_474 = {}, _474[CURRENCY.COIN] = 8000, _474) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_475 = {}, _475[heroes.Nonna.ID] = 10, _475) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_476 = {}, _476[heroes.Nonna.ID] = 15, _476) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_477 = {}, _477[heroes.Nonna.ID] = 15, _477) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Nonna.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_87 = roundsStats; _i < roundsStats_87.length; _i++) {
                    var round = roundsStats_87[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Shogun_cheap: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50550],
            conditions: {},
            incompatibilityGroup: 59088,
            sp: { min: 0, max: 9.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59088,
        Alias: "contextual_talent_marathone_Shogun",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ShogunSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59088,
                        inApp: inAppSettings.PRICE_7.ProductID,
                        offerName: "paid_marathon_contextual_shogun_cheap"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_478 = {}, _478[heroes.Shogun.ID] = 2, _478) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_479 = {}, _479[heroes.Shogun.ID] = 5, _479) }) } },
            120: { loot: new Loot({ Currencies: (_480 = {}, _480[CURRENCY.COIN] = 1500, _480) }) },
            180: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_481 = {}, _481[heroes.Shogun.ID] = 3, _481) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_482 = {}, _482[heroes.Shogun.ID] = 5, _482) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Shogun.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_88 = roundsStats; _i < roundsStats_88.length; _i++) {
                    var round = roundsStats_88[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Shogun_medium: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50550],
            conditions: {},
            incompatibilityGroup: 59088,
            sp: { min: 10, max: 149.99 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59089,
        Alias: "contextual_talent_marathone_Shogun",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ShogunSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59089,
                        inApp: inAppSettings.PRICE_20.ProductID,
                        offerName: "paid_marathon_contextual_shogun_medium"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_483 = {}, _483[heroes.Shogun.ID] = 5, _483) }) } },
            60: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_484 = {}, _484[heroes.Shogun.ID] = 5, _484) }) } },
            100: { loot: new Loot({ Currencies: (_485 = {}, _485[CURRENCY.COIN] = 3000, _485) }) },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_486 = {}, _486[heroes.Shogun.ID] = 5, _486) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_487 = {}, _487[heroes.Shogun.ID] = 5, _487) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Shogun.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_89 = roundsStats; _i < roundsStats_89.length; _i++) {
                    var round = roundsStats_89[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Contextual_ShardMarathon_Shogun_expensive: new Marathon({
        PromoSettings: {
            completedPreviousMarathons: [50550],
            conditions: {},
            incompatibilityGroup: 59088,
            sp: { min: 150, max: 999999 },
            activeTime: {
                duration: new Time({ Days: 7 }).value
            },
        },
        ID: 59090,
        Alias: "contextual_talent_marathone_Shogun",
        Description: "contextual_talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ShogunSM,
        MarathonType: MARATHON_TYPE.HEROES,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 59090,
                        inApp: inAppSettings.PRICE_40.ProductID,
                        offerName: "paid_marathon_contextual_shogun_expensive"
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_488 = {}, _488[heroes.Shogun.ID] = 5, _488) }) } },
            40: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_489 = {}, _489[heroes.Shogun.ID] = 10, _489) }) } },
            70: { loot: new Loot({ Currencies: (_490 = {}, _490[CURRENCY.COIN] = 8000, _490) }) },
            110: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_491 = {}, _491[heroes.Shogun.ID] = 10, _491) }) } },
            150: { chests: [chests.Epic_chest.ID] },
            200: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_492 = {}, _492[heroes.Shogun.ID] = 15, _492) }) } },
            250: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_493 = {}, _493[heroes.Shogun.ID] = 15, _493) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Shogun.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_90 = roundsStats; _i < roundsStats_90.length; _i++) {
                    var round = roundsStats_90[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
}, true);
