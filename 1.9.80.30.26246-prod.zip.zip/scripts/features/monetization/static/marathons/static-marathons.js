var _a, _b, _c, _d, _e, _f, _g, _h;
extend(Marathons, {
    PromoMarathon_weapon: new Marathon({
        PromoSettings: {
            conditions: {
                playerArenaId: { more_or_equal: 4 }
            },
            activeTime: {
                duration: new Time({ Days: 90 }).value,
            },
        },
        ID: 50004,
        Alias: "marathon_weaponPreview_title",
        Description: "marathon_weaponPreview_desc",
        PointsDescription: 'marathon_weaponPreview_descPoints',
        ViewConfig: MarathonView.UsualMarathon,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 250, _a) }) },
            500: { isHidden: true, lootSettings: { CardsSlots: { TotalCards: 20, TotalSlots: 1, Rarities: (_b = {}, _b[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 20 }] }, _b) } } },
            1000: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 50, _c) }) },
            1500: { isHidden: false, loot: new Loot({ HeroExp: (_d = {}, _d[heroes.Ling.ID] = 20, _d) }) },
            2500: { chests: [chests.Epic_chest.ID] },
            4000: { isHidden: false, loot: new Loot({ Weapons: [heroWeapons.wpn_Ling_R_RedBlade.ID] }) },
        },
        UpdateEvents: [QUEST_EVENT.GETTING_LOOT],
        Update: function (args) {
            var points = 0;
            if (args.Event == QUEST_EVENT.GETTING_LOOT) {
                var loot = LootUtils.getLootFromRaw(args.Loot || new Loot());
                var lootBeforeConversion = null;
                if (args.LootBeforeConversion) {
                    lootBeforeConversion = LootUtils.getLootFromRaw(args.LootBeforeConversion);
                }
                var cardsNumber = MarathonUtils.getCardsNumberByRarity(loot, lootBeforeConversion);
                points += cardsNumber[HERO_RARITY.COMMON] * 10;
                points += cardsNumber[HERO_RARITY.RARE] * 25;
                points += cardsNumber[HERO_RARITY.EPIC] * 50;
                points += cardsNumber[HERO_RARITY.LEGENDARY] * 75;
            }
            return args.Progress + points;
        }
    }),
    marathon_rubies: new Marathon({
        ID: 50046,
        PromoSettings: {
            activeTime: {
                duration: new Time({ Days: 3 }).value
            },
            conditions: {
                playerRating: { more_or_equal: 30, less_or_equal: 50 }
            },
        },
        Alias: "currency_rubies",
        Description: "marathon_rubiesPreview_desc",
        PointsDescription: 'marathon_descPoints_onboarding_rubies',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ReferralActivity,
        MarathonType: MARATHON_TYPE.SPECIAL,
        Rewards: {
            50: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.BONUS] = 50, _e) }) },
            100: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 50, _f) }) },
            175: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.BONUS] = 50, _g) }) },
            275: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 75, _h) }) },
            600: { chests: [chests.Epic_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.CURRENCY_WITHDRAW],
        Update: function (args) {
            var checkedCurrency = CURRENCY.BONUS;
            var pointsPerOneCurrency = 1;
            var points = 0;
            var spending = args.CurrencyWithdraw && args.CurrencyWithdraw.Type == checkedCurrency
                ? args.CurrencyWithdraw.Amount
                : 0;
            points += ((spending * pointsPerOneCurrency) >> 0);
            return args.Progress + points;
        }
    })
}, true);
