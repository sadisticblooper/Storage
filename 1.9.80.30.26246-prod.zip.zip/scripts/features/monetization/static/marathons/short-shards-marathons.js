var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155, _156, _157, _158, _159, _160, _161, _162, _163, _164, _165, _166, _167, _168, _169, _170, _171, _172, _173, _174, _175, _176, _177, _178, _179, _180, _181, _182, _183, _184, _185;
extend(Marathons, {
    Short_ShardMarathon_Ling: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_a = {}, _a[heroes.Ling.ID] = { Level: { less_or_equal: heroes.Ling.StartLevel } }, _a),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50517,
        Alias: "talent_marathone_ling",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_b = {}, _b[heroes.Ling.ID] = 4, _b) }) } },
            50: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.COIN] = 150, _c) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_d = {}, _d[heroes.Ling.ID] = 2, _d) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.COIN] = 150, _e) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_f = {}, _f[heroes.Ling.ID] = 4, _f) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_g = {}, _g[heroes.Ling.ID] = 3, _g) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ling.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_1 = roundsStats; _i < roundsStats_1.length; _i++) {
                    var round = roundsStats_1[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Monk: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_h = {}, _h[heroes.Monk.ID] = { Level: { less_or_equal: heroes.Monk.StartLevel } }, _h),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50518,
        Alias: "talent_marathone_monk",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MonkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_j = {}, _j[heroes.Monk.ID] = 4, _j) }) } },
            50: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.COIN] = 100, _k) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_l = {}, _l[heroes.Monk.ID] = 5, _l) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.COIN] = 100, _m) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_o = {}, _o[heroes.Monk.ID] = 5, _o) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_p = {}, _p[heroes.Monk.ID] = 5, _p) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monk.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_2 = roundsStats; _i < roundsStats_2.length; _i++) {
                    var round = roundsStats_2[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Liquidator: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_q = {}, _q[heroes.Liquidator.ID] = { Level: { less_or_equal: heroes.Liquidator.StartLevel } }, _q),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50519,
        Alias: "talent_marathone_kate",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LiquidatorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_r = {}, _r[heroes.Liquidator.ID] = 4, _r) }) } },
            50: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.COIN] = 100, _s) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_t = {}, _t[heroes.Liquidator.ID] = 5, _t) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 100, _u) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_v = {}, _v[heroes.Liquidator.ID] = 5, _v) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_w = {}, _w[heroes.Liquidator.ID] = 5, _w) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Liquidator.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_3 = roundsStats; _i < roundsStats_3.length; _i++) {
                    var round = roundsStats_3[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Ironclad: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_x = {}, _x[heroes.Ironclad.ID] = { Level: { less_or_equal: heroes.Ironclad.StartLevel } }, _x),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50520,
        Alias: "talent_marathone_ironclad",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.IroncladSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_y = {}, _y[heroes.Ironclad.ID] = 4, _y) }) } },
            50: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.COIN] = 100, _z) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_0 = {}, _0[heroes.Ironclad.ID] = 5, _0) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.COIN] = 100, _1) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_2 = {}, _2[heroes.Ironclad.ID] = 5, _2) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_3 = {}, _3[heroes.Ironclad.ID] = 5, _3) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Ironclad.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_4 = roundsStats; _i < roundsStats_4.length; _i++) {
                    var round = roundsStats_4[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Fireguard: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_4 = {}, _4[heroes.Fireguard.ID] = { Level: { less_or_equal: heroes.Fireguard.StartLevel } }, _4),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50521,
        Alias: "talent_marathone_fireguard",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FireguardSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_5 = {}, _5[heroes.Fireguard.ID] = 4, _5) }) } },
            50: { loot: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.COIN] = 100, _6) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_7 = {}, _7[heroes.Fireguard.ID] = 5, _7) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.COIN] = 100, _8) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_9 = {}, _9[heroes.Fireguard.ID] = 5, _9) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_10 = {}, _10[heroes.Fireguard.ID] = 5, _10) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Fireguard.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_5 = roundsStats; _i < roundsStats_5.length; _i++) {
                    var round = roundsStats_5[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Helga: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_11 = {}, _11[heroes.Helga.ID] = { Level: { less_or_equal: heroes.Helga.StartLevel } }, _11),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50522,
        Alias: "talent_marathone_helga",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HelgaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_12 = {}, _12[heroes.Helga.ID] = 4, _12) }) } },
            50: { loot: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.COIN] = 150, _13) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_14 = {}, _14[heroes.Helga.ID] = 2, _14) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_15 = {}, _15[CURRENCY.COIN] = 150, _15) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_16 = {}, _16[heroes.Helga.ID] = 4, _16) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_17 = {}, _17[heroes.Helga.ID] = 3, _17) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Helga.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_6 = roundsStats; _i < roundsStats_6.length; _i++) {
                    var round = roundsStats_6[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Jet: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_18 = {}, _18[heroes.Jet.ID] = { Level: { less_or_equal: heroes.Jet.StartLevel } }, _18),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50523,
        Alias: "talent_marathone_jet",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JetSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_19 = {}, _19[heroes.Jet.ID] = 4, _19) }) } },
            50: { loot: new Loot({ Currencies: (_20 = {}, _20[CURRENCY.COIN] = 150, _20) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_21 = {}, _21[heroes.Jet.ID] = 2, _21) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_22 = {}, _22[CURRENCY.COIN] = 150, _22) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_23 = {}, _23[heroes.Jet.ID] = 4, _23) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_24 = {}, _24[heroes.Jet.ID] = 3, _24) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Jet.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_7 = roundsStats; _i < roundsStats_7.length; _i++) {
                    var round = roundsStats_7[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Feldsher: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_25 = {}, _25[heroes.Feldsher.ID] = { Level: { less_or_equal: heroes.Feldsher.StartLevel } }, _25),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50524,
        Alias: "talent_marathone_feldsher",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.FeldsherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_26 = {}, _26[heroes.Feldsher.ID] = 4, _26) }) } },
            50: { loot: new Loot({ Currencies: (_27 = {}, _27[CURRENCY.COIN] = 100, _27) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_28 = {}, _28[heroes.Feldsher.ID] = 5, _28) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.COIN] = 100, _29) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_30 = {}, _30[heroes.Feldsher.ID] = 5, _30) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_31 = {}, _31[heroes.Feldsher.ID] = 5, _31) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Feldsher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_8 = roundsStats; _i < roundsStats_8.length; _i++) {
                    var round = roundsStats_8[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Yukka: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_32 = {}, _32[heroes.Yukka.ID] = { Level: { less_or_equal: heroes.Yukka.StartLevel } }, _32),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50525,
        Alias: "talent_marathone_yukka",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YukkaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_33 = {}, _33[heroes.Yukka.ID] = 4, _33) }) } },
            50: { loot: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.COIN] = 150, _34) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_35 = {}, _35[heroes.Yukka.ID] = 2, _35) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_36 = {}, _36[CURRENCY.COIN] = 150, _36) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_37 = {}, _37[heroes.Yukka.ID] = 4, _37) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_38 = {}, _38[heroes.Yukka.ID] = 3, _38) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yukka.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_9 = roundsStats; _i < roundsStats_9.length; _i++) {
                    var round = roundsStats_9[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Bulwark: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_39 = {}, _39[heroes.Bulwark.ID] = { Level: { less_or_equal: heroes.Bulwark.StartLevel } }, _39),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50526,
        Alias: "talent_marathone_bulwark",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.BulwarkSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_40 = {}, _40[heroes.Bulwark.ID] = 4, _40) }) } },
            50: { loot: new Loot({ Currencies: (_41 = {}, _41[CURRENCY.COIN] = 100, _41) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_42 = {}, _42[heroes.Bulwark.ID] = 5, _42) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.COIN] = 100, _43) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_44 = {}, _44[heroes.Bulwark.ID] = 5, _44) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_45 = {}, _45[heroes.Bulwark.ID] = 5, _45) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Bulwark.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_10 = roundsStats; _i < roundsStats_10.length; _i++) {
                    var round = roundsStats_10[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Emperor: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_46 = {}, _46[heroes.Emperor.ID] = { Level: { less_or_equal: heroes.Emperor.StartLevel } }, _46),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50527,
        Alias: "talent_marathone_emperor",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.EmperorSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_47 = {}, _47[heroes.Emperor.ID] = 2, _47) }) } },
            50: { loot: new Loot({ Currencies: (_48 = {}, _48[CURRENCY.COIN] = 250, _48) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_49 = {}, _49[heroes.Emperor.ID] = 2, _49) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.COIN] = 250, _50) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_51 = {}, _51[heroes.Emperor.ID] = 4, _51) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_52 = {}, _52[heroes.Emperor.ID] = 3, _52) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Emperor.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_11 = roundsStats; _i < roundsStats_11.length; _i++) {
                    var round = roundsStats_11[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Kibo: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_53 = {}, _53[heroes.Kibo.ID] = { Level: { less_or_equal: heroes.Kibo.StartLevel } }, _53),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50528,
        Alias: "talent_marathone_kibo",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.KiboSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_54 = {}, _54[heroes.Kibo.ID] = 2, _54) }) } },
            50: { loot: new Loot({ Currencies: (_55 = {}, _55[CURRENCY.COIN] = 250, _55) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_56 = {}, _56[heroes.Kibo.ID] = 2, _56) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_57 = {}, _57[CURRENCY.COIN] = 250, _57) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_58 = {}, _58[heroes.Kibo.ID] = 4, _58) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_59 = {}, _59[heroes.Kibo.ID] = 3, _59) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Kibo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_12 = roundsStats; _i < roundsStats_12.length; _i++) {
                    var round = roundsStats_12[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Marcus: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_60 = {}, _60[heroes.Marcus.ID] = { Level: { less_or_equal: heroes.Marcus.StartLevel } }, _60),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50529,
        Alias: "talent_marathone_marcus",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MarcusSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_61 = {}, _61[heroes.Marcus.ID] = 2, _61) }) } },
            50: { loot: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.COIN] = 250, _62) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_63 = {}, _63[heroes.Marcus.ID] = 2, _63) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_64 = {}, _64[CURRENCY.COIN] = 250, _64) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_65 = {}, _65[heroes.Marcus.ID] = 4, _65) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_66 = {}, _66[heroes.Marcus.ID] = 3, _66) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Marcus.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_13 = roundsStats; _i < roundsStats_13.length; _i++) {
                    var round = roundsStats_13[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_HongJoo: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_67 = {}, _67[heroes.HongJoo.ID] = { Level: { less_or_equal: heroes.HongJoo.StartLevel } }, _67),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50530,
        Alias: "talent_marathone_hongjoo",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.HongJooSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_68 = {}, _68[heroes.HongJoo.ID] = 4, _68) }) } },
            50: { loot: new Loot({ Currencies: (_69 = {}, _69[CURRENCY.COIN] = 150, _69) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_70 = {}, _70[heroes.HongJoo.ID] = 2, _70) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_71 = {}, _71[CURRENCY.COIN] = 150, _71) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_72 = {}, _72[heroes.HongJoo.ID] = 4, _72) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_73 = {}, _73[heroes.HongJoo.ID] = 3, _73) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.HongJoo.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_14 = roundsStats; _i < roundsStats_14.length; _i++) {
                    var round = roundsStats_14[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Midnight: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_74 = {}, _74[heroes.Midnight.ID] = { Level: { less_or_equal: heroes.Midnight.StartLevel } }, _74),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50531,
        Alias: "talent_marathone_midnight",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.MidnightSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_75 = {}, _75[heroes.Midnight.ID] = 2, _75) }) } },
            50: { loot: new Loot({ Currencies: (_76 = {}, _76[CURRENCY.COIN] = 250, _76) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_77 = {}, _77[heroes.Midnight.ID] = 2, _77) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_78 = {}, _78[CURRENCY.COIN] = 250, _78) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_79 = {}, _79[heroes.Midnight.ID] = 4, _79) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_80 = {}, _80[heroes.Midnight.ID] = 3, _80) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Midnight.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_15 = roundsStats; _i < roundsStats_15.length; _i++) {
                    var round = roundsStats_15[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Sarge: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_81 = {}, _81[heroes.Sarge.ID] = { Level: { less_or_equal: heroes.Sarge.StartLevel } }, _81),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50532,
        Alias: "talent_marathone_sarge",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.SargeSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_82 = {}, _82[heroes.Sarge.ID] = 4, _82) }) } },
            50: { loot: new Loot({ Currencies: (_83 = {}, _83[CURRENCY.COIN] = 150, _83) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_84 = {}, _84[heroes.Sarge.ID] = 2, _84) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_85 = {}, _85[CURRENCY.COIN] = 150, _85) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_86 = {}, _86[heroes.Sarge.ID] = 4, _86) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_87 = {}, _87[heroes.Sarge.ID] = 3, _87) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Sarge.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_16 = roundsStats; _i < roundsStats_16.length; _i++) {
                    var round = roundsStats_16[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Lynx: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_88 = {}, _88[heroes.Lynx.ID] = { Level: { less_or_equal: heroes.Lynx.StartLevel } }, _88),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50533,
        Alias: "talent_marathone_lynx",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.LynxSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_89 = {}, _89[heroes.Lynx.ID] = 2, _89) }) } },
            50: { loot: new Loot({ Currencies: (_90 = {}, _90[CURRENCY.COIN] = 250, _90) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_91 = {}, _91[heroes.Lynx.ID] = 2, _91) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_92 = {}, _92[CURRENCY.COIN] = 250, _92) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_93 = {}, _93[heroes.Lynx.ID] = 4, _93) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_94 = {}, _94[heroes.Lynx.ID] = 3, _94) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Lynx.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_17 = roundsStats; _i < roundsStats_17.length; _i++) {
                    var round = roundsStats_17[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Viper: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_95 = {}, _95[heroes.Viper.ID] = { Level: { less_or_equal: heroes.Viper.StartLevel } }, _95),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50534,
        Alias: "talent_marathone_cobra",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ViperSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_96 = {}, _96[heroes.Viper.ID] = 4, _96) }) } },
            50: { loot: new Loot({ Currencies: (_97 = {}, _97[CURRENCY.COIN] = 150, _97) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_98 = {}, _98[heroes.Viper.ID] = 2, _98) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_99 = {}, _99[CURRENCY.COIN] = 150, _99) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_100 = {}, _100[heroes.Viper.ID] = 4, _100) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_101 = {}, _101[heroes.Viper.ID] = 3, _101) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Viper.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_18 = roundsStats; _i < roundsStats_18.length; _i++) {
                    var round = roundsStats_18[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Monkey_King: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_102 = {}, _102[heroes.Monkey_King.ID] = { Level: { less_or_equal: heroes.Monkey_King.StartLevel } }, _102),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50535,
        Alias: "talent_marathone_monkeyking",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Monkey_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_103 = {}, _103[heroes.Monkey_King.ID] = 1, _103) }) } },
            50: { loot: new Loot({ Currencies: (_104 = {}, _104[CURRENCY.COIN] = 300, _104) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_105 = {}, _105[heroes.Monkey_King.ID] = 2, _105) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_106 = {}, _106[CURRENCY.COIN] = 300, _106) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_107 = {}, _107[heroes.Monkey_King.ID] = 3, _107) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_108 = {}, _108[heroes.Monkey_King.ID] = 3, _108) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Monkey_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_19 = roundsStats; _i < roundsStats_19.length; _i++) {
                    var round = roundsStats_19[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Legion_King: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_109 = {}, _109[heroes.Legion_King.ID] = { Level: { less_or_equal: heroes.Legion_King.StartLevel } }, _109),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50536,
        Alias: "talent_marathone_legionking",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Legion_KingSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_110 = {}, _110[heroes.Legion_King.ID] = 1, _110) }) } },
            50: { loot: new Loot({ Currencies: (_111 = {}, _111[CURRENCY.COIN] = 300, _111) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_112 = {}, _112[heroes.Legion_King.ID] = 2, _112) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_113 = {}, _113[CURRENCY.COIN] = 300, _113) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_114 = {}, _114[heroes.Legion_King.ID] = 3, _114) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_115 = {}, _115[heroes.Legion_King.ID] = 3, _115) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Legion_King.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_20 = roundsStats; _i < roundsStats_20.length; _i++) {
                    var round = roundsStats_20[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Butcher: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_116 = {}, _116[heroes.Butcher.ID] = { Level: { less_or_equal: heroes.Butcher.StartLevel } }, _116),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50537,
        Alias: "talent_marathone_butcher",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ButcherSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_117 = {}, _117[heroes.Butcher.ID] = 2, _117) }) } },
            50: { loot: new Loot({ Currencies: (_118 = {}, _118[CURRENCY.COIN] = 250, _118) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_119 = {}, _119[heroes.Butcher.ID] = 2, _119) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_120 = {}, _120[CURRENCY.COIN] = 250, _120) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_121 = {}, _121[heroes.Butcher.ID] = 4, _121) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_122 = {}, _122[heroes.Butcher.ID] = 3, _122) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Butcher.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_21 = roundsStats; _i < roundsStats_21.length; _i++) {
                    var round = roundsStats_21[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Itu: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_123 = {}, _123[heroes.Itu.ID] = { Level: { less_or_equal: heroes.Itu.StartLevel } }, _123),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50539,
        Alias: "talent_marathone_itu",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ItuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_124 = {}, _124[heroes.Itu.ID] = 1, _124) }) } },
            50: { loot: new Loot({ Currencies: (_125 = {}, _125[CURRENCY.COIN] = 300, _125) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_126 = {}, _126[heroes.Itu.ID] = 2, _126) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_127 = {}, _127[CURRENCY.COIN] = 300, _127) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_128 = {}, _128[heroes.Itu.ID] = 3, _128) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_129 = {}, _129[heroes.Itu.ID] = 3, _129) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Itu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_22 = roundsStats; _i < roundsStats_22.length; _i++) {
                    var round = roundsStats_22[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Yunlin: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_130 = {}, _130[heroes.Yunlin.ID] = { Level: { less_or_equal: heroes.Yunlin.StartLevel } }, _130),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50542,
        Alias: "talent_marathone_Yunlin",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.YunlinSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_131 = {}, _131[heroes.Yunlin.ID] = 4, _131) }) } },
            50: { loot: new Loot({ Currencies: (_132 = {}, _132[CURRENCY.COIN] = 150, _132) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_133 = {}, _133[heroes.Yunlin.ID] = 2, _133) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_134 = {}, _134[CURRENCY.COIN] = 150, _134) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_135 = {}, _135[heroes.Yunlin.ID] = 4, _135) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_136 = {}, _136[heroes.Yunlin.ID] = 3, _136) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Yunlin.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_23 = roundsStats; _i < roundsStats_23.length; _i++) {
                    var round = roundsStats_23[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Xiang_Tzu: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_137 = {}, _137[heroes.Xiang_Tzu.ID] = { Level: { less_or_equal: heroes.Xiang_Tzu.StartLevel } }, _137),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50544,
        Alias: "talent_marathone_xiang_tzu",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.Xiang_TzuSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_138 = {}, _138[heroes.Xiang_Tzu.ID] = 2, _138) }) } },
            50: { loot: new Loot({ Currencies: (_139 = {}, _139[CURRENCY.COIN] = 250, _139) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_140 = {}, _140[heroes.Xiang_Tzu.ID] = 2, _140) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_141 = {}, _141[CURRENCY.COIN] = 250, _141) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_142 = {}, _142[heroes.Xiang_Tzu.ID] = 4, _142) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_143 = {}, _143[heroes.Xiang_Tzu.ID] = 3, _143) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Xiang_Tzu.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_24 = roundsStats; _i < roundsStats_24.length; _i++) {
                    var round = roundsStats_24[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_June: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_144 = {}, _144[heroes.June.ID] = { Level: { less_or_equal: heroes.June.StartLevel } }, _144),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50545,
        Alias: "talent_marathone_june",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.JuneSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_145 = {}, _145[heroes.June.ID] = 1, _145) }) } },
            50: { loot: new Loot({ Currencies: (_146 = {}, _146[CURRENCY.COIN] = 300, _146) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_147 = {}, _147[heroes.June.ID] = 2, _147) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_148 = {}, _148[CURRENCY.COIN] = 300, _148) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_149 = {}, _149[heroes.June.ID] = 3, _149) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_150 = {}, _150[heroes.June.ID] = 3, _150) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.June.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_25 = roundsStats; _i < roundsStats_25.length; _i++) {
                    var round = roundsStats_25[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Gideon: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_151 = {}, _151[heroes.Gideon.ID] = { Level: { less_or_equal: heroes.Gideon.StartLevel } }, _151),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50546,
        Alias: "talent_marathone_Gideon",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.GideonSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_152 = {}, _152[heroes.Gideon.ID] = 2, _152) }) } },
            50: { loot: new Loot({ Currencies: (_153 = {}, _153[CURRENCY.COIN] = 250, _153) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_154 = {}, _154[heroes.Gideon.ID] = 2, _154) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_155 = {}, _155[CURRENCY.COIN] = 250, _155) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_156 = {}, _156[heroes.Gideon.ID] = 4, _156) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_157 = {}, _157[heroes.Gideon.ID] = 3, _157) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Gideon.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_26 = roundsStats; _i < roundsStats_26.length; _i++) {
                    var round = roundsStats_26[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Widow: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_158 = {}, _158[heroes.Widow.ID] = { Level: { less_or_equal: heroes.Widow.StartLevel } }, _158),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50547,
        Alias: "talent_marathone_Widow",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.WidowSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_159 = {}, _159[heroes.Widow.ID] = 2, _159) }) } },
            50: { loot: new Loot({ Currencies: (_160 = {}, _160[CURRENCY.COIN] = 250, _160) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_161 = {}, _161[heroes.Widow.ID] = 2, _161) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_162 = {}, _162[CURRENCY.COIN] = 250, _162) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_163 = {}, _163[heroes.Widow.ID] = 4, _163) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_164 = {}, _164[heroes.Widow.ID] = 3, _164) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Widow.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_27 = roundsStats; _i < roundsStats_27.length; _i++) {
                    var round = roundsStats_27[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Raikichi: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_165 = {}, _165[heroes.Raikichi.ID] = { Level: { less_or_equal: heroes.Raikichi.StartLevel } }, _165),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50548,
        Alias: "talent_marathone_raikichi",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.RaikichiSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_166 = {}, _166[heroes.Raikichi.ID] = 2, _166) }) } },
            50: { loot: new Loot({ Currencies: (_167 = {}, _167[CURRENCY.COIN] = 250, _167) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_168 = {}, _168[heroes.Raikichi.ID] = 2, _168) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_169 = {}, _169[CURRENCY.COIN] = 250, _169) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_170 = {}, _170[heroes.Raikichi.ID] = 4, _170) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_171 = {}, _171[heroes.Raikichi.ID] = 3, _171) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Raikichi.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_28 = roundsStats; _i < roundsStats_28.length; _i++) {
                    var round = roundsStats_28[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Nonna: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_172 = {}, _172[heroes.Nonna.ID] = { Level: { less_or_equal: heroes.Nonna.StartLevel } }, _172),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50549,
        Alias: "talent_marathone_nonna",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.NonnaSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_173 = {}, _173[heroes.Nonna.ID] = 1, _173) }) } },
            50: { loot: new Loot({ Currencies: (_174 = {}, _174[CURRENCY.COIN] = 300, _174) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_175 = {}, _175[heroes.Nonna.ID] = 2, _175) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_176 = {}, _176[CURRENCY.COIN] = 300, _176) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_177 = {}, _177[heroes.Nonna.ID] = 3, _177) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_178 = {}, _178[heroes.Nonna.ID] = 3, _178) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Nonna.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_29 = roundsStats; _i < roundsStats_29.length; _i++) {
                    var round = roundsStats_29[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    Short_ShardMarathon_Shogun: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 1 },
                heroes: (_179 = {}, _179[heroes.Shogun.ID] = { Level: { less_or_equal: heroes.Shogun.StartLevel } }, _179),
            },
            activeTime: {
                duration: PROMO_DURATION.ENDLESS,
            },
        },
        ID: 50550,
        Alias: "talent_marathone_shogun",
        Description: "talent_marathone_desc",
        PointsDescription: 'talent_marathone_points_desc',
        UseRewardsPopUp: true,
        ViewConfig: MarathonView.ShogunSM,
        MarathonType: MARATHON_TYPE.HEROES,
        Rewards: {
            20: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_180 = {}, _180[heroes.Shogun.ID] = 1, _180) }) } },
            50: { loot: new Loot({ Currencies: (_181 = {}, _181[CURRENCY.COIN] = 300, _181) }) },
            100: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_182 = {}, _182[heroes.Shogun.ID] = 2, _182) }) } },
            150: { chests: [chests.Rare_chest.ID] },
            230: { loot: new Loot({ Currencies: (_183 = {}, _183[CURRENCY.COIN] = 300, _183) }) },
            320: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_184 = {}, _184[heroes.Shogun.ID] = 3, _184) }) } },
            400: { isHidden: false, lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_185 = {}, _185[heroes.Shogun.ID] = 3, _185) }) } },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var points = 0;
            var heroID = heroes.Shogun.ID;
            var heroWinPoints = 10;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var roundsStats = battleStats.Rounds;
            if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _i = 0, roundsStats_30 = roundsStats; _i < roundsStats_30.length; _i++) {
                    var round = roundsStats_30[_i];
                    var heroIdInRound = round.HeroId;
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += heroIdInRound == heroID ? heroWinPoints : 0;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
}, true);
