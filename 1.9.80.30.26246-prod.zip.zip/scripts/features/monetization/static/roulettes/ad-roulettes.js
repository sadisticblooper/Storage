var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;
roulette.AD_roulette_07_2023 = new Roulette({
    ID: 1,
    promoSettings: {
        conditions: {
            playerRating: { more_or_equal: 70 }
        },
        activeTime: { duration: new Time({ Days: 30 }).value },
        disableGeneratingSince: 1,
    },
    weightSettings: {
        init: 1,
    },
    adRolls: { schedule: { Origin: "2016-01-01T03:00:00+03:00", Period: new Time({ Days: 1 }).value, }, rollQuantity: 2 },
    slots: [
        { rewards: [{ loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.GACHA_KEY] = 1, _a) }) }], probability: 2, cycleSlot: true, },
        { rewards: [{ chests: [chests.Rare_chest.ID] }], probability: 5, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 250, _b) }) }], probability: 25, cycleSlot: true, },
        { rewards: [{ chests: [chests.Small_Shard_Chest.ID] }], probability: 3, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.GACHA_KEY] = 2, _c) }) }], probability: 1, cycleSlot: true, },
        { rewards: [{ chests: [chests.Upgrade_chest.ID] }], probability: 8, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.BONUS] = 25, _d) }) }], probability: 25, cycleSlot: true, },
        { rewards: [{ chests: [chests.Common_chest.ID] }], probability: 25, cycleSlot: true, },
    ],
    bonusSlot: {
        isCycle: true,
        queue: [
            { rollsToClaim: 2, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 3, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 3, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 4, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 5, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 5, reward: { chests: [chests.Small_Shard_Chest.ID] } },
            { rollsToClaim: 5, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
            { rollsToClaim: 6, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
            { rollsToClaim: 6, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
            { rollsToClaim: 6, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
            { rollsToClaim: 7, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
            { rollsToClaim: 8, reward: { chests: [chests.Medium_Shard_Chest.ID] } },
        ],
    },
    finalSlot: {
        rollsToClaim: 45,
        reward: { chests: [chests.Large_Shard_Chest.ID] },
    },
    video: '',
    promoPreviewTooltipReward: null,
    centralCellAlias: 'roulette_title_new_players',
    descriptionAlias: 'roulette_desc_new_players_a',
    visualPreset: rouletteVisualConfig.AD_roulette,
});
roulette.AD_roulette_04_2025 = new Roulette({
    ID: 3,
    promoSettings: {
        conditions: {
            playerRating: { more_or_equal: 70 }
        },
        activeTime: { duration: new Time({ Days: 30 }).value },
        noActiveRouletteNow: [1],
        disableGeneratingSince: 1,
    },
    weightSettings: {
        init: 1,
    },
    relaunchAfterEnd: true,
    adRolls: { schedule: { Origin: "2016-01-01T03:00:00+03:00", Period: new Time({ Days: 1 }).value, }, rollQuantity: 2 },
    slots: [
        { rewards: [{ loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.GACHA_KEY] = 2, _e) }) }], probability: 11, cycleSlot: true, },
        { rewards: [{ chests: [chests.Rare_chest.ID] }], probability: 1, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 250, _f) }) }], probability: 90, cycleSlot: true, },
        { rewards: [{ chests: [chests.Small_Shard_Chest.ID] }], probability: 6, cycleSlot: true, },
        { rewards: [{ chests: [chests.Upgrade_chest.ID] }], probability: 38, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.GACHA_KEY] = 1, _g) }) }], probability: 6, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 25, _h) }) }], probability: 100, cycleSlot: true, },
        { rewards: [{ chests: [chests.Common_chest.ID] }], probability: 2, cycleSlot: true, },
    ],
    bonusSlot: {
        isCycle: true,
        queue: [
            { rollsToClaim: 5, reward: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.GACHA_KEY] = 1, _j) }) } },
            { rollsToClaim: 6, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 8, reward: { chests: [chests.Epic_chest.ID] } },
            { rollsToClaim: 6, reward: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.GACHA_KEY] = 1, _k) }) } },
            { rollsToClaim: 8, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 6, reward: { chests: [chests.Epic_chest.ID] } },
            { rollsToClaim: 8, reward: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.GACHA_KEY] = 1, _l) }) } },
            { rollsToClaim: 6, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 7, reward: { chests: [chests.Epic_chest.ID] } },
        ],
    },
    finalSlot: {
        rollsToClaim: 45,
        reward: { chests: [chests.Large_Shard_Chest.ID] },
    },
    video: '',
    promoPreviewTooltipReward: null,
    centralCellAlias: 'roulette_title_new_players',
    descriptionAlias: 'roulette_desc_new_players_a',
    visualPreset: rouletteVisualConfig.AD_roulette,
});
roulette.AD_roulette_06_2025 = new Roulette({
    ID: 4,
    showInModuleSettings: {
        currenciesToShow: [CURRENCY.AD_TOKEN],
        currencyNotificationsToShow: []
    },
    promoSettings: {
        conditions: {
            playerRating: { more_or_equal: 70 }
        },
        activeTime: { duration: new Time({ Days: 30 }).value },
        noActiveRouletteNow: [3],
    },
    weightSettings: {
        init: 1,
    },
    relaunchAfterEnd: true,
    adRolls: { schedule: { Origin: "2016-01-01T03:00:00+03:00", Period: new Time({ Days: 1 }).value, }, rollQuantity: 2 },
    slots: [
        { rewards: [{ loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.GACHA_KEY] = 2, _m) }) }], probability: 3, cycleSlot: true, },
        { rewards: [{ chests: [chests.Rare_chest.ID] }], probability: 8, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 250, _o) }) }], probability: 70, cycleSlot: true, },
        { rewards: [{ chests: [chests.Small_Shard_Chest.ID] }], probability: 5, cycleSlot: true, },
        { rewards: [{ chests: [chests.Upgrade_chest.ID] }], probability: 16, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.GACHA_KEY] = 1, _p) }) }], probability: 5, cycleSlot: true, },
        { rewards: [{ loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.BONUS] = 25, _q) }) }], probability: 64, cycleSlot: true, },
        { rewards: [{ chests: [chests.Common_chest.ID] }], probability: 30, cycleSlot: true, },
    ],
    bonusSlot: {
        isCycle: true,
        queue: [
            { rollsToClaim: 5, reward: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.GACHA_KEY] = 1, _r) }) } },
            { rollsToClaim: 6, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 8, reward: { chests: [chests.Epic_chest.ID] } },
            { rollsToClaim: 6, reward: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.GACHA_KEY] = 1, _s) }) } },
            { rollsToClaim: 8, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 6, reward: { chests: [chests.Epic_chest.ID] } },
            { rollsToClaim: 8, reward: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.GACHA_KEY] = 1, _t) }) } },
            { rollsToClaim: 6, reward: { chests: [chests.Rare_chest.ID] } },
            { rollsToClaim: 7, reward: { chests: [chests.Epic_chest.ID] } },
        ],
    },
    finalSlot: {
        rollsToClaim: 45,
        reward: { chests: [chests.Large_Shard_Chest.ID] },
    },
    video: '',
    promoPreviewTooltipReward: null,
    centralCellAlias: 'roulette_title_new_players',
    descriptionAlias: 'roulette_desc_new_players_a',
    visualPreset: rouletteVisualConfig.AD_roulette,
});
