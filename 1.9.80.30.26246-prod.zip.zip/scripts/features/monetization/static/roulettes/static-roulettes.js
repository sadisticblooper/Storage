var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
roulette.Onboadring_Ling_roulette = new Roulette({
    ID: 109,
    promoSettings: {
        conditions: {
            playerRating: { more_or_equal: 30, less_or_equal: 50 },
        },
        activeTime: { duration: new Time({ Days: 3 }).value },
    },
    singleRoll: {
        prices: [
            { currency: (_a = {}, _a[CURRENCY.BONUS] = 75, _a) },
            { currency: (_b = {}, _b[CURRENCY.BONUS] = 75, _b) },
            { currency: (_c = {}, _c[CURRENCY.BONUS] = 75, _c) },
            { currency: (_d = {}, _d[CURRENCY.BONUS] = 75, _d) },
            { currency: (_e = {}, _e[CURRENCY.BONUS] = 75, _e) },
            { currency: (_f = {}, _f[CURRENCY.BONUS] = 75, _f) },
            { currency: (_g = {}, _g[CURRENCY.BONUS] = 75, _g) },
            { currency: (_h = {}, _h[CURRENCY.BONUS] = 75, _h) },
        ],
    },
    weightSettings: {
        init: 1,
    },
    slots: [
        { rewards: [{ loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 500, _j) }) }], probability: 30, cycleSlot: false, },
        { rewards: [{ loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.GACHA_KEY] = 1, _k) }) }], probability: 6, cycleSlot: false, },
        { rewards: [
                { lootSettings: { AdditionalFixedLoot: new Loot({ Shards: (_l = {}, _l[heroes.Ling.ID] = 5, _l) }) } },
            ], probability: 8, cycleSlot: false, },
        { rewards: [{ chests: [chests.Emoji_chest.ID] }], probability: 15, cycleSlot: false, },
        { rewards: [{ chests: [chests.Small_Shard_Chest.ID] }], probability: 7, cycleSlot: false, },
        { rewards: [
                { lootSettings: { AdditionalFixedLoot: new Loot({ Skins: [skins.Ling_R_Red_skin.ID] }) } },
            ], probability: 1, cycleSlot: false, },
        { rewards: [{ chests: [chests.Rare_chest.ID] }], probability: 20, cycleSlot: false, },
        { rewards: [
                { lootSettings: { AdditionalFixedLoot: new Loot({ HeroExp: (_m = {}, _m[heroes.Ling.ID] = 10, _m) }) } },
            ], probability: 15, cycleSlot: false, },
    ],
    video: '',
    promoPreviewTooltipReward: null,
    centralCellAlias: 'roulette_title_new_players',
    descriptionAlias: 'roulette_desc_new_players_a',
    visualPreset: rouletteVisualConfig.Onboadring_Ling_roulette,
});
roulette.roulette_roguelike = new Roulette({
    ID: 10006,
    showInModuleSettings: {
        currenciesToShow: [CURRENCY.SILVER],
        currencyNotificationsToShow: []
    },
    promoSettings: {
        conditions: {
            playerRating: { more_or_equal: 50 },
        },
        activeTime: {
            duration: PROMO_DURATION.ENDLESS
        },
        regenerationDelay: 1,
    },
    weightSettings: {
        init: 1,
    },
    singleRoll: { prices: [
            { currency: (_o = {}, _o[CURRENCY.SILVER] = 250, _o) },
        ] },
    multipleRoll: {
        rollQuantity: 10,
        price: { currency: (_p = {}, _p[CURRENCY.SILVER] = 2500, _p) },
        discount: 0,
    },
    dontShowConfirm: true,
    slots: [
        { rewards: [
                { chests: [chests.Common_chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 1000, _q) }) },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Rare_chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Small_Shard_Chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Rare_chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Epic_chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Common_chest.ID] },
            ], probability: 100, cycleSlot: true, },
        { rewards: [
                { chests: [chests.Small_Shard_Chest.ID] },
            ], probability: 100, cycleSlot: true, },
    ],
    bonusSlot: {
        isCycle: true,
        queue: [
            { rollsToClaim: 10, reward: { chests: [chests.PVE_roulette_chest.ID] } },
        ],
    },
    video: '',
    promoPreviewTooltipReward: null,
    centralCellAlias: 'roulette_title_chest',
    descriptionAlias: 'roulette_desc_chest',
    visualPreset: rouletteVisualConfig.pve,
});
