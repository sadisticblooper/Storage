var event_black_market_07_2026_marathons_visual = {
    tournament: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/ViperStuffOffer/marathon_location_Viper_Stuff",
            "color": "#30ffff8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Challenges/Icons/icon_VIPER",
            "IconColor": "#ffd147",
            "BgColor": "#30ffa2"
        },
        "DetailsColor": "#30ffa2",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#8a7127",
                    "time": 0
                },
                {
                    "color": "#1a8a58",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": null,
        "PatternBgColor": "#171717"
    },
    chests: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/ViperStuffOffer/marathon_location_Viper_Stuff",
            "color": "#30ffff8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Icons/icon_STORE",
            "IconColor": "#30ffff",
            "BgColor": "#ffd147"
        },
        "DetailsColor": "#30ffa2",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#1a8a58",
                    "time": 0
                },
                {
                    "color": "#8a7127",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": {
            "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/marathon_pattern_viper",
            "color": "#b897332E"
        },
        "PatternBgColor": "#6F59165C"
    },
    weekend: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/ViperStuffOffer/marathon_location_Viper_Stuff",
            "color": "#30ffff8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Icons/icon_EVENTS",
            "IconColor": "#30ffff",
            "BgColor": "#30ffa2"
        },
        "DetailsColor": "#30ffa2",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#1a8a58",
                    "time": 0
                },
                {
                    "color": "#1a8a8a",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": {
            "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/marathon_pattern_viper",
            "color": "#23b8b82E"
        },
        "PatternBgColor": "#23b8b85C"
    },
};
