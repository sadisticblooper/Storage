var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15;
var black_market_07_2026_marathons = {
    PROMO_BuM_Event_black_market_07_2026_Tournament: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 2 },
            },
            activeTime: {
                startGenerationBound: EventTimeConstants.black_market_07_2026.marathons.tournaments.start,
                endGenerationBound: EventTimeConstants.black_market_07_2026.marathons.tournaments.end,
            },
        },
        ID: 1092001,
        Alias: "marathon_title_event44_2_Tournamet_Viper",
        Description: "marathon_desc_event44_2_Tournamet_Viper",
        PointsDescription: 'marathon_descPoints_event92_Viper_Tournament',
        ViewConfig: event_black_market_07_2026_marathons_visual.tournament,
        PaidClaimButtonAutoSettings: {
            offers: [{ points: 0,
                    offer: {
                        offerId: 1092001,
                        inApp: inAppSettings.PRICE_10.ProductID,
                        offerName: "PROMO_BuM_Event_Black_Market_07_2026_Tournament"
                    }
                }],
            buttonLabel: { isAlias: true, value: "marathon_claim_allprice_button", placeholders: null, },
            hideButtonAfterRewardStep: 12001,
            popUpDescriptionAlias: null,
            buttonState: "MarathonButtonUnlockBright"
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.BUYOUT,
        Rewards: {
            200: { chests: [chests.Upgrade_chest.ID] },
            500: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.CHIP_2] = 50, _a) }) },
            1000: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.CHIP_2] = 75, _b) }) },
            2000: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.TOKEN_2] = 1000, _c) }) },
            3000: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.CHIP_2] = 100, _d) }) },
            4000: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.CHIP_2] = 125, _e) }) },
            5000: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.TOKEN_2] = 1500, _f) }) },
            6000: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.CHIP_2] = 200, _g) }) },
            8000: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.TOKEN_2] = 2500, _h) }) },
            10000: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.CHIP_2] = 350, _j) }) },
            12000: { chests: [chests.Butcher_legendary_weapon_chest.ID] },
            15000: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.CHIP_2] = 600, _k) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var eventTournaments = black_market_07_2026_tournaments.TournamentGroup_1092002.getTournaments().map(function (t) { return t.ID; })
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092003.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092004.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092005.getTournaments().map(function (t) { return t.ID; }));
            var pointsForWinFight = 60;
            var pointsForWinRound = 35;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var tournamentId = battleStats.TournamentId ? +battleStats.TournamentId : 0;
            var fightResult = battleStats.FightResult, rounds = battleStats.Rounds;
            var isFightInEventTournament = tournamentId && eventTournaments.indexOf(tournamentId) > -1;
            var points = 0;
            if (isFightInEventTournament) {
                if (fightResult == FIGHT_RESULT.WIN || fightResult == FIGHT_RESULT.TECH_WIN) {
                    points += pointsForWinFight;
                }
                if (rounds) {
                    for (var _i = 0, rounds_1 = rounds; _i < rounds_1.length; _i++) {
                        var round = rounds_1[_i];
                        if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                            points += pointsForWinRound;
                        }
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    PROMO_paid_marathon_Event_black_market_07_2026_Chests_Low: new Marathon({
        ID: 1092002,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.black_market_07_2026.marathons.chests.start,
                endGenerationBound: EventTimeConstants.black_market_07_2026.marathons.chests.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
            sp: { min: 0.00, max: 49.99 },
            incompatibilityGroup: 1092002,
        },
        Alias: "marathon_title_event44_3_chest_viper", Description: "marathon_desc_event62_Chests_Viper", PointsDescription: 'marathon_descPoints_paidlow',
        ViewConfig: event_black_market_07_2026_marathons_visual.chests,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 1092002,
                        offerName: "PROMO_PaM_Event_blackMarket_01_2026_Chests_Low",
                        inApp: inAppSettings.PRICE_15.ProductID
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            5: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.CHIP_2] = 50, _l) }) },
            20: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.TOKEN_2] = 500, _m) }) },
            50: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.CHIP_2] = 100, _o) }) },
            100: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.TOKEN_2] = 1000, _p) }) },
            165: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.CHIP_2] = 150, _q) }) },
            250: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.CHIP_2] = 200, _r) }) },
            350: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.TOKEN_2] = 1500, _s) }) },
            550: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.CHIP_2] = 250, _t) }) },
            800: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.CHIP_2] = 500, _u) }) },
            1300: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.CHIP_2] = 750, _v) }) },
        },
        UpdateEvents: [QUEST_EVENT.OPEN_CHEST],
        Update: function (args) {
            var _a;
            var points = 0;
            if (args.ChestId != undefined) {
                var chest = chestsMap.get(args.ChestId);
                if (chest) {
                    var rates = (_a = {},
                        _a[CHEST_TYPE.COMMON] = 10,
                        _a[CHEST_TYPE.UPGRADE_CHEST] = 10,
                        _a[CHEST_TYPE.RARE] = 20,
                        _a[CHEST_TYPE.EMOJI_CHEST] = 20,
                        _a[CHEST_TYPE.EPIC] = 40,
                        _a[CHEST_TYPE.ANIMATION_PVE] = 45,
                        _a[CHEST_TYPE.WEAPON_PVE] = 65,
                        _a[CHEST_TYPE.SKIN_PVE] = 90,
                        _a[CHEST_TYPE.LEGENDARY] = 80,
                        _a[CHEST_TYPE.SHARDS_CHEST] = 95,
                        _a[CHEST_TYPE.MYTHIC] = 200,
                        _a[CHEST_TYPE.SHARDS_CHEST_SHOP] = 95,
                        _a);
                    if (rates[chest.Type] != undefined) {
                        points += rates[chest.Type];
                    }
                }
                return args.Progress + points;
            }
        }
    }),
    PROMO_paid_marathon_Event_black_market_01_2026_Chests_High: new Marathon({
        ID: 1092003,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.black_market_07_2026.marathons.chests.start,
                endGenerationBound: EventTimeConstants.black_market_07_2026.marathons.chests.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
            sp: { min: 50.00, max: 999999.99 },
            incompatibilityGroup: 1092002,
        },
        Alias: "marathon_title_event44_3_chest_viper", Description: "marathon_desc_event62_Chests_Viper", PointsDescription: 'marathon_descPoints_paidlow',
        ViewConfig: event_black_market_07_2026_marathons_visual.chests,
        UnlockRewardsButtonAutoSettings: {
            offers: [{
                    points: 0,
                    offer: {
                        offerId: 1092003,
                        offerName: "PROMO_PaM_Event_blackMarket_07_2026_Chests_High",
                        inApp: inAppSettings.PRICE_20.ProductID
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            5: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.CHIP_2] = 50, _w) }) },
            20: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.TOKEN_2] = 500, _x) }) },
            50: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.CHIP_2] = 100, _y) }) },
            100: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.TOKEN_2] = 1000, _z) }) },
            165: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.CHIP_2] = 150, _0) }) },
            250: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.CHIP_2] = 200, _1) }) },
            350: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.TOKEN_2] = 1500, _2) }) },
            550: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.CHIP_2] = 250, _3) }) },
            800: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.CHIP_2] = 500, _4) }) },
            1300: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.CHIP_2] = 750, _5) }) },
        },
        UpdateEvents: [QUEST_EVENT.OPEN_CHEST],
        Update: function (args) {
            var _a;
            var points = 0;
            if (args.ChestId != undefined) {
                var chest = chestsMap.get(args.ChestId);
                if (chest) {
                    var rates = (_a = {},
                        _a[CHEST_TYPE.COMMON] = 10,
                        _a[CHEST_TYPE.UPGRADE_CHEST] = 10,
                        _a[CHEST_TYPE.RARE] = 20,
                        _a[CHEST_TYPE.EMOJI_CHEST] = 20,
                        _a[CHEST_TYPE.EPIC] = 40,
                        _a[CHEST_TYPE.ANIMATION_PVE] = 45,
                        _a[CHEST_TYPE.WEAPON_PVE] = 65,
                        _a[CHEST_TYPE.SKIN_PVE] = 90,
                        _a[CHEST_TYPE.LEGENDARY] = 80,
                        _a[CHEST_TYPE.SHARDS_CHEST] = 95,
                        _a[CHEST_TYPE.MYTHIC] = 200,
                        _a[CHEST_TYPE.SHARDS_CHEST_SHOP] = 95,
                        _a);
                    if (rates[chest.Type] != undefined) {
                        points += rates[chest.Type];
                    }
                }
                return args.Progress + points;
            }
        }
    }),
    PROMO_marathon_Event_black_market_01_2026_Time_1: new Marathon({
        ID: 1092004,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.black_market_07_2026.marathons.time_1.start,
                endGenerationBound: EventTimeConstants.black_market_07_2026.marathons.time_1.end,
                duration: new Time({ Hours: 1 }).value,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
            timeFromLastLogin: new Time({ Minutes: 10 }).value,
            triggersToGenerate: Object.keys(PROMO_TRIGGER_TYPE).filter(isNumber).filter(function (id) { return +id != 1; }).map(Number),
        },
        Alias: "marathon_title_event56_1_Short_Viper",
        Description: "marathon_desc_event56_1_Short_Viper",
        PointsDescription: 'marathon_descPoints_event50_short_1',
        ViewConfig: event_black_market_07_2026_marathons_visual.weekend,
        UseRewardsPopUp: true,
        Rewards: {
            10: { chests: [chests.Upgrade_chest.ID] },
            30: { loot: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.CHIP_2] = 50, _6) }) },
            80: { loot: new Loot({ Currencies: (_7 = {}, _7[CURRENCY.TOKEN_2] = 500, _7) }) },
            150: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.CHIP_2] = 150, _8) }) },
            250: { loot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.TOKEN_2] = 1500, _9) }) },
            300: { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.CHIP_2] = 300, _10) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var eventTournaments = black_market_07_2026_tournaments.TournamentGroup_1092001.getTournaments().map(function (t) { return t.ID; })
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092002.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092003.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092004.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092005.getTournaments().map(function (t) { return t.ID; }));
            var pointsForEventWinRound = 20;
            var pointsForEventLoseRound = 10;
            var pointsForRankedWinRound = 15;
            var pointsForRankedLoseRound = 5;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var tournamentId = battleStats.TournamentId ? +battleStats.TournamentId : 0;
            var fightResult = battleStats.FightResult, rounds = battleStats.Rounds;
            var isFightInEventTournament = tournamentId && eventTournaments.indexOf(tournamentId) > -1;
            var points = 0;
            if (isFightInEventTournament) {
                if (rounds) {
                    for (var _i = 0, rounds_2 = rounds; _i < rounds_2.length; _i++) {
                        var round = rounds_2[_i];
                        if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                            points += pointsForEventWinRound;
                        }
                        else if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_LOSS
                            || round.RoundResult == ROUND_RESULT.ROUND_RESULT_DRAW) {
                            points += pointsForEventLoseRound;
                        }
                    }
                }
            }
            else if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _a = 0, rounds_3 = rounds; _a < rounds_3.length; _a++) {
                    var round = rounds_3[_a];
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += pointsForRankedWinRound;
                    }
                    else if (roundResult == ROUND_RESULT.ROUND_RESULT_LOSS
                        || roundResult == ROUND_RESULT.ROUND_RESULT_DRAW) {
                        points += pointsForRankedLoseRound;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    PROMO_marathon_Event_black_market_01_2026_Time_2: new Marathon({
        ID: 1092005,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.black_market_07_2026.marathons.time_2.start,
                endGenerationBound: EventTimeConstants.black_market_07_2026.marathons.time_2.end,
                duration: new Time({ Hours: 1 }).value,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
            timeFromLastLogin: new Time({ Minutes: 10 }).value,
            triggersToGenerate: Object.keys(PROMO_TRIGGER_TYPE).filter(isNumber).filter(function (id) { return +id != 1; }).map(Number),
        },
        Alias: "marathon_title_event56_1_Short_Viper",
        Description: "marathon_desc_event56_1_Short_Viper",
        PointsDescription: 'marathon_descPoints_event50_short_1',
        ViewConfig: event_black_market_07_2026_marathons_visual.weekend,
        UseRewardsPopUp: true,
        Rewards: {
            10: { chests: [chests.Upgrade_chest.ID] },
            30: { loot: new Loot({ Currencies: (_11 = {}, _11[CURRENCY.CHIP_2] = 50, _11) }) },
            80: { loot: new Loot({ Currencies: (_12 = {}, _12[CURRENCY.TOKEN_2] = 500, _12) }) },
            150: { loot: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.CHIP_2] = 150, _13) }) },
            250: { loot: new Loot({ Currencies: (_14 = {}, _14[CURRENCY.TOKEN_2] = 1500, _14) }) },
            300: { loot: new Loot({ Currencies: (_15 = {}, _15[CURRENCY.CHIP_2] = 300, _15) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: function (args) {
            var eventTournaments = black_market_07_2026_tournaments.TournamentGroup_1092001.getTournaments().map(function (t) { return t.ID; })
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092002.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092003.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092004.getTournaments().map(function (t) { return t.ID; }))
                .concat(black_market_07_2026_tournaments.TournamentGroup_1092005.getTournaments().map(function (t) { return t.ID; }));
            var pointsForEventWinRound = 20;
            var pointsForEventLoseRound = 10;
            var pointsForRankedWinRound = 15;
            var pointsForRankedLoseRound = 5;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var tournamentId = battleStats.TournamentId ? +battleStats.TournamentId : 0;
            var fightResult = battleStats.FightResult, rounds = battleStats.Rounds;
            var isFightInEventTournament = tournamentId && eventTournaments.indexOf(tournamentId) > -1;
            var points = 0;
            if (isFightInEventTournament) {
                if (rounds) {
                    for (var _i = 0, rounds_4 = rounds; _i < rounds_4.length; _i++) {
                        var round = rounds_4[_i];
                        if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                            points += pointsForEventWinRound;
                        }
                        else if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_LOSS
                            || round.RoundResult == ROUND_RESULT.ROUND_RESULT_DRAW) {
                            points += pointsForEventLoseRound;
                        }
                    }
                }
            }
            else if (battleStats.MatchingInfo.mode == FIGHT_MODE.RANKED) {
                for (var _a = 0, rounds_5 = rounds; _a < rounds_5.length; _a++) {
                    var round = rounds_5[_a];
                    var roundResult = round.RoundResult;
                    if (roundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                        points += pointsForRankedWinRound;
                    }
                    else if (roundResult == ROUND_RESULT.ROUND_RESULT_LOSS
                        || roundResult == ROUND_RESULT.ROUND_RESULT_DRAW) {
                        points += pointsForRankedLoseRound;
                    }
                }
            }
            return args.Progress + points;
        }
    }),
};
extend(Marathons, black_market_07_2026_marathons, true);
