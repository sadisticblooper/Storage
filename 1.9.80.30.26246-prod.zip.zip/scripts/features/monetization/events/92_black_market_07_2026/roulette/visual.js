rouletteVisualConfig.black_market_07_2026 = {
    "visualConfig": {
        "boardImage": "Sprites/PreviewImages/Lottery/Viper/lottery_table_viper",
        "textColor": "#ffd147",
        "backgroundImage": "Sprites/PreviewImages/Lottery/Viper/background_lottery_viper",
        "backgroundColor": "#FFFFFF",
        "particlesPrefabPath": "UIPrefabs/Effects/LingLotteryBGEffect",
        "rollButtonColor": "#e5c493",
        "rollGlowColor": "#e5c493",
        "gradient": "#30ffa2",
        "slotRewardCounterBgColor": "#8a7127",
        "leftExtraRewardBgColor": "#30ffa2",
        "rightExtraRewardBgColor": "#ffd147",
        "extraRewardBgPatternImage": "Sprites/PreviewImages/Lottery/Viper/bg_reward_pattern_viper",
        "showFreeBadge": false,
        "tableSelectedEffects": {
            "glowColor": "#ffd147",
            "mainColor": "#ffd147"
        },
        "promoPreview": "Sprites/PreviewImages/Lottery/UniversalRoulette/preview_wpn_Gideon_E_Hunter"
    },
    "bannerVisual": {
        "bannerBgImage": "Sprites/PreviewImages/Lottery/Viper/bg_location_viper",
        "bannerColors": {
            "bgColor": "#b8b8b8",
            "glowColor": "#115c3a",
            "decorColor": "#30ffa2",
            "activeFxColor": "#30ffa2"
        },
        "bannerMainImage": "Sprites/PreviewImages/Lottery/UniversalRoulette/preview_wpn_Gideon_E_Hunter",
        "bannerParticlesPrefabPath": "UIPrefabs/Effects/DefaultLotteryBannerEffectLing"
    },
};
