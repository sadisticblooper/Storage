var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11;
var black_market_07_2026_tournaments_rewards = {
    fruit: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.TOKEN_2] = 25, _a) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.CHIP_2] = 30, _b) }) },
                onetime: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.CHIP_2] = 50, _c) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.TOKEN_2] = 350, _d) }) },
                onetime: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.CHIP_2] = 100, _e) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.CHIP_2] = 60, _f) }) },
                onetime: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.CHIP_2] = 150, _g) }) },
            },
        },
    },
    pve: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.TOKEN_2] = 25, _h) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.CHIP_2] = 15, _j) }) },
                onetime: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.TOKEN_2] = 200, _k) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.TOKEN_2] = 50, _l) }) },
                onetime: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.TOKEN_2] = 300, _m) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.CHIP_2] = 25, _o) }) },
                onetime: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.CHIP_2] = 100, _p) }) },
            },
            4: {
                repeatable: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.TOKEN_2] = 250, _q) }) },
                onetime: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.TOKEN_2] = 500, _r) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.CHIP_2] = 35, _t) }) },
                onetime: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.CHIP_2] = 200, _u) }) },
            },
        },
    },
    pvp: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.TOKEN_2] = 25, _v) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.TOKEN_2] = 75, _w) }) },
                onetime: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.TOKEN_2] = 300, _x) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.TOKEN_2] = 100, _y) }) },
                onetime: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.TOKEN_2] = 750, _z) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.CHIP_2] = 75, _0) }) },
                onetime: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.CHIP_2] = 300, _1) }) },
            },
            4: {
                repeatable: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.TOKEN_2] = 300, _2) }) },
                onetime: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.TOKEN_2] = 2500, _3) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.CHIP_2] = 100, _4) }) },
                onetime: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.CHIP_2] = 500, _5) }) },
            },
        },
    },
    promo: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.COIN] = 10, _6) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_7 = {}, _7[CURRENCY.TOKEN_2] = 200, _7) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.TOKEN_2] = 300, _8) }) },
            },
            3: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.CHIP_2] = 150, _9) }) },
            },
            4: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.TOKEN_2] = 500, _10) }) },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_11 = {}, _11[CURRENCY.CHIP_2] = 250, _11) }) },
            },
        },
    },
};
