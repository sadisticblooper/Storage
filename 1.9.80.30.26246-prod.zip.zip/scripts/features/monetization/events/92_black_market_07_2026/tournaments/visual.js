var black_market_07_2026_tournament_visuals = {
    base: {
        "lobbyAndHubItemArtColor": "#30FFFF",
        "draftAndEventWindowArtColor": "#30FFFF",
        "lobbyAndHubItemGradientDefault": {
            "colorKeys": [
                {
                    "color": "#8A7127B7",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "lobbyAndHubItemGradientPremium": {
            "colorKeys": [
                {
                    "color": "#73612A",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "draftAndEventWindowGradientColorPremium": "#73612A",
        "draftAndEventWindowGradientColorDefault": "#8A7127B7",
        "eventWindowGlowPremium": "#73612A",
        "eventWindowGlowDefault": "#A1842D",
        "eventWindowRightGradientPremium": "#73612A",
        "eventWindowRightGradientDefault": "#8A7127",
        "hubItemPositionPremium": { "x": -450, "y": 0 },
        "hubItemPositionDefault": { "x": -450, "y": 0 },
        "hubItemScalePremium": 1,
        "hubItemScaleDefault": 1,
        "eventSubTitleColorPremium": "#ffd75e",
        "eventSubTitleColorDefault": "#30FFA2",
        "icon": 4,
    },
    viper_1: {
        "lobbyAndHubItemArtColor": "#30ffffC1",
        "draftAndEventWindowArtColor": "#d1eaff",
        "lobbyAndHubItemGradientDefault": {
            "colorKeys": [
                {
                    "color": "#8a7127",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "lobbyAndHubItemGradientPremium": {
            "colorKeys": [
                {
                    "color": "#8a7127",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "draftAndEventWindowGradientColorPremium": "#ffd147",
        "draftAndEventWindowGradientColorDefault": "#ffd147",
        "eventWindowGlowPremium": "#167349",
        "eventWindowGlowDefault": "#167349",
        "eventWindowRightGradientPremium": "#167349",
        "eventWindowRightGradientDefault": "#167349",
        "hubItemPositionPremium": { "x": 0, "y": 0 },
        "hubItemPositionDefault": { "x": 0, "y": 0 },
        "hubItemScalePremium": 1,
        "hubItemScaleDefault": 1,
        "eventSubTitleColorPremium": "#30ffa2",
        "eventSubTitleColorDefault": "#30ffa2",
        "icon": 4,
    },
    viper_2: {
        "lobbyAndHubItemArtColor": "#30ffffC1",
        "draftAndEventWindowArtColor": "#d1eaff",
        "lobbyAndHubItemGradientDefault": {
            "colorKeys": [
                {
                    "color": "#8a7127",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "lobbyAndHubItemGradientPremium": {
            "colorKeys": [
                {
                    "color": "#8a7127",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "draftAndEventWindowGradientColorPremium": "#30ffa2",
        "draftAndEventWindowGradientColorDefault": "#30ffa2",
        "eventWindowGlowPremium": "#1fa1a1",
        "eventWindowGlowDefault": "#1fa1a1",
        "eventWindowRightGradientPremium": "#1fa1a1",
        "eventWindowRightGradientDefault": "#1fa1a1",
        "hubItemPositionPremium": { "x": 0, "y": 0 },
        "hubItemPositionDefault": { "x": 0, "y": 0 },
        "hubItemScalePremium": 1,
        "hubItemScaleDefault": 1,
        "eventSubTitleColorPremium": "#30ffa2",
        "eventSubTitleColorDefault": "#30ffa2",
        "icon": null
    },
};
