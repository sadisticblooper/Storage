var _a, _b, _c, _d, _e, _f, _g, _h, _j;
var black_market_07_2026_tournaments = {
    TournamentGroup_1092001: new TournamentGroup({
        ID: 1092001,
        StartDate: EventTimeConstants.black_market_07_2026.tournaments.pvp.start,
        EndDate: EventTimeConstants.black_market_07_2026.tournaments.pvp.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tornament_event_description_event92_Gideon_Promo',
        InfoCards: TournamentVisualSettings.cardsPreset.slice(0, 1),
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4_Gideon_Epic,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        GuaranteeDraft: {
            heroId: heroes.Gideon.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [
                heroes.Bulwark.ID,
                heroes.Sarge.ID,
                heroes.Ironclad.ID,
                heroes.Gideon.ID,
            ],
        },
        BotPresetsByStage: [
            { stages: [3], presets: heroesGroupsForTournaments.All_Heroes_6 },
            { stages: [4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Idle_Tournament,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_GIDEON_VS_AI.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.pve_5_1.ID,
            locations.viper_backstreet.ID,
            locations.castle.ID,
        ],
        PresetLink: black_market_07_2026_tournament_visuals.viper_1,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_event_title_event92_Gideon_Promo',
                    AliasSubName: 'Tournament_event_subtitle_event92_Gideon_Promo',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_a = {}, _a[CURRENCY.COIN] = 10, _a)],
                    Rewards: black_market_07_2026_tournaments_rewards.promo,
                    PictureInHub: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_hub_1",
                    PictureInWindow: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_window",
                    PictureSmall: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_banner",
                },
            ]
        },
    }),
    TournamentGroup_1092002: new TournamentGroup({
        ID: 1092002,
        StartDate: EventTimeConstants.black_market_07_2026.tournaments.pve.start,
        EndDate: EventTimeConstants.black_market_07_2026.tournaments.pve.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_event62_Viper_Shop_PVE',
        InfoCards: TournamentVisualSettings.cardsPreset,
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        BotPresetsByStage: [
            { stages: [0], presets: heroesGroupsForTournaments.All_Heroes_4 },
            { stages: [2, 3], presets: heroesGroupsForTournaments.All_Heroes_6 },
            { stages: [4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_BLACK_MARKET.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.pve_5_1.ID,
            locations.viper_backstreet.ID,
            locations.castle.ID,
        ],
        PresetLink: black_market_07_2026_tournament_visuals.base,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._3_VS_3_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_event62_Viper_Shop_PVE',
                    AliasSubName: 'Tournament_subtitle_event39',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_b = {}, _b[CURRENCY.TICKET_2] = 5, _b), (_c = {}, _c[CURRENCY.BONUS] = 49, _c)],
                    Rewards: black_market_07_2026_tournaments_rewards.pve,
                    PictureInHub: "Sprites/PreviewImages/Events/ViperStuffOffer/BG_tournament_Viper_Stuff",
                    PictureInWindow: "Sprites/PreviewImages/Events/ViperStuffOffer/BG_tournament_Viper_Stuff",
                    PictureSmall: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_banner",
                },
            ]
        },
    }),
    TournamentGroup_1092003: new TournamentGroup({
        ID: 1092003,
        StartDate: EventTimeConstants.black_market_07_2026.tournaments.pvp.start,
        EndDate: EventTimeConstants.black_market_07_2026.tournaments.pvp.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_event44_viper',
        InfoCards: TournamentVisualSettings.cardsPreset,
        AccountLevel: 6,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4,
        RestrictionPlayerParams: {
            AccountLevel: { min: 1, max: 13 },
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 3,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_12_stages,
        MatchingZones: TournamentMatchingZones.MatcherZones_total,
        BattleID: battleSettings.EVENT_BLACK_MARKET.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.pve_5_1.ID,
            locations.viper_backstreet.ID,
            locations.castle.ID,
        ],
        PresetLink: black_market_07_2026_tournament_visuals.base,
        MaxDailyWonTournamentsWithBot: 20,
        TeamMode: TEAM_MODE._3_VS_3_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_event44_viper',
                    AliasSubName: 'Tournament_subtitle_event39',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_d = {}, _d[CURRENCY.TICKET_2] = 10, _d), (_e = {}, _e[CURRENCY.BONUS] = 99, _e)],
                    Rewards: black_market_07_2026_tournaments_rewards.pvp,
                    PictureInHub: "Sprites/PreviewImages/Events/ViperStuffOffer/BG_tournament_Viper_Stuff",
                    PictureInWindow: "Sprites/PreviewImages/Events/ViperStuffOffer/BG_tournament_Viper_Stuff",
                    PictureSmall: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_banner",
                    PremiumType: {
                        IsPremium: true,
                        Alias: 'tournament_event_high_stakes'
                    }
                },
            ]
        },
    }),
    TournamentGroup_1092004: new TournamentGroup({
        ID: 1092004,
        StartDate: EventTimeConstants.black_market_07_2026.tournaments.fruit_ninja_first.start,
        EndDate: EventTimeConstants.black_market_07_2026.tournaments.fruit_ninja_first.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_event39_1',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.Itu_Fruit_Ninja,
        GuaranteeDraft: {
            heroId: heroes.Itu.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            heroes: [HeroNames.Itu.ID],
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
        },
        BotOpponentByStage: {
            0: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
            1: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
            2: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
        },
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 3,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_ONE.ID,
        BattleIDByStageForPvE: {
            0: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_ONE.ID,
            1: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_TWO.ID,
            2: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_EASY_ROUND_THREE.ID,
        },
        LocationPool: [locations.viper_backstreet.ID],
        PresetLink: black_market_07_2026_tournament_visuals.viper_2,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_event39',
                    AliasSubName: 'Tournament_subtitle_event39',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_f = {}, _f[CURRENCY.TICKET_2] = 5, _f), (_g = {}, _g[CURRENCY.BONUS] = 49, _g)],
                    Rewards: black_market_07_2026_tournaments_rewards.fruit,
                    PictureInHub: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_hub_2",
                    PictureInWindow: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_window",
                    PictureSmall: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_banner",
                },
            ]
        },
    }),
    TournamentGroup_1092005: new TournamentGroup({
        ID: 1092005,
        StartDate: EventTimeConstants.black_market_07_2026.tournaments.fruit_ninja_second.start,
        EndDate: EventTimeConstants.black_market_07_2026.tournaments.fruit_ninja_second.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tournament_description_event39_1',
        InfoCards: [
            {
                Alias: "DraftCardAlias",
                Description: "DraftCardDescription",
                Image: "Sprites/Assets/Events/icon_HERO_DRAFT",
                ImageColor: "#ffffff"
            },
        ],
        AccountLevel: 4,
        HeroPresetsGroup: heroesGroupsForTournaments.Itu_Fruit_Ninja,
        GuaranteeDraft: {
            heroId: heroes.Itu.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            heroes: [HeroNames.Itu.ID],
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
        },
        BotOpponentByStage: {
            0: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
            1: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
            2: [{ id: heroes.Viper.ID, skinId: skins.Viper_E_Mobster.ID }],
        },
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 3,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_ONE.ID,
        BattleIDByStageForPvE: {
            0: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_ONE.ID,
            1: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_TWO.ID,
            2: battleSettings.EVENT_ITU_FRUIT_NINJA_ITERATION_TWO_HARD_ROUND_THREE.ID,
        },
        LocationPool: [locations.viper_backstreet.ID],
        PresetLink: black_market_07_2026_tournament_visuals.viper_2,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_title_event39',
                    AliasSubName: 'Tournament_subtitle_event39',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_h = {}, _h[CURRENCY.TICKET_2] = 5, _h), (_j = {}, _j[CURRENCY.BONUS] = 49, _j)],
                    Rewards: black_market_07_2026_tournaments_rewards.fruit,
                    PictureInHub: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_hub_2",
                    PictureInWindow: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_window",
                    PictureSmall: "Sprites/PreviewImages/Events/ViperStuffOffer/tournament_art_viper_banner",
                },
            ]
        },
    }),
};
extend(eventTournaments, black_market_07_2026_tournaments, true);
