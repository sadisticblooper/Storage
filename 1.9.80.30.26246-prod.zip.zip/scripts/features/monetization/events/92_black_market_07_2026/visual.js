eventVisualConfigs.black_market_07_2026 = {
    commonVisual: {
        "timerColor": "#30FFA2",
        "iconId": 4,
        "shop": {
            "shopTabColor": "#30FFA2",
            "background": {
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#2A5D73BF"
            },
            "location": {
                "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/bg_event_viper_stuff",
                "color": "#30ffffA6"
            },
            "titleColor": "#FFFFFF"
        },
    },
    "popups": CommonPopUpUtils.setActivityPopupsOverMap(activityPopupsMap, [
        {
            data: {
                "ID": 920,
                "priority": 10,
                "navigation": POPUP_NAVIGATION.ROULETTE,
                "navigationArg": 1092001,
                activeTime: EventTimeConstants.black_market_07_2026.popups._1,
                "endDate": EventTimeConstants.black_market_07_2026.event.start + new Time({ Days: 13 }).value,
            },
            visual: {
                "displayedCurrencies": [CURRENCY.TOKEN_2, CURRENCY.CHIP_2, CURRENCY.TICKET_2],
                "iconId": 4,
                "rulesDescription": {
                    "alias": "popup_rules_event92_Viper_Gideon",
                    "color": "#ffd147"
                },
                "rulesHeader": {
                    "alias": "popup_event_rules_title",
                    "color": "#FFFFFF"
                },
                "header": {
                    "alias": "popup_title_event44_additional_viper",
                    "color": "#30FFA2"
                },
                "subHeader": {
                    "alias": "event_popup_currency_title",
                    "color": "#ffd147"
                },
                "timer": {
                    "alias": "quest_ends_timer",
                    "color": "#30FFA2"
                },
                "button": {
                    "alias": "button_roulette",
                    "frameColor": "#75FF83",
                    "glow1Color": "#D7FFCE",
                    "glow2Color": "#D7FFCE",
                    "effect1Color": "#75FF83",
                    "effect2Color": "#75FF83",
                    "effect3Color": "#75FF83",
                    "effect4Color": "#75FF83",
                    "corner1Color": "#75FF83",
                    "corner2Color": "#75FF83"
                },
                "preview": {
                    "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/art_event_CobraStuff_wpn_Gideon",
                    "color": "#ffffff"
                },
                "background": {
                    "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/BG_tournament_Viper_Stuff",
                    "color": "#30ffffA6"
                },
                "backgroundEffect": {
                    "sprite": "",
                    "color": "#FFD147"
                },
                "particles": {
                    "maxColor": "#FFD147",
                    "minColor": "#FFD147"
                },
                "gradientLeft": {
                    "mode": 0,
                    "colorKeys": [
                        {
                            "time": 0,
                            "color": "#735E20"
                        },
                        {
                            "time": 0.98,
                            "color": "#735E20"
                        }
                    ],
                    "alphaKeys": [
                        {
                            "time": 0,
                            "alpha": 1
                        },
                        {
                            "time": 1,
                            "alpha": 0
                        }
                    ]
                },
                "gradientRight": {
                    "mode": 0,
                    "colorKeys": [
                        {
                            "time": 0,
                            "color": "#FFEA30"
                        },
                        {
                            "time": 0.99,
                            "color": "#30FFA272"
                        }
                    ],
                    "alphaKeys": [
                        {
                            "time": 0,
                            "alpha": 1
                        },
                        {
                            "time": 1,
                            "alpha": 1
                        }
                    ]
                },
                "descriptionItems": [
                    {
                        "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                        "alias": "roulette_benefit_desc_1",
                        "color": "#30ffff"
                    },
                    {
                        "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                        "alias": "roulette_benefit_desc_2",
                        "color": "#30ffff"
                    },
                    {
                        "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                        "alias": "roulette_benefit_desc_3",
                        "color": "#30ffff"
                    }
                ],
                "pattern": {
                    "sprite": "Sprites/PreviewImages/Events/ViperStuffOffer/_art_event_pattern_CobraStuff",
                    "color": "#1A8A5880"
                }
            },
        },
    ]),
};
