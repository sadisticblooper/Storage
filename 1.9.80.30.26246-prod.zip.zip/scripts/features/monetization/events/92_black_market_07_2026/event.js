var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var _a;
extend(seasonalEvents, {
    event_black_market_07_2026: new SeasonalEvent({
        ID: 92,
        startTime: EventTimeConstants.black_market_07_2026.event.start,
        endTime: EventTimeConstants.black_market_07_2026.event.end,
        eventCurrenciesToCurrencies: (_a = {},
            _a[EVENT_CURRENCY.TOKEN] = CURRENCY.TOKEN_2,
            _a[EVENT_CURRENCY.TICKET] = CURRENCY.TICKET_2,
            _a[EVENT_CURRENCY.CHIP] = CURRENCY.CHIP_2,
            _a),
        activities: {
            offers: __spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray([], OfferSkeletonUtils.getOfferIdsFromSkin("black_market_new_weapon"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_currencies"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_emperor_wpn"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_emperor_unlock"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_butcher_wpn"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_butcher_unlock"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_gideon_wpn"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_gideon_unlock"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_widow_wpn"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_widow_unlock"), true), OfferSkeletonUtils.getOfferIdsFromSkin("black_market_all_wpn"), true),
            marathons: Object.keys(black_market_07_2026_marathons).map(function (n) { return black_market_07_2026_marathons[n].ID; }),
            tournamentGroups: Object.keys(black_market_07_2026_tournaments).map(function (n) { return black_market_07_2026_tournaments[n]; }),
            roulette: [roulette.black_market_07_2026_roulette.ID],
            questsAggregator: eventQuestsAggregator.aggregator2.ID,
            shop: seasonalEventShops.shopForEventTemplate_1.ID,
        },
        visualConfig: eventVisualConfigs.black_market_07_2026,
        currencyGroupConfig: {
            headerAlias: "hub_event_currency_group_title_Viper",
            colors: {
                headerColor: "#30FFA2",
                timerColor: "#30FFA2",
                infoButtonColor: "#30FFA2",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#30FFA2" }, { time: 1, color: "#30FFA2" }],
                },
            },
        },
    }),
}, true);
