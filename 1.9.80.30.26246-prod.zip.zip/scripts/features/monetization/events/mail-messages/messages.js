var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
extend(mailMessages, __assign({}, EventMailMessagesUtils.createEventMessagesMap({
    eventId: 92,
    messages: [
        {
            messageSettings: {
                ID: 192,
                promoSettings: {
                    activeTime: null,
                    conditions: {
                        accountLevel: { more_or_equal: 2 }
                    },
                },
                localized: true,
                header: "mail_title_event_invitation",
                body: "mail_body_event_invitation",
                linkButtonAlias: "mail_button_event_invitation",
                linkMap: { default: "sfa://tournamentdraft" }
            },
            daysSettings: {
                firstTime: new Time({ Days: 3 }).value
            },
        },
        {
            messageSettings: {
                ID: 193,
                promoSettings: {
                    activeTime: null,
                    conditions: {
                        accountLevel: { more_or_equal: 2 }
                    },
                },
                localized: true,
                header: "mail_title_event_stimulus",
                body: "mail_body_event_stimulus",
            },
            daysSettings: {
                lastTime: new Time({ Days: 3 }).value
            },
        },
    ],
})), true);
