rouletteVisualConfig.event_shogun_07_2026_roulette_visual_hero = {
    "visualConfig": {
        "boardImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_table_shogun",
        "textColor": "#e6b46a",
        "backgroundImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_bg_shogun",
        "backgroundColor": "#FFFFFF",
        "particlesPrefabPath": "UIPrefabs/Effects/ShogunLotteryBGEffect",
        "rollButtonColor": "#e5c493",
        "rollGlowColor": "#e5c493",
        "gradient": "#ff5734",
        "slotRewardCounterBgColor": "#4b4d5c",
        "leftExtraRewardBgColor": "#71738a",
        "rightExtraRewardBgColor": "#ff4f30",
        "extraRewardBgPatternImage": "Sprites/PreviewImages/Lottery/Shogun/bg_reward_pattern_shogun",
        "showFreeBadge": false,
        "tableSelectedEffects": {
            "glowColor": "#ff5734",
            "mainColor": "#ff5734"
        },
        "promoPreview": "Sprites/PreviewImages/Lottery/Shogun/lottery_art_shogun"
    },
    "bannerVisual": {
        "bannerBgImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_banner_bg_shogun",
        "bannerColors": {
            "bgColor": "#ffffffff",
            "glowColor": "#060817",
            "decorColor": "#22141f",
            "activeFxColor": "#595770"
        },
        "bannerMainImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_banner_art_shogun",
        "bannerParticlesPrefabPath": "UIPrefabs/Effects/DefaultLotteryBannerEffectShogun"
    }
};
rouletteVisualConfig.event_shogun_07_2026_roulette_visual_eternium = {
    "visualConfig": {
        "boardImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_table_eternium",
        "textColor": "#d1d3e6",
        "backgroundImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_bg_eternium",
        "backgroundColor": "#FFFFFF",
        "particlesPrefabPath": "UIPrefabs/Effects/EterniumLotteryBGEffect",
        "rollButtonColor": "#e5c493",
        "rollGlowColor": "#e5c493",
        "gradient": "#55d0e6",
        "slotRewardCounterBgColor": "#732416",
        "leftExtraRewardBgColor": "#ff4f30",
        "rightExtraRewardBgColor": "#55d0e5",
        "extraRewardBgPatternImage": "Sprites/PreviewImages/Lottery/Shogun/bg_reward_pattern_shogun",
        "showFreeBadge": false,
        "tableSelectedEffects": {
            "glowColor": "#55d0e5",
            "mainColor": "#55d0e5"
        },
        "promoPreview": "Sprites/PreviewImages/Lottery/Shogun/lottery_art_eternium"
    },
    "bannerVisual": {
        "bannerBgImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_banner_bg_shogun",
        "bannerColors": {
            "bgColor": "#ffffffff",
            "glowColor": "#060817",
            "decorColor": "#63919aff",
            "activeFxColor": "#595770"
        },
        "bannerMainImage": "Sprites/PreviewImages/Lottery/Shogun/lottery_art_eternium",
        "bannerParticlesPrefabPath": "UIPrefabs/Effects/DefaultLotteryBannerEffectEternium"
    }
};
