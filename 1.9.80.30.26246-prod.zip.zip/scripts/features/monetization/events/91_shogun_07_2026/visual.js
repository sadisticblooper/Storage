eventVisualConfigs.shogun_07_2026 = {
    commonVisual: {
        "timerColor": "#ff4f30",
        "iconId": 54,
        "shop": {
            "shopTabColor": "#ff4f30",
            "background": {
                "sprite": "Sprites/Assets/Layouts/bg_rectangle_sliced_shadow",
                "color": "#2a5d73"
            },
            "location": {
                "sprite": "Sprites/PreviewImages/Events/Shogun/event_bg_shogun",
                "color": "#2e0e09"
            },
            "titleColor": "#ff4f30"
        }
    },
    "popups": CommonPopUpUtils.setActivityPopupsOverMap(activityPopupsMap, [
        {
            data: {
                "ID": 910,
                "priority": 10,
                "navigation": POPUP_NAVIGATION.ROULETTE,
                "navigationArg": 1091001,
                activeTime: EventTimeConstants.shogun_07_2026.popups._1,
                "endDate": EventTimeConstants.shogun_07_2026.event.end,
            },
            visual: {
                "displayedCurrencies": [3, 15, 5, 4],
                "iconId": 54,
                "rulesHeader": {
                    "alias": "popup_event_rules_title",
                    "color": "#FFFFFF"
                },
                "rulesDescription": {
                    "alias": "popup_rules_event91_Shogun",
                    "color": "#ff4f30"
                },
                "header": {
                    "alias": "popup_title_event91_Shogun",
                    "color": "#ff4f30"
                },
                "subHeader": {
                    "alias": "event_popup_currency_title",
                    "color": "#e6b46a"
                },
                "timer": {
                    "alias": "quest_ends_timer",
                    "color": "#e6b46a"
                },
                "button": {
                    "alias": "button_roulette",
                    "frameColor": "#75FF83",
                    "glow1Color": "#D7FFCE",
                    "glow2Color": "#D7FFCE",
                    "effect1Color": "#75FF83",
                    "effect2Color": "#75FF83",
                    "effect3Color": "#75FF83",
                    "effect4Color": "#75FF83",
                    "corner1Color": "#75FF83",
                    "corner2Color": "#75FF83"
                },
                "preview": {
                    "sprite": "Sprites/PreviewImages/Events/Shogun/popup_art_shogun",
                    "color": "#ffffff"
                },
                "background": {
                    "sprite": "Sprites/PreviewImages/Events/Shogun/popup_bg_shogun",
                    "color": "#5ECFFF"
                },
                "backgroundEffect": {
                    "sprite": "",
                    "color": "#ff4f30"
                },
                "particles": {
                    "maxColor": "#ff4f30",
                    "minColor": "#ff4f30"
                },
                "gradientLeft": {
                    "mode": 0,
                    "colorKeys": [
                        {
                            "time": 0,
                            "color": "#5c1d11"
                        },
                        {
                            "time": 0.98,
                            "color": "#5c1d11"
                        }
                    ],
                    "alphaKeys": [
                        {
                            "time": 0,
                            "alpha": 1
                        },
                        {
                            "time": 1,
                            "alpha": 0
                        }
                    ]
                },
                "gradientRight": {
                    "mode": 0,
                    "colorKeys": [
                        {
                            "time": 0,
                            "color": "#5c1d11"
                        },
                        {
                            "time": 0.99,
                            "color": "#151517"
                        }
                    ],
                    "alphaKeys": [
                        {
                            "time": 0,
                            "alpha": 1
                        },
                        {
                            "time": 1,
                            "alpha": 1
                        }
                    ]
                },
                "descriptionItems": [
                    {
                        "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_ACTIVITIES",
                        "alias": "event1_benefit_desc_1",
                        "color": "#d1d3e6"
                    },
                    {
                        "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_EVENT_TOKEN",
                        "alias": "event1_benefit_desc_2",
                        "color": "#d1d3e6"
                    },
                    {
                        "icon": "Sprites/Assets/Events/HalloweenCurrency/icon_TICKET",
                        "alias": "event1_benefit_desc_3",
                        "color": "#d1d3e6"
                    }
                ],
                "pattern": {
                    "sprite": "Sprites/PreviewImages/Events/Shogun/popup_pattern_shogun",
                    "color": "#8A765820"
                }
            },
        },
    ]),
};
