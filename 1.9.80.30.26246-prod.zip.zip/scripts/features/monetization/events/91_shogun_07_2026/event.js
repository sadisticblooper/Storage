var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var _a;
extend(seasonalEvents, {
    event_shogun_07_2026: new SeasonalEvent({
        ID: 91,
        startTime: EventTimeConstants.shogun_07_2026.event.start,
        endTime: EventTimeConstants.shogun_07_2026.event.end,
        eventCurrenciesToCurrencies: (_a = {},
            _a[EVENT_CURRENCY.TOKEN] = CURRENCY.TOKEN_1,
            _a[EVENT_CURRENCY.TICKET] = CURRENCY.TICKET_1,
            _a[EVENT_CURRENCY.CHIP] = CURRENCY.CHIP_1,
            _a[EVENT_CURRENCY.CHIP_ALT] = CURRENCY.TOKEN_ITU,
            _a),
        activities: {
            offers: __spreadArray([], OfferSkeletonUtils.getOfferIdsFromSkin("Shogun_Event_07_2026"), true),
            marathons: Object.keys(shogun_07_2026_marathons).map(function (n) { return shogun_07_2026_marathons[n].ID; }),
            tournamentGroups: Object.keys(shogun_07_2026_tournaments).map(function (n) { return shogun_07_2026_tournaments[n]; }),
            roulette: [roulette.event_shogun_07_2026_roulette_hero.ID, roulette.event_shogun_07_2026_roulette_eternium.ID],
            questsAggregator: eventQuestsAggregator.aggregator1.ID,
            shop: seasonalEventShops.shopForEventTemplate_2.ID,
        },
        visualConfig: eventVisualConfigs.shogun_07_2026,
        currencyGroupConfig: {
            headerAlias: "hub_event_currency_group_title_Shogun",
            colors: {
                headerColor: "#FF4F30",
                timerColor: "#FF4F30",
                infoButtonColor: "#FF4F30",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#E5632C" }, { time: 1, color: "#FE4530" }],
                },
            },
        },
    }),
}, true);
