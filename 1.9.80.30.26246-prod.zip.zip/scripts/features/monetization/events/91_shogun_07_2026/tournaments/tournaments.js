var _a, _b, _c, _d, _e;
var shogun_07_2026_tournaments = {
    TournamentGroup_1091001: new TournamentGroup({
        ID: 1091001,
        StartDate: EventTimeConstants.shogun_07_2026.tournaments._1.start,
        EndDate: EventTimeConstants.shogun_07_2026.tournaments._1.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tornament_event_description_event91_Shogun_Promo',
        InfoCards: TournamentVisualSettings.cardsPreset.slice(0, 1),
        AccountLevel: 6,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4_Shogun_Stronger_Rare,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        GuaranteeDraft: {
            heroId: heroes.Shogun.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_ONLY,
        },
        ExcludeHeroesFromDraft: {
            playerType: TOURNAMENT_GUARANTEE_DRAFT.BOT_ONLY,
            heroes: [
                heroes.Shogun.ID,
                heroes.Feldsher.ID,
                heroes.Helga.ID,
                heroes.Sarge.ID,
                heroes.Bulwark.ID,
            ],
        },
        BotPresetsByStage: [
            { stages: [2, 3], presets: heroesGroupsForTournaments.All_Heroes_6 },
            { stages: [4], presets: heroesGroupsForTournaments.All_Heroes_8 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Idle_Tournament,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_SHOGUN_PROMO.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.castle.ID,
            locations.viper_backstreet.ID,
        ],
        PresetLink: shogun_07_2026_tournaments_visual.promo,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_event_title_event91_Shogun_Promo',
                    AliasSubName: 'Tournament_event_subtitle_event91_Shogun',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_a = {}, _a[CURRENCY.COIN] = 10, _a)],
                    Rewards: shogun_07_2026_tournament_rewards.promo,
                    PictureInHub: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_2_hub",
                    PictureInWindow: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_2_window",
                    PictureSmall: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_2_banner",
                },
            ]
        },
    }),
    TournamentGroup_1091002: new TournamentGroup({
        ID: 1091002,
        StartDate: EventTimeConstants.shogun_07_2026.tournaments._1.start,
        EndDate: EventTimeConstants.shogun_07_2026.tournaments._1.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tornament_event_description_event91_Shogun_PVE',
        InfoCards: TournamentVisualSettings.cardsPreset.slice(0, 1),
        AccountLevel: 6,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        BotOpponentByStage: {
            4: [{ id: heroes.Shogun.ID, skinId: skins.Shogun_Base_skin.ID, level: 10 }],
        },
        BotPresetsByStage: [
            { stages: [2, 3], presets: heroesGroupsForTournaments.All_Heroes_6 },
        ],
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 1,
        BotSquad: TournamentBotSquad.BotSquad_Idle_Tournament,
        AutoBotDelay: TournamentBotDelay.BotDelay_noDelay,
        MatchingZones: TournamentMatchingZones.MatcherZones_PVE_12_stages,
        BattleID: battleSettings.EVENT_FREE.ID,
        LocationPool: [
            locations.bamboo_arena.ID,
            locations.castle.ID,
            locations.viper_backstreet.ID,
        ],
        PresetLink: shogun_07_2026_tournaments_visual.simple,
        MaxDailyWonTournamentsWithBot: MAX_SAFE_INTEGER,
        TeamMode: TEAM_MODE._1_VS_1_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_event_title_event91_Shogun',
                    AliasSubName: 'Tournament_event_subtitle_event91_Shogun',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_b = {}, _b[CURRENCY.TICKET_1] = 5, _b), (_c = {}, _c[CURRENCY.BONUS] = 49, _c)],
                    Rewards: shogun_07_2026_tournament_rewards.pve,
                    PictureInHub: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_hub",
                    PictureInWindow: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_hub",
                    PictureSmall: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_banner",
                },
            ]
        },
    }),
    TournamentGroup_1091003: new TournamentGroup({
        ID: 1091003,
        StartDate: EventTimeConstants.shogun_07_2026.tournaments._1.start,
        EndDate: EventTimeConstants.shogun_07_2026.tournaments._1.end,
        RestrictionMatchingTime: new Time({ Minutes: 10 }).value,
        RestrictionRegistrationTime: new Time({ Hours: 1 }).value,
        AliasDesc: 'Tornament_event_description_event91_Shogun_PVP',
        InfoCards: TournamentVisualSettings.cardsPreset,
        AccountLevel: 6,
        HeroPresetsGroup: heroesGroupsForTournaments.All_Heroes_4_Shogun_Stronger,
        RestrictionPlayerParams: {
            AccountLevel: { min: 2, max: 13 },
        },
        GuaranteeDraft: {
            heroId: heroes.Shogun.ID,
            type: TOURNAMENT_GUARANTEE_DRAFT.PLAYER_AND_BOT,
        },
        UITimerBeforeEnd: TournamentConstants.UITimerBeforeEnd,
        Stages: 5,
        DefeatsNumberToExit: 3,
        BotSquad: TournamentBotSquad.commonBotDifficulty,
        AutoBotDelay: TournamentBotDelay.BotDelay_12_stages,
        MatchingZones: TournamentMatchingZones.MatcherZones_total,
        BattleID: battleSettings.EVENT_FREE.ID,
        LocationPool: [
            locations.thunder.ID,
            locations.castle.ID,
            locations.viper_backstreet.ID,
        ],
        PresetLink: shogun_07_2026_tournaments_visual.simple,
        MaxDailyWonTournamentsWithBot: 35,
        TeamMode: TEAM_MODE._3_VS_3_,
        TournamentSettings: {
            items: [
                {
                    AliasName: 'Tournament_event_title_event91_Shogun_PVP',
                    AliasSubName: 'Tournament_event_subtitle_event91_Shogun',
                    CardAliasSubName: 'tournament_event_lowercase',
                    Prices: [(_d = {}, _d[CURRENCY.TICKET_1] = 10, _d), (_e = {}, _e[CURRENCY.BONUS] = 99, _e)],
                    Rewards: shogun_07_2026_tournament_rewards.pvp,
                    PictureInHub: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_hub",
                    PictureInWindow: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_hub",
                    PictureSmall: "Sprites/PreviewImages/Events/Shogun/tournament_art_shogun_1_banner",
                    PremiumType: {
                        IsPremium: true,
                        Alias: 'tournament_event_high_stakes'
                    }
                },
            ]
        },
    }),
};
extend(eventTournaments, shogun_07_2026_tournaments, true);
