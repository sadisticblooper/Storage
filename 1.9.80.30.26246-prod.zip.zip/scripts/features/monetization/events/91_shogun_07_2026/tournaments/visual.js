var shogun_07_2026_tournaments_visual = {
    promo: {
        "lobbyAndHubItemArtColor": "#B84733C1",
        "draftAndEventWindowArtColor": "#732416",
        "lobbyAndHubItemGradientDefault": {
            "colorKeys": [
                {
                    "color": "#5c1d11",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "lobbyAndHubItemGradientPremium": {
            "colorKeys": [
                {
                    "color": "#736335",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "draftAndEventWindowGradientColorPremium": "#8487a1",
        "draftAndEventWindowGradientColorDefault": "#8487a1",
        "eventWindowGlowPremium": "#5e6073",
        "eventWindowGlowDefault": "#5e6073",
        "eventWindowRightGradientPremium": "#5e6073",
        "eventWindowRightGradientDefault": "#5e6073",
        "hubItemPositionPremium": { "x": 0, "y": 0 },
        "hubItemPositionDefault": { "x": 0, "y": 0 },
        "hubItemScalePremium": 1,
        "hubItemScaleDefault": 1,
        "eventSubTitleColorPremium": "#ff4f30",
        "eventSubTitleColorDefault": "#ff4f30",
        "icon": null
    },
    simple: {
        "lobbyAndHubItemArtColor": "#979ab8",
        "draftAndEventWindowArtColor": "#4B4D5CB2",
        "lobbyAndHubItemGradientDefault": {
            "colorKeys": [
                {
                    "color": "#5c1d11",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "lobbyAndHubItemGradientPremium": {
            "colorKeys": [
                {
                    "color": "#736335",
                    "time": 0.0
                },
                {
                    "color": "#384145",
                    "time": 1.0
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 1.0,
                    "time": 0.0
                },
                {
                    "alpha": 1.0,
                    "time": 1.0
                }
            ],
            "mode": 0
        },
        "draftAndEventWindowGradientColorPremium": "#73612A",
        "draftAndEventWindowGradientColorDefault": "#5c1d11",
        "eventWindowGlowPremium": "#73612A",
        "eventWindowGlowDefault": "#732416",
        "eventWindowRightGradientPremium": "#73612A",
        "eventWindowRightGradientDefault": "#5c1d11",
        "hubItemPositionPremium": { "x": 354, "y": 0 },
        "hubItemPositionDefault": { "x": -354, "y": 0 },
        "hubItemScalePremium": 1,
        "hubItemScaleDefault": 1,
        "eventSubTitleColorPremium": "#FFD75E",
        "eventSubTitleColorDefault": "#ff4f30",
        "icon": 54
    },
};
