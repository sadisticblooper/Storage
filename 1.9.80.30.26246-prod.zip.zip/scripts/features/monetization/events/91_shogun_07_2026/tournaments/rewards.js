var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4;
var shogun_07_2026_tournament_rewards = {
    promo: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 10, _a) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.CHIP_1] = 50, _b) }) },
            },
            2: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.CHIP_1] = 150, _c) }) },
            },
            3: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.TOKEN_1] = 500, _d) }) },
            },
            4: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.CHIP_1] = 300, _e) }) },
            },
            5: {
                repeatable: null,
                onetime: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.CHIP_1] = 500, _f) }) },
            },
        },
    },
    pve: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.TOKEN_1] = 25, _g) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.TOKEN_1] = 50, _h) }) },
                onetime: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.CHIP_1] = 250, _j) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.CHIP_1] = 40, _k) }) },
                onetime: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.TOKEN_1] = 450, _l) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.TOKEN_1] = 50, _m) }) },
                onetime: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.CHIP_1] = 400, _o) }) },
            },
            4: {
                repeatable: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.CHIP_1] = 60, _p) }) },
                onetime: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.TOKEN_1] = 500, _q) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.TOKEN_1] = 100, _r) }) },
                onetime: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.TOKEN_1] = 1000, _t) }) },
            },
        },
    },
    pvp: {
        loseRewards: [
            {
                check: function (_s) { return true; },
                reward: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.TOKEN_1] = 25, _u) }) },
            }
        ],
        rewards: {
            1: {
                repeatable: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.TOKEN_1] = 50, _v) }) },
                onetime: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.TOKEN_1] = 500, _w) }) },
            },
            2: {
                repeatable: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.CHIP_1] = 70, _x) }) },
                onetime: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.TOKEN_1] = 750, _y) }) },
            },
            3: {
                repeatable: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.TOKEN_1] = 100, _z) }) },
                onetime: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.CHIP_1] = 400, _0) }) },
            },
            4: {
                repeatable: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.CHIP_1] = 100, _1) }) },
                onetime: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.TOKEN_1] = 1800, _2) }) },
            },
            5: {
                repeatable: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.TOKEN_1] = 300, _3) }) },
                onetime: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.CHIP_1] = 700, _4) }) },
            },
        },
    },
};
