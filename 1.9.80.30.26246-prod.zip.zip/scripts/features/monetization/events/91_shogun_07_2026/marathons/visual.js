var event_shogun_07_2026_marathons_visual = {
    tournament: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/Shogun/marathon_bg_shogun",
            "color": "#4b4d5c8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Challenges/Icons/icon_SHOGUN",
            "IconColor": "#ff4f30",
            "BgColor": "#4b4d5c"
        },
        "DetailsColor": "#ff4f30",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#8a2b1a",
                    "time": 0
                },
                {
                    "color": "#26262e",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": null,
        "PatternBgColor": "#171717"
    },
    chips: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/Shogun/marathon_bg_eternium",
            "color": "#71738a8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Challenges/Icons/icon_CHIP",
            "IconColor": "#bcc0e6",
            "BgColor": "#bcc0e6"
        },
        "DetailsColor": "#bcc0e6",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#8a2b1a",
                    "time": 0
                },
                {
                    "color": "#383a45",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": {
            "sprite": "Sprites/PreviewImages/Events/Shogun/marathon_pattern_eternium",
            "color": "#979AB82E"
        },
        "PatternBgColor": "#979AB85C"
    },
    daily: {
        "BgImage": {
            "name": "Sprites/PreviewImages/Events/Shogun/marathon_bg_eternium",
            "color": "#8a2b1a8A"
        },
        "Icon": {
            "IconBgName": "Sprites/Assets/Challenges/Icons/marathon_icon_bg",
            "Name": "Sprites/Assets/Icons/currency_token_itu",
            "IconColor": "#55d0e6",
            "BgColor": "#55d0e6"
        },
        "DetailsColor": "#55d0e6",
        "BgGradient": {
            "colorKeys": [
                {
                    "color": "#44a6b8",
                    "time": 0
                },
                {
                    "color": "#5c1d11",
                    "time": 1
                }
            ],
            "alphaKeys": [
                {
                    "alpha": 0.72,
                    "time": 0
                },
                {
                    "alpha": 0.72,
                    "time": 1
                }
            ],
            "mode": 1
        },
        "Pattern": null,
        "PatternBgColor": "#171717"
    },
};
