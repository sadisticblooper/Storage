var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88;
var shogun_07_2026_marathons = {
    PROMO_BuM_Event_Shogun_tournament: new Marathon({
        PromoSettings: {
            conditions: {
                accountLevel: { more_or_equal: 2 },
            },
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.buyout_tournament.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.buyout_tournament.end,
            },
        },
        ID: 1091001,
        Alias: "marathon_title_event91_Shogun_Tournament",
        Description: "marathon_desc_event91_Shogun_Tournament",
        PointsDescription: 'marathon_descPoints_event91_Shogun_Tournament',
        ViewConfig: event_shogun_07_2026_marathons_visual.tournament,
        PaidClaimButtonAutoSettings: {
            offers: [{ points: 0,
                    offer: {
                        offerId: 1091001,
                        inApp: inAppSettings.PRICE_15.ProductID,
                        offerName: "PROMO_BuM_Event_Shogun_07_2026_Tournament"
                    }
                }],
            buttonLabel: { isAlias: true, value: "marathon_claim_allprice_button", placeholders: null, },
            hideButtonAfterRewardStep: 12001,
            popUpDescriptionAlias: null,
            buttonState: "MarathonButtonUnlockBright"
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.BUYOUT,
        Rewards: {
            200: { chests: [chests.Upgrade_chest.ID] },
            500: { loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.TOKEN_1] = 500, _a) }) },
            1000: { loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.CHIP_1] = 250, _b) }) },
            2000: { loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.TOKEN_1] = 1000, _c) }) },
            3000: { loot: new Loot({ Currencies: (_d = {}, _d[CURRENCY.CHIP_1] = 300, _d) }) },
            4000: { loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.CHIP_1] = 350, _e) }) },
            5000: { loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.TOKEN_1] = 1500, _f) }) },
            6000: { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.CHIP_1] = 400, _g) }) },
            8000: { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.CHIP_1] = 500, _h) }) },
            10000: { loot: new Loot({ Stances: [stances.win_Shogun_R_Stomp.ID] }) },
            12000: { loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.CHIP_1] = 700, _j) }) },
            15000: { chests: [chests.Butcher_legendary_weapon_chest.ID] },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        SortingOrder: 2,
        Update: function (args) {
            var eventTournaments = shogun_07_2026_tournaments.TournamentGroup_1091002.getTournaments().map(function (t) { return t.ID; })
                .concat(shogun_07_2026_tournaments.TournamentGroup_1091003.getTournaments().map(function (t) { return t.ID; }));
            var pointsForWinFight = 60;
            var pointsForWinRound = 35;
            var battleStats = QuestUtils.getArgByName(args, "BattleStats");
            var tournamentId = battleStats.TournamentId ? +battleStats.TournamentId : 0;
            var fightResult = battleStats.FightResult, rounds = battleStats.Rounds;
            var isFightInEventTournament = tournamentId && eventTournaments.indexOf(tournamentId) > -1;
            var points = 0;
            if (isFightInEventTournament) {
                if (fightResult == FIGHT_RESULT.WIN || fightResult == FIGHT_RESULT.TECH_WIN) {
                    points += pointsForWinFight;
                }
                if (rounds) {
                    for (var _i = 0, rounds_1 = rounds; _i < rounds_1.length; _i++) {
                        var round = rounds_1[_i];
                        if (round.RoundResult == ROUND_RESULT.ROUND_RESULT_WIN) {
                            points += pointsForWinRound;
                        }
                    }
                }
            }
            return args.Progress + points;
        }
    }),
    PROMO_PaM_Event_Shogun_chips: new Marathon({
        ID: 1091002,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.paid_chips.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.paid_chips.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun_Chips",
        Description: "marathon_desc_event91_Shogun_Chips",
        PointsDescription: 'marathon_descPoints_event_gideon_2',
        ViewConfig: event_shogun_07_2026_marathons_visual.chips,
        UnlockRewardsButtonAutoSettings: {
            offers: [{ points: 0,
                    offer: {
                        offerId: 1091002,
                        offerName: "PROMO_PaM_Event_Shogun_07_2026_Chips",
                        inApp: inAppSettings.PRICE_20.ProductID
                    }
                }],
            buttonAlias: "marathon_unlockprice_button",
        },
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.PAID_COLLECT,
        Rewards: {
            50: { loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.CHIP_1] = 250, _k) }) },
            150: { loot: new Loot({ Currencies: (_l = {}, _l[CURRENCY.TOKEN_1] = 500, _l) }) },
            300: { loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.CHIP_1] = 400, _m) }) },
            500: { loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.TOKEN_1] = 1000, _o) }) },
            1000: { loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.CHIP_1] = 450, _p) }) },
            2000: { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.CHIP_1] = 600, _q) }) },
            3250: { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.TOKEN_1] = 1500, _r) }) },
            4500: { loot: new Loot({ Currencies: (_s = {}, _s[CURRENCY.CHIP_1] = 800, _s) }) },
            5750: { isHidden: false, loot: new Loot({ Weapons: [heroWeapons.wpn_Shogun_R_Base_Rec_Vassal.ID] }) },
        },
        UpdateEvents: [QUEST_EVENT.CURRENCY_WITHDRAW],
        Update: function (args) {
            var checkedCurrency = CURRENCY.CHIP_1;
            var pointsPerOneCurrency = 1;
            var points = 0;
            var spending = args.CurrencyWithdraw && args.CurrencyWithdraw.Type == checkedCurrency
                ? args.CurrencyWithdraw.Amount
                : 0;
            points += ((spending * pointsPerOneCurrency) >> 0);
            return args.Progress + points;
        }
    }),
    PROMO_CaM_Event_Shogun_daily_1_1: new Marathon({
        ID: 1091003,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_1.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_1.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_1',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_t = {}, _t[CURRENCY.TOKEN_1] = 100, _t) }) },
            220: { loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.TOKEN_ITU] = 200, _u) }) },
            340: { loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.TOKEN_1] = 200, _v) }) },
            460: { loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.TOKEN_ITU] = 300, _w) }) },
            580: { loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.TOKEN_1] = 300, _x) }) },
            700: { loot: new Loot({ Currencies: (_y = {}, _y[CURRENCY.TOKEN_ITU] = 300, _y) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 30,
            pointsForWin3v3: 30,
            pointsForWin1v1AsHero: 40,
            pointsForWin3v3AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_2_2: new Marathon({
        ID: 1091004,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_2.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_2.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_2',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_z = {}, _z[CURRENCY.TOKEN_1] = 100, _z) }) },
            210: { loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.TOKEN_ITU] = 200, _0) }) },
            320: { loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.TOKEN_1] = 200, _1) }) },
            430: { loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.TOKEN_ITU] = 250, _2) }) },
            540: { loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.TOKEN_1] = 300, _3) }) },
            650: { loot: new Loot({ Currencies: (_4 = {}, _4[CURRENCY.TOKEN_ITU] = 350, _4) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForWin1v1: 20,
            pointsForWin1v1AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_3_3: new Marathon({
        ID: 1076005,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_3.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_3.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_3',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_5 = {}, _5[CURRENCY.TOKEN_1] = 100, _5) }) },
            200: { loot: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.TOKEN_ITU] = 200, _6) }) },
            300: { loot: new Loot({ Currencies: (_7 = {}, _7[CURRENCY.TOKEN_1] = 200, _7) }) },
            400: { loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.TOKEN_ITU] = 250, _8) }) },
            500: { loot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.TOKEN_1] = 300, _9) }) },
            600: { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.TOKEN_ITU] = 350, _10) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss3v3: 10,
            pointsForWin3v3: 40,
            pointsForWin3v3AsHero: 50,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_1_4: new Marathon({
        ID: 1091006,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_4.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_4.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_1',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_11 = {}, _11[CURRENCY.TOKEN_1] = 100, _11) }) },
            220: { loot: new Loot({ Currencies: (_12 = {}, _12[CURRENCY.TOKEN_ITU] = 200, _12) }) },
            340: { loot: new Loot({ Currencies: (_13 = {}, _13[CURRENCY.TOKEN_1] = 200, _13) }) },
            460: { loot: new Loot({ Currencies: (_14 = {}, _14[CURRENCY.TOKEN_ITU] = 300, _14) }) },
            580: { loot: new Loot({ Currencies: (_15 = {}, _15[CURRENCY.TOKEN_1] = 300, _15) }) },
            700: { loot: new Loot({ Currencies: (_16 = {}, _16[CURRENCY.TOKEN_ITU] = 300, _16) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 30,
            pointsForWin3v3: 30,
            pointsForWin1v1AsHero: 40,
            pointsForWin3v3AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_2_5: new Marathon({
        ID: 1091007,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_5.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_5.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_2',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_17 = {}, _17[CURRENCY.TOKEN_1] = 100, _17) }) },
            210: { loot: new Loot({ Currencies: (_18 = {}, _18[CURRENCY.TOKEN_ITU] = 200, _18) }) },
            320: { loot: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.TOKEN_1] = 200, _19) }) },
            430: { loot: new Loot({ Currencies: (_20 = {}, _20[CURRENCY.TOKEN_ITU] = 250, _20) }) },
            540: { loot: new Loot({ Currencies: (_21 = {}, _21[CURRENCY.TOKEN_1] = 300, _21) }) },
            650: { loot: new Loot({ Currencies: (_22 = {}, _22[CURRENCY.TOKEN_ITU] = 350, _22) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForWin1v1: 20,
            pointsForWin1v1AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_3_6: new Marathon({
        ID: 1091008,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_6.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_6.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_3',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_23 = {}, _23[CURRENCY.TOKEN_1] = 100, _23) }) },
            200: { loot: new Loot({ Currencies: (_24 = {}, _24[CURRENCY.TOKEN_ITU] = 200, _24) }) },
            300: { loot: new Loot({ Currencies: (_25 = {}, _25[CURRENCY.TOKEN_1] = 200, _25) }) },
            400: { loot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.TOKEN_ITU] = 250, _26) }) },
            500: { loot: new Loot({ Currencies: (_27 = {}, _27[CURRENCY.TOKEN_1] = 300, _27) }) },
            600: { loot: new Loot({ Currencies: (_28 = {}, _28[CURRENCY.TOKEN_ITU] = 350, _28) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss3v3: 10,
            pointsForWin3v3: 40,
            pointsForWin3v3AsHero: 50,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_1_7: new Marathon({
        ID: 1091009,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_7.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_7.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_1',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_29 = {}, _29[CURRENCY.TOKEN_1] = 100, _29) }) },
            220: { loot: new Loot({ Currencies: (_30 = {}, _30[CURRENCY.TOKEN_ITU] = 200, _30) }) },
            340: { loot: new Loot({ Currencies: (_31 = {}, _31[CURRENCY.TOKEN_1] = 200, _31) }) },
            460: { loot: new Loot({ Currencies: (_32 = {}, _32[CURRENCY.TOKEN_ITU] = 300, _32) }) },
            580: { loot: new Loot({ Currencies: (_33 = {}, _33[CURRENCY.TOKEN_1] = 300, _33) }) },
            700: { loot: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.TOKEN_ITU] = 300, _34) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 30,
            pointsForWin3v3: 30,
            pointsForWin1v1AsHero: 40,
            pointsForWin3v3AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_2_8: new Marathon({
        ID: 1091010,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_8.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_8.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_2',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_35 = {}, _35[CURRENCY.TOKEN_1] = 100, _35) }) },
            210: { loot: new Loot({ Currencies: (_36 = {}, _36[CURRENCY.TOKEN_ITU] = 200, _36) }) },
            320: { loot: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.TOKEN_1] = 200, _37) }) },
            430: { loot: new Loot({ Currencies: (_38 = {}, _38[CURRENCY.TOKEN_ITU] = 250, _38) }) },
            540: { loot: new Loot({ Currencies: (_39 = {}, _39[CURRENCY.TOKEN_1] = 300, _39) }) },
            650: { loot: new Loot({ Currencies: (_40 = {}, _40[CURRENCY.TOKEN_ITU] = 350, _40) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForWin1v1: 20,
            pointsForWin1v1AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_3_9: new Marathon({
        ID: 1091011,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_9.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_9.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_3',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_41 = {}, _41[CURRENCY.TOKEN_1] = 100, _41) }) },
            200: { loot: new Loot({ Currencies: (_42 = {}, _42[CURRENCY.TOKEN_ITU] = 200, _42) }) },
            300: { loot: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.TOKEN_1] = 200, _43) }) },
            400: { loot: new Loot({ Currencies: (_44 = {}, _44[CURRENCY.TOKEN_ITU] = 250, _44) }) },
            500: { loot: new Loot({ Currencies: (_45 = {}, _45[CURRENCY.TOKEN_1] = 300, _45) }) },
            600: { loot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.TOKEN_ITU] = 350, _46) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss3v3: 10,
            pointsForWin3v3: 40,
            pointsForWin3v3AsHero: 50,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_1_10: new Marathon({
        ID: 1091012,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_10.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_1_10.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_1',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_47 = {}, _47[CURRENCY.TOKEN_1] = 100, _47) }) },
            220: { loot: new Loot({ Currencies: (_48 = {}, _48[CURRENCY.TOKEN_ITU] = 200, _48) }) },
            340: { loot: new Loot({ Currencies: (_49 = {}, _49[CURRENCY.TOKEN_1] = 200, _49) }) },
            460: { loot: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.TOKEN_ITU] = 300, _50) }) },
            580: { loot: new Loot({ Currencies: (_51 = {}, _51[CURRENCY.TOKEN_1] = 300, _51) }) },
            700: { loot: new Loot({ Currencies: (_52 = {}, _52[CURRENCY.TOKEN_ITU] = 300, _52) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 30,
            pointsForWin3v3: 30,
            pointsForWin1v1AsHero: 40,
            pointsForWin3v3AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_2_11: new Marathon({
        ID: 1091013,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_11.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_2_11.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_2',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_53 = {}, _53[CURRENCY.TOKEN_1] = 100, _53) }) },
            210: { loot: new Loot({ Currencies: (_54 = {}, _54[CURRENCY.TOKEN_ITU] = 200, _54) }) },
            320: { loot: new Loot({ Currencies: (_55 = {}, _55[CURRENCY.TOKEN_1] = 200, _55) }) },
            430: { loot: new Loot({ Currencies: (_56 = {}, _56[CURRENCY.TOKEN_ITU] = 250, _56) }) },
            540: { loot: new Loot({ Currencies: (_57 = {}, _57[CURRENCY.TOKEN_1] = 300, _57) }) },
            650: { loot: new Loot({ Currencies: (_58 = {}, _58[CURRENCY.TOKEN_ITU] = 350, _58) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForWin1v1: 20,
            pointsForWin1v1AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_4_12: new Marathon({
        ID: 1091014,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_4_12.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_4_12.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_4',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_59 = {}, _59[CURRENCY.TOKEN_1] = 100, _59) }) },
            220: { loot: new Loot({ Currencies: (_60 = {}, _60[CURRENCY.TOKEN_ITU] = 200, _60) }) },
            340: { loot: new Loot({ Currencies: (_61 = {}, _61[CURRENCY.TOKEN_1] = 150, _61) }) },
            460: { loot: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.TOKEN_ITU] = 225, _62) }) },
            580: { loot: new Loot({ Currencies: (_63 = {}, _63[CURRENCY.TOKEN_1] = 300, _63) }) },
            700: { loot: new Loot({ Currencies: (_64 = {}, _64[CURRENCY.TOKEN_ITU] = 250, _64) }) },
            820: { loot: new Loot({ Currencies: (_65 = {}, _65[CURRENCY.TOKEN_1] = 350, _65) }) },
            940: { loot: new Loot({ Currencies: (_66 = {}, _66[CURRENCY.TOKEN_ITU] = 275, _66) }) },
            1060: { loot: new Loot({ Currencies: (_67 = {}, _67[CURRENCY.TOKEN_1] = 400, _67) }) },
            1180: { loot: new Loot({ Currencies: (_68 = {}, _68[CURRENCY.TOKEN_ITU] = 300, _68) }) },
            1300: { loot: new Loot({ Currencies: (_69 = {}, _69[CURRENCY.TOKEN_1] = 500, _69) }) },
            1420: { loot: new Loot({ Currencies: (_70 = {}, _70[CURRENCY.TOKEN_ITU] = 350, _70) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 20,
            pointsForWin3v3: 40,
            pointsForWin1v1AsHero: 60,
            pointsForWin3v3AsHero: 60,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_4_13: new Marathon({
        ID: 1091015,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_4_13.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_4_13.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_4',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_71 = {}, _71[CURRENCY.TOKEN_1] = 100, _71) }) },
            220: { loot: new Loot({ Currencies: (_72 = {}, _72[CURRENCY.TOKEN_ITU] = 200, _72) }) },
            340: { loot: new Loot({ Currencies: (_73 = {}, _73[CURRENCY.TOKEN_1] = 150, _73) }) },
            460: { loot: new Loot({ Currencies: (_74 = {}, _74[CURRENCY.TOKEN_ITU] = 225, _74) }) },
            580: { loot: new Loot({ Currencies: (_75 = {}, _75[CURRENCY.TOKEN_1] = 300, _75) }) },
            700: { loot: new Loot({ Currencies: (_76 = {}, _76[CURRENCY.TOKEN_ITU] = 250, _76) }) },
            820: { loot: new Loot({ Currencies: (_77 = {}, _77[CURRENCY.TOKEN_1] = 350, _77) }) },
            940: { loot: new Loot({ Currencies: (_78 = {}, _78[CURRENCY.TOKEN_ITU] = 275, _78) }) },
            1060: { loot: new Loot({ Currencies: (_79 = {}, _79[CURRENCY.TOKEN_1] = 400, _79) }) },
            1180: { loot: new Loot({ Currencies: (_80 = {}, _80[CURRENCY.TOKEN_ITU] = 300, _80) }) },
            1300: { loot: new Loot({ Currencies: (_81 = {}, _81[CURRENCY.TOKEN_1] = 500, _81) }) },
            1420: { loot: new Loot({ Currencies: (_82 = {}, _82[CURRENCY.TOKEN_ITU] = 350, _82) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 20,
            pointsForWin3v3: 40,
            pointsForWin1v1AsHero: 60,
            pointsForWin3v3AsHero: 60,
            eventTournamentID: 10910031,
        }),
    }),
    PROMO_CaM_Event_Shogun_daily_1_1_relaunch: new Marathon({
        ID: 1091016,
        PromoSettings: {
            activeTime: {
                startGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_3.start,
                endGenerationBound: EventTimeConstants.shogun_07_2026.marathons.daily_3_3.end,
            },
            conditions: { accountLevel: { more_or_equal: 2 }, },
        },
        Alias: "marathon_title_event91_Shogun",
        Description: "marathon_desc_event91_Shogun",
        PointsDescription: 'marathon_descPoints_event91_Shogun_1',
        ViewConfig: event_shogun_07_2026_marathons_visual.daily,
        CollectRewardsStrategy: MARATHON_COLLECT_REWARDS_STRATEGY.COMMON,
        Rewards: {
            100: { loot: new Loot({ Currencies: (_83 = {}, _83[CURRENCY.TOKEN_1] = 100, _83) }) },
            220: { loot: new Loot({ Currencies: (_84 = {}, _84[CURRENCY.TOKEN_ITU] = 200, _84) }) },
            340: { loot: new Loot({ Currencies: (_85 = {}, _85[CURRENCY.TOKEN_1] = 200, _85) }) },
            460: { loot: new Loot({ Currencies: (_86 = {}, _86[CURRENCY.TOKEN_ITU] = 300, _86) }) },
            580: { loot: new Loot({ Currencies: (_87 = {}, _87[CURRENCY.TOKEN_1] = 300, _87) }) },
            700: { loot: new Loot({ Currencies: (_88 = {}, _88[CURRENCY.TOKEN_ITU] = 300, _88) }) },
        },
        UpdateEvents: [QUEST_EVENT.FIGHT_END],
        Update: UpdaterTemplates.rankedAndRogueliteWithHeroCheck({
            heroID: heroes.Shogun.ID,
            pointsForChapterPass: 50,
            pointsForLoss1v1: 10,
            pointsForLoss3v3: 10,
            pointsForWin1v1: 30,
            pointsForWin3v3: 30,
            pointsForWin1v1AsHero: 40,
            pointsForWin3v3AsHero: 40,
            eventTournamentID: 10910031,
        }),
    }),
};
extend(Marathons, shogun_07_2026_marathons, true);
