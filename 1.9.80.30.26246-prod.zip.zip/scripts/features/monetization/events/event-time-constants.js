var EventTimeConstants = (function () {
    function EventTimeConstants() {
    }
    EventTimeConstants.defaultEventMock = {
        event: {
            start: new Date("2007-01-01").getTime(),
            end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
        },
        questQueueStartArray: [
            new Date("2007-01-01").getTime(),
            new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            openChest: {
                start: new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
                end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
            },
            getCards: {
                start: new Date("2007-01-01").getTime(),
                end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
            },
            tournaments: {
                start: new Date("2007-01-01").getTime(),
                end: new Date("2007-01-01").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2007-01-01").getTime(),
                end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
            },
            second: {
                start: new Date("2007-01-01").getTime(),
                end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
            },
        },
        roulette: {
            start: new Date("2007-01-01").getTime(),
            end: new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
            first: {
                start: new Date("2007-01-01").getTime(),
                end: new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
            },
            second: {
                start: new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
                end: new Date("2007-01-01").getTime() + new Time({ Days: 14 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2007-01-01").getTime(), [1, 4, 8, 11]),
        },
        gacha: {
            start: new Date("2007-01-01").getTime(),
            end: new Date("2007-01-01").getTime() + new Time({ Days: 7 }).value,
        },
    };
    EventTimeConstants.Widow_2024 = {
        event: {
            start: new Date("2024-11-21").getTime(),
            end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2024-11-21").getTime(),
        ],
        roulette: {
            first: {
                start: new Date("2024-11-21").getTime(),
                end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2024-11-21").getTime(),
                end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
            },
            chips: {
                start: new Date("2024-11-21").getTime(),
                end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2024-11-21").getTime(),
                end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
            },
            second: {
                start: new Date("2024-11-21").getTime(),
                end: new Date("2024-11-21").getTime() + new Time({ Days: 7 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2024-11-21").getTime(), [2, 3, 5]),
        }
    };
    EventTimeConstants.April_2024 = {
        event: {
            start: new Date("2024-11-28").getTime(),
            end: new Date("2024-11-28").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2024-11-28").getTime(),
            new Date("2024-11-28").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2024-11-28").getTime(),
                end: new Date("2024-11-28").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2024-11-28").getTime(), [1, 4, 7, 11]),
        },
    };
    EventTimeConstants.stars_NY_2024 = {
        event: {
            start: new Date("2024-12-19").getTime(),
            end: new Date("2024-12-19").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2024-12-19").getTime(),
            new Date("2024-12-19").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2024-12-19").getTime(),
                end: new Date("2024-12-19").getTime() + new Time({ Days: 13 }).value,
            },
            getCards: {
                start: new Date("2024-12-19").getTime(),
                end: new Date("2024-12-19").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2024-12-19").getTime(),
                end: new Date("2024-12-19").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2024-12-19").getTime(),
                end: new Date("2024-12-19").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2024-12-19").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.black_market_01_2025 = {
        event: {
            start: new Date("2025-01-02").getTime(),
            end: new Date("2025-01-02").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-01-02").getTime(),
            new Date("2025-01-02").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-01-02").getTime(),
                end: new Date("2025-01-02").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-01-04").getTime(),
                end: new Date("2025-01-04").getTime() + new Time({ Days: 2 }).value,
            },
            time_2: {
                start: new Date("2025-01-11").getTime(),
                end: new Date("2025-01-11").getTime() + new Time({ Days: 2 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-01-02").getTime(),
                end: new Date("2025-01-02").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-01-02").getTime(),
                end: new Date("2025-01-02").getTime() + new Time({ Days: 13 }).value,
            },
            second: {
                start: new Date("2025-01-02").getTime() + new Time({ Days: 7 }).value,
                end: new Date("2025-01-02").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-01-02").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.MNY_2025 = {
        event: {
            start: new Date("2025-01-23").getTime(),
            end: new Date("2025-01-23").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-01-23").getTime(),
            new Date("2025-01-23").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            openChest: {
                start: new Date("2025-01-23").getTime(),
                end: new Date("2025-01-23").getTime() + new Time({ Days: 13 }).value,
            }
        },
        tournaments: {
            first: {
                start: new Date("2025-01-23").getTime(),
                end: new Date("2025-01-23").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-01-23").getTime(),
                end: new Date("2025-01-23").getTime() + new Time({ Days: 13 }).value,
            },
            second: {
                start: new Date("2025-01-23").getTime(),
                end: new Date("2025-01-23").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-01-23").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Valentine_2025 = {
        event: {
            start: new Date("2025-02-05").getTime(),
            end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2025-02-05").getTime(),
        ],
        roulette: {
            first: {
                start: new Date("2025-02-05").getTime(),
                end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-02-05").getTime(),
                end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
            },
            chips: {
                start: new Date("2025-02-05").getTime(),
                end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-02-05").getTime(),
                end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
            },
            second: {
                start: new Date("2025-02-05").getTime(),
                end: new Date("2025-02-05").getTime() + new Time({ Days: 7 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-02-05").getTime(), [2, 3, 5]),
        }
    };
    EventTimeConstants.April_2025 = {
        event: {
            start: new Date("2025-02-21").getTime(),
            end: new Date("2025-02-21").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-02-21").getTime(),
            new Date("2025-02-21").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-02-21").getTime(),
                end: new Date("2025-02-21").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-02-21").getTime(),
                end: new Date("2025-02-21").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-02-21").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Holi_2025 = {
        event: {
            start: new Date("2025-03-13").getTime(),
            end: new Date("2025-03-13").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2025-03-13").getTime(),
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-03-13").getTime(),
                end: new Date("2025-03-13").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-03-13").getTime(),
                end: new Date("2025-03-13").getTime() + new Time({ Days: 7 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-03-13").getTime(),
                end: new Date("2025-03-13").getTime() + new Time({ Days: 7 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-03-13").getTime(), [2, 3, 5]),
        },
    };
    EventTimeConstants.Sakura_2025 = {
        event: {
            start: new Date("2025-03-20").getTime(),
            end: new Date("2025-03-20").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-03-20").getTime(),
            new Date("2025-03-20").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-03-20").getTime(),
                end: new Date("2025-03-20").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-03-20").getTime(),
                end: new Date("2025-03-20").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-03-20").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Black_Market_04_2025 = {
        event: {
            start: new Date("2025-04-10").getTime(),
            end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-04-10").getTime(),
            new Date("2025-04-10").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-04-10").getTime(),
                end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2025-04-10").getTime(),
                end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-04-10").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-04-10").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2025-04-10").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-04-10").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            pve: {
                start: new Date("2025-04-10").getTime(),
                end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
            },
            pvp: {
                start: new Date("2025-04-10").getTime(),
                end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
            },
            fruit_ninja_first: {
                start: new Date("2025-04-10").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-04-10").getTime() + new Time({ Days: 4 }).value,
            },
            fruit_ninja_second: {
                start: new Date("2025-04-10").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-04-10").getTime() + new Time({ Days: 11 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-04-10").getTime(),
                end: new Date("2025-04-10").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-04-10").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Vampire_2025 = {
        event: {
            start: new Date("2025-05-01").getTime(),
            end: new Date("2025-05-01").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-05-01").getTime(),
            new Date("2025-05-01").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-05-01").getTime(),
                end: new Date("2025-05-01").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-05-01").getTime(),
                end: new Date("2025-05-01").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-05-01").getTime(),
                end: new Date("2025-05-01").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-05-01").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Leg_Skins_2025 = {
        event: {
            start: new Date("2025-05-15").getTime(),
            end: new Date("2025-05-15").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-05-15").getTime(),
            new Date("2025-05-15").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-05-15").getTime(),
                end: new Date("2025-05-15").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-05-15").getTime(),
                end: new Date("2025-05-15").getTime() + new Time({ Days: 13 }).value,
            },
            getCards: {
                start: new Date("2025-05-15").getTime(),
                end: new Date("2025-05-15").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-05-15").getTime(),
                end: new Date("2025-05-15").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-05-15").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Midsummer_2025 = {
        event: {
            start: new Date("2025-06-05").getTime(),
            end: new Date("2025-06-05").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-06-05").getTime(),
            new Date("2025-06-05").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-06-05").getTime(),
                end: new Date("2025-06-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-06-05").getTime(),
                end: new Date("2025-06-05").getTime() + new Time({ Days: 13 }).value,
            },
            battlePass: {
                start: new Date("2025-06-05").getTime(),
                end: new Date("2025-06-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-06-05").getTime(),
                end: new Date("2025-06-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-06-05").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Raikichi_2025 = {
        event: {
            start: new Date("2025-06-24").getTime(),
            end: new Date("2025-06-24").getTime() + new Time({ Days: 15 }).value,
        },
        questQueueStartArray: [
            new Date("2025-06-24").getTime(),
            new Date("2025-06-24").getTime() + new Time({ Days: 10 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-06-24").getTime(),
                end: new Date("2025-06-24").getTime() + new Time({ Days: 15 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-06-24").getTime(),
                end: new Date("2025-06-24").getTime() + new Time({ Days: 15 }).value,
            },
            chips: {
                first: {
                    start: new Date("2025-06-24").getTime(),
                    end: new Date("2025-06-24").getTime() + new Time({ Days: 15 }).value,
                },
                second: {
                    start: new Date("2025-07-04").getTime(),
                    end: new Date("2025-07-04").getTime() + new Time({ Days: 5 }).value,
                }
            },
        },
        roulette: {
            skin: {
                start: new Date("2025-06-24").getTime(),
                end: new Date("2025-06-24").getTime() + new Time({ Days: 15 }).value,
            },
            wpn: {
                start: new Date("2025-07-04").getTime(),
                end: new Date("2025-07-04").getTime() + new Time({ Days: 5 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-06-24").getTime(), [1, 3, 6, 9, 13]),
        },
    };
    EventTimeConstants.Community_2025 = {
        event: {
            start: new Date("2025-07-10").getTime(),
            end: new Date("2025-07-10").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-07-10").getTime(),
            new Date("2025-07-10").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2025-07-10").getTime(),
                end: new Date("2025-07-10").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-07-10").getTime(),
                end: new Date("2025-07-10").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-07-10").getTime(),
                end: new Date("2025-07-10").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-07-10").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Black_Market_07_2025 = {
        event: {
            start: new Date("2025-07-24").getTime(),
            end: new Date("2025-07-24").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-07-24").getTime(),
            new Date("2025-07-24").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2025-07-24").getTime(),
                end: new Date("2025-07-24").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-07-24").getTime(),
                end: new Date("2025-07-24").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2025-07-24").getTime(),
                end: new Date("2025-07-24").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-07-24").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-07-24").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2025-07-24").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-07-24").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-07-24").getTime(),
                end: new Date("2025-07-24").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-07-24").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Nekki_Fest_2025 = {
        event: {
            start: new Date("2025-08-06").getTime(),
            end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
        },
        questQueueStartArray: [
            new Date("2025-08-06").getTime(),
            new Date("2025-08-06").getTime() + new Time({ Days: 8 }).value,
            new Date("2025-08-06").getTime() + new Time({ Days: 15 }).value,
        ],
        roulette: {
            main: {
                start: new Date("2025-08-06").getTime(),
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
            premium: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 11 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
        },
        marathons: {
            play: {
                start: new Date("2025-08-06").getTime(),
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
            tournaments_1: {
                start: new Date("2025-08-06").getTime(),
                end: new Date("2025-08-06").getTime() + new Time({ Days: 11 }).value,
            },
            tournaments_2: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 11 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
            chests: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 8 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 15 }).value,
            },
        },
        tournaments: {
            pve_peace_1: {
                start: new Date("2025-08-06").getTime(),
                end: new Date("2025-08-06").getTime() + new Time({ Days: 11 }).value,
            },
            pve_peace_2: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 11 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
            pvp_1: {
                start: new Date("2025-08-06").getTime(),
                end: new Date("2025-08-06").getTime() + new Time({ Days: 8 }).value,
            },
            pvp_2: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 8 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 15 }).value,
            },
            pvp_3: {
                start: new Date("2025-08-06").getTime() + new Time({ Days: 15 }).value,
                end: new Date("2025-08-06").getTime() + new Time({ Days: 23 }).value,
            },
        },
        popups: {
            summer: CommonUtils.getStartEndByDays(new Date("2025-08-06").getTime(), [1, 5, 12, 15, 19]),
            nekki_fest: CommonUtils.getStartEndByDays(new Date("2025-08-06").getTime(), [2, 4, 8, 10, 13, 17, 21]),
            legendary_kibo: CommonUtils.getStartEndByDays(new Date("2025-08-06").getTime(), [9, 11, 14, 18, 22]),
        },
    };
    EventTimeConstants.Autumn_2025 = {
        event: {
            start: new Date("2025-09-04").getTime(),
            end: new Date("2025-09-04").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-09-04").getTime(),
            new Date("2025-09-04").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2025-09-04").getTime(),
                end: new Date("2025-09-04").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-09-04").getTime(),
                end: new Date("2025-09-04").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2025-09-04").getTime(),
                end: new Date("2025-09-04").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-09-04").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-09-04").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2025-09-04").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-09-04").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-09-04").getTime(),
                end: new Date("2025-09-04").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-09-04").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.April_09_2025 = {
        event: {
            start: new Date("2025-09-18").getTime(),
            end: new Date("2025-09-18").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2025-09-18").getTime(),
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-09-18").getTime(),
                end: new Date("2025-09-18").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-09-18").getTime(),
                end: new Date("2025-09-18").getTime() + new Time({ Days: 7 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-09-18").getTime(),
                end: new Date("2025-09-18").getTime() + new Time({ Days: 7 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-09-18").getTime(), [2, 3, 5]),
        },
    };
    EventTimeConstants.Raikichi_Wpn_2025 = {
        event: {
            start: new Date("2025-09-25").getTime(),
            end: new Date("2025-09-25").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-09-25").getTime(),
            new Date("2025-09-25").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-09-25").getTime(),
                end: new Date("2025-09-25").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-09-25").getTime(),
                end: new Date("2025-09-25").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-09-25").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Black_Market_10_2025 = {
        event: {
            start: new Date("2025-10-09").getTime(),
            end: new Date("2025-10-09").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2025-10-09").getTime(),
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-10-09").getTime(),
                end: new Date("2025-10-09").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-10-09").getTime(),
                end: new Date("2025-10-09").getTime() + new Time({ Days: 7 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-10-09").getTime(),
                end: new Date("2025-10-09").getTime() + new Time({ Days: 7 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-10-09").getTime(), [2, 3, 5]),
        },
    };
    EventTimeConstants.Lights_2025 = {
        event: {
            start: new Date("2025-10-16").getTime(),
            end: new Date("2025-10-16").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-10-16").getTime(),
            new Date("2025-10-16").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2025-10-16").getTime(),
                end: new Date("2025-10-16").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-10-16").getTime(),
                end: new Date("2025-10-16").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2025-10-16").getTime(),
                end: new Date("2025-10-16").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-10-16").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-10-16").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2025-10-16").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-10-16").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-10-16").getTime(),
                end: new Date("2025-10-16").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-10-16").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Halloween_11_2025 = {
        event: {
            start: new Date("2025-10-30").getTime(),
            end: new Date("2025-10-30").getTime() + new Time({ Days: 7 }).value,
        },
        questQueueStartArray: [
            new Date("2025-10-30").getTime(),
        ],
        marathons: {
            tournaments: {
                start: new Date("2025-10-30").getTime(),
                end: new Date("2025-10-30").getTime() + new Time({ Days: 7 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-10-30").getTime(),
                end: new Date("2025-10-30").getTime() + new Time({ Days: 7 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-10-30").getTime(),
                end: new Date("2025-10-30").getTime() + new Time({ Days: 7 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-10-30").getTime(), [2, 3, 5]),
        },
    };
    EventTimeConstants.Nonna_11_2025 = {
        event: {
            start: new Date("2025-11-13").getTime(),
            end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-11-13").getTime(),
            new Date("2025-11-13").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-11-13").getTime(),
                end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-11-13").getTime(),
                end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
            },
            chips: {
                start: new Date("2025-11-13").getTime(),
                end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
            },
            everyday: {
                _1: {
                    start: new Date("2025-11-13").getTime(),
                    end: new Date("2025-11-13").getTime() + new Time({ Days: 1 }).value,
                },
                _2: {
                    start: new Date("2025-11-14").getTime(),
                    end: new Date("2025-11-14").getTime() + new Time({ Days: 1 }).value,
                },
                _3: {
                    start: new Date("2025-11-15").getTime(),
                    end: new Date("2025-11-15").getTime() + new Time({ Days: 1 }).value,
                },
                _4: {
                    start: new Date("2025-11-16").getTime(),
                    end: new Date("2025-11-16").getTime() + new Time({ Days: 1 }).value,
                },
                _5: {
                    start: new Date("2025-11-17").getTime(),
                    end: new Date("2025-11-17").getTime() + new Time({ Days: 1 }).value,
                },
                _6: {
                    start: new Date("2025-11-18").getTime(),
                    end: new Date("2025-11-18").getTime() + new Time({ Days: 1 }).value,
                },
                _7: {
                    start: new Date("2025-11-19").getTime(),
                    end: new Date("2025-11-19").getTime() + new Time({ Days: 1 }).value,
                },
                _8: {
                    start: new Date("2025-11-20").getTime(),
                    end: new Date("2025-11-20").getTime() + new Time({ Days: 1 }).value,
                },
                _9: {
                    start: new Date("2025-11-21").getTime(),
                    end: new Date("2025-11-21").getTime() + new Time({ Days: 1 }).value,
                },
                _10: {
                    start: new Date("2025-11-22").getTime(),
                    end: new Date("2025-11-22").getTime() + new Time({ Days: 1 }).value,
                },
                _11: {
                    start: new Date("2025-11-23").getTime(),
                    end: new Date("2025-11-23").getTime() + new Time({ Days: 1 }).value,
                },
                _12: {
                    start: new Date("2025-11-24").getTime(),
                    end: new Date("2025-11-24").getTime() + new Time({ Days: 1 }).value,
                },
                _13: {
                    start: new Date("2025-11-25").getTime(),
                    end: new Date("2025-11-25").getTime() + new Time({ Days: 1 }).value,
                },
            },
        },
        roulette: {
            base: {
                start: new Date("2025-11-13").getTime(),
                end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
            },
            birthday: {
                start: new Date("2025-11-13").getTime(),
                end: new Date("2025-11-13").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-11-13").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Gideon_11_25 = {
        event: {
            start: new Date("2025-11-27").getTime(),
            end: new Date("2025-11-27").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-11-27").getTime(),
            new Date("2025-11-27").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2025-11-27").getTime(),
                end: new Date("2025-11-27").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-11-27").getTime(),
                end: new Date("2025-11-27").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2025-11-27").getTime(),
                end: new Date("2025-11-27").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2025-11-27").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2025-11-27").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2025-11-27").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2025-11-27").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2025-11-27").getTime(),
                end: new Date("2025-11-27").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-11-27").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Leg_Skins_12_2025 = {
        event: {
            start: new Date("2025-12-18").getTime(),
            end: new Date("2025-12-18").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2025-12-18").getTime(),
            new Date("2025-12-18").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2025-12-18").getTime(),
                end: new Date("2025-12-18").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2025-12-18").getTime(),
                end: new Date("2025-12-18").getTime() + new Time({ Days: 13 }).value,
            },
            getCards: {
                start: new Date("2025-12-18").getTime(),
                end: new Date("2025-12-18").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2025-12-18").getTime(),
                end: new Date("2025-12-18").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2025-12-18").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.new_year_01_2026 = {
        event: {
            start: new Date("2026-01-01").getTime(),
            end: new Date("2026-01-01").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-01-01").getTime(),
            new Date("2026-01-01").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2026-01-01").getTime(),
                end: new Date("2026-01-01").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2026-01-04").getTime(),
                end: new Date("2026-01-04").getTime() + new Time({ Days: 2 }).value,
            },
            time_2: {
                start: new Date("2026-01-11").getTime(),
                end: new Date("2026-01-11").getTime() + new Time({ Days: 2 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2026-01-01").getTime(),
                end: new Date("2026-01-01").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-01-01").getTime(),
                end: new Date("2026-01-01").getTime() + new Time({ Days: 13 }).value,
            },
            second: {
                start: new Date("2026-01-01").getTime() + new Time({ Days: 7 }).value,
                end: new Date("2026-01-01").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-01-01").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Black_Market_01_2026 = {
        event: {
            start: new Date("2026-01-22").getTime(),
            end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-01-22").getTime(),
            new Date("2026-01-22").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2026-01-22").getTime(),
                end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2026-01-22").getTime(),
                end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2026-01-22").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2026-01-22").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2026-01-22").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2026-01-22").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            pve: {
                start: new Date("2026-01-22").getTime(),
                end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
            },
            pvp: {
                start: new Date("2026-01-22").getTime(),
                end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
            },
            fruit_ninja_first: {
                start: new Date("2026-01-22").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2026-01-22").getTime() + new Time({ Days: 4 }).value,
            },
            fruit_ninja_second: {
                start: new Date("2026-01-22").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2026-01-22").getTime() + new Time({ Days: 11 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-01-22").getTime(),
                end: new Date("2026-01-22").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-01-22").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Event_Nonna_01_2026 = {
        event: {
            start: new Date("2026-02-05").getTime(),
            end: new Date("2026-02-05").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-02-05").getTime(),
            new Date("2026-02-05").getTime() + new Time({ Days: 7 }).value,
        ],
        roulette: {
            first: {
                start: new Date("2026-02-05").getTime(),
                end: new Date("2026-02-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2026-02-05").getTime(),
                end: new Date("2026-02-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2026-02-05").getTime(),
                end: new Date("2026-02-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-02-05").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.MNY_02_2026 = {
        event: {
            start: new Date("2026-02-19").getTime(),
            end: new Date("2026-02-19").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-02-19").getTime(),
            new Date("2026-02-19").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            openChest: {
                start: new Date("2026-02-19").getTime(),
                end: new Date("2026-02-19").getTime() + new Time({ Days: 13 }).value,
            }
        },
        tournaments: {
            first: {
                start: new Date("2026-02-19").getTime(),
                end: new Date("2026-02-19").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-02-19").getTime(),
                end: new Date("2026-02-19").getTime() + new Time({ Days: 13 }).value,
            },
            second: {
                start: new Date("2026-02-19").getTime(),
                end: new Date("2026-02-19").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-02-19").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.April_03_2026 = {
        event: {
            start: new Date("2026-03-05").getTime(),
            end: new Date("2026-03-05").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-03-05").getTime(),
            new Date("2026-03-05").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2026-03-05").getTime(),
                end: new Date("2026-03-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2026-03-05").getTime(),
                end: new Date("2026-03-05").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-03-05").getTime(),
                end: new Date("2026-03-05").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-03-05").getTime(), [2, 3, 5]),
        },
    };
    EventTimeConstants.Sakura_2026 = {
        event: {
            start: new Date("2026-03-26").getTime(),
            end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-03-26").getTime(),
            new Date("2026-03-26").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            tournament: {
                start: new Date("2026-03-26").getTime(),
                end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
            },
            paid: {
                start: new Date("2026-03-26").getTime(),
                end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            first: {
                start: new Date("2026-03-26").getTime(),
                end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-03-26").getTime(),
                end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
            },
            second: {
                start: new Date("2026-03-26").getTime(),
                end: new Date("2026-03-26").getTime() + new Time({ Days: 13 }).value,
            }
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-03-26").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Butcher_04_2026 = {
        event: {
            start: new Date("2026-04-16").getTime(),
            end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-04-16").getTime(),
            new Date("2026-04-16").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            buyout_tournament: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
            paid_chips: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
            paid_pvp: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
            buyout_daily_1_1: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_2_2: {
                start: new Date("2026-04-17").getTime(),
                end: new Date("2026-04-17").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_3_3: {
                start: new Date("2026-04-18").getTime(),
                end: new Date("2026-04-18").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_1_4: {
                start: new Date("2026-04-19").getTime(),
                end: new Date("2026-04-19").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_2_5: {
                start: new Date("2026-04-20").getTime(),
                end: new Date("2026-04-20").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_3_6: {
                start: new Date("2026-04-21").getTime(),
                end: new Date("2026-04-21").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_1_7: {
                start: new Date("2026-04-22").getTime(),
                end: new Date("2026-04-22").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_2_8: {
                start: new Date("2026-04-23").getTime(),
                end: new Date("2026-04-23").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_3_9: {
                start: new Date("2026-04-24").getTime(),
                end: new Date("2026-04-24").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_1_10: {
                start: new Date("2026-04-25").getTime(),
                end: new Date("2026-04-25").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_2_11: {
                start: new Date("2026-04-26").getTime(),
                end: new Date("2026-04-26").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_3_12: {
                start: new Date("2026-04-27").getTime(),
                end: new Date("2026-04-27").getTime() + new Time({ Days: 1 }).value,
            },
            buyout_daily_1_13: {
                start: new Date("2026-04-28").getTime(),
                end: new Date("2026-04-28").getTime() + new Time({ Days: 1 }).value,
            },
        },
        tournaments: {
            promo: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
            pve: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
            pvp: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-04-16").getTime(),
                end: new Date("2026-04-16").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-04-16").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.EarthDay_2026 = {
        marathons: {
            start: new Date("2026-04-21").getTime(),
            end: new Date("2026-06-04").getTime(),
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-04-21").getTime(), [
                1, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44,
            ]),
        }
    };
    EventTimeConstants.Japan_Gold_Week = {
        marathons: {
            start: new Date("2026-04-29").getTime(),
            end: new Date("2026-05-07").getTime(),
        },
    };
    EventTimeConstants.Labor_05_2026 = {
        event: {
            start: new Date("2026-04-30").getTime(),
            end: new Date("2026-04-30").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-04-30").getTime(),
            new Date("2026-04-30").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            tournament: {
                start: new Date("2026-04-30").getTime(),
                end: new Date("2026-04-30").getTime() + new Time({ Days: 13 }).value,
            },
            paid: {
                start: new Date("2026-04-30").getTime(),
                end: new Date("2026-04-30").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            _1: {
                start: new Date("2026-04-30").getTime(),
                end: new Date("2026-04-30").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-04-30").getTime(),
                end: new Date("2026-04-30").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-04-30").getTime(), [3, 6, 10]),
        },
    };
    EventTimeConstants.Leg_skin_05_2026 = {
        event: {
            start: new Date("2026-05-14").getTime(),
            end: new Date("2026-05-14").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-05-14").getTime(),
            new Date("2026-05-14").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            tournament: {
                start: new Date("2026-05-14").getTime(),
                end: new Date("2026-05-14").getTime() + new Time({ Days: 13 }).value,
            },
            paid: {
                start: new Date("2026-05-14").getTime(),
                end: new Date("2026-05-14").getTime() + new Time({ Days: 13 }).value,
            },
        },
        tournaments: {
            _1: {
                start: new Date("2026-05-14").getTime(),
                end: new Date("2026-05-14").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-05-14").getTime(),
                end: new Date("2026-05-14").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-05-14").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Vampires_06_2026 = {
        event: {
            start: new Date("2026-05-28").getTime(),
            end: new Date("2026-05-28").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-05-28").getTime(),
            new Date("2026-05-28").getTime() + new Time({ Days: 7 }).value,
        ],
        marathons: {
            buyout: {
                start: new Date("2026-05-28").getTime(),
                end: new Date("2026-05-28").getTime() + new Time({ Days: 13 }).value,
            },
            paid: {
                start: new Date("2026-05-28").getTime(),
                end: new Date("2026-05-28").getTime() + new Time({ Days: 13 }).value,
            }
        },
        tournaments: {
            _1: {
                start: new Date("2026-05-28").getTime(),
                end: new Date("2026-05-28").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            _1: {
                start: new Date("2026-05-28").getTime(),
                end: new Date("2026-05-28").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-05-28").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.Midsummer_2026 = {
        event: {
            start: new Date("2026-06-11").getTime(),
            end: new Date("2026-06-11").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-06-11").getTime(),
            new Date("2026-06-11").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            first: {
                start: new Date("2026-06-11").getTime(),
                end: new Date("2026-06-11").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            tournaments: {
                start: new Date("2026-06-11").getTime(),
                end: new Date("2026-06-11").getTime() + new Time({ Days: 13 }).value,
            },
            battlePass: {
                start: new Date("2026-06-11").getTime(),
                end: new Date("2026-06-11").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-06-11").getTime(),
                end: new Date("2026-06-11").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-06-11").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.april_06_2026 = {
        event: {
            start: new Date("2026-06-25").getTime(),
            end: new Date("2026-06-25").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-06-25").getTime(),
            new Date("2026-06-25").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            _1: {
                start: new Date("2026-06-25").getTime(),
                end: new Date("2026-06-25").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            _1: {
                start: new Date("2026-06-25").getTime(),
                end: new Date("2026-06-25").getTime() + new Time({ Days: 13 }).value,
            },
        },
        roulette: {
            _1: {
                start: new Date("2026-06-25").getTime(),
                end: new Date("2026-06-25").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            to_skin: CommonUtils.getStartEndByDays(new Date("2026-06-25").getTime(), [1, 3, 5, 7, 9, 11, 13]),
            to_weapon: CommonUtils.getStartEndByDays(new Date("2026-06-25").getTime(), [2, 4, 6, 8, 10, 12]),
        },
    };
    EventTimeConstants.shogun_07_2026 = {
        event: {
            start: new Date("2026-07-09").getTime(),
            end: new Date("2026-07-09").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-07-09").getTime(),
            new Date("2026-07-09").getTime() + new Time({ Days: 7 }).value,
        ],
        tournaments: {
            _1: {
                start: new Date("2026-07-09").getTime(),
                end: new Date("2026-07-09").getTime() + new Time({ Days: 13 }).value,
            },
        },
        marathons: {
            buyout_tournament: {
                start: new Date("2026-07-09").getTime(),
                end: new Date("2026-07-09").getTime() + new Time({ Days: 13 }).value,
            },
            paid_chips: {
                start: new Date("2026-07-09").getTime(),
                end: new Date("2026-07-09").getTime() + new Time({ Days: 13 }).value,
            },
            daily_1_1: {
                start: new Date("2026-07-09").getTime(),
                end: new Date("2026-07-09").getTime() + new Time({ Days: 1 }).value,
            },
            daily_2_2: {
                start: new Date("2026-07-10").getTime(),
                end: new Date("2026-07-10").getTime() + new Time({ Days: 1 }).value,
            },
            daily_3_3: {
                start: new Date("2026-07-11").getTime(),
                end: new Date("2026-07-11").getTime() + new Time({ Days: 1 }).value,
            },
            daily_1_4: {
                start: new Date("2026-07-12").getTime(),
                end: new Date("2026-07-12").getTime() + new Time({ Days: 1 }).value,
            },
            daily_2_5: {
                start: new Date("2026-07-13").getTime(),
                end: new Date("2026-07-13").getTime() + new Time({ Days: 1 }).value,
            },
            daily_3_6: {
                start: new Date("2026-07-14").getTime(),
                end: new Date("2026-07-14").getTime() + new Time({ Days: 1 }).value,
            },
            daily_1_7: {
                start: new Date("2026-07-15").getTime(),
                end: new Date("2026-07-15").getTime() + new Time({ Days: 1 }).value,
            },
            daily_2_8: {
                start: new Date("2026-07-16").getTime(),
                end: new Date("2026-07-16").getTime() + new Time({ Days: 1 }).value,
            },
            daily_3_9: {
                start: new Date("2026-07-17").getTime(),
                end: new Date("2026-07-17").getTime() + new Time({ Days: 1 }).value,
            },
            daily_1_10: {
                start: new Date("2026-07-18").getTime(),
                end: new Date("2026-07-18").getTime() + new Time({ Days: 1 }).value,
            },
            daily_2_11: {
                start: new Date("2026-07-19").getTime(),
                end: new Date("2026-07-19").getTime() + new Time({ Days: 1 }).value,
            },
            daily_4_12: {
                start: new Date("2026-07-20").getTime(),
                end: new Date("2026-07-20").getTime() + new Time({ Days: 1 }).value,
            },
            daily_4_13: {
                start: new Date("2026-07-21").getTime(),
                end: new Date("2026-07-21").getTime() + new Time({ Days: 1 }).value,
            },
        },
        roulette: {
            _1: {
                start: new Date("2026-07-09").getTime(),
                end: new Date("2026-07-09").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-07-09").getTime(), [1, 4, 8, 11]),
        },
    };
    EventTimeConstants.black_market_07_2026 = {
        event: {
            start: new Date("2026-07-23").getTime(),
            end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
        },
        questQueueStartArray: [
            new Date("2026-07-23").getTime(),
            new Date("2026-07-23").getTime() + new Time({ Days: 6 }).value,
        ],
        marathons: {
            tournaments: {
                start: new Date("2026-07-23").getTime(),
                end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
            },
            chests: {
                start: new Date("2026-07-23").getTime(),
                end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
            },
            time_1: {
                start: new Date("2026-07-23").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2026-07-23").getTime() + new Time({ Days: 4 }).value,
            },
            time_2: {
                start: new Date("2026-07-23").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2026-07-23").getTime() + new Time({ Days: 11 }).value,
            },
        },
        tournaments: {
            pve: {
                start: new Date("2026-07-23").getTime(),
                end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
            },
            pvp: {
                start: new Date("2026-07-23").getTime(),
                end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
            },
            fruit_ninja_first: {
                start: new Date("2026-07-23").getTime() + new Time({ Days: 2 }).value,
                end: new Date("2026-07-23").getTime() + new Time({ Days: 4 }).value,
            },
            fruit_ninja_second: {
                start: new Date("2026-07-23").getTime() + new Time({ Days: 9 }).value,
                end: new Date("2026-07-23").getTime() + new Time({ Days: 11 }).value,
            },
        },
        roulette: {
            first: {
                start: new Date("2026-07-23").getTime(),
                end: new Date("2026-07-23").getTime() + new Time({ Days: 13 }).value,
            },
        },
        popups: {
            _1: CommonUtils.getStartEndByDays(new Date("2026-07-23").getTime(), [1, 4, 8, 11]),
        },
    };
    return EventTimeConstants;
}());
