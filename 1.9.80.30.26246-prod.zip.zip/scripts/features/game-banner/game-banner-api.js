function getBannerSettings(platform) {
    return {
        gameLink: GameBannerUtils.getGameBannerLink(platform),
        showTime: new Time({ Seconds: 15 }).value,
        skipTime: new Time({ Seconds: 3 }).value,
    };
}
function getBannerShowRestrictions() {
    return GameBannerConstants.bannerAdRestrictions;
}
function getBannerVisualSettings() {
    return GameBannerUtils.getBannerVisualSettings();
}
