var GameBannerUtils = (function () {
    function GameBannerUtils() {
    }
    Object.defineProperty(GameBannerUtils, "currentBanner", {
        get: function () {
            return GameBannerConstants.banners[GameBannerConstants.currentGameBanner];
        },
        enumerable: false,
        configurable: true
    });
    GameBannerUtils.getGameBannerLink = function (platform) {
        var _a;
        return (_a = this.currentBanner.links[platform]) !== null && _a !== void 0 ? _a : this.currentBanner.links.default;
    };
    ;
    GameBannerUtils.getBannerVisualSettings = function () {
        return this.currentBanner.visual;
    };
    return GameBannerUtils;
}());
