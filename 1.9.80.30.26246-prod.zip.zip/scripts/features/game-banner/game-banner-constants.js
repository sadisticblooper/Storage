var GameBannerConstants = (function () {
    function GameBannerConstants() {
    }
    GameBannerConstants.currentGameBanner = 'demonization';
    GameBannerConstants.bannerAdRestrictions = {
        showLimitInPeriod: 3,
        timePeriod: { Origin: "2016-01-01T03:00:00+03", Period: new Time({ Days: 1 }).value },
    };
    GameBannerConstants.banners = {
        sf3: {
            links: {
                default: "https://sf3.onelink.me/S2uR/CrossPromo",
            },
            visual: {
                "backgroundImage": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_location",
                "backgroundColor": "#2E2E2E",
                "gradient": "#73352A45",
                "glowImage": "Sprites/PreviewImages/Advertising/AdvertisingSF3/glowLights",
                "glowColor": "#FFFFFF",
                "promoImage": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_Art",
                "flowEffect": "#B893768A",
                "dustParticlesColor1": "#B893765C",
                "dustParticlesColor2": "#B89376B8",
                "logoImage": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_logo",
                "buttonColorState": "FullGold",
                "buttonAlias": "button_download"
            },
        },
        demonization: {
            links: {
                default: "https://youtu.be/SYHaBAAcfI8",
            },
            visual: {
                "backgroundImage": "Sprites/PreviewImages/Advertising/DemonizationPromo/game_banner_bg_demonization",
                "backgroundColor": "#3b525c",
                "gradient": "#587B8A73",
                "glowImage": "Sprites/PreviewImages/Advertising/DemonizationPromo/game_banner_glow_demonization",
                "glowColor": "#732a2a",
                "promoImage": "Sprites/PreviewImages/Advertising/DemonizationPromo/game_banner_art_demonization",
                "flowEffect": "#1addff8A",
                "dustParticlesColor1": "#1addff5C",
                "dustParticlesColor2": "#1addffB8",
                "logoImage": "Sprites/PreviewImages/Advertising/DemonizationPromo/game_banner_logo_demonization",
                "buttonColorState": "FullGold",
                "buttonAlias": "button_watch_trailer"
            },
        },
    };
    return GameBannerConstants;
}());
