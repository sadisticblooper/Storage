function getEmojiById(id) {
    return emojiMap.checkedGet(id);
}
