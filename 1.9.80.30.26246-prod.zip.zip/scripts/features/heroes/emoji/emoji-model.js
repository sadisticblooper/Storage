var Emoji = (function () {
    function Emoji(settings) {
        this.customizationType = CUSTOMIZATION.EMOJI;
        this.settings = {
            ID: settings.ID,
            name: settings.name,
            animation: settings.animation,
            heroId: settings.heroId ? settings.heroId : null,
            isDefault: settings.isDefault != undefined ? settings.isDefault : false,
            assetBundleTag: settings.assetBundleTag ? settings.assetBundleTag : "",
            putOnPlayer: settings.putOnPlayer != undefined ? settings.putOnPlayer : false,
            videoId: settings.videoId ? settings.videoId : 0,
            customUnlockedPlacement: settings.customUnlockedPlacement ? settings.customUnlockedPlacement : null,
            configsOrder: settings.configsOrder,
        };
        this.VideoId = this.settings.videoId;
        this.rarity = this.settings.rarity ? this.settings.rarity : EMOJI_RARITY.ANY;
        this.configsOrder = this.settings.configsOrder;
        this.customUnlockedPlacement = this.settings.customUnlockedPlacement;
        this.ShardsNeeded = this.settings.shardsNeeded;
        if (this.settings.putOnPlayer && !this.settings.isDefault) {
            throw new Error("If emoji has flag putOnPlayer, it must has flag isDefault = true. Emoji ID ".concat(settings.ID));
        }
        Emoji.AddDefaultEmoji(this);
    }
    Object.defineProperty(Emoji.prototype, "ID", {
        get: function () { return this.settings.ID; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "Name", {
        get: function () { return this.settings.name; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "Animation", {
        get: function () { return this.settings.animation; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "HeroId", {
        get: function () { return this.settings.heroId; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "IsDefault", {
        get: function () { return this.settings.isDefault; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "AssetBundleTag", {
        get: function () { return this.settings.assetBundleTag; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "PutOnPlayer", {
        get: function () { return this.settings.putOnPlayer; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emoji.prototype, "Settings", {
        get: function () { return this.settings; },
        enumerable: false,
        configurable: true
    });
    Emoji.testDefaultEmoji = function (emojiIDs) {
        for (var _i = 0, emojiIDs_1 = emojiIDs; _i < emojiIDs_1.length; _i++) {
            var emojiID = emojiIDs_1[_i];
            var emoji_1 = emojiMap.checkedGet(emojiID);
            if (!emoji_1.Settings.isDefault) {
                throw new Error("testDefaultEmoji: emoji [id ".concat(emojiID, "] is not default!"));
            }
        }
        return emojiIDs;
    };
    Emoji.getStarterEmoji = function () {
        var result = [];
        for (var key in emoji) {
            var em = emoji[key];
            if (em.PutOnPlayer && result.indexOf(em.ID) == -1) {
                result.push(em.ID);
            }
        }
        return result;
    };
    Emoji.AddDefaultEmoji = function (emoji) {
        if (emoji.IsDefault && this.DefaultEmoji.indexOf(emoji.ID) == -1) {
            this.DefaultEmoji.push(emoji.ID);
        }
    };
    Emoji.DefaultEmoji = [];
    return Emoji;
}());
