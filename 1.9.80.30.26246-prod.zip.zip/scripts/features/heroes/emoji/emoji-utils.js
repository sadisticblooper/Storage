var EmojiUtils = (function () {
    function EmojiUtils() {
    }
    EmojiUtils.getAvailableIdsRandomGenerating = function (specify) {
        return EmojiConstants.availableEmotesForRandomGeneration;
    };
    return EmojiUtils;
}());
