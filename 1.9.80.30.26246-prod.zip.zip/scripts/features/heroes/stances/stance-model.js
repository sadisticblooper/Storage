var Stance = (function () {
    function Stance(settings) {
        this.customizationType = CUSTOMIZATION.STANCE;
        this.settings = settings;
        this.settings.VideoId = this.settings.VideoId ? this.settings.VideoId : 0;
        this.settings.IsDefault = this.settings.IsDefault == undefined ? false : this.settings.IsDefault;
        this.settings.HeroFormType = this.settings.HeroFormType != undefined
            ? this.settings.HeroFormType
            : HERO_FORM_TYPE.PRIMARY;
        if (this.settings.PutOnHero && !this.settings.IsDefault) {
            throw new Error("If stance has flag PutOnHero, it must has flag IsDefault = true. Stance ID ".concat(settings.ID));
        }
        this.configsOrder = settings.configsOrder;
        this.rarity = this.settings.Rarity;
        this.heroOwners = this.Settings.OwnerHeroes;
        this.customUnlockedPlacement = this.Settings.CustomUnlockedPlacement;
        this.ShardsNeeded = this.settings.ShardsNeeded;
        Stance.AddDefaultStance(this);
    }
    Object.defineProperty(Stance.prototype, "ID", {
        get: function () { return this.settings.ID; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Stance.prototype, "Settings", {
        get: function () { return this.settings; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Stance.prototype, "IsDefault", {
        get: function () { return this.settings.IsDefault; },
        enumerable: false,
        configurable: true
    });
    Stance.AddDefaultStance = function (stance) {
        if (stance.IsDefault && this.DefaultStances.indexOf(stance.ID) == -1) {
            this.DefaultStances.push(stance.ID);
        }
    };
    Stance.DefaultStances = [];
    return Stance;
}());
var StanceHeroSetter = (function () {
    function StanceHeroSetter() {
    }
    StanceHeroSetter.setStancesToHeroes = function () {
        for (var heroName in heroes) {
            var hero = heroes[heroName];
            var heroStances = [];
            for (var stanceName in stances) {
                var stance = stances[stanceName];
                if (stance.Settings.OwnerHeroes.indexOf(hero.ID) > -1 || stance.Settings.OwnerHeroes.length == 0) {
                    heroStances.push(stance);
                }
            }
            hero.setStances(heroStances);
        }
    };
    return StanceHeroSetter;
}());
