var StanceUtils = (function () {
    function StanceUtils() {
    }
    StanceUtils.getAvailableIdsRandomGenerating = function (specify) {
        var type = specify && specify.stanceType || STANCE_TYPE.UNKNOWN;
        return StanceConstants.availableStancesForRandomGeneration.filter(function (id) {
            if (type == STANCE_TYPE.UNKNOWN) {
                return true;
            }
            var stance = stancesMap.checkedGet(id);
            return stance.Settings.StanceType == type;
        });
    };
    return StanceUtils;
}());
