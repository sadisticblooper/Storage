function getHeroWeaponById(id) {
    return weaponsMap.checkedGet(id);
}
function getWeaponAttributeInfo(params) {
    return weaponsMap.checkedGet(params.weaponId).AttributesInfo;
}
function isAspectSelectionAvailable(settings) {
    return HeroWeaponUtils.isAspectSelectionAvailable(settings);
}
function getWeaponAspectsVisualSettings(weaponId) {
    return HeroWeaponUtils.getWeaponAspectsVisualSettings(weaponId);
}
