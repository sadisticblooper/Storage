var aspectVisuals = {
    wpn_Butcher_L_Gore_Knuckles_name_visual: {
        ID: aspects.wpn_Butcher_L_Gore_Knuckles_name.ID,
        weaponId: heroWeapons.wpn_Butcher_L_Gore.ID,
        header: "wpn_Butcher_L_Gore_Knuckles_name",
        desc: "wpn_Butcher_L_Gore_Knuckles_desc",
        icon: "Sprites/Assets/Abilities/Butcher/icon_ability_wpn_Butcher_L_Gore_Knuckles",
        iconColor: "#ffffff",
        iconGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#A11F32" }, { time: 1, color: "#FF758A" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        frameColor: "#FF304F",
        frameGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#8A8A8A" }, { time: 1, color: "#B8B8B8" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        headerIconColor: "#FF30444F",
        headerBgGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#731624" }, { time: 1, color: "#B82339" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        selectColor: "#FF304F",
    },
    wpn_Butcher_L_Gore_Saw_name_visual: {
        ID: aspects.wpn_Butcher_L_Gore_Saw_name.ID,
        weaponId: heroWeapons.wpn_Butcher_L_Gore.ID,
        header: "wpn_Butcher_L_Gore_Saw_name",
        desc: "wpn_Butcher_L_Gore_Saw_desc",
        icon: "Sprites/Assets/Abilities/Butcher/icon_ability_wpn_Butcher_L_Gore_Saw",
        iconColor: "#ffffff",
        iconGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#327D8A" }, { time: 1, color: "#A3F1FF" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        frameColor: "#5ee7ff",
        frameGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#8A8A8A" }, { time: 1, color: "#B8B8B8" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        headerIconColor: "#5EE7FF45",
        headerBgGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#2B6974" }, { time: 1, color: "#34A4B8" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        selectColor: "#5ee7ff",
    },
    wpn_Butcher_L_Gore_Club_name_visual: {
        ID: aspects.wpn_Butcher_L_Gore_Club_name.ID,
        weaponId: heroWeapons.wpn_Butcher_L_Gore.ID,
        header: "wpn_Butcher_L_Gore_Club_name",
        desc: "wpn_Butcher_L_Gore_Club_desc",
        icon: "Sprites/Assets/Abilities/Butcher/icon_ability_wpn_Butcher_L_Gore_Club",
        iconColor: "#ffffff",
        iconGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#6F732A" }, { time: 1, color: "#E0E57E" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        frameColor: "#B1B833",
        frameGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#8A8A8A" }, { time: 1, color: "#B8B8B8" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        headerIconColor: "#F9FF8C45",
        headerBgGradient: {
            mode: 0,
            colorKeys: [{ time: 0, color: "#5A5C32" }, { time: 1, color: "#B4B865" }],
            alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }]
        },
        selectColor: "#B1B833",
    },
};
