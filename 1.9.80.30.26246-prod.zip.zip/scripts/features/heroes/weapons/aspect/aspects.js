var aspects = {
    wpn_Butcher_L_Gore_Knuckles_name: {
        ID: 1,
        fightTag: "L_GORE_KNUCKLES",
        attributesMultipliers: {
            WeaponDamage: '1.1',
            BodyDefense: '1.1',
        },
    },
    wpn_Butcher_L_Gore_Saw_name: {
        ID: 2,
        fightTag: "L_GORE_SAW",
        attributesMultipliers: {
            WeaponDamage: '1.07',
            MagicDamage: '1.08',
            BodyDefense: '1.05',
        },
    },
    wpn_Butcher_L_Gore_Club_name: {
        ID: 3,
        fightTag: "L_GORE_CLUB",
        attributesMultipliers: {
            WeaponDamage: '1.05',
            BodyDefense: '1.15',
        },
    },
};
