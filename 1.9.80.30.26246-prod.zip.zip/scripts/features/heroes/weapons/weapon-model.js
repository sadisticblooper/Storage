var HeroWeapon = (function () {
    function HeroWeapon(settings) {
        this.customizationType = CUSTOMIZATION.WEAPON;
        this.Settings = settings;
        this.Settings.VideoId = getValueByKeyDefault(settings, "VideoId", 0);
        this.ID = settings.ID;
        this.AttributesInfo = this.GetAttributesInfoFromHero(this.Settings.AttributesMultipliers);
        this.Settings.Aspects = getValueByKeyDefault(settings, "Aspects", []);
        for (var _i = 0, _a = this.Settings.Aspects; _i < _a.length; _i++) {
            var aspect = _a[_i];
            aspect.attributesInfo = this.GetAttributesInfoFromHero(aspect.attributesMultipliers);
        }
        this.configsOrder = settings.configsOrder;
        this.rarity = this.Settings.Rarity;
        this.heroOwners = [this.Settings.HeroOwner];
        this.customUnlockedPlacement = this.Settings.CustomUnlockedPlacement;
        this.ShardsNeeded = settings.ShardsNeeded;
        HeroWeapon.AddDefaultWeapon(this);
    }
    HeroWeapon.prototype.GetAttributesInfoFromHero = function (attributes) {
        var result = {};
        var hero = heroesMap.checkedGet(this.Settings.HeroOwner);
        var heroAttributesInfo = hero.AttributesInfo;
        var weaponMultipliersAttributes = attributes;
        var uiAttributes = HeroConstants.defaultAttributeNameValues;
        for (var attrName in uiAttributes)
            if (uiAttributes.hasOwnProperty(attrName)) {
                if (weaponMultipliersAttributes[attrName] == undefined) {
                    continue;
                }
                if (heroAttributesInfo[attrName]) {
                    result[attrName] = heroAttributesInfo[attrName];
                }
                else {
                    result[attrName] = uiAttributes[attrName];
                }
            }
        return result;
    };
    HeroWeapon.AddDefaultWeapon = function (weapon) {
        if (weapon.Settings.IsDefault && this.DefaultWeapons.indexOf(weapon.ID) == -1) {
            this.DefaultWeapons.push(weapon.ID);
        }
    };
    HeroWeapon.DefaultWeapons = [];
    return HeroWeapon;
}());
