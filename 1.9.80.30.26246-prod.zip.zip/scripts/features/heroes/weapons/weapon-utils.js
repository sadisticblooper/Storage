var HeroWeaponUtils = (function () {
    function HeroWeaponUtils() {
    }
    HeroWeaponUtils.setWeaponsToHeroes = function () {
        var heroWeapons = {};
        for (var _i = 0, _a = weaponsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var weapon = weaponsMap.get(id);
            var hid = weapon.Settings.HeroOwner;
            if (heroWeapons[hid] == undefined) {
                heroWeapons[hid] = [];
            }
            heroWeapons[hid].push(weapon);
        }
        for (var heroId in heroWeapons) {
            var hero = heroesMap.checkedGet(heroId);
            hero.setWeapons(heroWeapons[heroId]);
        }
    };
    HeroWeaponUtils.getAvailableForGeneratingSeparated = function (playerProgress) {
        var result = {};
        for (var _i = 0, _a = weaponsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            if (Skin.WeaponsInKit.indexOf(id) == -1 && playerProgress.weapons.indexOf(id) == -1) {
                var weapon = weaponsMap.get(id);
                if (!result[weapon.Settings.Rarity]) {
                    result[weapon.Settings.Rarity] = [];
                }
                result[weapon.Settings.Rarity].push(id);
            }
        }
        return result;
    };
    HeroWeaponUtils.getAvailableIdsRandomGenerating = function (specify) {
        if (specify && specify.chestId && WeaponConstants.weaponsAvailableListSpecify[specify.chestId]) {
            return WeaponConstants.weaponsAvailableListSpecify[specify.chestId];
        }
        return WeaponConstants.availableWeaponsForRandomGeneration;
    };
    HeroWeaponUtils.isAspectSelectionAvailable = function (settings) {
        var weapon = weaponsMap.checkedGet(settings.weaponId);
        if (settings.fightMode == FIGHT_MODE.TRAINING)
            return false;
        if (settings.fightMode == FIGHT_MODE.LOCAL_PVP_FRIEND)
            return false;
        if (!weapon.Settings.Aspects || weapon.Settings.Aspects.length == 0)
            return false;
        if (settings.fightMode == FIGHT_MODE.ROGUELIKE_COMMON || settings.fightMode == FIGHT_MODE.ROGUELIKE_SURVIVAL) {
            return WeaponConstants.showAspectSelectionInRogueLikeRounds.indexOf(settings.roundNumber) != -1;
        }
        return true;
    };
    HeroWeaponUtils.getWeaponAspectsVisualSettings = function (weaponId) {
        var weapon = weaponsMap.checkedGet(weaponId);
        var result = [];
        if (!weapon.Settings.Aspects || weapon.Settings.Aspects.length == 0)
            throwDebugOrReturnDefault("No aspect configuration for selected weapon ".concat(weapon.Settings.Alias, "\n             with ID: ").concat(weaponId), null);
        for (var i in aspectVisuals) {
            var visual = aspectVisuals[i];
            if (visual.weaponId != weaponId)
                continue;
            result.push(visual);
        }
        if (result.length != WeaponConstants.weaponAspectMaxAmount)
            throwDebugOrReturnDefault("The number of aspects more or less of ".concat(WeaponConstants.weaponAspectMaxAmount, " \n            on weapon ID: ").concat(weaponId), null);
        return result;
    };
    return HeroWeaponUtils;
}());
