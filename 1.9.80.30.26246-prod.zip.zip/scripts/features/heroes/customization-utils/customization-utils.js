var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var CustomizationUtils = (function () {
    function CustomizationUtils() {
    }
    CustomizationUtils.getAllCustomizationsOrder = function () {
        if (CustomizationUtils.allCustomizations == undefined) {
            CustomizationUtils.allCustomizations = Object
                .keys(CUSTOMIZATION)
                .filter(function (c) { return isNumber(c); })
                .map(Number);
        }
        return CustomizationUtils.allCustomizations;
    };
    CustomizationUtils.getOrderMap = function (customizationType) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return weaponsMap;
            case CUSTOMIZATION.TAUNT:
                return tauntsMap;
            case CUSTOMIZATION.STANCE:
                return stancesMap;
            case CUSTOMIZATION.SKIN:
                return skinsMap;
            case CUSTOMIZATION.EMOJI:
                return emojiMap;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return textEmojiPacksMap;
        }
        return null;
    };
    CustomizationUtils.getPlayerIdsContainer = function (customizationType, playerProgress) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return playerProgress.weapons;
            case CUSTOMIZATION.TAUNT:
                return playerProgress.taunts;
            case CUSTOMIZATION.STANCE:
                return playerProgress.stances;
            case CUSTOMIZATION.SKIN:
                return playerProgress.skins;
            case CUSTOMIZATION.EMOJI:
                return playerProgress.emoji;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return playerProgress.textEmojiPacks;
        }
        return null;
    };
    CustomizationUtils.getLootIdsContainer = function (customizationType, loot) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return loot.Weapons;
            case CUSTOMIZATION.TAUNT:
                return loot.Taunts;
            case CUSTOMIZATION.STANCE:
                return loot.Stances;
            case CUSTOMIZATION.SKIN:
                return loot.HeroSkins;
            case CUSTOMIZATION.EMOJI:
                return loot.Emoji;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return loot.TextEmojiPacks;
        }
        return null;
    };
    CustomizationUtils.getLootSettingsIdsContainer = function (customizationType, lootSettings) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return lootSettings.Weapons;
            case CUSTOMIZATION.TAUNT:
                return lootSettings.Taunts;
            case CUSTOMIZATION.STANCE:
                return lootSettings.Stances;
            case CUSTOMIZATION.SKIN:
                return lootSettings.Skins;
            case CUSTOMIZATION.EMOJI:
                return lootSettings.Emoji;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return lootSettings.TextEmojiPacks;
        }
        return null;
    };
    CustomizationUtils.getLootSettingsForChestInPseudoRandom = function (chestModel) {
        var psdSettings = PseudorandomSettings.settings[chestModel.ID];
        if (!(psdSettings === null || psdSettings === void 0 ? void 0 : psdSettings.tooltipProbabilities)) {
            return undefined;
        }
        var tooltipProbabilities = psdSettings.tooltipProbabilities;
        for (var _i = 0, _a = Object.keys(tooltipProbabilities); _i < _a.length; _i++) {
            var tooltipTypeStr = _a[_i];
            var tooltipType = Number(tooltipTypeStr);
            var rarities = tooltipProbabilities[tooltipType];
            if (!rarities)
                continue;
            return __assign({}, this.buildCustomizationSettings(tooltipType, rarities));
        }
        return undefined;
    };
    CustomizationUtils.getGeneratorLootSettingsContainer = function (customizationType, settings) {
        var _a, _b, _c, _d, _e, _f;
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return (_a = this.getFromGroups(settings, "Weapons")) !== null && _a !== void 0 ? _a : settings.Weapons;
            case CUSTOMIZATION.TAUNT:
                return (_b = this.getFromGroups(settings, "Taunts")) !== null && _b !== void 0 ? _b : settings.Taunts;
            case CUSTOMIZATION.STANCE:
                return (_c = this.getFromGroups(settings, "Taunts")) !== null && _c !== void 0 ? _c : settings.Stances;
            case CUSTOMIZATION.SKIN:
                return (_d = this.getFromGroups(settings, "Skins")) !== null && _d !== void 0 ? _d : settings.Skins;
            case CUSTOMIZATION.EMOJI:
                return (_e = this.getFromGroups(settings, "Emoji")) !== null && _e !== void 0 ? _e : settings.Emoji;
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return (_f = this.getFromGroups(settings, "TextEmojiPacks")) !== null && _f !== void 0 ? _f : settings.TextEmojiPacks;
        }
        return null;
    };
    CustomizationUtils.getFromGroups = function (settings, key) {
        if (settings.Groups) {
            for (var _i = 0, _a = settings.Groups; _i < _a.length; _i++) {
                var group = _a[_i];
                var value = group[key];
                if (value)
                    return value;
            }
        }
        return null;
    };
    CustomizationUtils.getAvailableIdsForRandomGenerating = function (customizationType, specify) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return HeroWeaponUtils.getAvailableIdsRandomGenerating(specify);
            case CUSTOMIZATION.TAUNT:
                return TauntUtils.getAvailableIdsRandomGenerating(specify);
            case CUSTOMIZATION.STANCE:
                return StanceUtils.getAvailableIdsRandomGenerating(specify);
            case CUSTOMIZATION.SKIN:
                return SkinUtils.getAvailableIdsRandomGenerating(specify);
            case CUSTOMIZATION.EMOJI:
                return EmojiUtils.getAvailableIdsRandomGenerating(specify);
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return TextEmojiUtils.getAvailableIdsRandomGenerating(specify);
        }
        return null;
    };
    CustomizationUtils.getAvailableIdsForRandomGeneratingByChestTooltipType = function (type, specify) {
        specify = specify || {};
        switch (type) {
            case CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS:
                return HeroWeaponUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS:
                return TauntUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE:
                specify.stanceType = STANCE_TYPE.WIN_POSE;
                return StanceUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES:
                specify.stanceType = STANCE_TYPE.START_POSE;
                return StanceUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS:
                return SkinUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES:
                return EmojiUtils.getAvailableIdsRandomGenerating(specify);
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK:
                return TextEmojiUtils.getAvailableIdsRandomGenerating(specify);
        }
        return null;
    };
    CustomizationUtils.getCustomizationRaritiesByCustomize = function (customizationType) {
        switch (customizationType) {
            case CUSTOMIZATION.TAUNT:
                return [
                    CUSTOMIZATION_RARITY.SEASON_TAUNT,
                    CUSTOMIZATION_RARITY.EPIC_TAUNT,
                    CUSTOMIZATION_RARITY.RARE_TAUNT,
                    CUSTOMIZATION_RARITY.COMMON_TAUNT,
                ];
            case CUSTOMIZATION.STANCE:
                return [
                    CUSTOMIZATION_RARITY.SEASON_STANCE,
                    CUSTOMIZATION_RARITY.EPIC_STANCE,
                    CUSTOMIZATION_RARITY.RARE_STANCE,
                    CUSTOMIZATION_RARITY.COMMON_STANCE,
                ];
            case CUSTOMIZATION.SKIN:
                return [
                    CUSTOMIZATION_RARITY.LEGENDARY_SKIN,
                    CUSTOMIZATION_RARITY.SEASON_SKIN,
                    CUSTOMIZATION_RARITY.EPIC_SKIN,
                    CUSTOMIZATION_RARITY.RARE_SKIN,
                    CUSTOMIZATION_RARITY.COMMON_SKIN,
                ];
            case CUSTOMIZATION.EMOJI:
                return [
                    CUSTOMIZATION_RARITY.EMOJI,
                ];
            case CUSTOMIZATION.TEXT_EMOJI_PACK:
                return [
                    CUSTOMIZATION_RARITY.LEGENDARY_TEXT_EMOJI_PACK,
                    CUSTOMIZATION_RARITY.EPIC_TEXT_EMOJI_PACK,
                    CUSTOMIZATION_RARITY.RARE_TEXT_EMOJI_PACK,
                    CUSTOMIZATION_RARITY.COMMON_TEXT_EMOJI_PACK,
                ];
            case CUSTOMIZATION.WEAPON:
                return [
                    CUSTOMIZATION_RARITY.LEGENDARY_WEAPON,
                    CUSTOMIZATION_RARITY.EPIC_WEAPON,
                    CUSTOMIZATION_RARITY.RARE_WEAPON,
                    CUSTOMIZATION_RARITY.COMMON_WEAPON,
                ];
        }
        return [];
    };
    CustomizationUtils.getCustomizationChestTooltipTypeByPsrnd = function (type) {
        switch (type) {
            case PSRND_ITEM.COMMON_WEAPON:
            case PSRND_ITEM.RARE_WEAPON:
            case PSRND_ITEM.EPIC_WEAPON:
            case PSRND_ITEM.SEASON_WEAPON:
            case PSRND_ITEM.LEGENDARY_WEAPON:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS;
            case PSRND_ITEM.COMMON_SKIN:
            case PSRND_ITEM.RARE_SKIN:
            case PSRND_ITEM.EPIC_SKIN:
            case PSRND_ITEM.SEASON_SKIN:
            case PSRND_ITEM.LEGENDARY_SKIN:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS;
            case PSRND_ITEM.COMMON_STANCE:
            case PSRND_ITEM.RARE_STANCE:
            case PSRND_ITEM.EPIC_STANCE:
            case PSRND_ITEM.SEASON_STANCE:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES;
            case PSRND_ITEM.COMMON_WINPOSE:
            case PSRND_ITEM.RARE_WINPOSE:
            case PSRND_ITEM.EPIC_WINPOSE:
            case PSRND_ITEM.SEASON_WINPOSE:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE;
            case PSRND_ITEM.COMMON_TAUNT:
            case PSRND_ITEM.RARE_TAUNT:
            case PSRND_ITEM.EPIC_TAUNT:
            case PSRND_ITEM.SEASON_TAUNT:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS;
            case PSRND_ITEM.EMOJI:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES;
            case PSRND_ITEM.COMMON_TEXT_EMOJI_PACK:
            case PSRND_ITEM.RARE_TEXT_EMOJI_PACK:
            case PSRND_ITEM.EPIC_TEXT_EMOJI_PACK:
            case PSRND_ITEM.LEGENDARY_TEXT_EMOJI_PACK:
                return CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK;
        }
        return null;
    };
    CustomizationUtils.createLootSettings = function (customizationType, lootSettings) {
        var result = [];
        if (customizationType == CUSTOMIZATION.EMOJI) {
            lootSettings.Emoji = result;
        }
        else if (customizationType == CUSTOMIZATION.STANCE) {
            lootSettings.Stances = result;
        }
        else if (customizationType == CUSTOMIZATION.TAUNT) {
            lootSettings.Taunts = result;
        }
        else if (customizationType == CUSTOMIZATION.WEAPON) {
            lootSettings.Weapons = result;
        }
        else if (customizationType == CUSTOMIZATION.SKIN) {
            lootSettings.Skins = result;
        }
        else if (customizationType == CUSTOMIZATION.TEXT_EMOJI_PACK) {
            lootSettings.TextEmojiPacks = result;
        }
        return result;
    };
    CustomizationUtils.getDefaultUnavailableAlias = function (type, id) {
        switch (type) {
            case CUSTOMIZATION.SKIN: return HeroConstants.aliasesForFindButton.skinUnavailable;
            case CUSTOMIZATION.EMOJI: return HeroConstants.aliasesForFindButton.emojiUnavailable;
            case CUSTOMIZATION.TAUNT: return HeroConstants.aliasesForFindButton.tauntUnavailable;
            case CUSTOMIZATION.STANCE:
                var stance = stancesMap.get(id);
                return stance && stance.Settings.StanceType == STANCE_TYPE.WIN_POSE
                    ? HeroConstants.aliasesForFindButton.winUnavailable
                    : HeroConstants.aliasesForFindButton.stanceUnavailable;
            case CUSTOMIZATION.WEAPON: return HeroConstants.aliasesForFindButton.waitForEvent;
        }
        return HeroConstants.aliasesForFindButton.waitForEvent;
    };
    CustomizationUtils.getCustomizationCurrencies = function (compensatingRate, type, rarity) {
        var defaultCurrencies = compensatingRate.defaultCompensation;
        var cardCurrencies;
        if (type == CUSTOMIZATION.WEAPON) {
            cardCurrencies = compensatingRate.weapons[rarity];
        }
        else if (type == CUSTOMIZATION.EMOJI) {
            cardCurrencies = compensatingRate.emoji;
        }
        else if (type == CUSTOMIZATION.SKIN) {
            cardCurrencies = compensatingRate.skins[rarity];
        }
        else if (type == CUSTOMIZATION.STANCE) {
            cardCurrencies = compensatingRate.stances[rarity];
        }
        else if (type == CUSTOMIZATION.TAUNT) {
            cardCurrencies = compensatingRate.taunts[rarity];
        }
        else if (type == CUSTOMIZATION.TEXT_EMOJI_PACK) {
            cardCurrencies = compensatingRate.textEmojiPack[rarity];
        }
        return cardCurrencies || defaultCurrencies;
    };
    CustomizationUtils.getPromoInfoCustomizationContainer = function (customizationType, settings) {
        switch (customizationType) {
            case CUSTOMIZATION.WEAPON:
                return settings.customization.weapons;
            case CUSTOMIZATION.TAUNT:
                return settings.customization.taunts;
            case CUSTOMIZATION.STANCE:
                return settings.customization.stances;
            case CUSTOMIZATION.SKIN:
                return settings.customization.skins;
            case CUSTOMIZATION.EMOJI:
                return settings.customization.emoji;
        }
        return null;
    };
    CustomizationUtils.buildCustomizationSettings = function (type, rarities) {
        switch (type) {
            case CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS:
                return { Weapons: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS:
                return { Skins: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES:
                return { Emoji: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS:
                return { Taunts: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES:
                return { Stances: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK:
                return { TextEmojiPacks: { Rarities: __assign({}, rarities) } };
            case CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS:
                return {
                    Stances: { Rarities: __assign({}, rarities) },
                    Taunts: { Rarities: __assign({}, rarities) }
                };
            default:
                return {};
        }
    };
    CustomizationUtils.getCustomizationTypeByChestTooltipType = function (type) {
        return ChestsConstants.tooltipTypeToCustomization[type];
    };
    CustomizationUtils.getTypeChestTooltipTypeByCustomization = function (type) {
        var chestType;
        for (chestType in ChestsConstants.tooltipTypeToCustomization) {
            if (ChestsConstants.tooltipTypeToCustomization[chestType] == type) {
                return chestType;
            }
        }
        return undefined;
    };
    CustomizationUtils.getCompositeCustomizationShardID = function (settings) {
        return Number(settings.type) * this.customizationTypeMultiplier + settings.id;
    };
    CustomizationUtils.getCustomizationShardsData = function (compositeId) {
        return customizationShardsMap.checkedGet(compositeId);
    };
    CustomizationUtils.buildCompositeCustomizationShardsMap = function () {
        var result = {};
        for (var typeKey in CUSTOMIZATION) {
            var customizationType = Number(typeKey);
            if (isNaN(customizationType))
                continue;
            var customizationMap = CustomizationUtils.getOrderMap(customizationType);
            if (!customizationMap)
                continue;
            for (var _i = 0, _a = customizationMap.getKeys(); _i < _a.length; _i++) {
                var entityId = _a[_i];
                var numericEntityId = Number(entityId);
                var entity = customizationMap.checkedGet(numericEntityId);
                if (!entity)
                    continue;
                var shardsNeeded = entity.ShardsNeeded;
                if (!shardsNeeded || shardsNeeded <= 0)
                    continue;
                var compositeId = this.getCompositeCustomizationShardID({
                    type: customizationType,
                    id: numericEntityId
                });
                result[compositeId] = {
                    ID: compositeId,
                    entityId: numericEntityId,
                    customizationType: customizationType,
                    shardsNeeded: shardsNeeded,
                };
            }
        }
        return result;
    };
    CustomizationUtils.customizationTypeMultiplier = 10000000;
    return CustomizationUtils;
}());
function getCompositeShardsId(type, id) {
    return CustomizationUtils.getCompositeCustomizationShardID({ type: type, id: id });
}
