var shadowAbilities = {
    ShadowDash: new ShadowAbility({
        ID: 1,
        Icon: "Sprites/Assets/ShadowAbilities/Feldsher/icon_shadow_ability_Feldsher_forward",
        AliasName: "SHADOW_DASH_NAME",
        Tag: "SHADOW_DASH",
        Animation: "Shadow_Dash",
        Cooldown: 999999
    }),
    Shadow_Precise_Armor: new ShadowAbility({
        ID: 3,
        Icon: "Sprites/Assets/ShadowAbilities/Feldsher/icon_shadow_ability_Feldsher_down",
        AliasName: "SHADOW_PRECISE_ARMOR_EXPLOSION_NAME",
        Tag: "SHADOW_PRECISE_ARMOR_EXPLOSION",
        Animation: "Shadow_Precise_Armor",
        Cooldown: 999999
    }),
    Shadow_Push_Player: new ShadowAbility({
        ID: 25,
        Icon: "Sprites/Assets/ShadowAbilities/Feldsher/icon_shadow_ability_Feldsher_back",
        AliasName: "SHADOW_PUSH_NAME",
        Tag: "SHADOW_PUSH",
        Animation: "Shadow_Push_Player",
        Cooldown: 999999
    }),
    Shadow_Naginata_Slash_1: new ShadowAbility({
        ID: 55,
        Icon: "Sprites/Assets/ShadowAbilities/Feldsher/icon_shadow_ability_Feldsher_up",
        AliasName: "SHADOW_NAGINATA_SLASH_1_NAME",
        Tag: "SHADOW_NAGINATA_SLASH_1",
        Animation: "Shadow_Naginata_Slash_1",
        Cooldown: 999999
    }),
    Shadow_Guandao_Slash_1: new ShadowAbility({
        ID: 6,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_forward",
        AliasName: "SHADOW_GUANDAO_SPINNING_SLASH_1_NAME",
        Tag: "SHADOW_GUANDAO_SPINNING_SLASH_1",
        Animation: "Shadow_Guandao_Slash_1",
        Cooldown: 999999
    }),
    Shadow_Ranged_Agile_Bow: new ShadowAbility({
        ID: 8,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_up",
        AliasName: "SHADOW_RANGED_AGILE_BOW_NAME",
        Tag: "SHADOW_RANGED_AGILE_BOW",
        Animation: "Shadow_Ranged_Agile_Bow",
        Cooldown: 999999
    }),
    Shadow_Agile_Helmet: new ShadowAbility({
        ID: 9,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_up_update",
        AliasName: "SHADOW_AGILE_HELMET_NAME",
        Tag: "SHADOW_AGILE_HELMET",
        Animation: "Shadow_Agile_Helmet",
        Cooldown: 999999
    }),
    Shadow_Agile_Helmet_3: new ShadowAbility({
        ID: 10,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_back",
        AliasName: "SHADOW_MIND_CONTROL_NAME",
        Tag: "SHADOW_AGILE_HELMET_3",
        Animation: "Shadow_Agile_Helmet_3",
        Cooldown: 999999
    }),
    Shadow_Mine_Start: new ShadowAbility({
        ID: 11,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_down",
        AliasName: "SHADOW_MINE_NAME",
        Tag: "SHADOW_MINE",
        Animation: "Shadow_Mine_Start",
        Cooldown: 999999
    }),
    Shadow_Guandao_Slash_1_Zone: new ShadowAbility({
        ID: 107,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_forward",
        AliasName: "SHADOW_GUANDAO_SPINNING_SLASH_1_NAME",
        Tag: "SHADOW_GUANDAO_SPINNING_SLASH_1",
        Animation: "Shadow_Guandao_Slash_1_Zone",
        Cooldown: 999999
    }),
    Shadow_Agile_Helmet_3_Starter: new ShadowAbility({
        ID: 108,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_back",
        AliasName: "SHADOW_MIND_CONTROL_NAME",
        Tag: "SHADOW_AGILE_HELMET_3",
        Animation: "Shadow_Agile_Helmet_3_Starter",
        Cooldown: 999999
    }),
    Shadow_Mine_Start_Starter: new ShadowAbility({
        ID: 109,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_down",
        AliasName: "SHADOW_MINE_NAME",
        Tag: "SHADOW_MINE",
        Animation: "Shadow_Mine_Start_Starter",
        Cooldown: 999999
    }),
    Shadow_Guandao_Slash_1_Starter: new ShadowAbility({
        ID: 110,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_forward",
        AliasName: "SHADOW_GUANDAO_SPINNING_SLASH_1_NAME",
        Tag: "SHADOW_GUANDAO_SPINNING_SLASH_1",
        Animation: "Shadow_Guandao_Slash_1_Starter",
        Cooldown: 999999
    }),
    Shadow_Ranged_Agile_Bow_Starter: new ShadowAbility({
        ID: 111,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_up",
        AliasName: "SHADOW_RANGED_AGILE_BOW_NAME",
        Tag: "SHADOW_RANGED_AGILE_BOW",
        Animation: "Shadow_Ranged_Agile_Bow_Starter",
        Cooldown: 999999
    }),
    Shadow_Kunai: new ShadowAbility({
        ID: 118,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_down",
        AliasName: "MIDNIGHT_SHADOW_SAI_NAME",
        Tag: "MIDNIGHT_SHADOW_SAI",
        Animation: "Shadow_Kunai",
        Cooldown: 999999
    }),
    Shadow_Strong_Armor: new ShadowAbility({
        ID: 12,
        Icon: "Sprites/Assets/ShadowAbilities/Ironclad/icon_shadow_ability_Ironclad_forward",
        AliasName: "SHADOW_STRONG_ARMOR_NAME",
        Tag: "SHADOW_STRONG_ARMOR",
        Animation: "Shadow_Strong_Armor",
        Cooldown: 999999
    }),
    Shadow_Ranged_Strong_Pistol: new ShadowAbility({
        ID: 19,
        Icon: "Sprites/Assets/ShadowAbilities/Liquidator/icon_shadow_ability_Liquidator_Pistol_back",
        AliasName: "SHADOW_RANGED_STRONG_PISTOL_NAME",
        Tag: "SHADOW_RANGED_STRONG_PISTOL",
        Animation: "Shadow_Ranged_Strong_Pistol",
        Cooldown: 999999
    }),
    Shadow_Dual_Swords_Miss: new ShadowAbility({
        ID: 33,
        Icon: "Sprites/Assets/ShadowAbilities/Liquidator/icon_shadow_ability_Liquidator_forward",
        AliasName: "SHADOW_DUAL_SWORDS_SLASH_NAME",
        Tag: "SHADOW_DUAL_SWORDS_SLASH",
        Animation: "Shadow_Dual_Swords_Miss",
        Cooldown: 999999
    }),
    Shadow_Thud: new ShadowAbility({
        ID: 34,
        Icon: "Sprites/Assets/ShadowAbilities/Liquidator/icon_shadow_ability_Liquidator_down",
        AliasName: "SHADOW_THUD_NAME",
        Tag: "SHADOW_THUD",
        Animation: "Shadow_Thud",
        Cooldown: 999999
    }),
    Shadow_Ranged_Strong_Arbalest: new ShadowAbility({
        ID: 73,
        Icon: "Sprites/Assets/ShadowAbilities/Liquidator/icon_shadow_ability_Liquidator_Arbalest_back",
        AliasName: "SHADOW_RANGED_STRONG_ARBALEST_NAME",
        Tag: "SHADOW_RANGED_STRONG_ARBALEST",
        Animation: "Shadow_Ranged_Strong_Arbalest",
        Cooldown: 999999
    }),
    Shadow_Dual_Kama_Slash_1_Miss: new ShadowAbility({
        ID: 22,
        Icon: "Sprites/Assets/ShadowAbilities/Fireguard/icon_shadow_ability_Fireguard_forward",
        AliasName: "SHADOW_DUAL_KAMA_SLASH_1_NAME",
        Tag: "SHADOW_DUAL_KAMA_SLASH_1",
        Animation: "Shadow_Dual_Kama_Slash_1_Miss",
        Cooldown: 999999
    }),
    Shadow_Ranged_Precise_Folding_Shuriken: new ShadowAbility({
        ID: 43,
        Icon: "Sprites/Assets/ShadowAbilities/Fireguard/icon_shadow_ability_Fireguard_up",
        AliasName: "SHADOW_RANGED_PRECISE_FOLDING_SHURIKEN_NAME",
        Tag: "SHADOW_RANGED_PRECISE_FOLDING_SHURIKEN",
        Animation: "Shadow_Ranged_Precise_Folding_Shuriken",
        Cooldown: 999999
    }),
    Shadow_Fireguard_Dodge: new ShadowAbility({
        ID: 90,
        Icon: "Sprites/Assets/ShadowAbilities/Fireguard/icon_shadow_ability_Fireguard_down",
        AliasName: "SHADOW_FIREGUARD_DODGE_NAME",
        Tag: "SHADOW_FIREGUARD_DODGE",
        Animation: "Shadow_Fireguard_Dodge",
        Cooldown: 999999
    }),
    Fireguard_Shadow_Fly: new ShadowAbility({
        ID: 99,
        Icon: "Sprites/Assets/ShadowAbilities/Fireguard/icon_shadow_ability_Fireguard_up_new",
        AliasName: "SHADOW_PRECISE_ARMOR_THROW_NAME",
        Tag: "FIREGUARD_SHADOW_FLY",
        Animation: "Fireguard_Shadow_Fly_Start",
        Cooldown: 999999
    }),
    Kibo_Shadow_Ability_Miss: new ShadowAbility({
        ID: 27,
        Icon: "Sprites/Assets/ShadowAbilities/Kibo/icon_shadow_ability_Kibo_forward",
        AliasName: "SHADOW_KIBO_KATANA_NAME",
        Tag: "SHADOW_KIBO_KATANA",
        Animation: "Kibo_Shadow_Ability_Miss",
        Cooldown: 999999
    }),
    Kibo_Shadow_Katana_Slash: new ShadowAbility({
        ID: 28,
        Icon: "Sprites/Assets/ShadowAbilities/Ling/icon_shadow_ability_Ling_back",
        AliasName: "SHADOW_KIBO_KATANA_SLASH_1_NAME",
        Tag: "SHADOW_KATANA_SLASH_1",
        Animation: "Shadow_Katana_Slash_1_Start",
        Cooldown: 999999
    }),
    Ling_Super_Katana_Throw: new ShadowAbility({
        ID: 89,
        Icon: "Sprites/Assets/ShadowAbilities/Ling/icon_shadow_ability_Ling_up",
        AliasName: "SHADOW_KATANA_HOP_NAME",
        Tag: "KATANA_HOP_SHADOW",
        Animation: "Ling_Super_Katana_Throw",
        Cooldown: 999999
    }),
    Shadow_Ling_Thrust_Miss: new ShadowAbility({
        ID: 97,
        Icon: "Sprites/Assets/ShadowAbilities/Ling/icon_shadow_ability_Ling_forward",
        AliasName: "SHADOW_LING_THRUST_NAME",
        Tag: "SHADOW_LING_THRUST",
        Animation: "Shadow_Ling_Thrust_Miss",
        Cooldown: 999999
    }),
    Ling_Shadow_Katana_Slash: new ShadowAbility({
        ID: 98,
        Icon: "Sprites/Assets/ShadowAbilities/Ling/icon_shadow_ability_Ling_back",
        AliasName: "SHADOW_KATANA_SLASH_1_NAME",
        Tag: "SHADOW_KATANA_SLASH_1",
        Animation: "Shadow_Katana_Slash_1_Start",
        Cooldown: 999999
    }),
    Emperor_Shadow_Blade_Throw_Miss: new ShadowAbility({
        ID: 38,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_up",
        AliasName: "SHADOW_EMPEROR_BLADE_THROW_NAME",
        Tag: "SHADOW_EMPEROR_BLADE_THROW",
        Animation: "Emperor_Shadow_Blade_Throw_Miss",
        Cooldown: 999999
    }),
    Emperor_Shadow_Blade_Slash: new ShadowAbility({
        ID: 39,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_down",
        AliasName: "SHADOW_EMPEROR_BLADE_SLASH_NAME",
        Tag: "SHADOW_EMPEROR_BLADE_SLASH",
        Animation: "Emperor_Shadow_Blade_Slash",
        Cooldown: 999999
    }),
    Shadow_Carapace: new ShadowAbility({
        ID: 40,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_back",
        AliasName: "SHADOW_CARAPACE_NAME",
        Tag: "SHADOW_CARAPACE",
        Animation: "Shadow_Carapace",
        Cooldown: 999999
    }),
    Shadow_Claws_Slash_1: new ShadowAbility({
        ID: 15,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_forward",
        AliasName: "SHADOW_CLAWS_SLASH_1_NAME",
        Tag: "SHADOW_CLAWS_SLASH_1",
        Animation: "Shadow_Claws_Slash_1",
        Cooldown: 999999
    }),
    Marcus_Shadow_Pilum: new ShadowAbility({
        ID: 70,
        Icon: "Sprites/Assets/ShadowAbilities/Marcus/icon_shadow_ability_Marcus_back",
        AliasName: "MARCUS_SHADOW_PILUM_NAME",
        Tag: "MARCUS_SHADOW_PILUM",
        Animation: "Marcus_Shadow_Pilum",
        Cooldown: 999999
    }),
    Marcus_Shadow_Slash: new ShadowAbility({
        ID: 35,
        Icon: "Sprites/Assets/ShadowAbilities/Marcus/icon_shadow_ability_Marcus_forward",
        AliasName: "MARCUS_SHADOW_SLASH_NAME",
        Tag: "MARCUS_SHADOW_SLASH",
        Animation: "Marcus_Shadow_Slash",
        Cooldown: 999999
    }),
    Marcus_Shadow_Stun: new ShadowAbility({
        ID: 94,
        Icon: "Sprites/Assets/ShadowAbilities/Marcus/icon_shadow_ability_Marcus_down",
        AliasName: "Marcus_Talent_Third_Shadow_Ability_Name",
        Tag: "MARCUS_SHADOW_STUN",
        Animation: "Marcus_Shadow_Stun",
        Cooldown: 999999
    }),
    Shadow_Cat_Active: new ShadowAbility({
        ID: 87,
        Icon: "Sprites/Assets/ShadowAbilities/Yukka/icon_shadow_ability_Yukka_forward",
        AliasName: "SHADOW_YUKKA_CAT_NAME",
        Tag: "SHADOW_YUKKA_CAT",
        Animation: "Shadow_Cat_Active",
        Cooldown: 999999
    }),
    Paladinessa_Fly: new ShadowAbility({
        ID: 91,
        Icon: "Sprites/Assets/ShadowAbilities/Helga/icon_shadow_ability_Helga_forward",
        AliasName: "SHADOW_HELGA_FLY_FORWARD_NAME",
        Tag: "PALADINESSA_FLY",
        Animation: "Paladinessa_Fly",
        Cooldown: 200
    }),
    Paladinessa_Fly_Left: new ShadowAbility({
        ID: 92,
        Icon: "Sprites/Assets/ShadowAbilities/Helga/icon_shadow_ability_Helga_back",
        AliasName: "SHADOW_HELGA_FLY_BACK_NAME",
        Tag: "PALADINESSA_FLY_LEFT",
        Animation: "Paladinessa_Fly_Left",
        Cooldown: 200
    }),
    Shadow_Shield_Knobstick_Slash_1: new ShadowAbility({
        ID: 95,
        Icon: "Sprites/Assets/ShadowAbilities/Bulwark/icon_shadow_ability_Bulwark_back",
        AliasName: "SHADOW_SHIELD_KNOBSTICK_SLASH_1_NAME",
        Tag: "SHADOW_SHIELD_KNOBSTICK_SLASH_1",
        Animation: "Shadow_Shield_Knobstick_Slash_1",
        Cooldown: 999999
    }),
    Bulwark_Shadow_Chain: new ShadowAbility({
        ID: 96,
        Icon: "Sprites/Assets/ShadowAbilities/Bulwark/icon_shadow_ability_Bulwark_forward",
        AliasName: "SHADOW_GLADIATOR_CHAIN_NAME",
        Tag: "BULWARK_SHADOW_CHAIN",
        Animation: "Bulwark_Shadow_Chain_Miss",
        Cooldown: 999999
    }),
    HongJoo_Triumph: new ShadowAbility({
        ID: 112,
        Icon: "Sprites/Assets/ShadowAbilities/HongJoo/icon_shadow_ability_HongJoo",
        AliasName: "HONG_JOO_TRIUMPH_ABIILITY_NAME",
        Tag: "HONG_JOO_FAKE_TRIUMPH_TAG",
        Animation: "Hong_Joo_Rage_Ability",
        Cooldown: 999999
    }),
    HongJoo_Triumph_2: new ShadowAbility({
        ID: 113,
        Icon: "Sprites/Assets/ShadowAbilities/HongJoo/icon_shadow_ability_HongJoo_t_shadow2",
        AliasName: "HONG_JOO_TRIUMPH_ABIILITY_NAME",
        Tag: "HONG_JOO_FAKE_TRIUMPH_TAG",
        Animation: "Hong_Joo_Rage_Ability",
        Cooldown: 999999
    }),
    HongJoo_Triumph_shake_1: new ShadowAbility({
        ID: 114,
        Icon: "Sprites/Assets/ShadowAbilities/HongJoo/icon_shadow_ability_HongJoo_t_shake_01",
        AliasName: "HONG_JOO_TRIUMPH_ABIILITY_NAME",
        Tag: "HONG_JOO_FAKE_TRIUMPH_TAG",
        Animation: "Hong_Joo_Rage_Ability",
        Cooldown: 999999
    }),
    HongJoo_Triumph_shake_2: new ShadowAbility({
        ID: 115,
        Icon: "Sprites/Assets/ShadowAbilities/HongJoo/icon_shadow_ability_HongJoo_t_shake_02",
        AliasName: "HONG_JOO_TRIUMPH_ABIILITY_NAME",
        Tag: "HONG_JOO_FAKE_TRIUMPH_TAG",
        Animation: "Hong_Joo_Rage_Ability",
        Cooldown: 999999
    }),
    Midnight_Parry: new ShadowAbility({
        ID: 116,
        Icon: "Sprites/Assets/ShadowAbilities/Midnight/icon_shadow_ability_Midnight_back",
        AliasName: "MIDNIGHT_PARRY_NAME",
        Tag: "MIDNIGHT_PARRY",
        Animation: "Midnight_Parry",
        Cooldown: 999999
    }),
    Midnight_Sai_Slash: new ShadowAbility({
        ID: 117,
        Icon: "Sprites/Assets/ShadowAbilities/Midnight/icon_shadow_ability_Midnight_forward",
        AliasName: "MIDNIGHT_SHADOW_SAI_NAME",
        Tag: "MIDNIGHT_SHADOW_SAI",
        Animation: "Shadow_Sai_Slash_1_Miss",
        Cooldown: 999999
    }),
    Shadow_Lynx_Claws_2: new ShadowAbility({
        ID: 119,
        Icon: "Sprites/Assets/ShadowAbilities/Lynx/icon_shadow_ability_Lynx_Forward",
        AliasName: "SHADOW_LYNX_CLAWS_ALIAS",
        Tag: "SHADOW_LYNX_CLAWS_2",
        Animation: "Lynx_Shadow_Claws_Slash_1",
        Cooldown: 999999
    }),
    Shadow_Staff_Special: new ShadowAbility({
        ID: 120,
        Icon: "Sprites/Assets/ShadowAbilities/Monkey_King/icon_shadow_ability_Monkey_King_Special",
        AliasName: "SHADOW_STAFF_SPECIAL_ALIAS",
        Tag: "SHADOW_STAFF_SPECIAL",
        Animation: "Shadow_Staff_SPECIAL",
        Cooldown: 30
    }),
    Shadow_Staff: new ShadowAbility({
        ID: 121,
        Icon: "Sprites/Assets/ShadowAbilities/Monkey_King/icon_shadow_ability_Monkey_King",
        AliasName: "SHADOW_STAFF_ALIAS",
        Tag: "SHADOW_STAFF",
        Animation: "Shadow_Staff",
        Cooldown: 30
    }),
    Viper_Shadow_Long: new ShadowAbility({
        ID: 122,
        Icon: "Sprites/Assets/ShadowAbilities/Viper/icon_ability_Viper_shadow_forward",
        AliasName: "VIPER_SHADOW_LONG_ALIAS",
        Tag: "VIPER_SHADOW_LONG_TAG",
        Animation: "Viper_Shadow_Long",
        Cooldown: 999999
    }),
    Viper_Shadow_Short: new ShadowAbility({
        ID: 123,
        Icon: "Sprites/Assets/ShadowAbilities/Viper/icon_ability_Viper_shadow_down",
        AliasName: "VIPER_SHADOW_SHORT_ALIAS",
        Tag: "VIPER_SHADOW_SHORT_TAG",
        Animation: "Viper_Shadow_Short",
        Cooldown: 999999
    }),
    Jet_Shadow_Teleport_Miss: new ShadowAbility({
        ID: 124,
        Icon: "Sprites/Assets/ShadowAbilities/Jet/icon_shadow_ability_Jet_Teleport",
        AliasName: "JET_SHADOW_TELEPORT_ALIAS",
        Tag: "JET_SHADOW_TELEPORT",
        Animation: "Jet_Shadow_Teleport_Miss",
        Cooldown: 999999
    }),
    Shadow_Glaive_Knives_Slash: new ShadowAbility({
        ID: 125,
        Icon: "Sprites/Assets/ShadowAbilities/Jet/icon_shadow_ability_Shadow_Glave_Knives_Slash_new_version",
        AliasName: "SHADOW_GLAIVE_KNIVES_SLASH_ALIAS",
        Tag: "SHADOW_GLAIVE_KNIVES_SLASH_TAG",
        Animation: "Shadow_Glaive_Knives_Slash_Miss",
        Cooldown: 999999
    }),
    Shadow_Ranged_Chain: new ShadowAbility({
        ID: 126,
        Icon: "Sprites/Assets/Abilities/Legion_King/icon_shadow_ability_Legion_King_back",
        AliasName: "SHADOW_RANGED_CHAIN_ALIAS",
        Tag: "SHADOW_RANGED_CHAIN",
        Animation: "Shadow_Ranged_Chain",
        Cooldown: 999999
    }),
    Shadow_Twohanded_Sword_Forward: new ShadowAbility({
        ID: 127,
        Icon: "Sprites/Assets/Abilities/Legion_King/icon_shadow_ability_Legion_King_forward",
        AliasName: "SHADOW_TWOHANDED_SWORD_FORWARD_ALIAS",
        Tag: "SHADOW_TWOHANDED_SWORD_FORWARD",
        Animation: "Shadow_Twohanded_Sword_Forward",
        Cooldown: 999999
    }),
    Shadow_Twohanded_Sword_Down: new ShadowAbility({
        ID: 128,
        Icon: "Sprites/Assets/Abilities/Legion_King/icon_shadow_ability_Legion_King_down",
        AliasName: "SHADOW_TWOHANDED_SWORD_DOWN_ALIAS",
        Tag: "SHADOW_TWOHANDED_SWORD_DOWN",
        Animation: "Shadow_Twohanded_Sword_Down",
        Cooldown: 999999
    }),
    Shadow_Beam: new ShadowAbility({
        ID: 129,
        Icon: "Sprites/Assets/Abilities/Legion_King/icon_shadow_ability_Legion_King_up",
        AliasName: "SHADOW_BEAM_ALIAS",
        Tag: "SHADOW_BEAM",
        Animation: "Shadow_Beam",
        Cooldown: 999999
    }),
    Shadow_Charge: new ShadowAbility({
        ID: 130,
        Icon: "Sprites/Assets/ShadowAbilities/Itu/icon_shadow_ability_Itu_Shadow_Charge",
        AliasName: "SHADOW_CHARGE_ALIAS",
        Tag: "SHADOW_CHARGE",
        Animation: "Itu_Shadow_Charge_In",
        Cooldown: 999999
    }),
    Yunlin_Stun: new ShadowAbility({
        ID: 131,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Stun",
        AliasName: "YUNLIN_STUN_ALIAS",
        Tag: "YUNLIN_STUN",
        Animation: "Yunlin_Stun",
        Cooldown: 0
    }),
    Yunlin_Teleport: new ShadowAbility({
        ID: 132,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Teleport",
        AliasName: "YUNLIN_TELEPORT_ALIAS",
        Tag: "YUNLIN_TELEPORT",
        Animation: "Yunlin_Teleport",
        Cooldown: 0
    }),
    Yunlin_Heal: new ShadowAbility({
        ID: 133,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Heal",
        AliasName: "YUNLIN_HEAL_ALIAS",
        Tag: "YUNLIN_HEAL",
        Animation: "Yunlin_Heal",
        Cooldown: 0
    }),
    Yunlin_Manadrain: new ShadowAbility({
        ID: 134,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Manadrain",
        AliasName: "YUNLIN_MANADRAIN_ALIAS",
        Tag: "YUNLIN_MANADRAIN",
        Animation: "Yunlin_Manadrain_Miss",
        Cooldown: 0
    }),
    Yunlin_Invulnerability: new ShadowAbility({
        ID: 135,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Invulnerability",
        AliasName: "YUNLIN_INVULNERABILITY_ALIAS",
        Tag: "YUNLIN_INVULNERABILITY",
        Animation: "Yunlin_Invulnerability",
        Cooldown: 0
    }),
    Yunlin_Invisibility: new ShadowAbility({
        ID: 136,
        Icon: "Sprites/Assets/ShadowAbilities/Yunlin/icon_shadow_ability_Yunlin_Invisibility",
        AliasName: "YUNLIN_INVISIBILITY_ALIAS",
        Tag: "YUNLIN_INVISIBILITY",
        Animation: "Yunlin_Invisibility",
        Cooldown: 0
    }),
    June_Shadow_Up: new ShadowAbility({
        ID: 141,
        Icon: "Sprites/Assets/ShadowAbilities/June/icon_shadow_ability_June_up",
        AliasName: "SHADOW_JUNE_UP_NAME",
        Tag: "SHADOW_JUNE_UP",
        Animation: "June_Shadow_Up",
        Cooldown: 999999
    }),
    June_Shadow_Down: new ShadowAbility({
        ID: 142,
        Icon: "Sprites/Assets/ShadowAbilities/June/icon_shadow_ability_June_down",
        AliasName: "SHADOW_JUNE_DOWN_NAME",
        Tag: "SHADOW_JUNE_DOWN",
        Animation: "June_Shadow_Down",
        Cooldown: 999999
    }),
    Gideon_Shadow_Up: new ShadowAbility({
        ID: 143,
        Icon: "Sprites/Assets/ShadowAbilities/Gideon/icon_shadow_ability_Gideon_up",
        AliasName: "SHADOW_GIDEON_UP_NAME",
        Tag: "GIDEON_SHADOW_UP",
        Animation: "Gideon_Shadow_Ghost_Player",
        Cooldown: 999999
    }),
    Gideon_Shadow_Forward_Mana: new ShadowAbility({
        ID: 144,
        Icon: "Sprites/Assets/ShadowAbilities/Gideon/icon_shadow_ability_Gideon_forward_mana",
        AliasName: "GIDEON_SHADOW_FORWARD_MANA_NAME",
        Tag: "GIDEON_SHADOW_FORWARD_MANA",
        Animation: "Gideon_Shadow_Powder_Player",
        Cooldown: 999999
    }),
    Gideon_Shadow_Forward_Damage: new ShadowAbility({
        ID: 145,
        Icon: "Sprites/Assets/ShadowAbilities/Gideon/icon_shadow_ability_Gideon_forward_damage",
        AliasName: "GIDEON_SHADOW_FORWARD_DAMAGE_NAME",
        Tag: "GIDEON_SHADOW_FORWARD_DAMAGE",
        Animation: "Gideon_Shadow_Powder_Player",
        Cooldown: 999999
    }),
    Widow_Shadow_Forward: new ShadowAbility({
        ID: 146,
        Icon: "Sprites/Assets/ShadowAbilities/Widow/icon_shadow_ability_Widow_forward",
        AliasName: "SHADOW_WIDOW_FORWARD_NAME",
        Tag: "SHADOW_FANS",
        Animation: "Widow_Shadow_Player_Miss",
        Cooldown: 999999
    }),
    Raikichi_Ability_Dash: new ShadowAbility({
        ID: 147,
        Icon: "Sprites/Assets/ShadowAbilities/Raikichi/icon_shadow_ability_Raikichi_runes",
        AliasName: "Raikichi_Ability_Dash_Name",
        Tag: "Raikichi_Ability_Dash_Tag",
        Animation: "Raikichi_Slash_1",
        Cooldown: 999999
    }),
    Nonna_Bear_Form: new ShadowAbility({
        ID: 148,
        Icon: "Sprites/Assets/ShadowAbilities/Nonna/icon_shadow_ability_Nonna_bear",
        AliasName: "Nonna_Bear_Form",
        Tag: "",
        Animation: "Nonna_Bear_Transform_Anim",
        Cooldown: 999999
    }),
    Shogun_Shadow_Ability_Left: new ShadowAbility({
        ID: 149,
        Icon: "Sprites/Assets/ShadowAbilities/Shogun/icon_shadow_ability_Shogun_backward",
        AliasName: "SHOGUN_SHADOW_BACK_NAME",
        Tag: "",
        Animation: "Shogun_Shadow_Back_Miss",
        Cooldown: 999999
    }),
    Shogun_Shadow_Ability_Right: new ShadowAbility({
        ID: 150,
        Icon: "Sprites/Assets/ShadowAbilities/Shogun/icon_shadow_ability_Shogun_forward",
        AliasName: "SHOGUN_SHADOW_FORWARD_NAME",
        Tag: "",
        Animation: "Shogun_Shadow_Forward_Miss",
        Cooldown: 999999
    }),
    Shadow_Strong_Armor_PVE: new ShadowAbility({
        ID: 66601,
        Icon: "Sprites/Assets/ShadowAbilities/Ironclad/icon_shadow_ability_Ironclad_forward",
        AliasName: "SHADOW_STRONG_ARMOR_NAME",
        Tag: "SHADOW_STRONG_ARMOR",
        Animation: "Shadow_Strong_Armor_PvE",
        Cooldown: 999999
    }),
    Shadow_Strong_Armor_PVE_2: new ShadowAbility({
        ID: 66602,
        Icon: "Sprites/Assets/ShadowAbilities/Ironclad/icon_shadow_ability_Ironclad_forward",
        AliasName: "SHADOW_STRONG_ARMOR_NAME",
        Tag: "SHADOW_STRONG_ARMOR",
        Animation: "Shadow_Strong_Armor_PvE_2",
        Cooldown: 999999
    }),
    Shadow_Hammers_Throw: new ShadowAbility({
        ID: 66603,
        Icon: "Sprites/Assets/ShadowAbilities/Ironclad/icon_shadow_hammers_throw",
        AliasName: "SHADOW_HAMMERS_THROW_ALIAS",
        Tag: "SHADOW_HAMMERS_THROW_TAG",
        Animation: "Shadow_Hammers_Throw_Miss",
        Cooldown: 999999
    }),
    Sarge_Walk: new ShadowAbility({
        ID: 66604,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_down",
        AliasName: "SARGE_WALK_ALIAS",
        Tag: "SARGE_WALK_TAG",
        Animation: "Sarge_Walk",
        Cooldown: 999999
    }),
    Shadow_Agile_Helmet_3_PvE: new ShadowAbility({
        ID: 66605,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_back",
        AliasName: "SHADOW_MIND_CONTROL_NAME",
        Tag: "SHADOW_AGILE_HELMET_3_PvE",
        Animation: "Shadow_Agile_Helmet_3_PvE",
        Cooldown: 999999
    }),
    Shadow_Precise_Armor_PvE: new ShadowAbility({
        ID: 66606,
        Icon: "Sprites/Assets/ShadowAbilities/Feldsher/icon_shadow_ability_Feldsher_down",
        AliasName: "SHADOW_PRECISE_ARMOR_EXPLOSION_NAME",
        Tag: "SHADOW_PRECISE_ARMOR_EXPLOSION_PvE",
        Animation: "Shadow_Precise_Armor_PvE",
        Cooldown: 999999
    }),
    PVE_Bulwark_Shadow_Chain: new ShadowAbility({
        ID: 66607,
        Icon: "Sprites/Assets/ShadowAbilities/Bulwark/icon_shadow_ability_Bulwark_forward",
        AliasName: "SHADOW_GLADIATOR_CHAIN_NAME",
        Tag: "BULWARK_SHADOW_CHAIN",
        Animation: "PVE_Bulwark_Shadow_Chain_Miss",
        Cooldown: 999999
    }),
    PVE_Legion_King_Soul_Shower: new ShadowAbility({
        ID: 66608,
        Icon: "Sprites/Assets/Abilities/Legion_King/icon_shadow_ability_Legion_King_up",
        AliasName: "SHADOW_BEAM_ALIAS",
        Tag: "SHADOW_BEAM_PVE",
        Animation: "PVE_Legion_King_Soul_Shower",
        Cooldown: 999999
    }),
    Xiang_Tzu_Shadow_Forward: new ShadowAbility({
        ID: 137,
        Icon: "Sprites/Assets/ShadowAbilities/Midnight/icon_shadow_ability_Midnight_forward",
        AliasName: "SHADOW_CHARGE_ALIAS",
        Tag: "SHADOW_CHARGE",
        Animation: "Xiang_Tzu_Shadow_Forward",
        Cooldown: 999999
    }),
    Xiang_Tzu_Shadow_Back: new ShadowAbility({
        ID: 138,
        Icon: "Sprites/Assets/ShadowAbilities/Ling/icon_shadow_ability_Ling_back",
        AliasName: "SHADOW_CHARGE_ALIAS",
        Tag: "SHADOW_CHARGE",
        Animation: "Xiang_Tzu_Shadow_Back",
        Cooldown: 999999
    }),
    Xiang_Tzu_Shadow_Up: new ShadowAbility({
        ID: 139,
        Icon: "Sprites/Assets/ShadowAbilities/Midnight/icon_shadow_ability_Midnight_back",
        AliasName: "SHADOW_CHARGE_ALIAS",
        Tag: "SHADOW_CHARGE",
        Animation: "Xiang_Tzu_Shadow_Up",
        Cooldown: 999999
    }),
    Xiang_Tzu_Shadow_Down: new ShadowAbility({
        ID: 140,
        Icon: "Sprites/Assets/ShadowAbilities/Liquidator/icon_shadow_ability_Liquidator_down",
        AliasName: "SHADOW_CHARGE_ALIAS",
        Tag: "SHADOW_CHARGE",
        Animation: "Xiang_Tzu_Shadow_Down",
        Cooldown: 999999
    }),
    Shadow_Agile_Weapon_Tornado_PVE: new ShadowAbility({
        ID: 66609,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_AGILE_WEAPON_TORNADO",
        AliasName: "SHADOW_AGILE_WEAPON_TORNADO_NAME",
        Tag: "SHADOW_AGILE_WEAPON_TORNADO",
        Animation: "Shadow_Agile_Weapon_Tornado_PVE",
        Cooldown: 999999
    }),
    Shadow_Ranged_Precise_Beam_Electromine_PVE: new ShadowAbility({
        ID: 66610,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_RANGED_PRECISE_BEAM_ELECTROMINE",
        AliasName: "SHADOW_RANGED_PRECISE_BEAM_ELECTROMINE_NAME",
        Tag: "SHADOW_RANGED_PRECISE_BEAM_ELECTROMINE",
        Animation: "Shadow_Ranged_Precise_Electromine_Beam_Preparation_PVE",
        Cooldown: 999999
    }),
    Shadow_Agile_Whirl_PVE: new ShadowAbility({
        ID: 66611,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_AGILE_WHIRL",
        AliasName: "SHADOW_AGILE_WHIRL_NAME",
        Tag: "SHADOW_AGILE_WHIRL",
        Animation: "Shadow_Agile_Whirl_PVE",
        Cooldown: 999999
    }),
    Shadow_Ranged_Precise_Kunai_Start_PVE: new ShadowAbility({
        ID: 66612,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_RANGED_PRECISE_KUNAI",
        AliasName: "SHADOW_RANGED_PRECISE_KUNAI_NAME",
        Tag: "SHADOW_RANGED_PRECISE_KUNAI",
        Animation: "Shadow_Ranged_Precise_Kunai_Start_PVE",
        Cooldown: 999999
    }),
    Shadow_Ranged_Strong_Throwing_Axe_PVE: new ShadowAbility({
        ID: 66613,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_RANGED_STRONG_AXE",
        AliasName: "SHADOW_RANGED_STRONG_AXE_NAME",
        Tag: "SHADOW_RANGED_STRONG_AXE",
        Animation: "Shadow_Ranged_Strong_Throwing_Axe_PVE",
        Cooldown: 999999
    }),
    Shadow_Loop_PVE: new ShadowAbility({
        ID: 66614,
        Icon: "Sprites/Assets/ShadowAbilities/PVE_ShadowAbilities/SHADOW_LOOP",
        AliasName: "SHADOW_LOOP_NAME",
        Tag: "SHADOW_LOOP",
        Animation: "Shadow_Loop_PVE",
        Cooldown: 999999
    }),
    Shadow_Ranged_Agile_Bow_PVE: new ShadowAbility({
        ID: 66615,
        Icon: "Sprites/Assets/ShadowAbilities/Monk/icon_shadow_ability_Monk_up",
        AliasName: "SHADOW_RANGED_AGILE_BOW_PVE_NAME",
        Tag: "SHADOW_RANGED_AGILE_BOW_PVE",
        Animation: "Shadow_Ranged_Agile_Bow_PVE",
        Cooldown: 999999
    }),
    Emperor_Shadow_Blade_Throw_Miss_Pve: new ShadowAbility({
        ID: 66616,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_up",
        AliasName: "SHADOW_EMPEROR_BLADE_THROW_NAME",
        Tag: "SHADOW_EMPEROR_BLADE_THROW",
        Animation: "Emperor_Shadow_Blade_Throw_Miss",
        Cooldown: 0
    }),
    Emperor_Shadow_Blade_Slash_Pve: new ShadowAbility({
        ID: 66617,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_down",
        AliasName: "SHADOW_EMPEROR_BLADE_SLASH_NAME",
        Tag: "SHADOW_EMPEROR_BLADE_SLASH",
        Animation: "Emperor_Shadow_Blade_Slash",
        Cooldown: 0
    }),
    Shadow_Carapace_Pve: new ShadowAbility({
        ID: 66618,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_back",
        AliasName: "SHADOW_CARAPACE_NAME",
        Tag: "SHADOW_CARAPACE",
        Animation: "Shadow_Carapace",
        Cooldown: 0
    }),
    Shadow_Claws_Slash_1_Pve: new ShadowAbility({
        ID: 66619,
        Icon: "Sprites/Assets/ShadowAbilities/Emperor/icon_shadow_ability_Emperor_forward",
        AliasName: "SHADOW_CLAWS_SLASH_1_NAME",
        Tag: "SHADOW_CLAWS_SLASH_1",
        Animation: "Shadow_Claws_Slash_1",
        Cooldown: 0
    }),
};
