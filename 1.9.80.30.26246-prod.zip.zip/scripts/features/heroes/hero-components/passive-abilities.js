var passiveAbilities = {
    Example1: new PassiveAbility({
        ID: 501,
        Image: "Sprites/Assets/Abilities/feldsher_shadow_form_switch",
        AliasName: "feldsher_shadow_form_switch_name",
        AliasDesc: "feldsher_shadow_form_switch_desc",
        Parameters: {
            Frames: 60,
            SE_perFrame: 0.004,
            HP_perFrame: 0.0012
        }
    }),
    Example2: new PassiveAbility({
        ID: 502,
        Image: "Sprites/Assets/Abilities/ShadowProtect_icon",
        AliasName: "ShadowProtect_name",
        AliasDesc: "ShadowProtect_desc",
        Parameters: {
            ArmorMultiplier: 3
        }
    }),
    Example3: new PassiveAbility({
        ID: 503,
        Image: "Sprites/Assets/Abilities/light_judjment",
        AliasName: "light_judjment_name",
        AliasDesc: "light_judjment_desc",
        InterfaceOnTop: true
    }),
    Example4: new PassiveAbility({
        ID: 504,
        Image: "Sprites/Assets/Abilities/ShadowBurn_icon",
        AliasName: "ShadowBurn_name",
        AliasDesc: "ShadowBurn_desc",
        Parameters: {
            Frames: 60,
            SE_perFrame: 0.004,
            HP_perFrame: 0.0012
        }
    }),
    HelgaKara: new PassiveAbility({
        ID: 1,
        Image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_01",
        AliasName: "Helga_Ability_Kara_Alias",
        AliasDesc: "Helga_Ability_Kara_Desc",
        TalentComboOverride: [
            {
                Combo: [15],
                Override: { image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_t_2_1" },
                Priority: 1
            },
            {
                Combo: [16],
                Override: { image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_01" },
                Priority: 2
            }
        ]
    }),
    HelgaBubble: new PassiveAbility({
        ID: 2,
        Image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_02",
        AliasName: "Helga_Ability_Bubble_Alias",
        AliasDesc: "Helga_Ability_Bubble_Desc",
        TalentComboOverride: [
            {
                Combo: [24],
                Override: { image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_t_bubbledash" },
                Priority: 1
            },
            {
                Combo: [28],
                Override: { image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_02" },
                Priority: 2
            }
        ]
    }),
    LingUnblockCrit: new PassiveAbility({
        ID: 3,
        Image: "Sprites/Assets/Abilities/Ling/icon_ability_Ling_01_2",
        AliasName: "Ling_Ability_Unblock_Crit_Alias",
        AliasDesc: "Ling_Ability_Unblock_Crit_Desc",
    }),
    LingShadowSpit: new PassiveAbility({
        ID: 4,
        Image: "Sprites/Assets/Abilities/Ling/icon_ability_Ling_02",
        AliasName: "Ling_Ability_Shadow_Spit_Alias",
        AliasDesc: "Ling_Ability_Shadow_Spit_Desc",
    }),
    MarcusGlitch: new PassiveAbility({
        ID: 5,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_glitch",
        AliasName: "Marcus_Ability_Glitch_rework_Alias",
        AliasDesc: "Marcus_Ability_Glitch_rework_Desc",
    }),
    MarcusInvulnerability: new PassiveAbility({
        ID: 6,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "Marcus_Ability_Shadow_Unbreak_Alias",
        AliasDesc: "Marcus_Ability_Shadow_Unbreak_Desc",
        TalentComboOverride: [
            {
                Combo: [3],
                Override: { image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_shadow_lord_invul" },
                Priority: 1
            },
            {
                Combo: [4],
                Override: { image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_legion_hero_invul" },
                Priority: 1
            },
        ],
        Locked: true
    }),
    FeldsherSilence: new PassiveAbility({
        ID: 7,
        Image: "Sprites/Assets/Abilities/Feldsher/icon_ability_Feldsher_01",
        AliasName: "Feldsher_Ability_Silence_Alias",
        AliasDesc: "Feldsher_Ability_Silence_Rework_Desc",
        TalentComboOverride: [
            {
                Combo: [106],
                Override: {
                    alias_desc: "Feldsher_Ability_Silence_Upgrade_Desc"
                },
                Priority: 1
            },
        ],
    }),
    FeldsherPushOutOfShadow: new PassiveAbility({
        ID: 8,
        Image: "Sprites/Assets/Abilities/Feldsher/icon_ability_Feldsher_02",
        AliasName: "Feldsher_Ability_Push_Out_Of_Shadow_Alias",
        AliasDesc: "Feldsher_Ability_Push_Out_Of_Shadow_Rework_Desc",
    }),
    IroncladArmorStacks: new PassiveAbility({
        ID: 9,
        Image: "Sprites/Assets/Abilities/Ironclad/icon_ability_Ironclad_01",
        AliasName: "Ironclad_Ability_Armor_Stacks_Alias",
        AliasDesc: "Ironclad_Ability_Armor_Stacks_Desc",
    }),
    IroncladRngResist: new PassiveAbility({
        ID: 10,
        Image: "Sprites/Assets/Abilities/Ironclad/icon_ability_Ironclad_02",
        AliasName: "Ironclad_Ability_Rng_Resist_Alias",
        AliasDesc: "Ironclad_Ability_Rng_Resist_Desc",
    }),
    MonkShadowFlow: new PassiveAbility({
        ID: 11,
        Image: "Sprites/Assets/Abilities/Monk/icon_ability_Monk_01",
        AliasName: "Monk_Ability_Shadow_Flow_Alias",
        AliasDesc: "Monk_Ability_Shadow_Flow_Desc",
    }),
    MonkShadowArmor: new PassiveAbility({
        ID: 12,
        Image: "Sprites/Assets/Abilities/Monk/icon_ability_Monk_02",
        AliasName: "Monk_Ability_Shadow_Armor_Alias",
        AliasDesc: "Monk_Ability_Shadow_Armor_Desc",
    }),
    FireguardAutoSE: new PassiveAbility({
        ID: 13,
        Image: "Sprites/Assets/Abilities/Fireguard/icon_ability_Fireguard_01",
        AliasName: "Fireguard_Ability_Auto_SE_Alias",
        AliasDesc: "Fireguard_Ability_Auto_SE_Desc",
    }),
    FireguardFireBreath: new PassiveAbility({
        ID: 14,
        Image: "Sprites/Assets/Abilities/Fireguard/icon_ability_Fireguard_02",
        AliasName: "Fireguard_Ability_Fire_Breath_Alias",
        AliasDesc: "Fireguard_Ability_Fire_Breath_Desc",
    }),
    FireguardDeathExplosion: new PassiveAbility({
        ID: 15,
        Image: "Sprites/Assets/Abilities/Fireguard/icon_ability_Fireguard_03",
        AliasName: "Fireguard_Ability_Death_Explosion_Alias",
        AliasDesc: "Fireguard_Ability_Death_Explosion_Desc",
    }),
    LiquidatorShadowBurn: new PassiveAbility({
        ID: 16,
        Image: "Sprites/Assets/Abilities/Liquidator/icon_ability_Liquidator_01",
        AliasName: "Liquidator_Ability_Shadow_Burn_Alias",
        AliasDesc: "Liquidator_Ability_Shadow_Burn_Desc",
    }),
    LiquidatorMilitaryTraining: new PassiveAbility({
        ID: 17,
        Image: "Sprites/Assets/Abilities/Liquidator/icon_ability_Liquidator_02",
        AliasName: "Liquidator_Ability_Military_Training_Alias",
        AliasDesc: "Liquidator_Ability_Military_Training_Desc",
        Locked: true
    }),
    YukkaBleeding: new PassiveAbility({
        ID: 18,
        Image: "Sprites/Assets/Abilities/icon_ability_bleeding",
        AliasName: "Yukka_Ability_Bleeding_Alias",
        AliasDesc: "Yukka_Ability_Bleeding_Desc",
    }),
    YukkaHeavyRemoval: new PassiveAbility({
        ID: 19,
        Image: "Sprites/Assets/Abilities/Yukka/icon_ability_Yukka_02",
        AliasName: "Yukka_Ability_Heavy_Removal_Alias",
        AliasDesc: "Yukka_Ability_Heavy_Removal_Desc",
    }),
    YukkaCatRanged: new PassiveAbility({
        ID: 20,
        Image: "Sprites/Assets/Abilities/Yukka/icon_ability_Yukka_03",
        AliasName: "Yukka_Ability_Cat_Ranged_Alias",
        AliasDesc: "Yukka_Ability_Cat_Ranged_Desc",
    }),
    KiboDash: new PassiveAbility({
        ID: 21,
        Image: "Sprites/Assets/Abilities/Kibo/icon_ability_Kibo_01",
        AliasName: "Kibo_Ability_Dash_Alias",
        AliasDesc: "Kibo_Ability_Dash_Desc",
    }),
    JetStacks: new PassiveAbility({
        ID: 22,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_Stacks",
        AliasName: "Jet_Ability_Stacks_Alias",
        AliasDesc: "Jet_Ability_Stacks_Desc",
        TalentComboOverride: [
            {
                Combo: [88],
                Override: { image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_Stacks_Magic_Damage" },
                Priority: 1
            }
        ]
    }),
    EmperorMonster: new PassiveAbility({
        ID: 23,
        Image: "Sprites/Assets/Abilities/Emperor/icon_ability_Emperor_01",
        AliasName: "Emperor_Ability_Monster_Alias",
        AliasDesc: "Emperor_Ability_Monster_Desc",
    }),
    EmperorEmperor: new PassiveAbility({
        ID: 24,
        Image: "Sprites/Assets/Abilities/Emperor/icon_ability_Emperor_04",
        AliasName: "Emperor_Ability_Emperor_Alias",
        AliasDesc: "Emperor_Ability_Emperor_Desc",
    }),
    BulwarkBoneBreak: new PassiveAbility({
        ID: 25,
        Image: "Sprites/Assets/Abilities/Bulwark/icon_ability_Bulwark_01",
        AliasName: "Gladiator_Ability_Bone_Break_Alias",
        AliasDesc: "Gladiator_Ability_Bone_Break_Desc",
    }),
    BulwarkShieldBubble: new PassiveAbility({
        ID: 26,
        Image: "Sprites/Assets/Abilities/Bulwark/icon_ability_Bulwark_02",
        AliasName: "Gladiator_Ability_Shield_Bubble_Alias",
        AliasDesc: "Gladiator_Ability_Shield_Bubble_Desc",
    }),
    KiboShadowEnergy: new PassiveAbility({
        ID: 27,
        Image: "Sprites/Assets/Abilities/Kibo/icon_ability_Kibo_02",
        AliasName: "Kibo_Ability_ShadowEnergy_Alias",
        AliasDesc: "Kibo_Ability_ShadowEnergy_Desc",
    }),
    HelgaLightFly: new PassiveAbility({
        ID: 28,
        Image: "Sprites/Assets/Abilities/Helga/icon_ability_Helga_03_light_power",
        AliasName: "Helga_Ability_Light_Alias",
        AliasDesc: "Helga_Ability_Light_Desc",
    }),
    HongJooRanged: new PassiveAbility({
        ID: 28,
        Image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_1",
        AliasName: "HongJoo_Ability_Ranged_Short_Alias",
        AliasDesc: "HongJoo_Ability_Ranged_Short_Desc",
        TalentComboOverride: [
            {
                Combo: [140],
                Override: {
                    image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_1",
                    alias_name: "HongJoo_Ability_Ranged_Short_Alias",
                    alias_desc: "HongJoo_Ability_Ranged_Short_Desc"
                },
                Priority: 1
            },
            {
                Combo: [141],
                Override: {
                    image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_2",
                    alias_name: "HongJoo_Ability_Ranged_Long_Alias",
                    alias_desc: "HongJoo_Ability_Ranged_Long_Desc"
                },
                Priority: 2
            }
        ],
        Locked: true
    }),
    HongJooTriumph: new PassiveAbility({
        ID: 29,
        Image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_3",
        AliasName: "HongJoo_Ability_Triumph_Alias",
        AliasDesc: "HongJoo_Ability_Triumph_Desc",
    }),
    SargeShadowInvulnerability: new PassiveAbility({
        ID: 30,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Shadow_Invulnerability",
        AliasName: "Sarge_Ability_Shadow_Invulnerability_Alias",
        AliasDesc: "Sarge_Ability_Shadow_Invulnerability_New_Desc",
    }),
    SargeFloorfall: new PassiveAbility({
        ID: 31,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Floorfall",
        AliasName: "Sarge_Ability_Floorfall_Alias",
        AliasDesc: "Sarge_Ability_Floorfall_Desc",
        TalentComboOverride: [
            {
                Combo: [150],
                Override: { image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Floorfall" },
                Priority: 1
            },
            {
                Combo: [151],
                Override: { image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Floorfall_Upgrade" },
                Priority: 2
            }
        ]
    }),
    SargeSpecialMoves: new PassiveAbility({
        ID: 32,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Special_Moves",
        AliasName: "Sarge_Ability_Special_Moves_Alias",
        AliasDesc: "Sarge_Ability_Special_Moves_Desc",
    }),
    Midnight_Dodge: new PassiveAbility({
        ID: 33,
        Image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_02",
        AliasName: "Midnight_Ability_Dodge_Alias",
        AliasDesc: "Midnight_Ability_Dodge_Desc",
    }),
    Midnight_Phase: new PassiveAbility({
        ID: 34,
        Image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_01",
        AliasName: "Midnight_Ability_Phase_Alias",
        AliasDesc: "Midnight_Ability_Phase_Desc",
        TalentComboOverride: [
            {
                Combo: [172],
                Override: { image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_01" },
                Priority: 1
            },
            {
                Combo: [175],
                Override: { image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_t_8_2" },
                Priority: 2
            }
        ]
    }),
    Midnight_SA: new PassiveAbility({
        ID: 35,
        Image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_03",
        AliasName: "Midnight_Ability_SA_Alias",
        AliasDesc: "Midnight_Ability_SA_Desc",
    }),
    Lynx_Curse: new PassiveAbility({
        ID: 36,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Time_Bomb",
        AliasName: "LYNX_CURSE_ALIAS",
        AliasDesc: "LYNX_CURSE_DESC",
    }),
    Lynx_Invisible: new PassiveAbility({
        ID: 37,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Invisibility",
        AliasName: "LYNX_INVISIBLE_ALIAS",
        AliasDesc: "LYNX_INVISIBLE_DESC",
        TalentComboOverride: [
            {
                Combo: [180],
                Override: { image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_t_Invisibility_Stronger" },
                Priority: 1
            },
            {
                Combo: [181],
                Override: { image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Invisibility" },
                Priority: 1
            }
        ],
    }),
    Lynx_Claws: new PassiveAbility({
        ID: 38,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_t_Execution",
        AliasName: "LYNX_CLAWS_ALIAS",
        AliasDesc: "LYNX_CLAWS_DESC",
    }),
    MonkeyKing_Special: new PassiveAbility({
        ID: 39,
        Image: "Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Special",
        AliasName: "MONKEY_KING_SPECIAL_ALIAS",
        AliasDesc: "MONKEY_KING_SPECIAL_DESC",
    }),
    MonkeyKing_Rage: new PassiveAbility({
        ID: 40,
        Image: "Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Rage",
        AliasName: "MONKEY_KING_RAGE_ALIAS",
        AliasDesc: "MONKEY_KING_RAGE_DESC",
    }),
    Viper_Charge: new PassiveAbility({
        ID: 64,
        Image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_charge",
        AliasName: "VIPER_CHARGE_ALIAS",
        AliasDesc: "VIPER_CHARGE_DESC",
        TalentComboOverride: [
            {
                Combo: [208],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_charge" },
                Priority: 1
            },
            {
                Combo: [209],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_t_charge_cd_immediatly" },
                Priority: 2
            },
        ],
    }),
    Viper_Toxin: new PassiveAbility({
        ID: 65,
        Image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_toxin_lobby",
        AliasName: "VIPER_TOXIN_ALIAS",
        AliasDesc: "VIPER_TOXIN_DESC",
        TalentComboOverride: [
            {
                Combo: [202],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_t_toxin_longer_lobby" },
                Priority: 1
            },
            {
                Combo: [203],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_toxin_lobby" },
                Priority: 2
            },
        ],
    }),
    Viper_Smoke: new PassiveAbility({
        ID: 66,
        Image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_t_shadow_smoke",
        AliasName: "VIPER_SMOKE_ALIAS",
        AliasDesc: "VIPER_SMOKE_DESC",
        Locked: true,
        TalentComboOverride: [
            {
                Combo: [204],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_t_shadow_smoke" },
                Priority: 1
            },
            {
                Combo: [205],
                Override: { image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_t_toxin_smoke" },
                Priority: 2
            },
        ],
    }),
    Legion_King_Sacrifice: new PassiveAbility({
        ID: 41,
        Image: "Sprites/Assets/Abilities/Legion_King/icon_ability_Legion_King_Sacrifice",
        AliasName: "LEGION_KING_SACRIFICE_ALIAS",
        AliasDesc: "LEGION_KING_SACRIFICE_DESC",
    }),
    Legion_King_Shadow_Form: new PassiveAbility({
        ID: 42,
        Image: "Sprites/Assets/Abilities/Legion_King/icon_ability_Legion_King_Shadow_Form",
        AliasName: "LEGION_KING_SHADOW_FORM_ALIAS",
        AliasDesc: "LEGION_KING_SHADOW_FORM_DESC",
    }),
    Legion_King_Second_Life: new PassiveAbility({
        ID: 43,
        Image: "Sprites/Assets/Abilities/Legion_King/icon_ability_Legion_King_Second_Life",
        AliasName: "LEGION_KING_SECOND_LIFE_ALIAS",
        AliasDesc: "LEGION_KING_SECOND_LIFE_DESC",
    }),
    Butcher_Hook: new PassiveAbility({
        ID: 44,
        Image: "Sprites/Assets/Abilities/Butcher/icon_ability_Butcher_Hook",
        AliasName: "BUTCHER_HOOK_ALIAS",
        AliasDesc: "BUTCHER_HOOK_DESC",
    }),
    Butcher_Walls: new PassiveAbility({
        ID: 45,
        Image: "Sprites/Assets/Abilities/Butcher/icon_ability_Butcher_Walls",
        AliasName: "BUTCHER_WALLS_ALIAS",
        AliasDesc: "BUTCHER_WALLS_NEW_DESC",
        TalentComboOverride: [
            {
                Combo: [224],
                Override: { image: "Sprites/Assets/Abilities/Butcher/icon_ability_Butcher_Walls_Damage_Inverted" },
                Priority: 1
            },
            {
                Combo: [225],
                Override: { image: "Sprites/Assets/Abilities/Butcher/icon_ability_Butcher_Walls" },
                Priority: 1
            }
        ],
    }),
    Itu_Slowmotion: new PassiveAbility({
        ID: 46,
        Image: "Sprites/Assets/Abilities/Itu/icon_ability_Itu_Slowmotion",
        AliasName: "ITU_SLOWMOTION_ALIAS",
        AliasDesc: "ITU_SLOWMOTION_DESC",
    }),
    Itu_Shadow_Charge: new PassiveAbility({
        ID: 47,
        Image: "Sprites/Assets/Abilities/Itu/icon_ability_Itu_Shadow_Charge",
        AliasName: "ITU_SHADOW_CHARGE_ALIAS",
        AliasDesc: "ITU_SHADOW_CHARGE_DESC",
    }),
    Yunlin_Shadow_Parts: new PassiveAbility({
        ID: 48,
        Image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Shadow_Parts",
        AliasName: "YUNLIN_SHADOW_PARTS_ALIAS",
        AliasDesc: "YUNLIN_SHADOW_PARTS_DESC",
        TalentComboOverride: [
            {
                Combo: [248],
                Override: { image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Shadow_Parts" },
                Priority: 1
            },
            {
                Combo: [249],
                Override: { image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Shadow_Parts_More" },
                Priority: 1
            }
        ],
    }),
    Yunlin_Flute: new PassiveAbility({
        ID: 49,
        Image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Flute",
        AliasName: "YUNLIN_FLUTE_ALIAS",
        AliasDesc: "YUNLIN_FLUTE_DESC",
    }),
    Yunlin_Bell: new PassiveAbility({
        ID: 50,
        Image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_Bell",
        AliasName: "YUNLIN_BELL_ALIAS",
        AliasDesc: "YUNLIN_BELL_DESC",
    }),
    Xiang_Tzu_Rage_Energy: new PassiveAbility({
        ID: 51,
        Image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Energy",
        AliasName: "XIANG_TZU_RAGE_ENERGY_ALIAS",
        AliasDesc: "XIANG_TZU_RAGE_ENERGY_DESC",
    }),
    Xiang_Tzu_Rage_Form: new PassiveAbility({
        ID: 52,
        Image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Form",
        AliasName: "XIANG_TZU_RAGE_FORM_ALIAS",
        AliasDesc: "XIANG_TZU_RAGE_FORM_DESC",
        TalentComboOverride: [
            {
                Combo: [256],
                Override: { image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Upgrade" },
                Priority: 1
            },
            {
                Combo: [257],
                Override: { image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Rage_Form" },
                Priority: 1
            }
        ],
    }),
    Xiang_Tzu_Bloodborne: new PassiveAbility({
        ID: 53,
        Image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Bloodborne",
        AliasName: "XIANG_TZU_BLOODBORNE_ALIAS",
        AliasDesc: "XIANG_TZU_BLOODBORNE_DESC",
        TalentComboOverride: [
            {
                Combo: [258],
                Override: { image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Bloodborne" },
                Priority: 1
            },
            {
                Combo: [259],
                Override: { image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Bloodborne_Credit" },
                Priority: 1
            }
        ],
    }),
    June_Corruption_Energy: new PassiveAbility({
        ID: 54,
        Image: "Sprites/Assets/Abilities/June/icon_ability_June_Corruption_Energy",
        AliasName: "JUNE_CORRUPTION_ENERGY_ALIAS",
        AliasDesc: "JUNE_CORRUPTION_ENERGY_DESC",
    }),
    June_Dark_Form: new PassiveAbility({
        ID: 55,
        Image: "Sprites/Assets/Abilities/June/icon_ability_June_Dark_Form",
        AliasName: "JUNE_DARK_FORM_ALIAS",
        AliasDesc: "JUNE_DARK_FORM_DESC",
    }),
    June_Light_Form: new PassiveAbility({
        ID: 56,
        Image: "Sprites/Assets/Abilities/June/icon_ability_June_Light_Form",
        AliasName: "JUNE_LIGHT_FORM_ALIAS",
        AliasDesc: "JUNE_LIGHT_FORM_DESC",
    }),
    Gideon_Shot_Stance: new PassiveAbility({
        ID: 57,
        Image: "Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_shot_stance",
        AliasName: "GIDEON_SHOT_STANCE_ALIAS",
        AliasDesc: "GIDEON_SHOT_STANCE_DESC",
    }),
    Gideon_Mark: new PassiveAbility({
        ID: 58,
        Image: "Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_mark",
        AliasName: "GIDEON_MARK_ALIAS",
        AliasDesc: "GIDEON_MARK_DESC",
    }),
    Gideon_Shadow_Protection: new PassiveAbility({
        ID: 59,
        Image: "Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_shadow_protection",
        AliasName: "GIDEON_SHADOW_PROTECTION_ALIAS",
        AliasDesc: "GIDEON_SHADOW_PROTECTION_DESC",
        TalentComboOverride: [
            {
                Combo: [272],
                Override: { image: "Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_shadow_protection" },
                Priority: 1
            },
            {
                Combo: [273],
                Override: { image: "Sprites/Assets/Abilities/Gideon/icon_ability_Gideon_protection_longer" },
                Priority: 1
            }
        ]
    }),
    Widow_Corruption: new PassiveAbility({
        ID: 60,
        Image: "Sprites/Assets/Abilities/Widow/icon_ability_Widow_corruption",
        AliasName: "WIDOW_CORRUPTION_ALIAS",
        AliasDesc: "WIDOW_CORRUPTION_DESC",
    }),
    Widow_Teleport: new PassiveAbility({
        ID: 61,
        Image: "Sprites/Assets/Abilities/Widow/icon_ability_Widow_teleport",
        AliasName: "WIDOW_TP_ALIAS",
        AliasDesc: "WIDOW_TP_DESC",
    }),
    Widow_Intuition: new PassiveAbility({
        ID: 62,
        Image: "Sprites/Assets/Abilities/Widow/icon_ability_Widow_intuition",
        AliasName: "WIDOW_INTUITION_ALIAS",
        AliasDesc: "WIDOW_INTUITION_DESC",
    }),
    Raikichi_Runes: new PassiveAbility({
        ID: 63,
        Image: "Sprites/Assets/Abilities/Raikichi/icon_ability_Raikichi_runes",
        AliasName: "RAIKICHI_RUNES_ALIAS",
        AliasDesc: "RAIKICHI_RUNES_DESC",
    }),
    Raikichi_Abilities: new PassiveAbility({
        ID: 64,
        Image: "Sprites/Assets/Abilities/Raikichi/icon_ability_Raikichi_abilities",
        AliasName: "RAIKICHI_ABILITIES_ALIAS",
        AliasDesc: "RAIKICHI_ABILITIES_DESC",
    }),
    Raikichi_Overcharge: new PassiveAbility({
        ID: 65,
        Image: "Sprites/Assets/Abilities/Raikichi/icon_ability_Raikichi_overcharge",
        AliasName: "RAIKICHI_OVERCHARGE_ALIAS",
        AliasDesc: "RAIKICHI_OVERCHARGE_DESC",
    }),
    Nonna_Ability_Wolf: new PassiveAbility({
        ID: 66,
        Image: "Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_wolf",
        AliasName: "Nonna_Ability_Wolf_Alias",
        AliasDesc: "Nonna_Ability_Wolf_Desc",
    }),
    Nonna_Ability_Ranged: new PassiveAbility({
        ID: 67,
        Image: "Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_owl",
        AliasName: "Nonna_Ability_Ranged_Alias",
        AliasDesc: "Nonna_Ability_Ranged_Desc",
    }),
    Nonna_Ability_Bear: new PassiveAbility({
        ID: 68,
        Image: "Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_bear",
        AliasName: "Nonna_Ability_Bear_Alias",
        AliasDesc: "Nonna_Ability_Bear_Desc",
        TalentComboOverride: [
            {
                Combo: [304],
                Override: { image: "Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_bear" },
                Priority: 1
            },
            {
                Combo: [305],
                Override: { image: "Sprites/Assets/Abilities/Nonna/icon_ability_Nonna_bear_damage" },
                Priority: 1
            }
        ]
    }),
    Shogun_Ability_Shadow_Form: new PassiveAbility({
        ID: 69,
        Image: "Sprites/Assets/Abilities/Shogun/icon_ability_Shogun_shadow_form",
        AliasName: "Shogun_Ability_Shadow_Form_Alias",
        AliasDesc: "Shogun_Ability_Shadow_Form_Desc",
    }),
    Shogun_Ability_Demon_Form: new PassiveAbility({
        ID: 70,
        Image: "Sprites/Assets/Abilities/Shogun/icon_ability_Shogun_demon_form",
        AliasName: "Shogun_Ability_Demon_Form_Alias",
        AliasDesc: "Shogun_Ability_Demon_Form_Desc",
    }),
    Shogun_Ability_Minion: new PassiveAbility({
        ID: 71,
        Image: "Sprites/Assets/Abilities/Shogun/icon_ability_Shogun_minion",
        AliasName: "Shogun_Ability_Minion_Alias",
        AliasDesc: "Shogun_Ability_Minion_Desc",
    }),
    wpn_Bulwark_Receive_Lower_Damage_In_Block: new PassiveAbility({
        ID: 41,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Bulwark_R_Golden_Rec_Gray",
        AliasDesc: "wpn_Bulwark_Receive_Lower_Damage_In_Block",
    }),
    wpn_Jet_Less_Ranged_Cooldown: new PassiveAbility({
        ID: 42,
        Image: "Sprites/Assets/Fight/icon_ranged_needls_x3",
        AliasName: "wpn_Jet_R_Golden_Rec_Black",
        AliasDesc: "wpn_Jet_Less_Ranged_Cooldown",
    }),
    wpn_Emperor_More_Vampire_Heal: new PassiveAbility({
        ID: 43,
        Image: "Sprites/Assets/Abilities/icon_ability_vampirism",
        AliasName: "wpn_Emperor_R_Default_Rec_Red",
        AliasDesc: "wpn_Emperor_More_Vampire_Heal",
    }),
    wpn_Kibo_More_Crit_Chance: new PassiveAbility({
        ID: 44,
        Image: "Sprites/Assets/Abilities/icon_ability_critical",
        AliasName: "wpn_Kibo_R_Gray_Rec_Purple",
        AliasDesc: "wpn_Kibo_More_Crit_Chance",
    }),
    wpn_Kibo_Vampire_In_Shadow_Moves: new PassiveAbility({
        ID: 45,
        Image: "Sprites/PreviewImages/Weapons/Kibo/wpn_Kibo_Vampire_In_Shadow_Moves",
        AliasName: "wpn_Kibo_E_RedVampire",
        AliasDesc: "wpn_Kibo_Vampire_In_Shadow_Moves",
    }),
    wpn_Liquidator_More_Mana_Steal: new PassiveAbility({
        ID: 46,
        Image: "Sprites/Assets/Abilities/Liquidator/icon_ability_Liquidator_01",
        AliasName: "wpn_Liquidator_R_Gold_Rec_Bronze",
        AliasDesc: "wpn_Liquidator_More_Mana_Steal",
    }),
    wpn_Liquidator_More_Damage_To_Shadowless: new PassiveAbility({
        ID: 47,
        Image: "Sprites/PreviewImages/Weapons/Liquidator/wpn_Liquidator_More_Damage_To_Shadowless",
        AliasName: "wpn_Liquidator_E_Obsidians",
        AliasDesc: "wpn_Liquidator_More_Damage_To_Shadowless",
    }),
    wpn_Ling_More_Damage_From_Heavy: new PassiveAbility({
        ID: 48,
        Image: "Sprites/Assets/Abilities/icon_ability_DamageBonus",
        AliasName: "wpn_Ling_R_RedBlade",
        AliasDesc: "wpn_Ling_More_Damage_From_Heavy",
    }),
    wpn_Monkey_King_Break_More_Damage: new PassiveAbility({
        ID: 49,
        Image: "Sprites/Assets/Abilities/Monkey_King/icon_ability_Monkey_King_Unblockable",
        AliasName: "wpn_Monkey_King_R_Default_Rec_Blue",
        AliasDesc: "wpn_Monkey_King_Break_More_Damage",
    }),
    wpn_Marcus_More_SE_From_My_Hits: new PassiveAbility({
        ID: 50,
        Image: "Sprites/Assets/Abilities/icon_attribute_magic",
        AliasName: "wpn_Marcus_R_Lord_Rec_Brown",
        AliasDesc: "wpn_Marcus_More_SE_From_My_Hits",
    }),
    wpn_Marcus_Burn_On_Heavy: new PassiveAbility({
        ID: 51,
        Image: "Sprites/PreviewImages/Weapons/Marcus/wpn_Marcus_Burn_On_Heavy",
        AliasName: "wpn_Marcus_E_Lava",
        AliasDesc: "wpn_Marcus_Burn_On_Heavy",
    }),
    wpn_Midnight_More_SE_From_Dodge: new PassiveAbility({
        ID: 52,
        Image: "Sprites/Assets/Abilities/Midnight/icon_ability_Midnight_02",
        AliasName: "wpn_Midnight_R_Default_Rec_GoldenDark",
        AliasDesc: "wpn_Midnight_More_SE_From_Dodge",
    }),
    wpn_Monk_Less_Ranged_Cooldown: new PassiveAbility({
        ID: 53,
        Image: "Sprites/Assets/Fight/icon_ranged_Monk_bow_shadow",
        AliasName: "wpn_Monk_R_NeatBlade",
        AliasDesc: "wpn_Monk_Less_Ranged_Cooldown",
    }),
    wpn_Monk_More_Guandao_MagicDamage_In_Shadow: new PassiveAbility({
        ID: 54,
        Image: "Sprites/Assets/Abilities/Monk/wpn_Monk_More_Guandao_MagicDamage_In_Shadow",
        AliasName: "wpn_Monk_E_Druid",
        AliasDesc: "wpn_Monk_E_Druid_Desc",
    }),
    wpn_Lynx_More_Damage_From_Invisible: new PassiveAbility({
        ID: 55,
        Image: "Sprites/Assets/Fight/icon_ranged_bomb",
        AliasName: "wpn_Lynx_R_Rich",
        AliasDesc: "wpn_Lynx_More_Damage_From_Invisible",
    }),
    wpn_Sarge_More_Crit_Damage: new PassiveAbility({
        ID: 56,
        Image: "Sprites/Assets/Abilities/icon_ability_critical",
        AliasName: "wpn_Sarge_R_Patterns",
        AliasDesc: "wpn_Sarge_More_Crit_Damage",
    }),
    wpn_Fireguard_Longer_Burn: new PassiveAbility({
        ID: 57,
        Image: "Sprites/Assets/Abilities/Fireguard/icon_ability_Fireguard_02",
        AliasName: "wpn_Fireguard_R_Simplified",
        AliasDesc: "wpn_Fireguard_Longer_Burn",
    }),
    wpn_Feldsher_More_SE_From_My_Hits: new PassiveAbility({
        ID: 58,
        Image: "Sprites/Assets/Abilities/icon_attribute_magic",
        AliasName: "wpn_Feldsher_R_SpicyBlade",
        AliasDesc: "wpn_Feldsher_More_SE_From_My_Hits",
    }),
    wpn_Helga_More_Heal: new PassiveAbility({
        ID: 59,
        Image: "Sprites/Assets/Abilities/icon_ability_healing",
        AliasName: "wpn_Helga_R_Paladin_Rec_Blue",
        AliasDesc: "wpn_Helga_More_Heal",
    }),
    wpn_HongJoo_More_Triumph_Damage: new PassiveAbility({
        ID: 60,
        Image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_3",
        AliasName: "wpn_HongJoo_R_Equilibrist_Rec_Gold",
        AliasDesc: "wpn_HongJoo_More_Triumph_Damage",
    }),
    wpn_Ironclad_Receive_Less_Damage_While_Unbreak: new PassiveAbility({
        ID: 61,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Ironclad_R_Default_Rec_Chess",
        AliasDesc: "wpn_Ironclad_Receive_Less_Damage_While_Unbreak",
    }),
    wpn_Yukka_Better_Bleeding_Effect: new PassiveAbility({
        ID: 62,
        Image: "Sprites/Assets/Abilities/icon_ability_bleeding",
        AliasName: "wpn_Yukka_R_Monograms",
        AliasDesc: "wpn_Yukka_Better_Bleeding_Effect",
    }),
    wpn_Marcus_E_Knight: new PassiveAbility({
        ID: 63,
        Image: "Sprites/PreviewImages/Weapons/Marcus/wpn_Marcus_Short_Bubble_After_Unbreak_Hit",
        AliasName: "wpn_Marcus_E_Knight_name",
        AliasDesc: "wpn_Marcus_E_Knight_desc",
    }),
    wpn_Fireguard_Mana_On_Kama_Hits: new PassiveAbility({
        ID: 64,
        Image: "Sprites/PreviewImages/Weapons/Fireguard/wpn_Fireguard_Mana_On_Kama_Hits",
        AliasName: "wpn_Fireguard_E_Bones",
        AliasDesc: "wpn_Fireguard_Mana_On_Kama_Hits",
    }),
    wpn_Helga_Increase_Physical_Damage_On_Dash: new PassiveAbility({
        ID: 65,
        Image: "Sprites/PreviewImages/Weapons/Helga/wpn_Helga_Increase_Physical_Damage_On_Dash",
        AliasName: "wpn_Helga_E_White_Star",
        AliasDesc: "wpn_Helga_Increase_Physical_Damage_On_Dash",
    }),
    wpn_Feldsher_Heal_From_Shadow_Knockout: new PassiveAbility({
        ID: 66,
        Image: "Sprites/PreviewImages/Weapons/Feldsher/wpn_Feldsher_Heal_From_Shadow_Knockout",
        AliasName: "wpn_Feldsher_E_RedVampire",
        AliasDesc: "wpn_Feldsher_Heal_From_Shadow_Knockout",
    }),
    wpn_HongJoo_Triumph_Sets_On_Fire: new PassiveAbility({
        ID: 67,
        Image: "Sprites/PreviewImages/Weapons/HongJoo/wpn_HongJoo_Triumph_Sets_On_Fire",
        AliasName: "wpn_HongJoo_E_FireShow",
        AliasDesc: "wpn_HongJoo_Triumph_Sets_On_Fire",
    }),
    wpn_Monkey_King_Pillar_Grants_Invincibility: new PassiveAbility({
        ID: 68,
        Image: "Sprites/PreviewImages/Weapons/Monkey_King/wpn_Monkey_King_Pillar_Grants_Invincibility",
        AliasName: "wpn_Monkey_King_E_Nephritis",
        AliasDesc: "wpn_Monkey_King_Pillar_Grants_Invincibility",
    }),
    wpn_Viper_Chargebite_Damage_Increased: new PassiveAbility({
        ID: 69,
        Image: "Sprites/Assets/Abilities/Viper/icon_ability_Viper_stack",
        AliasName: "wpn_Viper_R_base_Rec_Snake",
        AliasDesc: "wpn_Viper_Chargebite_Damage_Increased",
    }),
    wpn_Bulwark_More_Bone_Breaker_Damage: new PassiveAbility({
        ID: 70,
        Image: "Sprites/Assets/Abilities/Bulwark/icon_ability_Bulwark_01",
        AliasName: "wpn_Bulwark_R_base_Rec_Black",
        AliasDesc: "wpn_Bulwark_More_Bone_Breaker_Damage",
    }),
    wpn_Viper_Less_Ranged_Cooldown: new PassiveAbility({
        ID: 71,
        Image: "Sprites/Assets/Abilities/icon_ability_gear",
        AliasName: "wpn_Viper_R_base_Rec_Purple",
        AliasDesc: "wpn_Viper_Less_Ranged_Cooldown",
    }),
    wpn_Emperor_More_HP_On_Monster_Form: new PassiveAbility({
        ID: 72,
        Image: "Sprites/Assets/Abilities/icon_ability_healing",
        AliasName: "wpn_Emperor_R_base_Rec_Silver",
        AliasDesc: "wpn_Emperor_More_HP_On_Monster_Form",
    }),
    wpn_Kibo_Deal_More_Damage_In_Block: new PassiveAbility({
        ID: 73,
        Image: "Sprites/Assets/Abilities/icon_attribute_attack",
        AliasName: "wpn_Kibo_R_base_Rec_Black",
        AliasDesc: "wpn_Kibo_Deal_More_Damage_In_Block",
    }),
    wpn_Liquidator_More_Heavy_Swords_Damage: new PassiveAbility({
        ID: 74,
        Image: "Sprites/Assets/Abilities/icon_attribute_attack",
        AliasName: "wpn_Liquidator_R_base_Rec_Red",
        AliasDesc: "wpn_Liquidator_More_Heavy_Swords_Damage",
    }),
    wpn_Ling_More_SE_From_Everything: new PassiveAbility({
        ID: 74,
        Image: "Sprites/Assets/Abilities/icon_ability_SE_accumulation",
        AliasName: "wpn_Ling_R_base_Rec_Dark",
        AliasDesc: "wpn_Ling_More_SE_From_Everything",
    }),
    wpn_Monkey_King_More_SE_From_Everything: new PassiveAbility({
        ID: 75,
        Image: "Sprites/Assets/Icons/icon_MONKEY",
        AliasName: "wpn_Monkey_King_R_base_Rec_Purple",
        AliasDesc: "wpn_Monkey_King_More_SE_From_Everything",
    }),
    wpn_Marcus_More_Damage_From_Glitch_Attacks: new PassiveAbility({
        ID: 76,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_glitch",
        AliasName: "wpn_Marcus_R_base_Rec_Black",
        AliasDesc: "wpn_Marcus_More_Damage_From_Glitch_Attacks",
    }),
    wpn_Midnight_More_Crit_Chance: new PassiveAbility({
        ID: 77,
        Image: "Sprites/Assets/Abilities/icon_ability_critical",
        AliasName: "wpn_Midnight_R_base_Rec_Red",
        AliasDesc: "wpn_Midnight_More_Crit_Chance",
    }),
    wpn_Monk_More_SF_Duration: new PassiveAbility({
        ID: 78,
        Image: "Sprites/Assets/Abilities/icon_ability_SE_accumulation",
        AliasName: "wpn_Monk_R_NeatBlade_Rec_Red",
        AliasDesc: "wpn_Monk_More_SF_Duration",
    }),
    wpn_Lynx_More_Damage_From_Mark_Explosion: new PassiveAbility({
        ID: 79,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_Lynx_Time_Bomb",
        AliasName: "wpn_Lynx_R_base_Black",
        AliasDesc: "wpn_Lynx_More_Damage_From_Mark_Explosion",
    }),
    wpn_Sarge_More_Fall_Damage: new PassiveAbility({
        ID: 80,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Floorfall_Upgrade",
        AliasName: "wpn_Sarge_R_Patterns_Rec_Red",
        AliasDesc: "wpn_Sarge_More_Fall_Damage",
    }),
    wpn_Fireguard_More_Crit_Chance: new PassiveAbility({
        ID: 81,
        Image: "Sprites/Assets/Abilities/icon_ability_critical",
        AliasName: "wpn_Fireguard_R_Yellow",
        AliasDesc: "wpn_Fireguard_More_Crit_Chance",
    }),
    wpn_Feldsher_Deal_More_Damage_In_Block: new PassiveAbility({
        ID: 82,
        Image: "Sprites/Assets/Abilities/icon_attribute_attack",
        AliasName: "wpn_Feldsher_R_base_Rec_Elegant",
        AliasDesc: "wpn_Feldsher_Deal_More_Damage_In_Block",
    }),
    wpn_Helga_Receive_Lower_Damage_In_Block: new PassiveAbility({
        ID: 83,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Helga_R_December",
        AliasDesc: "wpn_Helga_Receive_Lower_Damage_In_Block",
    }),
    wpn_HongJoo_More_Ranged_Damage: new PassiveAbility({
        ID: 84,
        Image: "Sprites/Assets/Abilities/HongJoo/icon_ability_HongJoo_02_1",
        AliasName: "wpn_HongJoo_R_Red",
        AliasDesc: "wpn_HongJoo_More_Ranged_Damage",
    }),
    wpn_Ironclad_More_SE_From_Everything: new PassiveAbility({
        ID: 85,
        Image: "Sprites/Assets/Abilities/icon_ability_SE_accumulation",
        AliasName: "wpn_Ironclad_R_Pattern",
        AliasDesc: "wpn_Ironclad_More_SE_From_Everything",
    }),
    wpn_Yukka_More_Damage_From_Guillotine: new PassiveAbility({
        ID: 86,
        Image: "Sprites/Assets/Abilities/Yukka/icon_ability_Yukka_02",
        AliasName: "wpn_Yukka_R_Monograms_Rec_Antique",
        AliasDesc: "wpn_Yukka_More_Damage_From_Guillotine",
    }),
    wpn_Jet_More_Damage_From_Stack: new PassiveAbility({
        ID: 87,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_Stacks",
        AliasName: "wpn_Jet_R_base_Rec_Brown",
        AliasDesc: "wpn_Jet_More_Damage_From_Stack",
    }),
    Shadowless: new PassiveAbility({
        ID: 100,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_02",
        AliasName: "Shadowless_Ability_Alias",
        AliasDesc: "Shadowless_Ability_Desc",
    }),
    wpn_Sarge_E_Explosion: new PassiveAbility({
        ID: 70,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Explosion",
        AliasName: "wpn_Sarge_E_Burn",
        AliasDesc: "wpn_Sarge_Explosion",
    }),
    wpn_Midnight_Parry_Freeze: new PassiveAbility({
        ID: 71,
        Image: "Sprites/Assets/Abilities/Midnight/wpn_Midnight_E_Cold",
        AliasName: "wpn_Midnight_E_Cold",
        AliasDesc: "wpn_Midnight_Freeze",
    }),
    wpn_Long_Claws_At_Low_HP: new PassiveAbility({
        ID: 88,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_lynx_low_hp_claws",
        AliasName: "wpn_Lynx_E_Legacy",
        AliasDesc: "wpn_Long_Claws_At_Low_HP",
    }),
    wpn_Yukka_Wind_Dash: new PassiveAbility({
        ID: 89,
        Image: "Sprites/Assets/Abilities/Yukka/icon_ability_Yukka_Wind_Dash",
        AliasName: "wpn_Yukka_E_Wind",
        AliasDesc: "wpn_Yukka_Wind_Dash",
    }),
    wpn_Emperor_Gloves_Protection: new PassiveAbility({
        ID: 89,
        Image: "Sprites/Assets/Abilities/wpn_Emperor_Gloves_Protection",
        AliasName: "wpn_Emperor_E_Stone_Gloves",
        AliasDesc: "wpn_Emperor_Gloves_Protection",
    }),
    wpn_Viper_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 90,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Viper_R_base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Jet_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 91,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Jet_R_Golden_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Emperor_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 92,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Emperor_R_base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Kibo_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 93,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Kibo_R_Gray_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Liquidator_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 94,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Liquidator_R_Gold_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Lynx_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 95,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Lynx_R_base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Marcus_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 96,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Marcus_R_Lord_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Monk_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 97,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Monk_R_base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Monkey_King_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 98,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Monkey_King_R_base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Bulwark_Pike_Returning: new PassiveAbility({
        ID: 99,
        Image: "Sprites/Assets/Abilities/Bulwark/icon_ability_Bulwark_Pike",
        AliasName: "wpn_Bulwark_E_Pike",
        AliasDesc: "wpn_Bulwark_E_Pike_desc",
    }),
    wpn_Ling_R_Samurai_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 101,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Ling_R_Samurai_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Ironclad_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 102,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Ironclad_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Fireguard_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 103,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Fireguard_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Helga_R_Paladin_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 104,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Helga_R_Paladin_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Feldsher_R_SpicyBlade_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 105,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Feldsher_R_SpicyBlade_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Yukka_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 106,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Yukka_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Bulwark_R_Gold_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 107,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Bulwark_R_Gold_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_HongJoo_R_Equilibrist_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 108,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_HongJoo_R_Equilibrist_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Sarge_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 109,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Sarge_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Midnight_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 110,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Midnight_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_LegionKing_R_base_Rec_Summer_22_Mana_Start: new PassiveAbility({
        ID: 111,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_LegionKing_R_base_Rec_Summer_22",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Ling_Shadow_Dissolve: new PassiveAbility({
        ID: 112,
        Image: "Sprites/Assets/Abilities/Ling/wpn_Ling_E_Shadow_Edge",
        AliasName: "wpn_Ling_E_Shadow_Edge",
        AliasDesc: "wpn_Ling_Shadow_Diffuse",
    }),
    wpn_Jet_E_Prism: new PassiveAbility({
        ID: 113,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_wpn_Jet_E_Prism",
        AliasName: "wpn_Jet_E_Prism",
        AliasDesc: "wpn_Harmony_Defence",
    }),
    wpn_Viper_R_base_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 114,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Viper_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Jet_R_base_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 115,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Jet_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Emperor_R_base_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 116,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Emperor_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Kibo_R_Gray_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 117,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Kibo_R_Gray_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Legion_King_R_base_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 118,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Legion_King_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Liquidator_R_Gold_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 119,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Liquidator_R_Gold_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Marcus_R_Lord_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 120,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Marcus_R_Lord_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Monk_R_NeatBlade_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 121,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Monk_R_NeatBlade_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Lynx_R_base_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 122,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Lynx_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Feldsher_R_SpicyBlade_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 123,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Feldsher_R_SpicyBlade_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Butcher_R_Default_Rec_Mystic_Heal_On_Enter_SF: new PassiveAbility({
        ID: 124,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Butcher_R_Default_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Ironclad_E_Puffer: new PassiveAbility({
        ID: 125,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Ironclad_E_Puffer",
        AliasName: "wpn_Ironclad_E_Puffer",
        AliasDesc: "wpn_Ironclad_E_Puffer_Desc",
    }),
    wpn_Legion_King_E_Witchblade: new PassiveAbility({
        ID: 126,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Legion_King_E_Witchblade",
        AliasName: "wpn_Legion_King_E_Witchblade",
        AliasDesc: "wpn_Legion_King_E_Witchblade_Desc",
    }),
    wpn_Butcher_R_base_Rec_April: new PassiveAbility({
        ID: 127,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Butcher_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Fireguard_R_Simplified_Rec_April: new PassiveAbility({
        ID: 128,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Fireguard_R_Simplified_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Helga_R_base_Rec_April: new PassiveAbility({
        ID: 129,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Helga_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_HongJoo_R_base_Rec_April: new PassiveAbility({
        ID: 130,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_HongJoo_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Ironclad_R_base_Rec_April: new PassiveAbility({
        ID: 131,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Ironclad_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Itu_R_base_Rec_April: new PassiveAbility({
        ID: 132,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Itu_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Ling_R_base_Rec_April: new PassiveAbility({
        ID: 133,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Ling_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Midnight_R_Base_Rec_April: new PassiveAbility({
        ID: 134,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Midnight_R_Base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Monkey_King_R_base_Rec_April: new PassiveAbility({
        ID: 135,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Monkey_King_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Sarge_R_Patterns_Rec_April: new PassiveAbility({
        ID: 136,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Sarge_R_Patterns_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Yukka_R_Monograms_Rec_April: new PassiveAbility({
        ID: 137,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Yukka_R_Monograms_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Yunlin_R_base_Rec_April: new PassiveAbility({
        ID: 138,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Yunlin_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Viper_E_Chargeboom: new PassiveAbility({
        ID: 139,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Viper_E_Chargeboom",
        AliasName: "wpn_Viper_E_Chargeboom",
        AliasDesc: "wpn_Viper_E_Chargeboom_Desc",
    }),
    wpn_Itu_E_Vortex: new PassiveAbility({
        ID: 140,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Itu_E_Vortex",
        AliasName: "wpn_Itu_E_Vortex",
        AliasDesc: "wpn_Itu_Vortex_Teleport",
    }),
    wpn_Bulwark_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 141,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Bulwark_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Fireguard_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 142,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Fireguard_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Helga_R_Paladin_Rec_Mystic: new PassiveAbility({
        ID: 143,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Helga_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Using_Light",
    }),
    wpn_HongJoo_R_Equilibrist_Rec_Mystic: new PassiveAbility({
        ID: 144,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_HongJoo_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Using_Triumph",
    }),
    wpn_Ironclad_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 145,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Ironclad_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Itu_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 146,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Itu_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Ling_R_Samurai_Rec_Mystic: new PassiveAbility({
        ID: 147,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Ling_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Midnight_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 148,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Midnight_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Sarge_R_Patterns_Rec_Mystic: new PassiveAbility({
        ID: 149,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Sarge_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Yukka_R_Monograms_Rec_Mystic: new PassiveAbility({
        ID: 150,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Yukka_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_YunLin_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 151,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Yunlin_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Abilities",
    }),
    wpn_Xiang_Tzu_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 152,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_XiangTzu_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Rampage",
    }),
    wpn_Monkey_King_R_Default_Rec_Mystic: new PassiveAbility({
        ID: 153,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_MonkeyKing_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Jingu",
    }),
    wpn_Legion_King_R_Default_Rec_Vampire: new PassiveAbility({
        ID: 154,
        Image: "Sprites/Assets/Abilities/icon_ability_vampirism",
        AliasName: "wpn_Legion_King_R_Default_Vampire",
        AliasDesc: "wpn_Legion_King_R_Default_Vampire_Desc",
    }),
    wpn_Yunlin_R_Default_Rec_Deceit: new PassiveAbility({
        ID: 155,
        Image: "Sprites/Assets/Abilities/icon_attribute_attack",
        AliasName: "wpn_Yunlin_R_Default_Deceit",
        AliasDesc: "wpn_Yunlin_R_Default_Deceit_Desc",
    }),
    wpn_Xiang_Tzu_R_Default_Rec_Guard: new PassiveAbility({
        ID: 156,
        Image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_Xiang_Tzu_Bloodborne_Credit_2",
        AliasName: "wpn_Xiang_Tzu_R_Default_Guard",
        AliasDesc: "wpn_Xiang_Tzu_R_Default_Guard_Desc",
    }),
    wpn_Helga_E_Black_Star: new PassiveAbility({
        ID: 157,
        Image: "Sprites/Assets/Abilities/Helga/icon_ability_wpn_Helga_E_Vampire_Trails",
        AliasName: "wpn_Helga_E_Black_Star",
        AliasDesc: "wpn_Helga_E_Black_Star_Desc",
    }),
    wpn_Monk_R_NeatBlade_Rec_Star: new PassiveAbility({
        ID: 158,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Monk_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Liquidator_R_Gold_Rec_Star: new PassiveAbility({
        ID: 159,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Liquidator_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Jet_R_Default_Rec_Star: new PassiveAbility({
        ID: 160,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Jet_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Feldsher_R_SpicyBlade_Rec_Star: new PassiveAbility({
        ID: 161,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Feldsher_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Emperor_R_Default_Rec_Star: new PassiveAbility({
        ID: 162,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Emperor_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Kibo_R_Default_Rec_Star: new PassiveAbility({
        ID: 163,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Kibo_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Marcus_R_Lord_Rec_Star: new PassiveAbility({
        ID: 164,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Marcus_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Lynx_R_Default_Rec_Star: new PassiveAbility({
        ID: 165,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Lynx_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Viper_R_Default_Rec_Star: new PassiveAbility({
        ID: 166,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Viper_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Legion_King_R_Default_Rec_Star: new PassiveAbility({
        ID: 167,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Legion_King_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Butcher_R_Default_Rec_Star: new PassiveAbility({
        ID: 168,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Butcher_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Itu_R_Default_Rec_Star: new PassiveAbility({
        ID: 169,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Itu_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Yunlin_R_Default_Rec_Star: new PassiveAbility({
        ID: 170,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Yunlin_R_base_Rec_Stellar",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_June_E_Default: new PassiveAbility({
        ID: 171,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_June_E_Default",
        AliasName: "wpn_June_E_Default",
        AliasDesc: "wpn_June_E_Default_Desc",
    }),
    wpn_June_E_Collapse: new PassiveAbility({
        ID: 172,
        Image: "Sprites/Assets/Abilities/June/icon_ability_wpn_June_E_Collapse",
        AliasName: "wpn_June_E_Collapse",
        AliasDesc: "wpn_June_E_Collapse_Desc",
    }),
    wpn_Sarge_E_Soul_Wind: new PassiveAbility({
        ID: 173,
        Image: "Sprites/Assets/Abilities/Sarge/icon_ability_Sarge_Cage",
        AliasName: "wpn_Sarge_E_Cage",
        AliasDesc: "wpn_Sarge_E_Cage_Desc",
    }),
    wpn_Yukka_R_Default_Rec_Valentine: new PassiveAbility({
        ID: 174,
        Image: "Sprites/Assets/Abilities/Yukka/icon_ability_healing_boost_valentine",
        AliasName: "wpn_Yukka_R_Default_Rec_Valentine",
        AliasDesc: "wpn_Yukka_R_Default_Rec_Valentine_Desc",
    }),
    wpn_YunLin_E_Golden_Red: new PassiveAbility({
        ID: 175,
        Image: "Sprites/Assets/Abilities/Yunlin/icon_ability_Yunlin_E_Golden_Red",
        AliasName: "wpn_YunLin_E_Golden_Red_Alias",
        AliasDesc: "wpn_YunLin_E_Golden_Red_Desc",
    }),
    wpn_Legion_King_E_Abyssblade: new PassiveAbility({
        ID: 176,
        Image: "Sprites/Assets/Abilities/Legion_King/icon_ability_wpn_Legion_King_E_Abyssblade",
        AliasName: "wpn_Legion_King_E_Abyssblade",
        AliasDesc: "wpn_Legion_King_E_Abyssblade_Desc",
    }),
    wpn_Long_Claws_After_Invis: new PassiveAbility({
        ID: 177,
        Image: "Sprites/Assets/Abilities/Lynx/icon_ability_claws_after_invis",
        AliasName: "wpn_Lynx_E_Hood",
        AliasDesc: "wpn_Long_Claws_After_Invis",
    }),
    wpn_Butcher_E_Gluttony: new PassiveAbility({
        ID: 178,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Butcher_E_Mana_Gain_Sprite",
        AliasName: "wpn_Butcher_E_Gluttony",
        AliasDesc: "wpn_Butcher_E_Gluttony_desc",
    }),
    wpn_Xiang_Tzu_E_Stealer: new PassiveAbility({
        ID: 179,
        Image: "Sprites/Assets/Abilities/Xiang_Tzu/icon_ability_wpn_Xiang_Tzu_E_Stealer",
        AliasName: "wpn_Xiang_Tzu_E_Stolen_name",
        AliasDesc: "wpn_Xiang_Tzu_E_Stolen_desc",
    }),
    wpn_Gideon_E_Fiery: new PassiveAbility({
        ID: 180,
        Image: "Sprites/Assets/Abilities/Gideon/icon_ability_wpn_Gideon_E_Fiery",
        AliasName: "wpn_Gideon_E_Fiery_name",
        AliasDesc: "wpn_Gideon_E_Fiery_desc",
    }),
    wpn_Itu_E_Cosmic: new PassiveAbility({
        ID: 181,
        Image: "Sprites/Assets/Abilities/Itu/icon_ability_wpn_Itu_E_Cosmic",
        AliasName: "wpn_Itu_E_Cosmic_name",
        AliasDesc: "wpn_Itu_E_Cosmic_desc",
    }),
    wpn_Widow_E_Waves: new PassiveAbility({
        ID: 182,
        Image: "Sprites/Assets/Abilities/Widow/icon_ability_wpn_Widow_E_Waves",
        AliasName: "wpn_Widow_E_Waves_name",
        AliasDesc: "wpn_Widow_E_Waves_desc",
    }),
    wpn_Butcher_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 183,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra",
        AliasName: "wpn_Butcher_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_ability_Rec_Cobra_desc",
    }),
    wpn_Emperor_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 184,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra",
        AliasName: "wpn_Emperor_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_ability_Rec_Cobra_desc",
    }),
    wpn_Gideon_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 185,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra",
        AliasName: "wpn_Gideon_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_ability_Rec_Cobra_desc",
    }),
    wpn_Yukka_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 186,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra",
        AliasName: "wpn_Yukka_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_ability_Rec_Cobra_desc",
    }),
    wpn_Widow_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 187,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra",
        AliasName: "wpn_Widow_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_ability_Rec_Cobra_desc",
    }),
    wpn_Sarge_R_Patterns_Rec_Vamp: new PassiveAbility({
        ID: 188,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Sarge_R_Patterns_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Lynx_R_Default_Rec_Vamp: new PassiveAbility({
        ID: 189,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Lynx_R_Default_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Monkey_King_R_Base_Rec_Vamp: new PassiveAbility({
        ID: 190,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Monkey_King_R_Base_Rec_Vamp",
        AliasDesc: "analog_sf_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Yunlin_R_Base_Rec_Vamp: new PassiveAbility({
        ID: 191,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Yunlin_R_Base_Rec_Vamp",
        AliasDesc: "analog_sf_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Xiang_Tzu_R_Default_Rec_Vamp: new PassiveAbility({
        ID: 192,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Xiang_Tzu_R_Default_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Monk_R_NeatBlade_Rec_Vamp: new PassiveAbility({
        ID: 193,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Monk_R_NeatBlade_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Jet_R_Golden_Rec_Vamp: new PassiveAbility({
        ID: 194,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Jet_R_Golden_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Marcus_R_Lord_Rec_Vamp: new PassiveAbility({
        ID: 195,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Marcus_R_Lord_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_HongJoo_R_Default_Rec_Vamp: new PassiveAbility({
        ID: 196,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_HongJoo_R_Default_Rec_Vamp",
        AliasDesc: "analog_sf_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Ironclad_R_Base_Rec_Vamp: new PassiveAbility({
        ID: 197,
        Image: "Sprites/Assets/Abilities/icon_ability_vamp_after_sf",
        AliasName: "wpn_Ironclad_R_Base_Rec_Vamp",
        AliasDesc: "shadow_form_ability_wpn_Rec_Vamp_desc",
    }),
    wpn_Legion_King_E_Castle: new PassiveAbility({
        ID: 198,
        Image: "Sprites/Assets/Abilities/Legion_King/icon_ability_wpn_Legion_King_E_Castle",
        AliasName: "wpn_Legion_King_E_Castle_name",
        AliasDesc: "wpn_Legion_King_E_Castle_desc",
    }),
    wpn_Raikichi_R_Base_Rec_Cobra: new PassiveAbility({
        ID: 199,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_Cobra_electricity",
        AliasName: "wpn_Raikichi_R_Base_Rec_Cobra_name",
        AliasDesc: "wpn_Raikichi_R_Base_Rec_Cobra_desc",
    }),
    wpn_Marcus_R_Ninja_Party: new PassiveAbility({
        ID: 200,
        Image: "Sprites/Assets/Abilities/Liquidator/icon_ability_Liquidator_t_10_2",
        AliasName: "wpn_Marcus_R_Ninja_Party_name",
        AliasDesc: "wpn_Marcus_R_Ninja_Party_desc",
    }),
    wpn_Jet_R_Golden_Rec_Summer: new PassiveAbility({
        ID: 201,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Jet_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Marcus_R_Lord_Rec_Summer: new PassiveAbility({
        ID: 202,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Marcus_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Xiang_Tzu_R_base_Rec_Summer: new PassiveAbility({
        ID: 203,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Xiang_Tzu_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Lynx_R_base_Rec_Summer: new PassiveAbility({
        ID: 204,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Lynx_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Itu_R_base_Rec_Summer: new PassiveAbility({
        ID: 205,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Itu_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Liquidator_R_Gold_Rec_Summer: new PassiveAbility({
        ID: 206,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Liquidator_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Gideon_R_base_Rec_Summer: new PassiveAbility({
        ID: 207,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Gideon_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Viper_R_base_Rec_Summer: new PassiveAbility({
        ID: 208,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Viper_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Monkey_King_R_base_Rec_Summer: new PassiveAbility({
        ID: 209,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Monkey_King_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Yunlin_R_base_Rec_Summer: new PassiveAbility({
        ID: 210,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Mana_Start",
        AliasName: "wpn_Yunlin_R_base_Rec_Summer",
        AliasDesc: "wpn_Mana_Start",
    }),
    wpn_Kibo_E_Eclipse: new PassiveAbility({
        ID: 211,
        Image: "Sprites/Assets/Abilities/Kibo/wpn_Kibo_E_Eclipse",
        AliasName: "wpn_Kibo_E_Eclipse_name",
        AliasDesc: "wpn_Kibo_E_Eclipse_desc",
    }),
    wpn_Raikichi_E_Burned: new PassiveAbility({
        ID: 212,
        Image: "Sprites/Assets/Abilities/Raikichi/icon_ability_E_Burned_Raikichi",
        AliasName: "wpn_Raikichi_E_Burned_name",
        AliasDesc: "wpn_Raikichi_E_Burned_desc",
    }),
    wpn_Bulwark_R_Base_Rec_Steam: new PassiveAbility({
        ID: 213,
        Image: "Sprites/Assets/Abilities/icon_money_stack",
        AliasName: "wpn_Bulwark_R_Base_Rec_Steam_name",
        AliasDesc: "wpn_Bulwark_R_Base_Rec_Steam_desc",
    }),
    wpn_Raikichi_R_base_Rec_Mystic: new PassiveAbility({
        ID: 214,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Raikichi_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Overcharge",
    }),
    wpn_Widow_R_Base_Rec_Mystic: new PassiveAbility({
        ID: 215,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Widow_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Gideon_R_Base_Rec_Mystic: new PassiveAbility({
        ID: 216,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Heal_On_Enter_SF",
        AliasName: "wpn_Gideon_R_base_Rec_Mystic",
        AliasDesc: "wpn_Mystic_Heal_On_Enter_SF",
    }),
    wpn_Sarge_R_Patterns_Rec_Star: new PassiveAbility({
        ID: 217,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Sarge_R_Patterns_Rec_Star",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Fireguard_R_Simplified_Rec_Star: new PassiveAbility({
        ID: 218,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Fireguard_R_Simplified_Rec_Star",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Xiang_Tzu_R_Base_Rec_Star: new PassiveAbility({
        ID: 219,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Xiang_Tzu_R_Base_Rec_Star",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Nonna_R_Base_Rec_Star: new PassiveAbility({
        ID: 220,
        Image: "Sprites/Assets/Abilities/Jet/icon_ability_Jet_dispell",
        AliasName: "wpn_Nonna_R_Base_Rec_Star",
        AliasDesc: "wpn_Stellar_Protection",
    }),
    wpn_Monkey_King_E_Crystal: new PassiveAbility({
        ID: 221,
        Image: "Sprites/Assets/Abilities/Monkey_King/icon_ability_wpn_E_Crystal_Monkey_King",
        AliasName: "wpn_Monkey_King_E_Crystal_Name",
        AliasDesc: "wpn_Monkey_King_E_Crystal_Desc",
    }),
    wpn_Bulwark_E_Streak: new PassiveAbility({
        ID: 222,
        Image: "Sprites/Assets/Abilities/Bulwark/icon_ability_wpn_Bulwark_E_Crater",
        AliasName: "wpn_Bulwark_E_Streak",
        AliasDesc: "wpn_Bulwark_E_Streak_Desc",
    }),
    wpn_Nonna_E_Owl: new PassiveAbility({
        ID: 223,
        Image: "Sprites/Assets/Abilities/Nonna/icon_ability_wpn_Nonna_E_Owl",
        AliasName: "wpn_Nonna_E_Owl_name",
        AliasDesc: "wpn_Nonna_E_Owl_desc",
    }),
    wpn_HongJoo_R_Equilibrist_Rec_CNY: new PassiveAbility({
        ID: 224,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_CNY",
        AliasName: "wpn_HongJoo_R_Equilibrist_Rec_CNY",
        AliasDesc: "wpn_ability_Rec_CNY_Alias",
    }),
    wpn_Yunlin_R_Base_Rec_CNY: new PassiveAbility({
        ID: 225,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_CNY",
        AliasName: "wpn_Yunlin_R_Base_Rec_CNY",
        AliasDesc: "wpn_ability_Rec_CNY_Alias",
    }),
    wpn_Xiang_Tzu_R_Base_Rec_CNY: new PassiveAbility({
        ID: 226,
        Image: "Sprites/Assets/Abilities/icon_ability_wpn_Rec_CNY",
        AliasName: "wpn_Xiang_Tzu_R_Base_Rec_CNY",
        AliasDesc: "wpn_ability_Rec_CNY_Alias",
    }),
    wpn_Fireguard_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 227,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Fireguard_R_Base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Ironclad_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 228,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Ironclad_R_Base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Itu_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 229,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Itu_R_Base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Ling_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 230,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Ling_R_Samurai_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Midnight_Receive_Less_Magic_Damage_Sakura: new PassiveAbility({
        ID: 231,
        Image: "Sprites/Assets/Abilities/icon_attribute_defense",
        AliasName: "wpn_Midnight_R_Base_Rec_Sakura",
        AliasDesc: "wpn_Receive_Less_Magic_Damage",
    }),
    wpn_Marcus_R_Bamboo_Fest: new PassiveAbility({
        ID: 232,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "wpn_Marcus_R_base_Rec_Bamboo_name",
        AliasDesc: "wpn_Pack_Rare_Bamboo_Fest_desc",
    }),
    wpn_Sarge_R_Bamboo_Fest: new PassiveAbility({
        ID: 233,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "wpn_Sarge_R_Patterns_Rec_Bamboo_name",
        AliasDesc: "wpn_Pack_Rare_Bamboo_Fest_desc",
    }),
    wpn_Gideon_R_Bamboo_Fest: new PassiveAbility({
        ID: 234,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "wpn_Gideon_R_base_Rec_Bamboo_name",
        AliasDesc: "wpn_Pack_Rare_Bamboo_Fest_desc",
    }),
    wpn_Helga_R_Bamboo_Fest: new PassiveAbility({
        ID: 235,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "wpn_Helga_R_base_Rec_Bamboo_name",
        AliasDesc: "wpn_Pack_Rare_Bamboo_Fest_desc",
    }),
    wpn_Nonna_R_Bamboo_Fest: new PassiveAbility({
        ID: 236,
        Image: "Sprites/Assets/Abilities/Marcus/icon_ability_Marcus_base_invul",
        AliasName: "wpn_Nonna_R_base_Rec_Bamboo_name",
        AliasDesc: "wpn_Pack_Rare_Bamboo_Fest_desc",
    }),
    wpn_Ironclad_E_Minotaur: new PassiveAbility({
        ID: 237,
        Image: "Sprites/Assets/Abilities/Ironclad/icon_ability_wpn_E_Minotaur",
        AliasName: "wpn_Ironclad_E_Minotaur_Name",
        AliasDesc: "wpn_Ironclad_E_Minotaur_Desc",
    }),
    wpn_Midnight_Dodge_Crit_Block_Break: new PassiveAbility({
        ID: 238,
        Image: "Sprites/Assets/Abilities/Midnight/icon_ability_wpn_Midnight_E_Feather_stacks",
        AliasName: "wpn_Midnight_E_Feather_name",
        AliasDesc: "wpn_Midnight_E_Feather_desc",
    }),
    wpn_Monk_R_NeatBlade_Rec_April: new PassiveAbility({
        ID: 239,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Monk_R_NeatBlade_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Lynx_R_base_Rec_April: new PassiveAbility({
        ID: 240,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Lynx_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Xiang_Tzu_R_base_Rec_April: new PassiveAbility({
        ID: 241,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Xiang_Tzu_R_Base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Marcus_R_Lord_Rec_April: new PassiveAbility({
        ID: 242,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Marcus_R_Lord_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Nonna_R_base_Rec_April: new PassiveAbility({
        ID: 243,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Nonna_R_base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Jet_R_Golden_Rec_April: new PassiveAbility({
        ID: 244,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Jet_R_Golden_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Emperor_R_base_Rec_April: new PassiveAbility({
        ID: 245,
        Image: "Sprites/Assets/Abilities/icon_ability_April",
        AliasName: "wpn_Emperor_R_Base_Rec_April",
        AliasDesc: "wpn_Better_PVE",
    }),
    wpn_Feldsher_E_Diver: new PassiveAbility({
        ID: 246,
        Image: "Sprites/Assets/Abilities/Feldsher/icon_wpn_ability_E_Diver",
        AliasName: "wpn_Feldsher_E_Diver_name",
        AliasDesc: "wpn_Feldsher_E_Diver_desc",
    }),
    wpn_Shogun_R_StunDamage: new PassiveAbility({
        ID: 247,
        Image: "Sprites/Assets/Abilities/Shogun/icon_ability_Shogun_minion_stronger",
        AliasName: "wpn_Shogun_R_Base_Rec_Vassal",
        AliasDesc: "wpn_Shogun_R_StunDamage",
    }),
    wpn_Gideon_E_hunter: new PassiveAbility({
        ID: 248,
        Image: "Sprites/Assets/Abilities/Gideon/icon_wpn_ability_E_Hunter",
        AliasName: "wpn_Gideon_E_Hunter_name",
        AliasDesc: "wpn_Gideon_E_Hunter_desc",
    }),
};
