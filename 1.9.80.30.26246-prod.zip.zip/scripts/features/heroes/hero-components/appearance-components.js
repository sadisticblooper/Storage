var skeletons = {
    FEMALE_SKELETON: new SkeletonItem({
        ID: 600,
        Component: "Commons/f_skeleton",
    }),
    MALE_SKELETON: new SkeletonItem({
        ID: 601,
        Component: "Commons/m_skeleton",
    }),
    FEMALE_SKELETON_HELGA: new SkeletonItem({
        ID: 602,
        Component: "Commons/helga_skeleton",
    }),
    FEMALE_SKELETON_JUNE: new SkeletonItem({
        ID: 603,
        Component: "Commons/june_f_skeleton",
    }),
};
var equipmentDict = {};
equipmentDict = extend(equipmentDict, helmets);
equipmentDict = extend(equipmentDict, armors);
equipmentDict = extend(equipmentDict, weapons);
equipmentDict = extend(equipmentDict, ranged);
equipmentDict = extend(equipmentDict, skeletons);
var equipmentMap = createIDMap(equipmentDict, "equipmentMap");
