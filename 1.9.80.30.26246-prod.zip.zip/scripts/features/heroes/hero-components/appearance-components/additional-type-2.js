var additionalItems2 = {};
