var ranged = {
    RNG_BLASTER: new RangedItem({
        ID: 1300,
        Component: "arena_bulwark/_base/rng_blaster",
        Bullet: "arena_bulwark/_base/rng_blaster_bolt",
    }),
    RNG_BLASTER_BULWARK_E_GOLD: new RangedItem({
        ID: 1301,
        Component: "arena_bulwark/E_Golden/rng_blaster",
        Bullet: "arena_bulwark/_base/rng_blaster_bolt",
    }),
    RNG_BLASTER_BULWARK_R_BLACK: new RangedItem({
        ID: 1302,
        Component: "arena_bulwark/R_Black/rng_blaster",
        Bullet: "arena_bulwark/_base/rng_blaster_bolt",
    }),
    RNG_BLASTER_BULWARK_E_CLOVER: new RangedItem({
        ID: 1303,
        Component: "arena_bulwark/E_Clover/rng_blaster",
        Bullet: "arena_bulwark/_base/rng_blaster_bolt",
    }),
    RNG_BLASTER_BULWARK_R_JEWEL: new RangedItem({
        ID: 1304,
        Component: "arena_bulwark/R_Jewel/rng_blaster",
        Bullet: "arena_bulwark/_base/rng_blaster_bolt",
    }),
    RNG_AGL_KNIVES: new RangedItem({
        ID: 2300,
        Component: "arena_emperor/_base/rng_knives",
    }),
    RNG_KUNAI: new RangedItem({
        ID: 3300,
        Component: "arena_feldsher/_base/rng_kunai",
    }),
    RNG_KUNAI_R_RUSTY: new RangedItem({
        ID: 3301,
        Component: "arena_feldsher/R_Rusty/rng_kunai",
    }),
    RNG_FLAME_SPIT_FIREGUARD: new RangedItem({
        ID: 4300,
        Component: "arena_fireguard/_base/mgc_fireguard_flame_spit",
    }),
    RNG_PISTOL: new RangedItem({
        ID: 5300,
        Component: "arena_helga/_base/rng_pistol",
    }),
    RNG_PISTOL_BASE_REC_PHOENIX: new RangedItem({
        ID: 5301,
        Component: "arena_helga/E_Phoenix/rng_pistol",
    }),
    RNG_PISTOL_BASE_REC_GlORY: new RangedItem({
        ID: 5302,
        Component: "arena_helga/E_Phoenix_Rec_Glory/rng_pistol",
    }),
    RNG_BOMB: new RangedItem({
        ID: 6300,
        Component: "arena_hong_joo/_base/rng_bomb",
    }),
    RNG_NEEDLE_JET: new RangedItem({
        ID: 8300,
        Component: "arena_jet/_base/rng_jet_needle",
    }),
    RNG_SHURIKEN_KIBO: new RangedItem({
        ID: 9300,
        Component: "arena_kibo/_base/rng_shuriken",
    }),
    RNG_SHURIKEN_KIBO_E_GRAY: new RangedItem({
        ID: 9301,
        Component: "arena_kibo/E_Gray/rng_shuriken",
    }),
    RNG_BOTTLE_LING: new RangedItem({
        ID: 10300,
        Component: "arena_ling/_base/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_SAMURAI: new RangedItem({
        ID: 10301,
        Component: "arena_ling/E_Samurai/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_R_RED: new RangedItem({
        ID: 10302,
        Component: "arena_ling/R_Red/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_SAMURAI_REC_GOLD: new RangedItem({
        ID: 10303,
        Component: "arena_ling/E_Samurai_Rec_Gold/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_RAVEN: new RangedItem({
        ID: 10304,
        Component: "arena_ling/E_Raven/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_REC_SEASON: new RangedItem({
        ID: 10305,
        Component: "arena_ling/E_Rec_Season/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_RONIN: new RangedItem({
        ID: 10306,
        Component: "arena_ling/E_Ronin/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_RONIN_REC_BLACK: new RangedItem({
        ID: 10307,
        Component: "arena_ling/E_Ronin_Rec_Black/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_RONIN_REC_SEASON: new RangedItem({
        ID: 10308,
        Component: "arena_ling/E_Ronin_Rec_Season/rng_bottle_ling",
    }),
    RNG_BOTTLE_LING_E_RAVEN_REC_BLUE: new RangedItem({
        ID: 10309,
        Component: "arena_ling/E_Raven_Rec_Blue/rng_bottle_ling",
    }),
    RNG_PISTOL_LIQ: new RangedItem({
        ID: 11300,
        Component: "arena_liquidator/_base/rng_pistol_liquidator",
    }),
    RNG_ARBALEST: new RangedItem({
        ID: 11301,
        Component: "arena_liquidator/_base/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_PISTOL_LIQ_S_GOLD: new RangedItem({
        ID: 11302,
        Component: "arena_liquidator/S_Gold/rng_pistol_liquidator",
    }),
    RNG_ARBALEST_S_GOLD: new RangedItem({
        ID: 11303,
        Component: "arena_liquidator/S_Gold/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_PISTOL_LIQ_E_WHITE: new RangedItem({
        ID: 11304,
        Component: "arena_liquidator/E_White/rng_pistol_liquidator",
    }),
    RNG_ARBALEST_E_WHITE: new RangedItem({
        ID: 11305,
        Component: "arena_liquidator/E_White/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_ARBALEST_E_VALKYRIE: new RangedItem({
        ID: 11306,
        Component: "arena_liquidator/E_Valkyrie/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_PISTOL_LIQ_E_VALKYRIE: new RangedItem({
        ID: 11307,
        Component: "arena_liquidator/E_Valkyrie/rng_pistol_liquidator",
    }),
    RNG_ARBALEST_E_VALKYRIE_REC_SEASON: new RangedItem({
        ID: 11308,
        Component: "arena_liquidator/E_Valkyrie_Rec_Season/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_ARBALEST_E_FORGED: new RangedItem({
        ID: 11310,
        Component: "arena_liquidator/E_Forged/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/E_Forged/rng_arbalest_bolt_liquidator",
    }),
    RNG_ARBALEST_E_FORGED_REC_JOUST: new RangedItem({
        ID: 11312,
        Component: "arena_liquidator/E_Forged/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/E_Forged/rng_arbalest_bolt_liquidator",
    }),
    RNG_ARBALEST_E_FORGED_REC_SEASON: new RangedItem({
        ID: 11315,
        Component: "arena_liquidator/E_Forged_Rec_Season/rng_arbalest_liquidator",
        Bullet: "arena_liquidator/E_Forged/rng_arbalest_bolt_liquidator",
    }),
    RNG_PISTOL_LIQ_E_VALKYRIE_REC_SEASON: new RangedItem({
        ID: 11309,
        Component: "arena_liquidator/E_Valkyrie_Rec_Season/rng_pistol_liquidator",
    }),
    RNG_PISTOL_LIQ_E_FORGED: new RangedItem({
        ID: 11311,
        Component: "arena_liquidator/E_Forged/rng_pistol_liquidator",
    }),
    RNG_PISTOL_LIQ_E_FORGED_REC_JOUST: new RangedItem({
        ID: 11313,
        Component: "arena_liquidator/E_Forged/rng_pistol_liquidator",
    }),
    RNG_PISTOL_LIQ_E_FORGED_REC_SEASON: new RangedItem({
        ID: 11314,
        Component: "arena_liquidator/E_Forged_Rec_Season/rng_pistol_liquidator",
    }),
    RNG_BOMB_LYNX: new RangedItem({
        ID: 12300,
        Component: "arena_lynx/_base/rng_bomb_lynx",
    }),
    RNG_PILUM: new RangedItem({
        ID: 13300,
        Component: "arena_marcus/_base/rng_pilum",
    }),
    RNG_PILUM_E_LORD: new RangedItem({
        ID: 13301,
        Component: "arena_marcus/E_Lord/rng_pilum",
    }),
    RNG_KUNAI_MIDNIGHT: new RangedItem({
        ID: 14300,
        Component: "arena_midnight/_base/rng_kunai_midnight",
    }),
    RNG_KUNAI_MIDNIGHT_E_WITCH: new RangedItem({
        ID: 14301,
        Component: "arena_midnight/E_Witch/rng_kunai_midnight",
    }),
    MONK_RNG_BASE: new RangedItem({
        ID: 15300,
        Component: "arena_monk/_base/rng_bow",
        Bullet: "arena_monk/_base/rng_bow_bolt",
    }),
    MONK_RNG_E_CURSED: new RangedItem({
        ID: 15301,
        Component: "arena_monk/E_Cursed/rng_bow",
        Bullet: "arena_monk/_base/rng_bow_bolt",
    }),
    MONK_RNG_E_CURSED_REC_WHITE: new RangedItem({
        ID: 15302,
        Component: "arena_monk/E_Cursed_Rec_White/rng_bow",
        Bullet: "arena_monk/_base/rng_bow_bolt",
    }),
    RNG_CHAKRAM_MONKEY_KING: new RangedItem({
        ID: 16300,
        Component: "arena_monkey_king/_base/rng_chakram",
    }),
    RNG_CHAKRAM_MONKEY_KING_L_CRYSTAL: new RangedItem({
        ID: 16301,
        Component: "arena_monkey_king/L_Crystal/rng_chakram",
    }),
    RNG_KNIVES: new RangedItem({
        ID: 17300,
        Component: "arena_sarge/_base/rng_knives_sarge",
    }),
    RNG_CAT_YUKKA: new RangedItem({
        ID: 18300,
        Component: "arena_yukka/_base/shd_yukka_cat_throw",
    }),
    RNG_BOMB_VIPER: new RangedItem({
        ID: 19300,
        Component: "arena_viper/_base/rng_bomb_viper",
    }),
    RNG_LEGION_KING_PILUM: new RangedItem({
        ID: 20300,
        Component: "arena_legion_king/_base/rng_legion_king_pilum",
    }),
    RNG_LEGION_KING_PILUM_R_VINY: new RangedItem({
        ID: 20301,
        Component: "arena_legion_king/R_Viny/rng_legion_king_pilum",
    }),
    RNG_LEGION_KING_PILUM_R_REC_BOSS: new RangedItem({
        ID: 20302,
        Component: "arena_legion_king/R_Rec_Boss/rng_legion_king_pilum",
    }),
    RNG_LEGION_KING_PILUM_E_BONE: new RangedItem({
        ID: 20303,
        Component: "arena_legion_king/E_Bone/rng_legion_king_pilum",
    }),
    RNG_LEGION_KING_PILUM_E_BONE_REC_LICH: new RangedItem({
        ID: 20304,
        Component: "arena_legion_king/E_Bone_Rec_Lich/rng_legion_king_pilum",
    }),
    RNG_LEGION_KING_PILUM_L_CASTLE: new RangedItem({
        ID: 20305,
        Component: "arena_legion_king/L_Castle/rng_legion_king_pilum",
    }),
    RNG_HOOK: new RangedItem({
        ID: 21300,
        Component: "arena_butcher/_base/rng_hook",
    }),
    RNG_XIANG_TZU_KNIVES: new RangedItem({
        ID: 25300,
        Component: "arena_xiang_tzu/_base/rng_knives_xiang_tzu",
    }),
    RNG_TIER1_PVE_ARBALEST: new RangedItem({
        ID: 60300,
        Component: "arena_pve_models/weapons/tier1_rng_arbalest",
        Bullet: "arena_liquidator/_base/rng_arbalest_bolt_liquidator",
    }),
    RNG_ITU_SHURIKEN: new RangedItem({
        ID: 23300,
        Component: "arena_itu/_base/rng_itu_shuriken",
    }),
    RNG_YUNLIN: new RangedItem({
        ID: 24300,
        Component: "arena_yunlin/_base/rng_bow_yunlin",
        Bullet: "arena_yunlin/_base/rng_bow_bolt_yunlin",
    }),
    RNG_SHOGUN_MINION: new RangedItem({
        ID: 31300,
        Component: "arena_shogun/_base/rng_shogun_minion",
    }),
    RNG_SHOGUN_MINION_R_RED: new RangedItem({
        ID: 31301,
        Component: "arena_shogun/R_red/rng_shogun_minion",
    }),
    RNG_EMPTY_MODEL: new RangedItem({
        ID: 26300,
        Component: "Commons/empty_model",
    }),
};
