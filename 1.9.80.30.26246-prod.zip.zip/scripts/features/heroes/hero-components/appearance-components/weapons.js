var weapons = {
    WPN_BULWARK_BASE: new WeaponItem({
        ID: 1400,
        Component: "arena_bulwark/_Weapons/_base",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_GOLDEN: new WeaponItem({
        ID: 1401,
        Component: "arena_bulwark/_Weapons/C_Golden",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BLACK: new WeaponItem({
        ID: 1403,
        Component: "arena_bulwark/_Weapons/C_Black",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_CLOVER: new WeaponItem({
        ID: 1406,
        Component: "arena_bulwark/_Weapons/C_base_Rec_Clover",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_BOSS: new WeaponItem({
        ID: 1408,
        Component: "arena_bulwark/_Weapons/C_Base_Rec_Boss",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_SNOW: new WeaponItem({
        ID: 1409,
        Component: "arena_bulwark/_Weapons/C_base_Rec_Snow",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_JEWEL: new WeaponItem({
        ID: 1411,
        Component: "arena_bulwark/_Weapons/C_Base_Rec_Jewel",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_SEASON: new WeaponItem({
        ID: 1413,
        Component: "arena_bulwark/_Weapons/C_Base_Rec_Season",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_CHILL: new WeaponItem({
        ID: 1414,
        Component: "arena_bulwark/_Weapons/C_Base_Rec_Chill",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_C_BASE_REC_IVY: new WeaponItem({
        ID: 1415,
        Component: "arena_bulwark/_Weapons/C_Base_Rec_Ivy",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_R_GOLDEN_REC_GRAY: new WeaponItem({
        ID: 1402,
        Component: "arena_bulwark/_Weapons/R_Golden_Rec_Gray",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_R_BASE_REC_BLACK: new WeaponItem({
        ID: 1404,
        Component: "arena_bulwark/_Weapons/R_base_Rec_Black",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_R_GOLD_REC_SUMMER_22: new WeaponItem({
        ID: 1407,
        Component: "arena_bulwark/_Weapons/R_Gold_Rec_Summer_22",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 1410,
        Component: "arena_bulwark/_Weapons/R_Default_Rec_Mystic",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_R_BASE_REC_STEAM: new WeaponItem({
        ID: 1416,
        Component: "arena_bulwark/_Weapons/R_base_Rec_Steam",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_E_PIKE: new WeaponItem({
        ID: 1405,
        Component: "arena_bulwark/_Weapons/E_Pike",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_BULWARK_E_STREAK: new WeaponItem({
        ID: 1417,
        Component: "arena_bulwark/_Weapons/E_Streak",
        Style: "SHIELD_KNOBSTICK"
    }),
    WPN_EMPEROR_BASE: new WeaponItem({
        ID: 2400,
        Component: "arena_emperor/_Weapons/_base",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_CYAN: new WeaponItem({
        ID: 2402,
        Component: "arena_emperor/_Weapons/C_Cyan",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_DOOMED: new WeaponItem({
        ID: 2404,
        Component: "arena_emperor/_Weapons/C_Doomed",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_BASE_REC_ENLIGHTEN: new WeaponItem({
        ID: 2408,
        Component: "arena_emperor/_Weapons/C_base_Rec_Enlighten",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_BASE_REC_ENLIGHTEN_BOSS: new WeaponItem({
        ID: 2410,
        Component: "arena_pve_models/weapons/C_base_Rec_Enlighten_Boss_emperor",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_BASE_REC_DRAGON: new WeaponItem({
        ID: 2411,
        Component: "arena_emperor/_Weapons/C_Base_Rec_Dragon",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_BASE_REC_SEASON: new WeaponItem({
        ID: 2412,
        Component: "arena_emperor/_Weapons/C_base_Rec_Season",
        Style: "FISTS"
    }),
    WPN_EMPEROR_C_BASE_REC_ORANGE: new WeaponItem({
        ID: 2414,
        Component: "arena_emperor/_Weapons/C_base_Rec_Orange",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_DEFAULT_REC_RED: new WeaponItem({
        ID: 2403,
        Component: "arena_emperor/_Weapons/R_Default_Rec_Red",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_BASE_REC_SILVER: new WeaponItem({
        ID: 2401,
        Component: "arena_emperor/_Weapons/R_base_Rec_Silver",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 2405,
        Component: "arena_emperor/_Weapons/R_base_Rec_Sakura",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 2407,
        Component: "arena_emperor/_Weapons/R_base_Rec_Mystic",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_DEFAULR_REC_STAR: new WeaponItem({
        ID: 2409,
        Component: "arena_emperor/_Weapons/R_Default_Rec_Star",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_BASE_REC_COBRA: new WeaponItem({
        ID: 2413,
        Component: "arena_emperor/_Weapons/R_Base_Rec_Cobra",
        Style: "FISTS"
    }),
    WPN_EMPEROR_R_BASE_REC_APRIL: new WeaponItem({
        ID: 2415,
        Component: "arena_emperor/_Weapons/R_Base_Rec_April",
        Style: "FISTS"
    }),
    WPN_EMPEROR_E_STONE_GLOVES: new WeaponItem({
        ID: 2406,
        Component: "arena_emperor/_Weapons/E_Stone_Gloves",
        Style: "FISTS"
    }),
    WPN_FELDSHER_BASE: new WeaponItem({
        ID: 3400,
        Component: "arena_feldsher/_Weapons/_base",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_RUSTY: new WeaponItem({
        ID: 3401,
        Component: "arena_feldsher/_Weapons/C_Rusty",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_SUIT: new WeaponItem({
        ID: 3404,
        Component: "arena_feldsher/_Weapons/C_Suit",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_REC_SEASON: new WeaponItem({
        ID: 3408,
        Component: "arena_feldsher/_Weapons/C_Rec_Season",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_REC_PLAGUE: new WeaponItem({
        ID: 3411,
        Component: "arena_feldsher/_Weapons/C_Rec_Plague",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_REC_VAMPIRE: new WeaponItem({
        ID: 3412,
        Component: "arena_feldsher/_Weapons/C_SpicyBlade_Rec_Vampire",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_BASE_REC_DIVER: new WeaponItem({
        ID: 3413,
        Component: "arena_feldsher/_Weapons/C_Rec_Diver",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_DIVER_REC_SEASON: new WeaponItem({
        ID: 3414,
        Component: "arena_feldsher/_Weapons/C_Diver_Rec_Season",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_C_DIVER_REC_HEATED: new WeaponItem({
        ID: 3415,
        Component: "arena_feldsher/_Weapons/C_Base_Rec_Heated",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_R_SPICY_BLADE: new WeaponItem({
        ID: 3402,
        Component: "arena_feldsher/_Weapons/R_SpicyBlade",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_R_BASE_REC_ELEGANT: new WeaponItem({
        ID: 3405,
        Component: "arena_feldsher/_Weapons/R_base_Rec_Elegant",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_R_SPICY_BLADE_REC_SUMMER_22: new WeaponItem({
        ID: 3406,
        Component: "arena_feldsher/_Weapons/R_SpicyBlade_Rec_Summer_22",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_R_SPICY_BLADE_REC_MYSTIC: new WeaponItem({
        ID: 3407,
        Component: "arena_feldsher/_Weapons/R_SpicyBlade_Rec_Mystic",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_R_SPICY_BLADE_REC_STAR: new WeaponItem({
        ID: 3409,
        Component: "arena_feldsher/_Weapons/R_SpicyBlade_Rec_Star",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_E_RED_VAMPIRE: new WeaponItem({
        ID: 3403,
        Component: "arena_feldsher/_Weapons/E_RedVampire",
        Style: "NAGINATA"
    }),
    WPN_FELDSHER_E_DIVER: new WeaponItem({
        ID: 3416,
        Component: "arena_feldsher/_Weapons/E_Diver",
        Style: "NAGINATA"
    }),
    WPN_FIREGUARD_BASE: new WeaponItem({
        ID: 4400,
        Component: "arena_fireguard/_Weapons/_base",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_RED: new WeaponItem({
        ID: 4401,
        Component: "arena_fireguard/_Weapons/C_Red",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_WHITE: new WeaponItem({
        ID: 4404,
        Component: "arena_fireguard/_Weapons/C_White",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_BASE_REC_VOID: new WeaponItem({
        ID: 4407,
        Component: "arena_fireguard/_Weapons/C_base_Rec_Void",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_CYBER: new WeaponItem({
        ID: 4408,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Cyber",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_SEASON: new WeaponItem({
        ID: 4411,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Season",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_PORCELAIN: new WeaponItem({
        ID: 4412,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Porcelain",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_STAR: new WeaponItem({
        ID: 4413,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Star",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_SEASON_2: new WeaponItem({
        ID: 4414,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Season_2",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_C_SIMPLIFIED_REC_GREEN: new WeaponItem({
        ID: 4417,
        Component: "arena_fireguard/_Weapons/C_Simplified_Rec_Green",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_SIMPLIFIED: new WeaponItem({
        ID: 4402,
        Component: "arena_fireguard/_Weapons/R_Simplified",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_YELLOW: new WeaponItem({
        ID: 4405,
        Component: "arena_fireguard/_Weapons/R_Yellow",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 4406,
        Component: "arena_fireguard/_Weapons/R_base_Rec_Summer_22",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_SIMPLIFIED_REC_APRIL: new WeaponItem({
        ID: 4409,
        Component: "arena_fireguard/_Weapons/R_Simplified_Rec_April",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 4410,
        Component: "arena_fireguard/_Weapons/R_Default_Rec_Mystic",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_SIMPLIFIED_REC_STAR: new WeaponItem({
        ID: 4415,
        Component: "arena_fireguard/_Weapons/R_Simplified_Rec_Star",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 4416,
        Component: "arena_fireguard/_Weapons/R_base_Rec_Sakura",
        Style: "KAMA"
    }),
    WPN_FIREGUARD_E_BONES: new WeaponItem({
        ID: 4403,
        Component: "arena_fireguard/_Weapons/E_Bones",
        Style: "KAMA"
    }),
    WPN_HELGA_BASE: new WeaponItem({
        ID: 5400,
        Component: "arena_helga/_Weapons/_base",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PALADIN: new WeaponItem({
        ID: 5401,
        Component: "arena_helga/_Weapons/C_Paladin",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_BASE_REC_UNSIGHT: new WeaponItem({
        ID: 5406,
        Component: "arena_helga/_Weapons/R_Base_Rec_Unsight",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_BASE_REC_PHOENIX: new WeaponItem({
        ID: 5407,
        Component: "arena_helga/_Weapons/C_base_Rec_Phoenix",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PHOENIX_REC_BOSS: new WeaponItem({
        ID: 5409,
        Component: "arena_helga/_Weapons/C_Phoenix_Rec_Boss",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_BASE_REC_VALENTINE: new WeaponItem({
        ID: 5410,
        Component: "arena_helga/_Weapons/C_base_Rec_Valentine",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PALADIN_REC_VAMPIRE: new WeaponItem({
        ID: 5413,
        Component: "arena_helga/_Weapons/C_Paladin_Rec_Vampire",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PALADIN_REC_SEASON: new WeaponItem({
        ID: 5414,
        Component: "arena_helga/_Weapons/C_Paladin_Rec_Season",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PHOENIX_REC_GLORY: new WeaponItem({
        ID: 5415,
        Component: "arena_helga/_Weapons/C_Phoenix_Rec_Glory",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_C_PALADIN_REC_SAKURA: new WeaponItem({
        ID: 5416,
        Component: "arena_helga/_Weapons/C_Paladin_Rec_Sakura",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_PALADIN_REC_BLUE: new WeaponItem({
        ID: 5402,
        Component: "arena_helga/_Weapons/R_Paladin_Rec_Blue",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_DECEMBER: new WeaponItem({
        ID: 5405,
        Component: "arena_helga/_Weapons/R_December",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_PALADIN_REC_SUMMER_22: new WeaponItem({
        ID: 5408,
        Component: "arena_helga/_Weapons/R_Paladin_Rec_Summer_22",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_BASE_REC_APRIL: new WeaponItem({
        ID: 5411,
        Component: "arena_helga/_Weapons/R_base_Rec_April",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_PALADIN_REC_MYSTIC: new WeaponItem({
        ID: 5412,
        Component: "arena_helga/_Weapons/R_Paladin_Rec_Mystic",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_R_BASE_REC_BAMBOO: new WeaponItem({
        ID: 5417,
        Component: "arena_helga/_Weapons/R_Base_Rec_Bamboo",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_E_WHITE_STAR: new WeaponItem({
        ID: 5403,
        Component: "arena_helga/_Weapons/E_White_Star",
        Style: "SWORD_LONELY"
    }),
    WPN_HELGA_E_BLACK_STAR: new WeaponItem({
        ID: 5404,
        Component: "arena_helga/_Weapons/E_Black_Star",
        Style: "SWORD_LONELY"
    }),
    WPN_HONG_JOO_BASE: new WeaponItem({
        ID: 6400,
        Component: "arena_hong_joo/_Weapons/_base",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_EQUILIBRIST: new WeaponItem({
        ID: 6401,
        Component: "arena_hong_joo/_Weapons/C_Equilibrist",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_EQUILIBRIST_REC_SAKURA: new WeaponItem({
        ID: 6405,
        Component: "arena_hong_joo/_Weapons/C_Equilibrist_Rec_Sakura",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_BASE_REC_FLAME: new WeaponItem({
        ID: 6407,
        Component: "arena_hong_joo/_Weapons/C_base_Rec_Flame",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_BASE_REC_PILGRIM: new WeaponItem({
        ID: 6409,
        Component: "arena_hong_joo/_Weapons/C_Base_Rec_Pilgrim",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_BASE_REC_SEASON: new WeaponItem({
        ID: 6411,
        Component: "arena_hong_joo/_Weapons/C_Base_Rec_Season",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_BASE_REC_CUPID: new WeaponItem({
        ID: 6412,
        Component: "arena_hong_joo/_Weapons/C_Default_Cupid",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_BASE_REC_DARK: new WeaponItem({
        ID: 6415,
        Component: "arena_hong_joo/_Weapons/C_Base_Rec_Dark",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_C_EQUILIBRIST_REC_FROG: new WeaponItem({
        ID: 6416,
        Component: "arena_hong_joo/_Weapons/C_Equilibrist_Rec_Frog",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_EQUILIBRIST_REC_GOLD: new WeaponItem({
        ID: 6402,
        Component: "arena_hong_joo/_Weapons/R_Equilibrist_Rec_Gold",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_RED: new WeaponItem({
        ID: 6404,
        Component: "arena_hong_joo/_Weapons/R_Red",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_EQUILIBRIST_REC_SUMMER_22: new WeaponItem({
        ID: 6406,
        Component: "arena_hong_joo/_Weapons/R_Equilibrist_Rec_Summer_22",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_BASE_REC_APRIL: new WeaponItem({
        ID: 6408,
        Component: "arena_hong_joo/_Weapons/R_base_Rec_April",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_EQUILIBRIST_REC_MYSTIC: new WeaponItem({
        ID: 6410,
        Component: "arena_hong_joo/_Weapons/R_Equilibrist_Rec_Mystic",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_DEFAULT_REC_VAMP: new WeaponItem({
        ID: 6413,
        Component: "arena_hong_joo/_Weapons/R_Default_Rec_Vamp",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_R_EQUILIBRIST_REC_CNY: new WeaponItem({
        ID: 6414,
        Component: "arena_hong_joo/_Weapons/R_Equilibrist_Rec_CNY",
        Style: "TRIPLE_STAFF"
    }),
    WPN_HONG_JOO_E_FIRE_SHOW: new WeaponItem({
        ID: 6403,
        Component: "arena_hong_joo/_Weapons/E_FireShow",
        Style: "TRIPLE_STAFF"
    }),
    WPN_IRONCLAD_BASE: new WeaponItem({
        ID: 7400,
        Component: "arena_ironclad/_Weapons/_base",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_ORANGE: new WeaponItem({
        ID: 7401,
        Component: "arena_ironclad/_Weapons/C_Orange",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_RUST: new WeaponItem({
        ID: 7403,
        Component: "arena_ironclad/_Weapons/C_Rust",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_RUST_REC_BOSS: new WeaponItem({
        ID: 7406,
        Component: "arena_ironclad/_Weapons/C_Rust_Rec_Boss",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_BASE_REC_GLADIATOR: new WeaponItem({
        ID: 7407,
        Component: "arena_ironclad/_Weapons/C_Base_Rec_Gladiator",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_REC_SEASON: new WeaponItem({
        ID: 7409,
        Component: "arena_ironclad/_Weapons/C_Default_Rec_Season",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_FERVOR: new WeaponItem({
        ID: 7412,
        Component: "arena_ironclad/_Weapons/C_Fervor",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_FERVOR_REC_SEASON: new WeaponItem({
        ID: 7415,
        Component: "arena_ironclad/_Weapons/C_Fervor_Rec_Season",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_C_BASE_REC_HOLI: new WeaponItem({
        ID: 7413,
        Component: "arena_ironclad/_Weapons/C_Base_Rec_Holi",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_DEFAULT_REC_CHESS: new WeaponItem({
        ID: 7402,
        Component: "arena_ironclad/_Weapons/R_Default_Rec_Chess",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_PATTERN: new WeaponItem({
        ID: 7404,
        Component: "arena_ironclad/_Weapons/R_Pattern",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 7405,
        Component: "arena_ironclad/_Weapons/R_base_Rec_Summer_22",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_BASE_REC_APRIL: new WeaponItem({
        ID: 7410,
        Component: "arena_ironclad/_Weapons/R_base_Rec_April",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 7411,
        Component: "arena_ironclad/_Weapons/R_Default_Rec_Mystic",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_BASE_REC_VAMP: new WeaponItem({
        ID: 7414,
        Component: "arena_ironclad/_Weapons/R_Base_Rec_Vamp",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 7416,
        Component: "arena_ironclad/_Weapons/R_Base_Rec_Sakura",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_E_PUFFER: new WeaponItem({
        ID: 7408,
        Component: "arena_ironclad/_Weapons/E_Puffer",
        Style: "FISTS"
    }),
    WPN_IRONCLAD_E_MINOTAUR: new WeaponItem({
        ID: 7417,
        Component: "arena_ironclad/_Weapons/E_Minotaur",
        Style: "FISTS"
    }),
    WPN_JET_BASE: new WeaponItem({
        ID: 8400,
        Component: "arena_jet/_Weapons/_base",
    }),
    WPN_JET_C_GOLDEN: new WeaponItem({
        ID: 8401,
        Component: "arena_jet/_Weapons/C_Golden",
    }),
    WPN_JET_C_BASE_REC_PURPLE: new WeaponItem({
        ID: 8405,
        Component: "arena_jet/_Weapons/C_base_Rec_Purple",
    }),
    WPN_JET_C_GOLDEN_REC_WATER: new WeaponItem({
        ID: 8408,
        Component: "arena_jet/_Weapons/C_Golden_Rec_Water",
    }),
    WPN_JET_C_GOLDEN_REC_PINK: new WeaponItem({
        ID: 8409,
        Component: "arena_jet/_Weapons/C_Golden_Rec_Pink",
    }),
    WPN_JET_C_GOLDEN_REC_NOMAD: new WeaponItem({
        ID: 8410,
        Component: "arena_jet/_Weapons/C_Golden_Rec_Nomad",
    }),
    WPN_JET_C_GOLDEN_REC_SEASON: new WeaponItem({
        ID: 8412,
        Component: "arena_jet/_Weapons/C_Golden_Rec_Season",
    }),
    WPN_JET_C_GOLDEN_REC_BURGLAR: new WeaponItem({
        ID: 8413,
        Component: "arena_jet/_Weapons/C_Golden_Rec_Burglar",
    }),
    WPN_JET_R_GOLDEN_REC_BLACK: new WeaponItem({
        ID: 8402,
        Component: "arena_jet/_Weapons/R_Golden_Rec_Black",
    }),
    WPN_JET_R_BASE_REC_BROWN: new WeaponItem({
        ID: 8403,
        Component: "arena_jet/_Weapons/R_base_Rec_Brown",
    }),
    WPN_JET_R_GOLDEN_REC_SAKURA: new WeaponItem({
        ID: 8404,
        Component: "arena_jet/_Weapons/R_Golden_Rec_Sakura",
    }),
    WPN_JET_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 8407,
        Component: "arena_jet/_Weapons/R_base_Rec_Mystic",
    }),
    WPN_JET_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 8411,
        Component: "arena_jet/_Weapons/R_Default_Rec_Star",
    }),
    WPN_JET_R_GOLDEN_REC_VAMP: new WeaponItem({
        ID: 8414,
        Component: "arena_jet/_Weapons/R_Golden_Rec_Vamp",
    }),
    WPN_JET_R_GOLDEN_REC_SUMMER: new WeaponItem({
        ID: 8415,
        Component: "arena_jet/_Weapons/R_Golden_Rec_Summer",
    }),
    WPN_JET_R_GOLDEN_REC_APRIL: new WeaponItem({
        ID: 8416,
        Component: "arena_jet/_Weapons/R_Golden_Rec_April",
    }),
    WPN_JET_E_PRISM: new WeaponItem({
        ID: 8406,
        Component: "arena_jet/_Weapons/E_Prism",
    }),
    WPN_KIBO_BASE: new WeaponItem({
        ID: 9400,
        Component: "arena_kibo/_Weapons/_base",
        Style: "KATANA"
    }),
    WPN_KIBO_C_GRAY: new WeaponItem({
        ID: 9401,
        Component: "arena_kibo/_Weapons/C_Gray",
        Style: "KATANA"
    }),
    WPN_KIBO_C_ROSE: new WeaponItem({
        ID: 9404,
        Component: "arena_kibo/_Weapons/C_Rose",
        Style: "KATANA"
    }),
    WPN_KIBO_C_ORIENTAL: new WeaponItem({
        ID: 9406,
        Component: "arena_kibo/_Weapons/C_Oriental",
        Style: "KATANA"
    }),
    WPN_KIBO_C_GRAY_REC_CRANE: new WeaponItem({
        ID: 9409,
        Component: "arena_kibo/_Weapons/C_Gray_Rec_Crane",
        Style: "KATANA"
    }),
    WPN_KIBO_C_BASE_REC_SAKURA: new WeaponItem({
        ID: 9411,
        Component: "arena_kibo/_Weapons/C_Base_Rec_Sakura",
        Style: "KATANA"
    }),
    WPN_KIBO_C_GRAY_REC_SEASON: new WeaponItem({
        ID: 9412,
        Component: "arena_kibo/_Weapons/C_Gray_Rec_Season",
        Style: "KATANA"
    }),
    WPN_KIBO_C_GRAY_REC_VENOM: new WeaponItem({
        ID: 9413,
        Component: "arena_kibo/_Weapons/C_Gray_Rec_Venom",
        Style: "KATANA"
    }),
    WPN_KIBO_C_GRAY_REC_ECLIPSE: new WeaponItem({
        ID: 9414,
        Component: "arena_kibo/_Weapons/C_Gray_Rec_Venom",
        Style: "KATANA"
    }),
    WPN_KIBO_R_GRAY_REC_PURPLE: new WeaponItem({
        ID: 9402,
        Component: "arena_kibo/_Weapons/R_Gray_Rec_Purple",
        Style: "KATANA"
    }),
    WPN_KIBO_R_BASE_REC_BLACK: new WeaponItem({
        ID: 9405,
        Component: "arena_kibo/_Weapons/R_base_Rec_Black",
        Style: "KATANA"
    }),
    WPN_KIBO_R_GRAY_REC_SAKURA: new WeaponItem({
        ID: 9407,
        Component: "arena_kibo/_Weapons/R_Gray_Rec_Sakura",
        Style: "KATANA"
    }),
    WPN_KIBO_R_GRAY_REC_MYSTIC: new WeaponItem({
        ID: 9408,
        Component: "arena_kibo/_Weapons/R_Gray_Rec_Mystic",
        Style: "KATANA"
    }),
    WPN_KIBO_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 9410,
        Component: "arena_kibo/_Weapons/R_Gray_Rec_Star",
        Style: "KATANA"
    }),
    WPN_KIBO_E_RED_VAMPIRE: new WeaponItem({
        ID: 9403,
        Component: "arena_kibo/_Weapons/E_RedVampire",
        Style: "KATANA"
    }),
    WPN_KIBO_E_ECLIPSE: new WeaponItem({
        ID: 9415,
        Component: "arena_kibo/_Weapons/E_Eclipse",
        Style: "KATANA"
    }),
    WPN_LING_BASE: new WeaponItem({
        ID: 10400,
        Component: "arena_ling/_Weapons/_base",
        Style: "KATANA"
    }),
    WPN_LING_C_SAMURAI: new WeaponItem({
        ID: 10401,
        Component: "arena_ling/_Weapons/C_Samurai",
        Style: "KATANA"
    }),
    WPN_LING_C_RED: new WeaponItem({
        ID: 10403,
        Component: "arena_ling/_Weapons/C_Red",
        Style: "KATANA"
    }),
    WPN_LING_C_SAMURAI_REC_GOLD: new WeaponItem({
        ID: 10404,
        Component: "arena_ling/_Weapons/C_Samurai_Rec_Gold",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_RAVEN: new WeaponItem({
        ID: 10407,
        Component: "arena_ling/_Weapons/C_base_Rec_Raven",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_SEASON: new WeaponItem({
        ID: 10409,
        Component: "arena_ling/_Weapons/C_Base_Rec_Season",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_RONIN: new WeaponItem({
        ID: 10412,
        Component: "arena_ling/_Weapons/C_base_Rec_Ronin",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_BLACK: new WeaponItem({
        ID: 10413,
        Component: "arena_ling/_Weapons/C_base_Rec_Black",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_RONIN_SEASON: new WeaponItem({
        ID: 10414,
        Component: "arena_ling/_Weapons/C_base_Rec_Ronin_Season",
        Style: "KATANA"
    }),
    WPN_LING_C_BASE_REC_BLUE: new WeaponItem({
        ID: 10416,
        Component: "arena_ling/_Weapons/C_base_Rec_Blue",
        Style: "KATANA"
    }),
    WPN_LING_R_RED_BLADE: new WeaponItem({
        ID: 10402,
        Component: "arena_ling/_Weapons/R_RedBlade",
        Style: "KATANA"
    }),
    WPN_LING_R_BASE_REC_DARK: new WeaponItem({
        ID: 10406,
        Component: "arena_ling/_Weapons/R_base_Rec_Dark",
        Style: "KATANA"
    }),
    WPN_LING_R_SAMURAI_REC_SUMMER_22: new WeaponItem({
        ID: 10408,
        Component: "arena_ling/_Weapons/R_Samurai_Rec_Summer_22",
        Style: "KATANA"
    }),
    WPN_LING_R_BASE_REC_APRIL: new WeaponItem({
        ID: 10410,
        Component: "arena_ling/_Weapons/R_base_Rec_April",
        Style: "KATANA"
    }),
    WPN_LING_R_SAMURAI_REC_MYSTIC: new WeaponItem({
        ID: 10411,
        Component: "arena_ling/_Weapons/R_Samurai_Rec_Mystic",
        Style: "KATANA"
    }),
    WPN_LING_R_SAMURAI_REC_SAKURA: new WeaponItem({
        ID: 10415,
        Component: "arena_ling/_Weapons/R_Samurai_Rec_Sakura",
        Style: "KATANA"
    }),
    WPN_LING_E_SHADOW_EDGE: new WeaponItem({
        ID: 10405,
        Component: "arena_ling/_Weapons/E_Shadow_Edge",
        Style: "KATANA"
    }),
    WPN_LIQUIDATOR_BASE: new WeaponItem({
        ID: 11400,
        Component: "arena_liquidator/_Weapons/_base",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_PURPLE: new WeaponItem({
        ID: 11401,
        Component: "arena_liquidator/_Weapons/C_Purple",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_GOLD: new WeaponItem({
        ID: 11402,
        Component: "arena_liquidator/_Weapons/C_Gold",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_WHITE: new WeaponItem({
        ID: 11403,
        Component: "arena_liquidator/_Weapons/C_White",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_BASE_REC_BOSS: new WeaponItem({
        ID: 11404,
        Component: "arena_liquidator/_Weapons/C_Base_Rec_Boss",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_GOLD_REC_VALKYRIE: new WeaponItem({
        ID: 11410,
        Component: "arena_liquidator/_Weapons/C_Gold_Rec_Valkyrie",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_GOLD_REC_BRONZE: new WeaponItem({
        ID: 11405,
        Component: "arena_liquidator/_Weapons/R_Gold_Rec_Bronze",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_BASE_REC_RED: new WeaponItem({
        ID: 11407,
        Component: "arena_liquidator/_Weapons/R_base_Rec_Red",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_GOLD_REC_SAKURA: new WeaponItem({
        ID: 11408,
        Component: "arena_liquidator/_Weapons/R_Gold_Rec_Sakura",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_GOLD_REC_MYSTIC: new WeaponItem({
        ID: 11409,
        Component: "arena_liquidator/_Weapons/R_Gold_Rec_Mystic",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_GOLD_REC_STAR: new WeaponItem({
        ID: 11412,
        Component: "arena_liquidator/_Weapons/R_Gold_Rec_Star",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_R_GOLD_REC_SUMMER: new WeaponItem({
        ID: 11415,
        Component: "arena_liquidator/_Weapons/R_Gold_Rec_Summer",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_E_OBSIDIANS: new WeaponItem({
        ID: 11406,
        Component: "arena_liquidator/_Weapons/E_Obsidians",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_GOLD_REC_VALKYRIE_SEASON: new WeaponItem({
        ID: 11411,
        Component: "arena_liquidator/_Weapons/C_Gold_Rec_Valkyrie_Season",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_GOLD_REC_JOUST: new WeaponItem({
        ID: 11414,
        Component: "arena_liquidator/_Weapons/C_Gold_Rec_Joust",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_BASE_REC_FORGED: new WeaponItem({
        ID: 11413,
        Component: "arena_liquidator/_Weapons/C_Base_Rec_Forged",
        Style: "SWORDS"
    }),
    WPN_LIQUIDATOR_C_GOLD_REC_SEASON: new WeaponItem({
        ID: 11416,
        Component: "arena_liquidator/_Weapons/C_Gold_Rec_Season",
        Style: "SWORDS"
    }),
    WPN_LYNX_BASE: new WeaponItem({
        ID: 12400,
        Component: "arena_lynx/_Weapons/_base",
    }),
    WPN_LYNX_C_ORIGINAL: new WeaponItem({
        ID: 12402,
        Component: "arena_lynx/_Weapons/C_Original",
    }),
    WPN_LYNX_C_BASE_REC_FANCY: new WeaponItem({
        ID: 12406,
        Component: "arena_lynx/_Weapons/C_base_Rec_Fancy",
    }),
    WPN_LYNX_C_ORIGINAL_REC_WHITE: new WeaponItem({
        ID: 12408,
        Component: "arena_lynx/_Weapons/C_Original_Rec_White",
    }),
    WPN_LYNX_C_BASE_REC_MAFIA: new WeaponItem({
        ID: 12410,
        Component: "arena_lynx/_Weapons/C_Base_Rec_Mafia",
    }),
    WPN_LYNX_C_BASE_REC_SEASON: new WeaponItem({
        ID: 12412,
        Component: "arena_lynx/_Weapons/C_Base_Rec_Season",
    }),
    WPN_LYNX_C_BASE_REC_VIOLET: new WeaponItem({
        ID: 12415,
        Component: "arena_lynx/_Weapons/C_Base_Rec_Violet",
    }),
    WPN_LYNX_R_RICH: new WeaponItem({
        ID: 12401,
        Component: "arena_lynx/_Weapons/R_Rich",
    }),
    WPN_LYNX_R_BASE_BLACK: new WeaponItem({
        ID: 12404,
        Component: "arena_lynx/_Weapons/R_base_Black",
    }),
    WPN_LYNX_R_BASE_SAKURA: new WeaponItem({
        ID: 12405,
        Component: "arena_lynx/_Weapons/R_base_Rec_Sakura",
    }),
    WPN_LYNX_R_BASE_MYSTIC: new WeaponItem({
        ID: 12407,
        Component: "arena_lynx/_Weapons/R_base_Rec_Mystic",
    }),
    WPN_LYNX_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 12409,
        Component: "arena_lynx/_Weapons/R_Default_Rec_Star",
    }),
    WPN_LYNX_R_DEFAULT_REC_VAMP: new WeaponItem({
        ID: 12413,
        Component: "arena_lynx/_Weapons/R_Default_Rec_Vamp",
    }),
    WPN_LYNX_R_BASE_SUMMER: new WeaponItem({
        ID: 12414,
        Component: "arena_lynx/_Weapons/R_base_Rec_Summer",
    }),
    WPN_LYNX_R_BASE_REC_APRIL: new WeaponItem({
        ID: 12416,
        Component: "arena_lynx/_Weapons/R_base_Rec_April",
    }),
    WPN_LYNX_E_LEGACY: new WeaponItem({
        ID: 12403,
        Component: "arena_lynx/_Weapons/E_Legacy",
    }),
    WPN_LYNX_E_HOOD: new WeaponItem({
        ID: 12411,
        Component: "arena_lynx/_Weapons/E_Hood",
    }),
    WPN_MARCUS_BASE: new WeaponItem({
        ID: 13400,
        Component: "arena_marcus/_Weapons/_base",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_LORD: new WeaponItem({
        ID: 13401,
        Component: "arena_marcus/_Weapons/C_Lord",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_WINY: new WeaponItem({
        ID: 13405,
        Component: "arena_marcus/_Weapons/C_Winy",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_ROYAL: new WeaponItem({
        ID: 13407,
        Component: "arena_marcus/_Weapons/C_Royal",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_BASE_REC_MAGMA: new WeaponItem({
        ID: 13410,
        Component: "arena_marcus/_Weapons/C_Base_Rec_Magma",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_LORD_REC_FALL: new WeaponItem({
        ID: 13411,
        Component: "arena_marcus/_Weapons/C_Lord_Rec_Fall",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_BASE_REC_VETERAN: new WeaponItem({
        ID: 13413,
        Component: "arena_marcus/_Weapons/C_Base_Rec_Veteran",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_BASE_REC_SEASON: new WeaponItem({
        ID: 13414,
        Component: "arena_marcus/_Weapons/C_Base_Rec_Season",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_BASE_REC_NOUVEAU: new WeaponItem({
        ID: 13420,
        Component: "arena_marcus/_Weapons/C_Base_Rec_Nouveau",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_C_LORD_REC_GLITCH: new WeaponItem({
        ID: 13415,
        Component: "arena_marcus/_Weapons/C_Lord_Rec_Glitch",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_BROWN: new WeaponItem({
        ID: 13402,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Brown",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_BASE_REC_BLACK: new WeaponItem({
        ID: 13406,
        Component: "arena_marcus/_Weapons/R_base_Rec_Black",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_BASE_REC_BAMBOO: new WeaponItem({
        ID: 13419,
        Component: "arena_marcus/_Weapons/R_base_Rec_Bamboo",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_APRIL: new WeaponItem({
        ID: 13421,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_April",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_SAKURA: new WeaponItem({
        ID: 13408,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Sakura",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_MYSTIC: new WeaponItem({
        ID: 13409,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Mystic",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_STAR: new WeaponItem({
        ID: 13412,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Star",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_VAMP: new WeaponItem({
        ID: 13416,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Vamp",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_R_LORD_REC_SUMMER: new WeaponItem({
        ID: 13418,
        Component: "arena_marcus/_Weapons/R_Lord_Rec_Summer",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_NINJA_PARTY: new WeaponItem({
        ID: 13417,
        Component: "arena_marcus/_Weapons/Ninja_party",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_E_KNIGHT: new WeaponItem({
        ID: 13403,
        Component: "arena_marcus/_Weapons/E_Knight",
        Style: "GIANT_SWORD"
    }),
    WPN_MARCUS_E_LAVA: new WeaponItem({
        ID: 13404,
        Component: "arena_marcus/_Weapons/E_Lava",
        Style: "GIANT_SWORD"
    }),
    WPN_MIDNIGHT_BASE: new WeaponItem({
        ID: 14400,
        Component: "arena_midnight/_Weapons/_base",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_GHOST: new WeaponItem({
        ID: 14401,
        Component: "arena_midnight/_Weapons/C_Ghost",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_BLUE: new WeaponItem({
        ID: 14404,
        Component: "arena_midnight/_Weapons/C_Blue",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_BASE_REC_WITCH: new WeaponItem({
        ID: 14407,
        Component: "arena_midnight/_Weapons/C_base_Rec_Witch",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_BASE_REC_SEASON: new WeaponItem({
        ID: 14409,
        Component: "arena_midnight/_Weapons/C_base_Rec_Season",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_ASSASSIN: new WeaponItem({
        ID: 14411,
        Component: "arena_midnight/_Weapons/C_Assassin",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_ASSASSIN_REC_WHITE: new WeaponItem({
        ID: 14412,
        Component: "arena_midnight/_Weapons/C_Assassin_Rec_White",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_ASSASSIN_REC_SEASON: new WeaponItem({
        ID: 14413,
        Component: "arena_midnight/_Weapons/C_Assassin_Rec_Season",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_C_BASE_REC_SHINOBI: new WeaponItem({
        ID: 14416,
        Component: "arena_midnight/_Weapons/C_base_Rec_Shinobi",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_DEFAULT_REC_GOLDENDARK: new WeaponItem({
        ID: 14402,
        Component: "arena_midnight/_Weapons/R_Default_Rec_GoldenDark",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_BASE_REC_RED: new WeaponItem({
        ID: 14405,
        Component: "arena_midnight/_Weapons/R_base_Rec_Red",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 14406,
        Component: "arena_midnight/_Weapons/R_base_Rec_Summer_22",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_BASE_REC_APRIL: new WeaponItem({
        ID: 14408,
        Component: "arena_midnight/_Weapons/R_base_Rec_April",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 14410,
        Component: "arena_midnight/_Weapons/R_Default_Rec_Mystic",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 14414,
        Component: "arena_midnight/_Weapons/R_Base_Rec_Sakura",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_E_TRIDENT: new WeaponItem({
        ID: 14403,
        Component: "arena_midnight/_Weapons/E_Trident",
        Style: "SAI"
    }),
    WPN_MIDNIGHT_E_FEATHER: new WeaponItem({
        ID: 14415,
        Component: "arena_midnight/_Weapons/E_Feather",
        Style: "SAI"
    }),
    WPN_MONK_BASE: new WeaponItem({
        ID: 15400,
        Component: "arena_monk/_Weapons/_base",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_BLUE: new WeaponItem({
        ID: 15401,
        Component: "arena_monk/_Weapons/C_Blue",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_Cursed: new WeaponItem({
        ID: 15402,
        Component: "arena_monk/_Weapons/E_Cursed",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_CURSED_REC_WHITE: new WeaponItem({
        ID: 15405,
        Component: "arena_monk/_Weapons/C_Cursed_Rec_White",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_REC_ROYAL: new WeaponItem({
        ID: 15409,
        Component: "arena_monk/_Weapons/C_Rec_Royal",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_BASE_REC_CREEPY: new WeaponItem({
        ID: 15410,
        Component: "arena_monk/_Weapons/C_Base_Rec_Creepy",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_ROYAL_REC_GOLD: new WeaponItem({
        ID: 15411,
        Component: "arena_monk/_Weapons/C_Royal_Rec_Gold",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_BASE_REC_MOTH: new WeaponItem({
        ID: 15413,
        Component: "arena_monk/_Weapons/C_Base_Rec_Moth",
        Style: "GUANDAO"
    }),
    WPN_MONK_C_NEATBLADE_REC_SEASON: new WeaponItem({
        ID: 15414,
        Component: "arena_monk/_Weapons/C_NeatBlade_Rec_Season",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEAT_BLADE: new WeaponItem({
        ID: 15403,
        Component: "arena_monk/_Weapons/R_NeatBlade",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEATBLADE_REC_RED: new WeaponItem({
        ID: 15406,
        Component: "arena_monk/_Weapons/R_NeatBlade_Rec_Red",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEATBLADE_REC_VAMP: new WeaponItem({
        ID: 15415,
        Component: "arena_monk/_Weapons/R_NeatBlade_Rec_Vamp",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 15407,
        Component: "arena_monk/_Weapons/R_base_Rec_Sakura",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEATBLADE_REC_MYSTIC: new WeaponItem({
        ID: 15408,
        Component: "arena_monk/_Weapons/R_NeatBlade_Rec_Mystic",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEATBLADE_REC_STAR: new WeaponItem({
        ID: 15412,
        Component: "arena_monk/_Weapons/R_NeatBlade_Rec_Star",
        Style: "GUANDAO"
    }),
    WPN_MONK_R_NEATBLADE_REC_APRIL: new WeaponItem({
        ID: 15416,
        Component: "arena_monk/_Weapons/R_NeatBlade_Rec_April",
        Style: "GUANDAO"
    }),
    WPN_MONK_E_DRUID: new WeaponItem({
        ID: 15404,
        Component: "arena_monk/_Weapons/E_Druid",
        Style: "GUANDAO"
    }),
    WPN_MONKEY_KING_BASE: new WeaponItem({
        ID: 16400,
        Component: "arena_monkey_king/_Weapons/_base",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_STRANGER: new WeaponItem({
        ID: 16401,
        Component: "arena_monkey_king/_Weapons/C_Stranger",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_BASE_REC_BLAZE: new WeaponItem({
        ID: 16406,
        Component: "arena_monkey_king/_Weapons/C_base_Rec_Blaze",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_BASE_REC_CRUEL: new WeaponItem({
        ID: 16407,
        Component: "arena_monkey_king/_Weapons/C_base_Rec_Cruel",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_Base_Rec_Season: new WeaponItem({
        ID: 16409,
        Component: "arena_monkey_king/_Weapons/C_Base_Rec_Season",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_BASE_REC_SYLVAN: new WeaponItem({
        ID: 16411,
        Component: "arena_monkey_king/_Weapons/C_base_Rec_Spriggan",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_BASE_REC_DRAGON: new WeaponItem({
        ID: 16413,
        Component: "arena_monkey_king/_Weapons/C_base_Rec_Dragon",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_C_BASE_REC_SEASON_2: new WeaponItem({
        ID: 16417,
        Component: "arena_monkey_king/_Weapons/C_base_Rec_Season_2",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_DEFAULT_REC_BLUE: new WeaponItem({
        ID: 16402,
        Component: "arena_monkey_king/_Weapons/R_Default_Rec_Blue",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_BASE_REC_PURPLE: new WeaponItem({
        ID: 16404,
        Component: "arena_monkey_king/_Weapons/R_base_Rec_Purple",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 16405,
        Component: "arena_monkey_king/_Weapons/R_base_Rec_Sakura",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_BASE_REC_APRIL: new WeaponItem({
        ID: 16408,
        Component: "arena_monkey_king/_Weapons/R_base_Rec_April",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 16410,
        Component: "arena_monkey_king/_Weapons/R_Default_Rec_Mystic",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_BASE_REC_VAMP: new WeaponItem({
        ID: 16412,
        Component: "arena_monkey_king/_Weapons/R_base_Rec_Vamp",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 16414,
        Component: "arena_monkey_king/_Weapons/R_base_Rec_Summer",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_E_NEPHRITIS: new WeaponItem({
        ID: 16403,
        Component: "arena_monkey_king/_Weapons/E_Nephritis",
        Style: "STAFF"
    }),
    WPN_MONKEY_KING_E_CRYSTAL: new WeaponItem({
        ID: 16416,
        Component: "arena_monkey_king/_Weapons/E_Crystal",
        Style: "STAFF"
    }),
    WPN_SARGE_BASE: new WeaponItem({
        ID: 17400,
        Component: "arena_sarge/_Weapons/_base",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_DARK: new WeaponItem({
        ID: 17401,
        Component: "arena_sarge/_Weapons/C_Dark",
        Style: "HAMMERS"
    }),
    WPN_SARGE_E_JAILER: new WeaponItem({
        ID: 17405,
        Component: "arena_sarge/_Weapons/C_base_Rec_Jailer",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_JAILER_REC_BOSS: new WeaponItem({
        ID: 17407,
        Component: "arena_sarge/_Weapons/C_Jailer_Rec_Boss",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_BASE_REC_VIKING: new WeaponItem({
        ID: 17408,
        Component: "arena_sarge/_Weapons/C_base_Rec_Viking",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_BASE_REC_SEASON: new WeaponItem({
        ID: 17410,
        Component: "arena_sarge/_Weapons/C_base_Rec_Season",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_PATTERNS_REC_CHITIN: new WeaponItem({
        ID: 17413,
        Component: "arena_sarge/_Weapons/C_Patterns_Rec_Chitin",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_PATTERNS_REC_WINTER: new WeaponItem({
        ID: 17414,
        Component: "arena_sarge/_Weapons/C_Patterns_Rec_Winter",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_PATTERNS_REC_SEASON: new WeaponItem({
        ID: 17416,
        Component: "arena_sarge/_Weapons/C_Patterns_Rec_Season",
        Style: "HAMMERS"
    }),
    WPN_SARGE_C_PATTERNS_REC_SUNNY: new WeaponItem({
        ID: 17417,
        Component: "arena_sarge/_Weapons/C_Patterns_Rec_Sunny",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS: new WeaponItem({
        ID: 17402,
        Component: "arena_sarge/_Weapons/R_Patterns",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS_REC_RED: new WeaponItem({
        ID: 17404,
        Component: "arena_sarge/_Weapons/R_Patterns_Rec_Red",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 17406,
        Component: "arena_sarge/_Weapons/R_base_Rec_Summer_22",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS_REC_APRIL: new WeaponItem({
        ID: 17409,
        Component: "arena_sarge/_Weapons/R_Patterns_Rec_April",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS_REC_MYSTIC: new WeaponItem({
        ID: 17411,
        Component: "arena_sarge/_Weapons/R_Patterns_Rec_Mystic",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS_REC_VAMP: new WeaponItem({
        ID: 17415,
        Component: "arena_sarge/_Weapons/R_Patterns_Rec_Vamp",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_PATTERNS_REC_STAR: new WeaponItem({
        ID: 17515,
        Component: "arena_sarge/_Weapons/R_Base_Rec_Star",
        Style: "HAMMERS"
    }),
    WPN_SARGE_R_BASE_REC_BAMBOO: new WeaponItem({
        ID: 17516,
        Component: "arena_sarge/_Weapons/R_Base_Rec_Bamboo",
        Style: "HAMMERS"
    }),
    WPN_SARGE_E_BURN: new WeaponItem({
        ID: 17403,
        Component: "arena_sarge/_Weapons/E_Burn",
        Style: "HAMMERS"
    }),
    WPN_SARGE_E_CAGE: new WeaponItem({
        ID: 17412,
        Component: "arena_sarge/_Weapons/E_Cage",
        Style: "HAMMERS"
    }),
    WPN_YUKKA_BASE: new WeaponItem({
        ID: 18400,
        Component: "arena_yukka/_Weapons/_base",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_RED: new WeaponItem({
        ID: 18402,
        Component: "arena_yukka/_Weapons/C_Red",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_CAT: new WeaponItem({
        ID: 18404,
        Component: "arena_yukka/_Weapons/C_Cat",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_MONOGRAMS_REC_WAYFARER: new WeaponItem({
        ID: 18408,
        Component: "arena_yukka/_Weapons/C_Monograms_Rec_Wayfarer",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_CAT_REC_BLACK: new WeaponItem({
        ID: 18410,
        Component: "arena_yukka/_Weapons/C_Cat_Rec_Black",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_BASE_REC_REBEL: new WeaponItem({
        ID: 18412,
        Component: "arena_yukka/_Weapons/C_Base_Rec_Rebel",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_BASE_REC_SEASON: new WeaponItem({
        ID: 18414,
        Component: "arena_yukka/_Weapons/C_Base_Rec_Season",
        Style: "DADAO"
    }),
    WPN_YUKKA_C_MONOGRAMS_REC_FLOWER: new WeaponItem({
        ID: 18416,
        Component: "arena_yukka/_Weapons/C_Monograms_Rec_Flower",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_MONOGRAMS: new WeaponItem({
        ID: 18401,
        Component: "arena_yukka/_Weapons/R_Monograms",
        Style: "DADAO"
    }),
    R_MONOGRAMS_REC_ANTIQUE: new WeaponItem({
        ID: 18405,
        Component: "arena_yukka/_Weapons/R_Monograms_Rec_Antique",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 18406,
        Component: "arena_yukka/_Weapons/R_base_Rec_Summer_22",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_MONOGRAMS_REC_APRIL: new WeaponItem({
        ID: 18407,
        Component: "arena_yukka/_Weapons/R_Monograms_Rec_April",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_MONOGRAMS_REC_MYSTIC: new WeaponItem({
        ID: 18409,
        Component: "arena_yukka/_Weapons/R_Monograms_Rec_Mystic",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_DEFAULT_REC_VALENTINE: new WeaponItem({
        ID: 18411,
        Component: "arena_yukka/_Weapons/R_Default_Rec_Valentine",
        Style: "DADAO"
    }),
    WPN_YUKKA_R_BASE_REC_COBRA: new WeaponItem({
        ID: 18415,
        Component: "arena_yukka/_Weapons/R_Base_Rec_Cobra",
        Style: "DADAO"
    }),
    WPN_YUKKA_E_WIND: new WeaponItem({
        ID: 18403,
        Component: "arena_yukka/_Weapons/E_Wind",
        Style: "DADAO"
    }),
    WPN_VIPER_BASE: new WeaponItem({
        ID: 19400,
        Component: "arena_viper/_Weapons/_base",
        Style: "KATAR"
    }),
    WPN_VIPER_C_BASE_REC_BRAT: new WeaponItem({
        ID: 19404,
        Component: "arena_viper/_Weapons/C_base_Rec_Brat",
        Style: "KATAR"
    }),
    WPN_VIPER_C_BASE_REC_GRAFFITI: new WeaponItem({
        ID: 19405,
        Component: "arena_viper/_Weapons/C_base_Rec_Graffiti",
        Style: "KATAR"
    }),
    WPN_VIPER_C_BASE_REC_VAMPIRE: new WeaponItem({
        ID: 19407,
        Component: "arena_viper/_Weapons/C_base_Rec_Vampire",
        Style: "KATAR"
    }),
    WPN_VIPER_C_BASE_REC_MOBSTER: new WeaponItem({
        ID: 19410,
        Component: "arena_viper/_Weapons/C_Base_Rec_Mobster",
        Style: "KATAR"
    }),
    WPN_VIPER_C_BASE_REC_SEASON: new WeaponItem({
        ID: 19411,
        Component: "arena_viper/_Weapons/C_Base_Rec_Season",
        Style: "KATAR"
    }),
    WPN_VIPER_C_MOBSTER_REC_GLOW: new WeaponItem({
        ID: 19413,
        Component: "arena_viper/_Weapons/C_Mobster_Rec_Glow",
        Style: "KATAR"
    }),
    WPN_VIPER_BASE_REC_R_SNAKE: new WeaponItem({
        ID: 19401,
        Component: "arena_viper/_Weapons/R_base_Rec_Snake",
        Style: "KATAR"
    }),
    WPN_VIPER_BASE_REC_R_PURPLE: new WeaponItem({
        ID: 19402,
        Component: "arena_viper/_Weapons/R_base_Rec_Purple",
        Style: "KATAR"
    }),
    WPN_VIPER_BASE_REC_R_SAKURA: new WeaponItem({
        ID: 19403,
        Component: "arena_viper/_Weapons/R_base_Rec_Sakura",
        Style: "KATAR"
    }),
    WPN_VIPER_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 19406,
        Component: "arena_viper/_Weapons/R_base_Rec_Mystic",
        Style: "KATAR"
    }),
    WPN_VIPER_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 19409,
        Component: "arena_viper/_Weapons/R_Default_Rec_Star",
        Style: "KATAR"
    }),
    WPN_VIPER_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 19412,
        Component: "arena_viper/_Weapons/R_base_Rec_Summer",
        Style: "KATAR"
    }),
    WPN_VIPER_E_CHARGEBOOM: new WeaponItem({
        ID: 19408,
        Component: "arena_viper/_Weapons/E_Chargeboom",
        Style: "KATAR"
    }),
    WPN_LEGION_KING_BASE: new WeaponItem({
        ID: 20400,
        Component: "arena_legion_king/_Weapons/_base",
    }),
    WPN_LEGION_KING_C_BASE_REC_VINY: new WeaponItem({
        ID: 20401,
        Component: "arena_legion_king/_Weapons/C_base_Rec_Viny",
    }),
    WPN_LEGION_KING_C_BASE_REC_BOSS: new WeaponItem({
        ID: 20403,
        Component: "arena_legion_king/_Weapons/C_Base_Rec_Boss",
    }),
    WPN_LEGION_KING_C_DEFAULT_REC_BONE: new WeaponItem({
        ID: 20405,
        Component: "arena_legion_king/_Weapons/C_base_Rec_Bone",
    }),
    WPN_LEGION_KING_C_BONE_REC_LICH: new WeaponItem({
        ID: 20406,
        Component: "arena_legion_king/_Weapons/C_Bone_Rec_Lich",
    }),
    WPN_LEGION_KING_C_BASE_REC_PRINCE: new WeaponItem({
        ID: 20408,
        Component: "arena_legion_king/_Weapons/C_base_Rec_Prince",
    }),
    WPN_LEGION_KING_C_BASE_REC_SEASON: new WeaponItem({
        ID: 20410,
        Component: "arena_legion_king/_Weapons/C_Base_Rec_Season",
    }),
    WPN_LEGION_KING_C_DEFAULT_REC_CASTLE: new WeaponItem({
        ID: 20413,
        Component: "arena_legion_king/_Weapons/C_Default_Rec_Season",
    }),
    WPN_LEGION_KING_R_BASE_REC_SUMMER_22: new WeaponItem({
        ID: 20402,
        Component: "arena_legion_king/_Weapons/R_base_Rec_Summer_22",
    }),
    WPN_LEGION_KING_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 20404,
        Component: "arena_legion_king/_Weapons/R_base_Rec_Mystic",
    }),
    WPN_LEGION_KING_R_DEFAULT_REC_VAMPIRE: new WeaponItem({
        ID: 20409,
        Component: "arena_legion_king/_Weapons/R_Default_Rec_Vampire",
    }),
    WPN_LEGION_KING_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 20411,
        Component: "arena_legion_king/_Weapons/R_Default_Rec_Star",
    }),
    WPN_LEGION_KING_E_WITCHBLADE: new WeaponItem({
        ID: 20407,
        Component: "arena_legion_king/_Weapons/E_Witchblade",
    }),
    WPN_LEGION_KING_E_ABYSSBLADE: new WeaponItem({
        ID: 20412,
        Component: "arena_legion_king/_Weapons/E_Abyssblade",
    }),
    WPN_LEGION_KING_E_CASTLE: new WeaponItem({
        ID: 20414,
        Component: "arena_legion_king/_Weapons/E_Castle",
    }),
    WPN_BUTCHER_BASE: new WeaponItem({
        ID: 21400,
        Component: "arena_butcher/_Weapons/_base",
    }),
    WPN_BUTCHER_C_BASE_REC_PURPLE: new WeaponItem({
        ID: 21401,
        Component: "arena_butcher/_Weapons/C_base_Rec_Purple",
    }),
    WPN_BUTCHER_C_BASE_REC_BIKER: new WeaponItem({
        ID: 21405,
        Component: "arena_butcher/_Weapons/C_Default_Rec_Biker",
    }),
    WPN_BUTCHER_C_BASE_REC_MOGWAI: new WeaponItem({
        ID: 21403,
        Component: "arena_butcher/_Weapons/C_Base_Rec_Mogwai",
    }),
    WPN_BUTCHER_C_BASE_REC_SEASON: new WeaponItem({
        ID: 21406,
        Component: "arena_butcher/_Weapons/C_Base_Rec_Season",
    }),
    WPN_BUTCHER_C_BASE_REC_KHAN: new WeaponItem({
        ID: 21408,
        Component: "arena_butcher/_Weapons/C_Base_Rec_Khan",
    }),
    WPN_BUTCHER_C_BASE_REC_SEASON2: new WeaponItem({
        ID: 21411,
        Component: "arena_butcher/_Weapons/C_Base_Rec_Season2",
    }),
    WPN_BUTCHER_C_BASE_REC_SUSHI: new WeaponItem({
        ID: 21412,
        Component: "arena_butcher/_Weapons/C_Base_Rec_Sushi",
    }),
    WPN_BUTCHER_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 21402,
        Component: "arena_butcher/_Weapons/R_Default_Rec_Mystic",
    }),
    WPN_BUTCHER_R_BASE_REC_APRIL: new WeaponItem({
        ID: 21404,
        Component: "arena_butcher/_Weapons/R_base_Rec_April",
    }),
    WPN_BUTCHER_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 21407,
        Component: "arena_butcher/_Weapons/R_Default_Rec_Star",
    }),
    WPN_BUTCHER_R_BASE_REC_COBRA: new WeaponItem({
        ID: 21410,
        Component: "arena_butcher/_Weapons/R_Base_Rec_Cobra",
    }),
    WPN_BUTCHER_E_WOLF: new WeaponItem({
        ID: 21409,
        Component: "arena_butcher/_Weapons/E_Wolf",
    }),
    WPN_BUTCHER_L_GORE: new WeaponItem({
        ID: 21413,
        Component: "arena_butcher/_Weapons/L_Gore",
    }),
    WPN_ITU_BASE: new WeaponItem({
        ID: 22400,
        Component: "arena_itu/_Weapons/_base",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_C_BASE_REC_RED: new WeaponItem({
        ID: 22401,
        Component: "arena_itu/_Weapons/C_Base_Rec_Red",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_C_BASE_REC_DEMON: new WeaponItem({
        ID: 22402,
        Component: "arena_itu/_Weapons/C_Base_Rec_Demon",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_C_BASE_REC_STAR: new WeaponItem({
        ID: 22407,
        Component: "arena_itu/_Weapons/C_Base_Rec_Star",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_C_REC_SEASON: new WeaponItem({
        ID: 22408,
        Component: "arena_itu/_Weapons/C_Rec_Season",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_C_BASE_REC_MASTER: new WeaponItem({
        ID: 22409,
        Component: "arena_itu/_Weapons/C_Base_Rec_Master",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_R_BASE_REC_APRIl: new WeaponItem({
        ID: 22403,
        Component: "arena_itu/_Weapons/R_base_Rec_April",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 22405,
        Component: "arena_itu/_Weapons/R_Default_Rec_Mystic",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 22406,
        Component: "arena_itu/_Weapons/R_Default_Rec_Star",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 22410,
        Component: "arena_itu/_Weapons/R_base_Rec_Summer",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_R_BASE_REC_SAKURA: new WeaponItem({
        ID: 22412,
        Component: "arena_itu/_Weapons/R_base_Rec_Sakura",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_E_VORTEX: new WeaponItem({
        ID: 22404,
        Component: "arena_itu/_Weapons/E_Vortex",
        Style: "KATANA_SCABBARD"
    }),
    WPN_ITU_E_COSMIC: new WeaponItem({
        ID: 22411,
        Component: "arena_itu/_Weapons/E_Cosmic",
        Style: "KATANA_SCABBARD"
    }),
    WPN_YUNLIN_BASE: new WeaponItem({
        ID: 23400,
        Component: "arena_yunlin/_Weapons/_base",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_HAZY: new WeaponItem({
        ID: 23402,
        Component: "arena_yunlin/_Weapons/C_Base_Rec_Hazy",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_SPRING: new WeaponItem({
        ID: 23414,
        Component: "arena_yunlin/_Weapons/C_Base_Rec_Spring",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_BRIDE: new WeaponItem({
        ID: 23406,
        Component: "arena_yunlin/_Weapons/C_Base_Rec_Bride",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_SEASON: new WeaponItem({
        ID: 23408,
        Component: "arena_yunlin/_Weapons/C_Base_Rec_Season",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_INDIAN: new WeaponItem({
        ID: 23409,
        Component: "arena_yunlin/_Weapons/C_base_Rec_Indian",
        Style: "STAFF"
    }),
    WPN_YUNLIN_C_BASE_REC_WINTER: new WeaponItem({
        ID: 23412,
        Component: "arena_yunlin/_Weapons/C_base_Rec_Winter",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_BASE_REC_APRIL: new WeaponItem({
        ID: 23401,
        Component: "arena_yunlin/_Weapons/R_base_Rec_April",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 23403,
        Component: "arena_yunlin/_Weapons/R_Default_Rec_Mystic",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_DEFAULT_REC_DECEIT: new WeaponItem({
        ID: 23404,
        Component: "arena_yunlin/_Weapons/R_Default_Rec_Deceit",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_DEFAULT_REC_STAR: new WeaponItem({
        ID: 23405,
        Component: "arena_yunlin/_Weapons/R_Default_Rec_Star",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_BASE_REC_VAMP: new WeaponItem({
        ID: 23410,
        Component: "arena_yunlin/_Weapons/R_Base_Rec_Vamp",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 23411,
        Component: "arena_yunlin/_Weapons/R_base_Rec_Summer",
        Style: "STAFF"
    }),
    WPN_YUNLIN_R_BASE_REC_CNY: new WeaponItem({
        ID: 23413,
        Component: "arena_yunlin/_Weapons/R_base_Rec_CNY",
        Style: "STAFF"
    }),
    WPN_YUNLIN_E_GOLDEN_RED: new WeaponItem({
        ID: 23407,
        Component: "arena_yunlin/_Weapons/E_Golden_Red",
        Style: "STAFF"
    }),
    WPN_XIANG_TZU_BASE: new WeaponItem({
        ID: 24400,
        Component: "arena_xiang_tzu/_Weapons/_base",
    }),
    WPN_XIANG_TZU_C_BASE_REC_FIGHTER: new WeaponItem({
        ID: 24401,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_Fighter",
    }),
    WPN_XIANG_TZU_C_DEFAULT_REC_MYSTIC: new WeaponItem({
        ID: 24402,
        Component: "arena_xiang_tzu/_Weapons/R_Default_Rec_Mystic",
    }),
    WPN_XIANG_TZU_C_BASE_REC_WINNER: new WeaponItem({
        ID: 24404,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_Winner",
    }),
    WPN_XIANG_TZU_C_BASE_REC_REIVER: new WeaponItem({
        ID: 24406,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_Reiver",
    }),
    WPN_XIANG_TZU_C_BASE_REC_SEASON: new WeaponItem({
        ID: 24407,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_Season",
    }),
    WPN_XIANG_TZU_C_BASE_REC_INDIAN: new WeaponItem({
        ID: 24409,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_Indian",
    }),
    WPN_XIANG_TZU_C_BASE_REC_WHITE: new WeaponItem({
        ID: 24413,
        Component: "arena_xiang_tzu/_Weapons/C_Base_Rec_White",
    }),
    WPN_XIANG_TZU_R_DEFAULT_REC_GUARD: new WeaponItem({
        ID: 24403,
        Component: "arena_xiang_tzu/_Weapons/R_Default_Rec_Guard",
    }),
    WPN_XIANG_TZU_R_DEFAULT_REC_VAMP: new WeaponItem({
        ID: 24408,
        Component: "arena_xiang_tzu/_Weapons/R_Default_Rec_Vamp",
    }),
    WPN_XIANG_TZU_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 24410,
        Component: "arena_xiang_tzu/_Weapons/R_Base_Rec_Summer",
    }),
    WPN_XIANG_TZU_R_BASE_REC_STAR: new WeaponItem({
        ID: 24411,
        Component: "arena_xiang_tzu/_Weapons/R_Base_Rec_Star",
    }),
    WPN_XIANG_TZU_R_BASE_REC_CNY: new WeaponItem({
        ID: 24412,
        Component: "arena_xiang_tzu/_Weapons/R_Base_Rec_CNY",
    }),
    WPN_XIANG_TZU_R_BASE_REC_APRIL: new WeaponItem({
        ID: 24414,
        Component: "arena_xiang_tzu/_Weapons/R_Base_Rec_April",
    }),
    WPN_XIANG_TZU_E_STOLEN: new WeaponItem({
        ID: 24405,
        Component: "arena_xiang_tzu/_Weapons/E_Stolen",
    }),
    WPN_JUNE_BASE: new WeaponItem({
        ID: 25400,
        Component: "arena_june/_Weapons/_base",
    }),
    WPN_GIDEON_BASE: new WeaponItem({
        ID: 26400,
        Component: "arena_gideon/_Weapons/_base",
    }),
    WPN_GIDEON_C_BASE_REC_MASK: new WeaponItem({
        ID: 26401,
        Component: "arena_gideon/_Weapons/C_Base_Rec_Mask",
    }),
    WPN_GIDEON_C_BASE_REC_MASK_REC_SEASON: new WeaponItem({
        ID: 26403,
        Component: "arena_gideon/_Weapons/C_Base_Rec_Mask_Rec_Season",
    }),
    WPN_GIDEON_C_BASE_REC_FORWARDER: new WeaponItem({
        ID: 26406,
        Component: "arena_gideon/_Weapons/C_Base_Rec_Forwarder",
    }),
    WPN_GIDEON_C_BASE_REC_COWBOY: new WeaponItem({
        ID: 26408,
        Component: "arena_gideon/_Weapons/C_Base_Rec_Jango",
    }),
    WPN_GIDEON_R_BASE_REC_COBRA: new WeaponItem({
        ID: 26404,
        Component: "arena_gideon/_Weapons/R_Base_Rec_Cobra",
    }),
    WPN_GIDEON_R_BASE_REC_SUMMER: new WeaponItem({
        ID: 26405,
        Component: "arena_gideon/_Weapons/R_Base_Rec_Summer",
    }),
    WPN_GIDEON_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 26407,
        Component: "arena_gideon/_Weapons/R_Base_Rec_Mystic",
    }),
    WPN_GIDEON_R_BASE_REC_BAMBOO: new WeaponItem({
        ID: 26409,
        Component: "arena_gideon/_Weapons/R_Base_Rec_Bamboo",
    }),
    WPN_GIDEON_E_FIERY: new WeaponItem({
        ID: 26402,
        Component: "arena_gideon/_Weapons/E_Fiery",
    }),
    WPN_GIDEON_E_HUNTER: new WeaponItem({
        ID: 26410,
        Component: "arena_gideon/_Weapons/E_Hunter",
    }),
    WPN_WIDOW_BASE: new WeaponItem({
        ID: 27400,
        Component: "arena_widow/_Weapons/_base",
    }),
    WPN_WIDOW_C_BASE_REC_SEER: new WeaponItem({
        ID: 27401,
        Component: "arena_widow/_Weapons/C_Base_Rec_Seer",
    }),
    WPN_WIDOW_C_BASE_REC_BONEMOTH: new WeaponItem({
        ID: 27402,
        Component: "arena_widow/_Weapons/C_Base_Bonemoth",
    }),
    WPN_WIDOW_C_BASE_REC_BONEMOTH_REC_SEASON: new WeaponItem({
        ID: 27405,
        Component: "arena_widow/_Weapons/C_Base_Bonemoth_Rec_Season",
    }),
    WPN_WIDOW_C_BASE_REC_NIGHT: new WeaponItem({
        ID: 27406,
        Component: "arena_widow/_Weapons/C_Base_Night",
    }),
    WPN_WIDOW_R_BASE_REC_COBRA: new WeaponItem({
        ID: 27403,
        Component: "arena_widow/_Weapons/R_Base_Rec_Cobra",
    }),
    WPN_WIDOW_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 27407,
        Component: "arena_widow/_Weapons/R_Base_Rec_Mystic",
    }),
    WPN_WIDOW_E_BONEMOTH: new WeaponItem({
        ID: 27404,
        Component: "arena_widow/_Weapons/E_Bonemoth",
    }),
    WPN_RAIKICHI_BASE: new WeaponItem({
        ID: 28400,
        Component: "arena_raikichi/_Weapons/_base",
    }),
    WPN_RAIKICHI_C_BASE_REC_INKY: new WeaponItem({
        ID: 28401,
        Component: "arena_raikichi/_Weapons/C_Base_Rec_Inky",
    }),
    WPN_RAIKICHI_C_BASE_REC_BURNED: new WeaponItem({
        ID: 28403,
        Component: "arena_raikichi/_Weapons/C_Base_Rec_Burned",
    }),
    WPN_RAIKICHI_C_BASE_REC_SEASON: new WeaponItem({
        ID: 28406,
        Component: "arena_raikichi/_Weapons/C_Base_Rec_Season",
    }),
    WPN_RAIKICHI_R_BASE_REC_COBRA: new WeaponItem({
        ID: 28402,
        Component: "arena_raikichi/_Weapons/R_base_Rec_Cobra",
    }),
    WPN_RAIKICHI_R_BASE_REC_MYSTIC: new WeaponItem({
        ID: 28405,
        Component: "arena_raikichi/_Weapons/R_Base_Rec_Mystic",
    }),
    WPN_RAIKICHI_E_BURNED: new WeaponItem({
        ID: 28404,
        Component: "arena_raikichi/_Weapons/E_Burned",
    }),
    WPN_NONNA_BASE: new WeaponItem({
        ID: 29400,
        Component: "arena_nonna/_Weapons/_base",
    }),
    WPN_NONNA_C_BASE_REC_CELTIC: new WeaponItem({
        ID: 29401,
        Component: "arena_nonna/_Weapons/C_base_Rec_Celtic",
    }),
    WPN_NONNA_C_BASE_REC_VALKYRIE: new WeaponItem({
        ID: 29404,
        Component: "arena_nonna/_Weapons/C_base_Rec_Valkyrie",
    }),
    WPN_NONNA_C_BASE_REC_SEASON: new WeaponItem({
        ID: 29406,
        Component: "arena_nonna/_Weapons/C_base_Rec_Season",
    }),
    WPN_NONNA_R_BASE_REC_STAR: new WeaponItem({
        ID: 29402,
        Component: "arena_nonna/_Weapons/C_base_Rec_Star",
    }),
    WPN_NONNA_R_BASE_REC_BAMBOO: new WeaponItem({
        ID: 29405,
        Component: "arena_nonna/_Weapons/R_base_Rec_Bamboo",
    }),
    WPN_NONNA_R_BASE_REC_APRIL: new WeaponItem({
        ID: 29407,
        Component: "arena_nonna/_Weapons/R_base_Rec_April",
    }),
    WPN_NONNA_E_OWL: new WeaponItem({
        ID: 29403,
        Component: "arena_nonna/_Weapons/E_Owl",
    }),
    WPN_SHOGUN_BASE: new WeaponItem({
        ID: 30400,
        Component: "arena_shogun/_Weapons/_base",
    }),
    WPN_SHOGUN_C_BASE_REC_RED: new WeaponItem({
        ID: 30401,
        Component: "arena_shogun/_Weapons/C_Base_Rec_Red",
    }),
    WPN_SHOGUN_R_BASE_REC_VASSAL: new WeaponItem({
        ID: 30402,
        Component: "arena_shogun/_Weapons/R_Base_Rec_Vassal",
    }),
};
var weaponsPvE = {
    tier_1_dynasty_killer_wpn_sabers: new WeaponItem({
        ID: 66200,
        Component: "arena_pve_models/weapons/tier_1_dynasty_killer_wpn_sabers",
        Style: "SABERS"
    }),
    tier_1_dynasty_killer_wpn_deerhorn: new WeaponItem({
        ID: 66201,
        Component: "arena_pve_models/weapons/tier_1_dynasty_killer_wpn_deerhorn",
    }),
    tier_1_dynasty_healer_wpn_nunchaku: new WeaponItem({
        ID: 66202,
        Component: "arena_pve_models/weapons/tier_1_dynasty_healer_wpn_nunchaku",
    }),
    tier_1_dynasty_mage_wpn_guandao: new WeaponItem({
        ID: 66203,
        Component: "arena_pve_models/weapons/tier_1_dynasty_mage_wpn_guandao",
    }),
    tier_1_dynasty_tank_wpn_knife: new WeaponItem({
        ID: 66204,
        Component: "arena_pve_models/weapons/tier_1_dynasty_tank_wpn_knife",
    }),
    tier_1_dynasty_tank_wpn_dadao: new WeaponItem({
        ID: 66205,
        Component: "arena_pve_models/weapons/tier_1_dynasty_tank_wpn_dadao",
    }),
    EmptyWep: new WeaponItem({
        ID: 61204,
        Component: "arena_pve_models/weapons/EmptyWep",
        Style: "FISTS"
    }),
    wpn_PVE_tier_1_dual_knives: new WeaponItem({
        ID: 61207,
        Component: "arena_pve_models/weapons/tier1_dual_knives",
        Style: "SAI"
    }),
    wpn_PVE_tier_1_staff: new WeaponItem({
        ID: 61208,
        Component: "arena_pve_models/weapons/tier1_staff",
        Style: "STAFF"
    }),
    wpn_PVE_tier_1_dual_hammers: new WeaponItem({
        ID: 61209,
        Component: "arena_pve_models/weapons/tier1_dual_hammers",
        Style: "HAMMERS"
    }),
    wpn_PVE_tier_2_dual_swords: new WeaponItem({
        ID: 61210,
        Component: "arena_pve_models/weapons/tier2_dd_dual_swords",
        Style: "SWORDS"
    }),
    wpn_PVE_tier_2_dual_hammers: new WeaponItem({
        ID: 61211,
        Component: "arena_pve_models/weapons/tier2_dual_hammers",
        Style: "HAMMERS"
    }),
    wpn_PVE_tier_2_dual_knives: new WeaponItem({
        ID: 61212,
        Component: "arena_pve_models/weapons/tier2_dual_knives",
        Style: "SAI"
    }),
    wpn_PVE_tier_2_onehanded_sword: new WeaponItem({
        ID: 61213,
        Component: "arena_pve_models/weapons/tier2_onehanded_sword",
        Style: "SWORD_LONELY"
    }),
    wpn_PVE_tier_2_staff: new WeaponItem({
        ID: 61214,
        Component: "arena_pve_models/weapons/tier2_staff",
        Style: "STAFF"
    }),
    wpn_PVE_tier_3_staff: new WeaponItem({
        ID: 61215,
        Component: "arena_pve_models/weapons/tier3_staff",
        Style: "STAFF"
    }),
};
