var hairs = {
    HAIR_FAKE: new Hair({
        ID: 100,
        Component: "Commons/hair_fake"
    }),
    HAIR_1_DYNASTY: new Hair({
        ID: 101,
        Component: "arena_pve_models/test_new_appirence/Hair_Test/dynasty_healer_head1_healer_hair1",
    }),
    HAIR_2_DYNASTY: new Hair({
        ID: 102,
        Component: "arena_pve_models/test_new_appirence/Hair_Test/dynasty_healer_head1_healer_hair2",
    }),
    HAIR_3_DYNASTY: new Hair({
        ID: 103,
        Component: "arena_pve_models/test_new_appirence/Hair_Test/dynasty_killer_head2_killer_hair4",
    }),
};
