var helmets = {
    HLM_BULWARK: new HelmetItem({
        ID: 1200,
        Component: "arena_bulwark/_base/helm_bulwark"
    }),
    HLM_BULWARK_E_GOLD: new HelmetItem({
        ID: 1201,
        Component: "arena_bulwark/E_Golden/helm_bulwark"
    }),
    HLM_BULWARK_R_BLACK: new HelmetItem({
        ID: 1202,
        Component: "arena_bulwark/R_Black/helm_bulwark"
    }),
    HLM_BULWARK_E_CLOVER: new HelmetItem({
        ID: 1203,
        Component: "arena_bulwark/E_Clover/helm_bulwark"
    }),
    HLM_BULWARK_E_SNOW: new HelmetItem({
        ID: 1204,
        Component: "arena_bulwark/E_Snow/helm_bulwark"
    }),
    HLM_BULWARK_E_SNOW_REC_SEASON: new HelmetItem({
        ID: 1205,
        Component: "arena_bulwark/E_Snow_Rec_Season/helm_bulwark"
    }),
    HLM_BULWARK_E_CLOVER_REC_CHILL: new HelmetItem({
        ID: 1206,
        Component: "arena_bulwark/E_Clover_Rec_Chill/helm_bulwark"
    }),
    HLM_BULWARK_E_IVY: new HelmetItem({
        ID: 1207,
        Component: "arena_bulwark/E_ivy/helm_bulwark"
    }),
    HLM_EMPEROR: new HelmetItem({
        ID: 2200,
        Component: "arena_emperor/_base/helm_emperor",
    }),
    HLM_EMPEROR_E_DOOMED: new HelmetItem({
        ID: 2201,
        Component: "arena_emperor/E_Doomed/helm_emperor",
    }),
    HLM_EMPEROR_E_DOOMED_REC_ENLIGHTEN: new HelmetItem({
        ID: 2202,
        Component: "arena_emperor/E_Doomed_Rec_Enlighten/helm_emperor",
    }),
    HLM_EMPEROR_E_DRAGON: new HelmetItem({
        ID: 2203,
        Component: "arena_emperor/E_Dragon/helm_emperor",
    }),
    HLM_EMPEROR_E_DRAGON_REC_SEASON: new HelmetItem({
        ID: 2204,
        Component: "arena_emperor/E_Dragon_Rec_Season/helm_emperor",
    }),
    HLM_EMPEROR_E_DRAGON_REC_ORANGE: new HelmetItem({
        ID: 2205,
        Component: "arena_emperor/E_Dragon_Rec_Orange/helm_emperor",
    }),
    HLM_FELDSHER: new HelmetItem({
        ID: 3200,
        Component: "arena_feldsher/_base/helm_feldsher",
    }),
    HLM_FELDSHER_R_RUSTY: new HelmetItem({
        ID: 3201,
        Component: "arena_feldsher/R_Rusty/helm_feldsher",
    }),
    HLM_FELDSHER_E_SUIT: new HelmetItem({
        ID: 3202,
        Component: "arena_feldsher/E_Suit/helm_feldsher",
    }),
    HLM_FELDSHER_E_REC_SEASON: new HelmetItem({
        ID: 3203,
        Component: "arena_feldsher/E_Rec_Season/helm_feldsher",
    }),
    HLM_FELDSHER_E_PLAGUE: new HelmetItem({
        ID: 3204,
        Component: "arena_feldsher/E_Plague/helm_feldsher",
    }),
    HLM_FELDSHER_E_PLAGUE_REC_VAMPIRE: new HelmetItem({
        ID: 3205,
        Component: "arena_feldsher/E_Plague_Rec_Vampire/helm_feldsher",
    }),
    HLM_FELDSHER_E_DIVER: new HelmetItem({
        ID: 3206,
        Component: "arena_feldsher/E_Diver/helm_feldsher",
    }),
    HLM_FELDSHER_E_DIVER_REC_SEASON: new HelmetItem({
        ID: 3207,
        Component: "arena_feldsher/E_Diver_Rec_Season/helm_feldsher",
    }),
    HLM_FELDSHER_E_DIVER_REC_HEATED: new HelmetItem({
        ID: 3208,
        Component: "arena_feldsher/E_Diver_Rec_Heated/helm_feldsher",
    }),
    HLM_FIREGUARD: new HelmetItem({
        ID: 4200,
        Component: "arena_fireguard/_base/helm_fireguard",
    }),
    HLM_FIREGUARD_R_RED: new HelmetItem({
        ID: 4201,
        Component: "arena_fireguard/R_Red/helm_fireguard",
    }),
    HLM_FIREGUARD_E_WHITE: new HelmetItem({
        ID: 4202,
        Component: "arena_fireguard/E_White/helm_fireguard",
    }),
    HLM_FIREGUARD_E_WHITE_REC_VOID: new HelmetItem({
        ID: 4203,
        Component: "arena_fireguard/E_White_Rec_Void/helm_fireguard",
    }),
    HLM_FIREGUARD_E_CYBER: new HelmetItem({
        ID: 4204,
        Component: "arena_fireguard/E_Cyber/helm_fireguard",
    }),
    HLM_FIREGUARD_E_CYBER_REC_SEASON: new HelmetItem({
        ID: 4205,
        Component: "arena_fireguard/E_Cyber_Rec_Season/helm_fireguard",
    }),
    HLM_FIREGUARD_E_PORCELAIN: new HelmetItem({
        ID: 4206,
        Component: "arena_fireguard/E_Porcelain/helm_fireguard",
    }),
    HLM_FIREGUARD_E_PORCELAIN_REC_STAR: new HelmetItem({
        ID: 4207,
        Component: "arena_fireguard/E_Porcelain_Rec_Star/helm_fireguard",
    }),
    HLM_FIREGUARD_E_PORCELAIN_REC_SEASON: new HelmetItem({
        ID: 4208,
        Component: "arena_fireguard/E_Porcelain_Rec_Season/helm_fireguard",
    }),
    HLM_FIREGUARD_E_CYBER_REC_GREEN: new HelmetItem({
        ID: 4209,
        Component: "arena_fireguard/E_Cyber_Rec_Green/helm_fireguard",
    }),
    HLM_HELGA: new HelmetItem({
        ID: 5200,
        Component: "arena_helga/_base/helm_helga",
    }),
    HLM_HELGA_E_PALADIN: new HelmetItem({
        ID: 5201,
        Component: "arena_helga/E_Paladin/helm_helga",
    }),
    HLM_HELGA_R_BASE_REC_UNSIGHT: new HelmetItem({
        ID: 5202,
        Component: "arena_helga/R_Base_Rec_Unsight/helm_helga",
    }),
    HLM_HELGA_E_PHOENIX: new HelmetItem({
        ID: 5203,
        Component: "arena_helga/E_Phoenix/helm_helga",
    }),
    HLM_HELGA_E_PHOENIX_REC_BOSS: new HelmetItem({
        ID: 5204,
        Component: "arena_helga/E_Phoenix_Rec_Boss/helm_helga",
    }),
    HLM_HELGA_R_VALENTINE: new HelmetItem({
        ID: 5205,
        Component: "arena_helga/R_Valentine/helm_helga",
    }),
    HLM_HELGA_E_VAMPIRE: new HelmetItem({
        ID: 5206,
        Component: "arena_helga/E_Vampire/helm_helga",
    }),
    HLM_HELGA_E_VAMPIRE_REC_SEASON: new HelmetItem({
        ID: 5207,
        Component: "arena_helga/E_Vampire_Rec_Season/helm_helga",
    }),
    HLM_HELGA_E_PHOENIX_REC_GLORY: new HelmetItem({
        ID: 5208,
        Component: "arena_helga/E_Phoenix_Rec_Glory/helm_helga",
    }),
    HLM_HELGA_E_VAMPIRE_REC_SAKURA: new HelmetItem({
        ID: 5209,
        Component: "arena_helga/E_Vampire_Rec_Sakura/helm_helga",
    }),
    HLM_HONG_JOO: new HelmetItem({
        ID: 6200,
        Component: "arena_hong_joo/_base/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_EQUILIBRIST: new HelmetItem({
        ID: 6201,
        Component: "arena_hong_joo/E_Equilibrist/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_EQUILIBRIST_REC_SACURA: new HelmetItem({
        ID: 6202,
        Component: "arena_hong_joo/E_Equilibrist_Rec_Sakura/helm_hong_joo",
    }),
    HLM_HONG_JOO_R_BASE_REC_FLAME: new HelmetItem({
        ID: 6203,
        Component: "arena_hong_joo/R_base_Rec_Flame/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_PILGRIM: new HelmetItem({
        ID: 6204,
        Component: "arena_hong_joo/E_Pilgrim/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_PILGRIM_REC_SEASON: new HelmetItem({
        ID: 6205,
        Component: "arena_hong_joo/E_Pilgrim_Rec_Season/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_CUPID: new HelmetItem({
        ID: 6206,
        Component: "arena_hong_joo/E_Cupid/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_CUPID_REC_DARK: new HelmetItem({
        ID: 6207,
        Component: "arena_hong_joo/E_Cupid_Rec_Dark/helm_hong_joo",
    }),
    HLM_HONG_JOO_E_FROG: new HelmetItem({
        ID: 6208,
        Component: "arena_hong_joo/E_Frog/helm_hong_joo",
    }),
    HLM_IRONCLAD: new HelmetItem({
        ID: 7200,
        Component: "arena_ironclad/_base/helm_ironclad",
    }),
    HLM_IRONCLAD_R_ORANGE: new HelmetItem({
        ID: 7201,
        Component: "arena_ironclad/R_Orange/helm_ironclad",
    }),
    HLM_IRONCLAD_E_RUST: new HelmetItem({
        ID: 7202,
        Component: "arena_ironclad/E_Rust/helm_ironclad",
    }),
    HLM_IRONCLAD_E_GLADIATOR: new HelmetItem({
        ID: 7203,
        Component: "arena_ironclad/E_Gladiator/helm_ironclad",
    }),
    HLM_IRONCLAD_E_GLADIATOR_REC_SEASON: new HelmetItem({
        ID: 7204,
        Component: "arena_ironclad/E_Gladiator_Rec_Season/helm_ironclad",
    }),
    HLM_IRONCLAD_E_FERVOR: new HelmetItem({
        ID: 7205,
        Component: "arena_ironclad/E_Fervor/helm_ironclad",
    }),
    HLM_IRONCLAD_E_FERVOR_REC_SEASON: new HelmetItem({
        ID: 7208,
        Component: "arena_ironclad/E_Fervor_Rec_Season/helm_ironclad",
    }),
    HLM_IRONCLAD_E_GLADIATOR_REC_HOLI: new HelmetItem({
        ID: 7206,
        Component: "arena_ironclad/E_Gladiator_Rec_Holi/helm_ironclad",
    }),
    HLM_IRONCLAD_L_MINOTAUR: new HelmetItem({
        ID: 7209,
        Component: "arena_ironclad/L_Minotaur/helm_ironclad",
    }),
    HLM_IRONCLAD_E_RUST_REC_BOSS: new HelmetItem({
        ID: 63002,
        Component: "arena_ironclad/E_Rust_Rec_Boss/helm_ironclad",
    }),
    HLM_JET: new HelmetItem({
        ID: 8200,
        Component: "arena_jet/_base/helm_jet",
    }),
    HLM_JET_E_GOLDEN: new HelmetItem({
        ID: 8201,
        Component: "arena_jet/E_Golden/helm_jet",
    }),
    HLM_JET_E_WATER: new HelmetItem({
        ID: 8202,
        Component: "arena_jet/E_Water/helm_jet",
    }),
    HLM_JET_E_WATER_REC_PINK: new HelmetItem({
        ID: 8203,
        Component: "arena_jet/E_Water_Rec_Pink/helm_jet",
    }),
    HLM_JET_E_NOMAD: new HelmetItem({
        ID: 8204,
        Component: "arena_jet/E_Nomad/helm_jet",
    }),
    HLM_JET_E_NOMAD_REC_SEASON: new HelmetItem({
        ID: 8205,
        Component: "arena_jet/E_Nomad_Rec_Season/helm_jet",
    }),
    HLM_JET_E_BURGLAR: new HelmetItem({
        ID: 8206,
        Component: "arena_jet/E_Burglar/helm_jet",
    }),
    HLM_KIBO: new HelmetItem({
        ID: 9200,
        Component: "arena_kibo/_base/helm_kibo",
    }),
    HLM_KIBO_E_GRAY: new HelmetItem({
        ID: 9201,
        Component: "arena_kibo/E_Gray/helm_kibo",
    }),
    HLM_KIBO_R_ROSE: new HelmetItem({
        ID: 9202,
        Component: "arena_kibo/R_Rose/helm_kibo",
    }),
    HLM_KIBO_E_ORIENTAL: new HelmetItem({
        ID: 9203,
        Component: "arena_kibo/E_Oriental/helm_kibo",
    }),
    HLM_KIBO_E_CRANE: new HelmetItem({
        ID: 9204,
        Component: "arena_kibo/E_Crane/helm_kibo",
    }),
    HLM_KIBO_E_ORIENTAL_REC_SAKURA: new HelmetItem({
        ID: 9205,
        Component: "arena_kibo/E_Oriental_Rec_Sakura/helm_kibo",
    }),
    HLM_KIBO_E_CRANE_REC_SEASON: new HelmetItem({
        ID: 9206,
        Component: "arena_kibo/E_Crane_Rec_Season/helm_kibo",
    }),
    HLM_KIBO_E_GRAY_REC_VENOM: new HelmetItem({
        ID: 9207,
        Component: "arena_kibo/E_Gray_Rec_Venom/helm_kibo",
    }),
    HLM_KIBO_L_ECLIPSE: new HelmetItem({
        ID: 9208,
        Component: "arena_kibo/L_Eclipse/helm_kibo",
    }),
    HLM_LING: new HelmetItem({
        ID: 10200,
        Component: "arena_ling/_base/helm_ling",
    }),
    HLM_LING_E_SAMURAI: new HelmetItem({
        ID: 10201,
        Component: "arena_ling/E_Samurai/helm_ling",
    }),
    HLM_LING_E_SAMURAI_REC_GOLD: new HelmetItem({
        ID: 10202,
        Component: "arena_ling/E_Samurai_Rec_Gold/helm_ling",
    }),
    HLM_LING_E_RAVEN: new HelmetItem({
        ID: 10203,
        Component: "arena_ling/E_Raven/helm_ling",
    }),
    HLM_LING_E_REC_SEASON: new HelmetItem({
        ID: 10204,
        Component: "arena_ling/E_Rec_Season/helm_ling",
    }),
    HLM_LING_E_RONIN: new HelmetItem({
        ID: 10205,
        Component: "arena_ling/E_Ronin/helm_ling",
    }),
    HLM_LING_E_RONIN_REC_BLACK: new HelmetItem({
        ID: 10206,
        Component: "arena_ling/E_Ronin_Rec_Black/helm_ling",
    }),
    HLM_LING_E_RONIN_REC_SEASON: new HelmetItem({
        ID: 10207,
        Component: "arena_ling/E_Ronin_Rec_Season/helm_ling",
    }),
    HLM_LING_E_RAVEN_REC_BLUE: new HelmetItem({
        ID: 10208,
        Component: "arena_ling/E_Raven_Rec_Blue/helm_ling",
    }),
    HLM_LIQUIDATOR: new HelmetItem({
        ID: 11200,
        Component: "arena_liquidator/_base/helm_liquidator",
    }),
    HLM_LIQUIDATOR_R_PURPLE: new HelmetItem({
        ID: 11201,
        Component: "arena_liquidator/R_Purple/helm_liquidator",
    }),
    HLM_LIQUIDATOR_S_GOLD: new HelmetItem({
        ID: 11202,
        Component: "arena_liquidator/S_Gold/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_WHITE: new HelmetItem({
        ID: 11203,
        Component: "arena_liquidator/E_White/helm_liquidator",
    }),
    HLM_LIQUIDATOR_R_REC_BOSS: new HelmetItem({
        ID: 11204,
        Component: "arena_liquidator/R_Rec_Boss/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_VALKYRIE: new HelmetItem({
        ID: 11205,
        Component: "arena_liquidator/E_Valkyrie/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_VALKYRIE_SEASON: new HelmetItem({
        ID: 11206,
        Component: "arena_liquidator/E_Valkyrie_Rec_Season/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_FORGED: new HelmetItem({
        ID: 11207,
        Component: "arena_liquidator/E_Forged/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_FORGED_REC_JOUST: new HelmetItem({
        ID: 11208,
        Component: "arena_liquidator/E_Forged_Rec_Joust/helm_liquidator",
    }),
    HLM_LIQUIDATOR_E_FORGED_REC_SEASON: new HelmetItem({
        ID: 11209,
        Component: "arena_liquidator/E_Forged_Rec_Season/helm_liquidator",
    }),
    HLM_LYNX: new HelmetItem({
        ID: 12200,
        Component: "arena_lynx/_base/helm_lynx"
    }),
    HLM_LYNX_E_ORIGINAL: new HelmetItem({
        ID: 12201,
        Component: "arena_lynx/E_Original/helm_lynx"
    }),
    HLM_LYNX_R_BASE_REC_FANCY: new HelmetItem({
        ID: 12202,
        Component: "arena_lynx/R_base_Rec_Fancy/helm_lynx"
    }),
    HLM_LYNX_E_ORIGINAL_REC_WHITE: new HelmetItem({
        ID: 12203,
        Component: "arena_lynx/E_Original_Rec_White/helm_lynx"
    }),
    HLM_LYNX_E_MAFIA: new HelmetItem({
        ID: 12204,
        Component: "arena_lynx/E_Mafia/helm_lynx"
    }),
    HLM_LYNX_L_HOOD: new HelmetItem({
        ID: 12205,
        Component: "arena_lynx/L_Hood/helm_lynx"
    }),
    HLM_LYNX_E_MAFIA_REC_SEASON: new HelmetItem({
        ID: 12206,
        Component: "arena_lynx/E_Mafia_Rec_Season/helm_lynx"
    }),
    HLM_LYNX_E_MAFIA_REC_VIOLET: new HelmetItem({
        ID: 12207,
        Component: "arena_lynx/E_Mafia_Rec_Violet/helm_lynx"
    }),
    HLM_MARCUS: new HelmetItem({
        ID: 13200,
        Component: "arena_marcus/_base/helm_marcus",
    }),
    HLM_MARCUS_E_LORD: new HelmetItem({
        ID: 13201,
        Component: "arena_marcus/E_Lord/helm_marcus",
    }),
    HLM_MARCUS_E_ROYAL: new HelmetItem({
        ID: 13202,
        Component: "arena_marcus/E_Royal/helm_marcus",
    }),
    HLM_MARCUS_E_MAGMA: new HelmetItem({
        ID: 13203,
        Component: "arena_marcus/E_Magma/helm_marcus",
    }),
    HLM_MARCUS_E_LORD_REC_FALL: new HelmetItem({
        ID: 13204,
        Component: "arena_marcus/E_Lord_Rec_Fall/helm_marcus",
    }),
    HLM_MARCUS_E_VETERAN: new HelmetItem({
        ID: 13205,
        Component: "arena_marcus/E_Veteran/helm_marcus",
    }),
    HLM_MARCUS_E_MAGMA_REC_GLITCH: new HelmetItem({
        ID: 13206,
        Component: "arena_marcus/E_Magma_Rec_Glitch/helm_marcus",
    }),
    HLM_MIDNIGHT: new HelmetItem({
        ID: 14200,
        Component: "arena_midnight/_base/helm_midnight",
    }),
    HLM_MIDNIGHT_E_GHOST: new HelmetItem({
        ID: 14201,
        Component: "arena_midnight/E_Ghost/helm_midnight",
    }),
    HLM_MIDNIGHT_R_BLUE: new HelmetItem({
        ID: 14202,
        Component: "arena_midnight/R_Blue/helm_midnight",
    }),
    HLM_MIDNIGHT_E_WITCH: new HelmetItem({
        ID: 14203,
        Component: "arena_midnight/E_Witch/helm_midnight",
    }),
    HLM_MIDNIGHT_E_WITCH_REC_SEASON: new HelmetItem({
        ID: 14204,
        Component: "arena_midnight/E_Witch_Rec_Season/helm_midnight",
    }),
    HLM_MIDNIGHT_E_ASSASSIN: new HelmetItem({
        ID: 14205,
        Component: "arena_midnight/E_Assassin/helm_midnight",
    }),
    HLM_MIDNIGHT_E_ASSASSIN_REC_WHITE: new HelmetItem({
        ID: 14206,
        Component: "arena_midnight/E_Assassin_Rec_White/helm_midnight",
    }),
    HLM_MIDNIGHT_E_ASSASSIN_REC_SEASON: new HelmetItem({
        ID: 14207,
        Component: "arena_midnight/E_Assassin_Rec_Season/helm_midnight",
    }),
    HLM_MIDNIGHT_E_SHINOBI: new HelmetItem({
        ID: 14208,
        Component: "arena_midnight/E_Shinobi/helm_midnight",
    }),
    HLM_MONK: new HelmetItem({
        ID: 15200,
        Component: "arena_monk/_base/helm_monk",
    }),
    HLM_MONK_R_BLUE: new HelmetItem({
        ID: 15201,
        Component: "arena_monk/R_Blue/helm_monk",
    }),
    HLM_MONK_E_CURSED: new HelmetItem({
        ID: 15202,
        Component: "arena_monk/E_Cursed/helm_monk",
    }),
    HLM_MONK_E_CURSED_REC_WHITE: new HelmetItem({
        ID: 15203,
        Component: "arena_monk/E_Cursed_Rec_White/helm_monk",
    }),
    HLM_MONK_E_ROYAL: new HelmetItem({
        ID: 15204,
        Component: "arena_monk/E_Royal/helm_monk",
    }),
    HLM_MONK_E_CURSED_REC_CREEPY: new HelmetItem({
        ID: 15205,
        Component: "arena_monk/E_Cursed_Rec_Creepy/helm_monk",
    }),
    HLM_MONK_E_ROYAL_REC_GOLD: new HelmetItem({
        ID: 15206,
        Component: "arena_monk/E_Royal_Rec_Gold/helm_monk",
    }),
    HLM_MONK_E_MOTH: new HelmetItem({
        ID: 15207,
        Component: "arena_monk/E_Moth/helm_monk",
    }),
    HLM_MONK_E_MOTH_REC_SEASON: new HelmetItem({
        ID: 15208,
        Component: "arena_monk/E_Moth_Rec_Season/helm_monk",
    }),
    HLM_MONKEY_KING: new HelmetItem({
        ID: 16200,
        Component: "arena_monkey_king/_base/helm_monkey_king",
    }),
    HLM_MONKEY_KING_E_STRANGER: new HelmetItem({
        ID: 16201,
        Component: "arena_monkey_king/E_Stranger/helm_monkey_king",
    }),
    HLM_MONKEY_R_BASE_REC_BLAZE: new HelmetItem({
        ID: 16202,
        Component: "arena_monkey_king/R_base_Rec_Blaze/helm_monkey_king",
    }),
    HLM_MONKEY_E_CRUEL: new HelmetItem({
        ID: 16203,
        Component: "arena_monkey_king/E_Cruel/helm_monkey_king",
    }),
    HLM_MONKEY_E_CRUEL_REC_SEASON: new HelmetItem({
        ID: 16204,
        Component: "arena_monkey_king/E_Cruel_Rec_Season/helm_monkey_king",
    }),
    HLM_MONKEY_E_SYLVAN: new HelmetItem({
        ID: 16205,
        Component: "arena_monkey_king/E_Sylvan/helm_monkey_king",
    }),
    HLM_MONKEY_E_DRAGON: new HelmetItem({
        ID: 16206,
        Component: "arena_monkey_king/E_Dragon/helm_monkey_king",
    }),
    HLM_MONKEY_L_CRYSTAL: new HelmetItem({
        ID: 16207,
        Component: "arena_monkey_king/L_Crystal/helm_monkey_king",
    }),
    HLM_MONKEY_E_DRAGON_REC_SEASON: new HelmetItem({
        ID: 16208,
        Component: "arena_monkey_king/E_Dragon_Rec_Season/helm_monkey_king",
    }),
    HLM_SARGE: new HelmetItem({
        ID: 17200,
        Component: "arena_sarge/_base/helm_sarge"
    }),
    HLM_SARGE_E_VIKING: new HelmetItem({
        ID: 17201,
        Component: "arena_sarge/E_Viking/helm_sarge"
    }),
    HLM_SARGE_E_VIKING_REC_SEASON: new HelmetItem({
        ID: 17202,
        Component: "arena_sarge/E_Viking_Rec_Season/helm_sarge"
    }),
    HLM_SARGE_E_CHITIN: new HelmetItem({
        ID: 17203,
        Component: "arena_sarge/E_Chitin/helm_sarge"
    }),
    HLM_SARGE_E_CHITIN_REC_WINTER: new HelmetItem({
        ID: 17204,
        Component: "arena_sarge/E_Chitin_Rec_Winter/helm_sarge"
    }),
    HLM_SARGE_E_CHITIN_REC_SEASON: new HelmetItem({
        ID: 17205,
        Component: "arena_sarge/E_Chitin_Rec_Season/helm_sarge"
    }),
    HLM_SARGE_E_SUNNY: new HelmetItem({
        ID: 17206,
        Component: "arena_sarge/E_Sunny/helm_sarge"
    }),
    HLM_YUKKA: new HelmetItem({
        ID: 18200,
        Component: "arena_yukka/_base/helm_yukka",
    }),
    HLM_YUKKA_R_RED: new HelmetItem({
        ID: 18201,
        Component: "arena_yukka/R_Red/helm_yukka",
    }),
    HLM_YUKKA_E_CAT: new HelmetItem({
        ID: 18202,
        Component: "arena_yukka/E_Cat/helm_yukka",
    }),
    HLM_YUKKA_E_WAYFARER: new HelmetItem({
        ID: 18203,
        Component: "arena_yukka/E_Wayfarer/helm_yukka",
    }),
    HLM_YUKKA_E_CAT_REC_BLACK: new HelmetItem({
        ID: 18204,
        Component: "arena_yukka/E_Cat_Rec_Black/helm_yukka",
    }),
    HLM_YUKKA_E_REBEL: new HelmetItem({
        ID: 18205,
        Component: "arena_yukka/E_Rebel/helm_yukka",
    }),
    HLM_YUKKA_E_REBEL_REC_SEASON: new HelmetItem({
        ID: 18206,
        Component: "arena_yukka/E_Rebel_Rec_Season/helm_yukka",
    }),
    HLM_YUKKA_E_WAYFARER_REC_FLOWER: new HelmetItem({
        ID: 18207,
        Component: "arena_yukka/E_Wayfarer_Rec_Flower/helm_yukka",
    }),
    HLM_VIPER: new HelmetItem({
        ID: 19200,
        Component: "arena_viper/_base/helm_viper",
    }),
    HLM_VIPER_R_BASE_REC_BRAT: new HelmetItem({
        ID: 19201,
        Component: "arena_viper/R_base_Rec_Brat/helm_viper",
    }),
    HLM_VIPER_E_GRAFFITI: new HelmetItem({
        ID: 19202,
        Component: "arena_viper/E_Graffiti/helm_viper",
    }),
    HLM_VIPER_R_BASE_REC_VAMPIRE: new HelmetItem({
        ID: 19203,
        Component: "arena_viper/R_base_Rec_Vampire/helm_viper",
    }),
    HLM_VIPER_E_MOBSTER: new HelmetItem({
        ID: 19204,
        Component: "arena_viper/E_Mobster/helm_viper",
    }),
    HLM_VIPER_E_GRAFFITI_REC_SEASON: new HelmetItem({
        ID: 19205,
        Component: "arena_viper/E_Graffiti_Rec_Season/helm_viper",
    }),
    HLM_VIPER_E_MOBSTER_REC_GLOW: new HelmetItem({
        ID: 19206,
        Component: "arena_viper/E_Mobster_Rec_Glow/helm_viper",
    }),
    HLM_LEGION_KING: new HelmetItem({
        ID: 20200,
        Component: "arena_legion_king/_base/helm_legion_king",
    }),
    HLM_LEGION_KING_R_VINY: new HelmetItem({
        ID: 20201,
        Component: "arena_legion_king/R_Viny/helm_legion_king",
    }),
    HLM_LEGION_KING_R_REC_BOSS: new HelmetItem({
        ID: 20202,
        Component: "arena_legion_king/R_Rec_Boss/helm_legion_king",
    }),
    HLM_LEGION_KING_E_BONE: new HelmetItem({
        ID: 20203,
        Component: "arena_legion_king/E_Bone/helm_legion_king",
    }),
    HLM_LEGION_KING_E_BONE_REC_LICH: new HelmetItem({
        ID: 20204,
        Component: "arena_legion_king/E_Bone_Rec_Lich/helm_legion_king",
    }),
    HLM_LEGION_KING_E_PRINCE: new HelmetItem({
        ID: 20205,
        Component: "arena_legion_king/E_Prince/helm_legion_king",
    }),
    HLM_LEGION_KING_E_PRINCE_REC_SEASON: new HelmetItem({
        ID: 20206,
        Component: "arena_legion_king/E_Prince_Rec_Season/helm_legion_king",
    }),
    HLM_LEGION_KING_L_CASTLE: new HelmetItem({
        ID: 20207,
        Component: "arena_legion_king/L_Castle/helm_legion_king",
    }),
    HLM_BUTCHER: new HelmetItem({
        ID: 21200,
        Component: "arena_butcher/_base/helm_butcher",
    }),
    HLM_BUTCHER_R_PURPLE: new HelmetItem({
        ID: 21201,
        Component: "arena_butcher/R_Purple/helm_butcher",
    }),
    HLM_BUTCHER_R_BIKER: new HelmetItem({
        ID: 21203,
        Component: "arena_butcher/R_Biker/helm_butcher",
    }),
    HLM_BUTCHER_E_MOGWAI: new HelmetItem({
        ID: 21202,
        Component: "arena_butcher/E_Mogwai/helm_butcher",
    }),
    HLM_BUTCHER_E_MOGWAI_REC_SEASON: new HelmetItem({
        ID: 21204,
        Component: "arena_butcher/E_Mogwai_Rec_Season/helm_butcher",
    }),
    HLM_BUTCHER_E_KHAN: new HelmetItem({
        ID: 21205,
        Component: "arena_butcher/E_Khan/helm_butcher",
    }),
    HLM_BUTCHER_E_KHAN_REC_SEASON: new HelmetItem({
        ID: 21206,
        Component: "arena_butcher/E_Khan_Rec_Season/helm_butcher",
    }),
    HLM_BUTCHER_E_SUSHI: new HelmetItem({
        ID: 21207,
        Component: "arena_butcher/E_Sushi/helm_butcher",
    }),
    HLM_ITU: new HelmetItem({
        ID: 22200,
        Component: "arena_itu/_base/helm_itu",
    }),
    HLM_ITU_E_DEMON: new HelmetItem({
        ID: 22201,
        Component: "arena_itu/E_Demon/helm_itu",
    }),
    HLM_ITU_E_DEMON_REC_SEASON: new HelmetItem({
        ID: 22202,
        Component: "arena_itu/E_Demon_Rec_Season/helm_itu",
    }),
    HLM_ITU_E_MASTER: new HelmetItem({
        ID: 22203,
        Component: "arena_itu/E_Master/helm_itu",
    }),
    HLM_ITU_L_COSMIC: new HelmetItem({
        ID: 22204,
        Component: "arena_itu/L_Cosmic/helm_itu",
    }),
    HLM_YUNLIN: new HelmetItem({
        ID: 23200,
        Component: "arena_yunlin/_base/helm_yunlin",
    }),
    HLM_YUNLIN_R_HAZY: new HelmetItem({
        ID: 23201,
        Component: "arena_yunlin/R_Hazy/helm_yunlin",
    }),
    HLM_YUNLIN_R_SPRING: new HelmetItem({
        ID: 23206,
        Component: "arena_yunlin/R_Spring/helm_yunlin",
    }),
    HLM_YUNLIN_E_BRIDE: new HelmetItem({
        ID: 23202,
        Component: "arena_yunlin/E_Bride/helm_yunlin",
    }),
    HLM_YUNLIN_E_BRIDE_REC_SEASON: new HelmetItem({
        ID: 23203,
        Component: "arena_yunlin/E_Bride_Rec_Season/helm_yunlin",
    }),
    HLM_YUNLIN_E_BRIDE_REC_INDIAN: new HelmetItem({
        ID: 23204,
        Component: "arena_yunlin/E_Bride_Rec_Indian/helm_yunlin",
    }),
    HLM_YUNLIN_E_WINTER: new HelmetItem({
        ID: 23205,
        Component: "arena_yunlin/E_Winter/helm_yunlin",
    }),
    HLM_XIANG_TZU: new HelmetItem({
        ID: 24200,
        Component: "arena_xiang_tzu/_base/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_R_FIGHTER: new HelmetItem({
        ID: 24201,
        Component: "arena_xiang_tzu/R_Fighter/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_E_WINNER: new HelmetItem({
        ID: 24202,
        Component: "arena_xiang_tzu/E_Winner/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_E_REIVER: new HelmetItem({
        ID: 24203,
        Component: "arena_xiang_tzu/E_Reiver/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_E_REAVER_REC_SEASON: new HelmetItem({
        ID: 24204,
        Component: "arena_xiang_tzu/E_Reiver_Rec_Season/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_E_INDIAN: new HelmetItem({
        ID: 24205,
        Component: "arena_xiang_tzu/E_Indian/helm_xiang_tzu",
    }),
    HLM_XIANG_TZU_E_INDIAN_REC_WHITE: new HelmetItem({
        ID: 24206,
        Component: "arena_xiang_tzu/E_Indian_Rec_White/helm_xiang_tzu",
    }),
    HLM_JUNE: new HelmetItem({
        ID: 25200,
        Component: "arena_june/_base/helm_june",
    }),
    HLM_JUNE_R_STAR: new HelmetItem({
        ID: 25201,
        Component: "arena_june/R_Star/helm_june",
    }),
    HLM_JUNE_E_EMPRESS: new HelmetItem({
        ID: 25202,
        Component: "arena_june/E_Empress/helm_june",
    }),
    HLM_JUNE_E_EMPRESS_REC_SEASON: new HelmetItem({
        ID: 25203,
        Component: "arena_june/E_Empress_Rec_Season/helm_june",
    }),
    HLM_JUNE_E_SAKURA: new HelmetItem({
        ID: 25204,
        Component: "arena_june/E_Sakura/helm_june",
    }),
    HLM_JUNE_E_SAKURA_REC_SEASON: new HelmetItem({
        ID: 25205,
        Component: "arena_june/E_Sakura_Rec_Season/helm_june",
    }),
    HLM_GIDEON: new HelmetItem({
        ID: 26200,
        Component: "arena_gideon/_base/helm_gideon",
    }),
    HLM_GIDEON_E_MASK: new HelmetItem({
        ID: 26201,
        Component: "arena_gideon/E_Mask/helm_gideon",
    }),
    HLM_GIDEON_E_MASK_REC_SEASON: new HelmetItem({
        ID: 26202,
        Component: "arena_gideon/E_Mask_Rec_Season/helm_gideon",
    }),
    HLM_GIDEON_E_FORWADER: new HelmetItem({
        ID: 26203,
        Component: "arena_gideon/E_Forwarder/helm_gideon",
    }),
    HLM_GIDEON_E_COWBOY: new HelmetItem({
        ID: 26204,
        Component: "arena_gideon/R_Jango/helm_gideon",
    }),
    HLM_WIDOW: new HelmetItem({
        ID: 27200,
        Component: "arena_widow/_base/helm_widow",
    }),
    HLM_WIDOW_R_SEER: new HelmetItem({
        ID: 27201,
        Component: "arena_widow/R_Seer/helm_widow",
    }),
    HLM_WIDOW_E_BONEMOTH: new HelmetItem({
        ID: 27202,
        Component: "arena_widow/E_Bonemoth/helm_widow",
    }),
    HLM_WIDOW_E_BONEMOTH_REC_SEASON: new HelmetItem({
        ID: 27203,
        Component: "arena_widow/E_Bonemoth_Rec_Season/helm_widow",
    }),
    HLM_WIDOW_E_NIGHT: new HelmetItem({
        ID: 27204,
        Component: "arena_widow/E_Night/helm_widow",
    }),
    HLM_RAIKICHI: new HelmetItem({
        ID: 28200,
        Component: "arena_raikichi/_base/helm_raikichi",
    }),
    HLM_RAIKICHI_R_BASE_REC_INKY: new HelmetItem({
        ID: 28201,
        Component: "arena_raikichi/R_Base_Rec_Inky/helm_raikichi",
    }),
    HLM_RAIKICHI_E_BURNED: new HelmetItem({
        ID: 28203,
        Component: "arena_raikichi/E_Burned/helm_raikichi",
    }),
    HLM_RAIKICHI_E_BURNED_REC_SEASON: new HelmetItem({
        ID: 28204,
        Component: "arena_raikichi/E_Burned_Rec_Season/helm_raikichi",
    }),
    HLM_NONNA: new HelmetItem({
        ID: 29200,
        Component: "arena_nonna/_base/helm_nonna",
    }),
    HLM_NONNA_R_CELTIC: new HelmetItem({
        ID: 29201,
        Component: "arena_nonna/R_Celtic/helm_nonna",
    }),
    HLM_NONNA_E_VALKYRIE: new HelmetItem({
        ID: 29202,
        Component: "arena_nonna/E_Valkyrie/helm_nonna",
    }),
    HLM_NONNA_E_VALKYRIE_REC_SEASON: new HelmetItem({
        ID: 29203,
        Component: "arena_nonna/E_Valkyrie_Rec_Season/helm_nonna",
    }),
    HLM_SHOGUN: new HelmetItem({
        ID: 30200,
        Component: "arena_shogun/_base/helm_shogun",
    }),
    HLM_SHOGUN_R_RED: new HelmetItem({
        ID: 30201,
        Component: "arena_shogun/R_Red/helm_shogun",
    }),
};
var helmetsPvE = {
    legion_damage_tier1_pve: new HelmetItem({
        ID: 61101,
        Component: "arena_pve_models/heads_legion/legion_head1_tier1",
    }),
    legion_mage_tier1_pve: new HelmetItem({
        ID: 61102,
        Component: "arena_pve_models/heads_legion/legion_head2_tier1",
    }),
    legion_tank_tier1_pve: new HelmetItem({
        ID: 61103,
        Component: "arena_pve_models/heads_legion/legion_head3_tier1",
    }),
    legion_head4_tier1_pve: new HelmetItem({
        ID: 61104,
        Component: "arena_pve_models/heads_legion/legion_head4_tier1",
    }),
    legion_head1_egg_universal_pve: new HelmetItem({
        ID: 61105,
        Component: "arena_pve_models/heads_legion/legion_head1_tier2_bold",
    }),
    legion_head2_egg_universal_pve: new HelmetItem({
        ID: 61106,
        Component: "arena_pve_models/heads_legion/legion_head2_tier2_bold",
    }),
    legion_head3_egg_universal_pve: new HelmetItem({
        ID: 61107,
        Component: "arena_pve_models/heads_legion/legion_head3_tier2_bold",
    }),
    legion_head4_egg_universal_pve: new HelmetItem({
        ID: 61108,
        Component: "arena_pve_models/heads_legion/legion_head4_tier2_bold",
    }),
    dynasty_tank_head1_bold: new HelmetItem({
        ID: 63101,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_bold",
    }),
    dynasty_tank_head1_healer_hair1: new HelmetItem({
        ID: 63102,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair1",
    }),
    dynasty_tank_head1_healer_hair2: new HelmetItem({
        ID: 63103,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair2",
    }),
    dynasty_tank_head1_healer_hair3: new HelmetItem({
        ID: 63104,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair3",
    }),
    dynasty_tank_head1_healer_hair4: new HelmetItem({
        ID: 63105,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair4",
    }),
    dynasty_tank_head1_healer_hair5: new HelmetItem({
        ID: 63106,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair5",
    }),
    dynasty_killer_head1_bold: new HelmetItem({
        ID: 63107,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_bold",
    }),
    dynasty_killer_head1_killer_hair1: new HelmetItem({
        ID: 63108,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_killer_hair1",
    }),
    dynasty_killer_head1_killer_hair2: new HelmetItem({
        ID: 63109,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_killer_hair2",
    }),
    dynasty_killer_head1_killer_hair3: new HelmetItem({
        ID: 63110,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_killer_hair3",
    }),
    dynasty_killer_head1_killer_hair4: new HelmetItem({
        ID: 63111,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_killer_hair4",
    }),
    dynasty_healer_head1_bold: new HelmetItem({
        ID: 63112,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_bold",
    }),
    dynasty_healer_head1_healer_hair1: new HelmetItem({
        ID: 63113,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair1",
    }),
    dynasty_healer_head1_healer_hair2: new HelmetItem({
        ID: 63114,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair2",
    }),
    dynasty_healer_head1_healer_hair3: new HelmetItem({
        ID: 63115,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair3",
    }),
    dynasty_healer_head1_healer_hair4: new HelmetItem({
        ID: 63116,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair4",
    }),
    dynasty_healer_head1_healer_hair5: new HelmetItem({
        ID: 63117,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair5",
    }),
    dynasty_healer_head2_healer_hair1: new HelmetItem({
        ID: 63118,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_healer_hair1",
    }),
    dynasty_healer_head2_healer_hair2: new HelmetItem({
        ID: 63119,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_healer_hair2",
    }),
    dynasty_healer_head2_healer_hair3: new HelmetItem({
        ID: 63120,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_healer_hair3",
    }),
    dynasty_healer_head2_healer_hair4: new HelmetItem({
        ID: 63121,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_healer_hair4",
    }),
    dynasty_healer_head2_healer_hair5: new HelmetItem({
        ID: 63122,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_healer_hair5",
    }),
    dynasty_healer_head3_healer_hair1: new HelmetItem({
        ID: 63122,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_healer_hair1",
    }),
    dynasty_healer_head3_healer_hair2: new HelmetItem({
        ID: 63123,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_healer_hair2",
    }),
    dynasty_healer_head3_healer_hair3: new HelmetItem({
        ID: 63124,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_healer_hair3",
    }),
    dynasty_healer_head3_healer_hair4: new HelmetItem({
        ID: 63125,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_healer_hair4",
    }),
    dynasty_healer_head3_healer_hair5: new HelmetItem({
        ID: 63126,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_healer_hair5",
    }),
    dynasty_healer_head2_bold: new HelmetItem({
        ID: 63127,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head2_bold",
    }),
    dynasty_healer_head3_bold: new HelmetItem({
        ID: 63128,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head3_bold",
    }),
    dynasty_tank_head2_bold: new HelmetItem({
        ID: 63129,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_bold",
    }),
    dynasty_tank_head2_healer_hair1: new HelmetItem({
        ID: 63130,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_healer_hair1",
    }),
    dynasty_tank_head2_healer_hair2: new HelmetItem({
        ID: 63131,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_healer_hair2",
    }),
    dynasty_tank_head2_healer_hair3: new HelmetItem({
        ID: 63132,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_healer_hair3",
    }),
    dynasty_tank_head2_healer_hair4: new HelmetItem({
        ID: 63133,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_healer_hair4",
    }),
    dynasty_tank_head2_healer_hair5: new HelmetItem({
        ID: 63134,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head2_healer_hair5",
    }),
    dynasty_tank_head3_bold: new HelmetItem({
        ID: 63135,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_bold",
    }),
    dynasty_tank_head3_healer_hair1: new HelmetItem({
        ID: 63136,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_healer_hair1",
    }),
    dynasty_tank_head3_healer_hair2: new HelmetItem({
        ID: 63137,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_healer_hair2",
    }),
    dynasty_tank_head3_healer_hair3: new HelmetItem({
        ID: 63138,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_healer_hair3",
    }),
    dynasty_tank_head3_healer_hair4: new HelmetItem({
        ID: 63139,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_healer_hair4",
    }),
    dynasty_tank_head3_healer_hair5: new HelmetItem({
        ID: 63140,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head3_healer_hair5",
    }),
    dynasty_mage_head1_bold: new HelmetItem({
        ID: 63141,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head1_bold",
    }),
    dynasty_mage_head1_hair1: new HelmetItem({
        ID: 63142,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head1_hair1",
    }),
    dynasty_mage_head1_hair2: new HelmetItem({
        ID: 63143,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head1_hair2",
    }),
    dynasty_mage_head2_bold: new HelmetItem({
        ID: 63144,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head2_bold",
    }),
    dynasty_mage_head2_hair1: new HelmetItem({
        ID: 63145,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head2_hair1",
    }),
    dynasty_mage_head2_hair2: new HelmetItem({
        ID: 63146,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head2_hair2",
    }),
    dynasty_mage_head3_bold: new HelmetItem({
        ID: 63147,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head3_bold",
    }),
    dynasty_mage_head3_hair1: new HelmetItem({
        ID: 63148,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head3_hair1",
    }),
    dynasty_mage_head3_hair2: new HelmetItem({
        ID: 63149,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head3_hair2",
    }),
    dynasty_killer_head2_bold: new HelmetItem({
        ID: 63150,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head2_bold",
    }),
    dynasty_killer_head2_killer_hair1: new HelmetItem({
        ID: 63151,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head2_killer_hair1",
    }),
    dynasty_killer_head2_killer_hair2: new HelmetItem({
        ID: 63152,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head2_killer_hair2",
    }),
    dynasty_killer_head2_killer_hair3: new HelmetItem({
        ID: 63153,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head2_killer_hair3",
    }),
    dynasty_killer_head2_killer_hair4: new HelmetItem({
        ID: 63154,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head2_killer_hair4",
    }),
    dynasty_killer_head3_bold: new HelmetItem({
        ID: 63155,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head3_bold",
    }),
    dynasty_killer_head3_killer_hair1: new HelmetItem({
        ID: 63156,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head3_killer_hair1",
    }),
    dynasty_killer_head3_killer_hair2: new HelmetItem({
        ID: 63157,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head3_killer_hair2",
    }),
    dynasty_killer_head3_killer_hair3: new HelmetItem({
        ID: 63158,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head3_killer_hair3",
    }),
    dynasty_killer_head3_killer_hair4: new HelmetItem({
        ID: 63159,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head3_killer_hair4",
    }),
    dynasty_tank_head1_healer_hair4_boss: new HelmetItem({
        ID: 63160,
        Component: "arena_pve_models/heads_dynasty/dynasty_tank_head1_healer_hair4_boss",
    }),
    dynasty_mage_head1_hair2_boss: new HelmetItem({
        ID: 63161,
        Component: "arena_pve_models/heads_dynasty/dynasty_mage_head1_hair2_boss",
    }),
    dynasty_healer_head1_healer_hair1_boss: new HelmetItem({
        ID: 63162,
        Component: "arena_pve_models/heads_dynasty/dynasty_healer_head1_healer_hair1_boss",
    }),
    dynasty_killer_head1_killer_hair2_boss: new HelmetItem({
        ID: 63163,
        Component: "arena_pve_models/heads_dynasty/dynasty_killer_head1_killer_hair2_boss",
    }),
    dynasty_head1_healer_maskHawk_tier1_hair1: new HelmetItem({
        ID: 67100,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier1_hair1",
    }),
    dynasty_head1_healer_maskHawk_tier1_hair2: new HelmetItem({
        ID: 67101,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier1_hair2",
    }),
    dynasty_head1_healer_maskHawk_tier1_hair5: new HelmetItem({
        ID: 67102,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier1_hair5",
    }),
    dynasty_head1_healer_maskOwl_tier1_hair1: new HelmetItem({
        ID: 67103,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier1_hair1",
    }),
    dynasty_head1_healer_maskOwl_tier1_hair2: new HelmetItem({
        ID: 67104,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier1_hair2",
    }),
    dynasty_head1_healer_maskOwl_tier1_hair5: new HelmetItem({
        ID: 67105,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier1_hair5",
    }),
    dynasty_head1_healer_maskHawk_tier2_hair1: new HelmetItem({
        ID: 67106,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier2_hair1",
    }),
    dynasty_head1_healer_maskHawk_tier2_hair2: new HelmetItem({
        ID: 67107,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier2_hair2",
    }),
    dynasty_head1_healer_maskHawk_tier2_hair5: new HelmetItem({
        ID: 67108,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier2_hair5",
    }),
    dynasty_head1_healer_maskOwl_tier2_hair1: new HelmetItem({
        ID: 67109,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier2_hair1",
    }),
    dynasty_head1_healer_maskOwl_tier2_hair2: new HelmetItem({
        ID: 67110,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier2_hair2",
    }),
    dynasty_head1_healer_maskOwl_tier2_hair5: new HelmetItem({
        ID: 67111,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier2_hair5",
    }),
    dynasty_head1_healer_maskHawk_tier3_hair1: new HelmetItem({
        ID: 67112,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier3_hair1",
    }),
    dynasty_head1_healer_maskHawk_tier3_hair2: new HelmetItem({
        ID: 67113,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier3_hair2",
    }),
    dynasty_head1_healer_maskHawk_tier3_hair5: new HelmetItem({
        ID: 67114,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskHawk_tier3_hair5",
    }),
    dynasty_head1_healer_maskOwl_tier3_hair1: new HelmetItem({
        ID: 67115,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier3_hair1",
    }),
    dynasty_head1_healer_maskOwl_tier3_hair2: new HelmetItem({
        ID: 67116,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier3_hair2",
    }),
    dynasty_head1_healer_maskOwl_tier3_hair5: new HelmetItem({
        ID: 67117,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_healer_maskOwl_tier3_hair5",
    }),
    dynasty_head1_killer_maskCat_tier1_bold: new HelmetItem({
        ID: 67118,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier1_bold",
    }),
    dynasty_head1_killer_maskCat_tier1_hair2: new HelmetItem({
        ID: 67119,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier1_hair2",
    }),
    dynasty_head1_killer_maskCat_tier1_hair3: new HelmetItem({
        ID: 67120,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier1_hair3",
    }),
    dynasty_head1_killer_maskWolf_tier1_bold: new HelmetItem({
        ID: 67121,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier1_bold",
    }),
    dynasty_head1_killer_maskWolf_tier1_hair2: new HelmetItem({
        ID: 67122,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier1_hair2",
    }),
    dynasty_head1_killer_maskWolf_tier1_hair3: new HelmetItem({
        ID: 67123,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier1_hair3",
    }),
    dynasty_head1_killer_maskCat_tier2_bold: new HelmetItem({
        ID: 67124,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier2_bold",
    }),
    dynasty_head1_killer_maskCat_tier2_hair2: new HelmetItem({
        ID: 67125,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier2_hair2",
    }),
    dynasty_head1_killer_maskCat_tier2_hair3: new HelmetItem({
        ID: 67126,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier2_hair3",
    }),
    dynasty_head1_killer_maskWolf_tier2_bold: new HelmetItem({
        ID: 67127,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier2_bold",
    }),
    dynasty_head1_killer_maskWolf_tier2_hair2: new HelmetItem({
        ID: 67128,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier2_hair2",
    }),
    dynasty_head1_killer_maskWolf_tier2_hair3: new HelmetItem({
        ID: 67129,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier2_hair3",
    }),
    dynasty_head1_killer_maskCat_tier3_bold: new HelmetItem({
        ID: 67130,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier3_bold",
    }),
    dynasty_head1_killer_maskCat_tier3_hair2: new HelmetItem({
        ID: 67131,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier3_hair2",
    }),
    dynasty_head1_killer_maskCat_tier3_hair3: new HelmetItem({
        ID: 67132,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskCat_tier3_hair3",
    }),
    dynasty_head1_killer_maskWolf_tier3_bold: new HelmetItem({
        ID: 67133,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier3_bold",
    }),
    dynasty_head1_killer_maskWolf_tier3_hair2: new HelmetItem({
        ID: 67133,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier3_hair2",
    }),
    dynasty_head1_killer_maskWolf_tier3_hair3: new HelmetItem({
        ID: 67134,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_killer_maskWolf_tier3_hair3",
    }),
    dynasty_head1_mage_maskMonkey_tier1_bold: new HelmetItem({
        ID: 67135,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier1_bold",
    }),
    dynasty_head1_mage_maskMonkey_tier1_bold2: new HelmetItem({
        ID: 67136,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier1_bold2",
    }),
    dynasty_head1_mage_maskMonkey_tier1_hair2: new HelmetItem({
        ID: 67137,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier1_hair2",
    }),
    dynasty_head1_mage_maskPanther_tier1_bold: new HelmetItem({
        ID: 67138,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier1_bold",
    }),
    dynasty_head1_mage_maskPanther_tier1_bold2: new HelmetItem({
        ID: 67139,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier1_bold2",
    }),
    dynasty_head1_mage_maskPanther_tier1_hair2: new HelmetItem({
        ID: 67140,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier1_hair2",
    }),
    dynasty_head1_mage_maskMonkey_tier2_bold: new HelmetItem({
        ID: 67141,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier2_bold",
    }),
    dynasty_head1_mage_maskMonkey_tier2_bold2: new HelmetItem({
        ID: 67142,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier2_bold2",
    }),
    dynasty_head1_mage_maskMonkey_tier2_hair2: new HelmetItem({
        ID: 67143,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier2_hair2",
    }),
    dynasty_head1_mage_maskPanther_tier2_bold: new HelmetItem({
        ID: 67144,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier2_bold",
    }),
    dynasty_head1_mage_maskPanther_tier2_bold2: new HelmetItem({
        ID: 67145,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier2_bold2",
    }),
    dynasty_head1_mage_maskPanther_tier2_hair2: new HelmetItem({
        ID: 67146,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier2_hair2",
    }),
    dynasty_head1_mage_maskMonkey_tier3_bold: new HelmetItem({
        ID: 67147,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier3_bold",
    }),
    dynasty_head1_mage_maskMonkey_tier3_bold2: new HelmetItem({
        ID: 67148,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier3_bold2",
    }),
    dynasty_head1_mage_maskMonkey_tier3_hair2: new HelmetItem({
        ID: 67149,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskMonkey_tier3_hair2",
    }),
    dynasty_head1_mage_maskPanther_tier3_bold: new HelmetItem({
        ID: 67150,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier3_bold",
    }),
    dynasty_head1_mage_maskPanther_tier3_bold2: new HelmetItem({
        ID: 67151,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier3_bold2",
    }),
    dynasty_head1_mage_maskPanther_tier3_hair2: new HelmetItem({
        ID: 67152,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_mage_maskPanther_tier3_hair2",
    }),
    dynasty_head1_tank_maskBoar_tier1_hair2: new HelmetItem({
        ID: 67153,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier1_hair2",
    }),
    dynasty_head1_tank_maskBoar_tier1_hair3: new HelmetItem({
        ID: 67154,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier1_hair3",
    }),
    dynasty_head1_tank_maskBoar_tier1_hair4: new HelmetItem({
        ID: 67155,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier1_hair4",
    }),
    dynasty_head1_tank_maskBull_tier1_hair2: new HelmetItem({
        ID: 67156,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier1_hair2",
    }),
    dynasty_head1_tank_maskBull_tier1_hair3: new HelmetItem({
        ID: 67157,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier1_hair3",
    }),
    dynasty_head1_tank_maskBull_tier1_hair4: new HelmetItem({
        ID: 67158,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier1_hair4",
    }),
    dynasty_head1_tank_maskBoar_tier2_hair2: new HelmetItem({
        ID: 67159,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier2_hair2",
    }),
    dynasty_head1_tank_maskBoar_tier2_hair3: new HelmetItem({
        ID: 67160,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier2_hair3",
    }),
    dynasty_head1_tank_maskBoar_tier2_hair4: new HelmetItem({
        ID: 67161,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier2_hair4",
    }),
    dynasty_head1_tank_maskBull_tier2_hair2: new HelmetItem({
        ID: 67162,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier2_hair2",
    }),
    dynasty_head1_tank_maskBull_tier2_hair3: new HelmetItem({
        ID: 67163,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier2_hair3",
    }),
    dynasty_head1_tank_maskBull_tier2_hair4: new HelmetItem({
        ID: 67164,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier2_hair4",
    }),
    dynasty_head1_tank_maskBoar_tier3_hair2: new HelmetItem({
        ID: 67165,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier3_hair2",
    }),
    dynasty_head1_tank_maskBoar_tier3_hair3: new HelmetItem({
        ID: 67166,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier3_hair3",
    }),
    dynasty_head1_tank_maskBoar_tier3_hair4: new HelmetItem({
        ID: 67167,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBoar_tier3_hair4",
    }),
    dynasty_head1_tank_maskBull_tier3_hair2: new HelmetItem({
        ID: 67168,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier3_hair2",
    }),
    dynasty_head1_tank_maskBull_tier3_hair3: new HelmetItem({
        ID: 67169,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier3_hair3",
    }),
    dynasty_head1_tank_maskBull_tier3_hair4: new HelmetItem({
        ID: 67170,
        Component: "arena_pve_models/Masks_Dynasty/dynasty_head1_tank_maskBull_tier3_hair4",
    }),
    EmptyHead: new HelmetItem({
        ID: 68101,
        Component: "arena_pve_models/EmptyHead",
    }),
};
