var armors = {
    ARM_BULWARK: new ArmorItem({
        ID: 1100,
        Component: "arena_bulwark/_base/arm_bulwark",
    }),
    ARM_BULWARK_E_GOLDEN: new ArmorItem({
        ID: 1101,
        Component: "arena_bulwark/E_Golden/arm_bulwark",
    }),
    ARM_BULWARK_R_BLACK: new ArmorItem({
        ID: 1102,
        Component: "arena_bulwark/R_Black/arm_bulwark",
    }),
    ARM_BULWARK_E_CLOVER: new ArmorItem({
        ID: 1103,
        Component: "arena_bulwark/E_Clover/arm_bulwark",
    }),
    ARM_BULWARK_R_REC_BOSS: new ArmorItem({
        ID: 1104,
        Component: "arena_bulwark/R_Rec_Boss/arm_bulwark",
    }),
    ARM_BULWARK_E_SNOW: new ArmorItem({
        ID: 1105,
        Component: "arena_bulwark/E_Snow/arm_bulwark",
    }),
    ARM_BULWARK_R_JEWEL: new ArmorItem({
        ID: 1106,
        Component: "arena_bulwark/R_Jewel/arm_bulwark",
    }),
    ARM_BULWARK_E_SNOW_REC_SEASON: new ArmorItem({
        ID: 1107,
        Component: "arena_bulwark/E_Snow_Rec_Season/arm_bulwark",
    }),
    ARM_BULWARK_E_CLOVER_REC_CHILL: new ArmorItem({
        ID: 1108,
        Component: "arena_bulwark/E_Clover_Rec_Chill/arm_bulwark",
    }),
    ARM_BULWARK_E_IVY: new ArmorItem({
        ID: 1109,
        Component: "arena_bulwark/E_ivy/arm_bulwark",
    }),
    ARM_EMPEROR: new ArmorItem({
        ID: 2100,
        Component: "arena_emperor/_base/arm_emperor",
    }),
    ARM_EMPEROR_R_CYAN: new ArmorItem({
        ID: 2101,
        Component: "arena_emperor/R_Cyan/arm_emperor",
    }),
    ARM_EMPEROR_E_DOOMED: new ArmorItem({
        ID: 2102,
        Component: "arena_emperor/E_Doomed/arm_emperor",
    }),
    ARM_EMPEROR_E_DOOMED_REC_ENLIGHTEN: new ArmorItem({
        ID: 2103,
        Component: "arena_emperor/E_Doomed_Rec_Enlighten/arm_emperor",
    }),
    ARM_EMPEROR_E_DOOMED_REC_ENLIGHTEN_BOSS: new ArmorItem({
        ID: 2104,
        Component: "arena_pve_models/Boss_emperor/arm_emperor",
    }),
    ARM_EMPEROR_E_DRAGON: new ArmorItem({
        ID: 2105,
        Component: "arena_emperor/E_Dragon/arm_emperor",
    }),
    ARM_EMPEROR_E_DRAGON_REC_SEASON: new ArmorItem({
        ID: 2106,
        Component: "arena_emperor/E_Dragon_Rec_Season/arm_emperor",
    }),
    ARM_EMPEROR_E_DRAGON_REC_ORANGE: new ArmorItem({
        ID: 2107,
        Component: "arena_emperor/E_Dragon_Rec_Orange/arm_emperor",
    }),
    ARM_FELDSHER: new ArmorItem({
        ID: 3100,
        Component: "arena_feldsher/_base/arm_feldsher",
    }),
    ARM_FELDSHER_R_RUSTY: new ArmorItem({
        ID: 3101,
        Component: "arena_feldsher/R_Rusty/arm_feldsher",
    }),
    ARM_FELDSHER_E_SUIT: new ArmorItem({
        ID: 3102,
        Component: "arena_feldsher/E_Suit/arm_feldsher",
    }),
    ARM_FELDSHER_E_REC_SEASON: new ArmorItem({
        ID: 3103,
        Component: "arena_feldsher/E_Rec_Season/arm_feldsher",
    }),
    ARM_FELDSHER_E_REC_PLAGUE: new ArmorItem({
        ID: 3104,
        Component: "arena_feldsher/E_Plague/arm_feldsher",
    }),
    ARM_FELDSHER_E_PLAGUE_REC_VAMPIRE: new ArmorItem({
        ID: 3105,
        Component: "arena_feldsher/E_Plague_Rec_Vampire/arm_feldsher",
    }),
    ARM_FELDSHER_E_DIVER: new ArmorItem({
        ID: 3106,
        Component: "arena_feldsher/E_Diver/arm_feldsher",
    }),
    ARM_FELDSHER_E_DIVER_REC_SEASON: new ArmorItem({
        ID: 3107,
        Component: "arena_feldsher/E_Diver_Rec_Season/arm_feldsher",
    }),
    ARM_FELDSHER_E_DIVER_REC_HEATED: new ArmorItem({
        ID: 3108,
        Component: "arena_feldsher/E_Diver_Rec_Heated/arm_feldsher",
    }),
    ARM_FIREGUARD: new ArmorItem({
        ID: 4100,
        Component: "arena_fireguard/_base/arm_fireguard",
    }),
    ARM_FIREGUARD_R_RED: new ArmorItem({
        ID: 4101,
        Component: "arena_fireguard/R_Red/arm_fireguard",
    }),
    ARM_FIREGUARD_E_WHITE: new ArmorItem({
        ID: 4102,
        Component: "arena_fireguard/E_White/arm_fireguard",
    }),
    ARM_FIREGUARD_E_WHITE_REC_VOID: new ArmorItem({
        ID: 4103,
        Component: "arena_fireguard/E_White_Rec_Void/arm_fireguard",
    }),
    ARM_FIREGUARD_E_CYBER: new ArmorItem({
        ID: 4104,
        Component: "arena_fireguard/E_Cyber/arm_fireguard",
    }),
    ARM_FIREGUARD_E_CYBER_REC_SEASON: new ArmorItem({
        ID: 4105,
        Component: "arena_fireguard/E_Cyber_Rec_Season/arm_fireguard",
    }),
    ARM_FIREGUARD_E_PORCELAIN: new ArmorItem({
        ID: 4106,
        Component: "arena_fireguard/E_Porcelain/arm_fireguard",
    }),
    ARM_FIREGUARD_E_PORCELAIN_REC_STAR: new ArmorItem({
        ID: 4107,
        Component: "arena_fireguard/E_Porcelain_Rec_Star/arm_fireguard",
    }),
    ARM_FIREGUARD_E_PORCELAIN_REC_SEASON: new ArmorItem({
        ID: 4108,
        Component: "arena_fireguard/E_Porcelain_Rec_Season/arm_fireguard",
    }),
    ARM_FIREGUARD_E_CYBER_REC_GREEN: new ArmorItem({
        ID: 4109,
        Component: "arena_fireguard/E_Cyber_Rec_Green/arm_fireguard",
    }),
    ARM_HELGA: new ArmorItem({
        ID: 5100,
        Component: "arena_helga/_base/arm_helga",
    }),
    ARM_HELGA_E_PALADIN: new ArmorItem({
        ID: 5101,
        Component: "arena_helga/E_Paladin/arm_helga",
    }),
    ARM_HELGA_R_BASE_REC_UNSIGHT: new ArmorItem({
        ID: 5102,
        Component: "arena_helga/R_Base_Rec_Unsight/arm_helga",
    }),
    ARM_HELGA_E_PHOENIX: new ArmorItem({
        ID: 5103,
        Component: "arena_helga/E_Phoenix/arm_helga",
    }),
    ARM_HELGA_E_PHOENIX_REC_BOSS: new ArmorItem({
        ID: 5104,
        Component: "arena_helga/E_Phoenix_Rec_Boss/arm_helga",
    }),
    ARM_HELGA_R_VALENTINE: new ArmorItem({
        ID: 5105,
        Component: "arena_helga/R_Valentine/arm_helga",
    }),
    ARM_HELGA_E_VAMPIRE: new ArmorItem({
        ID: 5106,
        Component: "arena_helga/E_Vampire/arm_helga",
    }),
    ARM_HELGA_E_VAMPIRE_REC_SEASON: new ArmorItem({
        ID: 5107,
        Component: "arena_helga/E_Vampire_Rec_Season/arm_helga",
    }),
    ARM_HELGA_E_PHOENIX_REC_GLORY: new ArmorItem({
        ID: 5108,
        Component: "arena_helga/E_Phoenix_Rec_Glory/arm_helga",
    }),
    ARM_HELGA_E_VAMPIRE_REC_SAKURA: new ArmorItem({
        ID: 5109,
        Component: "arena_helga/E_Vampire_Rec_Sakura/arm_helga",
    }),
    ARM_HONG_JOO: new ArmorItem({
        ID: 6100,
        Component: "arena_hong_joo/_base/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_EQUILIBRIST: new ArmorItem({
        ID: 6101,
        Component: "arena_hong_joo/E_Equilibrist/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_EQUILIBRIST_REC_SAKURA: new ArmorItem({
        ID: 6102,
        Component: "arena_hong_joo/E_Equilibrist_Rec_Sakura/arm_hong_joo",
    }),
    ARM_HONG_JOO_R_BASE_REC_FLAME: new ArmorItem({
        ID: 6103,
        Component: "arena_hong_joo/R_base_Rec_Flame/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_PILGRIM: new ArmorItem({
        ID: 6104,
        Component: "arena_hong_joo/E_Pilgrim/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_PILGRIM_REC_SEASON: new ArmorItem({
        ID: 6105,
        Component: "arena_hong_joo/E_Pilgrim_Rec_Season/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_CUPID: new ArmorItem({
        ID: 6106,
        Component: "arena_hong_joo/E_Cupid/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_CUPID_REC_DARK: new ArmorItem({
        ID: 6107,
        Component: "arena_hong_joo/E_Cupid_Rec_Dark/arm_hong_joo",
    }),
    ARM_HONG_JOO_E_FROG: new ArmorItem({
        ID: 6108,
        Component: "arena_hong_joo/E_Frog/arm_hong_joo",
    }),
    ARM_IRONCLAD: new ArmorItem({
        ID: 7100,
        Component: "arena_ironclad/_base/arm_ironclad",
    }),
    ARM_IRONCLAD_R_ORANGE: new ArmorItem({
        ID: 7101,
        Component: "arena_ironclad/R_Orange/arm_ironclad",
    }),
    ARM_IRONCLAD_E_RUST: new ArmorItem({
        ID: 7102,
        Component: "arena_ironclad/E_Rust/arm_ironclad",
    }),
    ARM_IRONCLAD_E_RUST_REC_BOSS: new ArmorItem({
        ID: 7103,
        Component: "arena_ironclad/E_Rust_Rec_Boss/arm_ironclad",
    }),
    ARM_IRONCLAD_E_GLADIATOR: new ArmorItem({
        ID: 7104,
        Component: "arena_ironclad/E_Gladiator/arm_ironclad",
    }),
    ARM_IRONCLAD_E_GLADIATOR_REC_SEASON: new ArmorItem({
        ID: 7105,
        Component: "arena_ironclad/E_Gladiator_Rec_Season/arm_ironclad",
    }),
    ARM_IRONCLAD_E_FERVOR: new ArmorItem({
        ID: 7106,
        Component: "arena_ironclad/E_Fervor/arm_ironclad",
    }),
    ARM_IRONCLAD_E_FERVOR_REC_SEASON: new ArmorItem({
        ID: 7108,
        Component: "arena_ironclad/E_Fervor_Rec_Season/arm_ironclad",
    }),
    ARM_IRONCLAD_E_GLADIATOR_REC_HOLI: new ArmorItem({
        ID: 7107,
        Component: "arena_ironclad/E_Gladiator_Rec_Holi/arm_ironclad",
    }),
    ARM_IRONCLAD_L_MINOTAUR: new ArmorItem({
        ID: 7109,
        Component: "arena_ironclad/L_Minotaur/arm_ironclad",
    }),
    ARM_JET: new ArmorItem({
        ID: 8100,
        Component: "arena_jet/_base/arm_jet",
    }),
    ARM_JET_E_GOLDEN: new ArmorItem({
        ID: 8102,
        Component: "arena_jet/E_Golden/arm_jet",
    }),
    ARM_JET_R_BASE_REC_PURPLE: new ArmorItem({
        ID: 8101,
        Component: "arena_jet/R_base_Rec_Purple/arm_jet",
    }),
    ARM_JET_E_WATER: new ArmorItem({
        ID: 8103,
        Component: "arena_jet/E_Water/arm_jet",
    }),
    ARM_JET_E_WATER_REC_PINK: new ArmorItem({
        ID: 8104,
        Component: "arena_jet/E_Water_Rec_Pink/arm_jet",
    }),
    ARM_JET_E_NOMAD: new ArmorItem({
        ID: 8105,
        Component: "arena_jet/E_Nomad/arm_jet",
    }),
    ARM_JET_E_NOMAD_REC_SEASON: new ArmorItem({
        ID: 8106,
        Component: "arena_jet/E_Nomad_Rec_Season/arm_jet",
    }),
    ARM_JET_E_BURGLAR: new ArmorItem({
        ID: 8107,
        Component: "arena_jet/E_Burglar/arm_jet",
    }),
    ARM_KIBO: new ArmorItem({
        ID: 9100,
        Component: "arena_kibo/_base/arm_kibo",
    }),
    ARM_KIBO_E_GRAY: new ArmorItem({
        ID: 9101,
        Component: "arena_kibo/E_Gray/arm_kibo",
    }),
    ARM_KIBO_R_ROSE: new ArmorItem({
        ID: 9102,
        Component: "arena_kibo/R_Rose/arm_kibo",
    }),
    ARM_KIBO_E_ORIENTAL: new ArmorItem({
        ID: 9103,
        Component: "arena_kibo/E_Oriental/arm_kibo",
    }),
    ARM_KIBO_E_CRANE: new ArmorItem({
        ID: 9104,
        Component: "arena_kibo/E_Crane/arm_kibo",
    }),
    ARM_KIBO_E_ORIENTAL_REC_SAKURA: new ArmorItem({
        ID: 9105,
        Component: "arena_kibo/E_Oriental_Rec_Sakura/arm_kibo",
    }),
    ARM_KIBO_E_CRANE_REC_SEASON: new ArmorItem({
        ID: 9106,
        Component: "arena_kibo/E_Crane_Rec_Season/arm_kibo",
    }),
    ARM_KIBO_E_GRAY_REC_VENOM: new ArmorItem({
        ID: 9107,
        Component: "arena_kibo/E_Gray_Rec_Venom/arm_kibo",
    }),
    ARM_KIBO_L_ECLIPSE: new ArmorItem({
        ID: 9108,
        Component: "arena_kibo/L_Eclipse/arm_kibo",
    }),
    ARM_LING: new ArmorItem({
        ID: 10100,
        Component: "arena_ling/_base/arm_ling",
    }),
    ARM_LING_E_SAMURAI: new ArmorItem({
        ID: 10101,
        Component: "arena_ling/E_Samurai/arm_ling",
    }),
    ARM_LING_R_RED: new ArmorItem({
        ID: 10102,
        Component: "arena_ling/R_Red/arm_ling",
    }),
    ARM_LING_E_SAMURAI_REC_GOLD: new ArmorItem({
        ID: 10103,
        Component: "arena_ling/E_Samurai_Rec_Gold/arm_ling",
    }),
    ARM_LING_E_Raven: new ArmorItem({
        ID: 10104,
        Component: "arena_ling/E_Raven/arm_ling",
    }),
    ARM_LING_E_REC_SEASON: new ArmorItem({
        ID: 10105,
        Component: "arena_ling/E_Rec_Season/arm_ling",
    }),
    ARM_LING_E_Ronin: new ArmorItem({
        ID: 10106,
        Component: "arena_ling/E_Ronin/arm_ling",
    }),
    ARM_LING_E_RONIN_REC_BLACK: new ArmorItem({
        ID: 10107,
        Component: "arena_ling/E_Ronin_Rec_Black/arm_ling",
    }),
    ARM_LING_E_RONIN_REC_SEASON: new ArmorItem({
        ID: 10108,
        Component: "arena_ling/E_Ronin_Rec_Season/arm_ling",
    }),
    ARM_LING_E_Raven_REC_BLUE: new ArmorItem({
        ID: 10109,
        Component: "arena_ling/E_Raven_Rec_Blue/arm_ling",
    }),
    ARM_LIQUIDATOR: new ArmorItem({
        ID: 11100,
        Component: "arena_liquidator/_base/arm_liquidator",
    }),
    ARM_LIQUIDATOR_R_PURPLE: new ArmorItem({
        ID: 11101,
        Component: "arena_liquidator/R_Purple/arm_liquidator",
    }),
    ARM_LIQUIDATOR_S_GOLD: new ArmorItem({
        ID: 11102,
        Component: "arena_liquidator/S_Gold/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_WHITE: new ArmorItem({
        ID: 11103,
        Component: "arena_liquidator/E_White/arm_liquidator",
    }),
    ARM_LIQUIDATOR_R_REC_BOSS: new ArmorItem({
        ID: 11104,
        Component: "arena_liquidator/R_Rec_Boss/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_VALKYRIE: new ArmorItem({
        ID: 11105,
        Component: "arena_liquidator/E_Valkyrie/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_VALKYRIE_REC_SEASON: new ArmorItem({
        ID: 11106,
        Component: "arena_liquidator/E_Valkyrie_Rec_Season/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_FORGED: new ArmorItem({
        ID: 11107,
        Component: "arena_liquidator/E_Forged/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_FORGED_REC_JOUST: new ArmorItem({
        ID: 11108,
        Component: "arena_liquidator/E_Forged_Rec_Joust/arm_liquidator",
    }),
    ARM_LIQUIDATOR_E_FORGED_REC_SEASON: new ArmorItem({
        ID: 11109,
        Component: "arena_liquidator/E_Forged_Rec_Season/arm_liquidator",
    }),
    ARM_LYNX: new ArmorItem({
        ID: 12100,
        Component: "arena_lynx/_base/arm_lynx",
    }),
    ARM_LYNX_E_ORIGINAL: new ArmorItem({
        ID: 12101,
        Component: "arena_lynx/E_Original/arm_lynx",
    }),
    ARM_LYNX_R_BASE_REC_FANCY: new ArmorItem({
        ID: 12102,
        Component: "arena_lynx/R_base_Rec_Fancy/arm_lynx",
    }),
    ARM_LYNX_E_ORIGINAL_REC_WHITE: new ArmorItem({
        ID: 12103,
        Component: "arena_lynx/E_Original_Rec_White/arm_lynx",
    }),
    ARM_LYNX_E_MAFIA: new ArmorItem({
        ID: 12104,
        Component: "arena_lynx/E_Mafia/arm_lynx",
    }),
    ARM_LYNX_L_HOOD: new ArmorItem({
        ID: 12105,
        Component: "arena_lynx/L_Hood/arm_lynx",
    }),
    ARM_LYNX_E_MAFIA_REC_SEASON: new ArmorItem({
        ID: 12106,
        Component: "arena_lynx/E_Mafia_Rec_Season/arm_lynx",
    }),
    ARM_LYNX_E_MAFIA_REC_VIOLET: new ArmorItem({
        ID: 12107,
        Component: "arena_lynx/E_Mafia_Rec_Violet/arm_lynx",
    }),
    ARM_MARCUS: new ArmorItem({
        ID: 13100,
        Component: "arena_marcus/_base/arm_marcus",
    }),
    ARM_MARCUS_E_LORD: new ArmorItem({
        ID: 13101,
        Component: "arena_marcus/E_Lord/arm_marcus",
    }),
    ARM_MARCUS_R_WINY: new ArmorItem({
        ID: 13102,
        Component: "arena_marcus/R_Winy/arm_marcus",
    }),
    ARM_MARCUS_E_ROYAL: new ArmorItem({
        ID: 13103,
        Component: "arena_marcus/E_Royal/arm_marcus",
    }),
    ARM_MARCUS_E_MAGMA: new ArmorItem({
        ID: 13104,
        Component: "arena_marcus/E_Magma/arm_marcus",
    }),
    ARM_MARCUS_E_LORD_REC_FALL: new ArmorItem({
        ID: 13105,
        Component: "arena_marcus/E_Lord_Rec_Fall/arm_marcus",
    }),
    ARM_MARCUS_E_VETERAN: new ArmorItem({
        ID: 13106,
        Component: "arena_marcus/E_Veteran/arm_marcus",
    }),
    ARM_MARCUS_E_VETERAN_REC_SEASON: new ArmorItem({
        ID: 13107,
        Component: "arena_marcus/E_Veteran_Rec_Season/arm_marcus",
    }),
    ARM_MARCUS_E_VETERAN_REC_NOUVEAU: new ArmorItem({
        ID: 13109,
        Component: "arena_marcus/E_Veteran_Rec_Nouveau/arm_marcus",
    }),
    ARM_MARCUS_E_MAGMA_REC_GLITCH: new ArmorItem({
        ID: 13108,
        Component: "arena_marcus/E_Magma_Rec_Glitch/arm_marcus",
    }),
    ARM_MIDNIGHT: new ArmorItem({
        ID: 14100,
        Component: "arena_midnight/_base/arm_midnight",
    }),
    ARM_MIDNIGHT_E_GHOST: new ArmorItem({
        ID: 14101,
        Component: "arena_midnight/E_Ghost/arm_midnight",
    }),
    ARM_MIDNIGHT_R_BLUE: new ArmorItem({
        ID: 14102,
        Component: "arena_midnight/R_Blue/arm_midnight",
    }),
    ARM_MIDNIGHT_E_WITCH: new ArmorItem({
        ID: 14103,
        Component: "arena_midnight/E_Witch/arm_midnight",
    }),
    ARM_MIDNIGHT_E_WITCH_REC_SEASON: new ArmorItem({
        ID: 14104,
        Component: "arena_midnight/E_Witch_Rec_Season/arm_midnight",
    }),
    ARM_MIDNIGHT_E_ASSASSIN: new ArmorItem({
        ID: 14105,
        Component: "arena_midnight/E_Assassin/arm_midnight",
    }),
    ARM_MIDNIGHT_E_ASSASSIN_REC_WHITE: new ArmorItem({
        ID: 14106,
        Component: "arena_midnight/E_Assassin_Rec_White/arm_midnight",
    }),
    ARM_MIDNIGHT_E_ASSASSIN_REC_SEASON: new ArmorItem({
        ID: 14107,
        Component: "arena_midnight/E_Assassin_Rec_Season/arm_midnight",
    }),
    ARM_MIDNIGHT_E_SHINOBI: new ArmorItem({
        ID: 14108,
        Component: "arena_midnight/E_Shinobi/arm_midnight",
    }),
    ARM_MONK: new ArmorItem({
        ID: 15100,
        Component: "arena_monk/_base/arm_monk",
    }),
    ARM_MONK_R_BLUE: new ArmorItem({
        ID: 15102,
        Component: "arena_monk/R_Blue/arm_monk",
    }),
    ARM_MONK_E_CURSED: new ArmorItem({
        ID: 15103,
        Component: "arena_monk/E_Cursed/arm_monk",
    }),
    ARM_MONK_E_CURSED_REC_WHITE: new ArmorItem({
        ID: 15104,
        Component: "arena_monk/E_Cursed_Rec_White/arm_monk",
    }),
    ARM_MONK_E_ROYAL: new ArmorItem({
        ID: 15105,
        Component: "arena_monk/E_Royal/arm_monk",
    }),
    ARM_MONK_E_CURSED_REC_CREEPY: new ArmorItem({
        ID: 15106,
        Component: "arena_monk/E_Cursed_Rec_Creepy/arm_monk",
    }),
    ARM_MONK_E_ROYAL_REC_GOLD: new ArmorItem({
        ID: 15107,
        Component: "arena_monk/E_Royal_Rec_Gold/arm_monk",
    }),
    ARM_MONK_E_MOTH: new ArmorItem({
        ID: 15109,
        Component: "arena_monk/E_Moth/arm_monk",
    }),
    ARM_MONK_E_MOTH_REC_SEASON: new ArmorItem({
        ID: 15110,
        Component: "arena_monk/E_Moth_Rec_Season/arm_monk",
    }),
    ARM_MONKEY_KING: new ArmorItem({
        ID: 16100,
        Component: "arena_monkey_king/_base/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_STRANGER: new ArmorItem({
        ID: 16101,
        Component: "arena_monkey_king/E_Stranger/arm_monkey_king",
    }),
    ARM_MONKEY_KING_R_BASE_REC_BLAZE: new ArmorItem({
        ID: 16102,
        Component: "arena_monkey_king/R_base_Rec_Blaze/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_CRUEL: new ArmorItem({
        ID: 16103,
        Component: "arena_monkey_king/E_Cruel/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_CRUEL_REC_SEASON: new ArmorItem({
        ID: 16104,
        Component: "arena_monkey_king/E_Cruel_Rec_Season/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_SYLVAN: new ArmorItem({
        ID: 16105,
        Component: "arena_monkey_king/E_Sylvan/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_DRAGON: new ArmorItem({
        ID: 16106,
        Component: "arena_monkey_king/E_Dragon/arm_monkey_king",
    }),
    ARM_MONKEY_KING_L_CRYSTAL: new ArmorItem({
        ID: 16107,
        Component: "arena_monkey_king/L_Crystal/arm_monkey_king",
    }),
    ARM_MONKEY_KING_E_DRAGON_REC_SEASON: new ArmorItem({
        ID: 16108,
        Component: "arena_monkey_king/E_Dragon_Rec_Season/arm_monkey_king",
    }),
    ARM_SARGE: new ArmorItem({
        ID: 17100,
        Component: "arena_sarge/_base/arm_sarge",
    }),
    ARM_SARGE_R_DARK: new ArmorItem({
        ID: 17102,
        Component: "arena_sarge/R_Dark/arm_sarge",
    }),
    ARM_SARGE_E_JAILER: new ArmorItem({
        ID: 17103,
        Component: "arena_sarge/E_Jailer/arm_sarge",
    }),
    ARM_SARGE_E_JAILER_REC_BOSS: new ArmorItem({
        ID: 17104,
        Component: "arena_sarge/E_Jailer_Rec_Boss/arm_sarge",
    }),
    ARM_SARGE_E_VIKING: new ArmorItem({
        ID: 17105,
        Component: "arena_sarge/E_Viking/arm_sarge",
    }),
    ARM_SARGE_E_VIKING_REC_SEASON: new ArmorItem({
        ID: 17106,
        Component: "arena_sarge/E_Viking_Rec_Season/arm_sarge",
    }),
    ARM_SARGE_E_CHITIN: new ArmorItem({
        ID: 17107,
        Component: "arena_sarge/E_Chitin/arm_sarge",
    }),
    ARM_SARGE_E_CHITIN_REC_WINTER: new ArmorItem({
        ID: 17108,
        Component: "arena_sarge/E_Chitin_Rec_Winter/arm_sarge",
    }),
    ARM_SARGE_E_CHITIN_REC_SEASON: new ArmorItem({
        ID: 17109,
        Component: "arena_sarge/E_Chitin_Rec_Season/arm_sarge",
    }),
    ARM_SARGE_E_SUNNY: new ArmorItem({
        ID: 17110,
        Component: "arena_sarge/E_Sunny/arm_sarge",
    }),
    ARM_YUKKA: new ArmorItem({
        ID: 18100,
        Component: "arena_yukka/_base/arm_yukka",
    }),
    ARM_YUKKA_R_RED: new ArmorItem({
        ID: 18101,
        Component: "arena_yukka/R_Red/arm_yukka",
    }),
    ARM_YUKKA_E_CAT: new ArmorItem({
        ID: 18103,
        Component: "arena_yukka/E_Cat/arm_yukka",
    }),
    ARM_YUKKA_E_WAYFARER: new ArmorItem({
        ID: 18104,
        Component: "arena_yukka/E_Wayfarer/arm_yukka",
    }),
    ARM_YUKKA_E_CAT_REC_BLACK: new ArmorItem({
        ID: 18105,
        Component: "arena_yukka/E_Cat_Rec_Black/arm_yukka",
    }),
    ARM_YUKKA_E_REBEL: new ArmorItem({
        ID: 18106,
        Component: "arena_yukka/E_Rebel/arm_yukka",
    }),
    ARM_YUKKA_E_REBEL_REC_SEASON: new ArmorItem({
        ID: 18107,
        Component: "arena_yukka/E_Rebel_Rec_Season/arm_yukka",
    }),
    ARM_YUKKA_E_WAYFARER_REC_FLOWER: new ArmorItem({
        ID: 18108,
        Component: "arena_yukka/E_Wayfarer_Rec_Flower/arm_yukka",
    }),
    ARM_VIPER: new ArmorItem({
        ID: 19100,
        Component: "arena_viper/_base/arm_viper",
    }),
    ARM_VIPER_R_BASE_REC_BRAT: new ArmorItem({
        ID: 19101,
        Component: "arena_viper/R_base_Rec_Brat/arm_viper",
    }),
    ARM_VIPER_E_GRAFFITY: new ArmorItem({
        ID: 19102,
        Component: "arena_viper/E_Graffiti/arm_viper",
    }),
    ARM_VIPER_R_BASE_REC_VAMPIRE: new ArmorItem({
        ID: 19103,
        Component: "arena_viper/R_base_Rec_Vampire/arm_viper",
    }),
    ARM_VIPER_E_MOBSTER: new ArmorItem({
        ID: 19104,
        Component: "arena_viper/E_Mobster/arm_viper",
    }),
    ARM_VIPER_E_GRAFFITY_REC_SEASON: new ArmorItem({
        ID: 19105,
        Component: "arena_viper/E_Graffiti_Rec_Season/arm_viper",
    }),
    ARM_VIPER_E_MOBSTER_REC_GLOW: new ArmorItem({
        ID: 19106,
        Component: "arena_viper/E_Mobster_Rec_Glow/arm_viper",
    }),
    ARM_LEGION_KING: new ArmorItem({
        ID: 20100,
        Component: "arena_legion_king/_base/arm_legion_king",
    }),
    ARM_LEGION_KING_R_VINY: new ArmorItem({
        ID: 20101,
        Component: "arena_legion_king/R_Viny/arm_legion_king",
    }),
    ARM_LEGION_KING_R_REC_BOSS: new ArmorItem({
        ID: 20102,
        Component: "arena_legion_king/R_Rec_Boss/arm_legion_king",
    }),
    ARM_LEGION_KING_E_BONE: new ArmorItem({
        ID: 20103,
        Component: "arena_legion_king/E_Bone/arm_legion_king",
    }),
    ARM_LEGION_KING_E_BONE_REC_LICH: new ArmorItem({
        ID: 20104,
        Component: "arena_legion_king/E_Bone_Rec_Lich/arm_legion_king",
    }),
    ARM_LEGION_KING_E_PRINCE: new ArmorItem({
        ID: 20105,
        Component: "arena_legion_king/E_Prince/arm_legion_king",
    }),
    ARM_LEGION_KING_E_PRINCE_REC_SEASON: new ArmorItem({
        ID: 20106,
        Component: "arena_legion_king/E_Prince_Rec_Season/arm_legion_king",
    }),
    ARM_LEGION_KING_L_CASTLE: new ArmorItem({
        ID: 20107,
        Component: "arena_legion_king/L_Castle/arm_legion_king",
    }),
    ARM_BUTCHER: new ArmorItem({
        ID: 21100,
        Component: "arena_butcher/_base/arm_butcher",
    }),
    ARM_BUTCHER_R_PURPLE: new ArmorItem({
        ID: 21101,
        Component: "arena_butcher/R_Purple/arm_butcher",
    }),
    ARM_BUTCHER_R_BIKER: new ArmorItem({
        ID: 21103,
        Component: "arena_butcher/R_Biker/arm_butcher",
    }),
    ARM_BUTCHER_E_MOGWAI: new ArmorItem({
        ID: 21102,
        Component: "arena_butcher/E_Mogwai/arm_butcher",
    }),
    ARM_BUTCHER_E_MOGWAI_REC_SEASON: new ArmorItem({
        ID: 21104,
        Component: "arena_butcher/E_Mogwai_Rec_Season/arm_butcher",
    }),
    ARM_BUTCHER_E_KHAN: new ArmorItem({
        ID: 21105,
        Component: "arena_butcher/E_Khan/arm_butcher",
    }),
    ARM_BUTCHER_E_KHAN_REC_SEASON: new ArmorItem({
        ID: 21106,
        Component: "arena_butcher/E_Khan_Rec_Season/arm_butcher",
    }),
    ARM_BUTCHER_E_SUSHI: new ArmorItem({
        ID: 21107,
        Component: "arena_butcher/E_Sushi/arm_butcher",
    }),
    ARM_ITU: new ArmorItem({
        ID: 22100,
        Component: "arena_itu/_base/arm_itu",
    }),
    ARM_ITU_R_RED: new ArmorItem({
        ID: 22101,
        Component: "arena_itu/R_Red/arm_itu",
    }),
    ARM_ITU_E_DEMON: new ArmorItem({
        ID: 22102,
        Component: "arena_itu/E_Demon/arm_itu",
    }),
    ARM_ITU_R_STAR: new ArmorItem({
        ID: 22103,
        Component: "arena_itu/R_Star/arm_itu",
    }),
    ARM_ITU_E_DEMON_REC_SEASON: new ArmorItem({
        ID: 22104,
        Component: "arena_itu/E_Demon_Rec_Season/arm_itu",
    }),
    ARM_ITU_E_MASTER: new ArmorItem({
        ID: 22105,
        Component: "arena_itu/E_Master/arm_itu",
    }),
    ARM_ITU_L_COSMIC: new ArmorItem({
        ID: 22106,
        Component: "arena_itu/L_Cosmic/arm_itu",
    }),
    ARM_XIANG_TZU: new ArmorItem({
        ID: 24100,
        Component: "arena_xiang_tzu/_base/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_R_FIGHTER: new ArmorItem({
        ID: 24101,
        Component: "arena_xiang_tzu/R_Fighter/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_E_WINNER: new ArmorItem({
        ID: 24102,
        Component: "arena_xiang_tzu/E_Winner/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_E_REIVER: new ArmorItem({
        ID: 24103,
        Component: "arena_xiang_tzu/E_Reiver/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_E_REAVER_REC_SEASON: new ArmorItem({
        ID: 24104,
        Component: "arena_xiang_tzu/E_Reiver_Rec_Season/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_E_INDIAN: new ArmorItem({
        ID: 24105,
        Component: "arena_xiang_tzu/E_Indian/arm_xiang_tzu",
    }),
    ARM_XIANG_TZU_E_INDIAN_REC_WHITE: new ArmorItem({
        ID: 24106,
        Component: "arena_xiang_tzu/E_Indian_Rec_White/arm_xiang_tzu",
    }),
    ARM_YUNLIN: new ArmorItem({
        ID: 23100,
        Component: "arena_yunlin/_base/arm_yunlin",
    }),
    ARM_YUNLIN_R_HAZY: new ArmorItem({
        ID: 23101,
        Component: "arena_yunlin/R_Hazy/arm_yunlin",
    }),
    ARM_YUNLIN_R_SPRING: new ArmorItem({
        ID: 23106,
        Component: "arena_yunlin/R_Spring/arm_yunlin",
    }),
    ARM_YUNLIN_E_BRIDE: new ArmorItem({
        ID: 23102,
        Component: "arena_yunlin/E_Bride/arm_yunlin",
    }),
    ARM_YUNLIN_E_BRIDE_REC_SEASON: new ArmorItem({
        ID: 23103,
        Component: "arena_yunlin/E_Bride_Rec_Season/arm_yunlin",
    }),
    ARM_YUNLIN_E_BRIDE_REC_INDIAN: new ArmorItem({
        ID: 23104,
        Component: "arena_yunlin/E_Bride_Rec_Indian/arm_yunlin",
    }),
    ARM_YUNLIN_E_WINTER: new ArmorItem({
        ID: 23105,
        Component: "arena_yunlin/E_Winter/arm_yunlin",
    }),
    ARM_JUNE: new ArmorItem({
        ID: 25100,
        Component: "arena_june/_base/arm_june",
    }),
    ARM_JUNE_R_STAR: new ArmorItem({
        ID: 25101,
        Component: "arena_june/R_Star/arm_june",
    }),
    ARM_JUNE_E_EMPRESS: new ArmorItem({
        ID: 25102,
        Component: "arena_june/E_Empress/arm_june",
    }),
    ARM_JUNE_E_EMPRESS_REC_SEASON: new ArmorItem({
        ID: 25103,
        Component: "arena_june/E_Empress_Rec_Season/arm_june",
    }),
    ARM_JUNE_E_SAKURA: new ArmorItem({
        ID: 25104,
        Component: "arena_june/E_Sakura/arm_june",
    }),
    ARM_JUNE_E_SAKURA_REC_SEASON: new ArmorItem({
        ID: 25105,
        Component: "arena_june/E_Sakura_Rec_Season/arm_june",
    }),
    ARM_GIDEON: new ArmorItem({
        ID: 26100,
        Component: "arena_gideon/_base/arm_gideon",
    }),
    ARM_GIDEON_E_MASK: new ArmorItem({
        ID: 26101,
        Component: "arena_gideon/E_Mask/arm_gideon",
    }),
    ARM_GIDEON_E_MASK_REC_SEASON: new ArmorItem({
        ID: 26102,
        Component: "arena_gideon/E_Mask_Rec_Season/arm_gideon",
    }),
    ARM_GIDEON_E_FORWARDER: new ArmorItem({
        ID: 26103,
        Component: "arena_gideon/E_Forwarder/arm_gideon",
    }),
    ARM_GIDEON_E_COWBOY: new ArmorItem({
        ID: 26104,
        Component: "arena_gideon/R_Jango/arm_gideon",
    }),
    ARM_WIDOW: new ArmorItem({
        ID: 27100,
        Component: "arena_widow/_base/arm_widow",
    }),
    ARM_WIDOW_R_SEER: new ArmorItem({
        ID: 27101,
        Component: "arena_widow/R_Seer/arm_widow",
    }),
    ARM_WIDOW_E_BONEMOTH: new ArmorItem({
        ID: 27102,
        Component: "arena_widow/E_Bonemoth/arm_widow",
    }),
    ARM_WIDOW_E_BONEMOTH_REC_SEASON: new ArmorItem({
        ID: 27103,
        Component: "arena_widow/E_Bonemoth_Rec_Season/arm_widow",
    }),
    ARM_WIDOW_E_NIGHT: new ArmorItem({
        ID: 27104,
        Component: "arena_widow/E_Night/arm_widow",
    }),
    ARM_RAIKICHI: new ArmorItem({
        ID: 28100,
        Component: "arena_raikichi/_base/arm_raikichi",
    }),
    ARM_RAIKICHI_R_BASE_REC_INKY: new ArmorItem({
        ID: 28101,
        Component: "arena_raikichi/R_Base_Rec_Inky/arm_raikichi",
    }),
    ARM_RAIKICHI_E_BURNED: new ArmorItem({
        ID: 28102,
        Component: "arena_raikichi/E_Burned/arm_raikichi",
    }),
    ARM_RAIKICHI_E_BURNED_REC_SEASON: new ArmorItem({
        ID: 28103,
        Component: "arena_raikichi/E_Burned_Rec_Season/arm_raikichi",
    }),
    ARM_NONNA: new ArmorItem({
        ID: 29100,
        Component: "arena_nonna/_base/arm_nonna",
    }),
    ARM_NONNA_R_CELTIC: new ArmorItem({
        ID: 29101,
        Component: "arena_nonna/R_Celtic/arm_nonna",
    }),
    ARM_NONNA_E_VALKYRIE: new ArmorItem({
        ID: 29102,
        Component: "arena_nonna/E_Valkyrie/arm_nonna",
    }),
    ARM_NONNA_E_VALKYRIE_REC_SEASON: new ArmorItem({
        ID: 29103,
        Component: "arena_nonna/E_Valkyrie_Rec_Season/arm_nonna",
    }),
    ARM_SHOGUN: new ArmorItem({
        ID: 30100,
        Component: "arena_shogun/_base/arm_shogun",
    }),
    ARM_SHOGUN_R_RED: new ArmorItem({
        ID: 30101,
        Component: "arena_shogun/R_Red/arm_shogun",
    }),
};
var armorsPvE = {
    dd_tier1: new ArmorItem({
        ID: 61301,
        Component: "arena_pve_models/arena_legion_damage/arm_tier1",
    }),
    mage_tier1: new ArmorItem({
        ID: 61302,
        Component: "arena_pve_models/arena_legion_mage/arm_tier1",
    }),
    tank_tier1: new ArmorItem({
        ID: 61303,
        Component: "arena_pve_models/arena_legion_tank/arm_tier1",
    }),
    dd_tier2: new ArmorItem({
        ID: 61304,
        Component: "arena_pve_models/arena_legion_damage/arm_tier2",
    }),
    mage_tier2: new ArmorItem({
        ID: 61305,
        Component: "arena_pve_models/arena_legion_mage/arm_tier2",
    }),
    tank_tier2: new ArmorItem({
        ID: 61306,
        Component: "arena_pve_models/arena_legion_tank/arm_tier2",
    }),
    dd_tier3: new ArmorItem({
        ID: 61307,
        Component: "arena_pve_models/arena_legion_damage/arm_tier3",
    }),
    tank_tier3: new ArmorItem({
        ID: 61308,
        Component: "arena_pve_models/arena_legion_tank/arm_tier3",
    }),
    mage_tier3: new ArmorItem({
        ID: 61309,
        Component: "arena_pve_models/arena_legion_mage/arm_tier3",
    }),
    dynasty_tank_arm_tier2: new ArmorItem({
        ID: 63301,
        Component: "arena_pve_models/arena_dynasty_tank/dynasty_tank_arm_tier2",
    }),
    dynasty_killer_arm_tier2: new ArmorItem({
        ID: 63302,
        Component: "arena_pve_models/arena_dynasty_killer/dynasty_killer_arm_tier2",
    }),
    dynasty_healer_arm_tier1: new ArmorItem({
        ID: 63303,
        Component: "arena_pve_models/arena_dynasty_healer/dynasty_healer_arm_tier1",
    }),
    dynasty_healer_arm_tier2: new ArmorItem({
        ID: 63304,
        Component: "arena_pve_models/arena_dynasty_healer/dynasty_healer_arm_tier2",
    }),
    dynasty_mage_arm_tier1: new ArmorItem({
        ID: 63305,
        Component: "arena_pve_models/arena_dynasty_mage/dynasty_mage_arm_tier1",
    }),
    dynasty_mage_arm_tier2: new ArmorItem({
        ID: 63306,
        Component: "arena_pve_models/arena_dynasty_mage/dynasty_mage_arm_tier2",
    }),
    dynasty_tank_arm_tier1: new ArmorItem({
        ID: 63307,
        Component: "arena_pve_models/arena_dynasty_tank/dynasty_tank_arm_tier1",
    }),
    dynasty_killer_arm_tier1: new ArmorItem({
        ID: 63308,
        Component: "arena_pve_models/arena_dynasty_killer/dynasty_killer_arm_tier1",
    }),
    dynasty_tank_arm_tier2_rec_tier3_boss: new ArmorItem({
        ID: 63309,
        Component: "arena_pve_models/arena_dynasty_tank/dynasty_tank_arm_tier2_rec_tier3_boss",
    }),
    dynasty_mage_arm_tier2_rec_tier3_boss: new ArmorItem({
        ID: 63310,
        Component: "arena_pve_models/arena_dynasty_mage/dynasty_mage_arm_tier2_rec_tier3_boss",
    }),
    dynasty_healer_arm_tier2_rec_tier3_boss: new ArmorItem({
        ID: 63311,
        Component: "arena_pve_models/arena_dynasty_healer/dynasty_healer_arm_tier2_rec_tier3_boss",
    }),
    dynasty_killer_arm_tier2_rec_tier3_boss: new ArmorItem({
        ID: 63312,
        Component: "arena_pve_models/arena_dynasty_killer/dynasty_killer_arm_tier2_rec_tier3_boss",
    }),
    dynasty_monster: new ArmorItem({
        ID: 68301,
        Component: "arena_pve_models/arena_dynasty_monster/arm_monster",
    }),
};
