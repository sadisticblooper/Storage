var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CustomizationRewardChecker = (function () {
    function CustomizationRewardChecker(settings, result) {
        this.settings = settings;
        this.result = result;
    }
    CustomizationRewardChecker.prototype.breakChecking = function () {
        return Object.keys(this.result).length == this.settings.customizationIDs.length;
    };
    CustomizationRewardChecker.prototype.checkRewardContentCustomization = function (reward, placementInfo) {
        var loot = new Loot();
        var customizationType = this.settings.customizationType;
        var customizationIDs = this.settings.customizationIDs;
        if (reward) {
            if (reward.loot) {
                loot.combineLoot(reward.loot);
            }
            if (reward.lootSettings && reward.lootSettings.AdditionalFixedLoot) {
                loot.combineLoot(reward.lootSettings.AdditionalFixedLoot);
            }
        }
        var lootIds = CustomizationUtils.getLootIdsContainer(customizationType, loot);
        for (var _i = 0, customizationIDs_1 = customizationIDs; _i < customizationIDs_1.length; _i++) {
            var id = customizationIDs_1[_i];
            if (lootIds.indexOf(id) > -1 && !this.result[id]) {
                this.result[id] = { placementInfo: placementInfo, reason: null };
            }
        }
    };
    CustomizationRewardChecker.prototype.checkLootCustomization = function (loot, placementInfo) {
        this.checkRewardContentCustomization({ loot: loot }, placementInfo);
    };
    CustomizationRewardChecker.prototype.checkRewardCustomization = function (r, placementInfo) {
        r && this.checkRewardContentCustomization({ loot: r.Loot, chests: r.Chests }, placementInfo);
    };
    return CustomizationRewardChecker;
}());
var ShopChestsCustomizationRewardChecker = (function (_super) {
    __extends(ShopChestsCustomizationRewardChecker, _super);
    function ShopChestsCustomizationRewardChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ShopChestsCustomizationRewardChecker.prototype.checkCustomizationPlacement = function () {
        var customizationType = this.settings.customizationType;
        var customizationIds = this.settings.customizationIDs;
        var playerProgress = this.settings.playerProgress;
        var shopChests = [];
        for (var _i = 0, _a = ShopSlotsPreset.chestShop; _i < _a.length; _i++) {
            var slot = _a[_i];
            var chestId = slot.SlotVariants && slot.SlotVariants[0] && slot.SlotVariants[0].ChestId;
            if (chestId) {
                shopChests.push(chestId);
            }
        }
        if (customizationType == CUSTOMIZATION.WEAPON
            && playerProgress.maxPlayerRating < WeaponConstants.lowerRatingOfIssueWeapon) {
            if (shopChests.indexOf(chests.Weapon_chest.ID) > -1) {
                shopChests = [chests.Weapon_chest.ID];
            }
            else {
                for (var _b = 0, customizationIds_1 = customizationIds; _b < customizationIds_1.length; _b++) {
                    var id = customizationIds_1[_b];
                    if (!this.result[id]) {
                        this.result[id] = {
                            placementInfo: { placement: META_PLACEMENT.UNKNOWN, target: 0 },
                            reason: {
                                isAlias: true,
                                value: HeroConstants.aliasesForFindButton.reachArenaToUnlockWeapon,
                                placeholders: null
                            },
                        };
                    }
                }
                return;
            }
        }
        var iterator = [
            { targetPlace: META_PLACEMENT.SHOP_CHESTS, target: SHOP_TYPE.CHEST, chestIds: shopChests },
            {
                targetPlace: META_PLACEMENT.SHOP_SPECIAL,
                target: SHOP_TYPE.EVENT_SHOP,
                chestIds: this.settings.eventChestIDs,
            },
            {
                targetPlace: META_PLACEMENT.SHOP_SPECIAL,
                target: SHOP_TYPE.SEASON_SHOP,
                chestIds: this.settings.seasonChestIDs,
            },
        ];
        for (var _c = 0, iterator_1 = iterator; _c < iterator_1.length; _c++) {
            var iteration = iterator_1[_c];
            var targetPlace = iteration.targetPlace, target = iteration.target, chestIds = iteration.chestIds;
            for (var _d = 0, chestIds_1 = chestIds; _d < chestIds_1.length; _d++) {
                var chestId = chestIds_1[_d];
                var chest = chestsMap.checkedGet(chestId);
                var lootSettings = chest.getLootSettingsFromPlayerProgress(playerProgress, true);
                var fixedLoot = lootSettings.AdditionalFixedLoot;
                var availableIds = [];
                var specify_1 = { chestId: chestId };
                var customizationSettings = {
                    playerIds: CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress),
                    lootIds: fixedLoot && CustomizationUtils.getLootSettingsIdsContainer(customizationType, fixedLoot),
                    availableList: CustomizationUtils.getAvailableIdsForRandomGenerating(customizationType, specify_1),
                    customizationMap: CustomizationUtils.getOrderMap(customizationType),
                    pseudorandomType: CustomizationUtils.getTypeChestTooltipTypeByCustomization(customizationType),
                    customizationLootSettings: CustomizationUtils
                        .getGeneratorLootSettingsContainer(customizationType, lootSettings),
                };
                var checkSettings = customizationSettings.pseudorandomType != undefined
                    && customizationSettings.customizationMap != undefined
                    && customizationSettings.playerIds != undefined
                    && customizationSettings.availableList != undefined
                    && customizationSettings.customizationLootSettings != undefined;
                if (checkSettings) {
                    if (customizationSettings.lootIds) {
                        availableIds = customizationSettings.lootIds;
                    }
                    if (customizationSettings.customizationLootSettings) {
                        var ids = LootUtils.getAvailableCustomizationsForGenerating({
                            customizationSettings: customizationSettings.customizationLootSettings,
                            customizationMap: customizationSettings.customizationMap,
                            availableList: customizationSettings.availableList,
                            playerIds: customizationSettings.playerIds,
                            playerProgress: playerProgress,
                            customizationType: customizationType
                        });
                        availableIds = availableIds.concat(ids);
                    }
                    for (var _e = 0, customizationIds_2 = customizationIds; _e < customizationIds_2.length; _e++) {
                        var cId = customizationIds_2[_e];
                        if (availableIds.indexOf(cId) > -1 && !this.result[cId]) {
                            this.result[cId] = {
                                placementInfo: { placement: targetPlace, target: target },
                                reason: null,
                            };
                        }
                    }
                    if (this.breakChecking()) {
                        return;
                    }
                    var tooltip = PseudorandomSettings.settings[chestId]
                        && PseudorandomSettings.settings[chestId].tooltipProbabilities
                        && PseudorandomSettings.settings[chestId]
                            .tooltipProbabilities[customizationSettings.pseudorandomType];
                    if (!tooltip && (customizationType == CUSTOMIZATION.STANCE || customizationType == CUSTOMIZATION.TAUNT)) {
                        tooltip = PseudorandomSettings.settings[chestId]
                            && PseudorandomSettings.settings[chestId].tooltipProbabilities
                            && PseudorandomSettings.settings[chestId]
                                .tooltipProbabilities[CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS];
                    }
                    if (tooltip) {
                        var ids = LootUtils.getAvailableCustomizationsForGenerating({
                            customizationSettings: { Rarities: tooltip },
                            customizationMap: customizationSettings.customizationMap,
                            availableList: customizationSettings.availableList,
                            playerIds: customizationSettings.playerIds,
                            playerProgress: playerProgress,
                            customizationType: customizationType
                        });
                        for (var _f = 0, customizationIds_3 = customizationIds; _f < customizationIds_3.length; _f++) {
                            var cId = customizationIds_3[_f];
                            if (ids.indexOf(cId) > -1 && !this.result[cId]) {
                                this.result[cId] = {
                                    placementInfo: { placement: targetPlace, target: target },
                                    reason: null,
                                };
                            }
                        }
                    }
                }
            }
        }
    };
    return ShopChestsCustomizationRewardChecker;
}(CustomizationRewardChecker));
