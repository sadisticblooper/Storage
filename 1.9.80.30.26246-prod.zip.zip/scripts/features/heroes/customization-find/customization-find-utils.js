var CustomizationFindUtils = (function () {
    function CustomizationFindUtils() {
    }
    CustomizationFindUtils.getCustomizationPlacement = function (params) {
        var result = {};
        var ids = params.customizationIDs;
        var customizationType = params.customizationType;
        CommonUtils.replaceReadOnlyProperty(params, "playerProgress", PlayerState.getCorrectFromRawOrCache(params.playerProgress));
        var checks = [
            new ShopChestsCustomizationRewardChecker(params, result),
        ];
        for (var _i = 0, checks_1 = checks; _i < checks_1.length; _i++) {
            var check = checks_1[_i];
            if (check.breakChecking()) {
                break;
            }
            check.checkCustomizationPlacement();
        }
        for (var _a = 0, ids_1 = ids; _a < ids_1.length; _a++) {
            var id = ids_1[_a];
            if (!result[id]) {
                result[id] = {
                    placementInfo: { placement: META_PLACEMENT.UNKNOWN, target: 0 },
                    reason: {
                        isAlias: true,
                        value: CustomizationUtils.getDefaultUnavailableAlias(customizationType, id),
                        placeholders: null
                    },
                };
            }
        }
        return result;
    };
    CustomizationFindUtils.getPresetCustomizationPlacements = function (params) {
        var result = {};
        var ids = params.customizationIDs;
        var customizationType = params.customizationType;
        for (var _i = 0, ids_2 = ids; _i < ids_2.length; _i++) {
            var id = ids_2[_i];
            var customUnlockedPlacement = this.getCustomUnlockedPlacement(customizationType, id);
            if (customUnlockedPlacement && !result[id]) {
                result[id] = customUnlockedPlacement;
            }
            if (!result[id] && customizationType == CUSTOMIZATION.WEAPON && Skin.WeaponsInKit.indexOf(id) > -1) {
                for (var _a = 0, _b = skinsMap.getKeys(); _a < _b.length; _a++) {
                    var skinId = _b[_a];
                    var skin = skinsMap.get(skinId);
                    if (skin.WeaponId == id) {
                        result[id] = {
                            placementInfo: { placement: META_PLACEMENT.CUSTOMIZATION_SKINS, target: skinId },
                            reason: null
                        };
                    }
                }
            }
        }
        return result;
    };
    CustomizationFindUtils.getCustomUnlockedPlacement = function (type, id) {
        var orderMap = CustomizationUtils.getOrderMap(type);
        if (orderMap == null) {
            return null;
        }
        var item = orderMap.get(id);
        return item && item.customUnlockedPlacement;
    };
    CustomizationFindUtils.getCustomizationSearchPriorityList = function () {
        return [
            META_PLACEMENT.PROMO_OFFERS,
            META_PLACEMENT.ARENA_REWARDS,
            META_PLACEMENT.BATTLE_PASS,
            META_PLACEMENT.DAILY_OFFERS,
            META_PLACEMENT.TOURNAMENTS,
            META_PLACEMENT.ROULETTE,
            META_PLACEMENT.MARATHONS,
            META_PLACEMENT.SHOP_SPECIAL,
            META_PLACEMENT.GACHA_BANNER,
        ];
    };
    return CustomizationFindUtils;
}());
