var TextEmojiPackVisuals = (function () {
    function TextEmojiPackVisuals() {
    }
    TextEmojiPackVisuals.default = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 450,
            "labelColor": "#171717FF",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_bg",
                "color": "#FFFFFFFF",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_tail",
                "color": "#FFFFFFFF",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null,
        },
        "bubbles": [
            {
                "alias": "textemote_hero_Universal_Hello"
            },
            {
                "alias": "textemote_hero_Universal_Thanks"
            },
            {
                "alias": "textemote_hero_Universal_Oops"
            },
            {
                "alias": "textemote_hero_Universal_Goodgame"
            },
            {
                "alias": "textemote_hero_Universal_Wellplayed"
            },
            {
                "alias": "textemote_hero_Universal_Rematch"
            },
            {
                "alias": "textemote_hero_Universal_Letsgo"
            },
            {
                "alias": "textemote_hero_Universal_Keepfighting"
            }
        ]
    };
    TextEmojiPackVisuals.recCyan = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 450,
            "labelColor": "#171717FF",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_bg",
                "color": "#7ed6e6",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_tail",
                "color": "#7ed6e6",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "textemote_hero_Universal_Hello"
            },
            {
                "alias": "textemote_hero_Universal_Thanks"
            },
            {
                "alias": "textemote_hero_Universal_Oops"
            },
            {
                "alias": "textemote_hero_Universal_Goodgame"
            },
            {
                "alias": "textemote_hero_Universal_Wellplayed"
            },
            {
                "alias": "textemote_hero_Universal_Rematch"
            },
            {
                "alias": "textemote_hero_Universal_Letsgo"
            },
            {
                "alias": "textemote_hero_Universal_Keepfighting"
            }
        ]
    };
    TextEmojiPackVisuals.recDark = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 450,
            "labelColor": "#5ee7ff",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_bg",
                "color": "#171717FF",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_tail",
                "color": "#171717FF",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "textemote_hero_Universal_Hello"
            },
            {
                "alias": "textemote_hero_Universal_Thanks"
            },
            {
                "alias": "textemote_hero_Universal_Oops"
            },
            {
                "alias": "textemote_hero_Universal_Goodgame"
            },
            {
                "alias": "textemote_hero_Universal_Wellplayed"
            },
            {
                "alias": "textemote_hero_Universal_Rematch"
            },
            {
                "alias": "textemote_hero_Universal_Letsgo"
            },
            {
                "alias": "textemote_hero_Universal_Keepfighting"
            }
        ]
    };
    TextEmojiPackVisuals.arena = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 4,
            "labelWidth": 370,
            "labelColor": "#5ee7ff",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Arena/text_emoji_Arena_bg",
                "color": "#FFFFFFFF",
                "leftOffset": -52,
                "rightOffset": -52,
                "topOffset": -52,
                "bottomOffset": -52
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Arena/text_emoji_Arena_tail",
                "color": "#FFFFFFFF",
                "position": {
                    "x": 5,
                    "y": -50
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": {
                "enabled": true,
                "vfxPrefab": "Sprites/Assets/TextEmoji/Arena/text_emoji_Arena_vfx_left",
                "vfxPreviewPrefab": "Sprites/Assets/TextEmoji/Arena/text_emoji_Arena_vfx_left_preview_1",
                "anchors": {
                    "minY": 0,
                    "maxY": 0
                },
                "position": {
                    "x": 50,
                    "y": 50
                },
                "scale": {
                    "x": 1,
                    "y": 1
                },
            },
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_E_Arena_Birthday_hello_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSF3/icon_Arena",
                    "color": "#47E3FF45",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 103,
                        "y": 60
                    },
                    "size": {
                        "width": 230,
                        "height": 230
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 10
                }
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_thanks_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_thanks_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_oops_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_oops_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_gg_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_gg_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_wp_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_wp_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_rematch_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_rematch_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_go_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_go_short",
            },
            {
                "alias": "text_bubble_E_Arena_Birthday_keep_fighting_long",
                "previewAlias": "text_bubble_E_Arena_Birthday_keep_fighting_short",
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSF3/icon_Arena",
                    "color": "#47E3FF45",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -95,
                        "y": 60
                    },
                    "size": {
                        "width": 230,
                        "height": 230
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": -10
                }
            }
        ]
    };
    TextEmojiPackVisuals.legionKing = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 4,
            "labelWidth": 450,
            "labelColor": "#a3ffd6",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_bg",
                "color": "#103e42",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_tail",
                "color": "#103e42",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Dreadmoon_hello_long",
                "previewAlias": "text_bubble_R_Dreadmoon_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_moon",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 112,
                        "y": -53
                    },
                    "size": {
                        "width": 360,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -70,
                        "y": 48
                    },
                    "size": {
                        "width": 288,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_thanks_long",
                "previewAlias": "text_bubble_R_Dreadmoon_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 48,
                        "y": 53
                    },
                    "size": {
                        "width": 240,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -70,
                        "y": -60
                    },
                    "size": {
                        "width": 272,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_oops_long",
                "previewAlias": "text_bubble_R_Dreadmoon_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 114,
                        "y": 53
                    },
                    "size": {
                        "width": 364,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -60,
                        "y": -50
                    },
                    "size": {
                        "width": 268,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_gg_long",
                "previewAlias": "text_bubble_R_Dreadmoon_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_moon",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 112,
                        "y": -53
                    },
                    "size": {
                        "width": 360,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -70,
                        "y": 48
                    },
                    "size": {
                        "width": 288,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_wp_long",
                "previewAlias": "text_bubble_R_Dreadmoon_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 48,
                        "y": 53
                    },
                    "size": {
                        "width": 240,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -70,
                        "y": -60
                    },
                    "size": {
                        "width": 272,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_rematch_long",
                "previewAlias": "text_bubble_R_Dreadmoon_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 114,
                        "y": 53
                    },
                    "size": {
                        "width": 364,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -60,
                        "y": -50
                    },
                    "size": {
                        "width": 268,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_go_long",
                "previewAlias": "text_bubble_R_Dreadmoon_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 114,
                        "y": 53
                    },
                    "size": {
                        "width": 364,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -60,
                        "y": -50
                    },
                    "size": {
                        "width": 268,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dreadmoon_keep_fighting_long",
                "previewAlias": "text_bubble_R_Dreadmoon_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_moon",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 112,
                        "y": -53
                    },
                    "size": {
                        "width": 360,
                        "height": 252
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/LegionKing/text_emoji_LegionKing_decor_hands_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -70,
                        "y": 48
                    },
                    "size": {
                        "width": 288,
                        "height": 252
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.stellarChorale = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 340,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#d1dce5",
                "colorBottom": "#7d848a"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_bg",
                "color": "#ffffff",
                "leftOffset": -75,
                "rightOffset": -75,
                "topOffset": -75,
                "bottomOffset": -75
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_tail",
                "color": "#ffffff",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Stellar_Chorale_hello_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_thanks_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_oops_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_7",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_8",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_gg_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_7",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_8",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_wp_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_rematch_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_go_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Stellar_Chorale_keep_fighting_long",
                "previewAlias": "text_bubble_R_Stellar_Chorale_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 82,
                        "y": 82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/StellarChorale/text_emoji_stellarChorale_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -82,
                        "y": -82
                    },
                    "size": {
                        "width": 88,
                        "height": 88
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.elegant = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 400,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#618aab",
                "colorBottom": "#e3f1fc"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Elegant/text_emoji_elegant_bg",
                "color": "#FFFFFFFF",
                "leftOffset": -72,
                "rightOffset": -72,
                "topOffset": -72,
                "bottomOffset": -72
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Elegant/text_emoji_elegant_tail",
                "color": "#FFFFFFFF",
                "position": {
                    "x": -5,
                    "y": -53
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Elegant_hello_long",
                "previewAlias": "text_bubble_R_Elegant_hello_short"
            },
            {
                "alias": "text_bubble_R_Elegant_thanks_long",
                "previewAlias": "text_bubble_R_Elegant_thanks_short"
            },
            {
                "alias": "text_bubble_R_Elegant_oops_long",
                "previewAlias": "text_bubble_R_Elegant_oops_short"
            },
            {
                "alias": "text_bubble_R_Elegant_gg_long",
                "previewAlias": "text_bubble_R_Elegant_gg_short"
            },
            {
                "alias": "text_bubble_R_Elegant_wp_long",
                "previewAlias": "text_bubble_R_Elegant_wp_short"
            },
            {
                "alias": "text_bubble_R_Elegant_rematch_long",
                "previewAlias": "text_bubble_R_Elegant_rematch_short"
            },
            {
                "alias": "text_bubble_R_Elegant_go_long",
                "previewAlias": "text_bubble_R_Elegant_go_short"
            },
            {
                "alias": "text_bubble_R_Elegant_keep_fighting_long",
                "previewAlias": "text_bubble_R_Elegant_keep_fighting_short"
            }
        ]
    };
    TextEmojiPackVisuals.art_of_war = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 305,
            "labelColor": "#ffb647",
            "labelGradient": {
                "enabled": false,
                "colorTop": "#ffb647",
                "colorBottom": "#ffb647"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_bg",
                "color": "#ffffff",
                "leftOffset": -20,
                "rightOffset": -20,
                "topOffset": -20,
                "bottomOffset": -20
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_tail",
                "color": "#ffffff",
                "position": {
                    "x": -12,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Art_Of_War_hello_long",
                "previewAlias": "text_bubble_R_Art_Of_War_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_1",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_2",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_thanks_long",
                "previewAlias": "text_bubble_R_Art_Of_War_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_3",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_4",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_oops_long",
                "previewAlias": "text_bubble_R_Art_Of_War_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_5",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_6",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_gg_long",
                "previewAlias": "text_bubble_R_Art_Of_War_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_5",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_6",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_wp_long",
                "previewAlias": "text_bubble_R_Art_Of_War_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_3",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_4",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_rematch_long",
                "previewAlias": "text_bubble_R_Art_Of_War_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_7",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_8",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_go_long",
                "previewAlias": "text_bubble_R_Art_Of_War_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_7",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_8",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Art_Of_War_keep_fighting_long",
                "previewAlias": "text_bubble_R_Art_Of_War_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_1",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 40,
                        "y": 40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/ArtOfWar/text_emoji_artOfWar_decor_2",
                    "color": "#ffb647ff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -40,
                        "y": -40
                    },
                    "size": {
                        "width": 116,
                        "height": 116
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.brash = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 320,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#ffffff",
                "colorBottom": "#a8abb4"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_bg",
                "color": "#ffffff",
                "leftOffset": -70,
                "rightOffset": -70,
                "topOffset": -70,
                "bottomOffset": -70
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_tail",
                "color": "#ffffff",
                "position": {
                    "x": 0,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Brash_hello_long",
                "previewAlias": "text_bubble_R_Brash_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_1",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_2",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_thanks_long",
                "previewAlias": "text_bubble_R_Brash_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_3",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_4",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_oops_long",
                "previewAlias": "text_bubble_R_Brash_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_3",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_4",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_gg_long",
                "previewAlias": "text_bubble_R_Brash_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_5",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_6",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_wp_long",
                "previewAlias": "text_bubble_R_Brash_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_5",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_6",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_rematch_long",
                "previewAlias": "text_bubble_R_Brash_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_1",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_2",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_go_long",
                "previewAlias": "text_bubble_R_Brash_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_1",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_2",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Brash_keep_fighting_long",
                "previewAlias": "text_bubble_R_Brash_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_3",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Brash/text_emoji_brash_decor_4",
                    "color": "#ffffff",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -80,
                        "y": -42
                    },
                    "size": {
                        "width": 212,
                        "height": 172
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.inspiration = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 320,
            "labelColor": "#452B20",
            "labelGradient": {
                "enabled": false,
                "colorTop": "#ffffff",
                "colorBottom": "#ffffff"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_1",
                "color": "#ffffff",
                "leftOffset": -75,
                "rightOffset": -75,
                "topOffset": -75,
                "bottomOffset": -75
            },
            "backgroundTail": {
                "enabled": false,
                "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_tail",
                "color": "#ffffff",
                "position": {
                    "x": -20,
                    "y": -50
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": {
                "enabled": true,
                "vfxPrefab": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_vfx",
                "vfxPreviewPrefab": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_vfx_empty",
                "anchors": {
                    "minY": 0.5,
                    "maxY": 0.5
                },
                "position": {
                    "x": 0,
                    "y": 0
                },
                "scale": {
                    "x": 1,
                    "y": 1
                }
            },
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_E_Inspiration_hello_long",
                "previewAlias": "text_bubble_E_Inspiration_hello_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_1",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_thanks_long",
                "previewAlias": "text_bubble_E_Inspiration_thanks_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_1",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_oops_long",
                "previewAlias": "text_bubble_E_Inspiration_oops_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_2",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_gg_long",
                "previewAlias": "text_bubble_E_Inspiration_gg_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_3",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_wp_long",
                "previewAlias": "text_bubble_E_Inspiration_wp_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_3",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_rematch_long",
                "previewAlias": "text_bubble_E_Inspiration_rematch_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_2",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_go_long",
                "previewAlias": "text_bubble_E_Inspiration_go_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_2",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": -1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_E_Inspiration_keep_fighting_long",
                "previewAlias": "text_bubble_E_Inspiration_keep_fighting_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_bg_1",
                    "color": "#ffffff",
                    "leftOffset": -75,
                    "rightOffset": -75,
                    "topOffset": -75,
                    "bottomOffset": -75
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 65,
                        "y": 35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -65,
                        "y": -35
                    },
                    "size": {
                        "width": 272,
                        "height": 200
                    },
                    "scale": {
                        "x": -1,
                        "y": -1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_Ling = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 350,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#ffe28c",
                "colorBottom": "#c3a158"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_bg",
                "color": "#ffffff",
                "leftOffset": -72,
                "rightOffset": -72,
                "topOffset": -72,
                "bottomOffset": -72
            },
            "backgroundTail": {
                "enabled": false,
                "sprite": "Sprites/Assets/TextEmoji/E_Inspiration/text_emoji_inspiration_tail",
                "color": "#ffffff",
                "position": {
                    "x": -20,
                    "y": -50
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Ling_hello_long",
                "previewAlias": "text_bubble_R_Ling_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_katana_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 178,
                        "y": 10
                    },
                    "size": {
                        "width": 444,
                        "height": 80
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -60,
                        "y": -60
                    },
                    "size": {
                        "width": 148,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ling_thanks_long",
                "previewAlias": "text_bubble_R_Ling_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_feathers",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 16,
                        "y": -16
                    },
                    "size": {
                        "width": 116,
                        "height": 128
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_round_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -25,
                        "y": -61
                    },
                    "size": {
                        "width": 120,
                        "height": 156
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ling_oops_long",
                "previewAlias": "text_bubble_R_Ling_oops_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_bg_accent",
                    "color": "#ffffff",
                    "leftOffset": -72,
                    "rightOffset": -72,
                    "topOffset": -72,
                    "bottomOffset": -72
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_flask",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 62,
                        "y": -35
                    },
                    "size": {
                        "width": 244,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_sode",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -18,
                        "y": -32
                    },
                    "size": {
                        "width": 120,
                        "height": 144
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ling_gg_long",
                "previewAlias": "text_bubble_R_Ling_gg_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_bg_accent",
                    "color": "#ffffff",
                    "leftOffset": -72,
                    "rightOffset": -72,
                    "topOffset": -72,
                    "bottomOffset": -72
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_token",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 38,
                        "y": -27
                    },
                    "size": {
                        "width": 100,
                        "height": 96
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_katana_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -237,
                        "y": 20
                    },
                    "size": {
                        "width": 556,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": -2
                }
            },
            {
                "alias": "text_bubble_R_Ling_wp_long",
                "previewAlias": "text_bubble_R_Ling_wp_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_bg_accent",
                    "color": "#ffffff",
                    "leftOffset": -72,
                    "rightOffset": -72,
                    "topOffset": -72,
                    "bottomOffset": -72
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_token",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 38,
                        "y": -27
                    },
                    "size": {
                        "width": 100,
                        "height": 96
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_katana_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -237,
                        "y": 20
                    },
                    "size": {
                        "width": 556,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": -2
                }
            },
            {
                "alias": "text_bubble_R_Ling_rematch_long",
                "previewAlias": "text_bubble_R_Ling_rematch_short",
                "background": {
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_bg_accent",
                    "color": "#ffffff",
                    "leftOffset": -72,
                    "rightOffset": -72,
                    "topOffset": -72,
                    "bottomOffset": -72
                },
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_flask",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 62,
                        "y": 73
                    },
                    "size": {
                        "width": 244,
                        "height": 200
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_sode",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -18,
                        "y": -32
                    },
                    "size": {
                        "width": 120,
                        "height": 144
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ling_go_long",
                "previewAlias": "text_bubble_R_Ling_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_feathers",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 16,
                        "y": -16
                    },
                    "size": {
                        "width": 116,
                        "height": 128
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_round_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -25,
                        "y": -61
                    },
                    "size": {
                        "width": 120,
                        "height": 156
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ling_keep_fighting_long",
                "previewAlias": "text_bubble_R_Ling_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_katana_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 178,
                        "y": 10
                    },
                    "size": {
                        "width": 444,
                        "height": 80
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ling/text_emoji_ling_decor_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -60,
                        "y": -60
                    },
                    "size": {
                        "width": 148,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.nekkiFest2025 = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 360,
            "labelColor": "#FFFFFFFF",
            "labelGradient": null,
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_bg",
                "color": "#ffffff",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_tail",
                "color": "#1a171b",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_hello_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 79,
                        "y": -32
                    },
                    "size": {
                        "width": 158,
                        "height": 106
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -96,
                        "y": 17
                    },
                    "size": {
                        "width": 255,
                        "height": 127
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_thanks_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 75,
                        "y": 40
                    },
                    "size": {
                        "width": 186,
                        "height": 81
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -72,
                        "y": -30
                    },
                    "size": {
                        "width": 160,
                        "height": 98
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_oops_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 75,
                        "y": 40
                    },
                    "size": {
                        "width": 186,
                        "height": 81
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -72,
                        "y": -30
                    },
                    "size": {
                        "width": 160,
                        "height": 98
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_gg_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 96,
                        "y": -27
                    },
                    "size": {
                        "width": 255,
                        "height": 130
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -91,
                        "y": 35
                    },
                    "size": {
                        "width": 183,
                        "height": 71
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_wp_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_7",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 98,
                        "y": 33
                    },
                    "size": {
                        "width": 242,
                        "height": 112
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_8",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -105,
                        "y": -31
                    },
                    "size": {
                        "width": 244,
                        "height": 107
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_rematch_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_7",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 98,
                        "y": 33
                    },
                    "size": {
                        "width": 242,
                        "height": 112
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "BackgroundDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_8",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -105,
                        "y": -31
                    },
                    "size": {
                        "width": 244,
                        "height": 107
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_go_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_5",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 96,
                        "y": -27
                    },
                    "size": {
                        "width": 255,
                        "height": 130
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_6",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -91,
                        "y": 35
                    },
                    "size": {
                        "width": 183,
                        "height": 71
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Nekki_Fest_2025_keep_fighting_long",
                "previewAlias": "text_bubble_R_Nekki_Fest_2025_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 79,
                        "y": -32
                    },
                    "size": {
                        "width": 158,
                        "height": 106
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Nekki_Fest_2025/text_emoji_nekkiFest_decor_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -96,
                        "y": 17
                    },
                    "size": {
                        "width": 255,
                        "height": 127
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_Yukka = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 390,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": false,
                "colorTop": "#ffe28c",
                "colorBottom": "#c3a158"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_bg",
                "color": "#ffffff",
                "leftOffset": -72,
                "rightOffset": -72,
                "topOffset": -72,
                "bottomOffset": -72
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_tail",
                "color": "#ffffff",
                "position": {
                    "x": -13,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Yukka_hello_long",
                "previewAlias": "text_bubble_R_Yukka_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_weapon",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 187,
                        "y": 23
                    },
                    "size": {
                        "width": 456,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_scratches",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -92,
                        "y": -23
                    },
                    "size": {
                        "width": 200,
                        "height": 100
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_thanks_long",
                "previewAlias": "text_bubble_R_Yukka_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_belt",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 53,
                        "y": -44
                    },
                    "size": {
                        "width": 160,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_paws",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 38
                    },
                    "size": {
                        "width": 136,
                        "height": 112
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_oops_long",
                "previewAlias": "text_bubble_R_Yukka_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_belt",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 53,
                        "y": -44
                    },
                    "size": {
                        "width": 160,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_paws",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 38
                    },
                    "size": {
                        "width": 136,
                        "height": 112
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_gg_long",
                "previewAlias": "text_bubble_R_Yukka_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_eye",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 63,
                        "y": 39
                    },
                    "size": {
                        "width": 208,
                        "height": 152
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_fur",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -43,
                        "y": -43
                    },
                    "size": {
                        "width": 156,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_wp_long",
                "previewAlias": "text_bubble_R_Yukka_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_eye",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 63,
                        "y": 39
                    },
                    "size": {
                        "width": 208,
                        "height": 152
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_fur",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -43,
                        "y": -43
                    },
                    "size": {
                        "width": 156,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_rematch_long",
                "previewAlias": "text_bubble_R_Yukka_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_flag",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 33,
                        "y": -14
                    },
                    "size": {
                        "width": 114,
                        "height": 72
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_shadow",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -90,
                        "y": 8
                    },
                    "size": {
                        "width": 244,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_go_long",
                "previewAlias": "text_bubble_R_Yukka_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_flag",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 33,
                        "y": -14
                    },
                    "size": {
                        "width": 114,
                        "height": 72
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_shadow",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -90,
                        "y": 8
                    },
                    "size": {
                        "width": 244,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Yukka_keep_fighting_long",
                "previewAlias": "text_bubble_R_Yukka_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_weapon",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 187,
                        "y": 23
                    },
                    "size": {
                        "width": 456,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Yukka/text_emoji_yukka_decor_scratches",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -92,
                        "y": -23
                    },
                    "size": {
                        "width": 200,
                        "height": 100
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_Ironclad = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 395,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#ffffff",
                "colorBottom": "#BCC6CF"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_bg",
                "color": "#ffffff",
                "leftOffset": -72,
                "rightOffset": -72,
                "topOffset": -72,
                "bottomOffset": -72
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_tail",
                "color": "#ffffff",
                "position": {
                    "x": -9,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Ironclad_hello_long",
                "previewAlias": "text_bubble_R_Ironclad_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_shoulder",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 38,
                        "y": -34
                    },
                    "size": {
                        "width": 112,
                        "height": 128
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_gloves",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -50,
                        "y": 26
                    },
                    "size": {
                        "width": 148,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_thanks_long",
                "previewAlias": "text_bubble_R_Ironclad_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_buckle",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 53,
                        "y": 26
                    },
                    "size": {
                        "width": 140,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_armor",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -34,
                        "y": -35
                    },
                    "size": {
                        "width": 100,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_oops_long",
                "previewAlias": "text_bubble_R_Ironclad_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_legion_faction",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 70,
                        "y": 53
                    },
                    "size": {
                        "width": 132,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_angry_face",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -70,
                        "y": -58
                    },
                    "size": {
                        "width": 128,
                        "height": 108
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_gg_long",
                "previewAlias": "text_bubble_R_Ironclad_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_shoulder",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 38,
                        "y": -34
                    },
                    "size": {
                        "width": 112,
                        "height": 128
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_gloves",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -50,
                        "y": 26
                    },
                    "size": {
                        "width": 148,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_wp_long",
                "previewAlias": "text_bubble_R_Ironclad_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_buckle",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 53,
                        "y": 26
                    },
                    "size": {
                        "width": 140,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_armor",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -34,
                        "y": -35
                    },
                    "size": {
                        "width": 100,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_rematch_long",
                "previewAlias": "text_bubble_R_Ironclad_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_legion_faction",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 70,
                        "y": 53
                    },
                    "size": {
                        "width": 132,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_angry_face",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -70,
                        "y": -58
                    },
                    "size": {
                        "width": 128,
                        "height": 108
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_go_long",
                "previewAlias": "text_bubble_R_Ironclad_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_shoulder",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 38,
                        "y": -34
                    },
                    "size": {
                        "width": 112,
                        "height": 128
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_gloves",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -50,
                        "y": 26
                    },
                    "size": {
                        "width": 148,
                        "height": 120
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Ironclad_keep_fighting_long",
                "previewAlias": "text_bubble_R_Ironclad_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_buckle",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 53,
                        "y": 26
                    },
                    "size": {
                        "width": 140,
                        "height": 136
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Ironclad/text_emoji_ironclad_decor_armor",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -34,
                        "y": -35
                    },
                    "size": {
                        "width": 100,
                        "height": 104
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_Butcher = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 395,
            "labelColor": "#E54940",
            "labelGradient": {
                "enabled": false,
                "colorTop": "#ffffff",
                "colorBottom": "#ffffff"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_bg",
                "color": "#ffffff",
                "leftOffset": -33,
                "rightOffset": -33,
                "topOffset": -33,
                "bottomOffset": -33
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_tail",
                "color": "#ffffff",
                "position": {
                    "x": -16,
                    "y": -54
                }
            },
            "backgroundGradient": null,
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Butcher_hello_long",
                "previewAlias": "text_bubble_R_Butcher_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_cleaver",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_hook",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_thanks_long",
                "previewAlias": "text_bubble_R_Butcher_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_chain_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_oops_long",
                "previewAlias": "text_bubble_R_Butcher_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_chain_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_rings",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_gg_long",
                "previewAlias": "text_bubble_R_Butcher_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_cleaver",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_hook",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_wp_long",
                "previewAlias": "text_bubble_R_Butcher_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_plate",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_chain_2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_rematch_long",
                "previewAlias": "text_bubble_R_Butcher_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_chain_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_rings",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_go_long",
                "previewAlias": "text_bubble_R_Butcher_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_chain_1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_rings",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Butcher_keep_fighting_long",
                "previewAlias": "text_bubble_R_Butcher_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_cleaver",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Butcher/text_emoji_butcher_decor_hook",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -61,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_DayOfEarth = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 360,
            "labelColor": "#ffe28c",
            "labelGradient": {
                "enabled": false,
                "colorTop": "#ffffff",
                "colorBottom": "#ffffff"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/Common/text_emoji_Common_bg",
                "color": "#ffffff",
                "leftOffset": -42,
                "rightOffset": -42,
                "topOffset": -42,
                "bottomOffset": -42
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_tail",
                "color": "#ffffff",
                "position": {
                    "x": -16,
                    "y": -54
                }
            },
            "backgroundGradient": {
                "enabled": true,
                "colorKeys": [
                    {
                        "color": "#008a4c",
                        "time": 0.0
                    },
                    {
                        "color": "#074516",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0.0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "textemote_hero_Universal_Hello",
                "previewAlias": "textemote_hero_Universal_Hello",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Thanks",
                "previewAlias": "textemote_hero_Universal_Thanks",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Oops",
                "previewAlias": "textemote_hero_Universal_Oops",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Goodgame",
                "previewAlias": "textemote_hero_Universal_Goodgame",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Wellplayed",
                "previewAlias": "textemote_hero_Universal_Wellplayed",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Rematch",
                "previewAlias": "textemote_hero_Universal_Rematch",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Letsgo",
                "previewAlias": "textemote_hero_Universal_Letsgo",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "textemote_hero_Universal_Keepfighting",
                "previewAlias": "textemote_hero_Universal_Keepfighting",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_l3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 40,
                        "y": -53
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_DayOfEarth/text_emoji_earthday_decor_r3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -40,
                        "y": 55
                    },
                    "size": {
                        "width": 164,
                        "height": 164
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    TextEmojiPackVisuals.R_Dynasty = {
        "base": {
            "alias": "",
            "previewAlias": null,
            "timeToHide": 3,
            "labelWidth": 400,
            "labelColor": "#ffffff",
            "labelGradient": {
                "enabled": true,
                "colorTop": "#f3f5d3",
                "colorBottom": "#eef0c1"
            },
            "animationSettings": null,
            "background": {
                "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_bg",
                "color": "#ffffff",
                "leftOffset": -72,
                "rightOffset": -72,
                "topOffset": -72,
                "bottomOffset": -72
            },
            "backgroundTail": {
                "enabled": true,
                "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_tail",
                "color": "#ffffff",
                "position": {
                    "x": -16,
                    "y": -54
                }
            },
            "backgroundGradient": {
                "enabled": false,
                "colorKeys": [
                    {
                        "color": "#008a4c",
                        "time": 0.0
                    },
                    {
                        "color": "#074516",
                        "time": 1.0
                    }
                ],
                "alphaKeys": [
                    {
                        "alpha": 0.72,
                        "time": 0.0
                    },
                    {
                        "alpha": 0.72,
                        "time": 1.0
                    }
                ],
                "mode": 0
            },
            "backgroundTailGradient": null,
            "decorLeft": null,
            "decorRight": null,
            "vfxLeft": null,
            "vfxRight": null
        },
        "bubbles": [
            {
                "alias": "text_bubble_R_Dynasty_hello_long",
                "previewAlias": "text_bubble_R_Dynasty_hello_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_thanks_long",
                "previewAlias": "text_bubble_R_Dynasty_thanks_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -87,
                        "y": 43
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_oops_long",
                "previewAlias": "text_bubble_R_Dynasty_oops_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_gg_long",
                "previewAlias": "text_bubble_R_Dynasty_gg_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_wp_long",
                "previewAlias": "text_bubble_R_Dynasty_wp_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r2",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -87,
                        "y": 43
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_rematch_long",
                "previewAlias": "text_bubble_R_Dynasty_rematch_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r3",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_go_long",
                "previewAlias": "text_bubble_R_Dynasty_go_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": 73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r4",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": -73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            },
            {
                "alias": "text_bubble_R_Dynasty_keep_fighting_long",
                "previewAlias": "text_bubble_R_Dynasty_keep_fighting_short",
                "decorLeft": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_l1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 0,
                        "maxY": 0
                    },
                    "position": {
                        "x": 73,
                        "y": 53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                },
                "decorRight": {
                    "enabled": true,
                    "decorType": "FrameDecor",
                    "sprite": "Sprites/Assets/TextEmoji/R_Dynasty/text_emoji_dynasty_decor_r1",
                    "color": "#FFFFFFFF",
                    "anchors": {
                        "minY": 1,
                        "maxY": 1
                    },
                    "position": {
                        "x": -73,
                        "y": -53
                    },
                    "size": {
                        "width": 180,
                        "height": 180
                    },
                    "scale": {
                        "x": 1,
                        "y": 1
                    },
                    "rotationZ": 0
                }
            }
        ]
    };
    return TextEmojiPackVisuals;
}());
