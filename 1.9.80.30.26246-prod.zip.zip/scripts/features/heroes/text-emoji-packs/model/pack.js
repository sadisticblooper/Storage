var TextEmojiPack = (function () {
    function TextEmojiPack(settings) {
        this.customizationType = CUSTOMIZATION.TEXT_EMOJI_PACK;
        this.settings = settings;
        this.ID = settings.ID;
        this.settings.videoId = settings.videoId ? settings.videoId : 0;
        this.rarity = settings.rarity || TEXT_EMOJI_PACK_RARITY.COMMON;
        this.heroOwners = null;
        this.customUnlockedPlacement = settings.customUnlockedPlacement;
        this.configsOrder = settings.configsOrder;
        this.ShardsNeeded = settings.ShardsNeeded;
        if (settings.isDefault) {
            TextEmojiPack.DefaultTextEmojiPacks.push(this.ID);
        }
        if (this.putOnPlayer) {
            TextEmojiPack.PutOnTextEmojiPacks.push(this.ID);
        }
    }
    Object.defineProperty(TextEmojiPack.prototype, "visualSettings", {
        get: function () { return this.settings.visualSettings; },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "nameAlias", {
        get: function () { return this.settings.nameAlias; },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "icon", {
        get: function () { return this.settings.icon; },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "isDefault", {
        get: function () { return Boolean(this.settings.isDefault); },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "videoId", {
        get: function () { return this.settings.videoId; },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "putOnPlayer", {
        get: function () { return Boolean(this.settings.putOnPlayer); },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(TextEmojiPack.prototype, "shardsNeeded", {
        get: function () { return this.ShardsNeeded; },
        enumerable: false,
        configurable: true
    });
    ;
    TextEmojiPack.DefaultTextEmojiPacks = [];
    TextEmojiPack.PutOnTextEmojiPacks = [];
    return TextEmojiPack;
}());
var textTaunts = {};
var textTauntsMap = createIDMap(textTaunts, "textTauntsMap");
