var TextEmojiUtils = (function () {
    function TextEmojiUtils() {
    }
    TextEmojiUtils.getAvailableIdsRandomGenerating = function (specify) {
        return TextEmojiConstants.availableEmotesForRandomGeneration;
    };
    TextEmojiUtils.getTextEmojiPackVisualSettings = function (packId) {
        var _a;
        var pack = textEmojiPacksMap.get(packId);
        return (_a = pack === null || pack === void 0 ? void 0 : pack.visualSettings) !== null && _a !== void 0 ? _a : TextEmojiPackVisuals.default;
    };
    return TextEmojiUtils;
}());
