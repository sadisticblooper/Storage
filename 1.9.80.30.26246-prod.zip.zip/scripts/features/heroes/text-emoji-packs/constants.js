var TextEmojiConstants = (function () {
    function TextEmojiConstants() {
    }
    TextEmojiConstants.availableEmotesForRandomGeneration = [];
    TextEmojiConstants.defaultTextEmojiPackId = textEmojiPacks.default.ID;
    return TextEmojiConstants;
}());
