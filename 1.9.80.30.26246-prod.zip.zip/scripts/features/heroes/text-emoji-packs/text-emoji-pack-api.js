function getTextEmojiPackVisualSettings(packId) {
    return TextEmojiUtils.getTextEmojiPackVisualSettings(packId);
}
