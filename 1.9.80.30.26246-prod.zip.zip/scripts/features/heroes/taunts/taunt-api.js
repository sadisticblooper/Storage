function getTauntById(id) {
    return tauntsMap.checkedGet(id);
}
