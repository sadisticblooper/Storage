var TauntUtils = (function () {
    function TauntUtils() {
    }
    TauntUtils.getAvailableIdsRandomGenerating = function (specify) {
        return TauntConstants.availableTauntsForRandomGeneration;
    };
    return TauntUtils;
}());
