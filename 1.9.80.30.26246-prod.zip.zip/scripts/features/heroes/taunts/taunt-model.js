var Taunt = (function () {
    function Taunt(settings) {
        this.customizationType = CUSTOMIZATION.TAUNT;
        this.settings = {
            Rarity: settings.Rarity,
            Icon: settings.Icon,
            Tags: settings.Tags.slice(),
            MaleAnimation: settings.MaleAnimation,
            FemaleAnimation: settings.FemaleAnimation ? settings.FemaleAnimation : settings.MaleAnimation,
            OwnerHeroes: settings.OwnerHeroes.slice(),
            NameAlias: settings.NameAlias,
            ID: settings.ID,
            isDefault: settings.isDefault != undefined ? settings.isDefault : false,
            PutOnHero: settings.PutOnHero != undefined ? settings.PutOnHero : false,
            AssetBundleTag: settings.AssetBundleTag,
            VideoId: settings.VideoId ? settings.VideoId : 0,
            CustomUnlockedPlacement: settings.CustomUnlockedPlacement ? settings.CustomUnlockedPlacement : null,
            HeroFormType: settings.HeroFormType != undefined ? settings.HeroFormType : HERO_FORM_TYPE.PRIMARY,
            configsOrder: settings.configsOrder,
            ShardsNeeded: settings.ShardsNeeded,
        };
        this.HeroFormType = settings.HeroFormType;
        if (this.settings.PutOnHero && !this.settings.isDefault) {
            throw new Error("If taunt has flag PutOnHero, it must has flag IsDefault = true. Taunt ID ".concat(settings.ID));
        }
        this.configsOrder = this.settings.configsOrder;
        this.rarity = this.settings.Rarity;
        this.heroOwners = this.settings.OwnerHeroes;
        this.customUnlockedPlacement = this.settings.CustomUnlockedPlacement;
        this.ShardsNeeded = this.settings.ShardsNeeded;
        Taunt.AddDefaultTaunt(this);
    }
    Object.defineProperty(Taunt.prototype, "Settings", {
        get: function () { return this.settings; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Taunt.prototype, "ID", {
        get: function () { return this.settings.ID; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Taunt.prototype, "Tags", {
        get: function () { return this.settings.Tags; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Taunt.prototype, "Default", {
        get: function () { return this.settings.isDefault; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Taunt.prototype, "IsDefault", {
        get: function () { return this.settings.isDefault; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Taunt.prototype, "AssetBundleTag", {
        get: function () { return this.settings.AssetBundleTag; },
        enumerable: false,
        configurable: true
    });
    Taunt.setTauntsToHeroes = function () {
        for (var key in heroes)
            if (heroes.hasOwnProperty(key)) {
                var hero = heroes[key];
                var tauntsIds = [];
                for (var name_1 in taunts) {
                    var taunt = taunts[name_1];
                    if (taunt.Settings.OwnerHeroes.length == 0 || taunt.Settings.OwnerHeroes.indexOf(hero.ID) > -1) {
                        tauntsIds.push(taunt.ID);
                    }
                }
                hero.addTaunts(tauntsIds);
            }
    };
    Taunt.AddDefaultTaunt = function (taunt) {
        if (taunt.IsDefault && this.DefaultTaunts.indexOf(taunt.ID) == -1) {
            this.DefaultTaunts.push(taunt.ID);
        }
    };
    Taunt.DefaultTaunts = [];
    return Taunt;
}());
