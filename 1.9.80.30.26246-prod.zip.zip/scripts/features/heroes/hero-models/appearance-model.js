var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var HeroComponent = (function () {
    function HeroComponent(js) {
        this.ID = js.ID;
        this.component = js.Component;
    }
    return HeroComponent;
}());
var HelmetItem = (function (_super) {
    __extends(HelmetItem, _super);
    function HelmetItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.HELMET];
        return _this;
    }
    return HelmetItem;
}(HeroComponent));
var WeaponItem = (function (_super) {
    __extends(WeaponItem, _super);
    function WeaponItem(js) {
        var _this = _super.call(this, js) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.WEAPON];
        if (js.Style) {
            _this.style = js.Style;
        }
        return _this;
    }
    WeaponItem.prototype.getWeaponStyle = function () {
        return this.style;
    };
    return WeaponItem;
}(HeroComponent));
var ArmorItem = (function (_super) {
    __extends(ArmorItem, _super);
    function ArmorItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.ARMOR];
        return _this;
    }
    return ArmorItem;
}(HeroComponent));
var SkeletonItem = (function (_super) {
    __extends(SkeletonItem, _super);
    function SkeletonItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.SKELETON];
        return _this;
    }
    return SkeletonItem;
}(HeroComponent));
var RangedItem = (function (_super) {
    __extends(RangedItem, _super);
    function RangedItem(js) {
        var _this = _super.call(this, js) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.RANGED];
        if (js.Bullet) {
            _this.bullet = js.Bullet;
        }
        return _this;
    }
    return RangedItem;
}(HeroComponent));
var Hair = (function (_super) {
    __extends(Hair, _super);
    function Hair() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.HAIR];
        return _this;
    }
    return Hair;
}(HeroComponent));
var AdditionalItem1 = (function (_super) {
    __extends(AdditionalItem1, _super);
    function AdditionalItem1() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.ADDITIONAL1];
        return _this;
    }
    return AdditionalItem1;
}(HeroComponent));
var AdditionalItem2 = (function (_super) {
    __extends(AdditionalItem2, _super);
    function AdditionalItem2() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = HERO_COMPONENT[HERO_COMPONENT.ADDITIONAL2];
        return _this;
    }
    return AdditionalItem2;
}(HeroComponent));
var Appearance = (function () {
    function Appearance(js) {
        this._isDefault = false;
        this._id = js.ID;
        this.hair = getValueByKeyDefault(js, "Hair", []);
        this.helmet = getValueByKeyDefault(js, "Helmet", []);
        this.additionalSlots = getValueByKeyDefault(js, "AdditionalSlots", []);
        this.weapon = js.Weapon;
        this.armor = js.Armor;
        this._isDefault = js.isDefault;
        this.skinName = getValueByKeyDefault(js, "SkinName", "");
        this.tags = getValueByKeyDefault(js, "Tags", []);
        this.ranged = getValueByKeyDefault(js, "Ranged", null);
        this.skeleton = js.Skeleton;
        var altSettings = js.AltAppearanceOverrideSettings;
        if (altSettings) {
            var resultSettings = {};
            for (var key in js)
                if (js.hasOwnProperty(key) && key != 'AltAppearanceOverrideSettings') {
                    if (altSettings.hasOwnProperty(key)) {
                        resultSettings[key] = altSettings[key];
                    }
                    else {
                        resultSettings[key] = js[key];
                    }
                }
            this.alternative_appearance = new Appearance(resultSettings);
        }
    }
    Object.defineProperty(Appearance.prototype, "ID", {
        get: function () {
            return this._id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Appearance.prototype, "isDefault", {
        get: function () {
            return this._isDefault;
        },
        set: function (value) {
            this._isDefault = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Appearance.prototype, "Tags", {
        get: function () {
            return this.tags;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Appearance.prototype, "rarity", {
        get: function () {
            return this._rarity;
        },
        set: function (value) {
            this._rarity = value;
        },
        enumerable: false,
        configurable: true
    });
    Appearance.prototype.getAppearanceWeaponStyle = function () {
        return this.weapon.getWeaponStyle();
    };
    Appearance.prototype.getAppearanceItemList = function (settings) {
        var alternative = settings.alternative, seed = settings.seed;
        seed = seed ? seed : 1;
        var source = alternative ? this.alternative_appearance : this;
        var rnd = new PcgRandom(seed);
        if (!source) {
            throw "getAppearanceItemList illegal appearance source to ID " + this.ID;
        }
        var components = [source.skeleton, source.armor];
        var poolComponents = __spreadArray([
            source.helmet,
            source.hair
        ], (source.additionalSlots ? source.additionalSlots : []), true);
        for (var _i = 0, poolComponents_1 = poolComponents; _i < poolComponents_1.length; _i++) {
            var pool = poolComponents_1[_i];
            var heroComponent = pool[rnd.nextInt(pool.length)];
            if (heroComponent) {
                components.push(heroComponent);
            }
        }
        if (source.ranged) {
            components.push(source.ranged);
        }
        return components;
    };
    Appearance.prototype.getWeaponComponent = function (alternative) {
        var source = alternative ? this.alternative_appearance : this;
        return source.weapon;
    };
    return Appearance;
}());
