var HeroBalance = (function () {
    function HeroBalance(settings) {
        this._attributes = new HeroAttributes(settings.absoluteAttributes);
        this._levelAttributes = settings.levelAttributes;
        this.createFakeAttributes(settings);
    }
    HeroBalance.prototype.createFakeAttributes = function (settings) {
        if (settings.fakeAttributes) {
            this._fakeAttributes = {};
            for (var attributeName in this._attributes) {
                if (settings.fakeAttributes[attributeName] != undefined) {
                    this._fakeAttributes[attributeName] = settings.fakeAttributes[attributeName];
                }
                else {
                    this._fakeAttributes[attributeName] = this._attributes[attributeName];
                }
            }
        }
        else {
            this._fakeAttributes = this._attributes;
        }
    };
    HeroBalance.prototype.getAttributes = function () {
        return this._attributes;
    };
    HeroBalance.prototype.getFakeAttributes = function () {
        return this._fakeAttributes;
    };
    HeroBalance.prototype.getLevelAttributes = function () {
        return this._levelAttributes;
    };
    HeroBalance.talentID = 500000;
    return HeroBalance;
}());
