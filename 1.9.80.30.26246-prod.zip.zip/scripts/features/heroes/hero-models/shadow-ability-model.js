var ShadowAbility = (function () {
    function ShadowAbility(js) {
        ShadowAbility.CheckId(js.ID);
        this.id = js.ID;
        this.icon = js.Icon;
        this.aliasName = js.AliasName;
        this.tag = js.Tag;
        this.animation = js.Animation;
        this.cooldown = js.Cooldown;
        this.customTooltipIcon = getValueByKeyDefault(js, "CustomTooltipIcon", "");
    }
    ShadowAbility.CheckId = function (id) {
        if (ShadowAbility._ids == undefined) {
            ShadowAbility._ids = [];
        }
        if (ShadowAbility._ids.indexOf(id) > -1) {
            throw new Error("ShadowAbility has repeated id ".concat(id));
        }
        ShadowAbility._ids.push(id);
    };
    Object.defineProperty(ShadowAbility.prototype, "Tag", {
        get: function () { return this.tag; },
        enumerable: false,
        configurable: true
    });
    return ShadowAbility;
}());
