var PassiveAbility = (function () {
    function PassiveAbility(js) {
        this.id = js.ID;
        this.image = js.Image;
        this.alias_name = js.AliasName;
        this.alias_desc = js.AliasDesc;
        this.parameters = getValueByKeyDefault(js, "Parameters", {});
        this.interface_on_top = getValueByKeyDefault(js, "InterfaceOnTop", false);
        this.locked = getValueByKeyDefault(js, "Locked", false);
        this.talentComboOverride = getValueByKeyDefault(js, "TalentComboOverride", null);
    }
    Object.defineProperty(PassiveAbility.prototype, "ID", {
        get: function () { return this.id; },
        enumerable: false,
        configurable: true
    });
    PassiveAbility.prototype.getParameters = function () { return this.parameters; };
    PassiveAbility.prototype.isLocked = function () { return this.locked; };
    PassiveAbility.prototype.getTalentComboOverride = function () { return this.talentComboOverride; };
    PassiveAbility.prototype.getName = function () { return this.alias_name; };
    PassiveAbility.prototype.getDesc = function () { return this.alias_desc; };
    PassiveAbility.prototype.getImage = function () { return this.image; };
    return PassiveAbility;
}());
