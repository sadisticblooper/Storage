var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var AttributeInfo = (function () {
    function AttributeInfo(js) {
        this.image = js.image;
        this.alias = js.alias;
    }
    return AttributeInfo;
}());
var HeroAttributes = (function () {
    function HeroAttributes(fixedAttributes) {
        this.WeaponDamage = HeroConstants.heroBaseAttributeValue;
        this.MagicDamage = HeroConstants.heroBaseAttributeValue;
        this.BodyDefense = HeroConstants.heroBaseAttributeValue;
        this.ShadowFormDuration = HeroConstants.heroBaseShadowTime;
        this.CriticalMultiplier = HeroConstants.heroBaseCritMultiplier;
        this.CriticalChance = HeroConstants.heroBaseCritChance;
        this.Cooldown = HeroConstants.heroBaseCooldown;
        this.Ammo = HeroConstants.heroBaseAmmo;
        if (fixedAttributes) {
            for (var key in fixedAttributes) {
                if (fixedAttributes.hasOwnProperty(key) && this.hasOwnProperty(key)) {
                    this[key] = fixedAttributes[key];
                }
            }
        }
    }
    HeroAttributes.prototype.allAttributesArray = function () {
        var result = [];
        for (var key in this)
            if (this.hasOwnProperty(key)) {
                result.push(key);
            }
        return result;
    };
    return HeroAttributes;
}());
var Hero = (function () {
    function Hero(js) {
        var _a;
        this.settings = js;
        this.id = js.ID;
        this.heroBalance = js.HeroBalance;
        this.attributes = this.heroBalance.getAttributes();
        this.attributesFake = this.heroBalance.getFakeAttributes();
        this._hero_class = js.HeroClass;
        this.alias = js.Alias;
        this.icon = js.Icon;
        this.gender = js.Gender;
        this.faction = js.Faction;
        this.difficulty = js.Difficulty;
        this.account_level_needed = js.AccountLevelNeeded;
        this.ArenaNumberNeeded = js.ArenaNumberNeeded;
        this.attributesInfo = this.overrideAttributesInfo(js.AttributeInfoOverride);
        this.interfaceElementsInfo = this.getHeroInterfaceElements(js.InterfaceElementsInfoOverride);
        this.talents = js.Talents;
        this.shadow_abilities = js.ShadowAbilities;
        this.passive_abilities = js.PassiveAbilities;
        this.tags = js.Tags;
        this.shards_needed = js.ShardsNeeded ? js.ShardsNeeded : 0;
        this.hero_rarity = js.Rarity;
        this._lock_shards = getValueByKeyDefault(js, 'LockShards', false);
        this._lock_cards = getValueByKeyDefault(js, 'LockCards', false);
        this.StartLevel = getValueByKeyDefault(js, 'StartLevel', 1);
        this._showInRoadMap = getValueByKeyDefault(js, 'ShowInRoadMap', true);
        this._allowInBotSquad = getValueByKeyDefault(js, 'AllowInBotSquad', null);
        this._assetBundleTag = getValueByKeyDefault(js, 'AssetBundleTag', "");
        this._available_skin_ids = [];
        this.default_skin_id = 0;
        this.default_taunt_ids = [];
        this.available_taunt_ids = [];
        this.availableStances = [];
        this.defaultStances = [(_a = {}, _a[STANCE_TYPE.START_POSE] = 0, _a[STANCE_TYPE.WIN_POSE] = 0, _a)];
        this.CustomUnlockedPlacement = js.CustomUnlockedPlacement != undefined ? js.CustomUnlockedPlacement : null;
        this.ShardsWeightForGenerating = js.ShardsWeightForGenerating != undefined ? js.ShardsWeightForGenerating : 0;
        this.DuplicatesWeightForGenerating = getValueByKeyDefault(js, "DuplicatesWeightForGenerating", 0);
        this.UnlockHeroSinceDateTime = getValueByKeyDefault(js, "UnlockHeroSinceDateTime", null);
        this.OfferToDirectBuy = getValueByKeyDefault(js, "OfferToDirectBuy", null);
        this.HeroFormType = js.HeroFormType != undefined ? js.HeroFormType : HERO_FORM_TYPE.PRIMARY;
        this.VideoId = js.VideoId ? js.VideoId : 0;
        this.levelAttributes = getValueByKeyDefault(js, 'LevelAttributes', {});
        this.talents = js.Talents;
        this.check();
    }
    Hero.prototype.check = function () {
        this.checkTalentTree();
        this.checkSkins();
    };
    Hero.prototype.setSkins = function (skins) {
        this.default_skin_id = 0;
        for (var _i = 0, skins_1 = skins; _i < skins_1.length; _i++) {
            var skin = skins_1[_i];
            if (skin.OwnerHeroID != this.id) {
                continue;
            }
            var index = this._available_skin_ids.indexOf(skin.ID);
            if (index == -1) {
                this._available_skin_ids.push(skin.ID);
                if (this.default_skin_id != 0 && skin.PutOnHero) {
                    throw new Error("Trying to wear 2 skins at hero ".concat(this.id, ": skin ").concat(this.default_skin_id, " and skin ").concat(skin.ID, ". See flag PutOnHero"));
                }
                if (skin.PutOnHero) {
                    this.default_skin_id = skin.ID;
                    this.defaultWeaponId = skin.DefaultWeaponId;
                }
            }
        }
        if (!this.default_skin_id || !this.defaultWeaponId) {
            throw new Error("No default (wear/put on) skin/weapon for hero "
                + "with id ".concat(this.id, ". See PutOnHero flag of Skins"));
        }
    };
    Hero.prototype.checkSkins = function () {
        for (var _i = 0, _a = this._available_skin_ids; _i < _a.length; _i++) {
            var skinId = _a[_i];
            var skin = skinsMap.checkedGet(skinId);
            var appearance = skin.Appearance;
            var ws = appearance.getAppearanceWeaponStyle();
            if (ws && this.tags.indexOf(ws) == -1) {
                throw "class Hero exeption: no tag " + ws + " in Hero ID " + this.id;
            }
        }
    };
    Object.defineProperty(Hero.prototype, "AvailableSkinIds", {
        get: function () {
            return this._available_skin_ids;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "DefaultSkinId", {
        get: function () {
            return this.default_skin_id;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.getCommonWeaponIfNotSelected = function (skinId) {
        var skin = skinsMap.checkedGet(skinId);
        if (skin.DefaultWeaponId == this.defaultWeaponId) {
            return skin.DefaultWeaponId;
        }
        var skinWeapon = weaponsMap.checkedGet(skin.DefaultWeaponId);
        var defaultWeapon = weaponsMap.checkedGet(this.defaultWeaponId);
        var attributePacks = [
            { common: defaultWeapon.Settings.AttributeShifts, skin: skinWeapon.Settings.AttributeShifts },
            { common: defaultWeapon.Settings.AttributesMultipliers, skin: skinWeapon.Settings.AttributesMultipliers },
        ];
        for (var _i = 0, attributePacks_1 = attributePacks; _i < attributePacks_1.length; _i++) {
            var pack = attributePacks_1[_i];
            var skin_1 = pack.skin, common = pack.common;
            var skinFields = Object.keys(skin_1);
            var commonFields = Object.keys(common);
            if (skinFields.length != commonFields.length) {
                return this.defaultWeaponId;
            }
            for (var key in commonFields) {
                if (commonFields[key] != skinFields[key]) {
                    return this.defaultWeaponId;
                }
            }
        }
        var skinPassiveIds = skinWeapon.Settings.PassiveAbilities.map(function (p) { return p.ID; });
        var commonPassiveIds = defaultWeapon.Settings.PassiveAbilities.map(function (p) { return p.ID; });
        if (skinPassiveIds.length != commonPassiveIds.length) {
            return this.defaultWeaponId;
        }
        if (ArrayUtils.getArraysIntersection(skinPassiveIds, commonPassiveIds).length != skinPassiveIds.length) {
            return this.defaultWeaponId;
        }
        return skin.DefaultWeaponId;
    };
    Object.defineProperty(Hero.prototype, "DefaultAppearanceModel", {
        get: function () {
            var skin = skinsMap.checkedGet(this.default_skin_id);
            return skin.Appearance;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.setStances = function (stances) {
        var _a;
        this.defaultStances = [];
        var defaultStancesForm = {};
        for (var _i = 0, stances_1 = stances; _i < stances_1.length; _i++) {
            var stance = stances_1[_i];
            var stanceSettings = stance.Settings;
            if (stanceSettings.OwnerHeroes.length != 0 && stanceSettings.OwnerHeroes.indexOf(this.ID) < 0) {
                continue;
            }
            if (!(stanceSettings.HeroFormType == HERO_FORM_TYPE.ANY
                || this.HeroFormType == HERO_FORM_TYPE.ANY
                || stanceSettings.HeroFormType == this.HeroFormType)) {
                continue;
            }
            if (stanceSettings.PutOnHero) {
                var stanceFormSettings = defaultStancesForm[stanceSettings.HeroFormType];
                if (stanceFormSettings) {
                    if (stanceFormSettings[stanceSettings.StanceType] != 0) {
                        throw new Error("Hero ".concat(this.ID, " already has default stance \n                        \r").concat(stanceFormSettings[stanceSettings.StanceType], " of stance type ").concat(STANCE_TYPE[stanceSettings.StanceType]));
                    }
                    else {
                        stanceFormSettings[stanceSettings.StanceType] = stance.ID;
                    }
                }
                else {
                    defaultStancesForm[stanceSettings.HeroFormType] = (_a = {}, _a[STANCE_TYPE.START_POSE] = 0, _a[STANCE_TYPE.WIN_POSE] = 0, _a);
                    defaultStancesForm[stanceSettings.HeroFormType][stanceSettings.StanceType] = stance.ID;
                }
            }
            if (this.availableStances.indexOf(stance.ID) < 0) {
                this.availableStances.push(stance.ID);
            }
        }
        for (var type in defaultStancesForm) {
            if (defaultStancesForm[type][STANCE_TYPE.START_POSE] == 0 || defaultStancesForm[type][STANCE_TYPE.WIN_POSE] == 0) {
                throw new Error("Hero ".concat(this.ID, " has not default stances: \n                \r").concat(JSON.stringify(defaultStancesForm[type]), ". See PutOnHero flag of Stances"));
            }
            this.defaultStances.push(defaultStancesForm[type]);
        }
    };
    Object.defineProperty(Hero.prototype, "DefaultHeroStance", {
        get: function () {
            return this.defaultStances;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.addTaunts = function (taunts) {
        for (var _i = 0, taunts_1 = taunts; _i < taunts_1.length; _i++) {
            var id = taunts_1[_i];
            var taunt = tauntsMap.checkedGet(id);
            if (taunt.Settings.OwnerHeroes.length != 0 && taunt.Settings.OwnerHeroes.indexOf(this.id) == -1) {
                continue;
            }
            if (this.available_taunt_ids.indexOf(id) == -1) {
                this.available_taunt_ids.push(id);
            }
            if (taunt.Settings.PutOnHero && (taunt.Settings.OwnerHeroes.length == 0 || taunt.Settings.OwnerHeroes.indexOf(this.id) > -1)) {
                if (this.default_taunt_ids.indexOf(id) == -1) {
                    this.default_taunt_ids.push(id);
                }
            }
        }
    };
    Object.defineProperty(Hero.prototype, "DefaultTauntIds", {
        get: function () {
            return this.default_taunt_ids;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.setWeapons = function (heroWeapons) {
        this.FreeWeaponIds = [];
        for (var _i = 0, heroWeapons_1 = heroWeapons; _i < heroWeapons_1.length; _i++) {
            var heroWeapon = heroWeapons_1[_i];
            if (heroWeapon.Settings.HeroOwner == this.ID
                && this.FreeWeaponIds.indexOf(heroWeapon.ID) == -1
                && heroWeapon.Settings.IsDefault) {
                this.FreeWeaponIds.push(heroWeapon.ID);
            }
        }
    };
    Object.defineProperty(Hero.prototype, "ID", {
        get: function () {
            return this.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "AllowInBotSquad", {
        get: function () {
            return this._allowInBotSquad;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Faction", {
        get: function () {
            return this.faction;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "AssetBundleTag", {
        get: function () { return this._assetBundleTag; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "ShardsNeeded", {
        get: function () {
            return this.shards_needed;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "AccLevelNeeded", {
        get: function () {
            return this.account_level_needed;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Difficulty", {
        get: function () {
            return this.difficulty;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "lock_shards", {
        get: function () {
            return this._lock_shards;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "lock_cards", {
        get: function () {
            return this._lock_cards;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Alias", {
        get: function () {
            return this.alias;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Icon", {
        get: function () {
            return this.icon;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "AttributesInfo", {
        get: function () {
            return this.attributesInfo;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "InterfaceElementsInfo", {
        get: function () {
            return this.interfaceElementsInfo;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Talents", {
        get: function () {
            return this.talents;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Rarity", {
        get: function () {
            return this.hero_rarity;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "Gender", {
        get: function () {
            return this.gender;
        },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(Hero.prototype, "StartLevel", {
        get: function () {
            return this._StartLevel;
        },
        set: function (value) {
            var _a;
            if (!this.hero_rarity)
                throw new Error("Rarity of hero must be init before StartLevel for hero ".concat(this.ID));
            var prices = (_a = {},
                _a[HERO_RARITY.COMMON] = HeroConstants.heroLevelUpPricesCommon,
                _a[HERO_RARITY.RARE] = HeroConstants.heroLevelUpPricesRare,
                _a[HERO_RARITY.EPIC] = HeroConstants.heroLevelUpPricesEpic,
                _a[HERO_RARITY.LEGENDARY] = HeroConstants.heroLevelUpPricesLegendary,
                _a);
            if (!prices[this.hero_rarity])
                throw new Error("No such rarity in prices for hero ".concat(this.ID, " with ").concat(this.hero_rarity, " rarity"));
            var levels = Object.keys(prices[this.hero_rarity]);
            var numbers = levels.map(function (i) { return Number(i); });
            var minLevel = Math.min.apply(Math, numbers);
            if (value < minLevel)
                throw new Error("StartLevel must be more than ".concat(minLevel, ". See prices table for rarity ").concat(this.hero_rarity));
            this._StartLevel = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "ShowInRoadMap", {
        get: function () {
            return this._showInRoadMap;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "ShadowAbilities", {
        get: function () {
            return this.shadow_abilities;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.getTags = function () {
        return this.tags;
    };
    Object.defineProperty(Hero.prototype, "hero_class", {
        get: function () {
            return this._hero_class;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "LockShards", {
        get: function () { return this._lock_shards; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "LockCards", {
        get: function () { return this._lock_cards; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "MaxLevel", {
        get: function () {
            return HeroConstants.maxHeroLevel;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Hero.prototype, "LevelAttributes", {
        get: function () {
            return this.levelAttributes;
        },
        enumerable: false,
        configurable: true
    });
    Hero.prototype.getLevelAttributesByLevel = function (level) {
        var result = [];
        for (var lvl in this.levelAttributes) {
            if (+lvl <= level) {
                result.push(this.levelAttributes[lvl]);
            }
        }
        return result;
    };
    Hero.upLevelIfNecessary = function (input, heroId, withOver) {
        if (withOver === void 0) { withOver = false; }
        var result = __assign({}, input);
        var upgradeInfo = HeroUtils.heroLevelUpPrices(input.Level, heroId);
        if (!upgradeInfo) {
            if (!withOver) {
                result.Exp = 0;
            }
            return result;
        }
        var expPrice = upgradeInfo.exp;
        if (expPrice <= input.Exp) {
            result.Level++;
            result.Exp -= expPrice;
            return Hero.upLevelIfNecessary(result, heroId, withOver);
        }
        return result;
    };
    Hero.prototype.passiveAbilitiesVisible = function (talentsTaken) {
        var passiveUnlocked = [];
        for (var _i = 0, talentsTaken_1 = talentsTaken; _i < talentsTaken_1.length; _i++) {
            var talentID = talentsTaken_1[_i];
            var talent = talentsMap.checkedGet(talentID);
            var passiveAffect = talent.AffectsPassive;
            if (passiveAffect && passiveUnlocked.indexOf(passiveAffect) == -1) {
                passiveUnlocked.push(passiveAffect);
            }
        }
        var result = [];
        var passiveIndexResult = 0;
        for (var passiveIndex in this.passive_abilities)
            if (this.passive_abilities.hasOwnProperty(passiveIndex)) {
                var passive = this.passive_abilities[passiveIndex];
                if (!passive.isLocked() || passiveUnlocked.indexOf(passive.ID) != -1) {
                    result[passiveIndexResult] = passive;
                    var talentCO = passive.getTalentComboOverride();
                    if (talentCO) {
                        var maxPriority = -Infinity;
                        var currentOverride = void 0;
                        for (var _a = 0, talentCO_1 = talentCO; _a < talentCO_1.length; _a++) {
                            var comboOverride = talentCO_1[_a];
                            if (comboOverride.Priority < maxPriority) {
                                break;
                            }
                            var notValidIDs = false;
                            for (var _b = 0, _c = comboOverride.Combo; _b < _c.length; _b++) {
                                var talentIDs = _c[_b];
                                if (talentsTaken.indexOf(talentIDs) == -1) {
                                    notValidIDs = true;
                                    break;
                                }
                            }
                            if (notValidIDs) {
                                continue;
                            }
                            maxPriority = comboOverride.Priority;
                            currentOverride = comboOverride;
                        }
                        if (currentOverride) {
                            for (var key in currentOverride.Override)
                                if (result[passiveIndexResult].hasOwnProperty(key)) {
                                    result[passiveIndexResult][key] = currentOverride.Override[key];
                                }
                        }
                    }
                    passiveIndexResult++;
                }
            }
        return result;
    };
    Hero.prototype.getAllPassiveAbilitiesForHero = function () {
        var result = [];
        var uniqParams = {};
        var source = [];
        for (var i in this.passive_abilities) {
            source.push(this.passive_abilities[i]);
        }
        for (var _i = 0, _a = weaponsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var weapon = weaponsMap.get(id);
            if (weapon.Settings.PassiveAbilities.length && weapon.heroOwners.indexOf(this.ID) > -1) {
                for (var _b = 0, _c = weapon.Settings.PassiveAbilities; _b < _c.length; _b++) {
                    var passiveAbility = _c[_b];
                    source.push(passiveAbility);
                }
            }
        }
        function getUniqFromPassiveAbility(passiveAbility) {
            return passiveAbility.getName() + passiveAbility.getDesc() + passiveAbility.getImage();
        }
        for (var _d = 0, source_1 = source; _d < source_1.length; _d++) {
            var passiveAbility = source_1[_d];
            var uniqKey = getUniqFromPassiveAbility(passiveAbility);
            if (uniqParams[uniqKey]) {
                continue;
            }
            uniqParams[uniqKey] = true;
            result.push(passiveAbility);
            var overrides = passiveAbility.getTalentComboOverride();
            if (overrides) {
                for (var _e = 0, overrides_1 = overrides; _e < overrides_1.length; _e++) {
                    var override = overrides_1[_e];
                    var name_1 = override.Override.alias_name || passiveAbility.getName();
                    var desc = override.Override.alias_desc || passiveAbility.getDesc();
                    var image = override.Override.image || passiveAbility.getImage();
                    var overrideAbility = new PassiveAbility({
                        ID: passiveAbility.ID,
                        AliasName: name_1,
                        AliasDesc: desc,
                        Image: image
                    });
                    var overrideUniqKey = getUniqFromPassiveAbility(overrideAbility);
                    if (uniqParams[overrideUniqKey]) {
                        continue;
                    }
                    uniqParams[overrideUniqKey] = true;
                    result.push(overrideAbility);
                }
            }
        }
        return result;
    };
    Hero.prototype.getHeroInterfaceElements = function (elementsOverride) {
        var result = {};
        for (var key in HeroConstants.defaultInterfaceElements)
            if (HeroConstants.defaultInterfaceElements.hasOwnProperty(key)) {
                result[key] = HeroConstants.defaultInterfaceElements[key];
            }
        if (elementsOverride) {
            for (var key in elementsOverride)
                if (elementsOverride.hasOwnProperty(key) && result.hasOwnProperty(key)) {
                    result[key] = elementsOverride[key];
                }
        }
        return result;
    };
    Hero.prototype.getInterfaceElementsWithTalents = function (talentsTaken) {
        var result = getObjectFromRaw(this.InterfaceElementsInfo);
        for (var _i = 0, talentsTaken_2 = talentsTaken; _i < talentsTaken_2.length; _i++) {
            var talentID = talentsTaken_2[_i];
            var talent = talentsMap.checkedGet(talentID);
            var elementsOverride = talent.getOverrideInterfaceElements(talentsTaken);
            for (var key in elementsOverride)
                if (elementsOverride.hasOwnProperty(key)) {
                    result[key] = elementsOverride[key];
                }
        }
        return result;
    };
    Hero.prototype.shadowAbilitiesVisible = function (talentsTaken) {
        var result = {};
        for (var key in this.ShadowAbilities)
            if (this.ShadowAbilities.hasOwnProperty(key)) {
                result[key] = this.ShadowAbilities[key];
            }
        for (var _i = 0, talentsTaken_3 = talentsTaken; _i < talentsTaken_3.length; _i++) {
            var talentID = talentsTaken_3[_i];
            var talent = talentsMap.checkedGet(talentID);
            var shadowOverride = talent.getOverrideShadowAbilities(talentsTaken);
            for (var key in shadowOverride)
                if (shadowOverride.hasOwnProperty(key)) {
                    result[key] = shadowOverride[key];
                }
        }
        return result;
    };
    Hero.prototype.getSettings = function () {
        return this.settings;
    };
    Hero.prototype.overrideAttributesInfo = function (override) {
        var result = {};
        var iterator = new HeroAttributes();
        for (var _i = 0, _a = iterator.allAttributesArray(); _i < _a.length; _i++) {
            var attribute = _a[_i];
            if (override && override.hasOwnProperty(attribute)) {
                result[attribute] = override[attribute];
            }
            else if (HeroConstants.defaultAttributeNameValues.hasOwnProperty(attribute)) {
                result[attribute] = HeroConstants.defaultAttributeNameValues[attribute];
            }
            else {
                result[attribute] = null;
            }
        }
        return result;
    };
    Hero.prototype.checkTalentTree = function () {
        if (this.talents.startLevel != 0 && this.talents.tree[this.talents.startLevel] == undefined) {
            throw new Error("checkTalentTree error: no talent settings for start level ".concat(this.talents.startLevel, ".\n                \rHero ").concat(this.ID));
        }
        var idArray = [];
        var levels = Object.keys(this.talents.tree).map(function (v) { return +v; });
        var min = Math.min.apply(Math, levels);
        var max = Math.max.apply(Math, levels);
        for (var level = min; level <= max; level++) {
            var talentSettings = this.talents.tree[level];
            if (talentSettings == undefined || Object.keys(talentSettings.talents).length == 0) {
                throw new Error("checkTalentTree error: no talents at level ".concat(level, " for hero ").concat(this.id));
            }
            if (level <= this.talents.startLevel && talentSettings.price > 0) {
                throw new Error("checkTalentTree error: settings at level ".concat(level, " available \n                    \rfrom start and have none zero price. Hero ").concat(this.ID));
            }
            if (Object.keys(talentSettings.talents).length == 1) {
                continue;
            }
            for (var talentIndex in talentSettings.talents)
                if (talentSettings.talents.hasOwnProperty(talentIndex)) {
                    var talent = talentSettings.talents[talentIndex];
                    var id = talent.ID;
                    if (idArray.indexOf(id) == -1) {
                        idArray.push(id);
                    }
                    else {
                        throw 'checkTalentTree failed. Two talents in hero ' + this.Alias + ' talent ID ' + id;
                    }
                }
        }
    };
    Hero.prototype.getRandomTalentsByLevel = function (level, ri) {
        var result = [];
        for (var lvl = 1; lvl <= level; lvl++) {
            if (this.talents && this.talents.tree[lvl]) {
                var talentSettings = this.talents.tree[lvl];
                var talentsAtLevel = talentSettings.talents;
                var keys = Object.keys(talentsAtLevel);
                var len = keys.length;
                var chosenTalentKey = keys[ri.nextInt(len)];
                var chosenTalentId = talentsAtLevel[chosenTalentKey].ID;
                result.push(chosenTalentId);
            }
        }
        return result;
    };
    Hero.prototype.getHeroAttributes = function () {
        return this.attributes;
    };
    Hero.prototype.getFakeAttributes = function () {
        return this.attributesFake;
    };
    Hero.getAccountPartLevel = function (al, exp) {
        if (al >= MAX_ACCOUNT_LEVEL) {
            return MAX_ACCOUNT_LEVEL;
        }
        var bound = AccountLevelUpPrices[al];
        if (!al || !bound) {
            return 0;
        }
        bound = exp ? exp / bound : 0;
        return bound + al;
    };
    Hero.prototype.getTalentPartLevel = function (talentLevel, duplicates) {
        var nextLevel = talentLevel + 1;
        if (this.talents.tree[nextLevel] != undefined && this.talents.tree[nextLevel].price > 0) {
            var info = this.talents.tree[nextLevel];
            talentLevel += duplicates / info.price;
        }
        return talentLevel;
    };
    Hero.extendShards = function (shards, heroesInfo, accLevel) {
        var result = {};
        shards = getObjectFromRaw(shards);
        heroesInfo = getObjectFromRaw(heroesInfo);
        for (var heroName in heroes) {
            var hero = heroes[heroName];
            if (shards && shards[hero.ID] != undefined) {
                result[hero.ID] = shards[hero.ID];
            }
            else if (accLevel >= hero.AccLevelNeeded && !heroesInfo[hero.ID]) {
                result[hero.ID] = 0;
            }
        }
        return result;
    };
    Hero.prototype.getStartHeroState = function () {
        return {
            Level: this.StartLevel,
            TalentLevel: this.talents.startLevel,
            Duplicates: 0,
            Exp: 0,
        };
    };
    Hero.prototype.setCorrectStateWithDuplicates = function (state) {
        var _a = this.getMinMaxTalentLevels(), minLevel = _a[0], maxLevel = _a[1];
        state.TalentLevel = Math.min(Math.max(minLevel, state.TalentLevel), maxLevel);
        var nextLevel = state.TalentLevel + 1;
        if (nextLevel <= maxLevel) {
            var price = this.talents.tree[nextLevel].price;
            if (state.Duplicates >= price) {
                state.TalentLevel++;
                state.Duplicates -= price;
                if (state.Duplicates > 0) {
                    this.setCorrectStateWithDuplicates(state);
                }
            }
        }
    };
    Hero.prototype.getMinMaxTalentLevels = function () {
        var levels = Object.keys(this.talents.tree).sort(function (a, b) { return +a - +b; });
        var min = Math.min(+levels[0], this.talents.startLevel);
        return [min, +levels[levels.length - 1]];
    };
    Hero.prototype.getMaxTalentLevel = function () {
        return this.getMinMaxTalentLevels()[1];
    };
    Hero.prototype.getAvailableShardsAndCardsQuantity = function (heroState, shardsNumber) {
        var state = heroState || this.getStartHeroState();
        state = Hero.upLevelIfNecessary(state, this.ID);
        this.setCorrectStateWithDuplicates(state);
        var availableCardsQuantity = 0;
        if (state.Level < HeroConstants.maxHeroLevel) {
            var price = getHeroLevelUpPrice({ heroId: this.ID, level: state.Level });
            availableCardsQuantity = price.exp - state.Exp;
            for (var level = state.Level + 1; level < HeroConstants.maxHeroLevel; level++) {
                price = getHeroLevelUpPrice({ heroId: this.ID, level: level });
                availableCardsQuantity += price.exp;
            }
        }
        var shards = 0;
        var availableShardsQuantity = 0;
        if (shardsNumber != undefined) {
            shards = shardsNumber;
        }
        else if (heroState != undefined) {
            shards = this.shards_needed;
        }
        if (shards < this.shards_needed) {
            availableShardsQuantity = this.shards_needed - shards;
        }
        var _a = this.getMinMaxTalentLevels(), _ = _a[0], maxLevel = _a[1];
        if (state.TalentLevel < maxLevel) {
            var nextLevel = state.TalentLevel + 1;
            if (this.talents.tree[nextLevel]) {
                availableShardsQuantity += (this.talents.tree[nextLevel].price - state.Duplicates);
            }
            for (var level = nextLevel + 1; level <= maxLevel; level++) {
                availableShardsQuantity += this.talents.tree[level].price;
            }
        }
        return {
            availableCardsQuantity: availableCardsQuantity,
            availableShardsQuantity: availableShardsQuantity,
        };
    };
    Hero.prototype.getTalentLevelByTalents = function (talents) {
        var _a = this.getMinMaxTalentLevels(), min = _a[0], _ = _a[1];
        var level = min;
        var talentsMap = {};
        for (var talentLevel in this.talents.tree) {
            var levelSettings = this.talents.tree[talentLevel];
            for (var index in levelSettings.talents) {
                var talent = levelSettings.talents[index];
                talentsMap[talent.ID] = +talentLevel;
            }
        }
        for (var _i = 0, talents_1 = talents; _i < talents_1.length; _i++) {
            var talentId = talents_1[_i];
            if (talentsMap[talentId] != undefined) {
                level = Math.max(talentsMap[talentId], level);
            }
        }
        return level;
    };
    Hero.prototype.cutTalentsByLevel = function (talents, talentLevel) {
        var result = [];
        for (var tLevel in this.talents.tree) {
            if (+tLevel <= talentLevel) {
                var levelSettings = this.talents.tree[tLevel];
                for (var index in levelSettings.talents) {
                    var talent = levelSettings.talents[index];
                    if (talents.indexOf(talent.ID) > -1) {
                        result.push(talent.ID);
                        break;
                    }
                }
            }
        }
        return result;
    };
    return Hero;
}());
var visibleAttributesInfo = {
    WeaponDamage: new AttributeInfo({ image: "weapon_damage_img", alias: "weapon_damage" }),
    BodyDefense: new AttributeInfo({ image: "body_defense_img", alias: "body_defense" }),
    MagicDamage: new AttributeInfo({ image: "magic_damage_img", alias: "magic_damage" })
};
