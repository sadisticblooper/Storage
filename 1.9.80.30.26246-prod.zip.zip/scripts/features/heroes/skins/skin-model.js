var Skin = (function () {
    function Skin(s) {
        this.customizationType = CUSTOMIZATION.SKIN;
        this.ID = s.ID;
        this.OwnerHeroID = s.OwnerHeroID;
        this.HeroOwner = s.OwnerHeroID;
        this.Rarity = s.Rarity;
        this.BigAvatar = s.BigAvatar;
        this.SmallAvatar = s.SmallAvatar;
        this.AliasName = s.AliasName;
        this.Appearance = s.Appearance;
        this.IsDefault = !!s.IsDefault;
        this.PutOnHero = !!s.PutOnHero;
        this.AssetBundleTag = s.AssetBundleTag;
        this.VideoId = s.VideoId ? s.VideoId : 0;
        this.WeaponId = s.WeaponId;
        this.DefaultWeaponId = this.WeaponId;
        this.customUnlockedPlacement = s.CustomUnlockedPlacement ? s.CustomUnlockedPlacement : null;
        this.RoguelikeAvatar = getValueByKeyDefault(s, "RoguelikeAvatar", "Sprites/PreviewImages/PVECharacters/Pve_character_Ling");
        this.AltRoguelikeAvatar =
            getValueByKeyDefault(s, "AltRoguelikeAvatar", this.RoguelikeAvatar);
        if (this.PutOnHero && !this.IsDefault) {
            throw new Error("If skin has flag PutOnHero, it must has flag IsDefault = true. Skin ID ".concat(s.ID));
        }
        if (this.WeaponId != this.DefaultWeaponId) {
            throw new Error("WeaponId [".concat(this.WeaponId, "] must be \n                \requal DefaultWeaponId [").concat(this.DefaultWeaponId, "] in Skin ").concat(this.ID));
        }
        Skin.AddDefaultSkin(this);
        Skin.WeaponsInKit.push(this.WeaponId);
        this.rarity = this.Rarity;
        this.configsOrder = s.configsOrder;
        this.heroOwners = [this.HeroOwner];
        this.ShardsNeeded = s.ShardsNeeded;
    }
    Skin.getAppearanceBySkinID = function (id) {
        var skin = skinsMap.checkedGet(id);
        return skin.Appearance;
    };
    Skin.setSkinsToHeroes = function () {
        var connector = {};
        for (var skinName in skins) {
            var skin = skins[skinName];
            if (skin.IsDefault) {
                HeroWeapon.DefaultWeapons.push(skin.WeaponId);
            }
            var heroId = skin.OwnerHeroID;
            if (!connector[heroId]) {
                connector[heroId] = [];
            }
            connector[heroId].push(skin);
        }
        for (var heroId in connector) {
            var hero = heroesMap.checkedGet(heroId);
            hero.setSkins(connector[heroId]);
        }
    };
    Skin.setSkinsToHero = function (hero) {
        var skins_ = [];
        for (var skinName in skins) {
            var skin = skins[skinName];
            if (skin.OwnerHeroID == hero.ID) {
                skins_.push(skin);
            }
        }
        hero.setSkins(skins_);
    };
    Skin.AddDefaultSkin = function (skin) {
        if (skin.IsDefault && this.DefaultSkins.indexOf(skin.ID) == -1) {
            this.DefaultSkins.push(skin.ID);
        }
    };
    Skin.DefaultSkins = [];
    Skin.WeaponsInKit = [];
    return Skin;
}());
