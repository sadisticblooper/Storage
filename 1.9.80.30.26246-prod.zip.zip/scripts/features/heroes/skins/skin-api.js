function getSkinById(id) {
    return skinsMap.checkedGet(id);
}
