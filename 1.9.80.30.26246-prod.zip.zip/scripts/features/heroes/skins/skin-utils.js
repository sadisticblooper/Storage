var SkinUtils = (function () {
    function SkinUtils() {
    }
    SkinUtils.getAvailableIdsRandomGenerating = function (specify) {
        if (specify && specify.chestId && SkinConstants.skinsAvailableListSpecify[specify.chestId]) {
            return SkinConstants.skinsAvailableListSpecify[specify.chestId];
        }
        return SkinConstants.availableSkinsForRandomGeneration;
    };
    return SkinUtils;
}());
