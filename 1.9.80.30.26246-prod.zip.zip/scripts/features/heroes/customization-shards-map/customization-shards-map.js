var customizationShardsMap = createIDMap(CustomizationUtils.buildCompositeCustomizationShardsMap(), "CustomizationShardsMap");
