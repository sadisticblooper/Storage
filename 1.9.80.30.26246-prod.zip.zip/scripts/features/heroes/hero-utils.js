var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var HeroUtils = (function () {
    function HeroUtils() {
    }
    HeroUtils.getHeroesInfoFromRaw = function (settings) {
        var result = {
            HeroesInfo: {},
            ShardsInfo: {},
        };
        var heroesInfo = settings.HeroesInfo;
        var shardsInfo = settings.ShardsInfo;
        for (var name_1 in heroes) {
            var hero = heroes[name_1];
            var id = hero.ID.toString();
            if (heroesInfo[id] != undefined) {
                result.HeroesInfo[id] = {
                    Level: heroesInfo[id].Level,
                    Exp: heroesInfo[id].Exp,
                    TalentLevel: heroesInfo[id].TalentLevel,
                    Duplicates: heroesInfo[id].Duplicates,
                };
            }
            if (shardsInfo[id] != undefined) {
                result.ShardsInfo[id] = shardsInfo[id];
            }
            HeroUtils.setValidHeroesInfoAndShardsInfo(result.HeroesInfo, result.ShardsInfo, hero);
        }
        return result;
    };
    HeroUtils.setValidHeroesInfoAndShardsInfo = function (heroesInfo, shardsInfo, hero) {
        var heroId = hero.ID;
        if (heroesInfo[heroId] == undefined && shardsInfo[heroId] == undefined) {
            shardsInfo[heroId] = 0;
        }
        else {
            if (heroesInfo[heroId] != undefined && shardsInfo[heroId] != undefined) {
                delete shardsInfo[heroId];
            }
            if (shardsInfo[heroId] != undefined) {
                var shards = shardsInfo[heroId];
                if (shards >= hero.ShardsNeeded) {
                    delete shardsInfo[heroId];
                    heroesInfo[heroId] = hero.getStartHeroState();
                }
            }
            else {
                hero.setCorrectStateWithDuplicates(heroesInfo[heroId]);
            }
        }
    };
    HeroUtils.combineLoot = function (playerProgress, loot, settings) {
        var shardsInfo = playerProgress.heroShards;
        var heroesInfo = playerProgress.heroes;
        if (!settings || !settings.combineOnlyCustomizations) {
            for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
                var hid = _a[_i];
                var hero = heroesMap.get(hid);
                if (loot.Shards[hid] != undefined) {
                    if (heroesInfo[hid] != undefined) {
                        heroesInfo[hid].Duplicates += loot.Shards[hid];
                    }
                    else {
                        var already = shardsInfo[hid];
                        var fromLoot = loot.Shards[hid];
                        if (already + fromLoot >= hero.ShardsNeeded) {
                            shardsInfo[hid] = hero.ShardsNeeded;
                            heroesInfo[hid] = hero.getStartHeroState();
                            heroesInfo[hid].Duplicates += (already + fromLoot - hero.ShardsNeeded);
                        }
                        else {
                            shardsInfo[hid] += fromLoot;
                        }
                    }
                }
                if (loot.HeroExp[hid] != undefined && heroesInfo[hid]) {
                    heroesInfo[hid].Exp += loot.HeroExp[hid];
                }
                HeroUtils.setValidHeroesInfoAndShardsInfo(heroesInfo, shardsInfo, hero);
            }
        }
        var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
        for (var _b = 0, allCustomizations_1 = allCustomizations; _b < allCustomizations_1.length; _b++) {
            var customizationType = allCustomizations_1[_b];
            var lootIds = CustomizationUtils.getLootIdsContainer(customizationType, loot);
            var playerIds = CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress);
            if (lootIds == undefined || playerIds == undefined) {
                continue;
            }
            if (customizationType == CUSTOMIZATION.SKIN) {
                for (var _c = 0, lootIds_1 = lootIds; _c < lootIds_1.length; _c++) {
                    var id = lootIds_1[_c];
                    var skin = skinsMap.checkedGet(id);
                    playerProgress.skins.push(id);
                    playerProgress.weapons.push(skin.WeaponId);
                }
            }
            else {
                playerIds.push.apply(playerIds, lootIds);
            }
        }
    };
    HeroUtils.getAvailableSeparatedHeroes = function (playerProgress, restrictedList) {
        var result = {
            available: {},
            heroesInfo: {},
            shardsInfo: {},
        };
        var heroesInfo = playerProgress.heroes;
        var shardsInfo = playerProgress.heroShards;
        for (var hid in heroesInfo) {
            var hero = heroesMap.checkedGet(hid);
            if (!restrictedList || restrictedList.Cards.indexOf(hero.ID) == -1) {
                if (!result.available[hero.Rarity]) {
                    result.available[hero.Rarity] = {
                        shards: [],
                        cards: []
                    };
                }
                result.available[hero.Rarity].cards.push(hero.ID);
                result.heroesInfo[hid] = __assign({}, heroesInfo[hid]);
            }
            if (!restrictedList || restrictedList.Shards.indexOf(hero.ID) == -1) {
                if (!result.available[hero.Rarity]) {
                    result.available[hero.Rarity] = {
                        shards: [],
                        cards: []
                    };
                }
                result.available[hero.Rarity].shards.push(hero.ID);
                result.shardsInfo[hid] = hero.ShardsNeeded;
            }
        }
        for (var hid in shardsInfo) {
            var hero = heroesMap.checkedGet(hid);
            if (restrictedList && restrictedList.Shards.indexOf(hero.ID) != -1) {
                continue;
            }
            if (!result.available[hero.Rarity]) {
                result.available[hero.Rarity] = {
                    shards: [],
                    cards: []
                };
            }
            result.available[hero.Rarity].shards.push(hero.ID);
            result.shardsInfo[hid] = shardsInfo[hid];
        }
        for (var rarity in result.available) {
            var itemTypes = ["cards", "shards"];
            for (var _i = 0, itemTypes_1 = itemTypes; _i < itemTypes_1.length; _i++) {
                var type = itemTypes_1[_i];
                result.available[rarity][type].sort(function (a, b) { return a - b; });
            }
        }
        return result;
    };
    HeroUtils.getExpandedAvailableSeparatedHeroes = function (playerProgress, availableSeparated, cardSlots, restrictedList) {
        var requiredHeroes = {};
        for (var rarityNumberString in cardSlots.Rarities) {
            var rarityNumber = +rarityNumberString;
            var slotSettings = cardSlots.Rarities[rarityNumberString];
            var availableData = availableSeparated[rarityNumber]
                ? availableSeparated.available[rarityNumber]
                : { cards: [], shards: [], };
            if (slotSettings.CardsWeight && availableData.cards.length == 0
                || slotSettings.ShardsWeight && availableData.shards.length == 0) {
                requiredHeroes[rarityNumber] = {
                    cards: false,
                    shards: false,
                };
                if (slotSettings.CardsWeight && availableData.cards.length == 0) {
                    requiredHeroes[rarityNumber].cards = true;
                }
                if (slotSettings.ShardsWeight && availableData.shards.length == 0) {
                    requiredHeroes[rarityNumber].shards = true;
                }
            }
        }
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            var rarityNumber = hero.Rarity;
            if (requiredHeroes[rarityNumber] != undefined) {
                if (requiredHeroes[rarityNumber].cards) {
                    if (restrictedList && restrictedList.Cards.indexOf(hero.ID) != -1) {
                        continue;
                    }
                    if (availableSeparated.available[rarityNumber] == undefined
                        || availableSeparated.available[rarityNumber].cards.indexOf(hero.ID) == -1) {
                        if (availableSeparated.available[rarityNumber] == undefined) {
                            availableSeparated.available[rarityNumber] = {
                                cards: [],
                                shards: [],
                            };
                        }
                        availableSeparated.available[rarityNumber].cards.push(hero.ID);
                        availableSeparated.heroesInfo[hid] = hero.getStartHeroState();
                    }
                }
                if (requiredHeroes[rarityNumber].shards) {
                    if (restrictedList && restrictedList.Shards.indexOf(hero.ID) != -1) {
                        continue;
                    }
                    if (availableSeparated.available[rarityNumber] == undefined
                        || availableSeparated.available[rarityNumber].shards.indexOf(hero.ID) == -1) {
                        if (availableSeparated.available[rarityNumber] == undefined) {
                            availableSeparated.available[rarityNumber] = {
                                cards: [],
                                shards: [],
                            };
                        }
                        availableSeparated.available[rarityNumber].shards.push(hero.ID);
                        availableSeparated.shardsInfo[hid] = 0;
                    }
                }
            }
        }
        for (var rarity in availableSeparated.available) {
            var itemTypes = ["cards", "shards"];
            for (var _b = 0, itemTypes_2 = itemTypes; _b < itemTypes_2.length; _b++) {
                var type = itemTypes_2[_b];
                availableSeparated.available[rarity][type].sort(function (a, b) { return a - b; });
            }
        }
        return availableSeparated;
    };
    HeroUtils.getAvailableHeroesOnAccLevel = function (accLevel, availableList) {
        var result = [];
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var hero = heroesMap.checkedGet(id);
            if (accLevel >= hero.AccLevelNeeded) {
                if (availableList && availableList.indexOf(id) == -1) {
                    continue;
                }
                result.push(id);
            }
        }
        return result;
    };
    HeroUtils.getBestLoseHeroIdsByRarity = function (playerHeroes) {
        var bestLose = {};
        var bounds = {};
        for (var _i = 0, _a = LootConstants.orderRarity; _i < _a.length; _i++) {
            var rarityNumber = _a[_i];
            bounds[rarityNumber] = {
                min: { Level: 1000, Exp: 0, Duplicates: 0, TalentLevel: 0 },
                max: { Level: 0, Exp: 0, Duplicates: 0, TalentLevel: 0 }
            };
        }
        for (var heroId in playerHeroes)
            if (playerHeroes.hasOwnProperty(heroId)) {
                var hero = heroesMap.checkedGet(heroId);
                if (!bestLose[hero.Rarity]) {
                    bestLose[hero.Rarity] = { best: hero.ID, lose: hero.ID };
                }
                var trueState = Hero.upLevelIfNecessary(playerHeroes[heroId], hero.ID);
                var bestHeroLevel = bounds[hero.Rarity].max.Level;
                var bestHeroExp = bounds[hero.Rarity].max.Exp;
                if (trueState.Level > bestHeroLevel || trueState.Level == bestHeroLevel && trueState.Exp > bestHeroExp) {
                    bounds[hero.Rarity].max = trueState;
                    bestLose[hero.Rarity].best = hero.ID;
                }
                var loseHeroLevel = bounds[hero.Rarity].min.Level;
                var loseHeroExp = bounds[hero.Rarity].min.Exp;
                if (trueState.Level < loseHeroLevel || trueState.Level == loseHeroLevel && trueState.Exp < loseHeroExp) {
                    bounds[hero.Rarity].min = trueState;
                    bestLose[hero.Rarity].lose = hero.ID;
                }
            }
        return bestLose;
    };
    HeroUtils.getLockedHeroInfo = function (settings) {
        var heroId = settings.heroId, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var hero = heroesMap.checkedGet(heroId);
        if (hero.CustomUnlockedPlacement) {
            return hero.CustomUnlockedPlacement;
        }
        if (hero.ArenaNumberNeeded != 1) {
            var arena = arenasMap.checkedGet(hero.ArenaNumberNeeded);
            return {
                placementInfo: {
                    placement: META_PLACEMENT.ARENA_REWARDS,
                    target: arena.Rating,
                },
                unlockRequirements: {
                    isAlias: true,
                    value: HeroConstants.aliasesForFindButton.reachArenaToUnlockHero,
                    placeholders: [{ Value: arena.NameInf.Postfix, Type: ALIAS_TEXT_INSERTION_TYPE.TEXT }]
                },
                unlockRequirementsType: UNLOCK_REQUIREMENTS_TYPE.ARENA,
            };
        }
        var isRandomDropAvailable = hero.ShardsWeightForGenerating > 0 &&
            (!hero.UnlockHeroSinceDateTime || startTimeOfCurrentDayMS >= hero.UnlockHeroSinceDateTime);
        if (isRandomDropAvailable) {
            var severalShardsNeeded = hero.ShardsNeeded > 1;
            return {
                placementInfo: {
                    placement: META_PLACEMENT.SHOP_CHESTS,
                    target: 0,
                },
                unlockRequirements: {
                    isAlias: true,
                    value: severalShardsNeeded
                        ? HeroConstants.aliasesForFindButton.collectShardsToUnlockHero
                        : HeroConstants.aliasesForFindButton.openChestsToUnlockHero,
                    placeholders: severalShardsNeeded
                        ? [
                            { Type: ALIAS_TEXT_INSERTION_TYPE.COUNTER, Value: null },
                            { Type: ALIAS_TEXT_INSERTION_TYPE.TEXT, Value: hero.ShardsNeeded.toString() },
                        ]
                        : null,
                },
                unlockRequirementsType: severalShardsNeeded
                    ? UNLOCK_REQUIREMENTS_TYPE.COLLECT_FROM_CHESTS
                    : UNLOCK_REQUIREMENTS_TYPE.FIND_IN_CHESTS
            };
        }
        return {
            unlockRequirementsType: UNLOCK_REQUIREMENTS_TYPE.NON_SPECIFIED,
            unlockRequirements: { isAlias: true, value: HeroConstants.aliasesForFindButton.nowhere, placeholders: null },
            placementInfo: { placement: META_PLACEMENT.UNKNOWN, target: 0, },
        };
    };
    HeroUtils.getAccountLevelProgressFromHeroes = function (heroesInfo) {
        var result = {
            accountLevel: PlayerDefaults.AccountLevel,
            accountExp: PlayerDefaults.AccountExperience,
        };
        var expFromLevelUps = 0;
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var heroId = _a[_i];
            var id = heroId.toString();
            if (heroesInfo[id] != undefined) {
                var hero = heroesMap.get(id);
                var startLevel = hero.StartLevel;
                var heroState = heroesInfo[id];
                if (PlayerDefaults.AvailableHeroes[id]) {
                    var heroDefaultData = PlayerDefaults.AvailableHeroes[id];
                    startLevel = heroDefaultData.StartLevel;
                }
                for (var level = startLevel; level < heroState.Level; level++) {
                    var exp = getHeroLevelUpReward({ heroId: heroId, level: level });
                    if (exp) {
                        expFromLevelUps += exp;
                    }
                }
            }
        }
        if (expFromLevelUps) {
            result = combineAccountExp({ accountExp: expFromLevelUps, accountLevel: result.accountLevel });
        }
        return result;
    };
    HeroUtils.combineAccountExp = function (state) {
        var level = state.accountLevel;
        var exp = state.accountExp;
        var result = {
            accountLevel: level,
            accountExp: exp,
        };
        var lvlUpPrice = AccountLevelUpPrices[level];
        if (!lvlUpPrice) {
            if (AccountLevelUpPrices[level - 1]) {
                return result;
            }
            throw "combineAccountExp exception: not legal account level: " + level;
        }
        if (exp >= lvlUpPrice) {
            if (!AccountLevelUpPrices[level + 1]) {
                return {
                    accountLevel: level + 1,
                    accountExp: (exp - lvlUpPrice),
                };
            }
            result.accountLevel++;
            result.accountExp -= lvlUpPrice;
            result = combineAccountExp(result);
        }
        return result;
    };
    HeroUtils.getHeroCardsToLevel = function (settings) {
        var heroId = settings.heroId, level = settings.level;
        var hero = heroesMap.checkedGet(heroId);
        var cardsAmount = 0;
        var maxLevel = Math.max(hero.StartLevel, Math.min(level, hero.MaxLevel));
        for (var level_1 = hero.StartLevel; level_1 < maxLevel; level_1++) {
            cardsAmount += getHeroExpForLevelUp({
                level: level_1,
                heroId: heroId,
            });
        }
        return cardsAmount;
    };
    HeroUtils.getAllHeroIdsInRarities = function (rarities) {
        var result = [];
        for (var _i = 0, rarities_1 = rarities; _i < rarities_1.length; _i++) {
            var rarity = rarities_1[_i];
            if (this.heroIdsByRaritiesCache[rarity] == undefined) {
                this.heroIdsByRaritiesCache[rarity] = [];
                for (var heroName in heroes) {
                    var hero = heroes[heroName];
                    if (rarity == hero.Rarity) {
                        this.heroIdsByRaritiesCache[rarity].push(hero.ID);
                    }
                }
            }
            result = result.concat(this.heroIdsByRaritiesCache[rarity]);
        }
        return result;
    };
    HeroUtils.getHeroAvailableAppearances = function (heroId) {
        var result = [];
        var hero = heroesMap.checkedGet(heroId);
        for (var _i = 0, _a = hero.AvailableSkinIds; _i < _a.length; _i++) {
            var skinId = _a[_i];
            var skin = skinsMap.checkedGet(skinId);
            result.push(skin.Appearance.ID);
        }
        return result;
    };
    HeroUtils.getDojoShownHeroes = function () {
        var resultHeroes = {};
        for (var heroName in heroes)
            if (heroes.hasOwnProperty(heroName)) {
                var hero = heroes[heroName];
                if (!hero.lock_shards
                    && hero.ShowInRoadMap) {
                    resultHeroes[heroName] = heroes[heroName];
                }
            }
        return resultHeroes;
    };
    HeroUtils.getVisibleHeroShadowAbilities = function (settings) {
        var heroID = settings.heroID, heroTalents = settings.heroTalents;
        var hero = heroesMap.checkedGet(heroID);
        return hero.shadowAbilitiesVisible(heroTalents);
    };
    HeroUtils.getVisibleHeroPassiveAbilities = function (settings) {
        var heroID = settings.heroID, heroTalents = settings.heroTalents;
        var hero = heroesMap.checkedGet(heroID);
        return hero.passiveAbilitiesVisible(heroTalents);
    };
    HeroUtils.getAllPassiveAbilitiesForHero = function (heroId) {
        var hero = heroesMap.checkedGet(heroId);
        return hero.getAllPassiveAbilitiesForHero();
    };
    HeroUtils.getHeroBattleButtons = function (settings) {
        var heroID = settings.heroID, heroTalents = settings.heroTalents;
        var hero = heroesMap.checkedGet(heroID);
        return hero.getInterfaceElementsWithTalents(heroTalents);
    };
    HeroUtils.getAllHeroRarities = function (heroes) {
        var result = [];
        for (var key in heroes)
            if (heroes.hasOwnProperty(key)) {
                var hero = heroesMap.checkedGet(key);
                var rarity = hero.Rarity;
                if (result.indexOf(rarity) != -1) {
                    continue;
                }
                result.push(rarity);
            }
        return result;
    };
    HeroUtils.getAllUnownedPossibleHeroRarities = function (heroes, accLevel) {
        heroes = getObjectFromRaw(heroes);
        var unOwnedHeroIds = ArrayUtils.getArraySubstraction(heroesMap.getKeys(), Object.keys(heroes).map(Number));
        var unownedDict = {};
        for (var _i = 0, unOwnedHeroIds_1 = unOwnedHeroIds; _i < unOwnedHeroIds_1.length; _i++) {
            var id = unOwnedHeroIds_1[_i];
            var hero = heroesMap.checkedGet(id);
            if (hero.AccLevelNeeded <= accLevel) {
                unownedDict[id] = {};
            }
        }
        return getAllHeroRarities(unownedDict);
    };
    HeroUtils.heroLevelUpPrices = function (level, heroID) {
        var _a;
        var prices = (_a = {},
            _a[HERO_RARITY.COMMON] = HeroConstants.heroLevelUpPricesCommon,
            _a[HERO_RARITY.RARE] = HeroConstants.heroLevelUpPricesRare,
            _a[HERO_RARITY.EPIC] = HeroConstants.heroLevelUpPricesEpic,
            _a[HERO_RARITY.LEGENDARY] = HeroConstants.heroLevelUpPricesLegendary,
            _a);
        var hero = heroesMap.checkedGet(heroID);
        var price = prices[hero.Rarity];
        if (price == undefined) {
            return undefined;
        }
        return price[level];
    };
    ;
    HeroUtils.heroLevelUpRewards = function (level, heroID) {
        var _a;
        var rewards = (_a = {},
            _a[HERO_RARITY.COMMON] = HeroConstants.heroLevelUpRewardsCommon,
            _a[HERO_RARITY.RARE] = HeroConstants.heroLevelUpRewardsRare,
            _a[HERO_RARITY.EPIC] = HeroConstants.heroLevelUpRewardsEpic,
            _a[HERO_RARITY.LEGENDARY] = HeroConstants.heroLevelUpRewardsLegendary,
            _a);
        var hero = heroesMap.checkedGet(heroID);
        var reward = rewards[hero.Rarity];
        if (reward == undefined) {
            return undefined;
        }
        return reward[level];
    };
    HeroUtils.getCorePower = function (settings) {
        var accountLevel = settings.accountLevel, heroLevels = settings.heroLevels;
        var accuracy = 2, sum, K1 = HeroConstants.corePowerSettings.heroesMultiply, K2 = HeroConstants.corePowerSettings.accountLevelMultiply, K3 = HeroConstants.corePowerSettings.normalCoefficient;
        var levels = heroLevels.length ? heroLevels.length : 1;
        heroLevels = heroLevels.map(function (level) { return Math.pow(K1, level); });
        sum = (heroLevels.reduce(function (s, e) { return s + e; }, 0)) / levels;
        sum *= Math.pow(K2, accountLevel);
        return CommonUtils.roundNumber(Math.log(sum) / K3, accuracy);
    };
    HeroUtils.isValidCorePower = function (playerPower, enemyPower) {
        var powerBound = CommonUtils.getRelativeNumber(playerPower, HeroConstants.corePowerSettings.errorPower);
        return enemyPower >= playerPower && enemyPower <= playerPower + powerBound;
    };
    HeroUtils.getNumberOfHeroesWith5Talent = function (playerProgress) {
        var numberOfHeroes = 0;
        for (var hero in playerProgress.heroes) {
            if (playerProgress.heroes[hero].TalentLevel >= 5) {
                numberOfHeroes++;
            }
        }
        return numberOfHeroes;
    };
    HeroUtils.checkIfNoHeroOrNoTalents = function (heroesInfo, heroId) {
        var heroState = heroesInfo[heroId];
        if (heroState == undefined) {
            return true;
        }
        else {
            return heroState.TalentLevel == 0;
        }
    };
    HeroUtils.getHeroIDFromString = function (string) {
        var tokenizedString = string.toLowerCase()
            .split('_').filter(function (s) { return s.length > 0; });
        ;
        var bestMatch;
        function heroMatches(tokenizedString, tokenizedAlias) {
            for (var i = 0; i + tokenizedAlias.length <= tokenizedString.length; i++) {
                var match = true;
                for (var j = 0; j < tokenizedAlias.length; j++) {
                    if (tokenizedString[i + j] !== tokenizedAlias[j]) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    return true;
                }
            }
            return false;
        }
        for (var name_2 in heroes) {
            var hero = heroes[name_2];
            var tokenizedAlias = hero.Alias.toLowerCase()
                .split('_').filter(function (s) { return s.length > 0; });
            if (heroMatches(tokenizedString, tokenizedAlias)) {
                if (!bestMatch || tokenizedAlias.length > bestMatch.tokensCount) {
                    bestMatch = {
                        id: hero.ID,
                        tokensCount: tokenizedAlias.length,
                    };
                }
            }
        }
        return bestMatch === null || bestMatch === void 0 ? void 0 : bestMatch.id;
    };
    HeroUtils.heroIdsByRaritiesCache = {};
    return HeroUtils;
}());
