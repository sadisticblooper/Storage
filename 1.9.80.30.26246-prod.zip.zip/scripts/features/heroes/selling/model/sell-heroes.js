var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var SellHeroes = (function () {
    function SellHeroes() {
    }
    SellHeroes.getSellHeroPopUpSettings = function (settings) {
        var entity = settings.entity, heroId = settings.heroId;
        var hero = heroesMap.checkedGet(heroId);
        var video = hero.VideoId ? hero.VideoId : null;
        var sellHeroOfferInfo = null;
        var popUpButton = null;
        switch (entity.subId) {
            case SELL_HEROES_POPUP_TYPE.GACHA:
                popUpButton = {
                    alias: SellSettings.defaultSettings.popUpButtonAliases.toGacha,
                    navigation: {
                        placement: META_PLACEMENT.GACHA_BANNER,
                        target: entity.id,
                    }
                };
                break;
            case SELL_HEROES_POPUP_TYPE.OFFER:
                var offer = offersMap.checkedGet(entity.id);
                sellHeroOfferInfo = {
                    offerId: entity.id,
                    offerType: offer._saleGroupId
                        ? SELL_HEROES_OFFER_TYPE.SaleDirectOffer
                        : offer._directSaleForHeroId
                            ? SELL_HEROES_OFFER_TYPE.DirectOffer
                            : SELL_HEROES_OFFER_TYPE.ShopOffer,
                };
                break;
            case SELL_HEROES_POPUP_TYPE.ROULETTE:
                popUpButton = {
                    alias: SellSettings.defaultSettings.popUpButtonAliases.toRoulette,
                    navigation: {
                        placement: META_PLACEMENT.ROULETTE,
                        target: entity.id,
                    }
                };
                break;
            default:
                throw new Error("getSellHeroPopUpSettings: no popup type ".concat(entity.subId));
        }
        return {
            videoId: video,
            sellHeroOfferInfo: sellHeroOfferInfo,
            popUpButton: popUpButton,
        };
    };
    SellHeroes.getSellHeroSettings = function (settings) {
        var hid = settings.lockedHeroId, activeOffers = settings.activeOffers;
        var playerSortedOffers = SellHeroes.sortPlayerOffersByTime(activeOffers);
        var hero = heroesMap.checkedGet(hid);
        var sellSettings = SellSettings.heroesSellSettings[hid];
        if (!sellSettings) {
            throw new Error("getSellHeroSettings: no settings for ".concat(hid));
        }
        sellSettings = __assign(__assign({}, sellSettings), { offers: SellHeroes.sortSettingOffers(playerSortedOffers, sellSettings.offers) });
        var buttons = [];
        var buttonsIterator = [
            {
                checkers: [
                    new SellHeroesGachaChecker(),
                    new SellHeroesRouletteChecker(),
                    new SellHeroesReferralChecker(),
                    new SellHeroesFindChecker()
                ],
                noneStyle: SELL_HEROES_FIND_STYLE.Disabled
            },
            {
                checkers: [
                    new SellHeroesSaleChecker(),
                    new SellHeroesStarterChecker(),
                    new SellHeroesOffersChecker(),
                ],
                noneStyle: SELL_HEROES_GET_STYLE.Inactive
            },
        ];
        for (var _i = 0, buttonsIterator_1 = buttonsIterator; _i < buttonsIterator_1.length; _i++) {
            var iteration = buttonsIterator_1[_i];
            var checkers = iteration.checkers, noneStyle = iteration.noneStyle;
            var buttonSetting = null;
            var candidates = [];
            if (!isBeta) {
                for (var _a = 0, checkers_1 = checkers; _a < checkers_1.length; _a++) {
                    var checker = checkers_1[_a];
                    var button = checker.check(settings, sellSettings);
                    if (button) {
                        if (button.badgeVisual) {
                            buttonSetting = button;
                            break;
                        }
                        else {
                            candidates.push(button);
                        }
                    }
                }
            }
            buttonSetting = buttonSetting || candidates[0] || {
                badgeVisual: null,
                badgeHeroAlias: null,
                button: {
                    buttonStyle: noneStyle,
                    sellingType: SELL_HEROES_SELLING_TYPE.NONE,
                    entity: { subId: 0, id: 0 }
                },
                sortingOrder: SellSettings.defaultSettings.sortingOrders.default,
            };
            buttons.push(buttonSetting);
        }
        var findButtonSetting = buttons[0], getButtonSetting = buttons[1];
        var badgeSource = getButtonSetting.badgeVisual
            ? getButtonSetting
            : findButtonSetting;
        var clickableTypes = [
            SELL_HEROES_SELLING_TYPE.STARTER_PACK, SELL_HEROES_SELLING_TYPE.POPUP,
            SELL_HEROES_SELLING_TYPE.REFERRAL_MARATHON,
        ];
        var clickType = clickableTypes.indexOf(getButtonSetting.button.sellingType) > -1 && getButtonSetting.badgeVisual
            ? SELL_HERO_CLICK_TYPE.Get
            : clickableTypes.indexOf(findButtonSetting.button.sellingType) > -1 && findButtonSetting.badgeVisual
                ? SELL_HERO_CLICK_TYPE.Find
                : SELL_HERO_CLICK_TYPE.None;
        var getButtonAvailabilityLabel = { hasText: false, };
        if (getButtonSetting.button.sellingType == SELL_HEROES_SELLING_TYPE.NONE) {
            getButtonAvailabilityLabel.hasText = true;
            var offer = offersMap.get(hero.OfferToDirectBuy);
            var timeToOfferEnd = offer && offer._activeTime.startGenerationBound;
            timeToOfferEnd = !!timeToOfferEnd && timeToOfferEnd > settings.startTimeOfCurrentDayMS
                ? timeToOfferEnd
                : null;
            getButtonAvailabilityLabel.timeToStartAvailability = timeToOfferEnd;
        }
        return {
            badgeVisual: badgeSource.badgeVisual,
            badgeHeroAlias: findButtonSetting.badgeHeroAlias,
            findButton: findButtonSetting.button,
            getButton: getButtonSetting.button,
            getButtonAvailabilityLabel: getButtonAvailabilityLabel,
            clickType: clickType,
            sortingOrder: badgeSource.sortingOrder,
        };
    };
    SellHeroes.sortSellActivities = function () {
        for (var heroId in SellSettings.heroesSellSettings) {
            var sellSettings = SellSettings.heroesSellSettings[heroId];
            sellSettings.gacha.sort(function (a, b) { return b.sortWeight - a.sortWeight; });
            sellSettings.marathons.sort(function (a, b) { return b.sortWeight - a.sortWeight; });
            sellSettings.roulette.sort(function (a, b) { return b.sortWeight - a.sortWeight; });
        }
    };
    SellHeroes.sortPlayerOffersByTime = function (playerOffers) {
        var result = [];
        var maxExpireTime = 0;
        for (var _i = 0, playerOffers_1 = playerOffers; _i < playerOffers_1.length; _i++) {
            var activeOffer = playerOffers_1[_i];
            var offer = offersMap.get(activeOffer.id);
            var expireTime = 0;
            if (!offer) {
                continue;
            }
            if (isNumber(activeOffer.expireTime) && +activeOffer.expireTime > 0) {
                expireTime = activeOffer.expireTime;
                maxExpireTime = Math.max(maxExpireTime, expireTime);
            }
            result.push({
                id: offer.ID,
                expireTime: expireTime,
            });
        }
        result.sort(function (info1, info2) {
            var time1 = info1.expireTime ? (maxExpireTime - info1.expireTime) : -1;
            var time2 = info2.expireTime ? (maxExpireTime - info2.expireTime) : -1;
            return time1 - time2;
        });
        return result;
    };
    SellHeroes.sortSettingOffers = function (playerOffers, sellOffer) {
        var result = sellOffer.slice();
        var prioritiesMap = {};
        for (var i = 0; i < playerOffers.length; i++) {
            var playerOffer = playerOffers[i];
            prioritiesMap[playerOffer.id] = playerOffers.length - i;
        }
        result.sort(function (item1, item2) {
            var priority1 = prioritiesMap[item1.id] || 0;
            var priority2 = prioritiesMap[item2.id] || 0;
            if (item2.sortWeight == item1.sortWeight) {
                return priority2 - priority1;
            }
            return item2.sortWeight - item1.sortWeight;
        });
        return result;
    };
    SellHeroes.getHeroesSaleSettings = function (settings) {
        var activeOffers = settings.activeOffers;
        var expireTime = Infinity;
        var result = {
            expireTime: null,
            saleId: -1,
            saleHeroesType: SELL_HEROES_SALE_TYPE.UNKNOWN,
        };
        for (var _i = 0, activeOffers_1 = activeOffers; _i < activeOffers_1.length; _i++) {
            var activeOffer = activeOffers_1[_i];
            var offer = offersMap.get(activeOffer.id);
            if (offer && offer._saleGroupId) {
                if (activeOffer.expireTime && activeOffer.expireTime > 0 && activeOffer.expireTime < expireTime) {
                    expireTime = activeOffer.expireTime;
                    result.saleId = offer._saleGroupId;
                }
            }
        }
        if (result.saleId > 0) {
            var saleSettings = PromoOfferSaleCreator.salesSettings[result.saleId];
            if (saleSettings) {
                result.saleHeroesType = saleSettings.closeSaleAfterOnePurchase
                    ? SELL_HEROES_SALE_TYPE.ONE_OF_ALL
                    : SELL_HEROES_SALE_TYPE.ALL_OF_ALL;
                result.expireTime = expireTime;
                return result;
            }
        }
        return null;
    };
    return SellHeroes;
}());
