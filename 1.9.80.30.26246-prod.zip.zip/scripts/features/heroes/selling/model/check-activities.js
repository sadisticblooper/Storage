var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SellHeroesActivityChecker = (function () {
    function SellHeroesActivityChecker() {
    }
    return SellHeroesActivityChecker;
}());
var SellHeroesGachaChecker = (function (_super) {
    __extends(SellHeroesGachaChecker, _super);
    function SellHeroesGachaChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesGachaChecker.prototype.check = function (settings, sellSettings) {
        var playerActivityIds = settings.activeGachaIds;
        var settingsActivityIds = sellSettings.gacha;
        if (playerActivityIds.length > 0) {
            for (var _i = 0, settingsActivityIds_1 = settingsActivityIds; _i < settingsActivityIds_1.length; _i++) {
                var item = settingsActivityIds_1[_i];
                if (playerActivityIds.indexOf(item.id) > -1) {
                    return {
                        badgeVisual: SellSettings.defaultSettings.badgesVisual.commonActivity,
                        badgeHeroAlias: HeroConstants.aliasesForFindButton.inGacha,
                        button: {
                            sellingType: SELL_HEROES_SELLING_TYPE.POPUP,
                            entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.GACHA },
                            buttonStyle: SELL_HEROES_FIND_STYLE.Activities,
                        },
                        sortingOrder: SellSettings.defaultSettings.sortingOrders.gacha,
                    };
                }
            }
        }
        return null;
    };
    return SellHeroesGachaChecker;
}(SellHeroesActivityChecker));
var SellHeroesRouletteChecker = (function (_super) {
    __extends(SellHeroesRouletteChecker, _super);
    function SellHeroesRouletteChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesRouletteChecker.prototype.check = function (settings, sellSettings) {
        var playerActivityIds = settings.activeRouletteIds;
        var settingsActivityIds = sellSettings.roulette;
        if (playerActivityIds.length > 0) {
            for (var _i = 0, settingsActivityIds_2 = settingsActivityIds; _i < settingsActivityIds_2.length; _i++) {
                var item = settingsActivityIds_2[_i];
                if (playerActivityIds.indexOf(item.id) > -1) {
                    return {
                        badgeVisual: SellSettings.defaultSettings.badgesVisual.commonActivity,
                        badgeHeroAlias: HeroConstants.aliasesForFindButton.inRoulette,
                        button: {
                            sellingType: SELL_HEROES_SELLING_TYPE.POPUP,
                            entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.ROULETTE },
                            buttonStyle: SELL_HEROES_FIND_STYLE.Activities,
                        },
                        sortingOrder: SellSettings.defaultSettings.sortingOrders.roulette,
                    };
                }
            }
        }
        return null;
    };
    return SellHeroesRouletteChecker;
}(SellHeroesActivityChecker));
var SellHeroesFindChecker = (function (_super) {
    __extends(SellHeroesFindChecker, _super);
    function SellHeroesFindChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesFindChecker.prototype.check = function (settings, sellSettings) {
        var lockedInfo = getLockedHeroInfo({
            heroId: settings.lockedHeroId,
            startTimeOfCurrentDayMS: settings.startTimeOfCurrentDayMS
        });
        var style = null;
        var sellingType = SELL_HEROES_SELLING_TYPE.FIND;
        switch (lockedInfo.unlockRequirementsType) {
            case UNLOCK_REQUIREMENTS_TYPE.ARENA:
                style = SELL_HEROES_FIND_STYLE.Arena;
                break;
            case UNLOCK_REQUIREMENTS_TYPE.COLLECT_FROM_CHESTS:
            case UNLOCK_REQUIREMENTS_TYPE.FIND_IN_CHESTS:
                style = SELL_HEROES_FIND_STYLE.ChestShop;
                break;
            case UNLOCK_REQUIREMENTS_TYPE.PVE_ROADMAP:
                style = SELL_HEROES_FIND_STYLE.Pve;
                break;
            default:
                style = SELL_HEROES_FIND_STYLE.Disabled;
                sellingType = SELL_HEROES_SELLING_TYPE.NONE;
        }
        return {
            badgeVisual: null,
            badgeHeroAlias: null,
            button: {
                sellingType: sellingType,
                entity: { subId: SELL_HEROES_POPUP_TYPE.NONE, id: 0 },
                buttonStyle: style,
            },
            sortingOrder: SellSettings.defaultSettings.sortingOrders.default,
        };
    };
    return SellHeroesFindChecker;
}(SellHeroesActivityChecker));
var SellHeroesReferralChecker = (function (_super) {
    __extends(SellHeroesReferralChecker, _super);
    function SellHeroesReferralChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesReferralChecker.prototype.check = function (settings, sellSettings) {
        var playerActivityIds = settings.activeMarathonsIds;
        var settingsActivityIds = sellSettings.marathons;
        if (playerActivityIds.length > 0) {
            for (var _i = 0, settingsActivityIds_3 = settingsActivityIds; _i < settingsActivityIds_3.length; _i++) {
                var item = settingsActivityIds_3[_i];
                if (playerActivityIds.indexOf(item.id) > -1) {
                    var marathon = MarathonsMap.get(item.id);
                    if (marathon && marathon.MarathonType == MARATHON_TYPE.REFERRAL) {
                        return {
                            badgeVisual: SellSettings.defaultSettings.badgesVisual.referral,
                            badgeHeroAlias: HeroConstants.aliasesForFindButton.inReferralMarathon,
                            button: {
                                sellingType: SELL_HEROES_SELLING_TYPE.REFERRAL_MARATHON,
                                entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.NONE },
                                buttonStyle: SELL_HEROES_FIND_STYLE.Social,
                            },
                            sortingOrder: SellSettings.defaultSettings.sortingOrders.referral,
                        };
                    }
                }
            }
        }
        return null;
    };
    return SellHeroesReferralChecker;
}(SellHeroesActivityChecker));
var SellHeroesSaleChecker = (function (_super) {
    __extends(SellHeroesSaleChecker, _super);
    function SellHeroesSaleChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesSaleChecker.prototype.check = function (settings, sellSettings) {
        var activeOffers = settings.activeOffers;
        var settingsActivityIds = sellSettings.offers;
        var offerIds = [];
        for (var _i = 0, activeOffers_1 = activeOffers; _i < activeOffers_1.length; _i++) {
            var item = activeOffers_1[_i];
            var offer = offersMap.get(item.id);
            if (offer && offer._saleGroupId) {
                offerIds.push(item.id);
            }
        }
        if (offerIds.length > 0) {
            for (var _a = 0, settingsActivityIds_4 = settingsActivityIds; _a < settingsActivityIds_4.length; _a++) {
                var item = settingsActivityIds_4[_a];
                if (offerIds.indexOf(item.id) > -1) {
                    return {
                        badgeVisual: SellSettings.defaultSettings.badgesVisual.sale,
                        badgeHeroAlias: HeroConstants.aliasesForFindButton.getHeroShardToUnlock,
                        button: {
                            sellingType: SELL_HEROES_SELLING_TYPE.POPUP,
                            entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.OFFER },
                            buttonStyle: SELL_HEROES_GET_STYLE.SaleOffer,
                        },
                        sortingOrder: SellSettings.defaultSettings.sortingOrders.sale,
                    };
                }
            }
        }
        return null;
    };
    return SellHeroesSaleChecker;
}(SellHeroesActivityChecker));
var SellHeroesStarterChecker = (function (_super) {
    __extends(SellHeroesStarterChecker, _super);
    function SellHeroesStarterChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesStarterChecker.prototype.check = function (settings, sellSettings) {
        var activeOffers = settings.activeOffers;
        var settingsActivityIds = sellSettings.offers;
        var offerIds = [];
        for (var _i = 0, activeOffers_2 = activeOffers; _i < activeOffers_2.length; _i++) {
            var item = activeOffers_2[_i];
            var offer = offersMap.get(item.id);
            if (offer && offer.IsStarterPack) {
                offerIds.push(item.id);
            }
        }
        if (offerIds.length > 0) {
            for (var _a = 0, settingsActivityIds_5 = settingsActivityIds; _a < settingsActivityIds_5.length; _a++) {
                var item = settingsActivityIds_5[_a];
                if (offerIds.indexOf(item.id) > -1) {
                    var visualSettings = getPromoOfferPopUpVisualSettings(item.id);
                    return {
                        badgeVisual: SellSettings.defaultSettings.badgesVisual.offers,
                        badgeHeroAlias: HeroConstants.aliasesForFindButton.getHeroShardToUnlock,
                        button: {
                            sellingType: visualSettings
                                ? SELL_HEROES_SELLING_TYPE.STARTER_PACK
                                : SELL_HEROES_SELLING_TYPE.POPUP,
                            entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.OFFER },
                            buttonStyle: SELL_HEROES_GET_STYLE.SpecialOffer,
                        },
                        sortingOrder: SellSettings.defaultSettings.sortingOrders.starter,
                    };
                }
            }
        }
        return null;
    };
    return SellHeroesStarterChecker;
}(SellHeroesActivityChecker));
var SellHeroesOffersChecker = (function (_super) {
    __extends(SellHeroesOffersChecker, _super);
    function SellHeroesOffersChecker() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SellHeroesOffersChecker.prototype.check = function (settings, sellSettings) {
        var activeOffers = settings.activeOffers;
        var settingsActivityIds = sellSettings.offers;
        var offerIds = [];
        for (var _i = 0, activeOffers_3 = activeOffers; _i < activeOffers_3.length; _i++) {
            var item = activeOffers_3[_i];
            var offer = offersMap.get(item.id);
            if (offer && !offer.IsStarterPack) {
                offerIds.push(item.id);
            }
        }
        if (offerIds.length > 0) {
            for (var _a = 0, settingsActivityIds_6 = settingsActivityIds; _a < settingsActivityIds_6.length; _a++) {
                var item = settingsActivityIds_6[_a];
                if (offerIds.indexOf(item.id) > -1) {
                    return {
                        badgeVisual: null,
                        badgeHeroAlias: HeroConstants.aliasesForFindButton.getHeroShardToUnlock,
                        button: {
                            sellingType: SELL_HEROES_SELLING_TYPE.POPUP,
                            entity: { id: item.id, subId: SELL_HEROES_POPUP_TYPE.OFFER },
                            buttonStyle: SELL_HEROES_GET_STYLE.DirectOffer,
                        },
                        sortingOrder: SellSettings.defaultSettings.sortingOrders.offer,
                    };
                }
            }
        }
        return null;
    };
    return SellHeroesOffersChecker;
}(SellHeroesActivityChecker));
