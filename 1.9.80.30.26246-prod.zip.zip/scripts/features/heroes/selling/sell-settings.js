var SellSettings = (function () {
    function SellSettings() {
    }
    SellSettings.defaultSettings = {
        badgesVisual: {
            referral: { bgColor: "#4C80CF", iconColor: "#22395C", icon: "Sprites/Assets/Icons/icon_FRIENDS" },
            offers: { bgColor: "#CFAE4C", iconColor: "#453A19", icon: "Sprites/Assets/Icons/icon_STORE_new" },
            commonActivity: { bgColor: "#75CF5F", iconColor: "#345C2A", icon: "Sprites/Assets/Icons/icon_ROULETTE" },
            sale: { bgColor: "#55E5BA", iconColor: "#225C4A", icon: "Sprites/Assets/Icons/icon_SALE" },
        },
        popUpButtonAliases: {
            toRoulette: "Hero_buy_roulette_button_alias",
            toGacha: "Hero_buy_shadow_rift_button_alias",
        },
        sortingOrders: {
            sale: 200,
            starter: 150,
            gacha: 100,
            roulette: 100,
            offer: 80,
            referral: 70,
            default: 0,
        },
    };
    SellSettings.heroesSellSettings = (function () {
        var result = {};
        for (var heroName in HeroNames) {
            result[HeroNames[heroName].ID] = { marathons: [], offers: [], gacha: [], roulette: [], };
        }
        return result;
    })();
    return SellSettings;
}());
