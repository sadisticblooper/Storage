function getHeroAvailableAppearances(heroId) {
    return HeroUtils.getHeroAvailableAppearances(heroId);
}
function getHeroAvailableSkinIds(heroId) {
    return heroesMap.checkedGet(heroId).AvailableSkinIds;
}
function getHeroLevelUpPrice(params) {
    return HeroUtils.heroLevelUpPrices(params.level, params.heroId);
}
function getHeroLevelUpReward(params) {
    return HeroUtils.heroLevelUpRewards(params.level, params.heroId);
}
function getHeroAttributeInfo(params) {
    return heroesMap.checkedGet(params.heroId).AttributesInfo;
}
function getDojoShownHeroes() {
    return HeroUtils.getDojoShownHeroes();
}
function getVisibleHeroShadowAbilities(settings) {
    return HeroUtils.getVisibleHeroShadowAbilities(settings);
}
function getVisibleHeroPassiveAbilities(settings) {
    return HeroUtils.getVisibleHeroPassiveAbilities(settings);
}
function getAllPassiveAbilitiesForHero(heroId) {
    return HeroUtils.getAllPassiveAbilitiesForHero(heroId);
}
function getHeroBattleButtons(settings) {
    return HeroUtils.getHeroBattleButtons(settings);
}
function getHeroExpForLevelUp(params) {
    var price = HeroUtils.heroLevelUpPrices(params.level, params.heroId);
    return price.exp;
}
function getAllHeroRarities(heroes) {
    return HeroUtils.getAllHeroRarities(heroes);
}
function getAllUnownedPossibleHeroRarities(heroes, accLevel) {
    return HeroUtils.getAllUnownedPossibleHeroRarities(heroes, accLevel);
}
function combineAccountExp(state) {
    return HeroUtils.combineAccountExp(state);
}
function getAllHeroIdsInRarities(rarities) {
    return HeroUtils.getAllHeroIdsInRarities(rarities);
}
function getSellHeroSettings(settings) {
    return SellHeroes.getSellHeroSettings(settings);
}
function getSellHeroPopUpSettings(settings) {
    return SellHeroes.getSellHeroPopUpSettings(settings);
}
function getLockedHeroInfo(settings) {
    return HeroUtils.getLockedHeroInfo(settings);
}
function getHeroesSaleSettings(settings) {
    return SellHeroes.getHeroesSaleSettings(settings);
}
function getCompositeCustomizationShardID(settings) {
    return CustomizationUtils.getCompositeCustomizationShardID(settings);
}
function getCustomizationShardsData(compositeId) {
    return CustomizationUtils.getCustomizationShardsData(compositeId);
}
