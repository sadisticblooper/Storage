var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18;
var HeroConstants = (function () {
    function HeroConstants() {
    }
    HeroConstants.heroBaseShadowTime = "4";
    HeroConstants.heroBaseAttributeValue = "100";
    HeroConstants.heroBaseCritChance = "0.1";
    HeroConstants.heroBaseCritMultiplier = "1.2";
    HeroConstants.heroBaseCooldown = "6";
    HeroConstants.heroBaseAmmo = "1";
    HeroConstants.accountMultiplier = "1.05";
    HeroConstants.accountAttributeCustomMultiplier = {
        Cooldown: "1",
        ShadowFormDuration: "1",
        CriticalChance: "1",
        CriticalMultiplier: "1",
        Ammo: "1",
    };
    HeroConstants.heroLevelUpPricesCommon = {
        1: { exp: 4, price: (_a = {}, _a[CURRENCY.COIN] = 100, _a) },
        2: { exp: 10, price: (_b = {}, _b[CURRENCY.COIN] = 200, _b) },
        3: { exp: 25, price: (_c = {}, _c[CURRENCY.COIN] = 350, _c) },
        4: { exp: 50, price: (_d = {}, _d[CURRENCY.COIN] = 600, _d) },
        5: { exp: 100, price: (_e = {}, _e[CURRENCY.COIN] = 2000, _e) },
        6: { exp: 200, price: (_f = {}, _f[CURRENCY.COIN] = 5000, _f) },
        7: { exp: 400, price: (_g = {}, _g[CURRENCY.COIN] = 10000, _g) },
        8: { exp: 600, price: (_h = {}, _h[CURRENCY.COIN] = 20000, _h) },
        9: { exp: 800, price: (_j = {}, _j[CURRENCY.COIN] = 30000, _j) },
        10: { exp: 1200, price: (_k = {}, _k[CURRENCY.COIN] = 40000, _k) },
        11: { exp: 2000, price: (_l = {}, _l[CURRENCY.COIN] = 50000, _l) },
        12: { exp: 4000, price: (_m = {}, _m[CURRENCY.COIN] = 60000, _m) },
    };
    HeroConstants.heroLevelUpRewardsCommon = {
        1: 5,
        2: 7,
        3: 10,
        4: 15,
        5: 20,
        6: 50,
        7: 75,
        8: 100,
        9: 125,
        10: 150,
        11: 175,
        12: 250,
    };
    HeroConstants.heroLevelUpPricesRare = {
        2: { exp: 4, price: (_o = {}, _o[CURRENCY.COIN] = 200, _o) },
        3: { exp: 10, price: (_p = {}, _p[CURRENCY.COIN] = 350, _p) },
        4: { exp: 25, price: (_q = {}, _q[CURRENCY.COIN] = 600, _q) },
        5: { exp: 50, price: (_r = {}, _r[CURRENCY.COIN] = 2000, _r) },
        6: { exp: 100, price: (_s = {}, _s[CURRENCY.COIN] = 5000, _s) },
        7: { exp: 150, price: (_t = {}, _t[CURRENCY.COIN] = 10000, _t) },
        8: { exp: 200, price: (_u = {}, _u[CURRENCY.COIN] = 20000, _u) },
        9: { exp: 300, price: (_v = {}, _v[CURRENCY.COIN] = 30000, _v) },
        10: { exp: 450, price: (_w = {}, _w[CURRENCY.COIN] = 40000, _w) },
        11: { exp: 750, price: (_x = {}, _x[CURRENCY.COIN] = 50000, _x) },
        12: { exp: 1200, price: (_y = {}, _y[CURRENCY.COIN] = 60000, _y) },
    };
    HeroConstants.heroLevelUpRewardsRare = {
        2: 7,
        3: 10,
        4: 15,
        5: 20,
        6: 50,
        7: 75,
        8: 100,
        9: 125,
        10: 150,
        11: 175,
        12: 250,
    };
    HeroConstants.heroLevelUpPricesEpic = {
        3: { exp: 4, price: (_z = {}, _z[CURRENCY.COIN] = 350, _z) },
        4: { exp: 10, price: (_0 = {}, _0[CURRENCY.COIN] = 600, _0) },
        5: { exp: 20, price: (_1 = {}, _1[CURRENCY.COIN] = 2000, _1) },
        6: { exp: 30, price: (_2 = {}, _2[CURRENCY.COIN] = 5000, _2) },
        7: { exp: 50, price: (_3 = {}, _3[CURRENCY.COIN] = 10000, _3) },
        8: { exp: 75, price: (_4 = {}, _4[CURRENCY.COIN] = 20000, _4) },
        9: { exp: 100, price: (_5 = {}, _5[CURRENCY.COIN] = 30000, _5) },
        10: { exp: 150, price: (_6 = {}, _6[CURRENCY.COIN] = 40000, _6) },
        11: { exp: 200, price: (_7 = {}, _7[CURRENCY.COIN] = 50000, _7) },
        12: { exp: 300, price: (_8 = {}, _8[CURRENCY.COIN] = 60000, _8) },
    };
    HeroConstants.heroLevelUpRewardsEpic = {
        3: 10,
        4: 15,
        5: 20,
        6: 50,
        7: 75,
        8: 100,
        9: 125,
        10: 150,
        11: 175,
        12: 250,
    };
    HeroConstants.heroLevelUpPricesLegendary = {
        4: { exp: 4, price: (_9 = {}, _9[CURRENCY.COIN] = 600, _9) },
        5: { exp: 10, price: (_10 = {}, _10[CURRENCY.COIN] = 2000, _10) },
        6: { exp: 20, price: (_11 = {}, _11[CURRENCY.COIN] = 5000, _11) },
        7: { exp: 30, price: (_12 = {}, _12[CURRENCY.COIN] = 10000, _12) },
        8: { exp: 50, price: (_13 = {}, _13[CURRENCY.COIN] = 20000, _13) },
        9: { exp: 75, price: (_14 = {}, _14[CURRENCY.COIN] = 30000, _14) },
        10: { exp: 100, price: (_15 = {}, _15[CURRENCY.COIN] = 40000, _15) },
        11: { exp: 150, price: (_16 = {}, _16[CURRENCY.COIN] = 50000, _16) },
        12: { exp: 200, price: (_17 = {}, _17[CURRENCY.COIN] = 60000, _17) },
    };
    HeroConstants.heroLevelUpRewardsLegendary = {
        4: 15,
        5: 20,
        6: 50,
        7: 75,
        8: 100,
        9: 125,
        10: 150,
        11: 175,
        12: 250,
    };
    HeroConstants.maxHeroLevel = (function () {
        var tables = [HeroConstants.heroLevelUpRewardsCommon, HeroConstants.heroLevelUpRewardsRare,
            HeroConstants.heroLevelUpRewardsEpic, HeroConstants.heroLevelUpRewardsLegendary];
        var max = 0;
        for (var _i = 0, tables_1 = tables; _i < tables_1.length; _i++) {
            var table = tables_1[_i];
            for (var level in table)
                if (isNumber(level)) {
                    max = Math.max(+level, max);
                }
        }
        return max + 1;
    })();
    HeroConstants.corePowerSettings = {
        heroesMultiply: 1.1,
        accountLevelMultiply: 1.21,
        normalCoefficient: 0.22 / 2 * 2.6,
        errorPower: "5%",
    };
    HeroConstants.equalTermsHeroLevel = 4;
    HeroConstants.defaultAttributeNameValues = {
        WeaponDamage: { icon: "icon_ATTACK", name: "hero_attack_tooltip", tooltip_desc: "hero_attack_tooltip_new_desc", bigIcon: "Sprites/Assets/Abilities/icon_attribute_attack" },
        BodyDefense: { icon: "icon_DEFENSE", name: "hero_defence_tooltip", tooltip_desc: "hero_defence_tooltip_desc", bigIcon: "Sprites/Assets/Abilities/icon_attribute_defense" },
        MagicDamage: { icon: "icon_MAGIC", name: "hero_magic_tooltip", tooltip_desc: "hero_magic_tooltip_new_desc", bigIcon: "Sprites/Assets/Abilities/icon_attribute_magic" }
    };
    HeroConstants.defaultInterfaceElements = {
        button_hit: "icon_KICK_FIST",
        button_kick: "icon_KICK_FOOT",
        button_ranged: "icon_ranged_shuriken",
        button_shadow: "icon_SHADOW_ENERGY",
        button_shadow_effect: "icon_ready_effect_shadow",
        abilities_tooltip_header: "shadow_abilities_tooltip_header",
        abilities_tooltip_desc: "shadow_abilities_tooltip_desc",
        interface_style_id: 1,
        shadow_ability_custom: false,
        shadow_bar_visuals_replace: ShadowBarVisualsReplace.None,
        shadow_bar: true,
    };
    HeroConstants.aliasesForFindButton = {
        reachArenaToUnlockHero: "hero_info_locked_by_arena",
        collectShardsToUnlockHero: "hero_info_locked_by_shards",
        openChestsToUnlockHero: "hero_info_locked_by_chest",
        stanceUnavailable: "hero_start_stance_unavailable",
        winUnavailable: "hero_win_stance_unavailable",
        skinUnavailable: "hero_skin_unavailable",
        tauntUnavailable: "hero_taunt_unavailable",
        emojiUnavailable: "library_emoji_unavailable",
        reachArenaToUnlockWeapon: "hero_customization_unavailable_not_enaugh_arena_level",
        waitForEvent: "hero_weapon_unavailable",
        getHeroShardToUnlock: "Hero_buy_find_shards_alias",
        nowhere: "Hero_buy_find_shards_alias",
        inGacha: "hero_info_locked_by_gacha",
        inRoulette: "hero_info_locked_by_roulette",
        inReferralMarathon: "hero_info_locked_by_marathon",
    };
    HeroConstants.customizationRarityMap = (_18 = {},
        _18[CUSTOMIZATION_RARITY.LEGENDARY_SKIN] = SKIN_RARITY.LEGENDARY,
        _18[CUSTOMIZATION_RARITY.SEASON_SKIN] = SKIN_RARITY.SEASON,
        _18[CUSTOMIZATION_RARITY.EPIC_SKIN] = SKIN_RARITY.EPIC,
        _18[CUSTOMIZATION_RARITY.RARE_SKIN] = SKIN_RARITY.RARE,
        _18[CUSTOMIZATION_RARITY.COMMON_SKIN] = SKIN_RARITY.COMMON,
        _18[CUSTOMIZATION_RARITY.SEASON_STANCE] = STANCE_RARITY.SEASON,
        _18[CUSTOMIZATION_RARITY.EPIC_STANCE] = STANCE_RARITY.EPIC,
        _18[CUSTOMIZATION_RARITY.RARE_STANCE] = STANCE_RARITY.RARE,
        _18[CUSTOMIZATION_RARITY.COMMON_STANCE] = STANCE_RARITY.COMMON,
        _18[CUSTOMIZATION_RARITY.SEASON_TAUNT] = TAUNT_RARITY.SEASON,
        _18[CUSTOMIZATION_RARITY.EPIC_TAUNT] = TAUNT_RARITY.EPIC,
        _18[CUSTOMIZATION_RARITY.RARE_TAUNT] = TAUNT_RARITY.RARE,
        _18[CUSTOMIZATION_RARITY.COMMON_TAUNT] = TAUNT_RARITY.COMMON,
        _18[CUSTOMIZATION_RARITY.LEGENDARY_WEAPON] = HERO_WEAPON_RARITY.LEGENDARY,
        _18[CUSTOMIZATION_RARITY.EPIC_WEAPON] = HERO_WEAPON_RARITY.EPIC,
        _18[CUSTOMIZATION_RARITY.RARE_WEAPON] = HERO_WEAPON_RARITY.RARE,
        _18[CUSTOMIZATION_RARITY.COMMON_WEAPON] = HERO_WEAPON_RARITY.COMMON,
        _18[CUSTOMIZATION_RARITY.EMOJI] = EMOJI_RARITY.ANY,
        _18[CUSTOMIZATION_RARITY.LEGENDARY_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.LEGENDARY,
        _18[CUSTOMIZATION_RARITY.EPIC_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.EPIC,
        _18[CUSTOMIZATION_RARITY.RARE_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.RARE,
        _18[CUSTOMIZATION_RARITY.COMMON_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.COMMON,
        _18);
    return HeroConstants;
}());
