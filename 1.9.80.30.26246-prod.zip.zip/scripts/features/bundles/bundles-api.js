function getBundleTags(settings) {
    return BundlesUtils.getBundleTags(settings);
}
function getBundleTagsForRemoving(settings) {
    return BundlesUtils.getBundleTagsForRemoving(settings);
}
function getAllBundleTags(isPBR) {
    return BundlesUtils.getAllBundleTags(isPBR);
}
function getShuffledBundleSlides() {
    return BundlesUtils.getShuffledBundleSlides();
}
function getBundlePreloaderParts() {
    return BundlesUtils.getBundlePreloaderParts();
}
function shouldGiveBundleLoadReward(settings) {
    return BundlesUtils.shouldGiveBundleLoadReward(settings);
}
function showBundlePreloaderParts(settings) {
    return shouldGiveBundleLoadReward(settings) && settings.isTutorialCompletedOnThisAppInstall;
}
function getBundlePartsExtractSlides() {
    return BundlesUtils.getBundlePartsExtractSlides();
}
function askForBundleDownloadPermissionWhileUsingCinematic(settings) {
    var platform = settings.platform;
    var platformsWithAsk = [];
    if (isIOSApproveInProgress) {
        platformsWithAsk.push.apply(platformsWithAsk, IOS_PLATFORMS);
    }
    return platformsWithAsk.indexOf(platform) > -1;
}
