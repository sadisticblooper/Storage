var Bundles = (function () {
    function Bundles() {
    }
    Bundles.preloaderSlideTime = new Time({ Seconds: 7 }).value;
    Bundles.fightsBeforeBundles = [
        FIGHT_MODE.PRE_TUTORIAL,
        FIGHT_MODE.TUTORIAL,
        FIGHT_MODE.TRAINING
    ];
    Bundles.preloaderSlides = [
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.Legion_King.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_E_Prince.RoguelikeAvatar),
            description: "loading_screen_text_legion_king_trivia",
        },
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.HongJoo.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.HongJoo_base_skin.RoguelikeAvatar),
            description: "loading_screen_text_hongjoo_trivia",
        },
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.Feldsher.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.Feldsher_base_skin.RoguelikeAvatar),
            description: "loading_screen_text_feldsher_trivia",
        },
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.Monk.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.RoguelikeAvatar),
            description: "loading_screen_text_monk",
        },
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.Ling.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.Ling_Base_skin.RoguelikeAvatar),
            description: "loading_screen_text_ling",
        },
        {
            type: PRELOADER_SLIDE_TYPE.HERO,
            heroId: heroes.Kibo.ID,
            image: "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.RoguelikeAvatar),
            description: "loading_screen_text_kibo",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "location_name_eldorado_new",
            image: "Sprites/PreviewImages/ArenaLocations/location_eldorado",
            description: "loading_screen_text_eldorado",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "location_name_wasteland",
            image: "Sprites/PreviewImages/ArenaLocations/location_wastelands",
            description: "loading_screen_text_outskirts",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "loading_screen_head_forest",
            image: "Sprites/PreviewImages/PreloaderInfo/preloader_gideon_forest",
            description: "loading_screen_text_forest",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "bamboo",
            image: "Sprites/PreviewImages/ArenaLocations/location_bamboo",
            description: "loading_screen_text_bamboo",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "marcus_village",
            image: "Sprites/PreviewImages/ArenaLocations/location_marcus_village",
            description: "loading_screen_text_village",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "castle",
            image: "Sprites/PreviewImages/ArenaLocations/location_castle",
            description: "loading_screen_text_castle",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "loading_screen_text_weapons_title",
            image: "Sprites/PreviewImages/PreloaderInfo/weapons_preloader",
            description: "loading_screen_text_weapons_descr",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "loading_screen_text_talents_title",
            image: "Sprites/PreviewImages/PreloaderInfo/talents_preloader",
            description: "loading_screen_text_talents_descr",
        },
        {
            type: PRELOADER_SLIDE_TYPE.IMAGE,
            header: "loading_screen_text_abilities_title",
            image: "Sprites/PreviewImages/PreloaderInfo/abilities_preloader",
            description: "loading_screen_text_abilities_descr",
        },
    ];
    Bundles.tutorialTags = [
        'common_animations', 'common_sounds', 'tutorial', 'cutscenes', 'common_effects',
        'texture_packs', 'common_models', 'common_taunts',
        'tutorial-ling', 'tutorial-monk', 'tutorial-liquidator', 'tutorial-kibo', 'tutorial-ironclad', 'tutorial-fireguard', 'tutorial-bulwark', 'preloader-images',
        BUNDLE_TAG.BAMBOO,
        'atlases', 'sprite_assets', 'sprite_previews', 'common_ui', 'console',
        'element_prefabs', 'widget_prefabs'
    ];
    Bundles.afterTutorialTags = [
        HERO_BUNDLE_TAG.BULWARK, HERO_BUNDLE_TAG.EMPEROR, HERO_BUNDLE_TAG.LEGION_KING, HERO_BUNDLE_TAG.FELDSHER,
        HERO_BUNDLE_TAG.FIREGUARD, HERO_BUNDLE_TAG.HELGA, HERO_BUNDLE_TAG.HONG_JOO,
        HERO_BUNDLE_TAG.IRONCLAD, HERO_BUNDLE_TAG.JET, HERO_BUNDLE_TAG.KIBO,
        HERO_BUNDLE_TAG.LING, HERO_BUNDLE_TAG.LIQUIDATOR, HERO_BUNDLE_TAG.LYNX,
        HERO_BUNDLE_TAG.MARCUS, HERO_BUNDLE_TAG.MIDNIGHT, HERO_BUNDLE_TAG.MONK, HERO_BUNDLE_TAG.MONKEY_KING,
        HERO_BUNDLE_TAG.SARGE, HERO_BUNDLE_TAG.VIPER, HERO_BUNDLE_TAG.YUKKA, HERO_BUNDLE_TAG.LEGION_KING, HERO_BUNDLE_TAG.BUTCHER,
        HERO_BUNDLE_TAG.ITU, HERO_BUNDLE_TAG.YUNLIN, HERO_BUNDLE_TAG.XIANG_TZU, HERO_BUNDLE_TAG.JUNE, HERO_BUNDLE_TAG.GIDEON, HERO_BUNDLE_TAG.WIDOW,
        HERO_BUNDLE_TAG.RAIKICHI, HERO_BUNDLE_TAG.NONNA, HERO_BUNDLE_TAG.SHOGUN,
        HERO_BUNDLE_TAG.WPN_BULWARK, HERO_BUNDLE_TAG.WPN_EMPEROR, HERO_BUNDLE_TAG.WPN_LEGION_KING, HERO_BUNDLE_TAG.WPN_FELDSHER, HERO_BUNDLE_TAG.WPN_FIREGUARD,
        HERO_BUNDLE_TAG.WPN_HELGA, HERO_BUNDLE_TAG.WPN_HONG_JOO, HERO_BUNDLE_TAG.WPN_IRONCLAD, HERO_BUNDLE_TAG.WPN_JET,
        HERO_BUNDLE_TAG.WPN_KIBO, HERO_BUNDLE_TAG.WPN_LING, HERO_BUNDLE_TAG.WPN_LIQUIDATOR, HERO_BUNDLE_TAG.WPN_LYNX,
        HERO_BUNDLE_TAG.WPN_MARCUS, HERO_BUNDLE_TAG.WPN_MIDNIGHT, HERO_BUNDLE_TAG.WPN_MONK, HERO_BUNDLE_TAG.WPN_MONKEY_KING,
        HERO_BUNDLE_TAG.WPN_SARGE, HERO_BUNDLE_TAG.WPN_VIPER, HERO_BUNDLE_TAG.WPN_YUKKA, HERO_BUNDLE_TAG.WPN_BUTCHER,
        HERO_BUNDLE_TAG.WPN_ITU, HERO_BUNDLE_TAG.WPN_YUNLIN, HERO_BUNDLE_TAG.WPN_XIANG_TZU, HERO_BUNDLE_TAG.WPN_JUNE, HERO_BUNDLE_TAG.WPN_GIDEON, HERO_BUNDLE_TAG.WPN_WIDOW,
        HERO_BUNDLE_TAG.WPN_RAIKICHI, HERO_BUNDLE_TAG.WPN_NONNA, HERO_BUNDLE_TAG.WPN_SHOGUN,
        'after_tutorial', 'stance_base', 'common_taunts', 'common_animations', 'atlases', 'common_sounds',
        'cutscenes', 'common_effects', 'texture_packs', 'common_models', 'machine_learning', 'effects', 'models', 'sounds',
        BUNDLE_TAG.BAMBOO,
        BUNDLE_TAG.VIPER_BACKSTREET,
        BUNDLE_TAG.ELDORADO,
        BUNDLE_TAG.THUNDER,
        BUNDLE_TAG.CASTLE,
        BUNDLE_TAG.PVE_CHAPTER_5,
        'sprite_assets', 'sprites_lottery', 'sprite_previews', 'stance_previews', 'taunt_previews', 'win_previews',
        'common_ui', 'console', 'element_prefabs', 'widget_prefabs', 'emoji_previews', 'event_prefabs', 'quests_preview',
        'pve'
    ];
    Bundles.tagsForRemoving = [
        BUNDLE_TAG.VOID_ROOM,
        BUNDLE_TAG.HERALDS_STREET_SPRING,
        BUNDLE_TAG.OBSERVATORY,
        BUNDLE_TAG.NEW_YEAR_LOCATION,
        BUNDLE_TAG.MARCUS_VILLAGE,
        BUNDLE_TAG.WASTELANDS,
        BUNDLE_TAG.PORT,
        BUNDLE_TAG.DESTROYED_VILLAGE,
    ];
    Bundles.bundlePreloaderParts = [
        {
            percentage: 0.03,
            reward: {
                icon: "Sprites/PreviewImages/CardCurrency/card_currency_Gold",
                iconColor: "#ffffff",
                overlay: null,
                glowColor: "#FFBB5E",
                state: "Default",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_resources", icon: "Sprites/Assets/Icons/icon_HERO_SHARDS" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_welcome",
                    header: "loading_screen_text_welcome_header",
                    description: "loading_screen_text_welcome_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_hero_upgrade",
                    header: "loading_screen_text_tournament_rules_header",
                    description: "loading_screen_text_tournament_rules_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_0",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.08,
            reward: {
                icon: "Sprites/PreviewImages/Emoji/AllPreview/emote_universal_Heralds",
                iconColor: "#ffffffff",
                overlay: null,
                glowColor: "#c878e2",
                state: "Emoji",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_tournaments", icon: "Sprites/Assets/Icons/icon_EVENTS" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_factions",
                    header: "loading_screen_text_factions_header",
                    description: "loading_screen_text_factions_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_heralds",
                    header: "loading_screen_text_heralds_header",
                    description: "loading_screen_text_heralds_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.HERO,
                    heroId: heroes.Itu.ID,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.RoguelikeAvatar),
                    description: "loading_screen_text_itu_desc"
                },
                {
                    type: PRELOADER_SLIDE_TYPE.HERO,
                    heroId: heroes.Lynx.ID,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Lynx_base_skin.RoguelikeAvatar),
                    description: "loading_screen_text_lynx_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_lynx_tournament",
                    header: "loading_screen_text_lynx_tournament_header",
                    description: "loading_screen_text_lynx_tournament_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_1",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.06,
            reward: {
                icon: "Sprites/PreviewImages/Emoji/AllPreview/emote_universal_Dynasty",
                iconColor: "#ffffffff",
                overlay: null,
                glowColor: "#7CDD9F",
                state: "Emoji",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_history", icon: "Sprites/Assets/Icons/icon_STORIES" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_dynasty",
                    header: "loading_screen_text_dynasty_story_1_header",
                    description: "loading_screen_text_dynasty_story_1_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_emperor_and_june",
                    header: "loading_screen_text_dynasty_story_2_header",
                    description: "loading_screen_text_dynasty_story_2_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_hongJoo_and_monkeyKing",
                    header: "loading_screen_text_dynasty_story_3_header",
                    description: "loading_screen_text_dynasty_story_3_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_dynasty_rewards",
                    header: "loading_screen_text_dynasty_rewards_header",
                    description: "loading_screen_text_dynasty_rewards_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_2",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.08,
            reward: {
                icon: "Sprites/PreviewImages/Heroes/".concat(skins.Monk_base_skin.SmallAvatar),
                iconColor: "#ffffff",
                overlay: "Sprites/Assets/CardLayout/card_shard_FX",
                overlayColor: "#97AEB8",
                glowColor: "#97AEB8",
                state: "Shards",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_bosses", icon: "Sprites/Assets/Icons/icon_DIFFICULTY_HARD" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_stories",
                    header: "loading_screen_text_stories_header",
                    description: "loading_screen_text_stories_mode_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_stories_buffs",
                    header: "loading_screen_text_stories_gameplay_header",
                    description: "loading_screen_text_stories_gameplay_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_stories_boss",
                    header: "loading_screen_text_boss_header",
                    description: "loading_screen_text_boss_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/ArenaLocations/location_pve_1_1",
                    header: "loading_screen_text_first_chapter_header",
                    description: "loading_screen_text_first_chapter_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_3",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.12,
            reward: {
                icon: "Sprites/PreviewImages/Emoji/AllPreview/emote_universal_Legion",
                iconColor: "#ffffffff",
                overlay: null,
                glowColor: "#D7464E",
                state: "Emoji",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_locations", icon: "Sprites/Assets/Icons/icon_LOCATION" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_legion",
                    header: "loading_screen_text_legion_header",
                    description: "loading_screen_text_legion_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.HERO,
                    heroId: heroes.Legion_King.ID,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Legion_King_base_skin.RoguelikeAvatar),
                    description: "loading_screen_text_legion_king_desc"
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/ArenaLocations/location_crypt",
                    header: "loading_screen_text_legion_crypt_header",
                    description: "loading_screen_text_legion_crypt_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.HERO,
                    heroId: heroes.Ironclad.ID,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Ironclad_base_skin.RoguelikeAvatar),
                    description: "loading_screen_text_ironclad_desc"
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_unbreak",
                    header: "loading_screen_text_legion_unbreak_header",
                    description: "loading_screen_text_legion_unbreak_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_leaderboard",
                    header: "loading_screen_text_legion_leaderboard_header",
                    description: "loading_screen_text_legion_leaderboard_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_4",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.16,
            reward: {
                icon: "Sprites/PreviewImages/Heroes/".concat(skins.Kibo_base_skin.SmallAvatar),
                iconColor: "#ffffff",
                overlay: "Sprites/Assets/CardLayout/card_shard_FX",
                overlayColor: "#C68CFF",
                glowColor: "#C68CFF",
                state: "Shards",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_heroes", icon: "Sprites/Assets/Icons/icon_HEROES" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_heroes_rarity",
                    header: "loading_screen_text_heroes_rarity_header",
                    description: "loading_screen_text_heroes_rarity_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_shards",
                    header: "loading_screen_text_heroes_shards_header",
                    description: "loading_screen_text_heroes_shards_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_shadow_rift",
                    header: "loading_screen_text_shadow_rift_header",
                    description: "loading_screen_text_shadow_rift_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/Chests/icon_chest_Shards_New",
                    header: "loading_screen_text_chest_header",
                    description: "loading_screen_text_chest_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/abilities_preloader",
                    header: "loading_screen_text_abilities_header",
                    description: "loading_screen_text_abilities_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/talents_preloader",
                    header: "loading_screen_text_talents_header",
                    description: "loading_screen_text_talents_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_weapons",
                    header: "loading_screen_text_weapons_header",
                    description: "loading_screen_text_weapons_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_5",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.12,
            reward: {
                icon: "Sprites/PreviewImages/Heroes/".concat(skins.Itu_base_skin.SmallAvatar),
                iconColor: "#ffffff",
                overlay: "Sprites/Assets/CardLayout/card_shard_FX",
                overlayColor: "#FFD75E",
                glowColor: "#FFD75E",
                state: "Shards",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_skins", icon: "Sprites/Assets/Icons/icon_SKINS" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_heroes_skins",
                    header: "loading_screen_text_heroes_skins_header",
                    description: "loading_screen_text_heroes_skins_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_heroes_skins_rarity",
                    header: "loading_screen_text_heroes_skins_variants_header",
                    description: "loading_screen_text_heroes_skins_variants_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_fight_pass_with_skin",
                    header: "loading_screen_text_heroes_skins_how_to_get_header",
                    description: "loading_screen_text_heroes_skins_how_to_get_desc",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Fireguard_E_White_Rec_Void.RoguelikeAvatar),
                    header: "loading_screen_text_heroes_skins_cool_header",
                    description: "loading_screen_text_heroes_skins_cool_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/Heroes/".concat(skins.Itu_L_Cosmic.RoguelikeAvatar),
                    header: "loading_screen_text_legendary_itu_skin_header",
                    description: "loading_screen_text_legendary_itu_skin_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_6",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
        {
            percentage: 0.35,
            reward: {
                icon: "Sprites/PreviewImages/Chests/icon_chest_Animation",
                iconColor: "#FFFFFF",
                overlay: null,
                glowColor: "#DA6ADE",
                state: "Chest",
            },
            circleLoaderIconVisualSettings: { color: "#E0C599", message: "loading_screen_head_animations", icon: "Sprites/Assets/Icons/icon_STANCES" },
            slides: [
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_respect",
                    header: "loading_screen_text_respect_header",
                    description: "loading_screen_text_respect_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_stances",
                    header: "loading_screen_text_stances_header",
                    description: "loading_screen_text_stances_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_taunts",
                    header: "loading_screen_text_taunts_header",
                    description: "loading_screen_text_taunts_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_emoji",
                    header: "loading_screen_text_emotes_header",
                    description: "loading_screen_text_emotes_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.REWARD,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_text_emoji",
                    header: "loading_screen_text_bubbles_header",
                    description: "loading_screen_text_bubbles_desc",
                    subHeader: "",
                },
                {
                    type: PRELOADER_SLIDE_TYPE.IMAGE,
                    image: "Sprites/PreviewImages/PreloaderInfo/preloader_rewards_7",
                    header: "loading_screen_text_rewards_header",
                    description: "loading_screen_text_rewards_desc",
                },
            ]
        },
    ];
    return Bundles;
}());
