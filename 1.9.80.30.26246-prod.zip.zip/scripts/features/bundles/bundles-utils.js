var BundlesUtils = (function () {
    function BundlesUtils() {
    }
    BundlesUtils.getBundleTags = function (settings) {
        var tags = !settings.IsTutorialPassed
            ? Bundles.tutorialTags
            : ArrayUtils.unionWithoutRepeats(Bundles.afterTutorialTags, Bundles.tutorialTags);
        if (settings.OpenedRoguelikeChapters) {
            for (var _i = 0, _a = settings.OpenedRoguelikeChapters; _i < _a.length; _i++) {
                var id = _a[_i];
                var chapter = chaptersMap.get(id);
                if (chapter) {
                    for (var _b = 0, _c = chapter.bundleTags; _b < _c.length; _b++) {
                        var tag = _c[_b];
                        if (tag && tags.indexOf(tag) == -1) {
                            tags.push(tag);
                        }
                    }
                }
            }
        }
        var removingTags = getBundleTagsForRemoving(settings);
        return ArrayUtils.getArraySubstraction(tags, removingTags);
    };
    BundlesUtils.getBundleTagsForRemoving = function (settings) {
        var removingTags = Bundles.tagsForRemoving.concat(settings.IsPBR ? ['nonpbr'] : ['pbr']);
        if (settings.PlayerInfo.Arena >= arenas.Arena3.ID) {
            removingTags.push('preloader-images');
        }
        return removingTags;
    };
    BundlesUtils.getAllBundleTags = function (isPBR) {
        var tags = ArrayUtils.unionWithoutRepeats(Bundles.afterTutorialTags, Bundles.tutorialTags);
        var removingTags = isPBR ? ['nonpbr'] : ['pbr'];
        return ArrayUtils.getArraySubstraction(tags, removingTags);
    };
    BundlesUtils.getShuffledBundleSlides = function () {
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        var slides = Bundles.preloaderSlides.slice().map(function (slide) {
            slide.nextSlideTimeMs = slide.nextSlideTimeMs || Bundles.preloaderSlideTime;
            return slide;
        });
        shuffle(slides, rnd);
        return slides;
    };
    BundlesUtils.getBundlePreloaderParts = function () {
        return Bundles.bundlePreloaderParts.map(function (pack) {
            pack.slides = pack.slides.map(function (slide) {
                slide.nextSlideTimeMs = slide.nextSlideTimeMs || Bundles.preloaderSlideTime;
                return slide;
            });
            return pack;
        });
    };
    BundlesUtils.shouldGiveBundleLoadReward = function (settings) {
        var isBundleLoadRewardGiven = settings.isBundleLoadRewardGiven, isTutorialPassed = settings.isTutorialPassed, regionalSettings = settings.regionalSettings, fightCounters = settings.fightCounters;
        if (["CN"].indexOf(regionalSettings.countryCode) > -1) {
            return false;
        }
        var fights = BundlesUtils.getFightCounterAfterBundles(fightCounters);
        return isTutorialPassed && !isBundleLoadRewardGiven && fights == 0;
    };
    BundlesUtils.getFightCounterAfterBundles = function (fightCounters) {
        var fights = 0;
        if (!fightCounters) {
            return fights;
        }
        for (var mode in fightCounters) {
            if (Bundles.fightsBeforeBundles.indexOf(+mode) > -1) {
                continue;
            }
            fights += fightCounters[mode];
        }
        return fights;
    };
    BundlesUtils.getBundlePartsExtractSlides = function () {
        return getShuffledBundleSlides();
    };
    return BundlesUtils;
}());
