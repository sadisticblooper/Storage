var DailyConstants = (function () {
    function DailyConstants() {
    }
    DailyConstants.getAllRewards = function () {
        return DailyConstants.cycles;
    };
    DailyConstants.getRelativeDayAndCycleNumber = function (day) {
        var cycle = 0;
        for (var _i = 0, _a = DailyConstants.cycles; _i < _a.length; _i++) {
            var period = _a[_i];
            if (day > period.length) {
                day -= period.length;
                cycle++;
            }
            else {
                break;
            }
        }
        cycle = Math.min(cycle, DailyConstants.cycles.length - 1);
        day = day % DailyConstants.cycles[cycle].length;
        day = day ? day : DailyConstants.cycles[cycle].length;
        return { CycleOrderNumber: cycle, Day: day };
    };
    DailyConstants.createDRSettings = function (settings) {
        var result = {};
        var cardsGenerated = false;
        var totalCards = 0;
        result.lootSettings = {};
        result.chests = [];
        function createEmptyRarity() {
            if (!result.lootSettings.CardsSlots) {
                result.lootSettings.CardsSlots = { TotalCards: 2, TotalSlots: 1, Rarities: {} };
            }
        }
        if (settings.C_Cards) {
            cardsGenerated = true;
            createEmptyRarity();
            totalCards += settings.C_Cards;
            result.lootSettings.CardsSlots.Rarities[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: settings.C_Cards }] };
        }
        if (settings.R_Cards) {
            cardsGenerated = true;
            createEmptyRarity();
            totalCards += settings.R_Cards;
            result.lootSettings.CardsSlots.Rarities[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: settings.R_Cards }] };
        }
        if (settings.E_Cards) {
            cardsGenerated = true;
            createEmptyRarity();
            totalCards += settings.E_Cards;
            result.lootSettings.CardsSlots.Rarities[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: settings.E_Cards }] };
        }
        if (cardsGenerated)
            result.lootSettings.CardsSlots.TotalCards = totalCards;
        if (settings.C_Chests) {
            for (var i = 0; i < settings.C_Chests; i++) {
                result.chests.push(chests.Common_chest.ID);
            }
        }
        if (settings.R_Chests) {
            for (var i = 0; i < settings.R_Chests; i++) {
                result.chests.push(chests.Rare_chest.ID);
            }
        }
        if (settings.E_Chests) {
            for (var i = 0; i < settings.E_Chests; i++) {
                result.chests.push(chests.Epic_chest.ID);
            }
        }
        if (settings.Gold) {
            if (!result.lootSettings.CurrencySlots) {
                result.lootSettings.CurrencySlots = {};
            }
            result.lootSettings.CurrencySlots[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(settings.Gold) }];
        }
        if (settings.Bonus) {
            if (!result.lootSettings.CurrencySlots) {
                result.lootSettings.CurrencySlots = {};
            }
            result.lootSettings.CurrencySlots[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(settings.Bonus) }];
        }
        return result;
    };
    DailyConstants.generateDailyReward = function (settings) {
        RandomInstance.setSeed(settings.Seed);
        var Day = settings.Day, AccountLevel = settings.AccountLevel;
        var playerProgress = PlayerState.getCorrectFromRawOrCache({
            accountLevel: settings.AccountLevel,
            accountExp: 0,
            playerArenaId: 0,
            maxPlayerArenaId: 0,
            playerRating: 0,
            maxPlayerRating: 0,
            lastSeasonRating: 0,
            currencies: {},
            heroes: settings.HeroesInfo,
            heroShards: {},
            skins: [],
            taunts: [],
            emoji: [],
            stances: [],
            weapons: [],
            tutorialPassed: undefined,
        });
        var targetIndex = DailyConstants.getRelativeDayAndCycleNumber(Day);
        var targetContent = DailyConstants.cycles[targetIndex.CycleOrderNumber][targetIndex.Day - 1];
        var lootGenerator = LootGeneratorBuilder.getCommonLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(settings.StartTimeOfCurrentDayMS);
        var rewardResult = lootGenerator.getRewardFromRewardContent(targetContent, RandomInstance);
        return {
            Loot: rewardResult.Loot.isEmpty() ? null : rewardResult.Loot,
            Chests: rewardResult.Chests,
            NewSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER())
        };
    };
    DailyConstants.generateDailyRewardPerDays = function (settings) {
        var start = Math.min(settings.DayStart, settings.DayEnd);
        var end = Math.max(settings.DayStart, settings.DayEnd);
        var AccountLevel = settings.AccountLevel, HeroesInfo = settings.HeroesInfo, Seed = settings.Seed, StartTimeOfCurrentDayMS = settings.StartTimeOfCurrentDayMS;
        var result = [];
        for (var day = start; day <= end; day++) {
            result.push(DailyConstants.generateDailyReward({
                Day: day,
                AccountLevel: AccountLevel,
                HeroesInfo: HeroesInfo,
                Seed: Seed,
                StartTimeOfCurrentDayMS: StartTimeOfCurrentDayMS,
            }));
        }
        return result;
    };
    DailyConstants.getDailyRewardFinalItem = function (settings) {
        var targetIndex = DailyConstants.getRelativeDayAndCycleNumber(settings.Day);
        var cycle = DailyConstants.cycles[targetIndex.CycleOrderNumber];
        var item = cycle[cycle.length - 1];
        var result = {
            FinalType: DAILY_REWARD_FINAL_TYPE.HERO,
            ID: heroes.Ling.ID,
        };
        if (item.loot && !item.loot.isEmpty()) {
            var cardIds = Object.keys(item.loot.HeroExp).sort(function (a, b) { return Number(a) - Number(b); });
            var shardIds = Object.keys(item.loot.Shards).sort(function (a, b) { return Number(a) - Number(b); });
            if (cardIds.length || shardIds.length) {
                var heroId = Number(cardIds.length ? cardIds[0] : shardIds[0]);
                result.FinalType = DAILY_REWARD_FINAL_TYPE.HERO;
                result.ID = heroId;
            }
        }
        else if (item.chests && item.chests.length) {
            result.FinalType = DAILY_REWARD_FINAL_TYPE.CHEST;
            result.ID = item.chests[0];
        }
        return result;
    };
    DailyConstants.getCycleSize = function (settings) {
        var cycleIndex = Math.min(settings.CycleOrderNumber, DailyConstants.cycles.length - 1);
        return DailyConstants.cycles[cycleIndex].length;
    };
    DailyConstants.isGuaranteedDailyReward = function (day) {
        var targetIndex = DailyConstants.getRelativeDayAndCycleNumber(day);
        var targetContent = DailyConstants.cycles[targetIndex.CycleOrderNumber][targetIndex.Day - 1];
        return !!targetContent.isGuaranteed;
    };
    DailyConstants.dailySchedule = {
        Origin: "2016-01-01T03:00:00+03",
        Period: new Time({ Hours: 24 }).value,
    };
    DailyConstants.firstMonthDailyOrder = [
        DailyConstants.createDRSettings({ Gold: 300 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ C_Cards: 30 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ Gold: 500 }),
        DailyConstants.createDRSettings({ Bonus: 15 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ C_Cards: 30 }),
        DailyConstants.createDRSettings({ Bonus: 30 }),
        DailyConstants.createDRSettings({ C_Chests: 1 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ Gold: 450 }),
        DailyConstants.createDRSettings({ Bonus: 25 }),
        DailyConstants.createDRSettings({ R_Cards: 5 }),
        DailyConstants.createDRSettings({ C_Cards: 20 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ C_Chests: 1 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ R_Cards: 3 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ Gold: 450 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ E_Cards: 1 }),
        DailyConstants.createDRSettings({ Bonus: 15 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ R_Cards: 3 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ E_Chests: 1 }),
    ];
    DailyConstants.dailyOrder = [
        DailyConstants.createDRSettings({ Gold: 300 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ C_Cards: 30 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ Gold: 500 }),
        DailyConstants.createDRSettings({ Bonus: 15 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ C_Cards: 30 }),
        DailyConstants.createDRSettings({ Bonus: 30 }),
        DailyConstants.createDRSettings({ C_Chests: 1 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ Gold: 450 }),
        DailyConstants.createDRSettings({ Bonus: 25 }),
        DailyConstants.createDRSettings({ R_Cards: 5 }),
        DailyConstants.createDRSettings({ C_Cards: 20 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ C_Chests: 1 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ R_Cards: 3 }),
        DailyConstants.createDRSettings({ Bonus: 20 }),
        DailyConstants.createDRSettings({ Gold: 450 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ E_Cards: 1 }),
        DailyConstants.createDRSettings({ Bonus: 15 }),
        DailyConstants.createDRSettings({ Gold: 350 }),
        DailyConstants.createDRSettings({ R_Cards: 3 }),
        DailyConstants.createDRSettings({ R_Chests: 1 }),
        DailyConstants.createDRSettings({ E_Chests: 1 }),
    ];
    DailyConstants.dailyRewardDaysInCycle = DailyConstants.dailyOrder.length;
    DailyConstants.cycles = [
        DailyConstants.firstMonthDailyOrder,
        DailyConstants.dailyOrder,
    ];
    return DailyConstants;
}());
