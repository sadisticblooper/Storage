function generateDailyReward(settings) {
    return DailyConstants.generateDailyReward(settings);
}
function generateDailyRewardPerDays(settings) {
    return DailyConstants.generateDailyRewardPerDays(settings);
}
function getDailyRewardFinalItem(settings) {
    return DailyConstants.getDailyRewardFinalItem(settings);
}
function getCycleSize(settings) {
    return DailyConstants.getCycleSize(settings);
}
function isGuaranteedDailyReward(day) {
    return DailyConstants.isGuaranteedDailyReward(day);
}
