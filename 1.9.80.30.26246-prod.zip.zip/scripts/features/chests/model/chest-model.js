var Chest = (function () {
    function Chest(js) {
        this.originalSettings = js;
        this.id = js.ID;
        this.alias = js.Alias;
        this.aliasShort = js.AliasShort;
        this.type = getValueByKeyDefault(js, "Type", CHEST_TYPE.COMMON);
        this.icon = js.Icon;
        this.loot_settings = js.LootSettings;
        this.rounds_to_unlock = js.RoundsToUnlock;
        this.time_to_unlock = getValueByKeyDefault(js, "TimeToUnlock", ChestsConstants.chestPeriod);
        this.popupShow = getValueByKeyDefault(js, "PopupShow", false);
        this.showFixLootChances = getValueByKeyDefault(js, "ShowFixLootChances", true);
        this.showFixLootSettings = getValueByKeyDefault(js, "ShowFixLootSettings", {});
        this.showRubiesChances = getValueByKeyDefault(js, "ShowRubiesChances", false);
        this.showCommonCardsChances = getValueByKeyDefault(js, "ShowCommonCardsChances", false);
        this.useAdvertising = getValueByKeyDefault(js, "UseAdvertising", false);
        this.EffectName = getValueByKeyDefault(js, "EffectName", CHEST_TYPE[this.type]);
        this.ShowArenaInTooltip = getValueByKeyDefault(js, "ShowArenaInTooltip", true);
        this.ShowTooltip = getValueByKeyDefault(js, "ShowTooltip", true);
        this.shardsGeneratingMode = getValueByKeyDefault(js, "ShardsGeneratingMode", null);
        this.repeatCustomizationWhileGenerating
            = getValueByKeyDefault(js, "RepeatCustomizationWhileGenerating", false);
        this.tooltipProbabilitySettings = getValueByKeyDefault(js, "TooltipProbabilitySettings", null);
        this.shardsModeDistribution = getValueByKeyDefault(js, "ShardsModeDistribution", null);
        this.ignoreLowerRatingOfIssueWeapon = getValueByKeyDefault(js, "IgnoreLowerRatingOfIssueWeapon", false);
    }
    Object.defineProperty(Chest.prototype, "ID", {
        get: function () {
            return this.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "UseAdvertising", {
        get: function () {
            return this.useAdvertising;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "Alias", {
        get: function () {
            return this.alias;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "AliasShort", {
        get: function () {
            return this.aliasShort;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "Type", {
        get: function () {
            return this.type;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "Icon", {
        get: function () {
            return this.icon;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "RoundsToUnlock", {
        get: function () {
            return this.rounds_to_unlock;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Chest.prototype, "TimeToUnlock", {
        get: function () {
            return this.time_to_unlock;
        },
        enumerable: false,
        configurable: true
    });
    Chest.prototype.setShowFixLootChances = function (value) {
        this.showFixLootChances = value;
    };
    Chest.prototype.setShowCommonCardsChances = function (value) {
        this.showCommonCardsChances = value;
    };
    Chest.prototype.setShowRubiesChances = function (value) {
        this.showRubiesChances = value;
    };
    Chest.prototype.canRepeatCustomization = function () {
        return this.repeatCustomizationWhileGenerating;
    };
    Chest.prototype.setLootSettings = function (lootSettings) {
        this.loot_settings = lootSettings;
    };
    Chest.prototype.hasSettingsForWeapons = function (lootSettings) {
        var pseudoRandomElements = PseudorandomSettings.settings[this.ID] && PseudorandomSettings.settings[this.ID].queue;
        if (pseudoRandomElements) {
            for (var _i = 0, _a = [PSRND_ITEM.COMMON_WEAPON, PSRND_ITEM.RARE_WEAPON, PSRND_ITEM.EPIC_WEAPON,]; _i < _a.length; _i++) {
                var type = _a[_i];
                if (pseudoRandomElements.indexOf(type) > -1) {
                    return true;
                }
            }
        }
        return lootSettings.Weapons != undefined;
    };
    Chest.prototype.getLootSettingsFromPlayerProgress = function (playerProgress, tryPsd) {
        if (tryPsd === void 0) { tryPsd = false; }
        var dan = playerProgress.playerArenaId;
        var lootSettings = this.loot_settings[dan];
        if (!lootSettings) {
            throw "getLootSettingsFromDan exception illegal dan " + dan + " for chest with ID " + this.ID;
        }
        var isEmpty = lootSettings && Object.keys(lootSettings).length == 0;
        if (tryPsd && isEmpty) {
            var psdLootSettings = CustomizationUtils.getLootSettingsForChestInPseudoRandom(this);
            if (psdLootSettings) {
                return psdLootSettings;
            }
        }
        lootSettings = ChestUtils.changeSettingsByWeaponsForOpeningFeature(lootSettings, playerProgress, this.ID);
        return lootSettings;
    };
    Chest.prototype.getChestInfo = function (playerProgress, serverTime) {
        var result = {
            Total: 0,
            GuaranteedTitleAlias: ChestsConstants.defaultTooltipSettings.guaranteedTitleAlias,
            Currencies: {},
            Rarities: {},
            PossibleDropTitleAlias: ChestsConstants.defaultTooltipSettings.possibleDropTitleAlias,
            PossibleDropItemsAliases: [],
            IconPaths: [],
            ProbabilityModels: [],
        };
        var lootSettings = this.getLootSettingsFromPlayerProgress(playerProgress);
        var restrictedList = RestrictedList.getDefault();
        RestrictedList.extendByBlockedByTime(restrictedList, serverTime);
        var availableHeroes = HeroUtils.getAvailableSeparatedHeroes(playerProgress, restrictedList);
        var pseudoRandomTooltip = PseudorandomSettings.settings[this.ID] && PseudorandomSettings.settings[this.ID].tooltipProbabilities;
        var canUsePseudorandomForTooltip = this.canUsePseudorandomForTooltip();
        var probabilityModelsChances = {};
        var types = this.getTooltipProbabilityTypes();
        var guaranteeTypes = [];
        if (pseudoRandomTooltip && canUsePseudorandomForTooltip) {
            for (var _i = 0, types_1 = types; _i < types_1.length; _i++) {
                var type = types_1[_i];
                if (pseudoRandomTooltip[type] != undefined) {
                    var data = ChestUtils.getTooltipDataFromPseudorandom({
                        type: type,
                        lootSettings: lootSettings,
                        rarityProbabilities: pseudoRandomTooltip[type],
                        chestId: this.ID,
                        playerProgress: playerProgress,
                        availableHeroes: availableHeroes,
                    });
                    if (PseudorandomUtils.isGuaranteeType(type, this.ID)) {
                        guaranteeTypes.push(type);
                    }
                    if (data.itemChances) {
                        probabilityModelsChances[type] = data.itemChances;
                    }
                }
            }
        }
        if (lootSettings) {
            ChestUtils.setChestInfoFromLootSettings({
                availableHeroes: availableHeroes,
                chest: this,
                lootSettings: lootSettings,
                playerProgress: playerProgress,
                probabilityModelsChances: probabilityModelsChances,
                resultTooltip: result,
                serverTime: serverTime,
            });
        }
        var useGuaranteeAlias = true;
        var itemsOrder = ChestsConstants.defaultTooltipSettings.tooltipItemProbabilitySettingsOrder;
        for (var _a = 0, itemsOrder_1 = itemsOrder; _a < itemsOrder_1.length; _a++) {
            var typeItem = itemsOrder_1[_a];
            if (probabilityModelsChances[typeItem.type] == undefined) {
                continue;
            }
            var chances = probabilityModelsChances[typeItem.type];
            var models = [];
            var icon = typeItem.icon;
            var aliasDrop = typeItem.aliasDrop;
            var guaranteeType = false;
            var raritiesOrder = typeItem.rarities;
            if (aliasDrop) {
                for (var _b = 0, aliasDrop_1 = aliasDrop; _b < aliasDrop_1.length; _b++) {
                    var alias = aliasDrop_1[_b];
                    if (result.PossibleDropItemsAliases.indexOf(alias) == -1) {
                        result.PossibleDropItemsAliases.push(alias);
                    }
                }
            }
            if (icon && result.IconPaths.indexOf(icon) == -1) {
                result.IconPaths.push(icon);
            }
            for (var _c = 0, raritiesOrder_1 = raritiesOrder; _c < raritiesOrder_1.length; _c++) {
                var rarityItem = raritiesOrder_1[_c];
                if (chances[rarityItem.rarity] == undefined) {
                    continue;
                }
                var chanceNumber = +chances[rarityItem.rarity];
                models.push({ chance: chances[rarityItem.rarity], color: rarityItem.color, alias: rarityItem.alias });
                if (chanceNumber >= 100 || guaranteeTypes.indexOf(typeItem.type) > -1) {
                    guaranteeType = true;
                }
            }
            var unGuaranteeDrop = aliasDrop && !guaranteeType;
            var forceGuarantee = this.tooltipProbabilitySettings && this.tooltipProbabilitySettings.forceGuaranteeAlias;
            if (unGuaranteeDrop && !forceGuarantee) {
                useGuaranteeAlias = false;
            }
            if (models.length > 0) {
                result.ProbabilityModels.push(models);
            }
        }
        if (useGuaranteeAlias && result.PossibleDropItemsAliases.length > 0) {
            result.PossibleDropTitleAlias = ChestsConstants.defaultTooltipSettings.guaranteeDropTitleAlias;
        }
        if (result.ProbabilityModels.length == 0) {
            result.ProbabilityModels = [
                [
                    { chance: "50", color: ChestsConstants.tooltipProbabilityColors.common, alias: "common_cards_tooltip" }
                ]
            ];
        }
        return result;
    };
    Chest.prototype.getFilteredFixedLootForTooltip = function (loot) {
        if (!this.showFixLootSettings) {
            return loot;
        }
        var result = new Loot();
        result.combineLoot(loot);
        if (this.showFixLootSettings.heroCards) {
            var allowIds = this.showFixLootSettings.heroCards;
            var ids = Object.keys(loot.HeroExp);
            for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                var id = ids_1[_i];
                var heroId = Number(id);
                if (allowIds.indexOf(heroId) == -1) {
                    result.removeHeroExp(heroId);
                }
            }
        }
        if (this.showFixLootSettings.heroShards) {
            var allowIds = this.showFixLootSettings.heroShards;
            var ids = Object.keys(loot.Shards);
            for (var _a = 0, ids_2 = ids; _a < ids_2.length; _a++) {
                var id = ids_2[_a];
                var heroId = Number(id);
                if (allowIds.indexOf(heroId) == -1) {
                    result.removeShards(heroId);
                }
            }
        }
        if (this.showFixLootSettings.weapons) {
            var allowIds = this.showFixLootSettings.weapons;
            var ids = loot.Weapons;
            for (var _b = 0, ids_3 = ids; _b < ids_3.length; _b++) {
                var weaponId = ids_3[_b];
                if (allowIds.indexOf(weaponId) == -1) {
                    result.removeWeapon(weaponId);
                }
            }
        }
        return result;
    };
    Chest.prototype.getTooltipDataOrigin = function () {
        return (this.tooltipProbabilitySettings && this.tooltipProbabilitySettings.dataOrigin)
            || ChestsConstants.defaultTooltipSettings.dataOrigin;
    };
    Chest.prototype.getTooltipProbabilityTypes = function () {
        return (this.tooltipProbabilitySettings && this.tooltipProbabilitySettings.items)
            || ChestsConstants.defaultTooltipSettings.items;
    };
    Chest.prototype.canUseLootSettingsForTooltip = function () {
        return this.getLootSettingsDataTypes().indexOf(this.getTooltipDataOrigin()) > -1;
    };
    Chest.prototype.canUsePseudorandomForTooltip = function () {
        return this.getPseudorandomDataTypes().indexOf(this.getTooltipDataOrigin()) > -1;
    };
    Chest.prototype.canUsePseudorandomForPopup = function () {
        if (this.tooltipProbabilitySettings && this.tooltipProbabilitySettings.dataOrigin) {
            if (this.tooltipProbabilitySettings.dataInPopupSource) {
                return this.getPseudorandomDataTypes().indexOf(this.tooltipProbabilitySettings.dataInPopupSource) > -1;
            }
            else {
                return this.getPseudorandomDataTypes().indexOf(this.getTooltipDataOrigin()) > -1;
            }
        }
        return false;
    };
    Chest.prototype.getPseudorandomDataTypes = function () {
        return [
            CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
            CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.MIXED
        ];
    };
    Chest.prototype.getLootSettingsDataTypes = function () {
        return [
            CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.MIXED
        ];
    };
    Chest.prototype.getOriginalSettings = function () {
        return this.originalSettings;
    };
    return Chest;
}());
