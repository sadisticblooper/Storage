var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var ChestUtils = (function () {
    function ChestUtils() {
    }
    ChestUtils.changeSettingsByWeaponsForOpeningFeature = function (lootSettings, playerProgress, chestId) {
        var playerRating = playerProgress.maxPlayerRating;
        var lowerRatingOfIssueWeapon = WeaponConstants.lowerRatingOfIssueWeapon;
        var chest = chestsMap.checkedGet(chestId);
        if (chest.hasSettingsForWeapons(lootSettings)) {
            var blockedWeaponsDrop = playerRating < lowerRatingOfIssueWeapon && !chest.ignoreLowerRatingOfIssueWeapon;
            if (blockedWeaponsDrop) {
                if (lootSettings.Weapons) {
                    lootSettings = __assign(__assign({}, lootSettings), { Weapons: null });
                }
            }
            else {
                var defaultSettings = WeaponConstants.weaponSettingsAfterOpeningFeature;
                if (defaultSettings) {
                    var availableIds = LootUtils.getAvailableCustomizationsForGenerating({
                        playerProgress: playerProgress,
                        playerIds: playerProgress.weapons,
                        availableList: HeroWeaponUtils.getAvailableIdsRandomGenerating({
                            chestId: chestId,
                        }),
                        customizationMap: weaponsMap,
                        customizationSettings: defaultSettings,
                        canRepeatCustomization: chest.canRepeatCustomization(),
                        customizationType: CUSTOMIZATION.WEAPON,
                    });
                    if (availableIds.length > 0) {
                        lootSettings = __assign(__assign({}, lootSettings), { Weapons: defaultSettings });
                    }
                }
            }
        }
        return lootSettings;
    };
    ChestUtils.getCustomizationDataForTooltip = function (settings) {
        var chestId = settings.chestId, type = settings.type, playerProgress = settings.playerProgress, lootSettings = settings.lootSettings, rarityProbabilities = settings.rarityProbabilities;
        var customizationType = CustomizationUtils.getCustomizationTypeByChestTooltipType(type);
        var resultChances = {};
        if (type == CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS) {
            return ChestUtils.getAnimationDataForTooltip(settings);
        }
        if (lootSettings == undefined || customizationType == undefined) {
            return { itemChances: null };
        }
        var customizationLootSettings = CustomizationUtils.getGeneratorLootSettingsContainer(customizationType, lootSettings);
        var specify = { chestId: chestId };
        var iteratorSettings = {
            randomSettings: customizationLootSettings || (rarityProbabilities && { Rarities: rarityProbabilities }),
            orderMap: CustomizationUtils.getOrderMap(customizationType),
            availableList: CustomizationUtils.getAvailableIdsForRandomGeneratingByChestTooltipType(type, specify),
            playerIds: CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress),
        };
        if (iteratorSettings.randomSettings == null) {
            return { itemChances: null };
        }
        var raritySettings = iteratorSettings.randomSettings.Rarities;
        var idSettings = iteratorSettings.randomSettings.Ids;
        if (!idSettings && !raritySettings) {
            return { itemChances: null };
        }
        var chest = chestsMap.checkedGet(chestId);
        var availableIds = LootUtils.getAvailableCustomizationsForGenerating({
            customizationSettings: iteratorSettings.randomSettings,
            customizationMap: iteratorSettings.orderMap,
            availableList: iteratorSettings.availableList,
            playerIds: iteratorSettings.playerIds,
            playerProgress: playerProgress,
            canRepeatCustomization: chest.canRepeatCustomization(),
            customizationType: customizationType,
        });
        if (availableIds.length > 0) {
            var probabilities = {};
            if (raritySettings) {
                var separatedByRarity = LootUtils.getSeparatedCustomizationsByRarity({
                    availableIds: availableIds,
                    customizationMap: iteratorSettings.orderMap,
                });
                if (separatedByRarity) {
                    for (var rarityNumber in raritySettings) {
                        if (separatedByRarity[rarityNumber] && separatedByRarity[rarityNumber].length) {
                            probabilities[rarityNumber] = raritySettings[rarityNumber];
                        }
                    }
                }
            }
            if (idSettings) {
                for (var id in idSettings) {
                    if (idSettings[id] && availableIds.indexOf(+id) > -1) {
                        var weapon = iteratorSettings.orderMap.checkedGet(id);
                        if (probabilities[weapon.rarity] == undefined) {
                            probabilities[weapon.rarity] = 0;
                        }
                        probabilities[weapon.rarity] += idSettings[id];
                    }
                }
            }
            for (var rarityNumber in probabilities) {
                var value = Math.min(1, probabilities[rarityNumber]);
                var percents = CommonUtils.roundNumber(100 * value, ChestsConstants.chestTooltipDecimalPlaces);
                if (percents) {
                    resultChances[rarityNumber]
                        = percents.toFixed(ChestsConstants.chestTooltipDecimalPlaces);
                }
            }
        }
        if (Object.keys(resultChances).length == 0) {
            return { itemChances: null };
        }
        return { itemChances: resultChances };
    };
    ChestUtils.getAnimationDataForTooltip = function (settings) {
        var chestId = settings.chestId, type = settings.type, playerProgress = settings.playerProgress, lootSettings = settings.lootSettings, rarityProbabilities = settings.rarityProbabilities;
        var resultChances = {};
        var emptyResult = { itemChances: null };
        if (type != CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS || lootSettings == undefined) {
            return emptyResult;
        }
        var tauntsSettings = lootSettings.Taunts || (rarityProbabilities && { Rarities: rarityProbabilities });
        var stancesSettings = lootSettings.Stances || (rarityProbabilities && { Rarities: rarityProbabilities });
        if (!tauntsSettings && !stancesSettings) {
            return emptyResult;
        }
        var chest = chestsMap.checkedGet(chestId);
        var availableTaunts = LootUtils.getAvailableCustomizationsForGenerating({
            customizationSettings: tauntsSettings,
            customizationMap: tauntsMap,
            availableList: TauntConstants.availableTauntsForRandomGeneration,
            playerIds: playerProgress.taunts,
            playerProgress: playerProgress,
            canRepeatCustomization: false,
            customizationType: CUSTOMIZATION.TAUNT,
        });
        var availableStances = LootUtils.getAvailableCustomizationsForGenerating({
            customizationSettings: stancesSettings,
            customizationMap: stancesMap,
            availableList: StanceUtils.getAvailableIdsRandomGenerating(),
            playerIds: playerProgress.stances,
            playerProgress: playerProgress,
            canRepeatCustomization: false,
            customizationType: CUSTOMIZATION.STANCE,
        });
        var doRepeat = (availableStances.length + availableTaunts.length) == 0;
        if (!chest.canRepeatCustomization() && doRepeat) {
            return emptyResult;
        }
        var probabilities = {};
        var customisations = [];
        if (doRepeat || availableStances.length > 0) {
            customisations.push({
                customizationSettings: stancesSettings,
                customizationMap: stancesMap,
                availableList: StanceUtils.getAvailableIdsRandomGenerating(),
                playerIds: playerProgress.stances,
                playerProgress: playerProgress,
                canRepeatCustomization: doRepeat,
                customizationType: CUSTOMIZATION.STANCE,
            });
        }
        if (doRepeat || availableTaunts.length > 0) {
            customisations.push({
                customizationSettings: tauntsSettings,
                customizationMap: tauntsMap,
                availableList: TauntConstants.availableTauntsForRandomGeneration,
                playerIds: playerProgress.taunts,
                playerProgress: playerProgress,
                canRepeatCustomization: doRepeat,
                customizationType: CUSTOMIZATION.TAUNT,
            });
        }
        for (var _i = 0, customisations_1 = customisations; _i < customisations_1.length; _i++) {
            var iteration = customisations_1[_i];
            var customizationSettings = iteration.customizationSettings, customizationMap = iteration.customizationMap, availableList = iteration.availableList, playerIds = iteration.playerIds, canRepeatCustomization = iteration.canRepeatCustomization;
            var raritySettings = customizationSettings.Rarities;
            var idSettings = customizationSettings.Ids;
            if (!idSettings && !raritySettings) {
                continue;
            }
            var availableIds = LootUtils.getAvailableCustomizationsForGenerating({
                customizationSettings: customizationSettings,
                customizationMap: customizationMap,
                availableList: availableList,
                playerIds: playerIds,
                playerProgress: playerProgress,
                canRepeatCustomization: canRepeatCustomization,
                customizationType: iteration.customizationType,
            });
            if (availableIds.length > 0) {
                if (raritySettings) {
                    var separatedByRarity = LootUtils.getSeparatedCustomizationsByRarity({
                        availableIds: availableIds,
                        customizationMap: customizationMap,
                    });
                    if (separatedByRarity) {
                        for (var rarityNumber in raritySettings) {
                            if (separatedByRarity[rarityNumber]
                                && separatedByRarity[rarityNumber].length > 0
                                && probabilities[rarityNumber] == undefined) {
                                probabilities[rarityNumber] = raritySettings[rarityNumber];
                            }
                        }
                    }
                }
                if (idSettings) {
                    for (var id in idSettings) {
                        if (idSettings[id] && availableIds.indexOf(+id) > -1) {
                            var customisation = customizationMap.checkedGet(id);
                            if (probabilities[customisation.rarity] == undefined) {
                                probabilities[customisation.rarity] = 0;
                            }
                            probabilities[customisation.rarity] += idSettings[id];
                        }
                    }
                }
            }
        }
        for (var rarityNumber in probabilities) {
            var value = Math.min(1, probabilities[rarityNumber]);
            var percents = CommonUtils.roundNumber(100 * value, ChestsConstants.chestTooltipDecimalPlaces);
            if (percents) {
                resultChances[rarityNumber]
                    = percents.toFixed(ChestsConstants.chestTooltipDecimalPlaces);
            }
        }
        if (Object.keys(resultChances).length == 0) {
            return emptyResult;
        }
        return { itemChances: resultChances };
    };
    ChestUtils.getHeroesDataForTooltip = function (settings) {
        var availableInfo = settings.availableInfo, heroRarities = settings.heroRarities, type = settings.type;
        var result = {};
        var availableHeroes = availableInfo.available;
        for (var rarityNumber in heroRarities) {
            if (availableHeroes[rarityNumber]) {
                var ids = type == CHEST_TOOLTIP_PROBABILITY_TYPE.CARDS
                    ? availableHeroes[rarityNumber].cards
                    : availableHeroes[rarityNumber].shards;
                if (ids.length == 0) {
                    continue;
                }
                var percents = CommonUtils
                    .roundNumber(100 * heroRarities[rarityNumber], ChestsConstants.chestTooltipDecimalPlaces);
                if (percents) {
                    result[rarityNumber] = percents.toFixed(ChestsConstants.chestTooltipDecimalPlaces);
                }
            }
        }
        if (Object.keys(result).length == 0) {
            return { itemChances: null };
        }
        return { itemChances: result };
    };
    ChestUtils.getMergedWeaponSettings = function (set1, set2) {
        var result = {};
        if (!set1 && !set2) {
            return null;
        }
        var s1 = set1 || {};
        var s2 = set2 || {};
        if (s1.HeroFilter || s2.HeroFilter) {
            result.HeroFilter = true;
        }
        if (s1.ExcludeList || s2.ExcludeList) {
            result.ExcludeList = [];
            if (s1.ExcludeList) {
                result.ExcludeList = result.ExcludeList.concat(s1.ExcludeList);
            }
            if (s2.ExcludeList) {
                result.ExcludeList = result.ExcludeList.concat(s2.ExcludeList);
            }
        }
        if (s1.Rarities || s2.Rarities) {
            result.Rarities = {};
            if (s1.Rarities) {
                for (var rarityNumber in s1.Rarities) {
                    result.Rarities[rarityNumber] = s1.Rarities[rarityNumber];
                }
            }
            if (s2.Rarities) {
                for (var rarityNumber in s2.Rarities) {
                    if (result.Rarities[rarityNumber]) {
                        result.Rarities[rarityNumber] = (result.Rarities[rarityNumber] + s2.Rarities[rarityNumber]) / 2;
                    }
                    else {
                        result.Rarities[rarityNumber] = s2.Rarities[rarityNumber];
                    }
                }
            }
        }
        if (s1.Ids || s2.Ids) {
            result.Ids = {};
            if (s1.Ids) {
                for (var id in s1.Ids) {
                    result.Ids[id] = s1.Ids[id];
                }
            }
            if (s2.Ids) {
                for (var id in s2.Ids) {
                    if (result.Ids[id]) {
                        result.Ids[id] = (result.Ids[id] + s2.Ids[id]) / 2;
                    }
                    else {
                        result.Ids[id] = s2.Ids[id];
                    }
                }
            }
        }
        return result;
    };
    ChestUtils.getChestsVisualSettingsMany = function () {
        return ChestPopupVisual.rarities;
    };
    ChestUtils.getChestInfoByChestId = function (parameters) {
        var chest = chestsMap.get(parameters.ChestID);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(parameters.PlayerProgress, { heroShards: parameters.HeroShards, playerArenaId: parameters.ArenaId });
        ChestUtils.setChestArenaIdInPlayerProgress(playerProgress, parameters.ChestArena || parameters.ArenaId);
        return chest.getChestInfo(playerProgress, parameters.StartTimeOfCurrentDayMS);
    };
    ChestUtils.generateLootFromChest = function (parameters) {
        RandomInstance.setSeed(parameters.Seed);
        var resultLoot = new Loot();
        var chest = chestsMap.get(parameters.ChestID);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(parameters.PlayerProgress, { heroShards: parameters.HeroShards, });
        ChestUtils.setChestArenaIdInPlayerProgress(playerProgress, parameters.ChestArena || parameters.ArenaId);
        var pseudorandomPositionsAtTime = PseudorandomUtils.getPositionsAtTimeForChest(chest.ID);
        var pseudorandomPositionGetter = new PseudorandomPositionGetter(parameters.ChestQueuePositions, parameters.Seed);
        var pseudoRandomLoot = PseudorandomUtils.getPseudoRandomLoot({
            playerProgress: playerProgress,
            chestId: chest.ID,
            positionInQueue: pseudorandomPositionGetter.getCurrentPosition(chest.ID),
            quantity: pseudorandomPositionsAtTime,
            rnd: RandomInstance,
            serverTime: parameters.StartTimeOfCurrentDayMS,
        });
        pseudorandomPositionGetter.movePosition(chest.ID, pseudorandomPositionsAtTime);
        if (pseudoRandomLoot && !pseudoRandomLoot.isEmpty()) {
            resultLoot.combineLoot(pseudoRandomLoot);
            HeroUtils.combineLoot(playerProgress, pseudoRandomLoot);
        }
        var lootGenerator = LootGeneratorBuilder.getChestLootGenerator();
        var lootSettings = chest.getLootSettingsFromPlayerProgress(playerProgress);
        var groupLootSettings = this.tryGetGroupFromLootSettings(lootSettings, RandomInstance);
        lootGenerator.setLootSettings(groupLootSettings ? groupLootSettings : lootSettings);
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(parameters.StartTimeOfCurrentDayMS);
        lootGenerator.setAdditionalSettings(new LootGeneratorAdditionalSettings({
            chestId: chest.ID,
        }));
        var loot = lootGenerator.generateLoot(RandomInstance);
        if (Object.keys(resultLoot.Shards).length > 0) {
            loot.removeAllShards();
        }
        if (resultLoot.Weapons.length > 0) {
            loot.removeAllWeapon();
        }
        resultLoot.combineLoot(loot);
        if (Advertising.isEnable(ADVERTISING_PLACE.CHEST) && chest.UseAdvertising) {
            resultLoot.setAdvertising({
                Quantity: 1,
                Place: ADVERTISING_PLACE.CHEST,
            });
        }
        return {
            Loot: resultLoot,
            NewSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
            ChestQueuePositions: pseudorandomPositionGetter.getChestQueuePositions(),
        };
    };
    ChestUtils.calcChestSkipPrice = function (parameters) {
        var result = {};
        var timeLeft = parameters.TimeLeft;
        var wholePrice = ChestsConstants.chestSkipPrice;
        var pulse = ChestsConstants.chestPriceRefreshPeriod;
        var trueTime = Math.ceil(timeLeft / pulse) * pulse;
        var part = trueTime > 0 ? trueTime / ChestsConstants.chestPeriod : 0;
        for (var key in wholePrice)
            if (wholePrice.hasOwnProperty(key)) {
                var currValue = Math.ceil(wholePrice[key] * part);
                if (currValue > 0) {
                    result[key] = Math.min(currValue, wholePrice[key]);
                }
            }
        return result;
    };
    ChestUtils.getChestsInfoAtArena = function (params) {
        var result = [], chestInfo;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(params.PlayerProgress, { heroShards: params.HeroShards, playerArenaId: params.ArenaId });
        ChestUtils.setChestArenaIdInPlayerProgress(playerProgress, params.ChestArena || params.ArenaId);
        for (var _i = 0, _a = chestsMap.getKeys(); _i < _a.length; _i++) {
            var chestId = _a[_i];
            var chest = chestsMap.checkedGet(chestId);
            if (!chest.popupShow) {
                continue;
            }
            chestInfo = chest.getChestInfo(playerProgress, params.StartTimeOfCurrentDayMS);
            result.push({
                Alias: chest.Alias,
                AliasShort: chest.AliasShort,
                ChestInfo: chestInfo,
                Icon: chest.Icon,
                ID: chestId,
                Type: chest.Type
            });
        }
        return result;
    };
    ChestUtils.setChestArenaIdInPlayerProgress = function (playerProgress, arenaId) {
        if (playerProgress && arenaId && playerProgress.playerArenaId != arenaId) {
            CommonUtils.replaceReadOnlyProperty(playerProgress, "playerArenaId", arenaId);
        }
    };
    ChestUtils.getTooltipDataFromPseudorandom = function (settings) {
        var type = settings.type, availableHeroes = settings.availableHeroes, chestId = settings.chestId, playerProgress = settings.playerProgress, rarityProbabilities = settings.rarityProbabilities, lootSettings = settings.lootSettings;
        switch (type) {
            case CHEST_TOOLTIP_PROBABILITY_TYPE.CARDS:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS:
                return ChestUtils.getHeroesDataForTooltip({
                    type: type,
                    heroRarities: rarityProbabilities,
                    availableInfo: availableHeroes,
                });
            case CHEST_TOOLTIP_PROBABILITY_TYPE.CUSTOMIZATION_SHARDS:
                return ChestUtils.getCustomizationShardsDataForTooltip({
                    type: type,
                    lootSettings: lootSettings,
                    playerProgress: playerProgress,
                    chestId: chestId,
                });
            case CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES:
            case CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE:
                return ChestUtils.getCustomizationDataForTooltip({
                    type: type,
                    lootSettings: lootSettings,
                    playerProgress: playerProgress,
                    chestId: chestId,
                    rarityProbabilities: rarityProbabilities,
                });
        }
    };
    ChestUtils.setChestInfoFromLootSettings = function (settings) {
        var lootSettings = settings.lootSettings, availableHeroes = settings.availableHeroes, resultTooltip = settings.resultTooltip, chest = settings.chest, probabilityModelsChances = settings.probabilityModelsChances, playerProgress = settings.playerProgress, serverTime = settings.serverTime;
        var canUseLootSettingsForTooltip = chest.canUseLootSettingsForTooltip();
        var types = chest.getTooltipProbabilityTypes();
        if (lootSettings.CardsSlots) {
            var correctCardsInfo = LootUtils.getCorrectedCardsSettings({
                cardsSlots: lootSettings.CardsSlots,
                availableSettings: availableHeroes,
            });
            if (correctCardsInfo) {
                var slots = correctCardsInfo;
                resultTooltip.Total = slots.TotalCards;
                for (var rarityNumberString in slots.Rarities) {
                    var raritySetting = slots.Rarities[rarityNumberString];
                    var rarityNumber = +rarityNumberString;
                    var cardsIterations = [
                        {
                            type: CHEST_TOOLTIP_PROBABILITY_TYPE.CARDS,
                            weights: raritySetting.CardsWeight,
                            skipNumbers: !chest.showCommonCardsChances && rarityNumber == HERO_RARITY.COMMON
                        },
                    ];
                    if (types.indexOf(CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS) > -1) {
                        cardsIterations.push({
                            type: CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,
                            weights: raritySetting.ShardsWeight,
                            skipNumbers: true,
                        });
                    }
                    for (var _i = 0, cardsIterations_1 = cardsIterations; _i < cardsIterations_1.length; _i++) {
                        var iteration = cardsIterations_1[_i];
                        var cardsWeight = iteration.weights;
                        if (cardsWeight != undefined) {
                            var min = CommonGameUtils.findMinimumFromWeights(cardsWeight);
                            if (min) {
                                if (iteration.skipNumbers) {
                                    continue;
                                }
                                resultTooltip.Rarities[rarityNumber] = min.toString();
                            }
                            else if (canUseLootSettingsForTooltip) {
                                var chance = CommonGameUtils.findChanceFromWeights(cardsWeight);
                                if (chance) {
                                    var percents = CommonUtils.roundNumber(100 * chance, ChestsConstants.chestTooltipDecimalPlaces);
                                    if (percents) {
                                        if (probabilityModelsChances[iteration.type] == undefined) {
                                            probabilityModelsChances[iteration.type] = {};
                                        }
                                        probabilityModelsChances[iteration.type][rarityNumber]
                                            = percents.toFixed(ChestsConstants.chestTooltipDecimalPlaces);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (lootSettings.CurrencySlots) {
            for (var currencyNumber in lootSettings.CurrencySlots) {
                if (lootSettings.CurrencySlots.hasOwnProperty(currencyNumber)) {
                    if (!chest.showRubiesChances && Number(currencyNumber) == CURRENCY.BONUS) {
                        continue;
                    }
                    resultTooltip.Currencies[currencyNumber] = { Min: Infinity, Max: -Infinity };
                    for (var _a = 0, _b = lootSettings.CurrencySlots[currencyNumber]; _a < _b.length; _a++) {
                        var chance = _b[_a];
                        resultTooltip.Currencies[currencyNumber].Max
                            = Math.max(resultTooltip.Currencies[currencyNumber].Max, chance.Amount.getMax());
                        resultTooltip.Currencies[currencyNumber].Min
                            = Math.min(resultTooltip.Currencies[currencyNumber].Min, chance.Amount.getMin());
                    }
                }
            }
        }
        if (canUseLootSettingsForTooltip) {
            for (var _c = 0, types_1 = types; _c < types_1.length; _c++) {
                var type = types_1[_c];
                var data = ChestUtils.getCustomizationDataForTooltip({
                    type: type,
                    chestId: chest.ID,
                    playerProgress: playerProgress,
                    lootSettings: lootSettings,
                    rarityProbabilities: null,
                });
                if (data.itemChances) {
                    probabilityModelsChances[type] = data.itemChances;
                }
            }
        }
        if (lootSettings.AdditionalFixedLoot && chest.showFixLootChances) {
            var lootSettingsForFixedLoot = {
                AdditionalFixedLoot: lootSettings.AdditionalFixedLoot
            };
            var lootGenerator = LootGeneratorBuilder.getChestLootGenerator();
            lootGenerator.setAdditionalSettings(new LootGeneratorAdditionalSettings({
                chestId: chest.ID,
            }));
            lootGenerator.setPlayerParams(playerProgress);
            lootGenerator.setLootSettings(lootSettingsForFixedLoot);
            lootGenerator.setServerTime(serverTime);
            var loot = lootGenerator.generateLoot(RandomInstance);
            loot = chest.getFilteredFixedLootForTooltip(loot);
            if (!loot.isEmpty()) {
                for (var hid in loot.HeroExp)
                    if (loot.HeroExp.hasOwnProperty(hid)) {
                        var hero = heroesMap.checkedGet(hid);
                        resultTooltip.Total += loot.HeroExp[hid];
                        if (!resultTooltip.Rarities[hero.Rarity]) {
                            resultTooltip.Rarities[hero.Rarity] = "0";
                        }
                        resultTooltip.Rarities[hero.Rarity]
                            = (+resultTooltip.Rarities[hero.Rarity] + loot.HeroExp[hid]).toString();
                    }
                if (canUseLootSettingsForTooltip) {
                    for (var hid in loot.Shards)
                        if (loot.Shards.hasOwnProperty(hid)) {
                            var hero = heroesMap.checkedGet(hid);
                            if (probabilityModelsChances[CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS] == undefined) {
                                probabilityModelsChances[CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS] = {};
                            }
                            probabilityModelsChances[CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS][hero.Rarity]
                                = 100..toFixed(ChestsConstants.chestTooltipDecimalPlaces);
                        }
                }
                for (var curNumber in loot.Currencies)
                    if (loot.Currencies.hasOwnProperty(curNumber)) {
                        if (Number(curNumber) == CURRENCY.BONUS && !chest.showRubiesChances) {
                            continue;
                        }
                        if (!resultTooltip.Currencies[curNumber]) {
                            resultTooltip.Currencies[curNumber] = { Min: 0, Max: 0 };
                        }
                        resultTooltip.Currencies[curNumber].Max += loot.Currencies[curNumber];
                        resultTooltip.Currencies[curNumber].Min += loot.Currencies[curNumber];
                    }
                if (canUseLootSettingsForTooltip) {
                    var customizationsOrder = CustomizationUtils.getAllCustomizationsOrder();
                    for (var _d = 0, customizationsOrder_1 = customizationsOrder; _d < customizationsOrder_1.length; _d++) {
                        var customizationType = customizationsOrder_1[_d];
                        var ids = CustomizationUtils.getLootIdsContainer(customizationType, loot);
                        var orderMap = CustomizationUtils.getOrderMap(customizationType);
                        var type = CustomizationUtils.getTypeChestTooltipTypeByCustomization(customizationType);
                        if (ids == undefined || type == undefined) {
                            continue;
                        }
                        for (var _e = 0, ids_1 = ids; _e < ids_1.length; _e++) {
                            var id = ids_1[_e];
                            var item = orderMap.checkedGet(id);
                            if (probabilityModelsChances[type] == undefined) {
                                probabilityModelsChances[type] = {};
                            }
                            probabilityModelsChances[type][item.rarity]
                                = 100..toFixed(ChestsConstants.chestTooltipDecimalPlaces);
                        }
                    }
                }
            }
        }
    };
    ChestUtils.reuseChest = function (settings) {
        var newId = settings.newId, origin = settings.origin, replace = settings.replace;
        if (newId == origin.ID) {
            throw new Error("reuseChest: id is repeated. See '".concat(newId, "' replace"));
        }
        return new Chest(__assign(__assign(__assign({}, origin.getOriginalSettings()), replace), { ID: newId }));
    };
    ChestUtils.calcChestCountersAfterFight = function (settings) {
        var _a;
        var chestsCounters = settings.chestsCounters, fightResult = settings.fightResult, matchingInfo = settings.matchingInfo, roundsWon = settings.roundsWon;
        var updatedChestsCounters = chestsCounters.map(function (chestData) { return __assign({}, chestData); });
        if (chestsCounters.length < 1) {
            return [];
        }
        var isModeAllowed = (_a = {},
            _a[FIGHT_MODE.RANKED] = true,
            _a[FIGHT_MODE.AI] = true,
            _a[FIGHT_MODE.TUTORIAL] = true,
            _a[FIGHT_MODE.TOURNAMENT] = true,
            _a[FIGHT_MODE.ROGUELIKE_COMMON] = true,
            _a[FIGHT_MODE.ROGUELIKE_SURVIVAL] = true,
            _a)[matchingInfo.mode];
        if (!isModeAllowed) {
            return updatedChestsCounters;
        }
        var isWin = fightResult == FIGHT_RESULT.WIN || fightResult == FIGHT_RESULT.TECH_WIN;
        var notRoguelike = matchingInfo.mode != FIGHT_MODE.ROGUELIKE_COMMON && matchingInfo.mode != FIGHT_MODE.ROGUELIKE_SURVIVAL;
        if (isWin && notRoguelike) {
            roundsWon = getFightConstants(matchingInfo.teamMode).maxWinRounds;
        }
        for (var _i = 0, updatedChestsCounters_1 = updatedChestsCounters; _i < updatedChestsCounters_1.length; _i++) {
            var data = updatedChestsCounters_1[_i];
            var chest = chestsMap.checkedGet(data.chestId);
            var chestCounter = data.counterValue || 0;
            var updatedCounter = CommonUtils.clamp(chestCounter + roundsWon, chestCounter, chest.RoundsToUnlock);
            var delta = updatedCounter - chestCounter;
            data.counterValue = updatedCounter;
            roundsWon -= delta;
        }
        return updatedChestsCounters;
    };
    ChestUtils.tryGetGroupFromLootSettings = function (lootSettings, rng) {
        if (lootSettings.Groups && lootSettings.Groups.length > 0) {
            var collection = new RandomCollection();
            for (var _i = 0, _a = lootSettings.Groups; _i < _a.length; _i++) {
                var group = _a[_i];
                var weight = group.Weight;
                collection.add(new CollectionObjectContainer(group, weight));
            }
            var selectedContainer = collection.next(rng);
            var selected = selectedContainer ? selectedContainer.get() : null;
            return selected;
        }
        return null;
    };
    ChestUtils.getCustomizationShardsDataForTooltip = function (args) {
        var _a, _b, _c, _d;
        var lootSettings = args.lootSettings;
        var resultChances = {};
        if (lootSettings == null) {
            return { itemChances: null };
        }
        var customizationShardsSettings = (_a = this.getCustomizationShardsFromGroups(lootSettings)) !== null && _a !== void 0 ? _a : lootSettings.CustomizationShards;
        if (customizationShardsSettings == null || customizationShardsSettings.items == null) {
            return { itemChances: null };
        }
        var items = customizationShardsSettings.items;
        if (items.length == 0) {
            return { itemChances: null };
        }
        var totalWeight = 0;
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            if ((_b = item === null || item === void 0 ? void 0 : item.params) === null || _b === void 0 ? void 0 : _b.W) {
                totalWeight += item.params.W;
            }
        }
        if (totalWeight <= 0) {
            return { itemChances: null };
        }
        for (var _e = 0, items_2 = items; _e < items_2.length; _e++) {
            var item = items_2[_e];
            var weight = (_d = (_c = item === null || item === void 0 ? void 0 : item.params) === null || _c === void 0 ? void 0 : _c.W) !== null && _d !== void 0 ? _d : 0;
            if (weight <= 0) {
                continue;
            }
            var value = weight / totalWeight;
            var percents = CommonUtils.roundNumber(100 * value, ChestsConstants.chestTooltipDecimalPlaces);
            if (percents) {
                resultChances[item.id.toString()] = percents.toFixed(ChestsConstants.chestTooltipDecimalPlaces);
            }
        }
        if (Object.keys(resultChances).length == 0) {
            return { itemChances: null };
        }
        return { itemChances: resultChances };
    };
    ChestUtils.getCustomizationShardsFromGroups = function (lootSettings) {
        if (lootSettings.Groups) {
            for (var _i = 0, _a = lootSettings.Groups; _i < _a.length; _i++) {
                var group = _a[_i];
                var value = group.CustomizationShards;
                if (value)
                    return value;
            }
        }
    };
    return ChestUtils;
}());
