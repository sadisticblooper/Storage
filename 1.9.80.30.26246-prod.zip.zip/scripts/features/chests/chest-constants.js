var _a, _b, _c, _d;
var ChestsConstants = (function () {
    function ChestsConstants() {
    }
    ChestsConstants.chestPeriod = new Time({ Hours: 3 }).value;
    ChestsConstants.playerChestStorage = 1;
    ChestsConstants.chestSkipPrice = (_a = {}, _a[CURRENCY.BONUS] = 50, _a);
    ChestsConstants.lobbyChestAdvertising = {
        enableAdvertisingSkip: true,
        skipLimit: 3,
        schedule: {
            Origin: "2016-01-01T03:00:00+03",
            Period: new Time({ Days: 1 }).value
        },
    };
    ChestsConstants.minChestPriceRefreshPeriod = new Time({ Seconds: 1 }).value;
    ChestsConstants.chestPriceRefreshPeriod = Math.floor(Math.max(ChestsConstants.chestPeriod / ChestsConstants.chestSkipPrice[CURRENCY.BONUS], ChestsConstants.minChestPriceRefreshPeriod));
    ChestsConstants.chestTooltipDecimalPlaces = 2;
    ChestsConstants.pseudorandomPositionsAtTime = 1;
    ChestsConstants.tooltipProbabilityColors = {
        common: "#97aeb8",
        rare: "#8cbaff",
        epic: "#c48cfc",
        legendary: "#ffd75e",
        season: "#ff5e76",
    };
    ChestsConstants.defaultTooltipSettings = {
        items: [
            CHEST_TOOLTIP_PROBABILITY_TYPE.CARDS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES,
            CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES,
            CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE,
            CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS,
            CHEST_TOOLTIP_PROBABILITY_TYPE.CUSTOMIZATION_SHARDS
        ],
        guaranteedTitleAlias: "chest_window_guaranteed",
        possibleDropTitleAlias: "tooltip_possibly_contains",
        guaranteeDropTitleAlias: "tournament_event_guaranteed_reward",
        dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
        tooltipItemProbabilitySettingsOrder: [
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.CARDS, icon: null, aliasDrop: null, rarities: [
                    {
                        rarity: HERO_RARITY.COMMON,
                        alias: "common_cards_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: HERO_RARITY.RARE,
                        alias: "rare_cards_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: HERO_RARITY.EPIC,
                        alias: "epic_cards_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: HERO_RARITY.LEGENDARY,
                        alias: "legendary_cards_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.legendary,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_hero_card2",
                aliasDrop: ["shards"],
                rarities: [
                    {
                        rarity: HERO_RARITY.COMMON,
                        alias: "common_shard",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: HERO_RARITY.RARE,
                        alias: "rare_shard",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: HERO_RARITY.EPIC,
                        alias: "epic_shard",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: HERO_RARITY.LEGENDARY,
                        alias: "legendary_shard",
                        color: ChestsConstants.tooltipProbabilityColors.legendary,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_weapon_card2",
                aliasDrop: ["weapon"],
                rarities: [
                    {
                        rarity: HERO_WEAPON_RARITY.COMMON,
                        alias: "common_weapon_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: HERO_WEAPON_RARITY.RARE,
                        alias: "rare_weapon_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: HERO_WEAPON_RARITY.EPIC,
                        alias: "epic_weapon_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_skin_card2",
                aliasDrop: ["skin"],
                rarities: [
                    {
                        rarity: SKIN_RARITY.COMMON,
                        alias: "Common_skin_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: SKIN_RARITY.RARE,
                        alias: "Rare_skin_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: SKIN_RARITY.EPIC,
                        alias: "Epic_skin_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: SKIN_RARITY.SEASON,
                        alias: "Season_skin_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.season,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES,
                icon: "Sprites/Assets/PossibleCardSmall/possible_customization_card2",
                aliasDrop: ["stance"],
                rarities: [
                    {
                        rarity: STANCE_RARITY.COMMON,
                        alias: "Common_stance_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: STANCE_RARITY.RARE,
                        alias: "Rare_stance_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: STANCE_RARITY.EPIC,
                        alias: "Epic_stance_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: STANCE_RARITY.SEASON,
                        alias: "Season_stance_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.season,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE,
                icon: "Sprites/Assets/PossibleCardSmall/possible_customization_card2",
                aliasDrop: ["victorypose"],
                rarities: [
                    {
                        rarity: STANCE_RARITY.COMMON,
                        alias: "Common_winpose_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: STANCE_RARITY.RARE,
                        alias: "Rare_winpose_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: STANCE_RARITY.EPIC,
                        alias: "Epic_winpose_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: STANCE_RARITY.SEASON,
                        alias: "Seasonal_winpose_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.season,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_customization_card2",
                aliasDrop: ["taunt"],
                rarities: [
                    {
                        rarity: TAUNT_RARITY.COMMON,
                        alias: "Common_taunt_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: TAUNT_RARITY.RARE,
                        alias: "Rare_taunt_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: TAUNT_RARITY.EPIC,
                        alias: "Epic_taunt_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: TAUNT_RARITY.SEASON,
                        alias: "Season_taunt_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.season,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES,
                icon: "Sprites/Assets/PossibleCardSmall/possible_emoji_card2",
                aliasDrop: ["emote"],
                rarities: [
                    { rarity: EMOJI_RARITY.ANY, alias: "emote", color: ChestsConstants.tooltipProbabilityColors.common, },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK,
                icon: "Sprites/Assets/PossibleCardSmall/possible_textemoji_card2",
                aliasDrop: ["emoji_pack"],
                rarities: [
                    {
                        rarity: TEXT_EMOJI_PACK_RARITY.COMMON,
                        alias: "common_emoji_pack",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: TEXT_EMOJI_PACK_RARITY.RARE,
                        alias: "rare_emoji_pack",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: TEXT_EMOJI_PACK_RARITY.EPIC,
                        alias: "epic_emoji_pack",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: TEXT_EMOJI_PACK_RARITY.LEGENDARY,
                        alias: "legendary_emoji_pack",
                        color: ChestsConstants.tooltipProbabilityColors.legendary,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_customization_card2",
                aliasDrop: ["stance", "victorypose", "taunt"],
                rarities: [
                    {
                        rarity: ANIMATION_RARITY.COMMON,
                        alias: "Common_animation_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.common,
                    },
                    {
                        rarity: ANIMATION_RARITY.RARE,
                        alias: "Rare_animation_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.rare,
                    },
                    {
                        rarity: ANIMATION_RARITY.EPIC,
                        alias: "Epic_animation_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.epic,
                    },
                    {
                        rarity: ANIMATION_RARITY.SEASON,
                        alias: "Season_animation_tooltip_alias",
                        color: ChestsConstants.tooltipProbabilityColors.season,
                    },
                ],
            },
            {
                type: CHEST_TOOLTIP_PROBABILITY_TYPE.CUSTOMIZATION_SHARDS,
                icon: "Sprites/Assets/PossibleCardSmall/possible_weapon_shard_card2",
                aliasDrop: ["legendary_weapon_customization_shard"],
                rarities: [
                    {
                        rarity: HERO_WEAPON_RARITY.LEGENDARY,
                        alias: "legendary_weapon_tooltip",
                        color: ChestsConstants.tooltipProbabilityColors.legendary,
                    },
                ],
            },
        ],
    };
    ChestsConstants.ratingToUnlockChestsInLobby = ArenaConstants.arenaFeatures[ARENA_FEATURE.CHEST_IN_LOBBY].rating;
    ChestsConstants.pseudorandomRarityMap = (_b = {},
        _b[PSRND_ITEM.COMMON_HERO] = HERO_RARITY.COMMON,
        _b[PSRND_ITEM.RARE_HERO] = HERO_RARITY.RARE,
        _b[PSRND_ITEM.EPIC_HERO] = HERO_RARITY.EPIC,
        _b[PSRND_ITEM.LEGENDARY_HERO] = HERO_RARITY.LEGENDARY,
        _b[PSRND_ITEM.LEGENDARY_SKIN] = SKIN_RARITY.LEGENDARY,
        _b[PSRND_ITEM.SEASON_SKIN] = SKIN_RARITY.SEASON,
        _b[PSRND_ITEM.EPIC_SKIN] = SKIN_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_SKIN] = SKIN_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_SKIN] = SKIN_RARITY.COMMON,
        _b[PSRND_ITEM.SEASON_STANCE] = STANCE_RARITY.SEASON,
        _b[PSRND_ITEM.EPIC_STANCE] = STANCE_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_STANCE] = STANCE_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_STANCE] = STANCE_RARITY.COMMON,
        _b[PSRND_ITEM.SEASON_WINPOSE] = STANCE_RARITY.SEASON,
        _b[PSRND_ITEM.EPIC_WINPOSE] = STANCE_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_WINPOSE] = STANCE_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_WINPOSE] = STANCE_RARITY.COMMON,
        _b[PSRND_ITEM.SEASON_TAUNT] = TAUNT_RARITY.SEASON,
        _b[PSRND_ITEM.EPIC_TAUNT] = TAUNT_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_TAUNT] = TAUNT_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_TAUNT] = TAUNT_RARITY.COMMON,
        _b[PSRND_ITEM.EPIC_WEAPON] = HERO_WEAPON_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_WEAPON] = HERO_WEAPON_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_WEAPON] = HERO_WEAPON_RARITY.COMMON,
        _b[PSRND_ITEM.EMOJI] = EMOJI_RARITY.ANY,
        _b[PSRND_ITEM.LEGENDARY_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.LEGENDARY,
        _b[PSRND_ITEM.EPIC_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.EPIC,
        _b[PSRND_ITEM.RARE_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.RARE,
        _b[PSRND_ITEM.COMMON_TEXT_EMOJI_PACK] = TEXT_EMOJI_PACK_RARITY.COMMON,
        _b);
    ChestsConstants.pseudorandomTypesMap = (_c = {},
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS] = [
            PSRND_ITEM.COMMON_HERO, PSRND_ITEM.RARE_HERO, PSRND_ITEM.EPIC_HERO, PSRND_ITEM.LEGENDARY_HERO,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES] = [
            PSRND_ITEM.EMOJI,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK] = [
            PSRND_ITEM.COMMON_TEXT_EMOJI_PACK, PSRND_ITEM.RARE_TEXT_EMOJI_PACK, PSRND_ITEM.EPIC_TEXT_EMOJI_PACK,
            PSRND_ITEM.LEGENDARY_TEXT_EMOJI_PACK,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS] = [
            PSRND_ITEM.LEGENDARY_SKIN, PSRND_ITEM.SEASON_SKIN, PSRND_ITEM.EPIC_SKIN, PSRND_ITEM.RARE_SKIN, PSRND_ITEM.COMMON_SKIN,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES] = [
            PSRND_ITEM.SEASON_STANCE, PSRND_ITEM.EPIC_STANCE, PSRND_ITEM.RARE_STANCE, PSRND_ITEM.COMMON_STANCE,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE] = [
            PSRND_ITEM.SEASON_WINPOSE, PSRND_ITEM.EPIC_WINPOSE, PSRND_ITEM.RARE_WINPOSE, PSRND_ITEM.COMMON_WINPOSE,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS] = [
            PSRND_ITEM.SEASON_TAUNT, PSRND_ITEM.EPIC_TAUNT, PSRND_ITEM.RARE_TAUNT, PSRND_ITEM.COMMON_TAUNT,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS] = [
            PSRND_ITEM.COMMON_WEAPON, PSRND_ITEM.RARE_WEAPON, PSRND_ITEM.EPIC_WEAPON, PSRND_ITEM.LEGENDARY_WEAPON,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS] = [
            PSRND_ITEM.COMMON_ANIMATION,
            PSRND_ITEM.RARE_ANIMATION,
            PSRND_ITEM.EPIC_ANIMATION,
            PSRND_ITEM.SEASON_ANIMATION,
        ],
        _c[CHEST_TOOLTIP_PROBABILITY_TYPE.CUSTOMIZATION_SHARDS] = [
            PSRND_ITEM.LEGENDARY_WEAPON,
        ],
        _c);
    ChestsConstants.tooltipTypeToCustomization = (_d = {},
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS] = CUSTOMIZATION.WEAPON,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS] = CUSTOMIZATION.SKIN,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.STANCES] = CUSTOMIZATION.STANCE,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.WIN_POSE] = CUSTOMIZATION.STANCE,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.TAUNTS] = CUSTOMIZATION.TAUNT,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES] = CUSTOMIZATION.EMOJI,
        _d[CHEST_TOOLTIP_PROBABILITY_TYPE.TEXT_EMOJI_PACK] = CUSTOMIZATION.TEXT_EMOJI_PACK,
        _d);
    return ChestsConstants;
}());
