var PseudorandomSettings = (function () {
    function PseudorandomSettings() {
    }
    PseudorandomSettings.calcQueueLengthForChests = function () {
        for (var id in PseudorandomSettings.settings) {
            PseudorandomSettings.settings[id].queueLength = PseudorandomSettings.settings[id].queue
                .reduce(function (sum, element) { return sum + (element < 0 ? 1 : element); }, 0);
        }
    };
    PseudorandomSettings.settings = {};
    return PseudorandomSettings;
}());
