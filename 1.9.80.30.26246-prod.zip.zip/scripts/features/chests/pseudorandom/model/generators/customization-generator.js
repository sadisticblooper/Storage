var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PseudorandomCustomizationGenerator = (function (_super) {
    __extends(PseudorandomCustomizationGenerator, _super);
    function PseudorandomCustomizationGenerator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PseudorandomCustomizationGenerator.prototype.generate = function () {
        var _a = this.settings, items = _a.items, playerProgress = _a.playerProgress;
        var result = new Loot();
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            var loot = this.generateCustomization(item);
            if (loot && !loot.isEmpty()) {
                result.combineLoot(loot);
                HeroUtils.combineLoot(playerProgress, loot);
            }
        }
        return result;
    };
    PseudorandomCustomizationGenerator.prototype.generateCustomization = function (item) {
        var _a;
        if ([PSRND_ITEM.SEASON_ANIMATION,
            PSRND_ITEM.COMMON_ANIMATION,
            PSRND_ITEM.RARE_ANIMATION,
            PSRND_ITEM.EPIC_ANIMATION,
        ].indexOf(item) > -1) {
            return this.generateAnimations(item);
        }
        var _b = this.settings, playerProgress = _b.playerProgress, rnd = _b.rnd, chestId = _b.chestId;
        var chest = chestsMap.checkedGet(chestId);
        var chestTooltipType = CustomizationUtils.getCustomizationChestTooltipTypeByPsrnd(item);
        var customizationType = CustomizationUtils.getCustomizationTypeByChestTooltipType(chestTooltipType);
        var specify = { chestId: chestId };
        var pseudorandomSettings = PseudorandomSettings.settings[chestId];
        if (chestTooltipType == null || customizationType == null) {
            return null;
        }
        var availableList = CustomizationUtils.getAvailableIdsForRandomGeneratingByChestTooltipType(chestTooltipType, specify);
        var playerIds = CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress);
        var customizationMap = CustomizationUtils.getOrderMap(customizationType);
        var chosenCustomizationSettings = {};
        var chosenCustomizationArray = CustomizationUtils.createLootSettings(customizationType, chosenCustomizationSettings);
        var rarity = ChestsConstants.pseudorandomRarityMap[item];
        var customizationSettings = {
            Rarities: (_a = {}, _a[rarity] = 1, _a),
            HeroFilter: pseudorandomSettings.isCustomizationHeroFilter
        };
        if (availableList == undefined
            || customizationMap == undefined
            || playerIds == undefined) {
            return null;
        }
        var ids = LootGenerator.generateCustomizations({
            playerProgress: playerProgress,
            playerIds: playerIds,
            availableList: availableList,
            customizationMap: customizationMap,
            customizationSettings: customizationSettings,
            canRepeatCustomization: chest.canRepeatCustomization(),
            customizationType: customizationType,
        }, rnd);
        if (ids.length == 0) {
            return null;
        }
        chosenCustomizationArray.push(ids[0]);
        return new Loot(chosenCustomizationSettings);
    };
    PseudorandomCustomizationGenerator.prototype.generateAnimations = function (item) {
        var _a, _b, _c, _d;
        var _e = this.settings, playerProgress = _e.playerProgress, rnd = _e.rnd, chestId = _e.chestId;
        var chest = chestsMap.checkedGet(chestId);
        var pseudorandomSettings = PseudorandomSettings.settings[chestId];
        var stanceRarity;
        var tauntRarity;
        switch (item) {
            case PSRND_ITEM.COMMON_ANIMATION:
                stanceRarity = STANCE_RARITY.COMMON;
                tauntRarity = TAUNT_RARITY.COMMON;
                break;
            case PSRND_ITEM.RARE_ANIMATION:
                stanceRarity = STANCE_RARITY.RARE;
                tauntRarity = TAUNT_RARITY.RARE;
                break;
            case PSRND_ITEM.EPIC_ANIMATION:
                stanceRarity = STANCE_RARITY.EPIC;
                tauntRarity = TAUNT_RARITY.EPIC;
                break;
            case PSRND_ITEM.SEASON_ANIMATION:
                stanceRarity = STANCE_RARITY.SEASON;
                tauntRarity = TAUNT_RARITY.SEASON;
                break;
            default:
                return null;
        }
        var availableTaunts = LootUtils.getAvailableCustomizationsForGenerating({
            availableList: TauntConstants.availableTauntsForRandomGeneration,
            canRepeatCustomization: false,
            customizationMap: tauntsMap,
            customizationSettings: { Rarities: (_a = {}, _a[tauntRarity] = 1, _a), HeroFilter: pseudorandomSettings.isCustomizationHeroFilter },
            playerIds: playerProgress.taunts,
            playerProgress: playerProgress,
            customizationType: CUSTOMIZATION.TAUNT
        });
        var availableStances = LootUtils.getAvailableCustomizationsForGenerating({
            availableList: StanceUtils.getAvailableIdsRandomGenerating(),
            canRepeatCustomization: false,
            customizationMap: stancesMap,
            customizationSettings: { Rarities: (_b = {}, _b[stanceRarity] = 1, _b), HeroFilter: pseudorandomSettings.isCustomizationHeroFilter },
            playerIds: playerProgress.stances,
            playerProgress: playerProgress,
            customizationType: CUSTOMIZATION.STANCE
        });
        var doRepeat = (availableTaunts.length + availableStances.length) == 0;
        if (!chest.canRepeatCustomization() && doRepeat) {
            return null;
        }
        var variants = [];
        if (doRepeat || availableTaunts.length > 0) {
            variants.push(CUSTOMIZATION.TAUNT);
        }
        if (doRepeat || availableStances.length > 0) {
            variants.push(CUSTOMIZATION.STANCE);
        }
        var chosenType = variants[rnd.nextInt(variants.length)];
        var chosenCustomizationSettings;
        var chosenCustomizationArray;
        var ids;
        if (chosenType == CUSTOMIZATION.STANCE) {
            chosenCustomizationSettings = { Stances: [] };
            chosenCustomizationArray = chosenCustomizationSettings.Stances;
            ids = LootGenerator.generateCustomizations({
                playerProgress: playerProgress,
                playerIds: playerProgress.stances,
                availableList: StanceUtils.getAvailableIdsRandomGenerating(),
                customizationMap: stancesMap,
                customizationSettings: { Rarities: (_c = {}, _c[stanceRarity] = 1, _c), HeroFilter: pseudorandomSettings.isCustomizationHeroFilter },
                canRepeatCustomization: doRepeat,
                customizationType: CUSTOMIZATION.STANCE
            }, rnd);
        }
        else {
            chosenCustomizationSettings = { Taunts: [] };
            chosenCustomizationArray = chosenCustomizationSettings.Taunts;
            ids = LootGenerator.generateCustomizations({
                playerProgress: playerProgress,
                playerIds: playerProgress.taunts,
                availableList: TauntConstants.availableTauntsForRandomGeneration,
                customizationMap: tauntsMap,
                customizationSettings: { Rarities: (_d = {}, _d[tauntRarity] = 1, _d), HeroFilter: pseudorandomSettings.isCustomizationHeroFilter },
                canRepeatCustomization: doRepeat,
                customizationType: CUSTOMIZATION.TAUNT
            }, rnd);
        }
        if (ids.length == 0) {
            return null;
        }
        chosenCustomizationArray.push(ids[0]);
        return new Loot(chosenCustomizationSettings);
    };
    return PseudorandomCustomizationGenerator;
}(PseudorandomGenerator));
