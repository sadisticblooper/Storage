var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PseudorandomCommonShardsGenerator = (function (_super) {
    __extends(PseudorandomCommonShardsGenerator, _super);
    function PseudorandomCommonShardsGenerator() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.shardsGenerator = new ShardsGenerator();
        return _this;
    }
    PseudorandomCommonShardsGenerator.prototype.generate = function () {
        var _a = this.settings, items = _a.items, playerProgress = _a.playerProgress;
        var result = new Loot();
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            var loot = this.generateShards(item);
            if (loot && !loot.isEmpty()) {
                result.combineLoot(loot);
                HeroUtils.combineLoot(playerProgress, loot);
            }
        }
        return result;
    };
    PseudorandomCommonShardsGenerator.prototype.generateShards = function (item) {
        var _a;
        var _b = this.settings, playerProgress = _b.playerProgress, rnd = _b.rnd, chestId = _b.chestId, serverTime = _b.serverTime;
        var collection = new RandomCollection();
        var chest = chestsMap.checkedGet(chestId);
        var rarity = ChestsConstants.pseudorandomRarityMap[item];
        var heroWeights = {};
        var heroesForShards = [];
        var heroesForDuplicates = [];
        for (var _i = 0, _c = heroesMap.getKeys(); _i < _c.length; _i++) {
            var id = _c[_i];
            var hero = heroesMap.get(id);
            if (hero.UnlockHeroSinceDateTime && hero.UnlockHeroSinceDateTime > serverTime) {
                continue;
            }
            if (!hero.LockShards
                && (hero.ArenaNumberNeeded == 1 || playerProgress.heroes[hero.ID] != undefined)
                && hero.Rarity == rarity) {
                if (playerProgress.heroes[hero.ID] != undefined && hero.DuplicatesWeightForGenerating) {
                    heroesForDuplicates.push(id);
                    heroWeights[id] = hero.DuplicatesWeightForGenerating;
                }
                else if (playerProgress.heroes[hero.ID] == undefined && hero.ShardsWeightForGenerating) {
                    heroesForShards.push(id);
                    heroWeights[id] = hero.ShardsWeightForGenerating;
                }
            }
        }
        var idsForGenerating = this.shardsGenerator.getHeroIdsForGeneratingByShardsMode({
            availableHeroesForShards: heroesForShards,
            availableHeroesForDuplicates: heroesForDuplicates,
            mode: chest.shardsGeneratingMode,
            modeChancesTable: chest.shardsModeDistribution || LootConstants.shardsModeDistribution,
            rnd: rnd,
        });
        for (var _d = 0, idsForGenerating_1 = idsForGenerating; _d < idsForGenerating_1.length; _d++) {
            var id = idsForGenerating_1[_d];
            collection.add(new CollectionObjectContainer(id, heroWeights[id]));
        }
        if (collection.size() == 0) {
            return null;
        }
        var heroId = Number(collection.next(rnd).get());
        return new Loot({ Shards: (_a = {}, _a[heroId] = 1, _a) });
    };
    return PseudorandomCommonShardsGenerator;
}(PseudorandomGenerator));
