var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var PseudorandomInflationShardsGenerator = (function (_super) {
    __extends(PseudorandomInflationShardsGenerator, _super);
    function PseudorandomInflationShardsGenerator() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.shardsGenerator = new ShardsGenerator();
        return _this;
    }
    PseudorandomInflationShardsGenerator.prototype.generate = function () {
        var _a = this.settings, playerProgress = _a.playerProgress, items = _a.items, chestId = _a.chestId, rnd = _a.rnd, serverTime = _a.serverTime;
        var amountsByRarity = {};
        var rarityOrder = LootConstants.orderRarity;
        var chest = chestsMap.checkedGet(chestId);
        var resultShards = {};
        var availableSeparated = this.getAvailableSeparated(playerProgress, serverTime);
        var shardsByRarity = this.shardsGenerator.getAvailableHeroesForDuplicatesAndShards({
            playerProgress: playerProgress,
            availableSeparated: availableSeparated,
        });
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            var rarity = ChestsConstants.pseudorandomRarityMap[item];
            if (amountsByRarity[rarity] == undefined) {
                amountsByRarity[rarity] = 0;
            }
            amountsByRarity[rarity]++;
        }
        for (var _b = 0, rarityOrder_1 = rarityOrder; _b < rarityOrder_1.length; _b++) {
            var rarityNumber = rarityOrder_1[_b];
            if (amountsByRarity[rarityNumber] && shardsByRarity[rarityNumber]) {
                this.addWeightsForAllHeroesOfRarity(shardsByRarity[rarityNumber].shards, shardsByRarity[rarityNumber].duplicates, playerProgress, chest.shardsGeneratingMode, chest.shardsModeDistribution || LootConstants.shardsModeDistribution);
                var idsForGenerating = this.shardsGenerator.getHeroIdsForGeneratingByShardsMode({
                    availableHeroesForShards: shardsByRarity[rarityNumber].shards,
                    availableHeroesForDuplicates: shardsByRarity[rarityNumber].duplicates,
                    mode: chest.shardsGeneratingMode,
                    modeChancesTable: chest.shardsModeDistribution || LootConstants.shardsModeDistribution,
                    rnd: rnd,
                });
                var hid = this.shardsGenerator.getRandomHero({
                    availablePool: idsForGenerating,
                    playerProgress: playerProgress,
                    rnd: rnd,
                });
                if (hid) {
                    resultShards[hid] = amountsByRarity[rarityNumber];
                }
            }
        }
        return new Loot({ Shards: resultShards });
    };
    PseudorandomInflationShardsGenerator.prototype.getAvailableSeparated = function (playerProgress, serverTime) {
        var result = {
            available: {},
            heroesInfo: {},
            shardsInfo: {},
        };
        var heroesInfo = playerProgress.heroes;
        var shardsInfo = playerProgress.heroShards;
        for (var _i = 0, _a = heroesMap.getKeys(); _i < _a.length; _i++) {
            var hid = _a[_i];
            var hero = heroesMap.get(hid);
            var state = heroesInfo[hid];
            if (hero.UnlockHeroSinceDateTime && hero.UnlockHeroSinceDateTime > serverTime) {
                continue;
            }
            if (state) {
                if (!result.available[hero.Rarity]) {
                    result.available[hero.Rarity] = {
                        shards: [],
                        cards: []
                    };
                }
                result.available[hero.Rarity].cards.push(hero.ID);
                result.heroesInfo[hid] = __assign({}, heroesInfo[hid]);
            }
            if (!hero.LockShards && (hero.ArenaNumberNeeded == 1 || state != undefined)) {
                if (!result.available[hero.Rarity]) {
                    result.available[hero.Rarity] = {
                        shards: [],
                        cards: []
                    };
                }
                result.available[hero.Rarity].shards.push(hero.ID);
                if (state) {
                    result.shardsInfo[hid] = hero.ShardsNeeded;
                }
                else {
                    result.shardsInfo[hid] = shardsInfo[hid] || 0;
                }
            }
        }
        return result;
    };
    PseudorandomInflationShardsGenerator.prototype.addWeightsForAllHeroesOfRarity = function (availableHeroesForShards, availableHeroesForDuplicates, playerProgress, mode, modeChancesTable) {
        var allHeroes = __spreadArray(__spreadArray([], availableHeroesForShards, true), availableHeroesForDuplicates, true);
        var baseWeights = {};
        for (var _i = 0, allHeroes_1 = allHeroes; _i < allHeroes_1.length; _i++) {
            var hid = allHeroes_1[_i];
            var hero = heroesMap.checkedGet(hid);
            var weight = 0;
            if (playerProgress.heroes[hid] == undefined) {
                var shards = playerProgress.heroShards[hid] || 0;
                shards += 1;
                weight = hero.ShardsWeightForGenerating * (shards / hero.ShardsNeeded);
            }
            else {
                var heroState = playerProgress.heroes[hid];
                var partTalentLevel = hero.getTalentPartLevel(heroState.TalentLevel, heroState.Duplicates + 1);
                weight = (hero.DuplicatesWeightForGenerating * (partTalentLevel - heroState.TalentLevel)) || MAX_TALENT_MIN_WEIGHT;
            }
            weight *= LootUtils.getModificationShardWeight(weight, LootConstants.shardsModificationContent);
            baseWeights[hid] = weight;
        }
        var finalWeights = {};
        var shardsWeight = modeChancesTable[SHARDS_GENERATING_MODE.SHARDS] || 1;
        var duplicatesWeight = modeChancesTable[SHARDS_GENERATING_MODE.DUPLICATES] || 1;
        for (var _a = 0, allHeroes_2 = allHeroes; _a < allHeroes_2.length; _a++) {
            var hid = allHeroes_2[_a];
            var isShard = availableHeroesForShards.indexOf(hid) >= 0;
            var isDuplicate = availableHeroesForDuplicates.indexOf(hid) >= 0;
            if (mode === SHARDS_GENERATING_MODE.SHARDS) {
                finalWeights[hid] = isShard ? baseWeights[hid] : 0;
            }
            else if (mode === SHARDS_GENERATING_MODE.DUPLICATES) {
                finalWeights[hid] = isDuplicate ? baseWeights[hid] : 0;
            }
            else {
                if (isShard) {
                    finalWeights[hid] = baseWeights[hid] * shardsWeight;
                }
                else if (isDuplicate) {
                    finalWeights[hid] = baseWeights[hid] * duplicatesWeight;
                }
            }
        }
        var sum = 0;
        for (var hid in finalWeights) {
            sum += finalWeights[hid];
        }
        if (sum > 0) {
            for (var hid in finalWeights) {
                finalWeights[hid] = finalWeights[hid] / sum;
            }
        }
        EXTENDED_DROP_POPUP_PROXY_MANAGER.addHeroShardsWeights(finalWeights);
    };
    return PseudorandomInflationShardsGenerator;
}(PseudorandomGenerator));
