var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var PseudorandomPositionGetter = (function () {
    function PseudorandomPositionGetter(chestQueuePositions, seed) {
        this.chestQueuePositions = PseudorandomPositionGetter.getFromRaw(chestQueuePositions);
        this.rnd = new PcgRandom(seed);
    }
    PseudorandomPositionGetter.prototype.getChestQueuePositions = function () {
        return __assign({}, this.chestQueuePositions);
    };
    PseudorandomPositionGetter.prototype.getCurrentPosition = function (chestId) {
        var settings = PseudorandomSettings.settings[chestId];
        if (!settings || settings.queue.length == 0) {
            return undefined;
        }
        if (this.chestQueuePositions[chestId] == undefined) {
            this.generateStartPosition(chestId, settings);
        }
        var lengthOfQueue = settings.queueLength ? settings.queueLength : 1;
        return this.chestQueuePositions[chestId] % lengthOfQueue;
    };
    PseudorandomPositionGetter.prototype.movePosition = function (chestId, delta) {
        var position = this.getCurrentPosition(chestId);
        var settings = PseudorandomSettings.settings[chestId];
        if (!settings || position == undefined) {
            return;
        }
        var lengthOfQueue = settings.queueLength ? settings.queueLength : 1;
        this.chestQueuePositions[chestId] = (position + delta) % lengthOfQueue;
    };
    PseudorandomPositionGetter.prototype.generateStartPosition = function (chestId, settings) {
        if (settings.initPositionsInQueue.length == 0) {
            this.chestQueuePositions[chestId] = 0;
        }
        else {
            var initPositions = settings.initPositionsInQueue;
            this.chestQueuePositions[chestId] = initPositions[this.rnd.nextInt(initPositions.length)];
        }
    };
    PseudorandomPositionGetter.getFromRaw = function (positions) {
        var result = {};
        for (var _i = 0, _a = chestsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var chestId = id.toString();
            if (positions[chestId] != undefined) {
                result[chestId] = Number(positions[chestId]);
            }
        }
        return result;
    };
    return PseudorandomPositionGetter;
}());
