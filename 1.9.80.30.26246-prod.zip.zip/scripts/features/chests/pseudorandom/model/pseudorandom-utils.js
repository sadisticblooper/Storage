var PseudorandomUtils = (function () {
    function PseudorandomUtils() {
    }
    PseudorandomUtils.getPositionsAtTimeForChest = function (chestId) {
        if (PseudorandomSettings.settings[chestId]) {
            return PseudorandomSettings.settings[chestId].pseudrorandomDropCount
                || ChestsConstants.pseudorandomPositionsAtTime;
        }
        return 0;
    };
    PseudorandomUtils.getPseudoRandomLoot = function (settings) {
        var playerProgress = settings.playerProgress, chestId = settings.chestId, rnd = settings.rnd, quantity = settings.quantity, positionInQueue = settings.positionInQueue, serverTime = settings.serverTime;
        var pseudorandomSettings = PseudorandomSettings.settings[chestId];
        var result = new Loot();
        if (!pseudorandomSettings || !quantity || positionInQueue == undefined) {
            return null;
        }
        var itemsForGenerating = PseudorandomUtils.getItemsFromQueueByStartPosition({
            startPosition: positionInQueue,
            quantity: quantity,
            queue: pseudorandomSettings.queue,
        });
        if (itemsForGenerating.length == 0) {
            return null;
        }
        var itemsForCustomization = [];
        var itemsForShards = [];
        for (var _i = 0, itemsForGenerating_1 = itemsForGenerating; _i < itemsForGenerating_1.length; _i++) {
            var item = itemsForGenerating_1[_i];
            if (item > 0) {
                continue;
            }
            if ([
                PSRND_ITEM.COMMON_HERO,
                PSRND_ITEM.RARE_HERO,
                PSRND_ITEM.EPIC_HERO,
                PSRND_ITEM.LEGENDARY_HERO,
            ].indexOf(item) > -1) {
                itemsForShards.push(item);
            }
            else {
                itemsForCustomization.push(item);
            }
        }
        var generators = [
            new PseudorandomCustomizationGenerator({
                playerProgress: playerProgress,
                rnd: rnd,
                chestId: chestId,
                items: itemsForCustomization,
                serverTime: serverTime,
            }),
            new PseudorandomInflationShardsGenerator({
                playerProgress: playerProgress,
                rnd: rnd,
                chestId: chestId,
                items: itemsForShards,
                serverTime: serverTime,
            }),
        ];
        for (var _a = 0, generators_1 = generators; _a < generators_1.length; _a++) {
            var generator = generators_1[_a];
            var loot = generator.generate();
            if (loot && !loot.isEmpty()) {
                result.combineLoot(loot);
            }
        }
        return result;
    };
    PseudorandomUtils.getItemsFromQueueByStartPosition = function (settings) {
        var queue = settings.queue, quantity = settings.quantity, startPosition = settings.startPosition;
        var result = [];
        if (queue.length > 0) {
            var positionInShortQueue = 0;
            var positionInFullQueue = 0;
            var startFound = false;
            while (quantity > 0) {
                var element = queue[positionInShortQueue];
                var elementsProcessed = element < 0 ? 1 : +element;
                if (positionInFullQueue >= startPosition && !startFound) {
                    startFound = true;
                }
                if (startFound) {
                    if (element < 0) {
                        result.push(+element);
                    }
                    quantity -= elementsProcessed;
                }
                positionInFullQueue += elementsProcessed;
                positionInShortQueue = (positionInShortQueue + 1) % queue.length;
            }
        }
        return result;
    };
    PseudorandomUtils.getPseudorandomTypes = function (type) {
        for (var tableType in ChestsConstants.pseudorandomTypesMap) {
            if (+tableType == type) {
                return ChestsConstants.pseudorandomTypesMap[tableType];
            }
        }
        return [];
    };
    PseudorandomUtils.isGuaranteeType = function (type, chestId) {
        var pseudoRandomQueue = PseudorandomSettings.settings[chestId] && PseudorandomSettings.settings[chestId].queue;
        if (!pseudoRandomQueue) {
            return undefined;
        }
        var pseudorandomItems = PseudorandomUtils.getPseudorandomTypes(type);
        for (var _i = 0, pseudoRandomQueue_1 = pseudoRandomQueue; _i < pseudoRandomQueue_1.length; _i++) {
            var element = pseudoRandomQueue_1[_i];
            if (pseudorandomItems.indexOf(element) == -1) {
                return false;
            }
        }
        return true;
    };
    return PseudorandomUtils;
}());
