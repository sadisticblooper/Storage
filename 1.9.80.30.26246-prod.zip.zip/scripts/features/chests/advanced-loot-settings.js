var _a, _b;
advancedLootSettings = (_a = {},
    _a[chests.Butcher_legendary_weapon_chest.ID] = {
        Groups: [
            {
                Weight: 6,
                Weapons: { Ids: (_b = {}, _b[heroWeapons.wpn_Butcher_L_Gore.ID] = 1, _b) }
            },
            {
                Weight: 9994,
                CustomizationShards: {
                    items: [{
                            id: getCompositeShardsId(CUSTOMIZATION.WEAPON, heroWeapons.wpn_Butcher_L_Gore.ID),
                            params: { W: 1, N: 1 }
                        }]
                }
            },
        ]
    },
    _a);
