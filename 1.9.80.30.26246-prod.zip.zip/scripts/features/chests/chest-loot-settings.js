var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151, _152, _153, _154, _155, _156, _157, _158, _159, _160, _161, _162, _163, _164, _165, _166, _167, _168, _169, _170, _171, _172, _173, _174, _175, _176, _177, _178, _179, _180, _181, _182, _183, _184, _185, _186, _187, _188, _189, _190, _191, _192, _193, _194, _195, _196, _197, _198, _199, _200, _201, _202, _203, _204, _205, _206, _207, _208, _209, _210, _211, _212, _213, _214, _215, _216, _217, _218, _219, _220, _221, _222, _223, _224, _225, _226, _227, _228, _229, _230, _231, _232, _233, _234, _235, _236, _237, _238, _239, _240, _241, _242, _243, _244, _245, _246, _247, _248, _249, _250, _251, _252, _253, _254, _255, _256, _257, _258, _259, _260, _261, _262, _263, _264, _265, _266, _267, _268, _269, _270, _271, _272, _273, _274, _275, _276, _277, _278, _279, _280, _281, _282, _283, _284, _285, _286, _287, _288, _289, _290, _291, _292, _293, _294, _295, _296, _297, _298, _299, _300, _301, _302, _303, _304, _305;
var shardsLootSettings = {
    CommonShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    RareShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    EpicShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    LegendaryShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    MythicShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    BattlePassShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    SuperBattlePassShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
    MonkeyKingShardSettings: { Rarities: { COMMON: [{ W: 0, N: 1 }] } },
};
var duplicatesLootSettings = {
    CommonShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    RareShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    EpicShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    LegendaryShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    MythicShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    RareShopShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    EpicShopShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    LegendaryShopShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
    MythicShopShardSettings: {
        Arena1: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena2: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena3: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena4: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena5: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena6: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena7: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena8: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena9: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
        Arena10: {
            Rarities: {
                COMMON: [{ W: 1, N: 0 }],
                RARE: [{ W: 1, N: 0 }],
                EPIC: [{ W: 1, N: 0 }],
                LEGENDARY: [{ W: 1, N: 0 }]
            }
        },
    },
};
var currencyLootSettings = {
    CommonCurrencySettings: (_a = {},
        _a[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
        _a),
    RareCurrencySettings: (_b = {},
        _b[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
        _b),
    EpicCurrencySettings: (_c = {},
        _c[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
        _c),
    LegendaryCurrencySettings: (_d = {},
        _d[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
        _d),
    MythicCurrencySettings: (_e = {}, _e[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(720, 850) }], _e),
    RareCurrencySettingsShop: (_f = {},
        _f[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(60, 80) }],
        _f),
    EpicCurrencySettingsShop: (_g = {},
        _g[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300, 410) }],
        _g),
    LegendaryCurrencySettingsShop: (_h = {},
        _h[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(720, 850) }],
        _h),
};
var chestLootSettings = {
    Common: {
        Arena1: {
            CardsSlots: {
                TotalCards: 3, TotalSlots: 4, Rarities: (_j = {},
                    _j[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.COMMON
                    },
                    _j[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.RARE
                    },
                    _j[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.EPIC
                    },
                    _j[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.95, N: 0 }, { W: 0.05, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _j),
            },
            CurrencySlots: (_k = {},
                _k[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(30) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(35)
                    }, { Weight: 0.16, Amount: new RndFromInterval(40) },],
                _k[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _k),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 4, TotalSlots: 4, Rarities: (_l = {},
                    _l[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.COMMON
                    },
                    _l[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.RARE
                    },
                    _l[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.EPIC
                    },
                    _l[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.935, N: 0 }, { W: 0.065, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _l),
            },
            CurrencySlots: (_m = {},
                _m[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(32) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(37)
                    }, { Weight: 0.15, Amount: new RndFromInterval(42) },],
                _m[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _m),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_o = {},
                    _o[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.COMMON
                    },
                    _o[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.RARE
                    },
                    _o[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.EPIC
                    },
                    _o[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.92, N: 0 }, { W: 0.08, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _o),
            },
            CurrencySlots: (_p = {},
                _p[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(35) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(40)
                    }, { Weight: 0.16, Amount: new RndFromInterval(45) },],
                _p[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _p),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 6, TotalSlots: 4, Rarities: (_q = {},
                    _q[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.COMMON
                    },
                    _q[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.RARE
                    },
                    _q[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.EPIC
                    },
                    _q[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.905, N: 0 }, { W: 0.095, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _q),
            },
            CurrencySlots: (_r = {},
                _r[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(37) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(42)
                    }, { Weight: 0.16, Amount: new RndFromInterval(47) },],
                _r[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _r),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_s = {},
                    _s[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.COMMON
                    },
                    _s[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.RARE
                    },
                    _s[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.EPIC
                    },
                    _s[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _s),
            },
            CurrencySlots: (_t = {},
                _t[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(40) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(45)
                    }, { Weight: 0.15, Amount: new RndFromInterval(50) },],
                _t[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _t),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_u = {},
                    _u[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.COMMON
                    },
                    _u[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.RARE
                    },
                    _u[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.EPIC
                    },
                    _u[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.875, N: 0 }, { W: 0.125, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _u),
            },
            CurrencySlots: (_v = {},
                _v[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(42) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(47)
                    }, { Weight: 0.15, Amount: new RndFromInterval(52) },],
                _v[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _v),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 4, Rarities: (_w = {},
                    _w[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.COMMON
                    },
                    _w[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.RARE
                    },
                    _w[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.EPIC
                    },
                    _w[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _w),
            },
            CurrencySlots: (_x = {},
                _x[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(45) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(50)
                    }, { Weight: 0.15, Amount: new RndFromInterval(55) },],
                _x[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _x),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_y = {},
                    _y[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.COMMON
                    },
                    _y[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.RARE
                    },
                    _y[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.EPIC
                    },
                    _y[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.845, N: 0 }, { W: 0.155, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _y),
            },
            CurrencySlots: (_z = {},
                _z[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(47) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(52)
                    }, { Weight: 0.1, Amount: new RndFromInterval(57) },],
                _z[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _z),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_0 = {},
                    _0[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.COMMON
                    },
                    _0[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.RARE
                    },
                    _0[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.EPIC
                    },
                    _0[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.83, N: 0 }, { W: 0.17, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _0),
            },
            CurrencySlots: (_1 = {},
                _1[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(50) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(55)
                    }, { Weight: 0.15, Amount: new RndFromInterval(60) },],
                _1[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _1),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 4, Rarities: (_2 = {},
                    _2[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.COMMON
                    },
                    _2[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.RARE
                    },
                    _2[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.EPIC
                    },
                    _2[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.815, N: 0 }, { W: 0.185, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _2),
            },
            CurrencySlots: (_3 = {},
                _3[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(52) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(57)
                    }, { Weight: 0.1, Amount: new RndFromInterval(62) },],
                _3[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _3),
        },
    },
    Rare: {
        Arena1: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 5, Rarities: (_4 = {},
                    _4[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena1.Rarities.COMMON
                    },
                    _4[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena1.Rarities.RARE
                    },
                    _4[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena1.Rarities.EPIC
                    },
                    _4[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _4),
            },
            CurrencySlots: (_5 = {},
                _5[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(60) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(80)
                    }, { Weight: 0.15, Amount: new RndFromInterval(100) },],
                _5[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _5),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 5, Rarities: (_6 = {},
                    _6[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena2.Rarities.COMMON
                    },
                    _6[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena2.Rarities.RARE
                    },
                    _6[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 0 }, { W: 0.35, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena2.Rarities.EPIC
                    },
                    _6[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _6),
            },
            CurrencySlots: (_7 = {},
                _7[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(65) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(85)
                    }, { Weight: 0.15, Amount: new RndFromInterval(105) },],
                _7[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _7),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 15, TotalSlots: 5, Rarities: (_8 = {},
                    _8[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena3.Rarities.COMMON
                    },
                    _8[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena3.Rarities.RARE
                    },
                    _8[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 0 }, { W: 0.4, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena3.Rarities.EPIC
                    },
                    _8[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _8),
            },
            CurrencySlots: (_9 = {},
                _9[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(70) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(75)
                    }, { Weight: 0.15, Amount: new RndFromInterval(110) },],
                _9[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _9),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 18, TotalSlots: 5, Rarities: (_10 = {},
                    _10[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena4.Rarities.COMMON
                    },
                    _10[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 6 }, { W: 0.5, N: 6 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena4.Rarities.RARE
                    },
                    _10[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 0 }, { W: 0.45, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena4.Rarities.EPIC
                    },
                    _10[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _10),
            },
            CurrencySlots: (_11 = {},
                _11[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(75) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(80)
                    }, { Weight: 0.15, Amount: new RndFromInterval(115) },],
                _11[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _11),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 21, TotalSlots: 5, Rarities: (_12 = {},
                    _12[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena5.Rarities.COMMON
                    },
                    _12[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 7 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena5.Rarities.RARE
                    },
                    _12[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena5.Rarities.EPIC
                    },
                    _12[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _12),
            },
            CurrencySlots: (_13 = {},
                _13[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(80) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(85)
                    }, { Weight: 0.15, Amount: new RndFromInterval(120) },],
                _13[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _13),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 24, TotalSlots: 5, Rarities: (_14 = {},
                    _14[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena6.Rarities.COMMON
                    },
                    _14[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena6.Rarities.RARE
                    },
                    _14[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.45, N: 0 }, { W: 0.55, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena6.Rarities.EPIC
                    },
                    _14[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _14),
            },
            CurrencySlots: (_15 = {},
                _15[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(85) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(90)
                    }, { Weight: 0.15, Amount: new RndFromInterval(125) },],
                _15[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _15),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 27, TotalSlots: 5, Rarities: (_16 = {},
                    _16[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena7.Rarities.COMMON
                    },
                    _16[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena7.Rarities.RARE
                    },
                    _16[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.4, N: 0 }, { W: 0.6, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena7.Rarities.EPIC
                    },
                    _16[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _16),
            },
            CurrencySlots: (_17 = {},
                _17[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(90) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(95)
                    }, { Weight: 0.1, Amount: new RndFromInterval(130) },],
                _17[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _17),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 30, TotalSlots: 5, Rarities: (_18 = {},
                    _18[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena8.Rarities.COMMON
                    },
                    _18[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 10 }, { W: 0.5, N: 10 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena8.Rarities.RARE
                    },
                    _18[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.35, N: 0 }, { W: 0.65, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena8.Rarities.EPIC
                    },
                    _18[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _18),
            },
            CurrencySlots: (_19 = {},
                _19[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(95) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(100)
                    }, { Weight: 0.1, Amount: new RndFromInterval(135) },],
                _19[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _19),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 33, TotalSlots: 5, Rarities: (_20 = {},
                    _20[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena9.Rarities.COMMON
                    },
                    _20[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 11 }, { W: 0.5, N: 11 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena9.Rarities.RARE
                    },
                    _20[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena9.Rarities.EPIC
                    },
                    _20[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _20),
            },
            CurrencySlots: (_21 = {},
                _21[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(100) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(105)
                    }, { Weight: 0.1, Amount: new RndFromInterval(140) },],
                _21[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _21),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 36, TotalSlots: 5, Rarities: (_22 = {},
                    _22[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena10.Rarities.COMMON
                    },
                    _22[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 12 }, { W: 0.5, N: 12 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena10.Rarities.RARE
                    },
                    _22[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.25, N: 0 }, { W: 0.75, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena10.Rarities.EPIC
                    },
                    _22[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.RareShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _22),
            },
            CurrencySlots: (_23 = {},
                _23[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(105) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(110)
                    }, { Weight: 0.1, Amount: new RndFromInterval(145) },],
                _23[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _23),
        },
        OneTime_Arena3: {
            CardsSlots: {
                TotalCards: 15, TotalSlots: 5, Rarities: (_24 = {},
                    _24[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.RareShardSettings.Rarities.COMMON
                    },
                    _24[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsWeight: shardsLootSettings.RareShardSettings.Rarities.RARE
                    },
                    _24[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 0 }, { W: 0.4, N: 1 },],
                        ShardsWeight: shardsLootSettings.RareShardSettings.Rarities.EPIC
                    },
                    _24[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsWeight: shardsLootSettings.RareShardSettings.Rarities.LEGENDARY
                    },
                    _24),
            },
            CurrencySlots: (_25 = {},
                _25[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(105) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(150)
                    }, { Weight: 0.5, Amount: new RndFromInterval(195) },],
                _25[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _25),
            AdditionalFixedLoot: {
                Shards: (_26 = {}, _26[HeroNames.Ironclad.ID] = 1, _26),
            },
        },
    },
    Epic: {
        Arena1: {
            CardsSlots: {
                TotalCards: 25, TotalSlots: 5, Rarities: (_27 = {},
                    _27[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena1.Rarities.COMMON
                    },
                    _27[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena1.Rarities.RARE
                    },
                    _27[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena1.Rarities.EPIC
                    },
                    _27[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _27),
            },
            CurrencySlots: (_28 = {},
                _28[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(250) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(300)
                    }, { Weight: 0.1, Amount: new RndFromInterval(350) },],
                _28[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _28),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 29, TotalSlots: 5, Rarities: (_29 = {},
                    _29[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena2.Rarities.COMMON
                    },
                    _29[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena2.Rarities.RARE
                    },
                    _29[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena2.Rarities.EPIC
                    },
                    _29[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.4, N: 0 }, { W: 0.6, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _29),
            },
            CurrencySlots: (_30 = {},
                _30[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(275) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(325)
                    }, { Weight: 0.1, Amount: new RndFromInterval(375) },],
                _30[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _30),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 33, TotalSlots: 5, Rarities: (_31 = {},
                    _31[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena3.Rarities.COMMON
                    },
                    _31[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 10 }, { W: 0.5, N: 10 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena3.Rarities.RARE
                    },
                    _31[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena3.Rarities.EPIC
                    },
                    _31[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _31),
            },
            CurrencySlots: (_32 = {},
                _32[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(300) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(350)
                    }, { Weight: 0.1, Amount: new RndFromInterval(400) },],
                _32[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _32),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 37, TotalSlots: 5, Rarities: (_33 = {},
                    _33[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena4.Rarities.COMMON
                    },
                    _33[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 12 }, { W: 0.5, N: 12 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena4.Rarities.RARE
                    },
                    _33[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena4.Rarities.EPIC
                    },
                    _33[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.2, N: 0 }, { W: 0.8, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _33),
            },
            CurrencySlots: (_34 = {},
                _34[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(325) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(375)
                    }, { Weight: 0.1, Amount: new RndFromInterval(425) },],
                _34[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _34),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 41, TotalSlots: 5, Rarities: (_35 = {},
                    _35[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena5.Rarities.COMMON
                    },
                    _35[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 13 }, { W: 0.5, N: 13 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena5.Rarities.RARE
                    },
                    _35[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena5.Rarities.EPIC
                    },
                    _35[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _35),
            },
            CurrencySlots: (_36 = {},
                _36[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(350) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(400)
                    }, { Weight: 0.1, Amount: new RndFromInterval(450) },],
                _36[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _36),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 45, TotalSlots: 5, Rarities: (_37 = {},
                    _37[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena6.Rarities.COMMON
                    },
                    _37[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 14 }, { W: 0.5, N: 14 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena6.Rarities.RARE
                    },
                    _37[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena6.Rarities.EPIC
                    },
                    _37[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _37),
            },
            CurrencySlots: (_38 = {},
                _38[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(375) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(425)
                    }, { Weight: 0.1, Amount: new RndFromInterval(475) },],
                _38[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _38),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 49, TotalSlots: 5, Rarities: (_39 = {},
                    _39[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena7.Rarities.COMMON
                    },
                    _39[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 15 }, { W: 0.5, N: 15 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena7.Rarities.RARE
                    },
                    _39[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena7.Rarities.EPIC
                    },
                    _39[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _39),
            },
            CurrencySlots: (_40 = {},
                _40[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(400) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(450)
                    }, { Weight: 0.1, Amount: new RndFromInterval(500) },],
                _40[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _40),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 53, TotalSlots: 5, Rarities: (_41 = {},
                    _41[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena8.Rarities.COMMON
                    },
                    _41[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 16 }, { W: 0.5, N: 16 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena8.Rarities.RARE
                    },
                    _41[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena8.Rarities.EPIC
                    },
                    _41[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _41),
            },
            CurrencySlots: (_42 = {},
                _42[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(425) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(475)
                    }, { Weight: 0.1, Amount: new RndFromInterval(525) },],
                _42[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _42),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 57, TotalSlots: 5, Rarities: (_43 = {},
                    _43[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena9.Rarities.COMMON
                    },
                    _43[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 18 }, { W: 0.5, N: 18 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena9.Rarities.RARE
                    },
                    _43[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena9.Rarities.EPIC
                    },
                    _43[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _43),
            },
            CurrencySlots: (_44 = {},
                _44[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(450) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(500)
                    }, { Weight: 0.1, Amount: new RndFromInterval(550) },],
                _44[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _44),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 61, TotalSlots: 5, Rarities: (_45 = {},
                    _45[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena10.Rarities.COMMON
                    },
                    _45[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 19 }, { W: 0.5, N: 19 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena10.Rarities.RARE
                    },
                    _45[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena10.Rarities.EPIC
                    },
                    _45[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.EpicShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _45),
            },
            CurrencySlots: (_46 = {},
                _46[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(475) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(525)
                    }, { Weight: 0.1, Amount: new RndFromInterval(575) },],
                _46[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _46),
        },
        OneTime_Arena4: {
            CardsSlots: {
                TotalCards: 37, TotalSlots: 5, Rarities: (_47 = {},
                    _47[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.COMMON
                    },
                    _47[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 12 }, { W: 0.5, N: 12 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.RARE
                    },
                    _47[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.EPIC
                    },
                    _47[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.2, N: 0 }, { W: 0.8, N: 1 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.LEGENDARY
                    },
                    _47),
            },
            CurrencySlots: (_48 = {},
                _48[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(420) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(600)
                    }, { Weight: 0.5, Amount: new RndFromInterval(780) },],
                _48[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _48),
            AdditionalFixedLoot: {
                Shards: (_49 = {}, _49[HeroNames.Sarge.ID] = 1, _49),
            },
        },
        OneTime_Arena5: {
            CardsSlots: {
                TotalCards: 41, TotalSlots: 5, Rarities: (_50 = {},
                    _50[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.COMMON
                    },
                    _50[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 13 }, { W: 0.5, N: 13 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.RARE
                    },
                    _50[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.EPIC
                    },
                    _50[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsWeight: shardsLootSettings.EpicShardSettings.Rarities.LEGENDARY
                    },
                    _50),
            },
            CurrencySlots: (_51 = {},
                _51[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(455) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(650)
                    }, { Weight: 0.5, Amount: new RndFromInterval(650) },],
                _51[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _51),
            AdditionalFixedLoot: {
                Shards: (_52 = {}, _52[HeroNames.Feldsher.ID] = 1, _52),
            },
        }
    },
    Legendary: {
        Arena1: {
            CardsSlots: {
                TotalCards: 80, TotalSlots: 6, Rarities: (_53 = {},
                    _53[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena1.Rarities.COMMON
                    },
                    _53[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 20 }, { W: 0.5, N: 20 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena1.Rarities.RARE
                    },
                    _53[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena1.Rarities.EPIC
                    },
                    _53[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _53),
            },
            CurrencySlots: (_54 = {},
                _54[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(560) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(800)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1040) },],
                _54[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _54),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 85, TotalSlots: 6, Rarities: (_55 = {},
                    _55[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena2.Rarities.COMMON
                    },
                    _55[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 22 }, { W: 0.5, N: 22 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena2.Rarities.RARE
                    },
                    _55[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 6 }, { W: 0.5, N: 6 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena2.Rarities.EPIC
                    },
                    _55[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _55),
            },
            CurrencySlots: (_56 = {},
                _56[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(630) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(900)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1170) },],
                _56[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _56),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 90, TotalSlots: 6, Rarities: (_57 = {},
                    _57[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena3.Rarities.COMMON
                    },
                    _57[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 24 }, { W: 0.5, N: 24 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena3.Rarities.RARE
                    },
                    _57[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 6 }, { W: 0.5, N: 6 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena3.Rarities.EPIC
                    },
                    _57[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _57),
            },
            CurrencySlots: (_58 = {},
                _58[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(700) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1000)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1300) },],
                _58[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _58),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 95, TotalSlots: 6, Rarities: (_59 = {},
                    _59[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena4.Rarities.COMMON
                    },
                    _59[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 26 }, { W: 0.5, N: 26 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena4.Rarities.RARE
                    },
                    _59[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 7 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena4.Rarities.EPIC
                    },
                    _59[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _59),
            },
            CurrencySlots: (_60 = {},
                _60[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(770) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1100)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1430) },],
                _60[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _60),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 100, TotalSlots: 6, Rarities: (_61 = {},
                    _61[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena5.Rarities.COMMON
                    },
                    _61[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 28 }, { W: 0.5, N: 28 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena5.Rarities.RARE
                    },
                    _61[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 7 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena5.Rarities.EPIC
                    },
                    _61[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _61),
            },
            CurrencySlots: (_62 = {},
                _62[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(840) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1200)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1560) },],
                _62[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _62),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 105, TotalSlots: 6, Rarities: (_63 = {},
                    _63[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena6.Rarities.COMMON
                    },
                    _63[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 30 }, { W: 0.5, N: 30 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena6.Rarities.RARE
                    },
                    _63[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena6.Rarities.EPIC
                    },
                    _63[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _63),
            },
            CurrencySlots: (_64 = {},
                _64[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(910) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1300)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1690) },],
                _64[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _64),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 110, TotalSlots: 6, Rarities: (_65 = {},
                    _65[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena7.Rarities.COMMON
                    },
                    _65[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 32 }, { W: 0.5, N: 32 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena7.Rarities.RARE
                    },
                    _65[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena7.Rarities.EPIC
                    },
                    _65[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _65),
            },
            CurrencySlots: (_66 = {},
                _66[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(980) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1400)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1820) },],
                _66[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _66),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 115, TotalSlots: 6, Rarities: (_67 = {},
                    _67[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena8.Rarities.COMMON
                    },
                    _67[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 34 }, { W: 0.5, N: 34 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena8.Rarities.RARE
                    },
                    _67[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena8.Rarities.EPIC
                    },
                    _67[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _67),
            },
            CurrencySlots: (_68 = {},
                _68[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(1050) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1500)
                    }, { Weight: 0.5, Amount: new RndFromInterval(1950) },],
                _68[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _68),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 120, TotalSlots: 6, Rarities: (_69 = {},
                    _69[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena9.Rarities.COMMON
                    },
                    _69[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 36 }, { W: 0.5, N: 36 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena9.Rarities.RARE
                    },
                    _69[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena9.Rarities.EPIC
                    },
                    _69[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _69),
            },
            CurrencySlots: (_70 = {},
                _70[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(1120) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1600)
                    }, { Weight: 0.5, Amount: new RndFromInterval(2080) },],
                _70[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _70),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 125, TotalSlots: 6, Rarities: (_71 = {},
                    _71[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena10.Rarities.COMMON
                    },
                    _71[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 38 }, { W: 0.5, N: 38 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena10.Rarities.RARE
                    },
                    _71[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 10 }, { W: 0.5, N: 10 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena10.Rarities.EPIC
                    },
                    _71[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.LegendaryShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _71),
            },
            CurrencySlots: (_72 = {},
                _72[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(1190) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(1700)
                    }, { Weight: 0.5, Amount: new RndFromInterval(2210) },],
                _72[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _72),
        },
    },
    Mythic: {
        Arena1: {
            CardsSlots: {
                TotalCards: 170, TotalSlots: 6, Rarities: (_73 = {},
                    _73[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.COMMON
                    },
                    _73[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 50 }, { W: 0.5, N: 50 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.RARE
                    },
                    _73[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 17 }, { W: 0.5, N: 17 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.EPIC
                    },
                    _73[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 5 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _73),
            },
            CurrencySlots: (_74 = {},
                _74[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(2100) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(3000)
                    }, { Weight: 0.5, Amount: new RndFromInterval(3900) },],
                _74),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 180, TotalSlots: 6, Rarities: (_75 = {},
                    _75[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.COMMON
                    },
                    _75[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 55 }, { W: 0.5, N: 55 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.RARE
                    },
                    _75[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 18 }, { W: 0.5, N: 18 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.EPIC
                    },
                    _75[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 6 }, { W: 0.5, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _75),
            },
            CurrencySlots: (_76 = {},
                _76[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(2310) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(3300)
                    }, { Weight: 0.5, Amount: new RndFromInterval(4290) },],
                _76),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 190, TotalSlots: 6, Rarities: (_77 = {},
                    _77[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.COMMON
                    },
                    _77[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 60 }, { W: 0.5, N: 60 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.RARE
                    },
                    _77[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 19 }, { W: 0.5, N: 19 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.EPIC
                    },
                    _77[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 6 }, { W: 0.5, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _77),
            },
            CurrencySlots: (_78 = {},
                _78[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(2520) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(3600)
                    }, { Weight: 0.5, Amount: new RndFromInterval(4680) },],
                _78),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 200, TotalSlots: 6, Rarities: (_79 = {},
                    _79[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.COMMON
                    },
                    _79[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 65 }, { W: 0.5, N: 65 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.RARE
                    },
                    _79[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 20 }, { W: 0.5, N: 20 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.EPIC
                    },
                    _79[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _79),
            },
            CurrencySlots: (_80 = {},
                _80[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(2730) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(3900)
                    }, { Weight: 0.5, Amount: new RndFromInterval(5070) },],
                _80),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 210, TotalSlots: 6, Rarities: (_81 = {},
                    _81[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.COMMON
                    },
                    _81[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 70 }, { W: 0.5, N: 70 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.RARE
                    },
                    _81[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 21 }, { W: 0.5, N: 21 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.EPIC
                    },
                    _81[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _81),
            },
            CurrencySlots: (_82 = {},
                _82[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(2940) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(4200)
                    }, { Weight: 0.5, Amount: new RndFromInterval(5460) },],
                _82),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 220, TotalSlots: 6, Rarities: (_83 = {},
                    _83[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.COMMON
                    },
                    _83[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 75 }, { W: 0.5, N: 75 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.RARE
                    },
                    _83[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 22 }, { W: 0.5, N: 22 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.EPIC
                    },
                    _83[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _83),
            },
            CurrencySlots: (_84 = {},
                _84[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(3150) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(4500)
                    }, { Weight: 0.5, Amount: new RndFromInterval(5850) },],
                _84),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 230, TotalSlots: 6, Rarities: (_85 = {},
                    _85[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.COMMON
                    },
                    _85[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 80 }, { W: 0.5, N: 80 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.RARE
                    },
                    _85[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 23 }, { W: 0.5, N: 23 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.EPIC
                    },
                    _85[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 8 }, { W: 0.5, N: 8 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _85),
            },
            CurrencySlots: (_86 = {},
                _86[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(3360) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(4800)
                    }, { Weight: 0.5, Amount: new RndFromInterval(6240) },],
                _86),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 240, TotalSlots: 6, Rarities: (_87 = {},
                    _87[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.COMMON
                    },
                    _87[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 85 }, { W: 0.5, N: 85 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.RARE
                    },
                    _87[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 24 }, { W: 0.5, N: 24 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.EPIC
                    },
                    _87[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _87),
            },
            CurrencySlots: (_88 = {},
                _88[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(3570) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(5100)
                    }, { Weight: 0.5, Amount: new RndFromInterval(6630) },],
                _88),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 250, TotalSlots: 6, Rarities: (_89 = {},
                    _89[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.COMMON
                    },
                    _89[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 90 }, { W: 0.5, N: 90 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.RARE
                    },
                    _89[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 25 }, { W: 0.5, N: 25 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.EPIC
                    },
                    _89[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 9 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _89),
            },
            CurrencySlots: (_90 = {},
                _90[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(3780) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(5400)
                    }, { Weight: 0.5, Amount: new RndFromInterval(7020) },],
                _90),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 260, TotalSlots: 6, Rarities: (_91 = {},
                    _91[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.COMMON
                    },
                    _91[HERO_RARITY.RARE] = {
                        Slots: 2,
                        CardsWeight: [{ W: 0.5, N: 95 }, { W: 0.5, N: 95 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.RARE
                    },
                    _91[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 26 }, { W: 0.5, N: 26 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.EPIC
                    },
                    _91[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 10 }, { W: 0.5, N: 10 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _91),
            },
            CurrencySlots: (_92 = {},
                _92[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(3990) }, {
                        Weight: 0.5,
                        Amount: new RndFromInterval(5700)
                    }, { Weight: 0.5, Amount: new RndFromInterval(7410) },],
                _92),
        },
    },
    ShardsChest: {
        Arena1: {},
        Arena2: {},
        Arena3: {},
        Arena4: {},
        Arena5: {},
        Arena6: {},
        Arena7: {},
        Arena8: {},
        Arena9: {},
        Arena10: {},
    },
    Customize_chest: {
        Arena1: {},
        Arena2: {},
        Arena3: {},
        Arena4: {},
        Arena5: {},
        Arena6: {},
        Arena7: {},
        Arena8: {},
        Arena9: {},
        Arena10: {},
    },
    Gold_chest: {
        Arena1: {
            CurrencySlots: (_93 = {},
                _93[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(270) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(300)
                    }, { Weight: 1, Amount: new RndFromInterval(330) },],
                _93),
        },
        Arena2: {
            CurrencySlots: (_94 = {},
                _94[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(280) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(310)
                    }, { Weight: 1, Amount: new RndFromInterval(340) },],
                _94),
        },
        Arena3: {
            CurrencySlots: (_95 = {},
                _95[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(290) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(320)
                    }, { Weight: 1, Amount: new RndFromInterval(350) },],
                _95),
        },
        Arena4: {
            CurrencySlots: (_96 = {},
                _96[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(300) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(330)
                    }, { Weight: 1, Amount: new RndFromInterval(365) },],
                _96),
        },
        Arena5: {
            CurrencySlots: (_97 = {},
                _97[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(310) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(340)
                    }, { Weight: 1, Amount: new RndFromInterval(375) },],
                _97),
        },
        Arena6: {
            CurrencySlots: (_98 = {},
                _98[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(320) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(350)
                    }, { Weight: 1, Amount: new RndFromInterval(385) },],
                _98),
        },
        Arena7: {
            CurrencySlots: (_99 = {},
                _99[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(330) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(360)
                    }, { Weight: 1, Amount: new RndFromInterval(395) },],
                _99),
        },
        Arena8: {
            CurrencySlots: (_100 = {},
                _100[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(335) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(370)
                    }, { Weight: 1, Amount: new RndFromInterval(405) },],
                _100),
        },
        Arena9: {
            CurrencySlots: (_101 = {},
                _101[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(345) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(380)
                    }, { Weight: 1, Amount: new RndFromInterval(420) },],
                _101),
        },
        Arena10: {
            CurrencySlots: (_102 = {},
                _102[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(355) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(390)
                    }, { Weight: 1, Amount: new RndFromInterval(430) },],
                _102),
        },
    },
    Shards_chest_arena_tutorial: {
        lootSettings: {
            CardsSlots: {
                TotalCards: 0,
                TotalSlots: 0,
                Rarities: (_103 = {},
                    _103[HERO_RARITY.COMMON] = {
                        Slots: 0,
                        ShardsWeight: [{ N: 10, W: 1 }],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES
                    },
                    _103)
            }
        },
    },
    Shards_chest_battlePass_tutorial: {
        lootSettings: {
            AdditionalFixedLoot: {
                Currencies: (_104 = {}, _104[CURRENCY.COIN] = 50, _104)
            },
            CardsSlots: {
                TotalCards: 4,
                TotalSlots: 1,
                Rarities: (_105 = {},
                    _105[HERO_RARITY.COMMON] = {
                        Slots: 1,
                        ShardsWeight: [{ N: 10, W: 1 }],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        CardsWeight: [{ N: 4, W: 1 }]
                    },
                    _105)
            }
        },
    },
    Upgrade_chest: {
        Arena1: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_106 = {},
                    _106[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.COMMON
                    },
                    _106[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.8, N: 1 }, { W: 0.2, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.RARE
                    },
                    _106[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.EPIC
                    },
                    _106[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.93, N: 0 }, { W: 0.07, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _106),
            },
            CurrencySlots: (_107 = {},
                _107[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(40) },
                    { Weight: 0.5, Amount: new RndFromInterval(45) },
                    { Weight: 0.5, Amount: new RndFromInterval(50) },
                ],
                _107),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_108 = {},
                    _108[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.COMMON
                    },
                    _108[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.2, N: 1 }, { W: 0.8, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.RARE
                    },
                    _108[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.67, N: 0 }, { W: 0.33, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.EPIC
                    },
                    _108[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.91, N: 0 }, { W: 0.09, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _108),
            },
            CurrencySlots: (_109 = {},
                _109[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(42) },
                    { Weight: 0.5, Amount: new RndFromInterval(47) },
                    { Weight: 0.5, Amount: new RndFromInterval(52) },
                ],
                _109),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_110 = {},
                    _110[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.COMMON
                    },
                    _110[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0, N: 1 }, { W: 1, N: 2 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.RARE
                    },
                    _110[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.59, N: 0 }, { W: 0.41, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.EPIC
                    },
                    _110[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _110),
            },
            CurrencySlots: (_111 = {},
                _111[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(44) },
                    { Weight: 0.5, Amount: new RndFromInterval(49) },
                    { Weight: 0.5, Amount: new RndFromInterval(54) },
                ],
                _111),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_112 = {},
                    _112[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.COMMON
                    },
                    _112[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.4, N: 2 }, { W: 0.6, N: 3 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.RARE
                    },
                    _112[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.EPIC
                    },
                    _112[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _112),
            },
            CurrencySlots: (_113 = {},
                _113[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(46) },
                    { Weight: 0.5, Amount: new RndFromInterval(51) },
                    { Weight: 0.5, Amount: new RndFromInterval(56) },
                ],
                _113),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_114 = {},
                    _114[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.COMMON
                    },
                    _114[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 2 }, { W: 0.4, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.RARE
                    },
                    _114[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.42, N: 0 }, { W: 0.58, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.EPIC
                    },
                    _114[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _114),
            },
            CurrencySlots: (_115 = {},
                _115[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(48) },
                    { Weight: 0.5, Amount: new RndFromInterval(53) },
                    { Weight: 0.5, Amount: new RndFromInterval(58) },
                ],
                _115),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 13, TotalSlots: 4, Rarities: (_116 = {},
                    _116[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.COMMON
                    },
                    _116[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.35, N: 2 }, { W: 0.65, N: 4 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.RARE
                    },
                    _116[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.33, N: 0 }, { W: 0.67, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.EPIC
                    },
                    _116[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.82, N: 0 }, { W: 0.18, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _116),
            },
            CurrencySlots: (_117 = {},
                _117[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(50) },
                    { Weight: 0.5, Amount: new RndFromInterval(56) },
                    { Weight: 0.5, Amount: new RndFromInterval(62) },
                ],
                _117),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 14, TotalSlots: 4, Rarities: (_118 = {},
                    _118[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.COMMON
                    },
                    _118[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.RARE
                    },
                    _118[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.24, N: 0 }, { W: 0.76, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.EPIC
                    },
                    _118[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.79, N: 0 }, { W: 0.21, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _118),
            },
            CurrencySlots: (_119 = {},
                _119[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(53) },
                    { Weight: 0.5, Amount: new RndFromInterval(59) },
                    { Weight: 0.5, Amount: new RndFromInterval(65) },
                ],
                _119),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 16, TotalSlots: 4, Rarities: (_120 = {},
                    _120[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.COMMON
                    },
                    _120[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.RARE
                    },
                    _120[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.16, N: 0 }, { W: 0.84, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.EPIC
                    },
                    _120[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.77, N: 0 }, { W: 0.23, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _120),
            },
            CurrencySlots: (_121 = {},
                _121[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(56) },
                    { Weight: 0.5, Amount: new RndFromInterval(62) },
                    { Weight: 0.5, Amount: new RndFromInterval(68) },
                ],
                _121),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 17, TotalSlots: 4, Rarities: (_122 = {},
                    _122[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.COMMON
                    },
                    _122[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.4, N: 3 }, { W: 0.6, N: 5 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.RARE
                    },
                    _122[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.08, N: 0 }, { W: 0.92, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.EPIC
                    },
                    _122[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _122),
            },
            CurrencySlots: (_123 = {},
                _123[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(57) },
                    { Weight: 0.5, Amount: new RndFromInterval(64) },
                    { Weight: 0.5, Amount: new RndFromInterval(70) },
                ],
                _123),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 19, TotalSlots: 4, Rarities: (_124 = {},
                    _124[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.COMMON
                    },
                    _124[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.45, N: 3 }, { W: 0.55, N: 6 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.RARE
                    },
                    _124[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0, N: 0 }, { W: 1, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.EPIC
                    },
                    _124[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.73, N: 0 }, { W: 0.27, N: 1 },],
                        ShardsMode: SHARDS_GENERATING_MODE.DUPLICATES,
                        ShardsWeight: duplicatesLootSettings.CommonShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _124),
            },
            CurrencySlots: (_125 = {},
                _125[CURRENCY.COIN] = [
                    { Weight: 0.5, Amount: new RndFromInterval(61) },
                    { Weight: 0.5, Amount: new RndFromInterval(68) },
                    { Weight: 0.5, Amount: new RndFromInterval(75) },
                ],
                _125),
        },
    },
    LegendaryShop: {
        Arena1: {
            CardsSlots: {
                TotalCards: 33, TotalSlots: 3, Rarities: (_126 = {},
                    _126[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 26 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena1.Rarities.RARE
                    },
                    _126[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 3 }, { W: 0.4, N: 5 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena1.Rarities.EPIC
                    },
                    _126[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 0 }, { W: 0.4, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _126),
            },
            CurrencySlots: (_127 = {},
                _127[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(2800) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(3100)
                    }, { Weight: 1, Amount: new RndFromInterval(3400) },],
                _127),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 36, TotalSlots: 3, Rarities: (_128 = {},
                    _128[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 28 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena2.Rarities.COMMON
                    },
                    _128[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 3 }, { W: 0.4, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena2.Rarities.RARE
                    },
                    _128[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 0 }, { W: 0.45, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena2.Rarities.RARE
                    },
                    _128),
            },
            CurrencySlots: (_129 = {},
                _129[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3000) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(3400)
                    }, { Weight: 1, Amount: new RndFromInterval(3700) },],
                _129),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 40, TotalSlots: 3, Rarities: (_130 = {},
                    _130[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 32 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena3.Rarities.RARE
                    },
                    _130[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 4 }, { W: 0.25, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena3.Rarities.EPIC
                    },
                    _130[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _130),
            },
            CurrencySlots: (_131 = {},
                _131[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3300) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(3700)
                    }, { Weight: 1, Amount: new RndFromInterval(4100) },],
                _131),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 43, TotalSlots: 3, Rarities: (_132 = {},
                    _132[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 35 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena4.Rarities.RARE
                    },
                    _132[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 4 }, { W: 0.45, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena4.Rarities.EPIC
                    },
                    _132[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 1 }, { W: 0.1, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _132),
            },
            CurrencySlots: (_133 = {},
                _133[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3600) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(4000)
                    }, { Weight: 1, Amount: new RndFromInterval(4400) },],
                _133),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 45, TotalSlots: 3, Rarities: (_134 = {},
                    _134[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 36 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena5.Rarities.RARE
                    },
                    _134[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 4 }, { W: 0.4, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena5.Rarities.EPIC
                    },
                    _134[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.85, N: 1 }, { W: 0.15, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _134),
            },
            CurrencySlots: (_135 = {},
                _135[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(3900) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(4300)
                    }, { Weight: 1, Amount: new RndFromInterval(4700) },],
                _135),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 50, TotalSlots: 3, Rarities: (_136 = {},
                    _136[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 41 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena6.Rarities.RARE
                    },
                    _136[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 5 }, { W: 0.3, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena6.Rarities.EPIC
                    },
                    _136[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 1 }, { W: 0.25, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _136),
            },
            CurrencySlots: (_137 = {},
                _137[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4100) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(4500)
                    }, { Weight: 1, Amount: new RndFromInterval(4900) },],
                _137),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 53, TotalSlots: 3, Rarities: (_138 = {},
                    _138[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 44 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena7.Rarities.RARE
                    },
                    _138[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 5 }, { W: 0.5, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena7.Rarities.EPIC
                    },
                    _138[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 1 }, { W: 0.35, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _138),
            },
            CurrencySlots: (_139 = {},
                _139[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4400) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(4900)
                    }, { Weight: 1, Amount: new RndFromInterval(5400) },],
                _139),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 55, TotalSlots: 3, Rarities: (_140 = {},
                    _140[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 45 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena8.Rarities.RARE
                    },
                    _140[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 5 }, { W: 0.45, N: 8 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena8.Rarities.EPIC
                    },
                    _140[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 1 }, { W: 0.4, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _140),
            },
            CurrencySlots: (_141 = {},
                _141[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4600) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(5100)
                    }, { Weight: 1, Amount: new RndFromInterval(5600) },],
                _141),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 60, TotalSlots: 3, Rarities: (_142 = {},
                    _142[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 49 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena9.Rarities.RARE
                    },
                    _142[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 6 }, { W: 0.35, N: 8 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena9.Rarities.EPIC
                    },
                    _142[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 1 }, { W: 0.25, N: 3 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _142),
            },
            CurrencySlots: (_143 = {},
                _143[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(4900) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(5400)
                    }, { Weight: 1, Amount: new RndFromInterval(5900) },],
                _143),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 63, TotalSlots: 3, Rarities: (_144 = {},
                    _144[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 51 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena10.Rarities.RARE
                    },
                    _144[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 6 }, { W: 0.35, N: 9 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena10.Rarities.EPIC
                    },
                    _144[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 1 }, { W: 0.3, N: 2 },],
                        ShardsWeight: duplicatesLootSettings.LegendaryShopShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _144),
            },
            CurrencySlots: (_145 = {},
                _145[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5200) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(5700)
                    }, { Weight: 1, Amount: new RndFromInterval(6300) },],
                _145),
        },
    },
    MythicShop: {
        Arena1: {
            CardsSlots: {
                TotalCards: 65, TotalSlots: 3, Rarities: (_146 = {},
                    _146[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 51 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.RARE
                    },
                    _146[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 7 }, { W: 0.5, N: 10 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.EPIC
                    },
                    _146[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 2 }, { W: 0.4, N: 4 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena1.Rarities.LEGENDARY
                    },
                    _146),
            },
            CurrencySlots: (_147 = {},
                _147[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(5800) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(6400)
                    }, { Weight: 1, Amount: new RndFromInterval(7000) },],
                _147),
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 70, TotalSlots: 3, Rarities: (_148 = {},
                    _148[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 54 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.RARE
                    },
                    _148[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 7 }, { W: 0.45, N: 12 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.EPIC
                    },
                    _148[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 4 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena2.Rarities.LEGENDARY
                    },
                    _148),
            },
            CurrencySlots: (_149 = {},
                _149[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(6300) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(7000)
                    }, { Weight: 1, Amount: new RndFromInterval(7700) },],
                _149),
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 75, TotalSlots: 3, Rarities: (_150 = {},
                    _150[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 58 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.RARE
                    },
                    _150[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 8 }, { W: 0.45, N: 13 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.EPIC
                    },
                    _150[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 4 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena3.Rarities.LEGENDARY
                    },
                    _150),
            },
            CurrencySlots: (_151 = {},
                _151[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(6800) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(7600)
                    }, { Weight: 1, Amount: new RndFromInterval(8400) },],
                _151),
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 80, TotalSlots: 3, Rarities: (_152 = {},
                    _152[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 62 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.RARE
                    },
                    _152[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 9 }, { W: 0.5, N: 13 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.EPIC
                    },
                    _152[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 3 }, { W: 0.35, N: 5 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena4.Rarities.LEGENDARY
                    },
                    _152),
            },
            CurrencySlots: (_153 = {},
                _153[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(7500) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(8300)
                    }, { Weight: 1, Amount: new RndFromInterval(91000) },],
                _153),
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 90, TotalSlots: 3, Rarities: (_154 = {},
                    _154[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 70 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.RARE
                    },
                    _154[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 10 }, { W: 0.45, N: 15 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.EPIC
                    },
                    _154[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 3 }, { W: 0.5, N: 5 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena5.Rarities.LEGENDARY
                    },
                    _154),
            },
            CurrencySlots: (_155 = {},
                _155[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(8300) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(9200)
                    }, { Weight: 1, Amount: new RndFromInterval(10000) },],
                _155),
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 100, TotalSlots: 3, Rarities: (_156 = {},
                    _156[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 78 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.RARE
                    },
                    _156[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 11 }, { W: 0.5, N: 16 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.EPIC
                    },
                    _156[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 4 }, { W: 0.25, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena6.Rarities.LEGENDARY
                    },
                    _156),
            },
            CurrencySlots: (_157 = {},
                _157[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(9000) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(10000)
                    }, { Weight: 1, Amount: new RndFromInterval(11000) },],
                _157),
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 105, TotalSlots: 3, Rarities: (_158 = {},
                    _158[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 81 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.RARE
                    },
                    _158[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.55, N: 12 }, { W: 0.45, N: 18 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.EPIC
                    },
                    _158[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 4 }, { W: 0.5, N: 6 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena7.Rarities.LEGENDARY
                    },
                    _158),
            },
            CurrencySlots: (_159 = {},
                _159[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10000) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(11000)
                    }, { Weight: 1, Amount: new RndFromInterval(12000) },],
                _159),
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 89, TotalSlots: 3, Rarities: (_160 = {},
                    _160[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 89 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.RARE
                    },
                    _160[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 13 }, { W: 0.5, N: 19 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.EPIC
                    },
                    _160[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 4 }, { W: 0.4, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena8.Rarities.LEGENDARY
                    },
                    _160),
            },
            CurrencySlots: (_161 = {},
                _161[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(11000) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(12000)
                    }, { Weight: 1, Amount: new RndFromInterval(13000) },],
                _161),
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 125, TotalSlots: 3, Rarities: (_162 = {},
                    _162[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 98 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.RARE
                    },
                    _162[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 14 }, { W: 0.5, N: 20 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.EPIC
                    },
                    _162[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.65, N: 5 }, { W: 0.35, N: 7 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena9.Rarities.LEGENDARY
                    },
                    _162),
            },
            CurrencySlots: (_163 = {},
                _163[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(12000) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(13000)
                    }, { Weight: 1, Amount: new RndFromInterval(14500) },],
                _163),
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 135, TotalSlots: 3, Rarities: (_164 = {},
                    _164[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 105 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.RARE
                    },
                    _164[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 15 }, { W: 0.5, N: 22 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.EPIC
                    },
                    _164[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.6, N: 5 }, { W: 0.4, N: 8 },],
                        ShardsWeight: duplicatesLootSettings.MythicShopShardSettings.Arena10.Rarities.LEGENDARY
                    },
                    _164),
            },
            CurrencySlots: (_165 = {},
                _165[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(12500) }, {
                        Weight: 1,
                        Amount: new RndFromInterval(14000)
                    }, { Weight: 1, Amount: new RndFromInterval(15500) },],
                _165),
        },
    },
    Sakura: {
        Arena1: {
            CardsSlots: {
                TotalCards: 26, TotalSlots: 6, Rarities: (_166 = {},
                    _166[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 26 }, { W: 1, N: 28 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _166),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 28, TotalSlots: 6, Rarities: (_167 = {},
                    _167[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 28 }, { W: 1, N: 30 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _167),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 30, TotalSlots: 6, Rarities: (_168 = {},
                    _168[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 30 }, { W: 1, N: 32 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _168),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 32, TotalSlots: 6, Rarities: (_169 = {},
                    _169[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 32 }, { W: 1, N: 34 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _169),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 34, TotalSlots: 6, Rarities: (_170 = {},
                    _170[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 34 }, { W: 1, N: 36 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _170),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 36, TotalSlots: 6, Rarities: (_171 = {},
                    _171[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 36 }, { W: 1, N: 38 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _171),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 38, TotalSlots: 6, Rarities: (_172 = {},
                    _172[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 38 }, { W: 1, N: 40 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _172),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 40, TotalSlots: 6, Rarities: (_173 = {},
                    _173[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 40 }, { W: 1, N: 42 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _173),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 42, TotalSlots: 6, Rarities: (_174 = {},
                    _174[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 42 }, { W: 1, N: 44 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _174),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 44, TotalSlots: 6, Rarities: (_175 = {},
                    _175[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 1, N: 44 }, { W: 1, N: 46 },],
                        ShardsWeight: shardsLootSettings.MythicShardSettings.Rarities.EPIC
                    },
                    _175),
            },
            CurrencySlots: currencyLootSettings.MythicCurrencySettings,
        },
    },
    Sakura22_chest: {
        Arena1: {
            CardsSlots: {
                TotalCards: 3, TotalSlots: 4, Rarities: (_176 = {},
                    _176[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _176[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _176[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _176[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.95, N: 0 }, { W: 0.05, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _176),
            },
            CurrencySlots: (_177 = {},
                _177[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(30) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(35)
                    }, { Weight: 0.16, Amount: new RndFromInterval(40) },],
                _177[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _177),
            Weapons: {
                Rarities: (_178 = {}, _178[HERO_WEAPON_RARITY.RARE] = 0.2, _178)
            }
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 4, TotalSlots: 4, Rarities: (_179 = {},
                    _179[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _179[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _179[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _179[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.935, N: 0 }, { W: 0.065, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _179),
            },
            CurrencySlots: (_180 = {},
                _180[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(32) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(37)
                    }, { Weight: 0.15, Amount: new RndFromInterval(42) },],
                _180[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _180),
            Weapons: {
                Rarities: (_181 = {}, _181[HERO_WEAPON_RARITY.RARE] = 0.2, _181)
            }
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_182 = {},
                    _182[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _182[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _182[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _182[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.92, N: 0 }, { W: 0.08, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _182),
            },
            CurrencySlots: (_183 = {},
                _183[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(35) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(40)
                    }, { Weight: 0.16, Amount: new RndFromInterval(45) },],
                _183[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _183),
            Weapons: {
                Rarities: (_184 = {}, _184[HERO_WEAPON_RARITY.RARE] = 0.2, _184)
            }
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 6, TotalSlots: 4, Rarities: (_185 = {},
                    _185[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _185[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _185[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _185[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.905, N: 0 }, { W: 0.095, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _185),
            },
            CurrencySlots: (_186 = {},
                _186[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(37) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(42)
                    }, { Weight: 0.16, Amount: new RndFromInterval(47) },],
                _186[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _186),
            Weapons: {
                Rarities: (_187 = {}, _187[HERO_WEAPON_RARITY.RARE] = 0.2, _187)
            }
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_188 = {},
                    _188[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _188[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _188[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _188[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _188),
            },
            CurrencySlots: (_189 = {},
                _189[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(40) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(45)
                    }, { Weight: 0.15, Amount: new RndFromInterval(50) },],
                _189[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _189),
            Weapons: {
                Rarities: (_190 = {}, _190[HERO_WEAPON_RARITY.RARE] = 0.2, _190)
            }
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_191 = {},
                    _191[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _191[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _191[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _191[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.875, N: 0 }, { W: 0.125, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _191),
            },
            CurrencySlots: (_192 = {},
                _192[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(42) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(47)
                    }, { Weight: 0.15, Amount: new RndFromInterval(52) },],
                _192[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _192),
            Weapons: {
                Rarities: (_193 = {}, _193[HERO_WEAPON_RARITY.RARE] = 0.2, _193)
            }
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 4, Rarities: (_194 = {},
                    _194[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _194[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _194[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _194[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _194),
            },
            CurrencySlots: (_195 = {},
                _195[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(45) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(50)
                    }, { Weight: 0.15, Amount: new RndFromInterval(55) },],
                _195[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _195),
            Weapons: {
                Rarities: (_196 = {}, _196[HERO_WEAPON_RARITY.RARE] = 0.2, _196)
            }
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_197 = {},
                    _197[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _197[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _197[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _197[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.845, N: 0 }, { W: 0.155, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _197),
            },
            CurrencySlots: (_198 = {},
                _198[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(47) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(52)
                    }, { Weight: 0.1, Amount: new RndFromInterval(57) },],
                _198[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _198),
            Weapons: {
                Rarities: (_199 = {}, _199[HERO_WEAPON_RARITY.RARE] = 0.2, _199)
            }
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_200 = {},
                    _200[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _200[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _200[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _200[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.83, N: 0 }, { W: 0.17, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _200),
            },
            CurrencySlots: (_201 = {},
                _201[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(50) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(55)
                    }, { Weight: 0.15, Amount: new RndFromInterval(60) },],
                _201[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _201),
            Weapons: {
                Rarities: (_202 = {}, _202[HERO_WEAPON_RARITY.RARE] = 0.2, _202)
            }
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 4, Rarities: (_203 = {},
                    _203[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _203[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _203[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _203[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.815, N: 0 }, { W: 0.185, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _203),
            },
            CurrencySlots: (_204 = {},
                _204[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(52) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(57)
                    }, { Weight: 0.1, Amount: new RndFromInterval(62) },],
                _204[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _204),
            Weapons: {
                Rarities: (_205 = {}, _205[HERO_WEAPON_RARITY.RARE] = 0.2, _205)
            }
        },
    },
    April_chest: {
        Arena1: {
            CardsSlots: {
                TotalCards: 3, TotalSlots: 4, Rarities: (_206 = {},
                    _206[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _206[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _206[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _206[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.95, N: 0 }, { W: 0.05, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _206),
            },
            CurrencySlots: (_207 = {},
                _207[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(30) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(35)
                    }, { Weight: 0.16, Amount: new RndFromInterval(40) },],
                _207[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _207),
            Weapons: {
                Rarities: (_208 = {}, _208[HERO_WEAPON_RARITY.RARE] = 0.2, _208)
            }
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 4, TotalSlots: 4, Rarities: (_209 = {},
                    _209[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _209[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _209[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _209[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.935, N: 0 }, { W: 0.065, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _209),
            },
            CurrencySlots: (_210 = {},
                _210[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(32) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(37)
                    }, { Weight: 0.15, Amount: new RndFromInterval(42) },],
                _210[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _210),
            Weapons: {
                Rarities: (_211 = {}, _211[HERO_WEAPON_RARITY.RARE] = 0.2, _211)
            }
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_212 = {},
                    _212[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _212[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _212[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _212[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.92, N: 0 }, { W: 0.08, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _212),
            },
            CurrencySlots: (_213 = {},
                _213[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(35) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(40)
                    }, { Weight: 0.16, Amount: new RndFromInterval(45) },],
                _213[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _213),
            Weapons: {
                Rarities: (_214 = {}, _214[HERO_WEAPON_RARITY.RARE] = 0.2, _214)
            }
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 6, TotalSlots: 4, Rarities: (_215 = {},
                    _215[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _215[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _215[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _215[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.905, N: 0 }, { W: 0.095, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _215),
            },
            CurrencySlots: (_216 = {},
                _216[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(37) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(42)
                    }, { Weight: 0.16, Amount: new RndFromInterval(47) },],
                _216[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _216),
            Weapons: {
                Rarities: (_217 = {}, _217[HERO_WEAPON_RARITY.RARE] = 0.2, _217)
            }
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_218 = {},
                    _218[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _218[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _218[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _218[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _218),
            },
            CurrencySlots: (_219 = {},
                _219[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(40) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(45)
                    }, { Weight: 0.15, Amount: new RndFromInterval(50) },],
                _219[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _219),
            Weapons: {
                Rarities: (_220 = {}, _220[HERO_WEAPON_RARITY.RARE] = 0.2, _220)
            }
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_221 = {},
                    _221[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _221[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _221[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _221[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.875, N: 0 }, { W: 0.125, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _221),
            },
            CurrencySlots: (_222 = {},
                _222[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(42) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(47)
                    }, { Weight: 0.15, Amount: new RndFromInterval(52) },],
                _222[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _222),
            Weapons: {
                Rarities: (_223 = {}, _223[HERO_WEAPON_RARITY.RARE] = 0.2, _223)
            }
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 4, Rarities: (_224 = {},
                    _224[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _224[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _224[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _224[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _224),
            },
            CurrencySlots: (_225 = {},
                _225[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(45) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(50)
                    }, { Weight: 0.15, Amount: new RndFromInterval(55) },],
                _225[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _225),
            Weapons: {
                Rarities: (_226 = {}, _226[HERO_WEAPON_RARITY.RARE] = 0.2, _226)
            }
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_227 = {},
                    _227[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _227[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _227[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _227[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.845, N: 0 }, { W: 0.155, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _227),
            },
            CurrencySlots: (_228 = {},
                _228[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(47) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(52)
                    }, { Weight: 0.1, Amount: new RndFromInterval(57) },],
                _228[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _228),
            Weapons: {
                Rarities: (_229 = {}, _229[HERO_WEAPON_RARITY.RARE] = 0.2, _229)
            }
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_230 = {},
                    _230[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _230[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _230[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _230[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.83, N: 0 }, { W: 0.17, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _230),
            },
            CurrencySlots: (_231 = {},
                _231[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(50) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(55)
                    }, { Weight: 0.15, Amount: new RndFromInterval(60) },],
                _231[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _231),
            Weapons: {
                Rarities: (_232 = {}, _232[HERO_WEAPON_RARITY.RARE] = 0.2, _232)
            }
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 4, Rarities: (_233 = {},
                    _233[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _233[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _233[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _233[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.815, N: 0 }, { W: 0.185, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _233),
            },
            CurrencySlots: (_234 = {},
                _234[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(52) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(57)
                    }, { Weight: 0.1, Amount: new RndFromInterval(62) },],
                _234[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _234),
            Weapons: {
                Rarities: (_235 = {}, _235[HERO_WEAPON_RARITY.RARE] = 0.2, _235)
            }
        },
    },
    Summer_event_chest: {
        Arena1: {
            CardsSlots: {
                TotalCards: 3, TotalSlots: 4, Rarities: (_236 = {},
                    _236[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _236[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _236[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _236[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.95, N: 0 }, { W: 0.05, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _236),
            },
            CurrencySlots: (_237 = {},
                _237[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(30) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(35)
                    }, { Weight: 0.16, Amount: new RndFromInterval(40) },],
                _237[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _237),
            Weapons: {
                Rarities: (_238 = {}, _238[HERO_WEAPON_RARITY.RARE] = 0.2, _238)
            }
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 4, TotalSlots: 4, Rarities: (_239 = {},
                    _239[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _239[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _239[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _239[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.935, N: 0 }, { W: 0.065, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _239),
            },
            CurrencySlots: (_240 = {},
                _240[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(32) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(37)
                    }, { Weight: 0.15, Amount: new RndFromInterval(42) },],
                _240[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _240),
            Weapons: {
                Rarities: (_241 = {}, _241[HERO_WEAPON_RARITY.RARE] = 0.2, _241)
            }
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_242 = {},
                    _242[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _242[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _242[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _242[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.92, N: 0 }, { W: 0.08, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _242),
            },
            CurrencySlots: (_243 = {},
                _243[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(35) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(40)
                    }, { Weight: 0.16, Amount: new RndFromInterval(45) },],
                _243[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _243),
            Weapons: {
                Rarities: (_244 = {}, _244[HERO_WEAPON_RARITY.RARE] = 0.2, _244)
            }
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 6, TotalSlots: 4, Rarities: (_245 = {},
                    _245[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _245[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _245[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _245[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.905, N: 0 }, { W: 0.095, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _245),
            },
            CurrencySlots: (_246 = {},
                _246[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(37) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(42)
                    }, { Weight: 0.16, Amount: new RndFromInterval(47) },],
                _246[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _246),
            Weapons: {
                Rarities: (_247 = {}, _247[HERO_WEAPON_RARITY.RARE] = 0.2, _247)
            }
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_248 = {},
                    _248[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _248[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _248[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _248[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _248),
            },
            CurrencySlots: (_249 = {},
                _249[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(40) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(45)
                    }, { Weight: 0.15, Amount: new RndFromInterval(50) },],
                _249[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _249),
            Weapons: {
                Rarities: (_250 = {}, _250[HERO_WEAPON_RARITY.RARE] = 0.2, _250)
            }
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_251 = {},
                    _251[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _251[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _251[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _251[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.875, N: 0 }, { W: 0.125, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _251),
            },
            CurrencySlots: (_252 = {},
                _252[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(42) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(47)
                    }, { Weight: 0.15, Amount: new RndFromInterval(52) },],
                _252[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _252),
            Weapons: {
                Rarities: (_253 = {}, _253[HERO_WEAPON_RARITY.RARE] = 0.2, _253)
            }
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 4, Rarities: (_254 = {},
                    _254[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _254[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _254[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _254[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _254),
            },
            CurrencySlots: (_255 = {},
                _255[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(45) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(50)
                    }, { Weight: 0.15, Amount: new RndFromInterval(55) },],
                _255[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _255),
            Weapons: {
                Rarities: (_256 = {}, _256[HERO_WEAPON_RARITY.RARE] = 0.2, _256)
            }
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_257 = {},
                    _257[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _257[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _257[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _257[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.845, N: 0 }, { W: 0.155, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _257),
            },
            CurrencySlots: (_258 = {},
                _258[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(47) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(52)
                    }, { Weight: 0.1, Amount: new RndFromInterval(57) },],
                _258[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _258),
            Weapons: {
                Rarities: (_259 = {}, _259[HERO_WEAPON_RARITY.RARE] = 0.2, _259)
            }
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_260 = {},
                    _260[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _260[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _260[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _260[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.83, N: 0 }, { W: 0.17, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _260),
            },
            CurrencySlots: (_261 = {},
                _261[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(50) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(55)
                    }, { Weight: 0.15, Amount: new RndFromInterval(60) },],
                _261[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _261),
            Weapons: {
                Rarities: (_262 = {}, _262[HERO_WEAPON_RARITY.RARE] = 0.2, _262)
            }
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 4, Rarities: (_263 = {},
                    _263[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _263[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _263[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _263[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.815, N: 0 }, { W: 0.185, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _263),
            },
            CurrencySlots: (_264 = {},
                _264[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(52) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(57)
                    }, { Weight: 0.1, Amount: new RndFromInterval(62) },],
                _264[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _264),
            Weapons: {
                Rarities: (_265 = {}, _265[HERO_WEAPON_RARITY.RARE] = 0.2, _265)
            }
        },
    },
    Halloween_event_chest: {
        Arena1: {
            CardsSlots: {
                TotalCards: 3, TotalSlots: 4, Rarities: (_266 = {},
                    _266[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _266[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.7, N: 0 }, { W: 0.3, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _266[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.9, N: 0 }, { W: 0.1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _266[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.95, N: 0 }, { W: 0.05, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _266),
            },
            CurrencySlots: (_267 = {},
                _267[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(30) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(35)
                    }, { Weight: 0.16, Amount: new RndFromInterval(40) },],
                _267[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _267),
            Weapons: {
                Rarities: (_268 = {}, _268[HERO_WEAPON_RARITY.RARE] = 0.2, _268)
            }
        },
        Arena2: {
            CardsSlots: {
                TotalCards: 4, TotalSlots: 4, Rarities: (_269 = {},
                    _269[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _269[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 0 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _269[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.87, N: 0 }, { W: 0.13, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _269[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.935, N: 0 }, { W: 0.065, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _269),
            },
            CurrencySlots: (_270 = {},
                _270[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(32) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(37)
                    }, { Weight: 0.15, Amount: new RndFromInterval(42) },],
                _270[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _270),
            Weapons: {
                Rarities: (_271 = {}, _271[HERO_WEAPON_RARITY.RARE] = 0.2, _271)
            }
        },
        Arena3: {
            CardsSlots: {
                TotalCards: 5, TotalSlots: 4, Rarities: (_272 = {},
                    _272[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _272[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.3, N: 0 }, { W: 0.7, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _272[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.84, N: 0 }, { W: 0.16, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _272[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.92, N: 0 }, { W: 0.08, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _272),
            },
            CurrencySlots: (_273 = {},
                _273[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(35) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(40)
                    }, { Weight: 0.16, Amount: new RndFromInterval(45) },],
                _273[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _273),
            Weapons: {
                Rarities: (_274 = {}, _274[HERO_WEAPON_RARITY.RARE] = 0.2, _274)
            }
        },
        Arena4: {
            CardsSlots: {
                TotalCards: 6, TotalSlots: 4, Rarities: (_275 = {},
                    _275[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _275[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.1, N: 0 }, { W: 0.9, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _275[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.81, N: 0 }, { W: 0.19, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _275[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.905, N: 0 }, { W: 0.095, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _275),
            },
            CurrencySlots: (_276 = {},
                _276[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(37) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(42)
                    }, { Weight: 0.16, Amount: new RndFromInterval(47) },],
                _276[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _276),
            Weapons: {
                Rarities: (_277 = {}, _277[HERO_WEAPON_RARITY.RARE] = 0.2, _277)
            }
        },
        Arena5: {
            CardsSlots: {
                TotalCards: 7, TotalSlots: 4, Rarities: (_278 = {},
                    _278[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _278[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _278[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.78, N: 0 }, { W: 0.22, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _278[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.89, N: 0 }, { W: 0.11, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _278),
            },
            CurrencySlots: (_279 = {},
                _279[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(40) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(45)
                    }, { Weight: 0.15, Amount: new RndFromInterval(50) },],
                _279[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _279),
            Weapons: {
                Rarities: (_280 = {}, _280[HERO_WEAPON_RARITY.RARE] = 0.2, _280)
            }
        },
        Arena6: {
            CardsSlots: {
                TotalCards: 8, TotalSlots: 4, Rarities: (_281 = {},
                    _281[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _281[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 1 }, { W: 0.5, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _281[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.75, N: 0 }, { W: 0.25, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _281[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.875, N: 0 }, { W: 0.125, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _281),
            },
            CurrencySlots: (_282 = {},
                _282[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(42) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(47)
                    }, { Weight: 0.15, Amount: new RndFromInterval(52) },],
                _282[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _282),
            Weapons: {
                Rarities: (_283 = {}, _283[HERO_WEAPON_RARITY.RARE] = 0.2, _283)
            }
        },
        Arena7: {
            CardsSlots: {
                TotalCards: 9, TotalSlots: 4, Rarities: (_284 = {},
                    _284[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _284[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _284[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.72, N: 0 }, { W: 0.28, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _284[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.86, N: 0 }, { W: 0.14, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _284),
            },
            CurrencySlots: (_285 = {},
                _285[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(45) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(50)
                    }, { Weight: 0.15, Amount: new RndFromInterval(55) },],
                _285[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _285),
            Weapons: {
                Rarities: (_286 = {}, _286[HERO_WEAPON_RARITY.RARE] = 0.2, _286)
            }
        },
        Arena8: {
            CardsSlots: {
                TotalCards: 10, TotalSlots: 4, Rarities: (_287 = {},
                    _287[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _287[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _287[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.69, N: 0 }, { W: 0.31, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _287[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.845, N: 0 }, { W: 0.155, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _287),
            },
            CurrencySlots: (_288 = {},
                _288[CURRENCY.COIN] = [{ Weight: 0.4, Amount: new RndFromInterval(47) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(52)
                    }, { Weight: 0.1, Amount: new RndFromInterval(57) },],
                _288[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _288),
            Weapons: {
                Rarities: (_289 = {}, _289[HERO_WEAPON_RARITY.RARE] = 0.2, _289)
            }
        },
        Arena9: {
            CardsSlots: {
                TotalCards: 11, TotalSlots: 4, Rarities: (_290 = {},
                    _290[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _290[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _290[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.66, N: 0 }, { W: 0.34, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _290[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.83, N: 0 }, { W: 0.17, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _290),
            },
            CurrencySlots: (_291 = {},
                _291[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(50) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(55)
                    }, { Weight: 0.15, Amount: new RndFromInterval(60) },],
                _291[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _291),
            Weapons: {
                Rarities: (_292 = {}, _292[HERO_WEAPON_RARITY.RARE] = 0.2, _292)
            }
        },
        Arena10: {
            CardsSlots: {
                TotalCards: 12, TotalSlots: 4, Rarities: (_293 = {},
                    _293[HERO_RARITY.COMMON] = {
                        Slots: 2,
                        CardsWeight: [{ W: 1, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.COMMON
                    },
                    _293[HERO_RARITY.RARE] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.5, N: 2 }, { W: 0.5, N: 2 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.RARE
                    },
                    _293[HERO_RARITY.EPIC] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.63, N: 0 }, { W: 0.37, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.EPIC
                    },
                    _293[HERO_RARITY.LEGENDARY] = {
                        Slots: 1,
                        CardsWeight: [{ W: 0.815, N: 0 }, { W: 0.185, N: 1 },],
                        ShardsWeight: shardsLootSettings.CommonShardSettings.Rarities.LEGENDARY
                    },
                    _293),
            },
            CurrencySlots: (_294 = {},
                _294[CURRENCY.COIN] = [{ Weight: 0.5, Amount: new RndFromInterval(52) }, {
                        Weight: 0.25,
                        Amount: new RndFromInterval(57)
                    }, { Weight: 0.1, Amount: new RndFromInterval(62) },],
                _294[CURRENCY.BONUS] = [{ Weight: 1, Amount: new RndFromInterval(0, 0) }],
                _294),
            Weapons: {
                Rarities: (_295 = {}, _295[HERO_WEAPON_RARITY.RARE] = 0.2, _295)
            }
        },
    },
};
var templateChestLootSettings = {
    1: { CurrencySlots: (_296 = {}, _296[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _296), },
    2: { CurrencySlots: (_297 = {}, _297[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _297), },
    3: { CurrencySlots: (_298 = {}, _298[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _298), },
    4: { CurrencySlots: (_299 = {}, _299[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _299), },
    5: { CurrencySlots: (_300 = {}, _300[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _300), },
    6: { CurrencySlots: (_301 = {}, _301[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _301), },
    7: { CurrencySlots: (_302 = {}, _302[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _302), },
    8: { CurrencySlots: (_303 = {}, _303[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _303), },
    9: { CurrencySlots: (_304 = {}, _304[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _304), },
    10: { CurrencySlots: (_305 = {}, _305[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(10) }], _305), },
};
function overrideLootSettings(shortLootSettings, TotalCoins, TotalCards) {
    var _a;
    var result = deepCopyOverJSON(shortLootSettings);
    if (TotalCards) {
        if (!result.CardsSlots) {
            CommonUtils.replaceReadOnlyProperty(result, "CardsSlots", {
                TotalCards: TotalCards,
                TotalSlots: 1,
                Rarities: (_a = {},
                    _a[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ N: TotalCards, W: 1 }] },
                    _a)
            });
        }
        CommonUtils.replaceReadOnlyProperty(result.CardsSlots, "TotalCards", TotalCards);
    }
    if (!result.CurrencySlots) {
        CommonUtils.replaceReadOnlyProperty(result, "CurrencySlots", {});
    }
    result.CurrencySlots[CURRENCY.COIN] = [{ Weight: 1, Amount: new RndFromInterval(TotalCoins) }];
    if (result.CurrencySlots[CURRENCY.BONUS]) {
        for (var i in result.CurrencySlots[CURRENCY.BONUS]) {
            var interval = new RndFromInterval(shortLootSettings.CurrencySlots[CURRENCY.BONUS][i].Amount.getMin(), shortLootSettings.CurrencySlots[CURRENCY.BONUS][i].Amount.getMax());
            CommonUtils.replaceReadOnlyProperty(result.CurrencySlots[CURRENCY.BONUS][i], "Amount", interval);
        }
    }
    return result;
}
var lootSettingsFields = [
    "Groups",
    "Weapons",
    "Skins",
    "Stances",
    "Taunts",
    "Emoji",
    "TextEmojiPacks",
    "CurrencySlots",
    "CardsSlots",
    "CustomizationShards",
    "RoguelikeModifiers",
    "AdditionalFixedLoot",
    "Weight"
];
function getLootSettingsAsLazy(getter) {
    var cached = null;
    var target = {};
    var init = function () {
        if (!cached) {
            cached = getter();
            for (var i = 0; i < lootSettingsFields.length; i++) {
                var key = lootSettingsFields[i];
                Object.defineProperty(target, key, {
                    value: cached[key],
                    writable: false,
                    enumerable: true,
                    configurable: true
                });
            }
        }
    };
    var _loop_1 = function (i) {
        var key = lootSettingsFields[i];
        Object.defineProperty(target, key, {
            configurable: true,
            enumerable: true,
            get: function () {
                init();
                return cached[key];
            }
        });
    };
    for (var i = 0; i < lootSettingsFields.length; i++) {
        _loop_1(i);
    }
    return target;
}
var advancedLootSettings = {};
