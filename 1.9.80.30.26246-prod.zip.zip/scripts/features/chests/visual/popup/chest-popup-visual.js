var _a;
var ChestPopupVisual = (function () {
    function ChestPopupVisual() {
    }
    ChestPopupVisual.rarities = (_a = {},
        _a[CHEST_TYPE.COMMON] = {
            alias: "common",
            color: "#97AEB8", darkColor: "#4B575C", mediumColor: "#8498A1",
            titleColor: "#97AEB8", decorColor: "#97AEB8", decorLinesColor: "#97AEB8", bgColor: "#97AEB8",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#546973" }, { time: 1, color: "#384145" }],
            },
        },
        _a[CHEST_TYPE.RARE] = {
            alias: "rare",
            color: "#8CBAFF", darkColor: "#495A73", mediumColor: "#93B4E5",
            titleColor: "#8CBAFF", decorColor: "#8CBAFF", decorLinesColor: "#8CBAFF", bgColor: "#495A73",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#4C658A" }, { time: 1, color: "#434D5C" }],
            },
        },
        _a[CHEST_TYPE.EPIC] = {
            alias: "epic",
            color: "#C68CFF", darkColor: "#5E4973", mediumColor: "#BC93E5",
            titleColor: "#C68CFF", decorColor: "#C68CFF", decorLinesColor: "#C68CFF", bgColor: "#4F435C",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#6B4C8A" }, { time: 1, color: "#434D5C" }],
            },
        },
        _a[CHEST_TYPE.LEGENDARY] = {
            alias: "legendary",
            color: "#FFD75E", darkColor: "#736335", mediumColor: "#E5C76A",
            titleColor: "#FFD75E", decorColor: "#FFD75E", decorLinesColor: "#FFD75E", bgColor: "#FFD75E",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#8A7433" }, { time: 1, color: "#5C5132" }],
            },
        },
        _a[CHEST_TYPE.MYTHIC] = {
            alias: "mythic",
            color: "#5EE7FF", darkColor: "#547373", mediumColor: "#86B8B8",
            titleColor: "#5EE7FF", decorColor: "#5EE7FF", decorLinesColor: "#5EE7FF", bgColor: "#356973",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#337D8A" }, { time: 1, color: "#32565C" }],
            },
        },
        _a[CHEST_TYPE.UNKNOWN] = {
            alias: "emoji_chest",
            color: "#55E5BA", darkColor: "#349075", mediumColor: "#4FC09F",
            titleColor: "#55E5BA", decorColor: "#55E5BA", decorLinesColor: "#55E5BA", bgColor: "#55E5BA",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#35876E" }, { time: 1, color: "#357360" }],
            },
        },
        _a[CHEST_TYPE.EMOJI_CHEST] = {
            alias: "extra_chest_rarity1",
            color: "#55E5BA", darkColor: "#349075", mediumColor: "#4FC09F",
            titleColor: "#55E5BA", decorColor: "#55E5BA", decorLinesColor: "#55E5BA", bgColor: "#55E5BA",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#892D2D" }, { time: 1, color: "#6F4848" }],
            },
        },
        _a[CHEST_TYPE.HALLOWEEN_CHEST] = {
            alias: "mystic_chest",
            "color": "#65B894",
            "darkColor": "#3f8a68",
            "mediumColor": "#76b89a",
            "titleColor": "#1aff98",
            "decorColor": "#1aff98",
            "decorLinesColor": "#1aff98",
            "bgColor": "#166573",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 1,
                        "color": "#435C51"
                    },
                    {
                        "time": 0,
                        "color": "#4C8A6E"
                    }
                ],
            },
        },
        _a[CHEST_TYPE.EXTRA_CHEST_RARITY_3] = {
            alias: "april_event_chest",
            color: "#C68CFF", darkColor: "#5E4873", mediumColor: "#BD93E6",
            titleColor: "#C68CFF", decorColor: "#C68CFF", decorLinesColor: "#C68CFF", bgColor: "#593F73",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#6B4C8A" }, { time: 1, color: "#4F435C" }],
            },
        },
        _a[CHEST_TYPE.GOLD_CHEST] = {
            alias: "common",
            color: "#e5c493", darkColor: "#736654", mediumColor: "#e5c493",
            titleColor: "#e5c493", decorColor: "#e5c493", decorLinesColor: "#e5c493", bgColor: "#736654",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#8a7b65" }, { time: 1, color: "#5c554b" }],
            },
        },
        _a[CHEST_TYPE.WEAPON_PVE] = {
            alias: "weapon_chest_short",
            color: "#B6FFA3", darkColor: "#527349", mediumColor: "#B6FFA3",
            titleColor: "#E5C493", decorColor: "#E5C493", decorLinesColor: "#B6FFA3", bgColor: "#527349",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#485C43" }, { time: 0, color: "#628A58" }],
            },
        },
        _a[CHEST_TYPE.SKIN_PVE] = {
            alias: "skins_chest_short",
            color: "#FF9F75", darkColor: "#734F3F", mediumColor: "#FF9F75",
            titleColor: "#FFD75E", decorColor: "#FFD75E", decorLinesColor: "#FF9F75", bgColor: "#734735",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#5C453B" }, { time: 0, color: "#8A563F" }],
            },
        },
        _a[CHEST_TYPE.ANIMATION_PVE] = {
            alias: "poses_chest_short",
            color: "#FFA3E8", darkColor: "#73546B", mediumColor: "#FFA3E8",
            titleColor: "#FFD75E", decorColor: "#FFD75E", decorLinesColor: "#FFA3E8", bgColor: "#734968",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#5C4B58" }, { time: 0, color: "#8A587D" }],
            },
        },
        _a[CHEST_TYPE.SHARDS_CHEST] = {
            alias: "shards_chest_tier3",
            color: "#928CFF", darkColor: "#4C4973", mediumColor: "#928CFF",
            titleColor: "#A8A3FF", decorColor: "#A8A3FF", decorLinesColor: "#928CFF", bgColor: "#423F73",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#44435C" }, { time: 0, color: "#4F4C8A" }],
            },
        },
        _a[CHEST_TYPE.SHARD_NEW_HERO] = {
            alias: "shards_chest_tier4",
            color: "#FFD75E", darkColor: "#736335", mediumColor: "#928CFF",
            titleColor: "#FFD75E", decorColor: "#FFD75E", decorLinesColor: "#FFD75E", bgColor: "#736335",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#5C5132" }, { time: 0, color: "#8A7433" }],
            },
        },
        _a[CHEST_TYPE.SHARD_MIDLE_CHEST] = {
            alias: "shards_chest_tier2",
            color: "#8CBAFF", darkColor: "#4B575C", mediumColor: "#928CFF",
            titleColor: "#8CBAFF", decorColor: "#8CBAFF", decorLinesColor: "#8CBAFF", bgColor: "#495A73",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#434D5C" }, { time: 0, color: "#4C658A" }],
            },
        },
        _a[CHEST_TYPE.SHARD_MINI_CHEST] = {
            alias: "shards_chest_tier1",
            color: "#97AEB8", darkColor: "#4B575C", mediumColor: "#928CFF",
            titleColor: "#97AEB8", decorColor: "#97AEB8", decorLinesColor: "#97AEB8", bgColor: "#4B575C",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 1, color: "#384145" }, { time: 0, color: "#546973" }],
            },
        },
        _a[CHEST_TYPE.UPGRADE_CHEST] = {
            alias: "ruby_chest",
            color: "#97AEB8", darkColor: "#4b575c", mediumColor: "#8498A1",
            titleColor: "#E5C493", decorColor: "#E5C493", decorLinesColor: "#97AEB8", bgColor: "#4B575C",
            bgGradient: {
                mode: 0,
                alphaKeys: [{ time: 0, alpha: 1 }, { time: 1, alpha: 1 }],
                colorKeys: [{ time: 0, color: "#546973" }, { time: 1, color: "#384145" }],
            },
        },
        _a[CHEST_TYPE.WEAPON_CHEST_ARENA_BIRTHDAY] = {
            "alias": "shards_chest_tier3",
            "color": "#FFACA3",
            "darkColor": "#9D493F",
            "mediumColor": "#928CFF",
            "titleColor": "#FF6E5E",
            "decorColor": "#FF6E5E",
            "decorLinesColor": "#FF6E5E",
            "bgColor": "#933E34",
            "bgGradient": {
                "mode": 0, "alphaKeys": [{ "time": 0, "alpha": 1 }, { "time": 1, "alpha": 1 }],
                "colorKeys": [{ "time": 1, "color": "#5C4343" }, { "time": 0, "color": "#8A4C4C" }]
            }
        },
        _a[CHEST_TYPE.STAR] = {
            "alias": "shards_chest_tier3",
            "color": "#9340e5",
            "darkColor": "#7633b8",
            "mediumColor": "#ba75ff",
            "titleColor": "#a347ff",
            "decorColor": "#a347ff",
            "decorLinesColor": "#a347ff",
            "bgColor": "#58278a",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [{ "time": 0, "alpha": 1 }, { "time": 1, "alpha": 1 }],
                "colorKeys": [{ "time": 1, "color": "#44435C" }, { "time": 0, "color": "#58278a" }]
            }
        },
        _a[CHEST_TYPE.ROGUELIKE_ROULETTE_CHEST] = {
            "alias": "shards_chest_tier5",
            "color": "#93e5d9",
            "darkColor": "#76b8ae",
            "mediumColor": "#a3fff1",
            "titleColor": "#a3fff1",
            "decorColor": "#a3fff1",
            "decorLinesColor": "#a3fff1",
            "bgColor": "#588a82",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [{ "time": 0, "alpha": 1 }, { "time": 1, "alpha": 1 }],
                "colorKeys": [{ "time": 1, "color": "#588a82" }, { "time": 0, "color": "#76b8ae" }]
            }
        },
        _a[CHEST_TYPE.EXTRA_SMALL_SHARDS_CHEST] = {
            "alias": "shards_chest_tier6",
            "color": "#758da1", "darkColor": "#43515c", "mediumColor": "#758da1",
            "titleColor": "#97AEB8", "decorColor": "#758da1", "decorLinesColor": "#86a1b8", "bgColor": "#758da1",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [{ "time": 0, "alpha": 1 }, { "time": 1, "alpha": 1 }],
                "colorKeys": [{ "time": 1, "color": "#758da1" }, { "time": 0, "color": "#43515c" }]
            }
        },
        _a[CHEST_TYPE.COBRA_CHEST] = {
            "alias": "viper_event73_chest",
            "color": "#00a189",
            "darkColor": "#005c4e",
            "mediumColor": "#00a189",
            "titleColor": "#15cfb3",
            "decorColor": "#15cfb3",
            "decorLinesColor": "#00a189",
            "bgColor": "#008a75",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 1,
                        "color": "#005c4e"
                    },
                    {
                        "time": 0,
                        "color": "#005c4e"
                    }
                ]
            }
        },
        _a[CHEST_TYPE.BUTCHER_SHARD_WEAPON_CHEST] = {
            "alias": "leg_weapon_shard_chest",
            "color": "#e5c155",
            "darkColor": "#5c4709",
            "mediumColor": "#b89b44",
            "titleColor": "#e5c155",
            "decorColor": "#e5c155",
            "decorLinesColor": "#8a6b0e",
            "bgColor": "#5c4709",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 1,
                        "color": "#8a6b0e"
                    },
                    {
                        "time": 0,
                        "color": "#8a6b0e"
                    }
                ]
            }
        },
        _a[CHEST_TYPE.SHARDS_CHEST_SHOP] = {
            "alias": "shards_chest_tier3",
            "color": "#73202d",
            "darkColor": "#73202d",
            "mediumColor": "#73202d",
            "titleColor": "#ff6347",
            "decorColor": "#ff6347",
            "decorLinesColor": "#ff6347",
            "bgColor": "#73202d",
            "bgGradient": {
                "mode": 0,
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ],
                "colorKeys": [
                    {
                        "time": 1,
                        "color": "#73202d"
                    },
                    {
                        "time": 0,
                        "color": "#73202d"
                    }
                ]
            }
        },
        _a);
    return ChestPopupVisual;
}());
