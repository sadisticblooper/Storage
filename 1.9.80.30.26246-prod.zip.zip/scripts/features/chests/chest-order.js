var ChestWheels = (function () {
    function ChestWheels() {
    }
    Object.defineProperty(ChestWheels, "SPLength", {
        get: function () {
            return ChestWheels.starterPoints.length;
        },
        enumerable: false,
        configurable: true
    });
    ChestWheels.initChestStarterPoint = function () {
        return Math.floor(Math.random() * ChestWheels.SPLength);
    };
    ChestWheels.getChestID = function (chestIndex, starterPointNumber) {
        if (chestIndex < 0) {
            throw "getLobbyChestID exception: chestIndex can not be negative";
        }
        if (starterPointNumber < 0) {
            throw "getLobbyChestID exception: starterPointNumber can not be negative";
        }
        if (ChestWheels.chestIdRewrite.hasOwnProperty(String(chestIndex))) {
            return ChestWheels.chestIdRewrite[chestIndex];
        }
        if (starterPointNumber >= ChestWheels.SPLength) {
            starterPointNumber = starterPointNumber % ChestWheels.SPLength;
        }
        var stPoint = ChestWheels.starterPoints[starterPointNumber];
        var realChestIndex = chestIndex + stPoint.ChIndex;
        var wheelIndex = stPoint.WhIndex;
        var cycledChestIndex = realChestIndex % ChestWheels.chestWheels[wheelIndex].length;
        return ChestWheels.chestWheels[wheelIndex][cycledChestIndex];
    };
    ChestWheels.testRepeatInRewrite = function () {
        var ids = [];
        for (var index in ChestWheels.chestIdRewrite) {
            var id = ChestWheels.chestIdRewrite[index];
            if (ids.indexOf(id) > -1) {
                throw new Error("Repeat in rewrite chests! Please, make copy of chest with ID ".concat(id, " and add other ID to ChestWheels.chestIdRewrite"));
            }
            ids.push(id);
        }
    };
    ChestWheels.chestIndexToID = {
        0: chests.Common_chest.ID,
        1: chests.Rare_chest.ID,
        2: chests.Epic_chest.ID,
        3: chests.Gold_chest.ID,
        4: chests.Small_Shard_Chest.ID
    };
    ChestWheels.chestWheelsConfig = [
        [1, 4, 1, 3, 1, 4, 2, 3],
    ];
    ChestWheels.starterPoints = [
        { WhIndex: 0, ChIndex: 0 },
    ];
    ChestWheels.chestIdRewrite = {
        0: chests.Common_override_for_lobby_chest.ID,
        1: chests.Epic_override_for_lobby_chest.ID,
        2: chests.Rare_override_for_lobby_chest.ID,
    };
    ChestWheels.chestWheels = ChestWheels.chestWheelsConfig.map(function (queue) {
        return queue.map(function (e) {
            return ChestWheels.chestIndexToID[e];
        });
    });
    return ChestWheels;
}());
