var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29;
var chests = (function () {
    function chests() {
    }
    chests.Common_chest = new Chest({
        ID: 1,
        UseAdvertising: true,
        PopupShow: true,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        RoundsToUnlock: 2,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Common.Arena1,
            2: chestLootSettings.Common.Arena2,
            3: chestLootSettings.Common.Arena3,
            4: chestLootSettings.Common.Arena4,
            5: chestLootSettings.Common.Arena5,
            6: chestLootSettings.Common.Arena6,
            7: chestLootSettings.Common.Arena7,
            8: chestLootSettings.Common.Arena8,
            9: chestLootSettings.Common.Arena9,
            10: chestLootSettings.Common.Arena10
        }
    });
    chests.Rare_chest = new Chest({
        ID: 2,
        UseAdvertising: true,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        PopupShow: true,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        RoundsToUnlock: 3,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Rare.Arena1,
            2: chestLootSettings.Rare.Arena2,
            3: chestLootSettings.Rare.Arena3,
            4: chestLootSettings.Rare.Arena4,
            5: chestLootSettings.Rare.Arena5,
            6: chestLootSettings.Rare.Arena6,
            7: chestLootSettings.Rare.Arena7,
            8: chestLootSettings.Rare.Arena8,
            9: chestLootSettings.Rare.Arena9,
            10: chestLootSettings.Rare.Arena10,
        }
    });
    chests.Epic_chest = new Chest({
        ID: 3,
        UseAdvertising: true,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        PopupShow: true,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        RoundsToUnlock: 5,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Epic.Arena1,
            2: chestLootSettings.Epic.Arena2,
            3: chestLootSettings.Epic.Arena3,
            4: chestLootSettings.Epic.Arena4,
            5: chestLootSettings.Epic.Arena5,
            6: chestLootSettings.Epic.Arena6,
            7: chestLootSettings.Epic.Arena7,
            8: chestLootSettings.Epic.Arena8,
            9: chestLootSettings.Epic.Arena9,
            10: chestLootSettings.Epic.Arena10
        }
    });
    chests.Legendary_chest = new Chest({
        ID: 6,
        UseAdvertising: true,
        PopupShow: true,
        Alias: "legendary_chest",
        AliasShort: "legendary_chest_short",
        Type: CHEST_TYPE.LEGENDARY,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Legendary",
        RoundsToUnlock: 12,
        LootSettings: {
            1: chestLootSettings.Legendary.Arena1,
            2: chestLootSettings.Legendary.Arena2,
            3: chestLootSettings.Legendary.Arena3,
            4: chestLootSettings.Legendary.Arena4,
            5: chestLootSettings.Legendary.Arena5,
            6: chestLootSettings.Legendary.Arena6,
            7: chestLootSettings.Legendary.Arena7,
            8: chestLootSettings.Legendary.Arena8,
            9: chestLootSettings.Legendary.Arena9,
            10: chestLootSettings.Legendary.Arena10
        }
    });
    chests.Mythic_chest = new Chest({
        ID: 205,
        UseAdvertising: true,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        PopupShow: true,
        Alias: "mythic_chest",
        AliasShort: "mythic_chest_short",
        Type: CHEST_TYPE.MYTHIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Mythic",
        RoundsToUnlock: 7,
        LootSettings: {
            1: chestLootSettings.Mythic.Arena1,
            2: chestLootSettings.Mythic.Arena2,
            3: chestLootSettings.Mythic.Arena3,
            4: chestLootSettings.Mythic.Arena4,
            5: chestLootSettings.Mythic.Arena5,
            6: chestLootSettings.Mythic.Arena6,
            7: chestLootSettings.Mythic.Arena7,
            8: chestLootSettings.Mythic.Arena8,
            9: chestLootSettings.Mythic.Arena9,
            10: chestLootSettings.Mythic.Arena10
        }
    });
    chests.Large_Shard_Chest = new Chest({
        ID: 5,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier3",
        AliasShort: "shards_chest_tier3_short",
        Type: CHEST_TYPE.SHARDS_CHEST_SHOP,
        EffectName: "SHARDS_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_shards_shop",
        RoundsToUnlock: 7,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.RANDOM,
        ShardsModeDistribution: (_a = {}, _a[SHARDS_GENERATING_MODE.DUPLICATES] = 8, _a[SHARDS_GENERATING_MODE.SHARDS] = 2, _a),
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Medium_Shard_Chest = new Chest({
        ID: 505,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier2",
        AliasShort: "shards_chest_tier2_short",
        Type: CHEST_TYPE.SHARD_MIDLE_CHEST,
        EffectName: "SHARD_MIDLE_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_midle",
        RoundsToUnlock: 7,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.RANDOM,
        ShardsModeDistribution: (_b = {}, _b[SHARDS_GENERATING_MODE.DUPLICATES] = 8, _b[SHARDS_GENERATING_MODE.SHARDS] = 2, _b),
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Small_Shard_Chest = new Chest({
        ID: 504,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier1",
        AliasShort: "shards_chest_tier1_short",
        Type: CHEST_TYPE.SHARD_MINI_CHEST,
        EffectName: "SHARD_MINI_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_mini",
        RoundsToUnlock: 3,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.RANDOM,
        ShardsModeDistribution: (_c = {}, _c[SHARDS_GENERATING_MODE.DUPLICATES] = 8, _c[SHARDS_GENERATING_MODE.SHARDS] = 2, _c),
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Emoji_chest = new Chest({
        ID: 1007,
        UseAdvertising: true,
        Alias: "emoji_chest",
        AliasShort: "emoji_chest_short",
        Type: CHEST_TYPE.EMOJI_CHEST,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Emoji",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.EMOTES,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10
        }
    });
    chests.Skin_chest = new Chest({
        ID: 2203,
        UseAdvertising: true,
        Alias: "skins_chest",
        AliasShort: "skins_chest_short",
        Type: CHEST_TYPE.SKIN_PVE,
        EffectName: "SKIN_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Skin",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10
        }
    });
    chests.Season_skin_chest = new Chest({
        ID: 303,
        UseAdvertising: true,
        Alias: "skins_chest",
        AliasShort: "skins_chest_short",
        Type: CHEST_TYPE.SKIN_PVE,
        EffectName: "SKIN_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Skin",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SKINS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10
        }
    });
    chests.Weapon_chest = new Chest({
        ID: 2204,
        UseAdvertising: true,
        Alias: "weapon_chest",
        AliasShort: "weapon_chest_short",
        Type: CHEST_TYPE.WEAPON_PVE,
        EffectName: "WEAPON_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Weapon",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.WEAPONS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10
        }
    });
    chests.Animation_chest = new Chest({
        ID: 2205,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "poses_chest",
        AliasShort: "poses_chest_short",
        Type: CHEST_TYPE.ANIMATION_PVE,
        EffectName: "ANIMATION_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Animation",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [
                CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS,
            ],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10,
        }
    });
    chests.Large_Shard_Chest_New_Hero = new Chest({
        ID: 2209,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier4",
        AliasShort: "shards_chest_tier4_short",
        Type: CHEST_TYPE.SHARD_NEW_HERO,
        EffectName: "SHARDS_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_New_White",
        RoundsToUnlock: 7,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.SHARDS,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Large_Shard_Chest_Duplicate = new Chest({
        ID: 2210,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier3",
        AliasShort: "shards_chest_tier3_short",
        Type: CHEST_TYPE.SHARDS_CHEST,
        EffectName: "SHARDS_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_New",
        RoundsToUnlock: 7,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.DUPLICATES,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Extra_Small_Shard_Chest = new Chest({
        ID: 1002,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier6",
        AliasShort: "shards_chest_tier6_short",
        Type: CHEST_TYPE.EXTRA_SMALL_SHARDS_CHEST,
        EffectName: "SHARD_MINI_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_shards_cheap",
        RoundsToUnlock: 3,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.RANDOM,
        ShardsModeDistribution: (_d = {}, _d[SHARDS_GENERATING_MODE.DUPLICATES] = 8, _d[SHARDS_GENERATING_MODE.SHARDS] = 2, _d),
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Gold_chest = new Chest({
        ID: 2200,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "gold_chest",
        AliasShort: "gold_chest_short",
        Type: CHEST_TYPE.GOLD_CHEST,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Gold",
        RoundsToUnlock: 3,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Gold_chest.Arena1,
            2: chestLootSettings.Gold_chest.Arena2,
            3: chestLootSettings.Gold_chest.Arena3,
            4: chestLootSettings.Gold_chest.Arena4,
            5: chestLootSettings.Gold_chest.Arena5,
            6: chestLootSettings.Gold_chest.Arena6,
            7: chestLootSettings.Gold_chest.Arena7,
            8: chestLootSettings.Gold_chest.Arena8,
            9: chestLootSettings.Gold_chest.Arena9,
            10: chestLootSettings.Gold_chest.Arena10
        }
    });
    chests.Common_override_for_lobby_chest = new Chest({
        ID: 2201,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        RoundsToUnlock: 3,
        TimeToUnlock: new Time({ Seconds: 0 }).value,
        LootSettings: {
            1: chestLootSettings.Common.Arena1,
            2: chestLootSettings.Common.Arena2,
            3: chestLootSettings.Common.Arena3,
            4: chestLootSettings.Common.Arena4,
            5: chestLootSettings.Common.Arena5,
            6: chestLootSettings.Common.Arena6,
            7: chestLootSettings.Common.Arena7,
            8: chestLootSettings.Common.Arena8,
            9: chestLootSettings.Common.Arena9,
            10: chestLootSettings.Common.Arena10
        }
    });
    chests.Rare_override_for_lobby_chest = new Chest({
        ID: 2202,
        UseAdvertising: true,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        RoundsToUnlock: 3,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Rare.Arena1,
            2: chestLootSettings.Rare.Arena2,
            3: chestLootSettings.Rare.Arena3,
            4: chestLootSettings.Rare.Arena4,
            5: chestLootSettings.Rare.Arena5,
            6: chestLootSettings.Rare.Arena6,
            7: chestLootSettings.Rare.Arena7,
            8: chestLootSettings.Rare.Arena8,
            9: chestLootSettings.Rare.Arena9,
            10: chestLootSettings.Rare.Arena10,
        }
    });
    chests.Epic_override_for_lobby_chest = new Chest({
        ID: 1004,
        UseAdvertising: true,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        RoundsToUnlock: 5,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Epic.Arena1,
            2: chestLootSettings.Epic.Arena2,
            3: chestLootSettings.Epic.Arena3,
            4: chestLootSettings.Epic.Arena4,
            5: chestLootSettings.Epic.Arena5,
            6: chestLootSettings.Epic.Arena6,
            7: chestLootSettings.Epic.Arena7,
            8: chestLootSettings.Epic.Arena8,
            9: chestLootSettings.Epic.Arena9,
            10: chestLootSettings.Epic.Arena10
        }
    });
    chests.PVE_roulette_chest = new Chest({
        ID: 1003,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "shards_chest_tier5",
        AliasShort: "shards_chest_tier5_short ",
        Type: CHEST_TYPE.ROGUELIKE_ROULETTE_CHEST,
        EffectName: "SHARD_MINI_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_shards_pve",
        RoundsToUnlock: 7,
        ShardsGeneratingMode: SHARDS_GENERATING_MODE.DUPLICATES,
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        LootSettings: {
            1: chestLootSettings.ShardsChest.Arena1,
            2: chestLootSettings.ShardsChest.Arena2,
            3: chestLootSettings.ShardsChest.Arena3,
            4: chestLootSettings.ShardsChest.Arena4,
            5: chestLootSettings.ShardsChest.Arena5,
            6: chestLootSettings.ShardsChest.Arena6,
            7: chestLootSettings.ShardsChest.Arena7,
            8: chestLootSettings.ShardsChest.Arena8,
            9: chestLootSettings.ShardsChest.Arena9,
            10: chestLootSettings.ShardsChest.Arena10
        }
    });
    chests.Shards_chest_arena_tutorial = new Chest({
        ID: 1009,
        UseAdvertising: false,
        PopupShow: false,
        Alias: "shards_chest_tier4",
        AliasShort: "shards_chest_tier4_short",
        Type: CHEST_TYPE.SHARD_NEW_HERO,
        EffectName: "SHARDS_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_New_White",
        RoundsToUnlock: 7,
        LootSettings: {
            1: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            2: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            3: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            4: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            5: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            6: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            7: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            8: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            9: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
            10: chestLootSettings.Shards_chest_arena_tutorial.lootSettings,
        }
    });
    chests.Shards_chest_battlePass_tutorial = new Chest({
        ID: 2000,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "shards_chest",
        AliasShort: "shards_chest_short",
        Type: CHEST_TYPE.COMMON,
        EffectName: "SHARDS_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards_New",
        TimeToUnlock: 0,
        RoundsToUnlock: 6,
        LootSettings: {
            1: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            2: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            3: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            4: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            5: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            6: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            7: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            8: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            9: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings,
            10: chestLootSettings.Shards_chest_battlePass_tutorial.lootSettings
        }
    });
    chests.Shards_chest_Sarge = ChestUtils.reuseChest({
        origin: chests.Large_Shard_Chest_New_Hero,
        newId: 2108,
        replace: {
            AliasShort: "new_hero",
            TooltipProbabilitySettings: {
                items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
                dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            },
            LootSettings: {
                1: __assign(__assign({}, chestLootSettings.ShardsChest.Arena1), { AdditionalFixedLoot: { Shards: (_e = {}, _e[HeroNames.Sarge.ID] = 10, _e) } }),
                2: __assign(__assign({}, chestLootSettings.ShardsChest.Arena2), { AdditionalFixedLoot: { Shards: (_f = {}, _f[HeroNames.Sarge.ID] = 10, _f) } }),
                3: __assign(__assign({}, chestLootSettings.ShardsChest.Arena3), { AdditionalFixedLoot: { Shards: (_g = {}, _g[HeroNames.Sarge.ID] = 10, _g) } }),
                4: __assign(__assign({}, chestLootSettings.ShardsChest.Arena4), { AdditionalFixedLoot: { Shards: (_h = {}, _h[HeroNames.Sarge.ID] = 10, _h) } }),
                5: __assign(__assign({}, chestLootSettings.ShardsChest.Arena5), { AdditionalFixedLoot: { Shards: (_j = {}, _j[HeroNames.Sarge.ID] = 10, _j) } }),
                6: __assign(__assign({}, chestLootSettings.ShardsChest.Arena6), { AdditionalFixedLoot: { Shards: (_k = {}, _k[HeroNames.Sarge.ID] = 10, _k) } }),
                7: __assign(__assign({}, chestLootSettings.ShardsChest.Arena7), { AdditionalFixedLoot: { Shards: (_l = {}, _l[HeroNames.Sarge.ID] = 10, _l) } }),
                8: __assign(__assign({}, chestLootSettings.ShardsChest.Arena8), { AdditionalFixedLoot: { Shards: (_m = {}, _m[HeroNames.Sarge.ID] = 10, _m) } }),
                9: __assign(__assign({}, chestLootSettings.ShardsChest.Arena9), { AdditionalFixedLoot: { Shards: (_o = {}, _o[HeroNames.Sarge.ID] = 10, _o) } }),
                10: __assign(__assign({}, chestLootSettings.ShardsChest.Arena10), { AdditionalFixedLoot: { Shards: (_p = {}, _p[HeroNames.Sarge.ID] = 10, _p) } }),
            }
        },
    });
    chests.Shards_chest_Sarge_alias_v2 = ChestUtils.reuseChest({
        origin: chests.Shards_chest_Sarge,
        newId: 2001,
        replace: {
            AliasShort: "shards_chest_tier4_short",
        },
    });
    chests.Shards_chest_Feldsher = ChestUtils.reuseChest({
        origin: chests.Large_Shard_Chest_New_Hero,
        newId: 2110,
        replace: {
            AliasShort: "new_hero",
            TooltipProbabilitySettings: {
                items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
                dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            },
            LootSettings: {
                1: __assign(__assign({}, chestLootSettings.ShardsChest.Arena1), { AdditionalFixedLoot: { Shards: (_q = {}, _q[HeroNames.Feldsher.ID] = 10, _q) } }),
                2: __assign(__assign({}, chestLootSettings.ShardsChest.Arena2), { AdditionalFixedLoot: { Shards: (_r = {}, _r[HeroNames.Feldsher.ID] = 10, _r) } }),
                3: __assign(__assign({}, chestLootSettings.ShardsChest.Arena3), { AdditionalFixedLoot: { Shards: (_s = {}, _s[HeroNames.Feldsher.ID] = 10, _s) } }),
                4: __assign(__assign({}, chestLootSettings.ShardsChest.Arena4), { AdditionalFixedLoot: { Shards: (_t = {}, _t[HeroNames.Feldsher.ID] = 10, _t) } }),
                5: __assign(__assign({}, chestLootSettings.ShardsChest.Arena5), { AdditionalFixedLoot: { Shards: (_u = {}, _u[HeroNames.Feldsher.ID] = 10, _u) } }),
                6: __assign(__assign({}, chestLootSettings.ShardsChest.Arena6), { AdditionalFixedLoot: { Shards: (_v = {}, _v[HeroNames.Feldsher.ID] = 10, _v) } }),
                7: __assign(__assign({}, chestLootSettings.ShardsChest.Arena7), { AdditionalFixedLoot: { Shards: (_w = {}, _w[HeroNames.Feldsher.ID] = 10, _w) } }),
                8: __assign(__assign({}, chestLootSettings.ShardsChest.Arena8), { AdditionalFixedLoot: { Shards: (_x = {}, _x[HeroNames.Feldsher.ID] = 10, _x) } }),
                9: __assign(__assign({}, chestLootSettings.ShardsChest.Arena9), { AdditionalFixedLoot: { Shards: (_y = {}, _y[HeroNames.Feldsher.ID] = 10, _y) } }),
                10: __assign(__assign({}, chestLootSettings.ShardsChest.Arena10), { AdditionalFixedLoot: { Shards: (_z = {}, _z[HeroNames.Feldsher.ID] = 10, _z) } }),
            }
        },
    });
    chests.Shards_chest_Feldsher_alias_v2 = ChestUtils.reuseChest({
        origin: chests.Shards_chest_Feldsher,
        newId: 2002,
        replace: {
            AliasShort: "shards_chest_tier4_short",
        },
    });
    chests.Shards_chest_Yukka = ChestUtils.reuseChest({
        origin: chests.Large_Shard_Chest_New_Hero,
        newId: 306,
        replace: {
            AliasShort: "new_hero",
            TooltipProbabilitySettings: {
                items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
                dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            },
            LootSettings: {
                1: __assign(__assign({}, chestLootSettings.ShardsChest.Arena1), { AdditionalFixedLoot: { Shards: (_0 = {}, _0[HeroNames.Yukka.ID] = 10, _0) } }),
                2: __assign(__assign({}, chestLootSettings.ShardsChest.Arena2), { AdditionalFixedLoot: { Shards: (_1 = {}, _1[HeroNames.Yukka.ID] = 10, _1) } }),
                3: __assign(__assign({}, chestLootSettings.ShardsChest.Arena3), { AdditionalFixedLoot: { Shards: (_2 = {}, _2[HeroNames.Yukka.ID] = 10, _2) } }),
                4: __assign(__assign({}, chestLootSettings.ShardsChest.Arena4), { AdditionalFixedLoot: { Shards: (_3 = {}, _3[HeroNames.Yukka.ID] = 10, _3) } }),
                5: __assign(__assign({}, chestLootSettings.ShardsChest.Arena5), { AdditionalFixedLoot: { Shards: (_4 = {}, _4[HeroNames.Yukka.ID] = 10, _4) } }),
                6: __assign(__assign({}, chestLootSettings.ShardsChest.Arena6), { AdditionalFixedLoot: { Shards: (_5 = {}, _5[HeroNames.Yukka.ID] = 10, _5) } }),
                7: __assign(__assign({}, chestLootSettings.ShardsChest.Arena7), { AdditionalFixedLoot: { Shards: (_6 = {}, _6[HeroNames.Yukka.ID] = 10, _6) } }),
                8: __assign(__assign({}, chestLootSettings.ShardsChest.Arena8), { AdditionalFixedLoot: { Shards: (_7 = {}, _7[HeroNames.Yukka.ID] = 10, _7) } }),
                9: __assign(__assign({}, chestLootSettings.ShardsChest.Arena9), { AdditionalFixedLoot: { Shards: (_8 = {}, _8[HeroNames.Yukka.ID] = 10, _8) } }),
                10: __assign(__assign({}, chestLootSettings.ShardsChest.Arena10), { AdditionalFixedLoot: { Shards: (_9 = {}, _9[HeroNames.Yukka.ID] = 10, _9) } }),
            }
        },
    });
    chests.Shards_chest_Yukka_alias_v2 = ChestUtils.reuseChest({
        origin: chests.Shards_chest_Yukka,
        newId: 2003,
        replace: {
            AliasShort: "shards_chest_tier4_short",
        },
    });
    chests.Shards_chest_Emperor = ChestUtils.reuseChest({
        origin: chests.Large_Shard_Chest_New_Hero,
        newId: 308,
        replace: {
            AliasShort: "new_hero",
            TooltipProbabilitySettings: {
                items: [CHEST_TOOLTIP_PROBABILITY_TYPE.SHARDS,],
                dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            },
            LootSettings: {
                1: __assign(__assign({}, chestLootSettings.ShardsChest.Arena1), { AdditionalFixedLoot: { Shards: (_10 = {}, _10[HeroNames.Emperor.ID] = 10, _10) } }),
                2: __assign(__assign({}, chestLootSettings.ShardsChest.Arena2), { AdditionalFixedLoot: { Shards: (_11 = {}, _11[HeroNames.Emperor.ID] = 10, _11) } }),
                3: __assign(__assign({}, chestLootSettings.ShardsChest.Arena3), { AdditionalFixedLoot: { Shards: (_12 = {}, _12[HeroNames.Emperor.ID] = 10, _12) } }),
                4: __assign(__assign({}, chestLootSettings.ShardsChest.Arena4), { AdditionalFixedLoot: { Shards: (_13 = {}, _13[HeroNames.Emperor.ID] = 10, _13) } }),
                5: __assign(__assign({}, chestLootSettings.ShardsChest.Arena5), { AdditionalFixedLoot: { Shards: (_14 = {}, _14[HeroNames.Emperor.ID] = 10, _14) } }),
                6: __assign(__assign({}, chestLootSettings.ShardsChest.Arena6), { AdditionalFixedLoot: { Shards: (_15 = {}, _15[HeroNames.Emperor.ID] = 10, _15) } }),
                7: __assign(__assign({}, chestLootSettings.ShardsChest.Arena7), { AdditionalFixedLoot: { Shards: (_16 = {}, _16[HeroNames.Emperor.ID] = 10, _16) } }),
                8: __assign(__assign({}, chestLootSettings.ShardsChest.Arena8), { AdditionalFixedLoot: { Shards: (_17 = {}, _17[HeroNames.Emperor.ID] = 10, _17) } }),
                9: __assign(__assign({}, chestLootSettings.ShardsChest.Arena9), { AdditionalFixedLoot: { Shards: (_18 = {}, _18[HeroNames.Emperor.ID] = 10, _18) } }),
                10: __assign(__assign({}, chestLootSettings.ShardsChest.Arena10), { AdditionalFixedLoot: { Shards: (_19 = {}, _19[HeroNames.Emperor.ID] = 10, _19) } }),
            }
        },
    });
    chests.Shards_chest_Emperor_alias_v2 = ChestUtils.reuseChest({
        origin: chests.Shards_chest_Emperor,
        newId: 2004,
        replace: {
            AliasShort: "shards_chest_tier4_short",
        },
    });
    chests.Available_Heroes_Animation_chest = new Chest({
        ID: 305,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "poses_chest",
        AliasShort: "poses_chest_short",
        Type: CHEST_TYPE.ANIMATION_PVE,
        EffectName: "ANIMATION_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Animation",
        RoundsToUnlock: 7,
        TooltipProbabilitySettings: {
            items: [
                CHEST_TOOLTIP_PROBABILITY_TYPE.ANIMATIONS,
            ],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
        },
        RepeatCustomizationWhileGenerating: true,
        LootSettings: {
            1: chestLootSettings.Customize_chest.Arena1,
            2: chestLootSettings.Customize_chest.Arena2,
            3: chestLootSettings.Customize_chest.Arena3,
            4: chestLootSettings.Customize_chest.Arena4,
            5: chestLootSettings.Customize_chest.Arena5,
            6: chestLootSettings.Customize_chest.Arena6,
            7: chestLootSettings.Customize_chest.Arena7,
            8: chestLootSettings.Customize_chest.Arena8,
            9: chestLootSettings.Customize_chest.Arena9,
            10: chestLootSettings.Customize_chest.Arena10,
        }
    });
    chests.Upgrade_chest = new Chest({
        ID: 501,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "ruby_chest",
        AliasShort: "ruby_chest_short",
        Type: CHEST_TYPE.UPGRADE_CHEST,
        EffectName: "UPGRADE_CHEST",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_100Rubies",
        RoundsToUnlock: 8,
        TimeToUnlock: new Time({ Hours: 3 }).value,
        LootSettings: {
            1: chestLootSettings.Upgrade_chest.Arena1,
            2: chestLootSettings.Upgrade_chest.Arena2,
            3: chestLootSettings.Upgrade_chest.Arena3,
            4: chestLootSettings.Upgrade_chest.Arena4,
            5: chestLootSettings.Upgrade_chest.Arena5,
            6: chestLootSettings.Upgrade_chest.Arena6,
            7: chestLootSettings.Upgrade_chest.Arena7,
            8: chestLootSettings.Upgrade_chest.Arena8,
            9: chestLootSettings.Upgrade_chest.Arena9,
            10: chestLootSettings.Upgrade_chest.Arena10
        }
    });
    chests.Legendary_chest_shop = new Chest({
        ID: 4,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "legendary_chest",
        AliasShort: "legendary_chest_short",
        Type: CHEST_TYPE.LEGENDARY,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Legendary",
        RoundsToUnlock: 12,
        LootSettings: {
            1: chestLootSettings.Legendary.Arena1,
            2: chestLootSettings.Legendary.Arena2,
            3: chestLootSettings.Legendary.Arena3,
            4: chestLootSettings.Legendary.Arena4,
            5: chestLootSettings.Legendary.Arena5,
            6: chestLootSettings.Legendary.Arena6,
            7: chestLootSettings.Legendary.Arena7,
            8: chestLootSettings.Legendary.Arena8,
            9: chestLootSettings.Legendary.Arena9,
            10: chestLootSettings.Legendary.Arena10
        }
    });
    chests.Mythic_chest_shop = new Chest({
        ID: 204,
        UseAdvertising: true,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        PopupShow: false,
        Alias: "mythic_chest",
        AliasShort: "mythic_chest_short",
        Type: CHEST_TYPE.MYTHIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Mythic",
        RoundsToUnlock: 7,
        LootSettings: {
            1: chestLootSettings.Mythic.Arena1,
            2: chestLootSettings.Mythic.Arena2,
            3: chestLootSettings.Mythic.Arena3,
            4: chestLootSettings.Mythic.Arena4,
            5: chestLootSettings.Mythic.Arena5,
            6: chestLootSettings.Mythic.Arena6,
            7: chestLootSettings.Mythic.Arena7,
            8: chestLootSettings.Mythic.Arena8,
            9: chestLootSettings.Mythic.Arena9,
            10: chestLootSettings.Mythic.Arena10
        }
    });
    chests.Observatory_chest = new Chest({
        ID: 1006,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "observatory_chest",
        AliasShort: "observatory_chest_short",
        Type: CHEST_TYPE.STAR,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Star",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: __assign(__assign({}, chestLootSettings.Common.Arena1), { Weapons: { Rarities: (_20 = {}, _20[HERO_WEAPON_RARITY.RARE] = 0.2, _20) } }),
            2: __assign(__assign({}, chestLootSettings.Common.Arena2), { Weapons: { Rarities: (_21 = {}, _21[HERO_WEAPON_RARITY.RARE] = 0.2, _21) } }),
            3: __assign(__assign({}, chestLootSettings.Common.Arena3), { Weapons: { Rarities: (_22 = {}, _22[HERO_WEAPON_RARITY.RARE] = 0.2, _22) } }),
            4: __assign(__assign({}, chestLootSettings.Common.Arena4), { Weapons: { Rarities: (_23 = {}, _23[HERO_WEAPON_RARITY.RARE] = 0.2, _23) } }),
            5: __assign(__assign({}, chestLootSettings.Common.Arena5), { Weapons: { Rarities: (_24 = {}, _24[HERO_WEAPON_RARITY.RARE] = 0.2, _24) } }),
            6: __assign(__assign({}, chestLootSettings.Common.Arena6), { Weapons: { Rarities: (_25 = {}, _25[HERO_WEAPON_RARITY.RARE] = 0.2, _25) } }),
            7: __assign(__assign({}, chestLootSettings.Common.Arena7), { Weapons: { Rarities: (_26 = {}, _26[HERO_WEAPON_RARITY.RARE] = 0.2, _26) } }),
            8: __assign(__assign({}, chestLootSettings.Common.Arena8), { Weapons: { Rarities: (_27 = {}, _27[HERO_WEAPON_RARITY.RARE] = 0.2, _27) } }),
            9: __assign(__assign({}, chestLootSettings.Common.Arena9), { Weapons: { Rarities: (_28 = {}, _28[HERO_WEAPON_RARITY.RARE] = 0.2, _28) } }),
            10: __assign(__assign({}, chestLootSettings.Common.Arena10), { Weapons: { Rarities: (_29 = {}, _29[HERO_WEAPON_RARITY.RARE] = 0.2, _29) } }),
        }
    });
    chests.Chest_MNY_2022 = new Chest({
        ID: 1008,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "mny_event3_chest",
        AliasShort: "mny_event3_chest_short",
        Type: CHEST_TYPE.UNKNOWN,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_ChineseNewYear",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Common.Arena1,
            2: chestLootSettings.Common.Arena2,
            3: chestLootSettings.Common.Arena3,
            4: chestLootSettings.Common.Arena4,
            5: chestLootSettings.Common.Arena5,
            6: chestLootSettings.Common.Arena6,
            7: chestLootSettings.Common.Arena7,
            8: chestLootSettings.Common.Arena8,
            9: chestLootSettings.Common.Arena9,
            10: chestLootSettings.Common.Arena10
        }
    });
    chests.Sakura22_chest = new Chest({
        ID: 1010,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "sakura_event4_chest",
        AliasShort: "sakura_event4_chest_short",
        Type: CHEST_TYPE.EXTRA_CHEST_RARITY_3,
        EffectName: "MYTHIC",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Sakura",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Sakura22_chest.Arena1,
            2: chestLootSettings.Sakura22_chest.Arena2,
            3: chestLootSettings.Sakura22_chest.Arena3,
            4: chestLootSettings.Sakura22_chest.Arena4,
            5: chestLootSettings.Sakura22_chest.Arena5,
            6: chestLootSettings.Sakura22_chest.Arena6,
            7: chestLootSettings.Sakura22_chest.Arena7,
            8: chestLootSettings.Sakura22_chest.Arena8,
            9: chestLootSettings.Sakura22_chest.Arena9,
            10: chestLootSettings.Sakura22_chest.Arena10
        }
    });
    chests.April_chest = new Chest({
        ID: 1011,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "april_event_chest",
        AliasShort: "april_event_chest",
        Type: CHEST_TYPE.EXTRA_CHEST_RARITY_3,
        EffectName: "MYTHIC",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_April",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.April_chest.Arena1,
            2: chestLootSettings.April_chest.Arena2,
            3: chestLootSettings.April_chest.Arena3,
            4: chestLootSettings.April_chest.Arena4,
            5: chestLootSettings.April_chest.Arena5,
            6: chestLootSettings.April_chest.Arena6,
            7: chestLootSettings.April_chest.Arena7,
            8: chestLootSettings.April_chest.Arena8,
            9: chestLootSettings.April_chest.Arena9,
            10: chestLootSettings.April_chest.Arena10
        }
    });
    chests.Summer_event_chest = new Chest({
        ID: 1012,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "summer_chest",
        AliasShort: "summer_chest_short",
        Type: CHEST_TYPE.UNKNOWN,
        EffectName: "MYTHIC",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Summer_event",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Summer_event_chest.Arena1,
            2: chestLootSettings.Summer_event_chest.Arena2,
            3: chestLootSettings.Summer_event_chest.Arena3,
            4: chestLootSettings.Summer_event_chest.Arena4,
            5: chestLootSettings.Summer_event_chest.Arena5,
            6: chestLootSettings.Summer_event_chest.Arena6,
            7: chestLootSettings.Summer_event_chest.Arena7,
            8: chestLootSettings.Summer_event_chest.Arena8,
            9: chestLootSettings.Summer_event_chest.Arena9,
            10: chestLootSettings.Summer_event_chest.Arena10
        }
    });
    chests.Halloween_event_chest = new Chest({
        ID: 1013,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "mystic_chest",
        AliasShort: "mystic_chest_short",
        Type: CHEST_TYPE.HALLOWEEN_CHEST,
        EffectName: "MYTHIC",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_halloween22",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Halloween_event_chest.Arena1,
            2: chestLootSettings.Halloween_event_chest.Arena2,
            3: chestLootSettings.Halloween_event_chest.Arena3,
            4: chestLootSettings.Halloween_event_chest.Arena4,
            5: chestLootSettings.Halloween_event_chest.Arena5,
            6: chestLootSettings.Halloween_event_chest.Arena6,
            7: chestLootSettings.Halloween_event_chest.Arena7,
            8: chestLootSettings.Halloween_event_chest.Arena8,
            9: chestLootSettings.Halloween_event_chest.Arena9,
            10: chestLootSettings.Halloween_event_chest.Arena10
        }
    });
    chests.Butcher_legendary_weapon_chest = new Chest({
        ID: 1014,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "leg_weapon_shard_chest",
        AliasShort: "leg_weapon_shard_chest_short",
        Type: CHEST_TYPE.BUTCHER_SHARD_WEAPON_CHEST,
        EffectName: "LEGENDARY_WEAPON",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_LegendaryWeapon",
        TooltipProbabilitySettings: {
            items: [CHEST_TOOLTIP_PROBABILITY_TYPE.CUSTOMIZATION_SHARDS],
            dataOrigin: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.PSEUDORANDOM,
            dataInPopupSource: CHEST_TOOLTIP_PROBABILITY_DATA_ORIGIN.LOOT_SETTINGS,
            forceGuaranteeAlias: true,
        },
        RepeatCustomizationWhileGenerating: true,
        RoundsToUnlock: 1,
        LootSettings: {
            1: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            2: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            3: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            4: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            5: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            6: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            7: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            8: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            9: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
            10: getLootSettingsAsLazy(function () { return advancedLootSettings[1014]; }),
        }
    });
    chests.Weapon_chest_arena_birthday_2024 = new Chest({
        ID: 601,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "birthday_chest",
        AliasShort: "birthday_chest_short",
        Type: CHEST_TYPE.WEAPON_CHEST_ARENA_BIRTHDAY,
        EffectName: "BIRTHDAY_23",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Birthday23",
        RoundsToUnlock: 7,
        RepeatCustomizationWhileGenerating: true,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Halloween_event_chest.Arena1,
            2: chestLootSettings.Halloween_event_chest.Arena2,
            3: chestLootSettings.Halloween_event_chest.Arena3,
            4: chestLootSettings.Halloween_event_chest.Arena4,
            5: chestLootSettings.Halloween_event_chest.Arena5,
            6: chestLootSettings.Halloween_event_chest.Arena6,
            7: chestLootSettings.Halloween_event_chest.Arena7,
            8: chestLootSettings.Halloween_event_chest.Arena8,
            9: chestLootSettings.Halloween_event_chest.Arena9,
            10: chestLootSettings.Halloween_event_chest.Arena10
        }
    });
    chests.Weapon_chest_arena_birthday_2023_2 = new Chest({
        ID: 602,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "birthday_chest",
        AliasShort: "birthday_chest_short",
        Type: CHEST_TYPE.WEAPON_CHEST_ARENA_BIRTHDAY,
        EffectName: "BIRTHDAY_23",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Birthday23",
        RoundsToUnlock: 7,
        RepeatCustomizationWhileGenerating: true,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Common.Arena1,
            2: chestLootSettings.Common.Arena2,
            3: chestLootSettings.Common.Arena3,
            4: chestLootSettings.Common.Arena4,
            5: chestLootSettings.Common.Arena5,
            6: chestLootSettings.Common.Arena6,
            7: chestLootSettings.Common.Arena7,
            8: chestLootSettings.Common.Arena8,
            9: chestLootSettings.Common.Arena9,
            10: chestLootSettings.Common.Arena10
        }
    });
    chests.Weapon_chest_arena_birthday_2023_3 = new Chest({
        ID: 506,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "birthday_chest",
        AliasShort: "birthday_chest_short",
        Type: CHEST_TYPE.WEAPON_CHEST_ARENA_BIRTHDAY,
        EffectName: "BIRTHDAY_23",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Birthday23",
        RoundsToUnlock: 7,
        RepeatCustomizationWhileGenerating: true,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Common.Arena1,
            2: chestLootSettings.Common.Arena2,
            3: chestLootSettings.Common.Arena3,
            4: chestLootSettings.Common.Arena4,
            5: chestLootSettings.Common.Arena5,
            6: chestLootSettings.Common.Arena6,
            7: chestLootSettings.Common.Arena7,
            8: chestLootSettings.Common.Arena8,
            9: chestLootSettings.Common.Arena9,
            10: chestLootSettings.Common.Arena10
        }
    });
    chests.Cobra_chest = new Chest({
        ID: 304,
        UseAdvertising: true,
        PopupShow: false,
        Alias: "viper_event73_chest",
        AliasShort: "viper_event73_chest_short",
        Type: CHEST_TYPE.COBRA_CHEST,
        EffectName: "COBRA_STUFF",
        Icon: "Sprites/PreviewImages/Chests/icon_chest_CobraStuff",
        RoundsToUnlock: 7,
        IgnoreLowerRatingOfIssueWeapon: true,
        LootSettings: {
            1: chestLootSettings.Summer_event_chest.Arena1,
            2: chestLootSettings.Summer_event_chest.Arena2,
            3: chestLootSettings.Summer_event_chest.Arena3,
            4: chestLootSettings.Summer_event_chest.Arena4,
            5: chestLootSettings.Summer_event_chest.Arena5,
            6: chestLootSettings.Summer_event_chest.Arena6,
            7: chestLootSettings.Summer_event_chest.Arena7,
            8: chestLootSettings.Summer_event_chest.Arena8,
            9: chestLootSettings.Summer_event_chest.Arena9,
            10: chestLootSettings.Summer_event_chest.Arena10
        }
    });
    chests.TournamentMockChest = new Chest({
        ID: 1005,
        Alias: "",
        AliasShort: "",
        Type: CHEST_TYPE.UNKNOWN,
        Icon: "", RoundsToUnlock: 0,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_1 = new Chest({
        ID: 2005,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_2 = new Chest({
        ID: 2006,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_3 = new Chest({
        ID: 2007,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_4 = new Chest({
        ID: 2008,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_5 = new Chest({
        ID: 2009,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_6 = new Chest({
        ID: 2010,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_7 = new Chest({
        ID: 2011,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_8 = new Chest({
        ID: 2012,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_9 = new Chest({
        ID: 2013,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_10 = new Chest({
        ID: 2014,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_11 = new Chest({
        ID: 2015,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_12 = new Chest({
        ID: 2016,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_13 = new Chest({
        ID: 2100,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "battlepass_free_chest_short",
        AliasShort: "battlepass_free_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Shards",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_14 = new Chest({
        ID: 2101,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_15 = new Chest({
        ID: 2102,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_16 = new Chest({
        ID: 2103,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_17 = new Chest({
        ID: 2104,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_18 = new Chest({
        ID: 2105,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_19 = new Chest({
        ID: 2106,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_20 = new Chest({
        ID: 2107,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_21 = new Chest({
        ID: 2109,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_22 = new Chest({
        ID: 2206,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 4,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_23 = new Chest({
        ID: 2207,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 8,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_24 = new Chest({
        ID: 2208,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 4,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_25 = new Chest({
        ID: 2211,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 8,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_26 = new Chest({
        ID: 2212,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "common_chest",
        AliasShort: "common_chest_short",
        Type: CHEST_TYPE.COMMON,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Common",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 4,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_27 = new Chest({
        ID: 2213,
        ShowFixLootChances: true,
        ShowFixLootSettings: { heroShards: [], },
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: new Time({ Hours: 4 }).value,
        RoundsToUnlock: 10,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_28 = new Chest({
        ID: 2500,
        UseAdvertising: false,
        PopupShow: false,
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        TimeToUnlock: 0,
        RoundsToUnlock: 3,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_29 = new Chest({
        ID: 201,
        UseAdvertising: true,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        PopupShow: false,
        Alias: "rare_chest",
        AliasShort: "rare_chest_short",
        Type: CHEST_TYPE.RARE,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Rare",
        RoundsToUnlock: 5,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_30 = new Chest({
        ID: 202,
        UseAdvertising: true,
        PopupShow: false,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        RoundsToUnlock: 7,
        LootSettings: templateChestLootSettings,
    });
    chests.Irrelevant_31 = new Chest({
        ID: 1001,
        UseAdvertising: true,
        PopupShow: false,
        ShowFixLootChances: true, ShowFixLootSettings: { heroShards: [], },
        Alias: "epic_chest",
        AliasShort: "epic_chest_short",
        Type: CHEST_TYPE.EPIC,
        Icon: "Sprites/PreviewImages/Chests/icon_chest_Epic",
        RoundsToUnlock: 7,
        LootSettings: templateChestLootSettings,
    });
    return chests;
}());
var chestsMap = createIDMap(chests, "chestsMap");
