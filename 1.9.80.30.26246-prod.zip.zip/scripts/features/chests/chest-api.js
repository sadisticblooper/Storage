function initChestStarterPoint() {
    return ChestWheels.initChestStarterPoint();
}
function generateChestID(parameters) {
    return ChestWheels.getChestID(parameters.Index, parameters.StarterPoint);
}
function generateLootFromChest(parameters) {
    return ChestUtils.generateLootFromChest(parameters);
}
function calcChestSkipPrice(parameters) {
    return ChestUtils.calcChestSkipPrice(parameters);
}
function getChestInfo(parameters) {
    return ChestUtils.getChestInfoByChestId(parameters);
}
function getChestsInfoAtArena(params) {
    return ChestUtils.getChestsInfoAtArena(params);
}
function calcChestCountersAfterFight(settings) {
    return ChestUtils.calcChestCountersAfterFight(settings);
}
function getChestsVisualSettingsMany() {
    return ChestUtils.getChestsVisualSettingsMany();
}
