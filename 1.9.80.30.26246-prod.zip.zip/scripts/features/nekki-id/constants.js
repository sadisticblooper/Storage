var NekkiIdConstants = (function () {
    function NekkiIdConstants() {
    }
    NekkiIdConstants.defaultSignInButtonSettings = {
        alias: "sign_in_button",
        iconPath: "",
    };
    NekkiIdConstants.steamSignInButtonSettings = {
        alias: "sign_in_steam_button",
        iconPath: "Sprites/Assets/Icons/icon_STEAM",
    };
    NekkiIdConstants.googlePlaySignInButtonSettings = {
        alias: "sign_in_google_play_button",
        iconPath: "Sprites/Assets/Icons/icon_PLAYMARKET_GREEN",
    };
    NekkiIdConstants.gameCenterSignInButtonSettings = {
        alias: "sign_in_game_center_button",
        iconPath: "Sprites/Assets/Icons/icon_APPSTORE",
    };
    NekkiIdConstants.nekkiIdPopupAliases = {
        headerAlias: "nekki_id_info_popup_steam_header",
        descriptionAlias: "nekki_id_info_popup_steam_message",
    };
    return NekkiIdConstants;
}());
