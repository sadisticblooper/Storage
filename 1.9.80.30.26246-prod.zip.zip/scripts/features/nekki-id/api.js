var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function canShowButtonToTransferProfileProgress(settings) {
    return false;
}
function canShowButtonToLinkNekkiId(settings) {
    return true;
}
function canShowPopupToLinkNekkiIdOnPlayerCreate(settings) {
    return SteamPlatformUtils.isPCBuild(settings.platform);
}
function getPlatformSignInButtonModel(settings) {
    var isPCBuild = SteamPlatformUtils.isPCBuild(settings.platform);
    var isAndroid = settings.platform == PLATFORM.ANDROID || settings.platform == PLATFORM.ANDROID_VIETNAM;
    var isIOS = settings.platform == PLATFORM.IOS || settings.platform == PLATFORM.IOS_VIETNAM;
    if (isPCBuild) {
        return NekkiIdConstants.steamSignInButtonSettings;
    }
    if (isAndroid) {
        return NekkiIdConstants.googlePlaySignInButtonSettings;
    }
    if (isIOS) {
        return NekkiIdConstants.gameCenterSignInButtonSettings;
    }
    return NekkiIdConstants.defaultSignInButtonSettings;
}
function showPopupOnPressNekkiIdButton(settings) {
    var isPCBuild = SteamPlatformUtils.isPCBuild(settings.platform);
    return __assign({ show: isPCBuild }, NekkiIdConstants.nekkiIdPopupAliases);
}
