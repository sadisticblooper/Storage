var GachaBannersConstants = (function () {
    function GachaBannersConstants() {
    }
    GachaBannersConstants.generatedEvents = [];
    return GachaBannersConstants;
}());
