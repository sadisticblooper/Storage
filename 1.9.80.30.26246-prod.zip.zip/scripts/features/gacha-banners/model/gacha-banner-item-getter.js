var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var GachaBannersToOffersConverter = (function () {
    function GachaBannersToOffersConverter() {
    }
    GachaBannersToOffersConverter.prototype.Args = function (p) {
        return __assign(__assign({}, p), { generatedOffers: this._generatedBannersToOffers(p.generatedGachaBanners, p.closedGachaBanners, p.serverCurrentTime), generatedRoulette: [] });
    };
    GachaBannersToOffersConverter.prototype.Result = function (p) {
        var result = [];
        var items = p.offers;
        if (items) {
            for (var id in items)
                if (items[id] != undefined) {
                    result.push({
                        expireTime: items[id].expireTime,
                        gachaBannerId: +id,
                    });
                }
        }
        return result;
    };
    GachaBannersToOffersConverter.prototype.Type = function (p) {
        return p.getPromoOffer();
    };
    GachaBannersToOffersConverter.prototype._generatedBannersToOffers = function (items, closed, serverTime) {
        var result = {};
        if (items) {
            for (var id in items)
                if (items[id] != undefined) {
                    result[id] = {
                        expireTime: items[id].expireTime,
                        purchaseCount: 0,
                        seed: 1,
                        universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                    };
                }
        }
        if (closed) {
            closed = getArrayFromRaw(closed);
            for (var _i = 0, closed_1 = closed; _i < closed_1.length; _i++) {
                var id = closed_1[_i];
                result[id] = {
                    expireTime: 1,
                    purchaseCount: 1,
                    seed: 1,
                    universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                };
            }
        }
        return result;
    };
    return GachaBannersToOffersConverter;
}());
