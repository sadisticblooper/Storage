var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var GachaBanner = (function () {
    function GachaBanner(config) {
        this.ID = config.ID;
        this.config = config;
        OffersUtils.updateSellHeroesSettings(config.promoSettings.sellHeroSettings, this.ID);
    }
    GachaBanner.prototype.getPromoOffer = function () {
        if (this.promoOffer == null) {
            var config = this.config;
            var offerSettings = __assign(__assign({}, config.promoSettings), { country: config.promoSettings.country ? config.promoSettings.country : [], ignoredCountry: config.promoSettings.ignoredCountry ? config.promoSettings.ignoredCountry : [], ID: this.ID, offerNameAlias: null, lootSettings: null, offerType: PROMO_OFFER_TYPE.DYNAMIC, visualPresetId: null });
            this.promoOffer = new PromoOffer(offerSettings);
        }
        return this.promoOffer;
    };
    GachaBanner.prototype.check = function () {
        var config = this.config;
        var additionalBannerSettings = config.additionalBannerSettings;
        if (additionalBannerSettings && additionalBannerSettings.guarantee) {
            var guarantee = additionalBannerSettings.guarantee;
            var groups = config.bannerGroupRewards;
            var groupNumber = guarantee.consistentRewardGroupIndex;
            if (!groups[groupNumber]) {
                throw new Error("gacha banner ".concat(this.ID, " error: no guarantee reward with group ").concat(groupNumber));
            }
            if (guarantee.consistentRewardIndex != undefined) {
                var elements = groups[groupNumber].rewards;
                var elementNumber = guarantee.consistentRewardIndex;
                if (!elements[elementNumber]) {
                    throw new Error("gacha banner ".concat(this.ID, " error: \n                        \rno guarantee reward with group ").concat(groupNumber, " and element ").concat(elementNumber));
                }
            }
            if (additionalBannerSettings.controlDropSettings) {
                var dropRewardSettings = additionalBannerSettings.controlDropSettings;
                for (var _i = 0, dropRewardSettings_1 = dropRewardSettings; _i < dropRewardSettings_1.length; _i++) {
                    var dropSetting = dropRewardSettings_1[_i];
                    if (dropSetting.roll % guarantee.rollsNumber == 0) {
                        throw new Error("gacha banner ".concat(this.ID, " error: same number of rolls used for \n                            \rguarantee reward ").concat(guarantee.rollsNumber, " and control reward settings ").concat(dropSetting.roll));
                    }
                }
            }
        }
        if (additionalBannerSettings && additionalBannerSettings.controlDropSettings) {
            var controlDropSettings = additionalBannerSettings.controlDropSettings;
            if (controlDropSettings.length == 0) {
                throw new Error("gacha banner ".concat(this.ID, " error: control settings is enabled but it has no elements"));
            }
            for (var _a = 0, controlDropSettings_1 = controlDropSettings; _a < controlDropSettings_1.length; _a++) {
                var element = controlDropSettings_1[_a];
                if (element.rewardGroups.length == 0) {
                    throw new Error("gacha banner ".concat(this.ID, " error: no elements in rewardGroups"));
                }
                if (element.rewardIndexes && element.rewardIndexes.length == 0) {
                    throw new Error("gacha banner ".concat(this.ID, " error: rewardIndexes is enabled but it has no elements"));
                }
                for (var i = 0; i < element.rewardGroups.length; i++) {
                    var group = this.config.bannerGroupRewards[element.rewardGroups[i]];
                    if (group == undefined) {
                        throw new Error("gacha banner ".concat(this.ID, " error: group index ").concat(element.rewardGroups[i], "\n                            \rdoesn't exist in gacha banner settings"));
                    }
                    if (element.rewardIndexes) {
                        if (element.rewardIndexes.length > group.rewards.length) {
                            throw new Error("gacha banner ".concat(this.ID, " error: the number of reward indexes in control settings\n                                \ris greater than there are rewards in group: \n                                \rgroup index ").concat(element.rewardGroups[i], ", number of rewards ").concat(group.rewards.length));
                        }
                        for (var j = 0; j < element.rewardIndexes.length; j++) {
                            if (group.rewards[element.rewardIndexes[j]] == undefined) {
                                throw new Error("gacha banner ".concat(this.ID, " error: rewardIndex ").concat(element.rewardIndexes[j], "\n                                    \rin group ").concat(element.rewardGroups[i], " doesn't exist"));
                            }
                        }
                    }
                }
            }
        }
        if (config.totalNumberOfRolls > 0) {
            var activeTime = config.promoSettings.activeTime;
            if (activeTime.duration != PROMO_DURATION.ENDLESS) {
                throw new Error("gacha banner ".concat(this.ID, " error: \n                        \ruse PROMO_DURATION.ENDLESS with non-zero totalNumberOfRolls"));
            }
        }
        if (!config.visualPreset) {
            throw new Error("gacha banner ".concat(this.ID, " error: \n                        \rno visual preset"));
        }
    };
    GachaBanner.prototype.getGachaBannerReward = function (groupIndex, rewardIndex) {
        return this.config.bannerGroupRewards[groupIndex]
            && this.config.bannerGroupRewards[groupIndex].rewards[rewardIndex]
            && this.config.bannerGroupRewards[groupIndex].rewards[rewardIndex].reward;
    };
    GachaBanner.prototype.rollGroupIndex = function (rnd, targetGroupIndexes) {
        if (targetGroupIndexes === void 0) { targetGroupIndexes = null; }
        var originalGachaGroups = this.config.bannerGroupRewards;
        var groups = [];
        var groupIndexes = [];
        var weightCollection = new RandomCollection();
        var weights = [];
        if (targetGroupIndexes != null) {
            for (var _i = 0, targetGroupIndexes_1 = targetGroupIndexes; _i < targetGroupIndexes_1.length; _i++) {
                var groupIndex = targetGroupIndexes_1[_i];
                if (originalGachaGroups[groupIndex]) {
                    groups.push(originalGachaGroups[groupIndex]);
                    groupIndexes.push(groupIndex);
                }
            }
        }
        else {
            groups = originalGachaGroups;
            for (var i = 0; i < groups.length; i++) {
                groupIndexes.push(i);
            }
        }
        for (var i = 0; i < groups.length; i++) {
            if (groups[i].weight > 0) {
                weights.push(new CollectionObjectContainer(groupIndexes[i], groups[i].weight));
            }
        }
        if (!weights.length) {
            return null;
        }
        weightCollection.addAll(weights);
        return Number(weightCollection.next(rnd).get());
    };
    GachaBanner.prototype.rollRewardByIndexes = function (groupIndex, availableIndexes, rnd) {
        var group = this.config.bannerGroupRewards[groupIndex];
        if (!group) {
            return null;
        }
        var weightCollection = new RandomCollection();
        var weights = [];
        for (var i = 0; i < availableIndexes.length; i++) {
            var index = availableIndexes[i];
            var reward = group.rewards[index];
            if (!reward) {
                continue;
            }
            if (reward.weight > 0) {
                weights.push(new CollectionObjectContainer(index, reward.weight));
            }
        }
        if (!weights.length) {
            return null;
        }
        weightCollection.addAll(weights);
        var chosenIndex = Number(weightCollection.next(rnd).get());
        return group.rewards[chosenIndex].reward;
    };
    GachaBanner.prototype.getAvailableIndexes = function (playerProgress, groupIndex) {
        var targetGroup = this.config.bannerGroupRewards[groupIndex];
        if (!targetGroup) {
            return null;
        }
        var allIndexes = targetGroup.rewards.map(function (_, index) { return index; });
        var availableIndexes = [];
        var uniqueRewards = 0;
        var disableUniqueLootPriority = targetGroup.disableUniqueLootPriority !== undefined
            ? targetGroup.disableUniqueLootPriority
            : Boolean(this.config.disableUniqueLootPriority);
        if (disableUniqueLootPriority) {
            return allIndexes;
        }
        for (var i = 0; i < targetGroup.rewards.length; i++) {
            var reward = targetGroup.rewards[i] && targetGroup.rewards[i].reward;
            var isDuplicate = GachaBannerUtils.doesPlayerHaveReward(playerProgress, {
                Loot: reward.loot,
                Chests: reward.chests,
                NewSeed: 0,
                IsHidden: false,
            });
            if (GachaBannerUtils.doesRewardHaveUniqueLoot(reward)) {
                uniqueRewards++;
            }
            if (isDuplicate) {
                continue;
            }
            availableIndexes.push(i);
        }
        if (availableIndexes.length <= targetGroup.rewards.length - uniqueRewards) {
            availableIndexes = allIndexes;
        }
        return availableIndexes;
    };
    GachaBanner.prototype.getDroppedItems = function (playerProgress, currentServerTime) {
        var result = [];
        var lootGenerator = LootGeneratorBuilder.getGachaLootGenerator();
        lootGenerator.setServerTime(currentServerTime);
        var rnd = new PcgRandom(this.ID);
        var dropGroups = this.getDropGroups(playerProgress, lootGenerator, rnd);
        var orderDropGroupIds = Object.keys(dropGroups)
            .map(Number)
            .sort(function (a, b) { return a - b; });
        for (var _i = 0, orderDropGroupIds_1 = orderDropGroupIds; _i < orderDropGroupIds_1.length; _i++) {
            var groupId = orderDropGroupIds_1[_i];
            var dropGroup = dropGroups[groupId];
            var dropGroupSettings = GachaBannerVisualConfig.detailsGroupsSettings[groupId];
            result.push({
                header: {
                    alias: { alias: dropGroupSettings.alias, color: dropGroupSettings.color },
                    backgroundColor: dropGroupSettings.backgroundColor,
                    chance: dropGroup.weight + '%',
                },
                items: dropGroups[groupId].items,
            });
        }
        return result;
    };
    GachaBanner.prototype.getDropGroups = function (playerProgress, lootGenerator, rnd) {
        var resultDropGroups = {};
        var groupsAndRewardsWithProbabilities = GachaBannerUtils
            .translateWeightsToProbabilitiesInGroups(this.config.bannerGroupRewards);
        var rewardsWithProbabilities = GachaBannerUtils
            .flatRewardsFromGroupAndCalcProbabilities(groupsAndRewardsWithProbabilities);
        var uniqueRewardsWithProbabilities = GachaBannerUtils.stackSameRewardsAndSumProbabilities(rewardsWithProbabilities);
        for (var _i = 0, uniqueRewardsWithProbabilities_1 = uniqueRewardsWithProbabilities; _i < uniqueRewardsWithProbabilities_1.length; _i++) {
            var groupReward = uniqueRewardsWithProbabilities_1[_i];
            var dropGroupIndex = GachaBannerUtils.getDropGroupIndex(groupReward.reward);
            if (dropGroupIndex > -1) {
                lootGenerator.setPlayerParams(playerProgress);
                var rewardResult = lootGenerator.getRewardFromRewardContent(groupReward.reward, rnd);
                var resultDropGroup = resultDropGroups[dropGroupIndex];
                if (resultDropGroup == undefined) {
                    resultDropGroup = resultDropGroups[dropGroupIndex] = {
                        items: [],
                        weight: 0,
                    };
                }
                resultDropGroup.items.push({
                    reward: rewardResult,
                    isHighChance: !!groupReward.isRateUp,
                    isClaimed: GachaBannerUtils.doesPlayerHaveReward(playerProgress, rewardResult),
                    chance: groupReward.weight.toString(),
                });
            }
        }
        resultDropGroups = GachaBannerUtils.getReformedDropGroups(resultDropGroups);
        var groupsIndexOrder = Object.keys(resultDropGroups);
        var weightsOfGroups = [];
        for (var _a = 0, groupsIndexOrder_1 = groupsIndexOrder; _a < groupsIndexOrder_1.length; _a++) {
            var dropGroupIndex = groupsIndexOrder_1[_a];
            var resultDropGroup = resultDropGroups[dropGroupIndex];
            var weights = resultDropGroup.items.map(function (el) { return +el.chance; });
            var sumWeightOfItems = weights.reduce(function (a, v) { return a + v; }, 0);
            weights = CommonUtils.getNormalChances(weights, GachaBannerVisualConfig.chanceDigit);
            for (var i = 0; i < weights.length; i++) {
                resultDropGroup
                    .items[i]
                    .chance = (weights[i]).toFixed(GachaBannerVisualConfig.chanceDigit) + "%";
            }
            weightsOfGroups.push(sumWeightOfItems);
        }
        weightsOfGroups = CommonUtils.getNormalChances(weightsOfGroups, GachaBannerVisualConfig.chanceDigit);
        for (var i = 0; i < groupsIndexOrder.length; i++) {
            var dropGroupIndex = groupsIndexOrder[i];
            var resultDropGroup = resultDropGroups[dropGroupIndex];
            resultDropGroup.weight = weightsOfGroups[i];
        }
        return resultDropGroups;
    };
    GachaBanner.isGachaBannerFeatureActive = function (playerProgress) {
        return playerProgress.tutorialPassed;
    };
    GachaBanner.getActiveGachaBannersArray = function (settings) {
        if (!GachaBanner.isGachaBannerFeatureActive(settings.playerProgress)) {
            return [];
        }
        var converter = new GachaBannersToOffersConverter();
        var itemsGetter = new GettingItemsLikeOffers(gachaBannersMap, converter);
        return itemsGetter.getPromos(settings);
    };
    GachaBanner.getGachaBannerSliderVisualSettings = function (bannerId) {
        var banner = gachaBannersMap.get(bannerId);
        if (!banner) {
            return null;
        }
        return banner.config.visualPreset.slideConfig;
    };
    GachaBanner.getGachaBannerSettings = function (settings) {
        var id = settings.gachaBannerId;
        var banner = gachaBannersMap.get(id);
        if (!banner) {
            return throwDebugOrReturnDefault("getGachaBannerSettings: no banner with id ".concat(id));
        }
        return {
            totalNumberOfRolls: banner.config.totalNumberOfRolls,
            multipleRoll: banner.config.multipleRoll ? banner.config.multipleRoll : null,
            singleRoll: banner.config.singleRoll ? banner.config.singleRoll : null,
            weightForSlider: banner.config.weightForSlider,
            weightForModule: banner.config.weightForModule || banner.config.weightForSlider,
        };
    };
    GachaBanner.rollGachaBanner = function (settings) {
        var gachaBannerId = settings.gachaBannerId, rollCounter = settings.rollCounter, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var banner = gachaBannersMap.get(gachaBannerId);
        var seed = CommonUtils.getRandomJSSeed();
        var rnd = new PcgRandom(seed);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        if (!banner) {
            return throwDebugOrReturnDefault("rollGachaBanner: \n                \rno banner with id ".concat(gachaBannerId, ". Inner params: ").concat(JSON.stringify(settings)));
        }
        var additionalSettings = banner.config.additionalBannerSettings;
        var targetContent = null;
        var groupIndex;
        var availableRewardIndexes = null;
        if (additionalSettings && additionalSettings.controlDropSettings) {
            var controlDropSettings = additionalSettings.controlDropSettings;
            for (var i = 0; i < controlDropSettings.length; i++) {
                if (controlDropSettings[i].roll == rollCounter + 1) {
                    groupIndex = banner.rollGroupIndex(rnd, controlDropSettings[i].rewardGroups);
                    if (groupIndex == null) {
                        return throwDebugOrReturnDefault("rollGroup: No available elements with weights\n                            \rin banner ".concat(gachaBannerId, " in controlled roll. Inner params: ").concat(JSON.stringify(settings)));
                    }
                    if (controlDropSettings[i].rewardIndexes) {
                        availableRewardIndexes = controlDropSettings[i].rewardIndexes;
                        break;
                    }
                    availableRewardIndexes = banner.getAvailableIndexes(playerProgress, groupIndex);
                    break;
                }
            }
        }
        if (additionalSettings && additionalSettings.guarantee
            && (rollCounter + 1) % additionalSettings.guarantee.rollsNumber == 0) {
            var guaranteeSettings = banner.config.additionalBannerSettings.guarantee;
            groupIndex = guaranteeSettings.consistentRewardGroupIndex;
            if (groupIndex == null) {
                return throwDebugOrReturnDefault("rollGroup: No available elements with weights\n                    \rin banner ".concat(gachaBannerId, " in guarantee roll. Inner params: ").concat(JSON.stringify(settings)));
            }
            if (guaranteeSettings.consistentRewardIndex != undefined) {
                availableRewardIndexes = [guaranteeSettings.consistentRewardIndex];
            }
            else {
                availableRewardIndexes = banner.getAvailableIndexes(playerProgress, groupIndex);
            }
        }
        if (!groupIndex && !availableRewardIndexes) {
            groupIndex = banner.rollGroupIndex(rnd);
            if (groupIndex == null) {
                return throwDebugOrReturnDefault("rollGroup: No available elements with weights\n                    \rin banner ".concat(gachaBannerId, " in normal roll. Inner params: ").concat(JSON.stringify(settings)));
            }
            availableRewardIndexes = banner.getAvailableIndexes(playerProgress, groupIndex);
        }
        if (!availableRewardIndexes || availableRewardIndexes.length == 0) {
            return throwDebugOrReturnDefault("availableRewardIndexes: undefined in banner ".concat(gachaBannerId, ".\n                \rGroup Index: ").concat(groupIndex, ". Inner params: ").concat(JSON.stringify(settings)));
        }
        targetContent = banner.rollRewardByIndexes(groupIndex, availableRewardIndexes, rnd);
        if (!targetContent) {
            return throwDebugOrReturnDefault("roll error: No targetContent\n                \rin banner ".concat(gachaBannerId, " in group ").concat(groupIndex, ". \n                \rInner params: ").concat(JSON.stringify(settings)));
        }
        var lootGenerator = LootGeneratorBuilder.getGachaLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(startTimeOfCurrentDayMS);
        return lootGenerator.getRewardFromRewardContent(targetContent, rnd);
    };
    GachaBanner.multipleRollGachaBanner = function (settings) {
        var gachaBannerId = settings.gachaBannerId, rollCounter = settings.rollCounter, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var banner = gachaBannersMap.get(gachaBannerId);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var result = [];
        if (!banner) {
            return throwDebugOrReturnDefault("multipleRollGachaBanner: no banner with id ".concat(gachaBannerId, ". \n                \rInner params: ").concat(JSON.stringify(settings)));
        }
        var multipleRollSettings = banner.config.multipleRoll;
        if (!multipleRollSettings) {
            return throwDebugOrReturnDefault("multipleRollGachaBanner: no multiple roll settings \n                \rfor banner  with id ".concat(gachaBannerId, ". Inner params: ").concat(JSON.stringify(settings)));
        }
        for (var i = 0; i < multipleRollSettings.rollQuantity; i++) {
            var chosenReward = rollGachaBanner({
                gachaBannerId: gachaBannerId,
                rollCounter: rollCounter,
                playerProgress: playerProgress,
                startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            });
            result.push(chosenReward);
            if (chosenReward && chosenReward.Loot && !chosenReward.Loot.isEmpty()) {
                HeroUtils.combineLoot(playerProgress, chosenReward.Loot);
            }
            rollCounter++;
        }
        return result;
    };
    GachaBanner.getGachaBannerDetailsVisualSettings = function (bannerId) {
        var banner = gachaBannersMap.get(bannerId);
        if (!banner) {
            return throwDebugOrReturnDefault("getGachaBannerDetails: no banner with id ".concat(bannerId, ". \n                \rInner params: ").concat(JSON.stringify(bannerId)));
        }
        return banner.config.visualPreset.detailsConfig;
    };
    GachaBanner.getGachaBannerDetailsDrop = function (settings) {
        var gachaBannerId = settings.gachaBannerId, playerProgress = settings.playerProgress, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var banner = gachaBannersMap.get(gachaBannerId);
        if (!banner) {
            return throwDebugOrReturnDefault("getGachaBannerDetailsDrop: no banner with id ".concat(gachaBannerId, ". \n                \rInner params: ").concat(JSON.stringify(settings)));
        }
        playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        return banner.getDroppedItems(playerProgress, startTimeOfCurrentDayMS);
    };
    GachaBanner.getGachaBannerProgressRolls = function (settings) {
        var banner = gachaBannersMap.get(settings.id);
        if (!banner) {
            return throwDebugOrReturnDefault("getGachaBannerProgressRolls: no banner with id ".concat(settings.id, ". \n                \rInner params: ").concat(JSON.stringify(settings)));
        }
        var additionalBannerSettings = banner.config.additionalBannerSettings;
        if (!additionalBannerSettings || !additionalBannerSettings.guarantee) {
            return null;
        }
        var guaranteeTotalRolls = additionalBannerSettings.guarantee.rollsNumber;
        var currentMilestone = settings.totalRolls % guaranteeTotalRolls;
        var visualPreset = banner.config.visualPreset;
        return {
            currentRollMilestone: currentMilestone,
            lastMilestoneColor: visualPreset.viewConfig.lastMilestoneColor,
            rollsForGuarantee: guaranteeTotalRolls
        };
    };
    return GachaBanner;
}());
