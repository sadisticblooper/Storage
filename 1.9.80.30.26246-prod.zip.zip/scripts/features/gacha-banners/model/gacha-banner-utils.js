var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var GachaBannerUtils = (function () {
    function GachaBannerUtils() {
    }
    GachaBannerUtils.getDropGroupIndex = function (rewardContent) {
        var groupSettings = GachaBannerVisualConfig.detailsGroupsSettings;
        for (var i = 0; i < groupSettings.length; i++) {
            var settings = groupSettings[i];
            if (settings.check(rewardContent)) {
                return i;
            }
        }
        return -1;
    };
    GachaBannerUtils.doesPlayerHaveReward = function (playerProgress, rewardResult) {
        var loot = rewardResult.Loot;
        if (loot) {
            var iterator = [
                {
                    ids: Object.keys(loot.Shards).map(function (id) { return +id; }),
                    playerIds: Object.keys(playerProgress.heroes).map(function (id) { return +id; }),
                    noIds: []
                },
            ];
            var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
            for (var _i = 0, allCustomizations_1 = allCustomizations; _i < allCustomizations_1.length; _i++) {
                var customizationType = allCustomizations_1[_i];
                iterator.push({
                    ids: CustomizationUtils.getLootIdsContainer(customizationType, loot),
                    playerIds: CustomizationUtils.getPlayerIdsContainer(customizationType, playerProgress),
                    noIds: []
                });
            }
            for (var _a = 0, iterator_1 = iterator; _a < iterator_1.length; _a++) {
                var iteration = iterator_1[_a];
                var ids = iteration.ids;
                var playerIds = iteration.playerIds;
                if (!ids || !playerIds) {
                    continue;
                }
                if (ArrayUtils.getArraysIntersection(ids, playerIds).length > 0) {
                    return true;
                }
            }
        }
        return false;
    };
    GachaBannerUtils.doesRewardHaveUniqueLoot = function (rewardContent) {
        var loot = new Loot();
        if (rewardContent.loot) {
            loot.combineLoot(rewardContent.loot);
        }
        if (rewardContent.lootSettings && rewardContent.lootSettings.AdditionalFixedLoot) {
            loot.combineLoot(rewardContent.lootSettings.AdditionalFixedLoot);
        }
        return loot.hasCustomize() || Object.keys(loot.Shards).length > 0;
    };
    GachaBannerUtils.getReformedDropGroups = function (groups) {
        var result = __assign({}, groups);
        for (var groupIndex in groups) {
            var groupSettings = GachaBannerVisualConfig.detailsGroupsSettings[groupIndex];
            if (groupSettings != undefined && groupSettings.mixSameLoot) {
                result[groupIndex] = {
                    weight: groups[groupIndex].weight,
                    items: GachaBannerUtils.stackUniqueTypeRewards(groups[groupIndex].items),
                };
            }
        }
        return result;
    };
    GachaBannerUtils.stackUniqueTypeRewards = function (rewards) {
        var result = [];
        var sameRewards = {};
        for (var _i = 0, rewards_1 = rewards; _i < rewards_1.length; _i++) {
            var reward = rewards_1[_i];
            var type = GachaBannerUtils.getRewardDropType(reward.reward);
            if (type == null) {
                result.push(reward);
                continue;
            }
            if (sameRewards[type] == undefined) {
                sameRewards[type] = reward;
                continue;
            }
            sameRewards[type].chance = (+sameRewards[type].chance + +reward.chance).toString();
        }
        for (var type in sameRewards) {
            result.push(sameRewards[type]);
        }
        return result;
    };
    GachaBannerUtils.getRewardDropType = function (reward) {
        if (reward.Chests && reward.Chests.length > 0) {
            var chest = chestsMap.get(reward.Chests[0]);
            if (chest) {
                return "chest_rarity_".concat(chest.Type);
            }
        }
        if (reward.Loot) {
            var shardsIds = Object.keys(reward.Loot.Shards);
            if (shardsIds.length > 0) {
                var hero = heroesMap.get(shardsIds[0]);
                if (hero) {
                    return "shard_rarity_".concat(hero.Rarity);
                }
            }
            var heroIds = Object.keys(reward.Loot.HeroExp);
            if (heroIds.length > 0) {
                var hero = heroesMap.get(heroIds[0]);
                if (hero) {
                    return "card_rarity_".concat(hero.Rarity);
                }
            }
            for (var curType in reward.Loot.Currencies) {
                if (reward.Loot.Currencies[curType]) {
                    return "currency_".concat(curType);
                }
            }
            var allCustomizations = CustomizationUtils.getAllCustomizationsOrder();
            for (var _i = 0, allCustomizations_2 = allCustomizations; _i < allCustomizations_2.length; _i++) {
                var customizationType = allCustomizations_2[_i];
                var ids = CustomizationUtils.getLootIdsContainer(customizationType, reward.Loot);
                var map = CustomizationUtils.getOrderMap(customizationType);
                if (ids && ids.length > 0) {
                    var customization = map.get(ids[0]);
                    if (customization) {
                        return "".concat(CUSTOMIZATION[customizationType], "_rarity_").concat(customization.rarity);
                    }
                }
            }
        }
        return null;
    };
    GachaBannerUtils.reuseGacha = function (settings) {
        var origin = settings.origin, replaceConfig = settings.replaceConfig, rewardReplacer = settings.rewardReplacer;
        if (replaceConfig.ID == undefined || origin.ID == replaceConfig.ID) {
            throw new Error("reuseGacha: you must have choose new ID for gacha");
        }
        var newConfig = __assign(__assign({}, origin.config), replaceConfig);
        if (rewardReplacer) {
            var newRewards = origin.config.bannerGroupRewards.slice();
            for (var _i = 0, rewardReplacer_1 = rewardReplacer; _i < rewardReplacer_1.length; _i++) {
                var rewardReplace = rewardReplacer_1[_i];
                if (newRewards[rewardReplace.rewardIndex] == undefined) {
                    throw new Error("reuseGacha: no reward with index ".concat(rewardReplace.rewardIndex));
                }
                var newItems = newRewards[rewardReplace.rewardIndex].rewards.slice();
                if (rewardReplace.items) {
                    for (var _a = 0, _b = rewardReplace.items; _a < _b.length; _a++) {
                        var item = _b[_a];
                        var originItem = newItems[item.rewardIndex];
                        if (originItem == undefined) {
                            throw new Error("reuseGacha: \n                                \rno reward with index ".concat(rewardReplace.rewardIndex, "_").concat(item.rewardIndex));
                        }
                        newItems[item.rewardIndex] = {
                            isRateUp: getValueByKeyDefault(item, "isRateUp", originItem.isRateUp),
                            reward: getValueByKeyDefault(item, "reward", originItem.reward),
                            weight: getValueByKeyDefault(item, "weight", originItem.weight),
                        };
                    }
                }
                newRewards[rewardReplace.rewardIndex] = {
                    weight: getValueByKeyDefault(rewardReplace, "weight", newRewards[rewardReplace.rewardIndex].weight),
                    rewards: newItems,
                    disableUniqueLootPriority: getValueByKeyDefault(rewardReplace, "disableUniqueLootPriority", newRewards[rewardReplace.rewardIndex].disableUniqueLootPriority),
                };
            }
            CommonUtils.replaceReadOnlyProperty(newConfig, "bannerGroupRewards", newRewards);
        }
        return new GachaBanner(newConfig);
    };
    GachaBannerUtils.getGachaBannerVisualSettings = function (bannerId) {
        var banner = gachaBannersMap.get(bannerId);
        if (!banner) {
            return null;
        }
        return banner.config.visualPreset.viewConfig;
    };
    GachaBannerUtils.translateWeightsToProbabilitiesInGroups = function (groups) {
        var result = [];
        var sumWeightsOfGroups = groups
            .reduce(function (sum, group) { return sum + group.weight; }, 0);
        for (var _i = 0, groups_1 = groups; _i < groups_1.length; _i++) {
            var group = groups_1[_i];
            var sumWeightsOfRewards = group
                .rewards.reduce(function (sum, reward) { return sum + reward.weight; }, 0);
            var rewardsWithProbabilities = [];
            for (var _a = 0, _b = group.rewards; _a < _b.length; _a++) {
                var reward = _b[_a];
                rewardsWithProbabilities.push(__assign(__assign({}, reward), { weight: reward.weight / sumWeightsOfRewards }));
            }
            result.push(__assign(__assign({}, group), { rewards: rewardsWithProbabilities, weight: group.weight / sumWeightsOfGroups }));
        }
        return result;
    };
    GachaBannerUtils.flatRewardsFromGroupAndCalcProbabilities = function (groups) {
        var result = [];
        for (var _i = 0, groups_2 = groups; _i < groups_2.length; _i++) {
            var group = groups_2[_i];
            for (var _a = 0, _b = group.rewards; _a < _b.length; _a++) {
                var reward = _b[_a];
                result.push(__assign(__assign({}, reward), { weight: reward.weight * group.weight }));
            }
        }
        return result;
    };
    GachaBannerUtils.stackSameRewardsAndSumProbabilities = function (rewards) {
        var result = [];
        var sameRewards = {};
        for (var _i = 0, rewards_2 = rewards; _i < rewards_2.length; _i++) {
            var reward = rewards_2[_i];
            var rewardContent = reward.reward;
            var loot = new Loot();
            if (rewardContent.loot) {
                loot.combineLoot(rewardContent.loot);
            }
            else if (rewardContent.lootSettings && rewardContent.lootSettings.AdditionalFixedLoot) {
                loot.combineLoot(rewardContent.lootSettings.AdditionalFixedLoot);
            }
            else {
                result.push(reward);
                continue;
            }
            var hash = loot.getUniqueHashOfContent();
            var sameReward = sameRewards[hash];
            if (sameReward == undefined) {
                sameRewards[hash] = __assign(__assign({}, reward), { reward: __assign(__assign({}, rewardContent), { lootSettings: undefined, loot: loot }) });
                continue;
            }
            sameReward.reward.loot.combineLoot(loot);
            sameReward.weight += reward.weight;
        }
        for (var hash in sameRewards) {
            result.push(sameRewards[hash]);
        }
        return result;
    };
    return GachaBannerUtils;
}());
