function getGachaBanners(settings) {
    return GachaBanner.getActiveGachaBannersArray(settings);
}
function getGachaBannerSettings(settings) {
    return GachaBanner.getGachaBannerSettings(settings);
}
function getGachaBannerDetailsDrop(settings) {
    return GachaBanner.getGachaBannerDetailsDrop(settings);
}
function getGachaBannerVisualSettings(bannerId) {
    return GachaBannerUtils.getGachaBannerVisualSettings(bannerId);
}
function getGachaBannerSliderVisualSettings(bannerId) {
    return GachaBanner.getGachaBannerSliderVisualSettings(bannerId);
}
function getGachaBannerDetailsVisualSettings(bannerId) {
    return GachaBanner.getGachaBannerDetailsVisualSettings(bannerId);
}
function rollGachaBanner(settings) {
    return GachaBanner.rollGachaBanner(settings);
}
function multipleRollGachaBanner(settings) {
    return GachaBanner.multipleRollGachaBanner(settings);
}
function getGachaBannerProgressRolls(settings) {
    return GachaBanner.getGachaBannerProgressRolls(settings);
}
