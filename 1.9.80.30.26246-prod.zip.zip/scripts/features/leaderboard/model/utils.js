var LeaderboardUtils = (function () {
    function LeaderboardUtils() {
    }
    LeaderboardUtils.getHeroMiniIcons = function () {
        var result = {};
        for (var heroName in heroes) {
            var hero = heroes[heroName];
            result[hero.ID] = "Sprites/PreviewImages/HeroMiniIcons/mini_icon_"
                + hero.Alias.replace(/_/g, "");
        }
        return result;
    };
    LeaderboardUtils.getPlayerLeaderboardPercentile = function (settings) {
        var rating = settings.rating, section = settings.section, heroId = settings.heroId, checkPercentileDisplayBound = settings.checkPercentileDisplayBound;
        var table;
        switch (section) {
            case LEADERBOARD_SECTION.OVERALL:
                table = LeaderboardSettings.percentileTable.overall;
                break;
            case LEADERBOARD_SECTION.SINGLE:
                if (isNumber(heroId) && heroId > 0) {
                    table = LeaderboardSettings.percentileTable.heroes[heroId];
                }
                else {
                    table = LeaderboardSettings.percentileTable.topHeroes;
                }
                break;
            case LEADERBOARD_SECTION.SQUAD:
                table = LeaderboardSettings.percentileTable.team;
                break;
        }
        if (!table) {
            throw new Error("get percentile error: no table with settings for params ".concat(JSON.stringify(settings)));
        }
        var percentile = 100;
        for (var i = 0; i < table.length - 1; i += 2) {
            var r = table[i];
            var p = table[i + 1];
            if (rating <= r) {
                percentile = p;
                break;
            }
        }
        percentile = Math.max(1, Math.min(Math.round(101 - percentile), 100));
        return checkPercentileDisplayBound
            ? (percentile > LeaderboardSettings.startPercentileForDisplayPlayerTop ? null : percentile)
            : percentile;
    };
    LeaderboardUtils.convertLeaderboardPlaceTypeToTeamMode = function (type) {
        switch (type) {
            case LEADERBOARD_PLACE_TYPE.ANY_HERO:
                return TEAM_MODE._1_VS_1_;
            case LEADERBOARD_PLACE_TYPE.SQUAD:
                return TEAM_MODE._3_VS_3_;
            default:
                throw new Error("convertLeaderboardPlaceTypeToTeamMode: unsupported type ".concat(type, "."));
        }
    };
    LeaderboardUtils.calculateRewardForPlace = function (place, table) {
        var _a = table.reduce(function (acc, pl) { return [Math.min(acc[0], pl.minPlace), Math.max(acc[1], pl.maxPlace)]; }, [Infinity, -Infinity]), MIN_PLACE = _a[0], MAX_PLACE = _a[1];
        if (place > MAX_PLACE || place < MIN_PLACE) {
            return 0;
        }
        for (var ruleIndex = 0; ruleIndex < table.length; ruleIndex++) {
            var rule = table[ruleIndex];
            if (place >= rule.minPlace && place <= rule.maxPlace) {
                return rule.currencyAmount;
            }
        }
        return 0;
    };
    LeaderboardUtils.getLeaderboardReward = function (settings) {
        if (!settings || settings.length === 0) {
            return {};
        }
        var amountByType = {};
        for (var _i = 0, settings_1 = settings; _i < settings_1.length; _i++) {
            var playerPlace = settings_1[_i];
            var place = playerPlace.place, type = playerPlace.type;
            var teamMode = LeaderboardUtils.convertLeaderboardPlaceTypeToTeamMode(type);
            var table = LeaderboardUtils.getPlaceRewardTable(teamMode);
            var amount = LeaderboardUtils.calculateRewardForPlace(place, table);
            amountByType[type] = (amountByType[type] || 0) + amount;
        }
        return Object
            .keys(amountByType)
            .reduce(function (result, type) {
            var _a;
            result[type] = (_a = {}, _a[CURRENCY.CUSTOMIZATION_TOKEN] = amountByType[type], _a);
            return result;
        }, {});
    };
    LeaderboardUtils.getPlaceRewardTable = function (teamMode) {
        return LeaderboardSettings.leaderboardRewardRules[teamMode];
    };
    LeaderboardUtils.getPlaceRewardTableWithCurrencies = function (teamMode) {
        return LeaderboardUtils.getPlaceRewardTable(teamMode)
            .map(function (r) {
            var _a;
            return { maxPlace: r.maxPlace, minPlace: r.minPlace, reward: (_a = {}, _a[CURRENCY.CUSTOMIZATION_TOKEN] = r.currencyAmount, _a) };
        });
    };
    return LeaderboardUtils;
}());
