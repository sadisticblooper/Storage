function getHeroMiniIcons() {
    return LeaderboardUtils.getHeroMiniIcons();
}
function getPlayerLeaderboardPercentile(settings) {
    return LeaderboardUtils.getPlayerLeaderboardPercentile(settings);
}
function getLeaderboardSnapshotSchedule() {
    return LeaderboardSettings.leaderboardSnapshotSchedule;
}
function getLeaderboardReward(settings) {
    return LeaderboardUtils.getLeaderboardReward(settings);
}
function getLeaderboardRewardTable(settings) {
    return LeaderboardUtils.getPlaceRewardTableWithCurrencies(settings.teamMode);
}
