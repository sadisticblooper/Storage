var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a, _b, _c, _d, _e, _f;
var LeaderboardSettings = (function () {
    function LeaderboardSettings() {
    }
    var _g;
    _g = LeaderboardSettings;
    LeaderboardSettings.leaderboardUpdateInterval = new Time({ Minutes: 5 }).value;
    LeaderboardSettings.leaderboardDeltaInterval = new Time({ Hours: 6 }).value;
    LeaderboardSettings.leaderboardWriteDbInterval = new Time({ Hours: 3 }).value;
    LeaderboardSettings.lowerRatingToTakePartInLeaderboard = (_a = {},
        _a[LEADERBOARD_SECTION.OVERALL] = 6500,
        _a[LEADERBOARD_SECTION.SINGLE] = RatingSeasonsSettings.startRatingsForSeasons[TEAM_MODE._1_VS_1_],
        _a[LEADERBOARD_SECTION.SQUAD] = RatingSeasonsSettings.startRatingsForSeasons[TEAM_MODE._3_VS_3_],
        _a);
    LeaderboardSettings.topPlayersLimit = (_b = {},
        _b[LEADERBOARD_SECTION.OVERALL] = 200,
        _b[LEADERBOARD_SECTION.SINGLE] = 200,
        _b[LEADERBOARD_SECTION.SQUAD] = 200,
        _b);
    LeaderboardSettings.showPlayerPositionForTop = (_c = {},
        _c[LEADERBOARD_SECTION.OVERALL] = 200,
        _c[LEADERBOARD_SECTION.SINGLE] = 200,
        _c[LEADERBOARD_SECTION.SQUAD] = 200,
        _c);
    LeaderboardSettings.startPercentileForDisplayPlayerTop = 50;
    LeaderboardSettings.topPlayersLastSeasonLimitStore = (_d = {},
        _d[LEADERBOARD_SECTION.OVERALL] = 10,
        _d[LEADERBOARD_SECTION.SINGLE] = 200,
        _d[LEADERBOARD_SECTION.SQUAD] = 200,
        _d);
    LeaderboardSettings.topPlayersLastSeasonLimitDisplay = (_e = {},
        _e[LEADERBOARD_SECTION.OVERALL] = 10,
        _e[LEADERBOARD_SECTION.SINGLE] = 10,
        _e[LEADERBOARD_SECTION.SQUAD] = 10,
        _e);
    LeaderboardSettings.leaderboardSnapshotSchedule = {
        Origin: "2016-01-01T03:00:00+03",
        Period: new Time({ Days: 1 }).value
    };
    LeaderboardSettings.leaderboardRewardRules = (_f = {},
        _f[TEAM_MODE._1_VS_1_] = [
            { minPlace: 1, maxPlace: 1, currencyAmount: 150 },
            { minPlace: 2, maxPlace: 2, currencyAmount: 125 },
            { minPlace: 3, maxPlace: 3, currencyAmount: 100 },
            { minPlace: 4, maxPlace: 10, currencyAmount: 80 },
            { minPlace: 11, maxPlace: 30, currencyAmount: 60 },
            { minPlace: 31, maxPlace: 50, currencyAmount: 40 },
            { minPlace: 51, maxPlace: 100, currencyAmount: 20 }
        ],
        _f[TEAM_MODE._3_VS_3_] = [
            { minPlace: 1, maxPlace: 1, currencyAmount: 150 },
            { minPlace: 2, maxPlace: 2, currencyAmount: 125 },
            { minPlace: 3, maxPlace: 3, currencyAmount: 100 },
            { minPlace: 4, maxPlace: 10, currencyAmount: 80 },
            { minPlace: 11, maxPlace: 30, currencyAmount: 60 },
            { minPlace: 31, maxPlace: 50, currencyAmount: 40 },
            { minPlace: 51, maxPlace: 100, currencyAmount: 20 }
        ],
        _f);
    LeaderboardSettings.percentileTableUnreleasedHeroes = {};
    LeaderboardSettings.percentileTable = {
        team: LEADERBOARD_PERCENTILE_TABLE.team,
        overall: LEADERBOARD_PERCENTILE_TABLE.overall,
        heroes: __assign(__assign({}, _g.percentileTableUnreleasedHeroes), LEADERBOARD_PERCENTILE_TABLE.heroes),
        topHeroes: LEADERBOARD_PERCENTILE_TABLE.topHeroes,
    };
    return LeaderboardSettings;
}());
