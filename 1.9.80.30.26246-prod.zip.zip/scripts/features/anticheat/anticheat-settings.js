var AntiCheatSettings = (function () {
    function AntiCheatSettings() {
    }
    AntiCheatSettings.ratingToUnlockAntiCheat = ArenaConstants.arenaFeatures[ARENA_FEATURE.ANTI_CHEAT].rating;
    AntiCheatSettings.disableLowPriorityDetection = false;
    AntiCheatSettings.matchesToSpectatePlayer = 10;
    AntiCheatSettings.badMatchesToEnableLowPriority = 4;
    AntiCheatSettings.lowPriorityDuration = new Time({ Minutes: 15 }).value;
    AntiCheatSettings.lowPriorityDeltaDurationForRepeat = new Time({ Minutes: 5 }).value;
    AntiCheatSettings.dirtyCarmaCleanDuration = new Time({ Minutes: 60 }).value;
    AntiCheatSettings.maxDirtyCarma = 9;
    AntiCheatSettings.botRestrictionWarmupTime = new Time({ Minutes: 10 }).value;
    AntiCheatSettings.redReasons = [
        PvpFinishReason.PFR_CHOOSING_CONN_TYPE_TIMEOUT,
        PvpFinishReason.PFR_CHOOSING_CONN_TYPE_TIMEOUT_BAD_PING,
        PvpFinishReason.PFR_LOCAL_BAD_PING,
        PvpFinishReason.PFR_EXTERNAL_BAD_PING,
        PvpFinishReason.PFR_CHOOSING_CONN_TYPE_ABORTED,
        PvpFinishReason.PFR_ABORT_REQUESTED,
        PvpFinishReason.PFR_PAUSE_FAILED,
    ];
    AntiCheatSettings.skipReasonsNotStartedFight = [
        PvpFinishReason.PFR_CHOOSING_CONN_TYPE_TIMEOUT,
    ];
    return AntiCheatSettings;
}());
