var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var MultiBonus = (function () {
    function MultiBonus(settings) {
        this.ID = settings.ID;
        this.multiplier = settings.multiplier;
        this.endCondition = settings.endCondition;
        this.multiBonusSlots = settings.multiBonusSlots;
        this.storeTooltip = settings.storeTooltip;
        this.popUp = settings.popUp;
        var offerSettings = __assign(__assign({}, settings.promoSettings), { country: settings.promoSettings.country ? settings.promoSettings.country : [], ignoredCountry: settings.promoSettings.ignoredCountry ? settings.promoSettings.ignoredCountry : [], ID: this.ID, offerNameAlias: null, lootSettings: null, offerType: PROMO_OFFER_TYPE.DYNAMIC, visualPresetId: null });
        this.promoOffer = new PromoOffer(offerSettings);
    }
    MultiBonus.prototype.getPromoOffer = function () {
        return this.promoOffer;
    };
    MultiBonus.prototype.checkEndConditions = function (uniquePurchases) {
        if (this.endCondition == END_MULTIBONUS_CONDITION.ONE_TIME_PURCHASE && uniquePurchases > 0) {
            return false;
        }
        return !(this.endCondition == END_MULTIBONUS_CONDITION.FULL_SLOT_PURCHASE
            && Object.keys(this.multiBonusSlots).length == uniquePurchases);
    };
    MultiBonus.getActiveMultiBonuses = function (settings) {
        var converter = new MultiBonusToOffersConverter();
        var itemsGetter = new GettingItemsLikeOffers(multiBonusMap, converter);
        var activeMultiBonuses = itemsGetter.getPromos(settings);
        return this.setPriorityOrder(activeMultiBonuses);
    };
    MultiBonus.getMultiBonusById = function (id) {
        var multiBonus = multiBonusMap.checkedGet(id);
        return {
            multiplier: multiBonus.multiplier,
            storeTooltip: multiBonus.storeTooltip,
            timer: VisualConstants.commonTimerSettings,
        };
    };
    MultiBonus.setPriorityOrder = function (activeMultiBonuses) {
        if (activeMultiBonuses.length == 0) {
            return activeMultiBonuses;
        }
        return activeMultiBonuses.sort(function (a, b) {
            var multiBonusA = multiBonusMap.checkedGet(a.multiBonusId);
            var MultiBonusB = multiBonusMap.checkedGet(b.multiBonusId);
            if (multiBonusA.multiplier != MultiBonusB.multiplier) {
                return MultiBonusB.multiplier - multiBonusA.multiplier;
            }
            else if (a.expireTime != b.expireTime) {
                return a.expireTime - a.expireTime;
            }
            else {
                return b.multiBonusId - a.multiBonusId;
            }
        });
    };
    MultiBonus.getMultiBonusPopupSettingsById = function (settings) {
        var id = settings.id, expireTime = settings.expireTime;
        var isCareGameBuild = CareGameState.getIsCareGameBuild();
        var multiBonus = multiBonusMap.get(id);
        var data = multiBonus && multiBonus.popUp.data;
        if (data && expireTime) {
            data = __assign(__assign({}, data), { endDate: expireTime });
        }
        if (CommonPopUpUtils.breakPopUpForCareGame(data, isCareGameBuild)) {
            return null;
        }
        return data;
    };
    MultiBonus.getMultiBonusPopupVisualSettings = function (multiBonusId) {
        var multiBonus = multiBonusMap.get(multiBonusId);
        return multiBonus && multiBonus.popUp.visual;
    };
    return MultiBonus;
}());
