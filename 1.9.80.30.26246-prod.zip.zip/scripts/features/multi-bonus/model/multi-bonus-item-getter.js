var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var MultiBonusToOffersConverter = (function () {
    function MultiBonusToOffersConverter() {
    }
    MultiBonusToOffersConverter.prototype.Args = function (p) {
        return __assign(__assign({}, p), { generatedOffers: this._generatedMultiBonusToOffers(p.generatedMultiBonuses, p.closedMultiBonuses, p.serverCurrentTime), generatedRoulette: [], generatedOffersAnotherSource: p.generatedOffers });
    };
    MultiBonusToOffersConverter.prototype.Result = function (p) {
        var result = [];
        var items = p.offers;
        if (items) {
            for (var id in items)
                if (items[id] != undefined) {
                    result.push({
                        expireTime: items[id].expireTime,
                        multiBonusId: +id,
                    });
                }
        }
        return result;
    };
    MultiBonusToOffersConverter.prototype.Type = function (p) {
        return p.getPromoOffer();
    };
    MultiBonusToOffersConverter.prototype._generatedMultiBonusToOffers = function (generatedMultiBonuses, closed, serverTime) {
        var result = {};
        for (var _i = 0, generatedMultiBonuses_1 = generatedMultiBonuses; _i < generatedMultiBonuses_1.length; _i++) {
            var item = generatedMultiBonuses_1[_i];
            var multiBonus = multiBonusMap.get(item.multiBonusId);
            if (multiBonus) {
                result[multiBonus.ID] = {
                    expireTime: item.expireTime,
                    purchaseCount: 0,
                    seed: 1,
                    universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                };
            }
        }
        if (closed) {
            closed = getArrayFromRaw(closed);
            for (var _a = 0, closed_1 = closed; _a < closed_1.length; _a++) {
                var id = closed_1[_a];
                result[id] = {
                    expireTime: 1,
                    purchaseCount: 1,
                    seed: 1,
                    universalOfferParameter: PROMO_OFFER_UNIVERSAL_TYPE.NONE,
                };
            }
        }
        return result;
    };
    return MultiBonusToOffersConverter;
}());
