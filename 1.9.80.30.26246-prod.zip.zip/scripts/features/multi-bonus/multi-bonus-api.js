function getActiveMultiBonuses(settings) {
    return MultiBonus.getActiveMultiBonuses(settings);
}
function getMultiBonusById(id) {
    return MultiBonus.getMultiBonusById(id);
}
function getMultiBonusPopupSettingsById(settings) {
    return MultiBonus.getMultiBonusPopupSettingsById(settings);
}
function getMultiBonusPopupVisualSettings(multiBonusId) {
    return MultiBonus.getMultiBonusPopupVisualSettings(multiBonusId);
}
