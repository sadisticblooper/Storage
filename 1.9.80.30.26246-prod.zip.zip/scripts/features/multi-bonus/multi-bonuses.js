var multiBonuses = {
    STARTER_MB_X2: new MultiBonus({
        ID: 2,
        multiplier: 2,
        endCondition: END_MULTIBONUS_CONDITION.ONE_TIME_PURCHASE,
        multiBonusSlots: {
            2: ShopSlots.RUBIES_SLOT_3_X2,
            3: ShopSlots.RUBIES_SLOT_4_X2,
            4: ShopSlots.RUBIES_SLOT_5_X2,
            5: ShopSlots.RUBIES_SLOT_6_X2,
        },
        promoSettings: {
            conditions: {},
            activeTime: {
                duration: new Time({ Hours: 12 }).value
            },
            checkForOffersFromAnotherSource: {
                oneOfIgnoredOffers: [7407, 7408, 7409],
            },
        },
        storeTooltip: "tooltip_rubypack_getall",
        popUp: MultiBonusesPopUps.common,
    }),
    STARTER_MB_X3: new MultiBonus({
        ID: 3,
        multiplier: 3,
        endCondition: END_MULTIBONUS_CONDITION.ONE_TIME_PURCHASE,
        multiBonusSlots: {
            0: ShopSlots.RUBIES_SLOT_1_X3,
            1: ShopSlots.RUBIES_SLOT_2_X3,
            2: ShopSlots.RUBIES_SLOT_3_X3,
            3: ShopSlots.RUBIES_SLOT_4_X3,
            4: ShopSlots.RUBIES_SLOT_5_X3,
            5: ShopSlots.RUBIES_SLOT_6_X3,
        },
        promoSettings: {
            conditions: {},
            activeTime: {
                duration: new Time({ Hours: 24 }).value
            },
            checkForOffersFromAnotherSource: {
                oneOfIgnoredOffers: [7402, 7410, 7411],
            },
        },
        storeTooltip: "tooltip_rubypack_getall",
        popUp: MultiBonusesPopUps.common,
    }),
    STARTER_MB_X2_T20: new MultiBonus({
        ID: 4,
        multiplier: 2,
        endCondition: END_MULTIBONUS_CONDITION.ONE_TIME_PURCHASE,
        multiBonusSlots: {
            2: ShopSlots.RUBIES_SLOT_3_X2,
            3: ShopSlots.RUBIES_SLOT_4_X2,
            4: ShopSlots.RUBIES_SLOT_5_X2,
            5: ShopSlots.RUBIES_SLOT_6_X2,
        },
        promoSettings: {
            conditions: {},
            activeTime: {
                duration: new Time({ Hours: 12 }).value
            },
            checkForOffersFromAnotherSource: {
                oneOfIgnoredOffers: [7437, 7438, 7440],
            },
        },
        storeTooltip: "tooltip_rubypack_getall",
        popUp: MultiBonusesPopUps.common,
    }),
    STARTER_MB_X3_T20: new MultiBonus({
        ID: 5,
        multiplier: 3,
        endCondition: END_MULTIBONUS_CONDITION.ONE_TIME_PURCHASE,
        multiBonusSlots: {
            0: ShopSlots.RUBIES_SLOT_1_X3,
            1: ShopSlots.RUBIES_SLOT_2_X3,
            2: ShopSlots.RUBIES_SLOT_3_X3,
            3: ShopSlots.RUBIES_SLOT_4_X3,
            4: ShopSlots.RUBIES_SLOT_5_X3,
            5: ShopSlots.RUBIES_SLOT_6_X3,
        },
        promoSettings: {
            conditions: {},
            activeTime: {
                duration: new Time({ Hours: 24 }).value
            },
            checkForOffersFromAnotherSource: {
                oneOfIgnoredOffers: [7432, 7441, 7439],
            },
        },
        storeTooltip: "tooltip_rubypack_getall",
        popUp: MultiBonusesPopUps.common,
    }),
};
var multiBonusMap = createIDMap(multiBonuses, "multiBonusMap");
