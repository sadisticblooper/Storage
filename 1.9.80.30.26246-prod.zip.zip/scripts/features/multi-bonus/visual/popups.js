var MultiBonusesPopUps = (function () {
    function MultiBonusesPopUps() {
    }
    MultiBonusesPopUps.common = {
        data: {
            "ID": 8000,
            "priority": 5,
            "navigation": POPUP_NAVIGATION.NAVIGATION_LINK,
            "navigationArg": 0,
            "navigationLinkURL": "sfa://shop?section=Currencies",
            "activeTime": [],
            "endDate": null,
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": null,
            "iconBackground": {
                "sprite": "Sprites/PreviewImages/Bonus/icon_bonus_back",
                "color": "#FFD75E"
            },
            "iconLabel": {
                "alias": "x2",
                "color": "#8A7433"
            },
            "rulesDescription": null,
            "rulesHeader": null,
            "header": {
                "alias": "bonus_card",
                "color": "#FFD75E"
            },
            "subHeader": {
                "alias": "multi_bonus_popup_subheader",
                "color": "#FFFFFF"
            },
            "timer": {
                "alias": "multi_bonus_popup_ends_in",
                "color": "#FFD75E"
            },
            "content": {
                "alias": "popup_title_rubypack_getone",
                "color": "#FFFFFFB8"
            },
            "button": {
                "alias": "button_shop",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Bonus/bonus_art",
                "color": "#FFFFFF"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Bonus/background_bonus",
                "color": "#FFFFFF"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#FF5E768A"
            },
            "particles": {
                "maxColor": "#FF5E76B2",
                "minColor": "#FF5E764C"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#5C222B"
                    },
                    {
                        "time": 0.98,
                        "color": "#5C222B"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#A11F32"
                    },
                    {
                        "time": 0.99,
                        "color": "#E5C76A"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": null,
            "pattern": {
                "sprite": "Sprites/PreviewImages/Bonus/pattern_bonus",
                "color": "#FFDD752E"
            },
            "popupType": ActivityPopupType.Offer,
        },
    };
    return MultiBonusesPopUps;
}());
