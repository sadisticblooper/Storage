var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var Hint = (function () {
    function Hint(js) {
        this.ID = js.ID;
        this.Alias = js.Alias;
        this.SpecifiedAliasGetter = js.SpecifiedAliasGetter;
    }
    Hint.prototype.getAlias = function (settings) {
        return this.SpecifiedAliasGetter
            ? this.SpecifiedAliasGetter(settings)
            : this.Alias;
    };
    Hint.getVsHints = function (settings) {
        var result;
        var ids = [];
        var intervalIndexes = CommonGameUtils.getNumberIntervalIndexes(settings.rating, HintConstants.hintsRatingZones);
        for (var _i = 0, intervalIndexes_1 = intervalIndexes; _i < intervalIndexes_1.length; _i++) {
            var index = intervalIndexes_1[_i];
            ids = __spreadArray(__spreadArray([], ids, true), HintConstants.hintsRatingZones[index].items, true);
        }
        result = ids.map(function (id) { return HintsMap.checkedGet(id).getAlias(settings); });
        result = ArrayUtils.getUniqueArray(result);
        RandomInstance.setSeed(CommonUtils.getRandomJSSeed());
        shuffle(result, RandomInstance);
        return result ? result : [];
    };
    return Hint;
}());
