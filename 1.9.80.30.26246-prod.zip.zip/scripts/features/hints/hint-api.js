function getVsHints(settings) {
    return Hint.getVsHints(settings);
}
