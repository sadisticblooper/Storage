var Hints = {
    Hint_Text_Wall: new Hint({
        ID: 1,
        Alias: "Hint_Text_Wall",
    }),
    Hint_Text_Bypass: new Hint({
        ID: 2,
        Alias: "Hint_Text_Bypass",
        SpecifiedAliasGetter: function (s) { return s.isNonMobile ? "Hint_Text_Bypass_non_mobile" : "Hint_Text_Bypass"; },
    }),
    Hint_Text_Roll: new Hint({
        ID: 3,
        Alias: "Hint_Text_Roll",
    }),
    Hint_Text_Kicks: new Hint({
        ID: 4,
        Alias: "Hint_Text_Kicks",
    }),
    Hint_Text_ShadowEnergy: new Hint({
        ID: 5,
        Alias: "Hint_Text_ShadowEnergy",
    }),
    Hint_Text_KnockDown: new Hint({
        ID: 6,
        Alias: "Hint_Text_KnockDown",
    }),
    Hint_Text_AntishadowHeroes: new Hint({
        ID: 7,
        Alias: "Hint_Text_AntishadowHeroes",
    }),
    Hint_Text_Closeranged: new Hint({
        ID: 8,
        Alias: "Hint_Text_Closeranged",
    }),
    Hint_Text_Throw: new Hint({
        ID: 9,
        Alias: "Hint_Text_Throw",
        SpecifiedAliasGetter: function (s) { return s.isNonMobile ? "Hint_Text_Throw_non_mobile" : "Hint_Text_Throw"; },
    }),
    Hint_Text_Hops: new Hint({
        ID: 10,
        Alias: "Hint_Text_Hops",
    }),
    Hint_Text_Unbreak: new Hint({
        ID: 11,
        Alias: "Hint_Text_Unbreak",
    }),
    Hint_Text_Crouch: new Hint({
        ID: 12,
        Alias: "Hint_Text_Crouch",
    }),
    Hint_Text_CrouchBlock: new Hint({
        ID: 13,
        Alias: "Hint_Text_CrouchBlock",
    }),
    Hint_Text_Predictability: new Hint({
        ID: 14,
        Alias: "Hint_Text_Predictability",
    }),
    Hint_Text_Timer: new Hint({
        ID: 15,
        Alias: "Hint_Text_Timer",
    }),
    Hint_Text_Talents: new Hint({
        ID: 16,
        Alias: "Hint_Text_Talents",
    }),
    Hint_Text_Block: new Hint({
        ID: 17,
        Alias: "Hint_Text_Block",
    }),
    Hint_Text_Training: new Hint({
        ID: 18,
        Alias: "Hint_Text_Training",
    }),
    Hint_Text_Knowledge: new Hint({
        ID: 19,
        Alias: "Hint_Text_Knowledge",
    }),
    Hint_Text_Guides: new Hint({
        ID: 20,
        Alias: "Hint_Text_Guides",
    }),
    Hint_Text_Pve: new Hint({
        ID: 21,
        Alias: "Hint_Text_Pve",
    }),
    Hint_Text_Shards: new Hint({
        ID: 22,
        Alias: "Hint_Text_Shards",
    }),
    Hint_Text_Tournaments: new Hint({
        ID: 23,
        Alias: "Hint_Text_Tournaments",
    }),
    Hint_Text_Energy: new Hint({
        ID: 24,
        Alias: "Hint_Text_Energy",
    }),
    Hint_Text_Never: new Hint({
        ID: 25,
        Alias: "Hint_Text_Never",
    }),
    Hint_Text_Friends: new Hint({
        ID: 26,
        Alias: "Hint_Text_Friends",
    }),
    Hint_Text_Pushback: new Hint({
        ID: 27,
        Alias: "Hint_Text_Pushback",
    }),
    Hint_Text_Magic: new Hint({
        ID: 28,
        Alias: "Hint_Text_Magic",
    }),
    Hint_Text_Physical: new Hint({
        ID: 29,
        Alias: "Hint_Text_Physical",
    }),
    Hint_Text_SuccessfulAttack: new Hint({
        ID: 30,
        Alias: "Hint_Text_SuccessfulAttack",
    }),
    Hint_Text_Stories: new Hint({
        ID: 31,
        Alias: "Hint_Text_Stories",
    }),
    Hint_Text_OpponentTalents: new Hint({
        ID: 32,
        Alias: "Hint_Text_OpponentTalents",
    }),
    Hint_Text_Jumps: new Hint({
        ID: 33,
        Alias: "Hint_Text_Jumps",
    }),
    Hint_Text_Practice: new Hint({
        ID: 34,
        Alias: "Hint_Text_Practice",
    }),
    Hint_Text_Lying: new Hint({
        ID: 35,
        Alias: "Hint_Text_Lying",
    }),
    Hint_Text_Shadow_damage: new Hint({
        ID: 36,
        Alias: "hint_text_shadow_damage",
    }),
};
var HintsMap = createIDMap(Hints, "HintsMap");
