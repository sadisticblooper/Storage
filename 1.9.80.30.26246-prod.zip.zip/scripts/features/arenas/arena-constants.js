var _a;
var ArenaConstants = (function () {
    function ArenaConstants() {
    }
    ArenaConstants.ratingBoundsToShowPopUp = {
        start: 0,
        end: 300,
    };
    ArenaConstants.maxArenaNumber = 10;
    ArenaConstants.arenaIdAfterTutorial = 2;
    ArenaConstants.arenaFeatures = (_a = {},
        _a[ARENA_FEATURE.QUESTS] = { rating: 100 },
        _a[ARENA_FEATURE.TEAM_MODES] = { rating: 1400 },
        _a[ARENA_FEATURE.WEAPONS] = { rating: 0 },
        _a[ARENA_FEATURE.CHEST_IN_LOBBY] = { rating: 20 },
        _a[ARENA_FEATURE.ROGUELIKE] = { rating: 50 },
        _a[ARENA_FEATURE.ANTI_CHEAT] = { rating: 0 },
        _a);
    return ArenaConstants;
}());
