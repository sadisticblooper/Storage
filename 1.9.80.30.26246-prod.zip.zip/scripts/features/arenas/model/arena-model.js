var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ArenaCheckpoint = (function () {
    function ArenaCheckpoint(js) {
        this.ID = js.ID;
        this.NameInf = js.NameInf;
        this.Icon = js.Icon;
        this.DotIcon = getValueByKeyDefault(js, "DotIcon", "");
        this.Rating = js.Rating;
        this.Reward = js.Reward;
        this.HackReward = getValueByKeyDefault(js, "HackReward", null);
        this.ChestIfHeroExists = getValueByKeyDefault(js, "ChestIfHeroExists", null);
    }
    ;
    ArenaCheckpoint.prototype.getLootSettings = function () {
        return this.HackReward
            ? (this.HackReward.lootSettings ? this.HackReward.lootSettings : {})
            : (this.Reward.lootSettings ? this.Reward.lootSettings : {});
    };
    ArenaCheckpoint.prototype.getChests = function (playerProgress) {
        if (this.ChestIfHeroExists && playerProgress.heroes[this.ChestIfHeroExists.heroId] != undefined) {
            return [this.ChestIfHeroExists.chestId];
        }
        return this.HackReward
            ? (this.HackReward.chests ? this.HackReward.chests : [])
            : (this.Reward.chests ? this.Reward.chests : []);
    };
    ArenaCheckpoint.prototype.getLoot = function () {
        return this.HackReward ? this.HackReward.loot : this.Reward.loot;
    };
    return ArenaCheckpoint;
}());
var Arena = (function (_super) {
    __extends(Arena, _super);
    function Arena(js) {
        var _this = _super.call(this, js) || this;
        _this.DemotionRating = js.DemotionRating;
        _this.RatingIncSpeed = js.RatingIncSpeed;
        _this.RatingDecSpeed = js.RatingDecSpeed;
        _this.CanDemote = js.CanDemote;
        _this.ArenaNumber = js.ArenaNumber;
        _this.SeasonEndReward = false;
        _this.BackGround = getValueByKeyDefault(js, "BackGround", "");
        _this.NotShowBackground = getValueByKeyDefault(js, "NotShowBackground", false);
        _this.League = getValueByKeyDefault(js, "League", false);
        _this.HeroLevelAvg = getValueByKeyDefault(js, "HeroLevelAvg", _this.ArenaNumber);
        _this.AccountLevelAvg = getValueByKeyDefault(js, "AccountLevelAvg", _this.ArenaNumber);
        _this.DisableBotPenalty = getValueByKeyDefault(js, "DisableBotPenalty", false);
        _this.LeaderboardBgColor = getValueByKeyDefault(js, "LeaderboardBgColor", "#ffffffff");
        return _this;
    }
    ;
    return Arena;
}(ArenaCheckpoint));
