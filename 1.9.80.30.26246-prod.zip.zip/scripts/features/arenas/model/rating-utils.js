var RatingUtils = (function () {
    function RatingUtils() {
    }
    RatingUtils.getTotalRatingCap = function () {
        var heroRankRatingCup = CalculationRatingSettings.rankRatingCap[TEAM_MODE._1_VS_1_];
        var squadRankRatingCup = CalculationRatingSettings.rankRatingCap[TEAM_MODE._3_VS_3_];
        return heroesMap.getKeys().length * heroRankRatingCup + squadRankRatingCup;
    };
    RatingUtils.calcDeltaRating = function (settings) {
        if (TutorialModel.isTutorialDeltaRating(settings.battleId)) {
            return TutorialModel.calcDeltaRatingTutorial(settings);
        }
        if ([FIGHT_MODE.RANKED, FIGHT_MODE.PRE_TUTORIAL, FIGHT_MODE.TUTORIAL]
            .indexOf(settings.matchingInfo.mode) == -1) {
            return null;
        }
        var fightResult = settings.fightResult, playerRating = settings.playerRating, matchingInfo = settings.matchingInfo, pvpWinStreak = settings.pvpWinStreak, playerRankRating = settings.playerRankRating, playerAccountLevel = settings.playerAccountLevel, playerFormation = settings.playerFormation, enemyAccountLevel = settings.enemyAccountLevel, enemyFormation = settings.enemyFormation;
        var targetHero = playerFormation.formationId == TEAM_MODE._1_VS_1_ ? playerFormation.heroes[0].heroID : 0;
        var teamMode = playerFormation.formationId;
        var playerWarriors = playerFormation.heroes;
        var enemyWarriors = enemyFormation.heroes;
        var result = { commonRankRating: 0, winStreakRankRating: 0, targetHeroId: targetHero };
        if (fightResult == FIGHT_RESULT.DRAW
            || fightResult == FIGHT_RESULT.TECH_DRAW
            || MatchingModel.isRankRatingBoundForBotsReached(matchingInfo, playerRankRating)) {
            return result;
        }
        var isWin = (fightResult == FIGHT_RESULT.WIN) || (fightResult == FIGHT_RESULT.TECH_WIN);
        var ratingAfterTutorial = arenasMap.checkedGet(ArenaConstants.arenaIdAfterTutorial).Rating;
        var deltaRatingTable = CalculationRatingSettings.deltaRatingSettings[teamMode];
        var deltaRatingIndex = CommonGameUtils.getNumberIntervalIndex(playerRankRating, deltaRatingTable);
        var deltaRatingSettings = deltaRatingTable[deltaRatingIndex].items[0];
        var winStreakRating = RatingUtils.getRatingForWinStreak(pvpWinStreak);
        var deltaRating = isWin ? deltaRatingSettings.incRating : -deltaRatingSettings.decRating;
        var rankRatingCap = CalculationRatingSettings.rankRatingCap[matchingInfo.teamMode];
        var minDemoteRankRating = CalculationRatingSettings.minDemoteRankRating[matchingInfo.teamMode];
        var playerMetaPower = RatingUtils.getMetaPower({
            heroLevels: playerWarriors.map(function (w) { return w.warriorLevel; }),
            accountLevel: playerAccountLevel,
        });
        var enemyMetaPower = RatingUtils.getMetaPower({
            heroLevels: enemyWarriors.map(function (w) { return w.warriorLevel; }),
            accountLevel: enemyAccountLevel,
        });
        if (playerRating < ratingAfterTutorial) {
            return RatingUtils.calcDeltaRatingInTutorial(isWin, ratingAfterTutorial, playerRating, deltaRatingSettings.incRating, targetHero);
        }
        if (teamMode == TEAM_MODE._1_VS_1_) {
            winStreakRating = 0;
        }
        if (matchingInfo.enemyMode == ENEMY_MODE.COMMON_BOT) {
            winStreakRating = 0;
            deltaRating *= RatingUtils.getBotPowerPenalty({
                actualValue: playerMetaPower,
                rankRating: playerRankRating,
                teamMode: matchingInfo.teamMode,
            });
        }
        if (isWin && deltaRating < 0 || !isWin && deltaRating > 0) {
            deltaRating = 0;
        }
        if (deltaRating < 0) {
            deltaRating *= RatingUtils.getUnderdogModifier(playerMetaPower, enemyMetaPower, teamMode);
        }
        if (deltaRating > 0) {
            if (playerRankRating + deltaRating + winStreakRating > rankRatingCap) {
                if (playerRankRating + deltaRating > rankRatingCap) {
                    deltaRating = rankRatingCap - playerRankRating;
                    winStreakRating = 0;
                }
                else {
                    winStreakRating = rankRatingCap - (playerRankRating + deltaRating);
                }
            }
        }
        else {
            var rankRatingCorrection = 0;
            var playerRatingCorrection = 0;
            if (playerRankRating >= minDemoteRankRating) {
                rankRatingCorrection = playerRankRating + deltaRating - minDemoteRankRating;
                rankRatingCorrection = rankRatingCorrection < 0 ? Math.abs(rankRatingCorrection) : 0;
            }
            if (playerRating >= ratingAfterTutorial) {
                playerRatingCorrection = playerRating + deltaRating - ratingAfterTutorial;
                playerRatingCorrection = playerRatingCorrection < 0 ? Math.abs(playerRatingCorrection) : 0;
            }
            deltaRating += Math.max(rankRatingCorrection, playerRatingCorrection);
        }
        result.commonRankRating = Math.round(deltaRating);
        result.winStreakRankRating = Math.round(winStreakRating);
        return result;
    };
    RatingUtils.calcDeltaRatingInTutorial = function (isWin, ratingAfterTutorial, playerRating, incDeltaRating, targetHeroId) {
        var result = { commonRankRating: 0, winStreakRankRating: 0, targetHeroId: targetHeroId };
        var startRating = PlayerDefaults.Rating;
        var deltaRating;
        if (isWin) {
            var tutorialFights = TutorialConstants.tutorialTotalFights;
            deltaRating = ((ratingAfterTutorial - startRating) / tutorialFights) >> 0;
            if (deltaRating) {
                var currentFightCounter = (playerRating - startRating) / deltaRating >> 0;
                var nextRatingPosition = (currentFightCounter + 1) * deltaRating;
                deltaRating = nextRatingPosition - playerRating;
            }
            if (deltaRating <= 0) {
                deltaRating = incDeltaRating;
            }
        }
        else {
            deltaRating = 0;
        }
        result.commonRankRating = deltaRating;
        return result;
    };
    RatingUtils.getUnderdogModifier = function (playerPower, enemyPower, teamMode) {
        var delta = enemyPower - playerPower;
        var table = CalculationRatingSettings.underdogSettings[teamMode];
        var index = CommonGameUtils.getNumberIntervalIndex(delta, table);
        return table[index].items[0];
    };
    RatingUtils.getBotPowerPenalty = function (settings) {
        var rankRating = settings.rankRating, actualValue = settings.actualValue, teamMode = settings.teamMode;
        var defaultResult = 1;
        var tableSettings = CalculationRatingSettings.botPowerPenalty[teamMode];
        if (tableSettings) {
            var index = CommonGameUtils.getNumberIntervalIndex(rankRating, tableSettings);
            var intervalSettings = tableSettings[index];
            if (intervalSettings) {
                var minDelta = Infinity;
                var itemIndex = -1;
                for (var i = 0; i < intervalSettings.items.length; i++) {
                    var penalty = intervalSettings.items[i];
                    var delta = Math.abs(penalty.L - actualValue);
                    if (delta < minDelta) {
                        minDelta = delta;
                        itemIndex = i;
                    }
                }
                if (itemIndex == -1) {
                    throw new Error("No such Multiply in " +
                        "CalculationRatingSettings.botPowerPenalty for " + rankRating + ", " + actualValue + "!");
                }
                return intervalSettings.items[itemIndex].K;
            }
        }
        return defaultResult;
    };
    RatingUtils.getRecommendedValueWithoutBotPenalty = function (rankRating, teamMode) {
        var tableSettings = CalculationRatingSettings.botPowerPenalty[teamMode];
        if (tableSettings) {
            var index = CommonGameUtils.getNumberIntervalIndex(rankRating, tableSettings);
            var intervalSettings = tableSettings[index];
            if (intervalSettings) {
                var maxK = { maxK: 0, value: -1 };
                for (var _i = 0, _a = intervalSettings.items; _i < _a.length; _i++) {
                    var penalty = _a[_i];
                    if (penalty.K >= maxK.maxK) {
                        maxK.maxK = penalty.K;
                        maxK.value = penalty.L;
                    }
                }
                return maxK.value;
            }
        }
        return -1;
    };
    RatingUtils.getRatingForWinStreak = function (streak) {
        var index = CommonGameUtils.getNumberIntervalIndex(streak, CalculationRatingSettings.winStreakSettings);
        return CalculationRatingSettings.winStreakSettings[index].items[0];
    };
    RatingUtils.getMetaPower = function (settings) {
        var accountLevel = settings.accountLevel, heroLevels = settings.heroLevels;
        var maxHeroLevel = Math.max.apply(Math, heroLevels);
        return accountLevel + maxHeroLevel;
    };
    RatingUtils.getFightResult = function (settings) {
        var battleId = settings.battleId, battlePassProgress = settings.battlePassProgress, enemyRankRating = settings.enemyRankRating, fightResult = settings.fightResult, matchingInfo = settings.matchingInfo, maxPlayerRankRating = settings.maxPlayerRankRating, playerRankRating = settings.playerRankRating, pvpWinStreak = settings.pvpWinStreak, fightRewardProgressionCounters = settings.fightRewardProgressionCounters, seed = settings.seed, enemyAccountLevel = settings.enemyAccountLevel, enemyFormation = settings.enemyFormation, playerFormation = settings.playerFormation, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, adViewCounterInRanked = settings.adViewCounterInRanked, lastRatingForMilestoneReward = settings.lastRatingForMilestoneReward, fightCount = settings.fightCount;
        var teamMode = matchingInfo.teamMode;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var updatedLastRatingForMilestoneReward = lastRatingForMilestoneReward || 0;
        var updatedFightCount = fightCount || 0;
        var deltaRatingResult = calcDeltaRating({
            playerRating: playerProgress.playerRating,
            playerRankRating: playerRankRating,
            enemyRankRating: enemyRankRating,
            playerAccountLevel: playerProgress.accountLevel,
            playerFormation: playerFormation,
            enemyAccountLevel: enemyAccountLevel,
            enemyFormation: enemyFormation,
            fightResult: fightResult,
            matchingInfo: matchingInfo,
            pvpWinStreak: pvpWinStreak,
            battleId: battleId,
        });
        var fightReward = FightRewards.generateFightRewardForPlayer({
            playerProgress: playerProgress,
            battlePassProgress: battlePassProgress,
            matchingInfo: matchingInfo,
            battleId: battleId,
            fightRewardProgressionCounters: fightRewardProgressionCounters,
            seed: seed,
            fightResult: fightResult,
            rankRating: playerRankRating,
            startTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            adViewCounterInRanked: adViewCounterInRanked,
        });
        if (deltaRatingResult) {
            var startRatingsForSeasons = RatingSeasonsSettings.startRatingsForSeasons[teamMode];
            var deltaRating = deltaRatingResult.commonRankRating + deltaRatingResult.winStreakRankRating;
            var newPlayerRating = playerRankRating + deltaRating;
            var isPlayerInSeasonRating = newPlayerRating >= startRatingsForSeasons;
            var isFightResultCorrectToUpdateSeasonFightCount = SeasonUtils.isFightResultCorrectToUpdateSeasonFightCount(fightResult);
            if (isPlayerInSeasonRating && isFightResultCorrectToUpdateSeasonFightCount) {
                updatedFightCount++;
            }
            if (updatedFightCount >= RatingSeasonsSettings.numberOfMatchesForSeasonParticipation) {
                var rewardForRating = RankUtils.getRewardForRating({
                    playerProgress: playerProgress,
                    teamMode: teamMode,
                    newPlayerRating: newPlayerRating,
                    lastRatingForMilestoneReward: updatedLastRatingForMilestoneReward,
                });
                updatedLastRatingForMilestoneReward = rewardForRating.lastRatingForMilestoneReward;
                var reward = rewardForRating.reward;
                if (reward && !reward.isEmpty()) {
                    if (fightReward) {
                        fightReward.loot.combineLoot(reward);
                    }
                    else {
                        fightReward = {
                            loot: reward,
                            newSeed: seed,
                            fightRewardProgressionCounters: fightRewardProgressionCounters,
                        };
                    }
                }
            }
        }
        return {
            deltaRatingResult: deltaRatingResult,
            fightReward: fightReward,
            lastRatingForMilestoneReward: updatedLastRatingForMilestoneReward,
            fightCount: updatedFightCount,
        };
    };
    RatingUtils.getRatingSettingsByLevelPower = function (levelPower, teamMode) {
        var table = CalculationRatingSettings.deltaRatingSettings[teamMode];
        var delta = Infinity;
        var index = 0;
        for (var i = 0; i < table.length; i++) {
            var row = table[i];
            var item = row.items[0];
            var currentPower = item.accountLevel + item.maxHeroLevel;
            var currentDelta = levelPower - currentPower;
            if (currentDelta >= 0 && currentDelta < delta) {
                index = i;
                delta = currentDelta;
            }
        }
        return table[index];
    };
    return RatingUtils;
}());
