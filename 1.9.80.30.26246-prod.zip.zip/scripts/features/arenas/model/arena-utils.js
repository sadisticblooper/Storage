var ArenaUtils = (function () {
    function ArenaUtils() {
    }
    ArenaUtils.getArenaByRating = function (rating) {
        var arenaIntervals = ArenaUtils.getIntervalsForEveryArena();
        for (var arenaId in arenaIntervals) {
            if (rating >= arenaIntervals[arenaId].start
                && (!arenaIntervals[arenaId].end || rating <= arenaIntervals[arenaId].end)) {
                return arenasMap.checkedGet(arenaId);
            }
        }
        return undefined;
    };
    ArenaUtils.getArenaByNewRating = function (params) {
        var newRating = params.newRating, currentArenaId = params.currentArenaId;
        var arena = arenasMap.checkedGet(currentArenaId);
        var arenaInterval = ArenaUtils.getArenaInterval(currentArenaId);
        var canDemote = arena.CanDemote;
        var changeArena = newRating < arena.DemotionRating && canDemote || arenaInterval.end && newRating > arenaInterval.end;
        return changeArena ? ArenaUtils.getArenaByRating(newRating) : arena;
    };
    ArenaUtils.getIntervalsForEveryArena = function () {
        var result = {};
        var arenaWithRatings = [];
        for (var _i = 0, _a = arenasMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var arena = arenasMap.get(id);
            arenaWithRatings.push({
                rating: arena.Rating,
                arenaId: id
            });
        }
        arenaWithRatings
            .sort(function (a1, a2) { return a1.rating - a2.rating; });
        for (var i = 0; i < arenaWithRatings.length - 1; i++) {
            result[arenaWithRatings[i].arenaId] = {
                start: arenaWithRatings[i].rating,
                end: arenaWithRatings[i + 1].rating - 1,
            };
        }
        result[arenaWithRatings[arenaWithRatings.length - 1].arenaId] = {
            start: arenaWithRatings[arenaWithRatings.length - 1].rating,
            end: null,
        };
        return result;
    };
    ArenaUtils.getArenaInterval = function (arenaId) {
        var arenaIntervals = ArenaUtils.getIntervalsForEveryArena();
        if (!arenaIntervals[arenaId]) {
            throw new Error("getArenaInterval: no interval for arena ".concat(arenaId));
        }
        return arenaIntervals[arenaId];
    };
    ArenaUtils.getArenaOrCheckpointReward = function (settings, isCheckpoint) {
        RandomInstance.setSeed(settings.Seed);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.PlayerProgress);
        var MilestoneID = settings.MilestoneID, StartTimeOfCurrentDayMS = settings.StartTimeOfCurrentDayMS;
        var lootGenerator = LootGeneratorBuilder.getCommonLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(StartTimeOfCurrentDayMS);
        var reward = { chests: [], loot: new Loot(), lootSettings: null };
        var rewardResult = { Chests: [], Loot: new Loot(), NewSeed: 0 };
        if (isCheckpoint) {
            var checkpoint = checkpointsMap.get(MilestoneID);
            reward.lootSettings = checkpoint.getLootSettings();
            reward.chests = checkpoint.getChests(playerProgress);
            reward.loot = checkpoint.getLoot();
            reward.isHidden = !!(checkpoint.Reward && checkpoint.Reward.isHidden);
        }
        else {
            var arena = arenasMap.get(MilestoneID);
            if (!arena.SeasonEndReward) {
                reward.lootSettings = arena.getLootSettings();
                reward.chests = arena.getChests(playerProgress);
                reward.loot = arena.getLoot();
                reward.isHidden = !!(arena.Reward && arena.Reward.isHidden);
            }
        }
        if (reward.lootSettings || reward.loot || reward.chests) {
            rewardResult = lootGenerator.getRewardFromRewardContent(reward, RandomInstance);
        }
        return {
            Loot: rewardResult.Loot.isEmpty() ? null : rewardResult.Loot,
            Chests: rewardResult.Chests,
            NewSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
            IsHidden: rewardResult.IsHidden,
        };
    };
    ArenaUtils.getRemovedArenaOrCheckpointReward = function (settings) {
        var removedMilestone = null;
        var isCheckpoint = settings.isCheckpoint;
        var id = settings.MilestoneID;
        for (var _i = 0, removedMilestones_AB_enable_fight_chest_1 = removedMilestones_AB_enable_fight_chest; _i < removedMilestones_AB_enable_fight_chest_1.length; _i++) {
            var milestone = removedMilestones_AB_enable_fight_chest_1[_i];
            if (milestone.id == id && milestone.isCheckpoint == isCheckpoint) {
                removedMilestone = milestone;
                break;
            }
        }
        if (!removedMilestone) {
            try {
                var reward = getArenaOrCheckpointReward(settings);
                var arenaId = 0;
                if (!isCheckpoint) {
                    arenaId = settings.MilestoneID;
                }
                else {
                    var checkpoint = checkpointsMap.checkedGet(id);
                    var arena = this.getArenaByRating(checkpoint.Rating);
                    arenaId = arena.ID;
                }
                return {
                    reward: reward,
                    chestArena: arenaId,
                };
            }
            catch (e) {
                throw new Error("getRemovedArenaOrCheckpointReward: \n                \rno settings for ".concat(id, " checkpoint '").concat(isCheckpoint, "'. ").concat(e.toString()));
            }
        }
        RandomInstance.setSeed(settings.Seed);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.PlayerProgress);
        var lootGenerator = LootGeneratorBuilder.getCommonLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(settings.StartTimeOfCurrentDayMS);
        var rewardResult = lootGenerator
            .getRewardFromRewardContent(removedMilestone.reward, RandomInstance);
        return {
            reward: rewardResult,
            chestArena: removedMilestone.chestArena,
        };
    };
    ArenaUtils.getAllArenaRewards = function (settings) {
        var result = {};
        var startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, playerProgress = settings.playerProgress;
        for (var _i = 0, _a = checkpointsMap.getKeys(); _i < _a.length; _i++) {
            var id = _a[_i];
            var item = checkpointsMap.get(id);
            var reward = this.getArenaOrCheckpointReward({
                isCheckpoint: true,
                MilestoneID: id,
                PlayerProgress: playerProgress,
                Seed: 1,
                StartTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            }, true);
            if ((!reward.Loot || reward.Loot.isEmpty()) && (!reward.Chests || reward.Chests.length == 0)) {
                reward = null;
            }
            result[item.Rating] = reward;
        }
        for (var _b = 0, _c = arenasMap.getKeys(); _b < _c.length; _b++) {
            var id = _c[_b];
            var item = arenasMap.get(id);
            var reward = this.getArenaOrCheckpointReward({
                isCheckpoint: false,
                MilestoneID: id,
                PlayerProgress: playerProgress,
                Seed: 1,
                StartTimeOfCurrentDayMS: startTimeOfCurrentDayMS,
            }, false);
            if ((!reward.Loot || reward.Loot.isEmpty()) && (!reward.Chests || reward.Chests.length == 0)) {
                reward = null;
            }
            result[item.Rating] = reward;
        }
        return result;
    };
    return ArenaUtils;
}());
