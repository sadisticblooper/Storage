function calcDeltaRating(settings) {
    return RatingUtils.calcDeltaRating(settings);
}
function getArenaOrCheckpointReward(settings) {
    return ArenaUtils.getArenaOrCheckpointReward(settings, settings.isCheckpoint);
}
function getRemovedArenaOrCheckpointReward(settings) {
    return ArenaUtils.getRemovedArenaOrCheckpointReward(settings);
}
function getArenaIdByNewRating(a) {
    return ArenaUtils.getArenaByNewRating(a).ID;
}
function getArenaInterval(arenaId) {
    return ArenaUtils.getArenaInterval(arenaId);
}
function getAllArenaRewards(settings) {
    return ArenaUtils.getAllArenaRewards(settings);
}
function getFightResult(settings) {
    return RatingUtils.getFightResult(settings);
}
