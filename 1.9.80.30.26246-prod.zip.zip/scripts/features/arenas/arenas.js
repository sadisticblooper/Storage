var _a;
var arenas = {
    Arena1: new Arena({
        ID: 1,
        ArenaNumber: 1,
        HeroLevelAvg: 1,
        AccountLevelAvg: 1,
        Rating: 0,
        DemotionRating: 0,
        NameInf: { Alias: "roadmap_tab_arena", Postfix: "", Name: "Tutorial Bamboo" },
        LeaderboardBgColor: "#735A35",
        Icon: "Arena1",
        DotIcon: "",
        BackGround: "location_bamboo",
        NotShowBackground: true,
        CanDemote: false,
        RatingDecSpeed: 0,
        RatingIncSpeed: 1,
        DisableBotPenalty: true,
        Reward: {}
    }),
    Arena2: new Arena({
        ID: 2,
        ArenaNumber: 2,
        AccountLevelAvg: 1.8,
        HeroLevelAvg: 1.8,
        Rating: 10,
        DemotionRating: 9,
        NameInf: { Alias: "arena", Postfix: "I", Name: "Castle" },
        LeaderboardBgColor: "#687373",
        Icon: "Arena2",
        DotIcon: "Milestone2",
        BackGround: "location_legion_castle",
        CanDemote: true,
        RatingDecSpeed: 0.2,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Shards_chest_arena_tutorial.ID]
        }
    }),
    Arena3: new Arena({
        ID: 3,
        ArenaNumber: 3,
        AccountLevelAvg: 3.5,
        HeroLevelAvg: 3.5,
        Rating: 100,
        DemotionRating: 50,
        NameInf: { Alias: "arena", Postfix: "II", Name: "Cinematic Arena" },
        LeaderboardBgColor: "#735135",
        Icon: "Arena3",
        DotIcon: "Milestone3",
        BackGround: "location_cinematic_arena",
        CanDemote: true,
        RatingDecSpeed: 0.4,
        RatingIncSpeed: 1,
        Reward: {
            isHidden: true, lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_a = {}, _a[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Weight: 1, Amount: 5 },] }, _a) }, }
        }
    }),
    Arena4: new Arena({
        ID: 4,
        ArenaNumber: 4,
        AccountLevelAvg: 4,
        HeroLevelAvg: 4,
        Rating: 600,
        DemotionRating: 400,
        NameInf: { Alias: "arena", Postfix: "III", Name: "Destroyed Village" },
        LeaderboardBgColor: "#5E6673",
        Icon: "Arena4",
        DotIcon: "Milestone4",
        BackGround: "location_destroyed_village",
        CanDemote: true,
        RatingDecSpeed: 0.6,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Shards_chest_Sarge.ID]
        },
        ChestIfHeroExists: {
            heroId: HeroNames.Sarge.ID,
            chestId: chests.Shards_chest_Sarge_alias_v2.ID
        },
    }),
    Arena5: new Arena({
        ID: 5,
        ArenaNumber: 5,
        AccountLevelAvg: 5,
        HeroLevelAvg: 5,
        Rating: 1400,
        DemotionRating: 1200,
        NameInf: { Alias: "arena", Postfix: "IV", Name: "Marcus Village" },
        LeaderboardBgColor: "#73612A",
        Icon: "Arena5",
        DotIcon: "Milestone5",
        BackGround: "location_marcus_village",
        CanDemote: true,
        RatingDecSpeed: 0.8,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Shards_chest_Feldsher.ID]
        },
        ChestIfHeroExists: {
            heroId: HeroNames.Feldsher.ID,
            chestId: chests.Shards_chest_Feldsher_alias_v2.ID
        },
    }),
    Arena6: new Arena({
        ID: 6,
        ArenaNumber: 6,
        AccountLevelAvg: 6,
        HeroLevelAvg: 6,
        Rating: 3000,
        DemotionRating: 2800,
        NameInf: { Alias: "arena", Postfix: "V", Name: "Void Room" },
        LeaderboardBgColor: "#2A7347",
        Icon: "Arena6",
        DotIcon: "Milestone6",
        BackGround: "location_void_room",
        CanDemote: true,
        RatingDecSpeed: 1,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Shards_chest_Yukka.ID]
        },
        ChestIfHeroExists: {
            heroId: HeroNames.Yukka.ID,
            chestId: chests.Shards_chest_Yukka_alias_v2.ID
        },
    }),
    Arena7: new Arena({
        ID: 7,
        ArenaNumber: 7,
        AccountLevelAvg: 7,
        HeroLevelAvg: 7,
        Rating: 6200,
        DemotionRating: 6000,
        NameInf: { Alias: "arena", Postfix: "VI", Name: "Heralds Street" },
        LeaderboardBgColor: "#543573",
        Icon: "Arena7",
        DotIcon: "Milestone7",
        BackGround: "location_heralds_street",
        CanDemote: true,
        RatingDecSpeed: 1,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Shards_chest_Emperor.ID]
        },
        ChestIfHeroExists: {
            heroId: HeroNames.Emperor.ID,
            chestId: chests.Shards_chest_Emperor_alias_v2.ID
        },
    }),
    Arena8: new Arena({
        ID: 8,
        ArenaNumber: 8,
        AccountLevelAvg: 8,
        HeroLevelAvg: 8,
        Rating: 8600,
        DemotionRating: 10800,
        NameInf: { Alias: "arena", Postfix: "VII", Name: "Crypt" },
        LeaderboardBgColor: "#732A30",
        Icon: "Arena8",
        DotIcon: "Milestone8",
        BackGround: "location_crypt",
        CanDemote: true,
        RatingDecSpeed: 1,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Mythic_chest.ID]
        }
    }),
    Arena9: new Arena({
        ID: 9,
        ArenaNumber: 9,
        AccountLevelAvg: 9,
        HeroLevelAvg: 9,
        Rating: 11000,
        DemotionRating: 17800,
        NameInf: { Alias: "arena", Postfix: "VIII", Name: "Wastelands" },
        LeaderboardBgColor: "#734016",
        Icon: "Arena9",
        DotIcon: "Milestone9",
        BackGround: "location_wastelands",
        CanDemote: true,
        RatingDecSpeed: 1,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Mythic_chest.ID]
        }
    }),
    Arena10: new Arena({
        ID: 10,
        ArenaNumber: 10,
        AccountLevelAvg: 10,
        HeroLevelAvg: 10,
        Rating: 13000,
        DemotionRating: 25800,
        NameInf: { Alias: "arena", Postfix: "IX", Name: "Thunder" },
        LeaderboardBgColor: "#357373",
        Icon: "Arena10",
        DotIcon: "Milestone10",
        BackGround: "location_thunder",
        CanDemote: true,
        RatingDecSpeed: 1,
        RatingIncSpeed: 1,
        Reward: {
            chests: [chests.Mythic_chest.ID]
        }
    }),
};
var arenasMap = createIDMap(arenas, "arenasMap");
