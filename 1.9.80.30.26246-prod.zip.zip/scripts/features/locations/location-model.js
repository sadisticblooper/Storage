var LocationModel = (function () {
    function LocationModel() {
    }
    LocationModel.updateLocationHistory = function (arg) {
        var playedRounds = arg.playedRounds, lastLocationId = arg.lastLocationId;
        var history = getArrayFromRaw(arg.locationHistory);
        if (playedRounds > 0) {
            history.push(lastLocationId);
        }
        if (history.length > LocationConstants.lengthOfHistory) {
            history = history.slice(history.length - LocationConstants.lengthOfHistory);
        }
        return {
            locationHistory: history,
        };
    };
    LocationModel.getWeightForLocationsByHistory = function (history) {
        var result = {};
        var activePool = LocationConstants.locationsPool;
        for (var locationId in activePool) {
            var settings = activePool[locationId];
            if (settings.stepProbability.length == 0) {
                continue;
            }
            var maxStep = settings.stepProbability.length - 1;
            var initStep = settings.initStep ? settings.initStep : 0;
            var currentStep = Math.min(maxStep, Math.max(0, initStep));
            for (var _i = 0, history_1 = history; _i < history_1.length; _i++) {
                var idInHistory = history_1[_i];
                if (idInHistory == +locationId) {
                    currentStep = Math.min(maxStep, currentStep + 1);
                }
                else {
                    currentStep = Math.max(0, currentStep - 1);
                }
            }
            result[locationId] = settings.stepProbability[currentStep];
        }
        return result;
    };
    LocationModel.getLobbyLocationId = function (arg) {
        var lobbyLocation = arg.isPremiumUnlocked ? LOBBY_LOCATION.BATTLEPASS : LOBBY_LOCATION.DEFAULT;
        return lobbyLocation;
    };
    return LocationModel;
}());
