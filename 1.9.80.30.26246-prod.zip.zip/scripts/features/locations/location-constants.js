var _a;
var LocationConstants = (function () {
    function LocationConstants() {
    }
    LocationConstants.lengthOfHistory = 10;
    LocationConstants.locationsPool = (_a = {},
        _a[locations.bamboo_arena.ID] = { stepProbability: [0.2, 0.15, 0.1, 0], },
        _a[locations.thunder.ID] = { stepProbability: [0.2, 0.15, 0.1, 0], },
        _a[locations.eldorado.ID] = { stepProbability: [0.2, 0.15, 0.1, 0], },
        _a[locations.viper_backstreet.ID] = { stepProbability: [0.2, 0.15, 0.1, 0], },
        _a[locations.castle.ID] = { stepProbability: [0.4, 0.3, 0.15, 0], },
        _a[locations.pve_5_1.ID] = { stepProbability: [0.4, 0.3, 0.15, 0], },
        _a);
    return LocationConstants;
}());
