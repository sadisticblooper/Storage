function getLocationById(id) {
    return locationsMap.checkedGet(id);
}
function getBattleData(arg) {
    return BattleUtils.getBattleData(arg);
}
function updateLocations(arg) {
    return LocationModel.updateLocationHistory(arg);
}
function getLobbyLocationId(arg) {
    return LocationModel.getLobbyLocationId(arg);
}
