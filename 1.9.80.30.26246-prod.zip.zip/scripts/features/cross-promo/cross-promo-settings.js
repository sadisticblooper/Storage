var CrossPromoSettings = (function () {
    function CrossPromoSettings() {
    }
    CrossPromoSettings.getRewardForLinkInstall = function (settings) {
        var crossPromo = settings.crossPromo, eventId = settings.eventId, seed = settings.seed;
        var result = {};
        var rewardSettings = CrossPromoSettings.rewardsForPromo[crossPromo];
        if (!rewardSettings || !rewardSettings.eventCurrency && !rewardSettings.reward) {
            return result;
        }
        var resultReward = {
            Loot: new Loot(),
            Chests: [],
            NewSeed: seed,
        };
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var lootGenerator = LootGeneratorBuilder.getPromoCodesLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        if (rewardSettings.reward) {
            var rnd = new PcgRandom(seed);
            var rewardResult = lootGenerator.getRewardFromRewardContent(rewardSettings.reward, rnd);
            if (rewardResult.Loot && !rewardResult.Loot.isEmpty()) {
                resultReward.Loot.combineLoot(rewardResult.Loot);
            }
            if (rewardResult.Chests && rewardResult.Chests.length) {
                resultReward.Chests = resultReward.Chests.concat(rewardResult.Chests);
            }
            resultReward.NewSeed = rnd.nextInt(rnd.MAX_INTEGER());
        }
        if (rewardSettings.eventCurrency) {
            var event_1 = seasonalEventsMap.get(rewardSettings.eventCurrency.eventId);
            if (!event_1 || event_1.ID != eventId) {
                return result;
            }
            var currencyReward = {};
            for (var eventCurrency in rewardSettings.eventCurrency.currency) {
                var cur = event_1.eventCurrenciesToCurrencies[eventCurrency];
                if (cur) {
                    currencyReward[cur] = rewardSettings.eventCurrency.currency[eventCurrency];
                }
            }
            resultReward.Loot.combineLoot(new Loot({ Currencies: currencyReward }));
        }
        if (!resultReward.Loot.isEmpty() || resultReward.Chests.length > 0) {
            result.reward = resultReward;
        }
        return result;
    };
    CrossPromoSettings.rewardsForPromo = {};
    return CrossPromoSettings;
}());
