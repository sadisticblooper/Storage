var crossPromoPopupVisualConfigs = CommonPopUpUtils.setActivityPopupsOverMap(activityPopupsMap, [
    {
        data: {
            "ID": 6001,
            "priority": 6,
            "navigation": POPUP_NAVIGATION.URL,
            "navigationArg": 0,
            "navigationLinkURL": "https://sf3.onelink.me/S2uR/VerRelease",
            "activeTime": CommonUtils.getStartEndByDays(new Date("2023-12-14").getTime(), [1, 2, 3, 4, 5]),
            "endDate": new Date("2023-12-19").getTime(),
        },
        visual: {
            "displayedCurrencies": null,
            "iconId": 21,
            "rulesDescription": {
                "alias": "crosspromo_benefit_desc_3_02",
                "color": "#5eb7ff"
            },
            "rulesHeader": {
                "alias": "popup_title_crosspromo_02",
                "color": "#FFFFFF"
            },
            "header": {
                "alias": "popup_title_crosspromo_02",
                "color": "#5eb7ff"
            },
            "subHeader": null,
            "timer": null,
            "button": {
                "alias": "button_proceed",
                "frameColor": "#75FF83",
                "glow1Color": "#D7FFCE",
                "glow2Color": "#D7FFCE",
                "effect1Color": "#75FF83",
                "effect2Color": "#75FF83",
                "effect3Color": "#75FF83",
                "effect4Color": "#75FF83",
                "corner1Color": "#75FF83",
                "corner2Color": "#75FF83"
            },
            "preview": {
                "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_crossPromo_art_4",
                "color": "#ffffff"
            },
            "background": {
                "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_crossPromo_bg_3",
                "color": "#ffffff"
            },
            "backgroundEffect": {
                "sprite": "",
                "color": "#4788c4"
            },
            "particles": {
                "maxColor": "#4788c4",
                "minColor": "#4788c4"
            },
            "gradientLeft": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#3f688a"
                    },
                    {
                        "time": 0.98,
                        "color": "#3f688a"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 0
                    },
                    {
                        "time": 1,
                        "alpha": 0
                    }
                ]
            },
            "gradientRight": {
                "mode": 0,
                "colorKeys": [
                    {
                        "time": 0,
                        "color": "#53058a"
                    },
                    {
                        "time": 0.99,
                        "color": "#14379d"
                    }
                ],
                "alphaKeys": [
                    {
                        "time": 0,
                        "alpha": 1
                    },
                    {
                        "time": 1,
                        "alpha": 1
                    }
                ]
            },
            "descriptionItems": [
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "popup_rules_crosspromo_02",
                    "color": "#6aaee5"
                },
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "crosspromo_benefit_desc_1_02",
                    "color": "#6aaee5"
                },
                {
                    "icon": "Sprites/Assets/Layouts/decor_rhombus_small",
                    "alias": "crosspromo_benefit_desc_2_02",
                    "color": "#6aaee5"
                },
            ],
            "pattern": {
                "sprite": "Sprites/PreviewImages/Advertising/AdvertisingSF3/SF3_crossPromo_pattern",
                "color": "#2D4AA1B8"
            }
        },
    },
]);
