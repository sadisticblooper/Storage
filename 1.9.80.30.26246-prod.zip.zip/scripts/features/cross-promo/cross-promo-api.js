function getRewardForLinkInstall(settings) {
    return CrossPromoSettings.getRewardForLinkInstall(settings);
}
