function getBattlePassIdByTime(serverTime) {
    var bp = BattlePass.getBattlePassByTime(serverTime);
    return bp ? bp.ID : null;
}
function isBattlePassAvailable(progress) {
    return BattlePass.isBattlePassAvailable(progress);
}
function getLevelsUpPrice(settings) {
    return BattlePass.getLevelsUpPrice(settings);
}
function getBattlePassCombinedRewards(settings) {
    return BattlePass.getBattlePassCombinedRewards(settings);
}
function getBattlePassRewardsPerLevels(settings) {
    return BattlePass.getBattlePassRewardsPerLevels(settings);
}
function getBattlePassRewards(settings) {
    return BattlePass.getBattlePassRewards(settings);
}
function getBattlePassSettings(settings) {
    return BattlePass.getBattlePassSettings(settings);
}
function getBattlePassVisualSettings(battlePassId) {
    return BattlePassUtils.getBattlePassVisualSettings(battlePassId);
}
function updateCurrentBattlePassLevelState(settings) {
    return BattlePass.updateCurrentBattlePassLevelState(settings);
}
function isBattlePassComplete(settings) {
    return BattlePass.isBattlePassComplete(settings);
}
function hasBattlePassRewardsAtLevel(settings) {
    return BattlePass.hasBattlePassRewardsAtLevel(settings);
}
function sortBattlePassRewards(settings) {
    return BattlePass.sortBattlePassRewards(settings);
}
function updateCustomBattlePassRewardsOffset(settings) {
    return BattlePass.updateCustomBattlePassRewardsOffset(settings);
}
function getValuableRewards(settings) {
    return BattlePass.getValuableRewards(settings);
}
function isBattlePassOfferVisualChangeNeeded(settings) {
    return settings.battlePassLevel >= 70;
}
