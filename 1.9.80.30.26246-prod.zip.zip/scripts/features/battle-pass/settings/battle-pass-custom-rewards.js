var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
var BattlePassCustomRewards = (function () {
    function BattlePassCustomRewards() {
    }
    BattlePassCustomRewards.customRewards = [
        [{ chests: [chests.Shards_chest_battlePass_tutorial.ID] }],
        [{ loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 500, _a) }) }],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 5, TotalSlots: 1, Rarities: (_b = {}, _b[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 5, Weight: 1 }] }, _b) } } }],
        [{ loot: new Loot({ Currencies: (_c = {}, _c[CURRENCY.BONUS] = 25, _c) }) }],
        [{ loot: new Loot({ Emoji: [emoji.Feldsher_Greeting.ID] }) },],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_d = {}, _d[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _d) } } }],
        [{ chests: [chests.Common_chest.ID] }],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 15, TotalSlots: 1, Rarities: (_e = {}, _e[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 15, Weight: 1 }] }, _e) } } }],
        [{ loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.COIN] = 300, _f) }) }],
        [{ loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.BONUS] = 40, _g) }) }],
        [{ chests: [chests.Common_chest.ID] }],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_h = {}, _h[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _h) } } }],
        [{ chests: [chests.Common_chest.ID] }],
        [{ loot: new Loot({ Currencies: (_j = {}, _j[CURRENCY.COIN] = 300, _j) }) }],
        [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        [{ chests: [chests.Rare_chest.ID] }],
        [{ loot: new Loot({ Currencies: (_k = {}, _k[CURRENCY.BONUS] = 60, _k) }) }],
        [{ chests: [chests.Common_chest.ID] }],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _l) } } }],
        [{ loot: new Loot({ Currencies: (_m = {}, _m[CURRENCY.GACHA_KEY] = 1, _m) }) }],
        [{ chests: [chests.Rare_chest.ID] }],
        [{ loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 300, _o) }) }],
        [{ chests: [chests.Common_chest.ID] }],
        [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_p = {}, _p[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _p) } } }],
        [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    ];
    return BattlePassCustomRewards;
}());
