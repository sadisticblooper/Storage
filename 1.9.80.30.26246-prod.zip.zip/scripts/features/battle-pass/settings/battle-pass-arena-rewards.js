var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87, _88, _89, _90, _91, _92, _93, _94, _95, _96, _97, _98, _99, _100, _101, _102, _103, _104, _105, _106, _107, _108, _109, _110, _111, _112, _113, _114, _115, _116, _117, _118, _119, _120, _121, _122, _123, _124, _125, _126, _127, _128, _129, _130, _131, _132, _133, _134, _135, _136, _137, _138, _139, _140, _141, _142, _143, _144, _145, _146, _147, _148, _149, _150, _151;
var BattlePassArenaRewardsUtils = (function () {
    function BattlePassArenaRewardsUtils() {
    }
    BattlePassArenaRewardsUtils.rewardsReplacerByType = function (src, replace) {
        var result = {
            Arenas: src.Arenas
        };
        for (var level in src)
            if (isNumber(level)) {
                var c = replace.c && replace.c[level] !== undefined ? replace.c[level] : src[level].c;
                var s = replace.s && replace.s[level] !== undefined ? replace.s[level] : src[level].s;
                result[level] = {
                    c: c,
                    s: s
                };
            }
        return result;
    };
    return BattlePassArenaRewardsUtils;
}());
var BattlePassArenaRewards = {};
BattlePassArenaRewards.template_without_legendary_weapon = {
    Arenas: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    1: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    2: {
        c: [{ loot: new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 500, _a) }) }],
        s: [{ loot: new Loot({ Currencies: (_b = {}, _b[CURRENCY.COIN] = 5000, _b) }) }]
    },
    3: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_c = {}, _c[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _c) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_d = {}, _d[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _d) } } }],
    },
    4: {
        c: [{ loot: new Loot({ Currencies: (_e = {}, _e[CURRENCY.BONUS] = 50, _e) }) }],
        s: [{ loot: new Loot({ Currencies: (_f = {}, _f[CURRENCY.BONUS] = 300, _f) }) }]
    },
    5: {
        c: [
            { loot: new Loot({ Emoji: [emoji.Liquidator_Salute.ID] }) },
            { loot: new Loot({ Currencies: (_g = {}, _g[CURRENCY.COIN] = 700, _g) }) }
        ],
        s: [
            { loot: new Loot({ Emoji: [emoji.Emperor_Anger.ID] }) },
            { loot: new Loot({ Currencies: (_h = {}, _h[CURRENCY.BONUS] = 50, _h) }) },
        ]
    },
    6: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_j = {}, _j[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _j) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_k = {}, _k[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _k) } } }],
    },
    7: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    8: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_l = {}, _l[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _l) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_m = {}, _m[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _m) } } }],
    },
    9: {
        c: [{ loot: new Loot({ Currencies: (_o = {}, _o[CURRENCY.COIN] = 250, _o) }) }],
        s: [{ loot: new Loot({ Currencies: (_p = {}, _p[CURRENCY.COIN] = 1000, _p) }) }]
    },
    10: {
        c: [
            { loot: new Loot({ Stances: [stances.stance_Monk_R_stand_one_leg.ID] }) },
            { loot: new Loot({ Stances: [stances.stance_Ling_R_drink.ID] }) },
            { loot: new Loot({ Stances: [stances.stance_Liquidator_R_right_sword_twist.ID] }) },
            { loot: new Loot({ Currencies: (_q = {}, _q[CURRENCY.COIN] = 1000, _q) }) }
        ],
        s: [
            { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_no.ID] }) },
            { loot: new Loot({ Currencies: (_r = {}, _r[CURRENCY.BONUS] = 200, _r) }) }
        ]
    },
    11: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    12: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_s = {}, _s[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _s) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_t = {}, _t[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _t) } } }],
    },
    13: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    14: {
        c: [{ loot: new Loot({ Currencies: (_u = {}, _u[CURRENCY.COIN] = 250, _u) }) }],
        s: [{ loot: new Loot({ Currencies: (_v = {}, _v[CURRENCY.COIN] = 1000, _v) }) }]
    },
    15: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    16: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    17: {
        c: [{ loot: new Loot({ Currencies: (_w = {}, _w[CURRENCY.COIN] = 250, _w) }) }],
        s: [{ loot: new Loot({ Currencies: (_x = {}, _x[CURRENCY.COIN] = 1000, _x) }) }]
    },
    18: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    19: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_y = {}, _y[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _y) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_z = {}, _z[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _z) } } }],
    },
    20: {
        c: [{ loot: new Loot({ Currencies: (_0 = {}, _0[CURRENCY.GACHA_KEY] = 1, _0) }) }],
        s: [{ loot: new Loot({ Currencies: (_1 = {}, _1[CURRENCY.GACHA_KEY] = 2, _1) }) }]
    },
    21: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    22: {
        c: [{ loot: new Loot({ Currencies: (_2 = {}, _2[CURRENCY.COIN] = 250, _2) }) }],
        s: [{ loot: new Loot({ Currencies: (_3 = {}, _3[CURRENCY.COIN] = 1000, _3) }) }]
    },
    23: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    24: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_4 = {}, _4[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _4) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_5 = {}, _5[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _5) } } }],
    },
    25: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_New_Hero.ID] }]
    },
    26: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    27: {
        c: [{ loot: new Loot({ Currencies: (_6 = {}, _6[CURRENCY.COIN] = 250, _6) }) }],
        s: [{ loot: new Loot({ Currencies: (_7 = {}, _7[CURRENCY.COIN] = 1000, _7) }) }]
    },
    28: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    29: {
        c: [{ loot: new Loot({ Currencies: (_8 = {}, _8[CURRENCY.COIN] = 250, _8) }) }],
        s: [{ loot: new Loot({ Currencies: (_9 = {}, _9[CURRENCY.COIN] = 1000, _9) }) }]
    },
    30: {
        c: [
            { loot: new Loot({ Stances: [stances.win_Ironclad_R_hell_yeah.ID] }) },
            { loot: new Loot({ Stances: [stances.win_Monk_R_stand_straight.ID] }) },
            { loot: new Loot({ Stances: [stances.win_Kibo_R_swing_hide.ID] }) },
            { loot: new Loot({ Currencies: (_10 = {}, _10[CURRENCY.COIN] = 1000, _10) }) }
        ],
        s: [
            { loot: new Loot({ Stances: [stances.win_HongJoo_R_autograph.ID] }) },
            { loot: new Loot({ Currencies: (_11 = {}, _11[CURRENCY.BONUS] = 200, _11) }) }
        ]
    },
    31: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_12 = {}, _12[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _12) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_13 = {}, _13[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _13) } } }],
    },
    32: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    33: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    34: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_14 = {}, _14[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _14) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_15 = {}, _15[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _15) } } }],
    },
    35: {
        c: [{ loot: new Loot({ Currencies: (_16 = {}, _16[CURRENCY.COIN] = 700, _16) }) }],
        s: [
            { loot: new Loot({ Emoji: [emoji.Legion_King_ThumbsDown.ID] }) },
            { loot: new Loot({ Currencies: (_17 = {}, _17[CURRENCY.BONUS] = 50, _17) }) },
        ]
    },
    36: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    37: {
        c: [{ loot: new Loot({ Currencies: (_18 = {}, _18[CURRENCY.BONUS] = 25, _18) }) }],
        s: [{ loot: new Loot({ Currencies: (_19 = {}, _19[CURRENCY.BONUS] = 150, _19) }) }]
    },
    38: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_20 = {}, _20[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _20) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_21 = {}, _21[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _21) } } }],
    },
    39: {
        c: [{ loot: new Loot({ Currencies: (_22 = {}, _22[CURRENCY.COIN] = 250, _22) }) }],
        s: [{ loot: new Loot({ Currencies: (_23 = {}, _23[CURRENCY.COIN] = 1000, _23) }) }]
    },
    40: {
        c: [{ loot: new Loot({ Currencies: (_24 = {}, _24[CURRENCY.GACHA_KEY] = 1, _24) }) }],
        s: [{ loot: new Loot({ Currencies: (_25 = {}, _25[CURRENCY.GACHA_KEY] = 2, _25) }) }]
    },
    41: {
        c: [{ loot: new Loot({ Currencies: (_26 = {}, _26[CURRENCY.COIN] = 250, _26) }) }],
        s: [{ loot: new Loot({ Currencies: (_27 = {}, _27[CURRENCY.COIN] = 1000, _27) }) }]
    },
    42: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    43: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    44: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }],
    },
    45: {
        c: [{ chests: [chests.Large_Shard_Chest_New_Hero.ID] }],
        s: [{ chests: [chests.Weapon_chest.ID] }]
    },
    46: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_28 = {}, _28[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _28) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_29 = {}, _29[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _29) } } }],
    },
    47: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    48: {
        c: [{ loot: new Loot({ Currencies: (_30 = {}, _30[CURRENCY.COIN] = 250, _30) }) }],
        s: [{ loot: new Loot({ Currencies: (_31 = {}, _31[CURRENCY.COIN] = 1000, _31) }) }]
    },
    49: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_32 = {}, _32[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _32) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_33 = {}, _33[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _33) } } }],
    },
    50: {
        c: [
            { loot: new Loot({ Skins: [skins.Fireguard_R_Red_skin.ID] }) },
            { loot: new Loot({ Skins: [skins.Liquidator_R_Purple.ID] }) },
            { loot: new Loot({ Skins: [skins.Monk_R_Blue.ID] }) },
            { loot: new Loot({ Currencies: (_34 = {}, _34[CURRENCY.COIN] = 2000, _34) }) }
        ],
        s: [
            { loot: new Loot({ Stances: [stances.stance_Monkeyking_E_toothpick.ID] }) },
            { loot: new Loot({ Currencies: (_35 = {}, _35[CURRENCY.BONUS] = 200, _35) }) }
        ]
    },
    51: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    52: {
        c: [{ loot: new Loot({ Currencies: (_36 = {}, _36[CURRENCY.COIN] = 500, _36) }) }],
        s: [{ loot: new Loot({ Currencies: (_37 = {}, _37[CURRENCY.COIN] = 5000, _37) }) }]
    },
    53: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    54: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_38 = {}, _38[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _38) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_39 = {}, _39[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _39) } } }],
    },
    55: {
        c: [{ chests: [chests.Weapon_chest.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    56: {
        c: [{ loot: new Loot({ Currencies: (_40 = {}, _40[CURRENCY.BONUS] = 25, _40) }) }],
        s: [{ loot: new Loot({ Currencies: (_41 = {}, _41[CURRENCY.BONUS] = 150, _41) }) }]
    },
    57: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    58: {
        c: [{ loot: new Loot({ Currencies: (_42 = {}, _42[CURRENCY.COIN] = 250, _42) }) }],
        s: [{ loot: new Loot({ Currencies: (_43 = {}, _43[CURRENCY.COIN] = 1000, _43) }) }]
    },
    59: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_44 = {}, _44[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _44) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_45 = {}, _45[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _45) } } }],
    },
    60: {
        c: [{ loot: new Loot({ Currencies: (_46 = {}, _46[CURRENCY.GACHA_KEY] = 1, _46) }) }],
        s: [{ loot: new Loot({ Currencies: (_47 = {}, _47[CURRENCY.GACHA_KEY] = 2, _47) }) }]
    },
    61: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    62: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_48 = {}, _48[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _48) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_49 = {}, _49[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _49) } } }],
    },
    63: {
        c: [{ loot: new Loot({ Currencies: (_50 = {}, _50[CURRENCY.COIN] = 250, _50) }) }],
        s: [{ loot: new Loot({ Currencies: (_51 = {}, _51[CURRENCY.COIN] = 1000, _51) }) }]
    },
    64: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    65: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    66: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    67: {
        c: [{ loot: new Loot({ Currencies: (_52 = {}, _52[CURRENCY.COIN] = 250, _52) }) }],
        s: [{ loot: new Loot({ Currencies: (_53 = {}, _53[CURRENCY.COIN] = 1000, _53) }) }]
    },
    68: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_54 = {}, _54[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _54) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_55 = {}, _55[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _55) } } }],
    },
    69: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    70: {
        c: [{ chests: [chests.Legendary_chest.ID] }],
        s: [
            { loot: new Loot({ Skins: [skins.Viper_E_Grafitti.ID] }) },
            { loot: new Loot({ Currencies: (_56 = {}, _56[CURRENCY.GACHA_KEY] = 2, _56) }) }
        ]
    },
};
BattlePassArenaRewards.template_with_legendary_weapon = {
    Arenas: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    1: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Butcher_legendary_weapon_chest.ID] }]
    },
    2: {
        c: [{ loot: new Loot({ Currencies: (_57 = {}, _57[CURRENCY.COIN] = 500, _57) }) }],
        s: [{ loot: new Loot({ Currencies: (_58 = {}, _58[CURRENCY.COIN] = 5000, _58) }) }]
    },
    3: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_59 = {}, _59[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _59) } } }],
        s: [{ chests: [chests.Rare_chest.ID] }],
    },
    4: {
        c: [{ loot: new Loot({ Currencies: (_60 = {}, _60[CURRENCY.BONUS] = 50, _60) }) }],
        s: [{ loot: new Loot({ Currencies: (_61 = {}, _61[CURRENCY.BONUS] = 300, _61) }) }]
    },
    5: {
        c: [
            { loot: new Loot({ Emoji: [emoji.Liquidator_Salute.ID] }) },
            { loot: new Loot({ Currencies: (_62 = {}, _62[CURRENCY.COIN] = 700, _62) }) }
        ],
        s: [
            { loot: new Loot({ Emoji: [emoji.Emperor_Anger.ID] }) },
            { loot: new Loot({ Currencies: (_63 = {}, _63[CURRENCY.BONUS] = 50, _63) }) },
        ]
    },
    6: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_64 = {}, _64[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _64) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_65 = {}, _65[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _65) } } }],
    },
    7: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    8: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_66 = {}, _66[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _66) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_67 = {}, _67[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _67) } } }],
    },
    9: {
        c: [{ loot: new Loot({ Currencies: (_68 = {}, _68[CURRENCY.COIN] = 250, _68) }) }],
        s: [{ loot: new Loot({ Currencies: (_69 = {}, _69[CURRENCY.COIN] = 1000, _69) }) }]
    },
    10: {
        c: [
            { chests: [chests.Butcher_legendary_weapon_chest.ID] }
        ],
        s: [
            { loot: new Loot({ Taunts: [taunts.taunt_Universal_R_no.ID] }) },
            { loot: new Loot({ Currencies: (_70 = {}, _70[CURRENCY.BONUS] = 200, _70) }) }
        ],
    },
    11: {
        c: [
            { loot: new Loot({ Stances: [stances.stance_Monk_R_stand_one_leg.ID] }) },
            { loot: new Loot({ Stances: [stances.stance_Ling_R_drink.ID] }) },
            { loot: new Loot({ Stances: [stances.stance_Liquidator_R_right_sword_twist.ID] }) },
            { loot: new Loot({ Currencies: (_71 = {}, _71[CURRENCY.COIN] = 1000, _71) }) }
        ],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    12: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_72 = {}, _72[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _72) } } }],
    },
    13: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_73 = {}, _73[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _73) } } }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    14: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ loot: new Loot({ Currencies: (_74 = {}, _74[CURRENCY.COIN] = 1000, _74) }) }]
    },
    15: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    16: {
        c: [{ loot: new Loot({ Currencies: (_75 = {}, _75[CURRENCY.COIN] = 250, _75) }) }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    17: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ loot: new Loot({ Currencies: (_76 = {}, _76[CURRENCY.COIN] = 1000, _76) }) }]
    },
    18: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_77 = {}, _77[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _77) } } }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    19: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 6, TotalSlots: 1, Rarities: (_78 = {}, _78[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 6, Weight: 1 }] }, _78) } } }],
    },
    20: {
        c: [{ loot: new Loot({ Currencies: (_79 = {}, _79[CURRENCY.GACHA_KEY] = 1, _79) }) }],
        s: [{ loot: new Loot({ Currencies: (_80 = {}, _80[CURRENCY.GACHA_KEY] = 2, _80) }) }]
    },
    21: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    22: {
        c: [{ loot: new Loot({ Currencies: (_81 = {}, _81[CURRENCY.COIN] = 250, _81) }) }],
        s: [{ loot: new Loot({ Currencies: (_82 = {}, _82[CURRENCY.COIN] = 1000, _82) }) }]
    },
    23: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    24: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_83 = {}, _83[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _83) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_84 = {}, _84[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _84) } } }],
    },
    25: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Butcher_legendary_weapon_chest.ID] }]
    },
    26: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    27: {
        c: [{ loot: new Loot({ Currencies: (_85 = {}, _85[CURRENCY.COIN] = 250, _85) }) }],
        s: [{ loot: new Loot({ Currencies: (_86 = {}, _86[CURRENCY.COIN] = 1000, _86) }) }]
    },
    28: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    29: {
        c: [{ loot: new Loot({ Currencies: (_87 = {}, _87[CURRENCY.COIN] = 250, _87) }) }],
        s: [{ loot: new Loot({ Currencies: (_88 = {}, _88[CURRENCY.COIN] = 1000, _88) }) }]
    },
    30: {
        c: [
            { loot: new Loot({ Stances: [stances.win_Ironclad_R_hell_yeah.ID] }) },
            { loot: new Loot({ Stances: [stances.win_Monk_R_stand_straight.ID] }) },
            { loot: new Loot({ Stances: [stances.win_Kibo_R_swing_hide.ID] }) },
            { loot: new Loot({ Currencies: (_89 = {}, _89[CURRENCY.COIN] = 1000, _89) }) }
        ],
        s: [
            { loot: new Loot({ Stances: [stances.win_HongJoo_R_autograph.ID] }) },
            { loot: new Loot({ Currencies: (_90 = {}, _90[CURRENCY.BONUS] = 200, _90) }) }
        ]
    },
    31: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_91 = {}, _91[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _91) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_92 = {}, _92[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _92) } } }],
    },
    32: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    33: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    34: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_93 = {}, _93[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _93) } } }],
        s: [{ loot: new Loot({ Currencies: (_94 = {}, _94[CURRENCY.COIN] = 1000, _94) }) }],
    },
    35: {
        c: [{ loot: new Loot({ Currencies: (_95 = {}, _95[CURRENCY.COIN] = 700, _95) }) }],
        s: [
            { loot: new Loot({ Emoji: [emoji.Legion_King_ThumbsDown.ID] }) },
            { loot: new Loot({ Currencies: (_96 = {}, _96[CURRENCY.BONUS] = 50, _96) }) },
        ]
    },
    36: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    37: {
        c: [{ loot: new Loot({ Currencies: (_97 = {}, _97[CURRENCY.BONUS] = 25, _97) }) }],
        s: [{ loot: new Loot({ Currencies: (_98 = {}, _98[CURRENCY.BONUS] = 150, _98) }) }]
    },
    38: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_99 = {}, _99[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _99) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_100 = {}, _100[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _100) } } }],
    },
    39: {
        c: [{ loot: new Loot({ Currencies: (_101 = {}, _101[CURRENCY.COIN] = 250, _101) }) }],
        s: [{ chests: [chests.Large_Shard_Chest_New_Hero.ID] }]
    },
    40: {
        c: [{ chests: [chests.Butcher_legendary_weapon_chest.ID] }],
        s: [{ loot: new Loot({ Currencies: (_102 = {}, _102[CURRENCY.GACHA_KEY] = 2, _102) }) }]
    },
    41: {
        c: [{ loot: new Loot({ Currencies: (_103 = {}, _103[CURRENCY.GACHA_KEY] = 1, _103) }) }],
        s: [{ loot: new Loot({ Currencies: (_104 = {}, _104[CURRENCY.COIN] = 1000, _104) }) }]
    },
    42: {
        c: [{ loot: new Loot({ Currencies: (_105 = {}, _105[CURRENCY.COIN] = 250, _105) }) }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    43: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    44: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }],
    },
    45: {
        c: [{ chests: [chests.Large_Shard_Chest_New_Hero.ID] }],
        s: [{ chests: [chests.Weapon_chest.ID] }]
    },
    46: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_106 = {}, _106[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _106) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_107 = {}, _107[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _107) } } }],
    },
    47: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    48: {
        c: [{ loot: new Loot({ Currencies: (_108 = {}, _108[CURRENCY.COIN] = 250, _108) }) }],
        s: [{ loot: new Loot({ Currencies: (_109 = {}, _109[CURRENCY.COIN] = 1000, _109) }) }]
    },
    49: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_110 = {}, _110[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _110) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 7, TotalSlots: 1, Rarities: (_111 = {}, _111[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 7, Weight: 1 }] }, _111) } } }],
    },
    50: {
        c: [
            { loot: new Loot({ Skins: [skins.Fireguard_R_Red_skin.ID] }) },
            { loot: new Loot({ Skins: [skins.Liquidator_R_Purple.ID] }) },
            { loot: new Loot({ Skins: [skins.Monk_R_Blue.ID] }) },
            { loot: new Loot({ Currencies: (_112 = {}, _112[CURRENCY.COIN] = 2000, _112) }) }
        ],
        s: [
            { loot: new Loot({ Stances: [stances.stance_Monkeyking_E_toothpick.ID] }) },
            { loot: new Loot({ Currencies: (_113 = {}, _113[CURRENCY.BONUS] = 200, _113) }) }
        ]
    },
    51: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    52: {
        c: [{ loot: new Loot({ Currencies: (_114 = {}, _114[CURRENCY.COIN] = 500, _114) }) }],
        s: [{ loot: new Loot({ Currencies: (_115 = {}, _115[CURRENCY.COIN] = 5000, _115) }) }]
    },
    53: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    54: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_116 = {}, _116[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _116) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 3, TotalSlots: 1, Rarities: (_117 = {}, _117[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 3, Weight: 1 }] }, _117) } } }],
    },
    55: {
        c: [{ chests: [chests.Weapon_chest.ID] }],
        s: [{ chests: [chests.Butcher_legendary_weapon_chest.ID] }]
    },
    56: {
        c: [{ loot: new Loot({ Currencies: (_118 = {}, _118[CURRENCY.BONUS] = 25, _118) }) }],
        s: [{ loot: new Loot({ Currencies: (_119 = {}, _119[CURRENCY.BONUS] = 150, _119) }) }]
    },
    57: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    58: {
        c: [{ loot: new Loot({ Currencies: (_120 = {}, _120[CURRENCY.COIN] = 250, _120) }) }],
        s: [{ loot: new Loot({ Currencies: (_121 = {}, _121[CURRENCY.COIN] = 1000, _121) }) }]
    },
    59: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 10, TotalSlots: 1, Rarities: (_122 = {}, _122[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 10, Weight: 1 }] }, _122) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 30, TotalSlots: 1, Rarities: (_123 = {}, _123[HERO_RARITY.COMMON] = { Slots: 1, CardsWeight: [{ Amount: 30, Weight: 1 }] }, _123) } } }],
    },
    60: {
        c: [{ loot: new Loot({ Currencies: (_124 = {}, _124[CURRENCY.GACHA_KEY] = 1, _124) }) }],
        s: [{ loot: new Loot({ Currencies: (_125 = {}, _125[CURRENCY.GACHA_KEY] = 2, _125) }) }]
    },
    61: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    62: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 4, TotalSlots: 1, Rarities: (_126 = {}, _126[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 4, Weight: 1 }] }, _126) } } }],
        s: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 7, TotalSlots: 1, Rarities: (_127 = {}, _127[HERO_RARITY.RARE] = { Slots: 1, CardsWeight: [{ Amount: 7, Weight: 1 }] }, _127) } } }],
    },
    63: {
        c: [{ loot: new Loot({ Currencies: (_128 = {}, _128[CURRENCY.COIN] = 250, _128) }) }],
        s: [{ loot: new Loot({ Currencies: (_129 = {}, _129[CURRENCY.COIN] = 1000, _129) }) }]
    },
    64: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Rare_chest.ID] }]
    },
    65: {
        c: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    66: {
        c: [{ chests: [chests.Rare_chest.ID] }],
        s: [{ chests: [chests.Epic_chest.ID] }],
    },
    67: {
        c: [{ loot: new Loot({ Currencies: (_130 = {}, _130[CURRENCY.COIN] = 250, _130) }) }],
        s: [{ loot: new Loot({ Currencies: (_131 = {}, _131[CURRENCY.COIN] = 1000, _131) }) }]
    },
    68: {
        c: [{ isHidden: true, lootSettings: { CardsSlots: { TotalCards: 2, TotalSlots: 1, Rarities: (_132 = {}, _132[HERO_RARITY.EPIC] = { Slots: 1, CardsWeight: [{ Amount: 2, Weight: 1 }] }, _132) } } }],
        s: [{ chests: [chests.Rare_chest.ID] }],
    },
    69: {
        c: [{ chests: [chests.Common_chest.ID] }],
        s: [{ chests: [chests.Large_Shard_Chest_Duplicate.ID] }]
    },
    70: {
        c: [{ chests: [chests.Legendary_chest.ID] }],
        s: [
            { loot: new Loot({ Skins: [skins.Viper_E_Grafitti.ID] }) },
            { loot: new Loot({ Currencies: (_133 = {}, _133[CURRENCY.GACHA_KEY] = 2, _133) }) }
        ]
    },
};
BattlePassArenaRewards.Rewards_template_1_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_with_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.Bulwark_SmokingGun.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ Stances: [stances.win_Lynx_E_portal.ID] }) },
            { loot: new Loot({ Currencies: (_134 = {}, _134[CURRENCY.BONUS] = 200, _134) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Viper_ThugLife.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ TextEmojiPacks: [textEmojiPacks.R_Dynasty.ID] }) },
            { loot: new Loot({ Currencies: (_135 = {}, _135[CURRENCY.BONUS] = 200, _135) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Marcus_E_Veteran_Rec_Nouveau_skin.ID] }) },
            { loot: new Loot({ Currencies: (_136 = {}, _136[CURRENCY.GACHA_KEY] = 2, _136) }) }
        ],
    },
});
BattlePassArenaRewards.Rewards_template_2_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_with_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.Lynx_Confused.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ Taunts: [taunts.Raikichi_E_ball.ID] }) },
            { loot: new Loot({ Currencies: (_137 = {}, _137[CURRENCY.BONUS] = 200, _137) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Yukka_Singing.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ Stances: [stances.win_Yunlin_E_flowers.ID] }) },
            { loot: new Loot({ Currencies: (_138 = {}, _138[CURRENCY.BONUS] = 200, _138) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Ling_E_Raven_Rec_Blue.ID] }) },
            { loot: new Loot({ Currencies: (_139 = {}, _139[CURRENCY.GACHA_KEY] = 2, _139) }) }
        ],
    },
});
BattlePassArenaRewards.Rewards_template_3_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_without_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.Midnight_Salute.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ Stances: [stances.stance_Marcus_E_stranger.ID] }) },
            { loot: new Loot({ Currencies: (_140 = {}, _140[CURRENCY.BONUS] = 200, _140) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Ironclad_Headless.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ TextEmojiPacks: [textEmojiPacks.R_Ironclad.ID] }) },
            { loot: new Loot({ Currencies: (_141 = {}, _141[CURRENCY.BONUS] = 200, _141) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Feldsher_E_Diver_Rec_Heated.ID] }) },
            { loot: new Loot({ Currencies: (_142 = {}, _142[CURRENCY.GACHA_KEY] = 2, _142) }) }
        ],
    },
});
BattlePassArenaRewards.Rewards_template_4_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_without_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.HongJoo_ChefsKiss.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ Taunts: [taunts.Butcher_E_bully.ID] }) },
            { loot: new Loot({ Currencies: (_143 = {}, _143[CURRENCY.BONUS] = 200, _143) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Feldsher_GlovedHand.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ Stances: [stances.stance_Nonna_R_drink.ID] }) },
            { loot: new Loot({ Currencies: (_144 = {}, _144[CURRENCY.BONUS] = 200, _144) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Xiang_Tzu_E_Indian_Rec_White.ID] }) },
            { loot: new Loot({ Currencies: (_145 = {}, _145[CURRENCY.GACHA_KEY] = 2, _145) }) }
        ],
    },
});
BattlePassArenaRewards.Rewards_template_5_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_without_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.Viper_Coffee.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ TextEmojiPacks: [textEmojiPacks.R_Butcher.ID] }) },
            { loot: new Loot({ Currencies: (_146 = {}, _146[CURRENCY.BONUS] = 200, _146) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Marcus_Sleep.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ Stances: [stances.stance_Gideon_R_fient.ID] }) },
            { loot: new Loot({ Currencies: (_147 = {}, _147[CURRENCY.BONUS] = 200, _147) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Butcher_E_Sushi.ID] }) },
            { loot: new Loot({ Currencies: (_148 = {}, _148[CURRENCY.GACHA_KEY] = 2, _148) }) }
        ],
    },
});
BattlePassArenaRewards.Rewards_template_6_of_6 = BattlePassArenaRewardsUtils
    .rewardsReplacerByType(BattlePassArenaRewards.template_with_legendary_weapon, {
    s: {
        5: [
            { loot: new Loot({ Emoji: [emoji.Monk_WasActing.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        10: [
            { chests: [chests.Animation_chest.ID] },
        ],
        30: [
            { loot: new Loot({ Taunts: [taunts.Sarge_R_walk.ID] }) },
            { loot: new Loot({ Currencies: (_149 = {}, _149[CURRENCY.BONUS] = 200, _149) }) }
        ],
        35: [
            { loot: new Loot({ Emoji: [emoji.Kibo_Speechless.ID] }) },
            { chests: [chests.Emoji_chest.ID] },
        ],
        50: [
            { loot: new Loot({ Stances: [stances.stance_Fireguard_E_slicing.ID] }) },
            { loot: new Loot({ Currencies: (_150 = {}, _150[CURRENCY.BONUS] = 200, _150) }) }
        ],
        70: [
            { loot: new Loot({ Skins: [skins.Fireguard_E_Cyber_Rec_Green.ID] }) },
            { loot: new Loot({ Currencies: (_151 = {}, _151[CURRENCY.GACHA_KEY] = 2, _151) }) }
        ],
    },
});
