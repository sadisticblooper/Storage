var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
var BATTLE_PASS_VISUAL_TIME_OF_YEAR;
(function (BATTLE_PASS_VISUAL_TIME_OF_YEAR) {
    BATTLE_PASS_VISUAL_TIME_OF_YEAR["WINTER"] = "winter";
    BATTLE_PASS_VISUAL_TIME_OF_YEAR["SPRING"] = "spring";
    BATTLE_PASS_VISUAL_TIME_OF_YEAR["SUMMER"] = "summer";
    BATTLE_PASS_VISUAL_TIME_OF_YEAR["AUTUMN"] = "autumn";
})(BATTLE_PASS_VISUAL_TIME_OF_YEAR || (BATTLE_PASS_VISUAL_TIME_OF_YEAR = {}));
var BattlePassVisual = (function () {
    function BattlePassVisual() {
    }
    BattlePassVisual.makeFromTemplate = function (timeOfYear, seasonImages) {
        return __assign(__assign({}, BattlePassVisual.templates[timeOfYear]), seasonImages);
    };
    BattlePassVisual.templates = (_a = {},
        _a[BATTLE_PASS_VISUAL_TIME_OF_YEAR.WINTER] = {
            "SubscriptionPopupPath": "UIPrefabs/Widgets/GamePopups/PassSubscriptionPopupWinter.prefab",
            "SharingPopupPath": "UIPrefabs/Widgets/GamePopups/PassSharingPopupWinter.prefab",
            "SubscriptionOfferBackground": "Sprites/PreviewImages/PassImages/pass_bg_winter",
            "FightPassBgImage": "Sprites/PreviewImages/ArenaLocations/location_winter",
            "FightPassGradientColor": "#276ACF8A",
            "LastRewardEffectColor": "#33568a",
            "FlowEffectColor": "#5ee7ff",
            "DustParticlesSettings": {
                "maxColor": "#5ee7ffb8",
                "minColor": "#5ee7ff5c"
            },
            "QuestsBgImage": "Sprites/PreviewImages/ArenaLocations/location_winter",
            "QuestsGradientColor": "#276acf",
        },
        _a[BATTLE_PASS_VISUAL_TIME_OF_YEAR.SPRING] = {
            "SubscriptionPopupPath": "UIPrefabs/Widgets/GamePopups/PassSubscriptionPopupSpring.prefab",
            "SharingPopupPath": "UIPrefabs/Widgets/GamePopups/PassSharingPopupSpring.prefab",
            "SubscriptionOfferBackground": "Sprites/PreviewImages/PassImages/pass_bg_spring",
            "FightPassBgImage": "Sprites/PreviewImages/ArenaLocations/location_heralds_street",
            "FightPassGradientColor": "#4e8a3f8A",
            "LastRewardEffectColor": "#4e8a3f",
            "FlowEffectColor": "#91ff75",
            "DustParticlesSettings": {
                "maxColor": "#ffd75eb8",
                "minColor": "#ffd75e5c"
            },
            "QuestsBgImage": "Sprites/PreviewImages/ArenaLocations/location_heralds_street",
            "QuestsGradientColor": "#4e8a3f",
        },
        _a[BATTLE_PASS_VISUAL_TIME_OF_YEAR.SUMMER] = {
            "SubscriptionPopupPath": "UIPrefabs/Widgets/GamePopups/PassSubscriptionPopupSummer.prefab",
            "SharingPopupPath": "UIPrefabs/Widgets/GamePopups/PassSharingPopupSummer.prefab",
            "SubscriptionOfferBackground": "Sprites/PreviewImages/PassImages/pass_bg_summer",
            "FightPassBgImage": "Sprites/PreviewImages/ArenaLocations/location_summer",
            "FightPassGradientColor": "#279ccf",
            "LastRewardEffectColor": "#337d8a",
            "FlowEffectColor": "#76EBFF",
            "DustParticlesSettings": {
                "maxColor": "#75EAFFb8",
                "minColor": "#75EAFF5c"
            },
            "QuestsBgImage": "Sprites/PreviewImages/ArenaLocations/location_summer",
            "QuestsGradientColor": "#3F7F8A",
        },
        _a[BATTLE_PASS_VISUAL_TIME_OF_YEAR.AUTUMN] = {
            "SubscriptionPopupPath": "UIPrefabs/Widgets/GamePopups/PassSubscriptionPopupAutumn.prefab",
            "SharingPopupPath": "UIPrefabs/Widgets/GamePopups/PassSharingPopupAutumn.prefab",
            "SubscriptionOfferBackground": "Sprites/PreviewImages/PassImages/pass_bg_autumn",
            "FightPassBgImage": "Sprites/PreviewImages/ArenaLocations/location_autumn",
            "FightPassGradientColor": "#e5ac55",
            "LastRewardEffectColor": "#5c4522",
            "FlowEffectColor": "#ffd75e",
            "DustParticlesSettings": {
                "maxColor": "#ffd75eb8",
                "minColor": "#ffd75e5c"
            },
            "QuestsBgImage": "Sprites/PreviewImages/ArenaLocations/location_autumn",
            "QuestsGradientColor": "#e5ac55",
        },
        _a);
    return BattlePassVisual;
}());
