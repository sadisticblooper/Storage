var BattlePassUtils = (function () {
    function BattlePassUtils() {
    }
    BattlePassUtils.convertBattlePassPoints = function (points, battlePassProgress) {
        var _a = BattlePassUtils.getConvertPointsSettings(battlePassProgress), rate = _a.rate, roundNumber = _a.roundNumber;
        var result = {};
        for (var currency in rate)
            if (rate.hasOwnProperty(currency)) {
                result[currency] = Math.max(roundNumber, Math.round((rate[currency] * points / roundNumber)) * roundNumber);
            }
        return result;
    };
    BattlePassUtils.convertBattlePassLoot = function (loot, battlePassProgress) {
        var result = new Loot();
        result.combineLoot(loot);
        result.BattlePassLevels = 0;
        var toConvert = result.BattlePassPoints;
        if (toConvert > 0) {
            result.BattlePassPoints = 0;
            var currencies = this.convertBattlePassPoints(toConvert, battlePassProgress);
            var converted = new Loot({ Currencies: currencies });
            result.combineLoot(converted);
        }
        return result;
    };
    BattlePassUtils.convertBattlePassLevelsToLoot = function (levels, battlePassProgress) {
        var defaultResult = {
            loot: new Loot(),
            restLevels: 0,
        };
        var rest = levels > 0 ? levels : 0;
        var toConvert = 0;
        if (!rest) {
            return defaultResult;
        }
        var battlePassId = battlePassProgress.BattlePassId, currentBattlePassLevel = battlePassProgress.CurrentBattlePassLevel;
        if (BattlePass.doSettingsHaveCorrectBattlePass(battlePassProgress)) {
            var battlePass = battlePassesMap.get(battlePassId);
            currentBattlePassLevel = Math.min(currentBattlePassLevel, battlePass.Levels);
            toConvert = currentBattlePassLevel + rest - battlePass.Levels;
            if (toConvert > 0) {
                rest = rest - toConvert;
            }
            else {
                toConvert = 0;
            }
        }
        else {
            toConvert = rest;
            rest = 0;
        }
        var compensation = {};
        var rate = BattlePassConstants.BattlePassLevelsRate;
        for (var currency in rate)
            if (rate.hasOwnProperty(currency)) {
                compensation[currency] = Math.max(0, (toConvert * rate[currency]) >> 0);
            }
        return { loot: new Loot({ Currencies: compensation }), restLevels: rest };
    };
    BattlePassUtils.getConvertPointsSettings = function (battlePassProgress) {
        if (BattlePass.doSettingsHaveCorrectBattlePass(battlePassProgress)) {
            return {
                rate: BattlePassConstants.BattlePassPointsRate,
                roundNumber: 1,
            };
        }
        return {
            rate: BattlePassConstants.BattlePassPointsLowRate,
            roundNumber: 5,
        };
    };
    BattlePassUtils.getBattlePassVisualSettings = function (battlePassId) {
        var battlePass = battlePassesMap.get(battlePassId);
        if (battlePass) {
            return battlePass.Settings.BattlePassVisualSettings;
        }
        return null;
    };
    return BattlePassUtils;
}());
