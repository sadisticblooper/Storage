var BattlePass = (function () {
    function BattlePass(settings) {
        this._id = settings.ID;
        this._start = settings.StartDate;
        this._levels = this.getLevels(settings.ArenaRewards);
        this.settings = settings;
        this._calcEnd();
    }
    Object.defineProperty(BattlePass.prototype, "ID", {
        get: function () { return this._id; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "Start", {
        get: function () { return this._start; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "AssetBundleTag", {
        get: function () { return this.settings.AssetBundleTag; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "Levels", {
        get: function () { return this._levels; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "Settings", {
        get: function () { return this.settings; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "End", {
        get: function () {
            return this._end;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BattlePass.prototype, "LevelUpPrice", {
        get: function () { return this.settings.LevelUpPrice; },
        enumerable: false,
        configurable: true
    });
    BattlePass.prototype._calcEnd = function () {
        if (this.settings.Days != undefined && this.settings.End != undefined) {
            throw new Error("you can use only one param in settings: or Days or End. BP ".concat(this._id));
        }
        if (this.settings.Days != undefined) {
            this._end = this._start + new Time({ Days: 1 }).value * this.settings.Days;
            this.Settings.End = this._end;
        }
        else if (this.settings.End != undefined) {
            if (this.settings.End < this._start) {
                throw new Error("end time less then start. BP ".concat(this._id));
            }
            this._end = this.settings.End;
            this.Settings.Days = ((this._end - this._start) / (new Time({ Days: 1 }).value)) >> 0;
        }
        else {
            throw new Error("you must use param in settings: or Days or End. BP ".concat(this._id));
        }
    };
    BattlePass.prototype.check = function () {
        this.testID();
        for (var level = 1; level < this._levels; level++) {
            if (!this.settings.PointsToLevelUp[level]) {
                throw new Error("Battle pass ".concat(this.ID, " error. No points to level up on level ").concat(level));
            }
        }
    };
    BattlePass.prototype.testID = function () {
        var idString = this._id.toString();
        var errorText = "ID of battle pass must be YYYYMM format, where YYYY - year, MM - month, ".concat(this._id, " given");
        if (idString.length != 6) {
            throw new Error(errorText);
        }
        var year = parseInt(idString.substr(0, 4));
        var month = parseInt(idString.substr(4, 2));
        if (!year || !month || month < 1 || month > 12) {
            throw new Error(errorText);
        }
    };
    BattlePass.prototype.getLevels = function (settings) {
        var levels = 0;
        for (var _i = 0, settings_1 = settings; _i < settings_1.length; _i++) {
            var battlePassArenasReward = settings_1[_i];
            if (!battlePassArenasReward) {
                throw new Error("No arena reward settings for ".concat(this.ID, " bp. Settings: ").concat(JSON.stringify(settings)));
            }
            if (!levels) {
                levels = Object.keys(battlePassArenasReward).length - 1;
            }
            if (levels != Object.keys(battlePassArenasReward).length - 1) {
                throw new Error("setRewardSettingsWithTest: Count of battle pass levels must be same at different arenas");
            }
        }
        return levels;
    };
    BattlePass.setRewardSettingsWithTest = function (settings) {
        var arenaIds = arenasMap.getKeys();
        var rewardArenasIds = [];
        var levels = 0;
        for (var _i = 0, settings_2 = settings; _i < settings_2.length; _i++) {
            var battlePassArenasReward = settings_2[_i];
            if (!levels) {
                levels = Object.keys(battlePassArenasReward).length - 1;
            }
            if (levels != Object.keys(battlePassArenasReward).length - 1) {
                throw new Error("setRewardSettingsWithTest: Count of battle pass levels must be same at different arenas");
            }
            for (var _a = 0, _b = battlePassArenasReward.Arenas; _a < _b.length; _a++) {
                var arenaID = _b[_a];
                if (rewardArenasIds.indexOf(arenaID) == -1) {
                    rewardArenasIds.push(arenaID);
                }
            }
        }
        for (var _c = 0, arenaIds_1 = arenaIds; _c < arenaIds_1.length; _c++) {
            var arenaID = arenaIds_1[_c];
            var index = rewardArenasIds.indexOf(arenaID);
            if (index > -1) {
                rewardArenasIds.splice(index, 1);
            }
            else {
                throw new Error("setRewardSettingsWithTest: No reward for arena(ID: ".concat(arenaID, ")"));
            }
        }
        if (rewardArenasIds.length) {
            throw new Error("setRewardSettingsWithTest: Unknown arena ids: ".concat(JSON.stringify(rewardArenasIds)));
        }
        return settings;
    };
    BattlePass.getStartDateAfterBattlePass = function (bp) {
        return bp.End;
    };
    BattlePass.isBattlePassAvailable = function (progress_) {
        var progress = PlayerState.getCorrectFromRawOrCache(progress_);
        var isAvailable = progress.accountLevel >= BattlePassConstants.minNeededLevel
            && progress.playerRating >= BattlePassConstants.minNeededRating;
        var arenaToUnlock = ArenaUtils.getArenaByRating(BattlePassConstants.minNeededRating) || arenas.Arena4;
        return {
            available: isAvailable,
            reason: isAvailable ? null : {
                isAlias: true,
                value: "quest_desc_arena",
                placeholders: [{ Type: ALIAS_TEXT_INSERTION_TYPE.TEXT, Value: arenaToUnlock.NameInf.Postfix }],
            },
        };
    };
    BattlePass.getBattlePassDay = function (time, battlePassId) {
        var bp = battlePassesMap.checkedGet(battlePassId);
        var currentTime = bp.Start;
        var day = 0;
        while (currentTime <= time) {
            day++;
            currentTime += 86400000;
        }
        return day;
    };
    BattlePass.getBattlePassByTime = function (time) {
        for (var bp_name in BattlePassSeasons) {
            var bp = BattlePassSeasons[bp_name];
            if (time >= bp.Start && time <= bp.End) {
                return bp;
            }
        }
        return null;
    };
    BattlePass.getLevelsUpPrice = function (settings) {
        var result = [];
        var bp = battlePassesMap.checkedGet(settings.BattlePassId);
        for (var level = 1; level <= bp.Levels; level++) {
            var price = {};
            for (var cur in bp.LevelUpPrice)
                if (bp.LevelUpPrice.hasOwnProperty(cur)) {
                    price[cur] = Math.round(bp.LevelUpPrice[cur] * level);
                }
            result.push({
                Levels: level,
                Price: price
            });
        }
        return result;
    };
    BattlePass.getBattlePassReward = function (settings) {
        var _a;
        var result = { Common: null, Subscription: null };
        var rewards;
        var bp = battlePassesMap.checkedGet(settings.BattlePassId);
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.PlayerProgress);
        for (var _i = 0, _b = bp.Settings.ArenaRewards; _i < _b.length; _i++) {
            var arenaRewardBlock = _b[_i];
            if (arenaRewardBlock.Arenas.indexOf(playerProgress.playerArenaId) > -1) {
                if (!arenaRewardBlock[settings.Level]) {
                    throw new Error("getBattlePassReward: No level ".concat(settings.Level, " in \n                    battle pass (id ").concat(settings.BattlePassId, ") settings"));
                }
                rewards = arenaRewardBlock[settings.Level];
                break;
            }
        }
        if (!rewards) {
            throw new Error("getBattlePassReward: Arena with id ".concat(playerProgress.playerArenaId, " not found \n            in battle pass (id ").concat(settings.BattlePassId, ") settings!"));
        }
        rewards = BattlePass.getRewardsWithCustom(settings.CustomRewardsOffset, settings.Level, rewards);
        var iterator = { "Subscription": "s", "Common": "c" };
        var orderOfIteration = ["Subscription", "Common"];
        RandomInstance.setSeed(settings.Seed);
        var lootGenerator = LootGeneratorBuilder.getBattlePassLootGenerator();
        lootGenerator.setPlayerParams(playerProgress);
        lootGenerator.setServerTime(settings.StartTimeOfCurrentDayMS);
        for (var _c = 0, orderOfIteration_1 = orderOfIteration; _c < orderOfIteration_1.length; _c++) {
            var outType = orderOfIteration_1[_c];
            var inType = iterator[outType];
            var rewardsInType = rewards[inType];
            if (!rewardsInType) {
                result[outType] = null;
                continue;
            }
            var lootGenerated = false;
            var loot = void 0;
            var chests_1 = void 0;
            var isHidden = false;
            for (var _d = 0, rewardsInType_1 = rewardsInType; _d < rewardsInType_1.length; _d++) {
                var rewardContent = rewardsInType_1[_d];
                chests_1 = [];
                loot = new Loot();
                var rewardResult = lootGenerator.getRewardFromRewardContent(rewardContent, RandomInstance);
                isHidden = rewardResult.IsHidden;
                if (rewardResult.Loot && !rewardResult.Loot.isEmpty()) {
                    loot = rewardResult.Loot;
                    lootGenerated = true;
                }
                else if (rewardResult.Chests && rewardResult.Chests.length > 0) {
                    chests_1 = rewardResult.Chests.slice();
                    lootGenerated = true;
                }
                if (lootGenerated) {
                    break;
                }
            }
            if (!lootGenerated) {
                loot = new Loot({ Currencies: (_a = {}, _a[CURRENCY.COIN] = 101, _a) });
            }
            result[outType] = {
                Loot: loot,
                Chests: chests_1,
                NewSeed: RandomInstance.nextInt(RandomInstance.MAX_INTEGER()),
                IsHidden: isHidden,
            };
        }
        return result;
    };
    BattlePass.getBattlePassRewardsPerLevels = function (settings) {
        var result = { Common: {}, Subscription: {} };
        var bp = battlePassesMap.checkedGet(settings.BattlePassId);
        var startLevel = Math.max(1, Math.min(settings.LevelStart, settings.LevelEnd));
        var endLevel = Math.min(bp.Levels, Math.max(settings.LevelStart, settings.LevelEnd));
        for (var level = startLevel; level <= endLevel; level++) {
            var reward = BattlePass.getBattlePassReward({
                Level: level,
                BattlePassId: settings.BattlePassId,
                PlayerProgress: settings.PlayerProgress,
                CustomRewardsOffset: settings.CustomRewardsOffset,
                Seed: settings.Seed,
                StartTimeOfCurrentDayMS: settings.StartTimeOfCurrentDayMS,
            });
            result.Common[level] = reward.Common;
            result.Subscription[level] = reward.Subscription;
        }
        return result;
    };
    BattlePass.getBattlePassCombinedRewards = function (settings) {
        var chestQueue = settings.ChestQueuePositions;
        var chestSeed = settings.ChestSeed;
        var commonSeed = settings.Seed;
        var battlePassId = settings.BattlePassId;
        var playerProgress = PlayerState.getCorrectFromRawOrCache(settings.PlayerProgress);
        var rewardsOffset = settings.CustomRewardsOffset;
        var premiumLevels = getArrayFromRaw(settings.PremiumLevels);
        var commonLevels = getArrayFromRaw(settings.CommonLevels);
        var doFullResult = settings.GetFullResult;
        var levels = ArrayUtils.getUniqueArray(commonLevels.concat(premiumLevels));
        var currentServerTime = settings.StartTimeOfCurrentDayMS;
        levels.sort(function (a, b) { return a - b; });
        var totalResultLoot = new Loot();
        var fullResult = doFullResult ? { Common: [], Premium: [] } : null;
        var iterator = [
            { kIn: "Common", kOut: "Common", requiredLevels: commonLevels },
            { kIn: "Subscription", kOut: "Premium", requiredLevels: premiumLevels },
        ];
        if (levels.length > 0) {
            for (var _i = 0, levels_1 = levels; _i < levels_1.length; _i++) {
                var level = levels_1[_i];
                var bpRewardResult = BattlePass.getBattlePassReward({
                    Level: level,
                    BattlePassId: battlePassId,
                    CustomRewardsOffset: rewardsOffset,
                    PlayerProgress: playerProgress,
                    Seed: commonSeed,
                    StartTimeOfCurrentDayMS: currentServerTime,
                });
                for (var _a = 0, iterator_1 = iterator; _a < iterator_1.length; _a++) {
                    var iteration = iterator_1[_a];
                    var kIn = iteration.kIn, kOut = iteration.kOut, requiredLevels = iteration.requiredLevels;
                    if (requiredLevels.indexOf(level) == -1) {
                        continue;
                    }
                    var rewardResult = bpRewardResult[kIn];
                    var rewardLoot = null;
                    var rewardChests = null;
                    if (!rewardResult) {
                        if (doFullResult) {
                            fullResult[kOut].push({ Stage: level, Chests: null, Loot: null });
                        }
                        continue;
                    }
                    commonSeed = rewardResult.NewSeed;
                    var combinedReward = LootUtils.getGeneratedLootFromRewardResult({
                        playerProgress: playerProgress,
                        reward: rewardResult,
                        chestSeed: chestSeed,
                        chestQueuePositions: chestQueue,
                        enableCombiningWithPlayer: true,
                        startTimeOfCurrentDayMS: currentServerTime,
                    });
                    chestSeed = combinedReward.chestSeed;
                    chestQueue = combinedReward.chestQueuePositions;
                    if (!combinedReward.loot.isEmpty()) {
                        rewardLoot = combinedReward.loot;
                        HeroUtils.combineLoot(playerProgress, rewardLoot);
                        totalResultLoot.combineLoot(rewardLoot);
                    }
                    if (combinedReward.chests.length > 0) {
                        rewardChests = [];
                        for (var _b = 0, _c = combinedReward.chests; _b < _c.length; _b++) {
                            var chestInfo = _c[_b];
                            rewardChests.push({
                                ID: chestInfo.id,
                                Loot: chestInfo.loot,
                            });
                            HeroUtils.combineLoot(playerProgress, chestInfo.loot);
                            totalResultLoot.combineLoot(chestInfo.loot);
                        }
                    }
                    if (doFullResult) {
                        fullResult[kOut].push({ Stage: level, Loot: rewardLoot, Chests: rewardChests });
                    }
                }
            }
        }
        return {
            Seed: commonSeed,
            ChestSeed: chestSeed,
            ChestQueuePositions: chestQueue,
            Loot: totalResultLoot.isEmpty() ? null : totalResultLoot,
            FullResult: fullResult,
        };
    };
    BattlePass.getBattlePassRewards = function (settings) {
        var bp = battlePassesMap.checkedGet(settings.BattlePassId);
        var newSettings = {
            BattlePassId: settings.BattlePassId,
            LevelStart: 1,
            LevelEnd: bp.Levels,
            PlayerProgress: settings.PlayerProgress,
            CustomRewardsOffset: settings.CustomRewardsOffset,
            Seed: settings.Seed,
            StartTimeOfCurrentDayMS: settings.StartTimeOfCurrentDayMS,
        };
        return BattlePass.getBattlePassRewardsPerLevels(newSettings);
    };
    BattlePass.updateCurrentBattlePassLevelState = function (settings) {
        var bp = battlePassesMap.checkedGet(settings.BattlePassId);
        var currentLevel = settings.CurrentBattlePassLevel;
        var currentPoints = settings.CurrentBattlePassPoints + settings.BattlePassPointsFromReward;
        var levels = bp.Levels;
        if (currentLevel < 1) {
            return { CurrentBattlePassPoints: 0, CurrentBattlePassLevel: 1 };
        }
        if (currentLevel >= levels) {
            return { CurrentBattlePassPoints: 0, CurrentBattlePassLevel: levels };
        }
        for (var level = currentLevel; level < levels; level++) {
            var pointsToLevelUp = bp.Settings.PointsToLevelUp[level];
            if (currentPoints >= pointsToLevelUp) {
                currentLevel++;
                currentPoints -= pointsToLevelUp;
            }
            else {
                break;
            }
        }
        if (currentLevel >= levels) {
            return { CurrentBattlePassPoints: 0, CurrentBattlePassLevel: levels };
        }
        return { CurrentBattlePassPoints: currentPoints, CurrentBattlePassLevel: currentLevel };
    };
    BattlePass.doSettingsHaveCorrectBattlePass = function (settings) {
        return !!(settings && settings.BattlePassId && battlePassesMap.get(settings.BattlePassId));
    };
    BattlePass.isBattlePassComplete = function (settings) {
        if (!this.doSettingsHaveCorrectBattlePass(settings)) {
            return false;
        }
        var battlePass = battlePassesMap.get(settings.BattlePassId);
        return battlePass ? settings.CurrentBattlePassLevel >= battlePass.Levels : false;
    };
    BattlePass.doNeedConvertBattlePassPoints = function (settings) {
        if (!this.doSettingsHaveCorrectBattlePass(settings)) {
            return true;
        }
        return this.isBattlePassComplete(settings);
    };
    BattlePass.hasBattlePassRewardsAtLevel = function (settings) {
        var bp = battlePassesMap.checkedGet(settings.BattlePassProgressSettings.BattlePassId);
        var arena = settings.ArenaId;
        var level = settings.BattlePassProgressSettings.CurrentBattlePassLevel;
        var rewards;
        for (var _i = 0, _a = bp.Settings.ArenaRewards; _i < _a.length; _i++) {
            var arenaRewardBlock = _a[_i];
            if (arenaRewardBlock.Arenas.indexOf(arena) > -1) {
                if (!arenaRewardBlock[level]) {
                    throw new Error("hasBattlePassRewardsAtLevel: \n                    \rNo level ".concat(level, " in battle pass (id ").concat(bp.ID, ") settings"));
                }
                rewards = arenaRewardBlock[level];
                break;
            }
        }
        if (!rewards) {
            throw new Error("hasBattlePassRewardsAtLevel: \n            \rArena with id ".concat(arena, " not found in battle pass (id ").concat(bp.ID, ") settings!"));
        }
        return {
            Common: !!rewards.c,
            Subscription: !!rewards.s
        };
    };
    BattlePass.createOfferForBattlePass = function (settings) {
        var shopOfferSettings = new ShopOfferSettings(settings.offerSettings);
        var shopOffer = new ShopOffer();
        shopOffer.generate({
            shopType: SHOP_TYPE.UNKNOWN_SHOP_TYPE,
            regionalSettings: settings.regionalSettings,
            playerProgress: null,
            seed: 0,
            startTimeOfCurrentDayMS: 1,
        }, shopOfferSettings);
        shopOffer.updateInAppByRegional(settings.regionalSettings);
        return shopOffer;
    };
    BattlePass.getBattlePassSettings = function (settings) {
        var battlePass = battlePassesMap.get(settings.BattlePassId);
        if (!battlePass) {
            return null;
        }
        var battlePassSettings = battlePass.Settings;
        var offer = BattlePass.createOfferForBattlePass({
            regionalSettings: settings.RegionalSettings,
            offerSettings: battlePassSettings.OfferToBuyPremium,
        });
        var offerWithLevels = BattlePass.createOfferForBattlePass({
            regionalSettings: settings.RegionalSettings,
            offerSettings: battlePassSettings.OfferToBuyPremiumWithLevels,
        });
        var additionalBattlePassLevelsForInApp = battlePassSettings.OfferToBuyPremiumWithLevels.FixedLoot
            ? battlePassSettings.OfferToBuyPremiumWithLevels.FixedLoot.BattlePassLevels
            : 0;
        return {
            StartDate: battlePassSettings.StartDate,
            Days: battlePassSettings.Days,
            SeasonNumber: battlePassSettings.SeasonNumber,
            PointsToLevelUp: battlePassSettings.PointsToLevelUp,
            AddLevelsBySubscription: battlePassSettings.AddLevelsBySubscription,
            AdditionalBattlePassLevelsForInApp: additionalBattlePassLevelsForInApp,
            RubiesEquivalentOfPremium: battlePassSettings.RubiesEquivalentOfPremium,
            OfferToBuyPremium: offer,
            OfferToBuyPremiumWithLevels: offerWithLevels,
            Levels: battlePass.Levels,
        };
    };
    BattlePass.sortBattlePassRewards = function (settings) {
        var _a, _b, _c, _d;
        var rewards = getBattlePassRewards(settings);
        var subscriptionsRewards = rewards.Subscription;
        var result;
        var skins = [];
        var weapons = [];
        var taunts = [];
        var textTaunts = [];
        var stances = [];
        var emoji = [];
        var chests = {};
        var currency = {};
        var shards = {};
        var cards = {};
        var amountOfRewards = Object.keys(subscriptionsRewards).length;
        var customizationShards = {};
        for (var i = 1; i <= amountOfRewards; i++) {
            if (!subscriptionsRewards[i]) {
                continue;
            }
            var loot = subscriptionsRewards[i].Loot;
            if (loot) {
                if (loot.HeroSkins.length > 0) {
                    skins.push.apply(skins, loot.HeroSkins);
                }
                if (loot.Weapons.length > 0) {
                    weapons.push.apply(weapons, loot.Weapons);
                }
                if (loot.Taunts.length > 0) {
                    taunts.push.apply(taunts, loot.Taunts);
                }
                if (loot.TextEmojiPacks.length > 0) {
                    textTaunts.push.apply(textTaunts, loot.TextEmojiPacks);
                }
                if (loot.Stances.length > 0) {
                    stances.push.apply(stances, loot.Stances);
                }
                if (loot.Emoji.length > 0) {
                    emoji.push.apply(emoji, loot.Emoji);
                }
                if (loot.Currencies) {
                    for (var key in loot.Currencies) {
                        if (!currency[key]) {
                            currency[key] = 0;
                        }
                        currency[key] += loot.Currencies[key];
                    }
                }
                if (loot.hasCards()) {
                    for (var heroId in loot.HeroExp) {
                        if (!cards[heroId]) {
                            cards[heroId] = 0;
                        }
                        cards[heroId] += loot.HeroExp[heroId];
                    }
                }
                if (loot.hasShards()) {
                    for (var heroId in loot.Shards) {
                        if (!shards[heroId]) {
                            shards[heroId] = 0;
                        }
                        shards[heroId] += loot.Shards[heroId];
                    }
                }
                if (loot.hasCustomizationShards()) {
                    for (var id in loot.CustomizationShards) {
                        if (!customizationShards[id]) {
                            customizationShards[id] = 0;
                        }
                        customizationShards[id] += loot.CustomizationShards[id];
                    }
                }
            }
            if (subscriptionsRewards[i].Chests && subscriptionsRewards[i].Chests.length > 0) {
                for (var _i = 0, _e = subscriptionsRewards[i].Chests; _i < _e.length; _i++) {
                    var id = _e[_i];
                    if (!chests[id]) {
                        chests[id] = 0;
                    }
                    chests[id] += 1;
                }
            }
        }
        skins = ArrayUtils.getUniqueArray(skins);
        weapons = ArrayUtils.getUniqueArray(weapons);
        taunts = ArrayUtils.getUniqueArray(taunts);
        textTaunts = ArrayUtils.getUniqueArray(textTaunts);
        stances = ArrayUtils.getUniqueArray(stances);
        emoji = ArrayUtils.getUniqueArray(emoji);
        skins.sort(function (id1, id2) {
            var skin1 = skinsMap.checkedGet(id1);
            var skin2 = skinsMap.checkedGet(id2);
            return skin2.Rarity - skin1.Rarity;
        });
        weapons.sort(function (id1, id2) {
            var weapon1 = weaponsMap.checkedGet(id1);
            var weapon2 = weaponsMap.checkedGet(id2);
            return weapon2.Settings.Rarity - weapon1.Settings.Rarity;
        });
        taunts.sort(function (id1, id2) {
            var taunt1 = tauntsMap.checkedGet(id1);
            var taunt2 = tauntsMap.checkedGet(id2);
            return taunt2.Settings.Rarity - taunt1.Settings.Rarity;
        });
        textTaunts.sort(function (id1, id2) {
            var textTaunt1 = textEmojiPacksMap.checkedGet(id1);
            var textTaunt2 = textEmojiPacksMap.checkedGet(id2);
            return textTaunt1.rarity - textTaunt2.rarity;
        });
        stances.sort(function (id1, id2) {
            var stance1 = stancesMap.checkedGet(id1);
            var stance2 = stancesMap.checkedGet(id2);
            return stance2.Settings.Rarity - stance1.Settings.Rarity;
        });
        var idChests = Object.keys(chests).map(function (id) { return Number(id); });
        idChests.sort(function (id1, id2) {
            var idChest1 = chestsMap.checkedGet(id1);
            var idChest2 = chestsMap.checkedGet(id2);
            return idChest2.Type - idChest1.Type;
        });
        var customizationShardsResult = [];
        var skinsAndWeaponsResult = [];
        var tauntsAndStancesResult = [];
        var textTauntsResult = [];
        var emojiResult = [];
        var chestsResult = [];
        var currencyResult = [];
        var cardResult = [];
        var shardsResult = [];
        for (var _f = 0, skins_1 = skins; _f < skins_1.length; _f++) {
            var id = skins_1[_f];
            skinsAndWeaponsResult.push({
                Loot: new Loot({ Skins: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var _g = 0, weapons_1 = weapons; _g < weapons_1.length; _g++) {
            var id = weapons_1[_g];
            skinsAndWeaponsResult.push({
                Loot: new Loot({ Weapons: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var _h = 0, taunts_1 = taunts; _h < taunts_1.length; _h++) {
            var id = taunts_1[_h];
            tauntsAndStancesResult.push({
                Loot: new Loot({ Taunts: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var _j = 0, stances_1 = stances; _j < stances_1.length; _j++) {
            var id = stances_1[_j];
            tauntsAndStancesResult.push({
                Loot: new Loot({ Stances: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var _k = 0, textTaunts_1 = textTaunts; _k < textTaunts_1.length; _k++) {
            var id = textTaunts_1[_k];
            textTauntsResult.push({
                Loot: new Loot({ TextEmojiPacks: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var _l = 0, emoji_1 = emoji; _l < emoji_1.length; _l++) {
            var id = emoji_1[_l];
            emojiResult.push({
                Loot: new Loot({ Emoji: [id] }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var type in currency) {
            currencyResult.push({
                Loot: new Loot({ Currencies: (_a = {}, _a[type] = currency[type], _a) }),
                Chests: [],
                NewSeed: 0,
            });
        }
        for (var heroId in cards) {
            cardResult.push({
                Loot: new Loot({ HeroExp: (_b = {}, _b[heroId] = cards[heroId], _b) }),
                Chests: [],
                NewSeed: 0
            });
        }
        for (var heroId in shards) {
            shardsResult.push({
                Loot: new Loot({ Shards: (_c = {}, _c[heroId] = shards[heroId], _c) }),
                Chests: [],
                NewSeed: 0
            });
        }
        for (var id in customizationShards) {
            customizationShardsResult.push({
                Loot: new Loot({ CustomizationShards: (_d = {}, _d[id] = customizationShards[id], _d) }),
                Chests: [],
                NewSeed: 0
            });
        }
        for (var _m = 0, idChests_1 = idChests; _m < idChests_1.length; _m++) {
            var id = idChests_1[_m];
            var repeats = [];
            for (var i = 0; i < chests[id]; i++) {
                repeats.push(id);
            }
            chestsResult.push({
                Loot: new Loot(),
                Chests: repeats,
                NewSeed: 0,
            });
        }
        result = [customizationShardsResult, skinsAndWeaponsResult, tauntsAndStancesResult, textTauntsResult, emojiResult,
            chestsResult, shardsResult, cardResult, currencyResult];
        return result;
    };
    BattlePass.updateCustomBattlePassRewardsOffset = function (settings) {
        var customCommonRewards = BattlePassCustomRewards.customRewards;
        var offset = settings.CustomRewardsOffset;
        if (offset == null || offset < 0) {
            offset = customCommonRewards.length;
        }
        return Math.min(customCommonRewards.length, offset + settings.BattlePassLevel);
    };
    BattlePass.getRewardsWithCustom = function (customOffset, level, rewards) {
        var customCommonRewards = BattlePassCustomRewards.customRewards;
        var offset = customOffset;
        if (offset == null || offset < 0) {
            offset = customCommonRewards.length;
        }
        var customIndex = offset + level - 1;
        if (customIndex >= customCommonRewards.length) {
            return rewards;
        }
        return {
            s: rewards.s,
            c: customCommonRewards[customIndex],
        };
    };
    BattlePass.getValuableRewards = function (settings) {
        var battlePass = battlePassesMap.checkedGet(settings.BattlePassId);
        var battlePassLevels = battlePass.Levels;
        var rewards = getBattlePassRewards(settings);
        var result = {};
        for (var i = 1; i <= battlePassLevels; i++) {
            if (rewards.Subscription[i] != null) {
                var subscriptionReward = rewards.Subscription[i].Loot;
                if (subscriptionReward && !subscriptionReward.isEmpty()) {
                    var allowedReward = !subscriptionReward.hasCurrency()
                        && !subscriptionReward.hasCards()
                        && !subscriptionReward.hasShards();
                    if (allowedReward) {
                        var claimed = settings.ClaimedSubscriberLevels.indexOf(i) > -1;
                        if (!claimed) {
                            result[i] = {
                                Loot: subscriptionReward,
                                Chests: [],
                                NewSeed: settings.Seed,
                                IsHidden: false,
                            };
                        }
                    }
                }
            }
        }
        return result;
    };
    return BattlePass;
}());
