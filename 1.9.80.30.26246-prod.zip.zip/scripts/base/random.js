var PcgRandom = (function () {
    function PcgRandom(seedHi, seedLo, incHi, incLo) {
        if (seedLo === void 0) { seedLo = null; }
        if (incHi === void 0) { incHi = null; }
        if (incLo === void 0) { incLo = null; }
        this.defaultIncHi = 0x14057b7e;
        this.defaultIncLo = 0xf767814f;
        this.MUL_HI = 0x5851f42d >>> 0;
        this.MUL_LO = 0x4c957f2d >>> 0;
        this.BIT_53 = 9007199254740992.0;
        this.BIT_27 = 134217728.0;
        this.state = [];
        this.initSeed(seedHi, seedLo, incHi, incLo);
    }
    PcgRandom.prototype.setSeed = function (seed) {
        this.initSeed(seed);
    };
    PcgRandom.prototype.nextInt = function (bound) {
        return this.integer(bound);
    };
    PcgRandom.prototype.nextDouble = function () {
        return this.number();
    };
    PcgRandom.prototype.MAX_INTEGER = function () {
        return 2147483647;
    };
    PcgRandom.prototype.initSeed = function (seedHi, seedLo, incHi, incLo) {
        if (seedLo === void 0) { seedLo = null; }
        if (incHi === void 0) { incHi = null; }
        if (incLo === void 0) { incLo = null; }
        if (seedLo == null && seedHi == null) {
            seedLo = (Math.random() * 0xffffffff) >>> 0;
            seedHi = 0;
        }
        else if (seedLo == null) {
            seedLo = seedHi;
            seedHi = 0;
        }
        if (incLo == null && incHi == null) {
            incLo = this.state ? this.state[3] : this.defaultIncLo;
            incHi = this.state ? this.state[2] : this.defaultIncHi;
        }
        else if (incLo == null) {
            incLo = incHi;
            incHi = 0;
        }
        this.state = [0, 0, incHi >>> 0, (incLo | 1) >>> 0];
        this.next();
        this.add64(this.state, this.state[0], this.state[1], seedHi >>> 0, seedLo >>> 0);
        this.next();
        return this;
    };
    PcgRandom.prototype.getState = function () {
        return [this.state[0], this.state[1], this.state[2], this.state[3]];
    };
    PcgRandom.prototype.imul = function (a, b) {
        var ah = (a >>> 16) & 0xffff, al = a & 0xffff;
        var bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
        return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0) | 0);
    };
    PcgRandom.prototype.mul64 = function (out, aHi, aLo, bHi, bLo) {
        var c1 = (aLo >>> 16) * (bLo & 0xffff) >>> 0;
        var c0 = (aLo & 0xffff) * (bLo >>> 16) >>> 0;
        var lo = ((aLo & 0xffff) * (bLo & 0xffff)) >>> 0;
        var hi = ((aLo >>> 16) * (bLo >>> 16)) + ((c0 >>> 16) + (c1 >>> 16)) >>> 0;
        c0 = (c0 << 16) >>> 0;
        lo = (lo + c0) >>> 0;
        if ((lo >>> 0) < (c0 >>> 0)) {
            hi = (hi + 1) >>> 0;
        }
        c1 = (c1 << 16) >>> 0;
        lo = (lo + c1) >>> 0;
        if ((lo >>> 0) < (c1 >>> 0)) {
            hi = (hi + 1) >>> 0;
        }
        hi = (hi + this.imul(aLo, bHi)) >>> 0;
        hi = (hi + this.imul(aHi, bLo)) >>> 0;
        out[0] = hi;
        out[1] = lo;
    };
    PcgRandom.prototype.add64 = function (out, aHi, aLo, bHi, bLo) {
        var hi = (aHi + bHi) >>> 0;
        var lo = (aLo + bLo) >>> 0;
        if ((lo >>> 0) < (aLo >>> 0)) {
            hi = (hi + 1) | 0;
        }
        out[0] = hi;
        out[1] = lo;
    };
    PcgRandom.prototype.next = function () {
        var oldHi = this.state[0] >>> 0;
        var oldLo = this.state[1] >>> 0;
        this.mul64(this.state, oldHi, oldLo, this.MUL_HI, this.MUL_LO);
        this.add64(this.state, this.state[0], this.state[1], this.state[2], this.state[3]);
        var xsHi = oldHi >>> 18;
        var xsLo = ((oldLo >>> 18) | (oldHi << 14)) >>> 0;
        xsHi = (xsHi ^ oldHi) >>> 0;
        xsLo = (xsLo ^ oldLo) >>> 0;
        var xorshifted = ((xsLo >>> 27) | (xsHi << 5)) >>> 0;
        var rot = oldHi >>> 27;
        var rot2 = ((-rot >>> 0) & 31) >>> 0;
        return ((xorshifted >>> rot) | (xorshifted << rot2)) >>> 0;
    };
    PcgRandom.prototype.integer = function (max) {
        if (!max) {
            return this.next();
        }
        max = max >>> 0;
        if ((max & (max - 1)) === 0) {
            return this.next() & (max - 1);
        }
        var num = 0;
        var skew = ((-max >>> 0) % max) >>> 0;
        for (num = this.next(); num < skew; num = this.next()) {
        }
        return num % max;
    };
    PcgRandom.prototype.number = function () {
        var hi = (this.next() & 0x03ffffff) * 1.0;
        var lo = (this.next() & 0x07ffffff) * 1.0;
        return ((hi * this.BIT_27) + lo) / this.BIT_53;
    };
    return PcgRandom;
}());
var RndFromInterval = (function () {
    function RndFromInterval(a, b) {
        this._min = a;
        this._max = b != undefined ? b : a;
        if (this._max < this._min) {
            var t = this._max;
            this._max = this._min;
            this._min = t;
        }
    }
    RndFromInterval.prototype.getRandomValue = function (rnd) {
        if (this._max == this._min) {
            return this._min;
        }
        var borders = this._max - this._min;
        var rand = Math.floor(rnd.nextDouble() * borders + 0.5);
        return this._min + rand;
    };
    RndFromInterval.prototype.getMin = function () { return this._min; };
    RndFromInterval.prototype.getMax = function () { return this._max; };
    Object.defineProperty(RndFromInterval.prototype, "min", {
        get: function () { return this._min; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RndFromInterval.prototype, "max", {
        get: function () { return this._max; },
        enumerable: false,
        configurable: true
    });
    return RndFromInterval;
}());
var CollectionObjectContainer = (function () {
    function CollectionObjectContainer(item, weight) {
        this.Object = item;
        this.Weight = weight;
    }
    CollectionObjectContainer.prototype.getWeight = function () {
        return this.Weight;
    };
    CollectionObjectContainer.prototype.get = function () {
        return this.Object;
    };
    return CollectionObjectContainer;
}());
var RandomCollection = (function () {
    function RandomCollection() {
        this.map = new OrderMap();
        this.mapSize = 0;
        this.total = 0;
    }
    RandomCollection.prototype.addAll = function (values) {
        for (var _i = 0, values_1 = values; _i < values_1.length; _i++) {
            var value = values_1[_i];
            this.add(value);
        }
    };
    RandomCollection.prototype.add = function (value) {
        var weight = value.getWeight();
        if (weight <= 0)
            return;
        this.total += weight;
        this.map.put(this.total, value);
        this.mapSize++;
    };
    RandomCollection.prototype.next = function (rnd) {
        if (this.mapSize == 0)
            return null;
        var rd = rnd.nextDouble() * this.total;
        return this.ceilingValue(rd);
    };
    RandomCollection.prototype.ceilingValue = function (key) {
        for (var _i = 0, _a = this.map.getKeys(); _i < _a.length; _i++) {
            var obj = _a[_i];
            if (obj >= key) {
                return this.map.get(obj);
            }
        }
    };
    RandomCollection.prototype.remove = function (value) {
        var result = false;
        var all = this.map;
        this.clear();
        for (var _i = 0, _a = all.getKeys(); _i < _a.length; _i++) {
            var key = _a[_i];
            var item = all.get(key);
            if (item === value) {
                result = true;
            }
            else {
                this.add(item);
            }
        }
        return result;
    };
    RandomCollection.prototype.size = function () {
        return this.mapSize;
    };
    RandomCollection.prototype.clear = function () {
        this.map = new OrderMap();
        this.mapSize = 0;
        this.total = 0;
    };
    RandomCollection.prototype.list = function (extract) {
        if (extract === void 0) { extract = (function (x) { return x; }); }
        var result = [];
        for (var _i = 0, _a = this.map.getKeys(); _i < _a.length; _i++) {
            var obj = _a[_i];
            result.push(extract(this.map.get(obj)));
        }
        return result;
    };
    return RandomCollection;
}());
