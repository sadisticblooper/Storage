var FlagUtils = (function () {
    function FlagUtils() {
    }
    FlagUtils.check = function (flag, flags) {
        return !((flags & flag) == 0);
    };
    FlagUtils.set = function (flag, flags) {
        flags |= flag;
        return flags;
    };
    FlagUtils.unset = function (flag, flags) {
        flags &= (~flag);
        return flags;
    };
    return FlagUtils;
}());
var ArrayUtils = (function () {
    function ArrayUtils() {
    }
    ArrayUtils.getArrayProportionalMinimized = function (goalSum, _inA, _inAMax, _inAMin) {
        if (!_inA
            || !_inAMax
            || !Array.isArray(_inAMax)
            || _inAMax.length < 1
            || _inAMax.length != _inA.length
            || !goalSum
            || !Array.isArray(_inA)
            || !_inAMin
            || !Array.isArray(_inAMin)
            || _inAMin.length < 1
            || _inAMin.length != _inA.length) {
            throw new Error("GetArrayProportionalMinimized: \n                \rwrong in parameters: ".concat(JSON.stringify([goalSum, _inA, _inAMax])));
        }
        var inArray = [];
        var inArrayMaxes = [];
        var inArrayMinimums = [];
        var currentSum = 0;
        var maxSum = 0;
        var minSum = 0;
        for (var i = 0; i < _inA.length; i++) {
            var max = Math.max(_inAMax[i], _inAMin[i]);
            var min = Math.min(_inAMax[i], _inAMin[i]);
            var v = _inA[i];
            inArray.push(v);
            inArrayMaxes.push(max);
            inArrayMinimums.push(min);
            currentSum += v;
            maxSum += max;
            minSum += min;
        }
        if (currentSum == minSum) {
            return inArray;
        }
        goalSum = Math.min(Math.max(goalSum, minSum), maxSum);
        var K = (goalSum - minSum) / (currentSum - minSum);
        var indexes;
        var rests = [];
        var outArray = [];
        var newCurrentSum = 0;
        for (var i = 0; i < inArray.length; i++) {
            var value = inArray[i];
            var min = inArrayMinimums[i];
            if (value == 0) {
                outArray.push(0);
                rests.push(0);
                continue;
            }
            var newValue = min + K * (value - min);
            var rest = (Math.round(newValue) - newValue) / value;
            if (Math.round(newValue) < 1) {
                rest = (1 - newValue) / value;
                newValue = 1;
            }
            newValue = Math.round(newValue);
            newCurrentSum += newValue;
            outArray.push(newValue);
            rests.push(rest);
        }
        if (newCurrentSum != goalSum) {
            var restIndex = 0;
            var infinityStop = outArray.length * Math.abs(newCurrentSum - goalSum);
            indexes = rests.map(function (v, i) { return i; });
            newCurrentSum > goalSum
                ? indexes.sort(function (i1, i2) { return rests[i2] - rests[i1]; })
                : indexes.sort(function (i1, i2) { return rests[i1] - rests[i2]; });
            while (newCurrentSum != goalSum && infinityStop--) {
                var index = indexes[restIndex];
                if (newCurrentSum > goalSum && outArray[index] > 1
                    && outArray[index] > inArrayMinimums[index]) {
                    outArray[index] -= 1;
                    newCurrentSum -= 1;
                }
                else if (newCurrentSum < goalSum && outArray[index] < inArrayMaxes[index] && outArray[index] > 0) {
                    outArray[index] += 1;
                    newCurrentSum += 1;
                }
                restIndex = (restIndex + 1) % rests.length;
            }
        }
        return outArray;
    };
    ArrayUtils.redistributePile = function (elementsCounter, pilesCounter, k) {
        if (!elementsCounter
            || !pilesCounter
            || !k) {
            throw new Error("redistributePile: wrong in parameters: ".concat(JSON.stringify([elementsCounter, pilesCounter, k])));
        }
        var out = [];
        var eCounter = Math.round(Math.abs(elementsCounter));
        var pCounter = Math.round(Math.abs(pilesCounter));
        var current_eCounter = eCounter;
        k = Math.abs(k);
        k = k < 1 ? k : 1 / k;
        pCounter = Math.min(pCounter, eCounter);
        for (var i = 0; i < pCounter; i++) {
            out.push(0);
        }
        var index = 0;
        while (current_eCounter > 0) {
            var elementsInPile = Math.ceil(current_eCounter * k);
            current_eCounter -= elementsInPile;
            out[index] += elementsInPile;
            index = (index + 1) % pCounter;
        }
        out.forEach(function (v, i, a) { if (!a[i])
            a[i] = 1; });
        var minAmounts = out.map(function () { return 1; });
        var currentSum = out.reduce(function (a, v) { return a + v; }, 0);
        if (eCounter < currentSum) {
            out = ArrayUtils.getArrayProportionalMinimized(eCounter, out, out, minAmounts);
        }
        return out;
    };
    ArrayUtils.unionWithoutRepeats = function () {
        var arrays = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            arrays[_i] = arguments[_i];
        }
        var result = [];
        for (var _a = 0, arrays_1 = arrays; _a < arrays_1.length; _a++) {
            var arr = arrays_1[_a];
            for (var _b = 0, arr_1 = arr; _b < arr_1.length; _b++) {
                var el = arr_1[_b];
                if (result.indexOf(el) == -1) {
                    result.push(el);
                }
            }
        }
        return result;
    };
    ArrayUtils.haveArraysSameElements = function (array1, array2) {
        for (var _i = 0, array1_1 = array1; _i < array1_1.length; _i++) {
            var id = array1_1[_i];
            if (array2.indexOf(id) > -1) {
                return true;
            }
        }
        return false;
    };
    ArrayUtils.getArraysIntersection = function (array1, array2) {
        var result = [];
        for (var _i = 0, array1_2 = array1; _i < array1_2.length; _i++) {
            var element = array1_2[_i];
            if (array2.indexOf(element) > -1) {
                result.push(element);
            }
        }
        return result;
    };
    ArrayUtils.getArraySubstraction = function (baseArray, remove) {
        var result = [];
        for (var _i = 0, baseArray_1 = baseArray; _i < baseArray_1.length; _i++) {
            var element = baseArray_1[_i];
            if (remove.indexOf(element) == -1) {
                result.push(element);
            }
        }
        return result;
    };
    ArrayUtils.getUniqueArray = function (array, toStrFunction) {
        if (toStrFunction === void 0) { toStrFunction = function (v) { return v.toString(); }; }
        var uniqObj = {};
        var result = [];
        if (array) {
            for (var _i = 0, array_1 = array; _i < array_1.length; _i++) {
                var v = array_1[_i];
                uniqObj[toStrFunction(v)] = v;
            }
        }
        for (var v in uniqObj) {
            result.push(uniqObj[v]);
        }
        return result;
    };
    ArrayUtils.createFilled = function (callable, size) {
        var result = [];
        for (var i = 0; i < size; i++) {
            result.push(callable());
        }
        return result;
    };
    ArrayUtils.find = function (array, predicate) {
        for (var i = 0; i < array.length; i++) {
            if (predicate(array[i])) {
                return array[i];
            }
        }
    };
    ArrayUtils.ensureArray = function (value) {
        return Array.isArray(value) ? value : [value];
    };
    return ArrayUtils;
}());
var BitMaskUtils = (function () {
    function BitMaskUtils() {
    }
    BitMaskUtils.getOrderNumbersFromInt = function (n, max) {
        if (max === void 0) { max = 32; }
        if (n === 0)
            return [];
        var result = [];
        var test = 1;
        for (var i = 0; i < max; i++) {
            if (n & test) {
                result.push(i);
            }
            n = n >>> 1;
        }
        return result;
    };
    BitMaskUtils.getIdsFromBitSetIntArray = function (bitSetIntArray, switchValueByIds) {
        var result = [];
        var switches = {};
        if (switchValueByIds) {
            switchValueByIds.forEach(function (id) { return switches[id] = true; });
        }
        for (var arrayIndex = 0; arrayIndex < bitSetIntArray.length; arrayIndex++) {
            var int32 = bitSetIntArray[arrayIndex];
            if (int32 == 0) {
                continue;
            }
            for (var bitIndex = 0; bitIndex < 32; bitIndex++) {
                var id = arrayIndex * 32 + bitIndex;
                var isIdSet = (int32 & (1 << bitIndex)) != 0;
                var doSwitchId = Boolean(switches[id]);
                if (+isIdSet ^ +doSwitchId) {
                    result.push(id);
                }
            }
        }
        return result;
    };
    return BitMaskUtils;
}());
var CommonUtils = (function () {
    function CommonUtils() {
    }
    CommonUtils.checkDateCentury = function (century, time) {
        var date = new Date(time);
        return Math.ceil(date.getUTCFullYear() / 100) == century;
    };
    CommonUtils.getTimeOfNearestUpdate = function (schedule, currentTime) {
        var origin = new Date(schedule.Origin);
        var originTime = origin.getTime();
        if (isNaN(originTime)) {
            throw new Error("GetTimeOfNearestUpdate: Check your origin "
                + "format 'YYYY-MM-ddTHH:mm:ss+HH:mm' of ".concat(schedule.Origin));
        }
        if (currentTime < originTime) {
            throw new Error("GetTimeOfNearestUpdate: currentTime < originTime == ".concat(currentTime, " < ").concat(originTime));
        }
        if (!schedule.Period || !(schedule.Period > 0)) {
            throw new Error("GetTimeOfNearestUpdate: no Period in schedule - ".concat(schedule));
        }
        var periods = ((currentTime - originTime) / schedule.Period) >> 0;
        return originTime + (periods + 1) * schedule.Period;
    };
    CommonUtils.roundNumber = function (num, decimalPlaces) {
        var order = Math.pow(10, decimalPlaces);
        return ((num * order) >> 0) / order;
    };
    CommonUtils.getPercentsFromProbability = function (probability, decimalPlaces) {
        return this.roundNumber(probability * 100, decimalPlaces);
    };
    CommonUtils.replaceReadOnlyProperty = function (obj, key, value) {
        if (obj && key != undefined) {
            obj[key] = value;
        }
    };
    CommonUtils.replaceSimple = function (origin, replaces) {
        var result = {};
        for (var key in origin)
            if (origin.hasOwnProperty(key)) {
                if (replaces[key] !== undefined) {
                    result[key] = replaces[key];
                }
                else {
                    result[key] = origin[key];
                }
            }
        return result;
    };
    CommonUtils.getNormalChances = function (chances, orderPrecision, gaolSum) {
        if (gaolSum === void 0) { gaolSum = 100; }
        var order = Math.pow(10, orderPrecision);
        var sum = gaolSum * order;
        var result = [];
        var sumChances = 0;
        var mines = [];
        var maxes = [];
        for (var _i = 0, chances_1 = chances; _i < chances_1.length; _i++) {
            var chance = chances_1[_i];
            var value = chance * order;
            result.push(value);
            sumChances += value;
            mines.push(1);
            maxes.push(sum);
        }
        var K = sum / sumChances;
        for (var i = 0; i < result.length; i++) {
            result[i] = Math.ceil(K * result[i]);
        }
        result = ArrayUtils.getArrayProportionalMinimized(sum, result, maxes, mines);
        for (var i = 0; i < result.length; i++) {
            result[i] = result[i] / order;
        }
        return result;
    };
    CommonUtils.getCorrectMinMax = function (value1, value2) {
        var min = Math.min(value1, value2);
        var max = Math.max(value1, value2);
        return [min, max];
    };
    CommonUtils.getRawValueDefault = function (obj, key, defaultValue) {
        if (defaultValue === void 0) { defaultValue = null; }
        return !obj || obj[key] == undefined ? defaultValue : obj[key];
    };
    CommonUtils.getRandomJSSeed = function () {
        return (Math.random() * 2147483647) >> 0;
    };
    CommonUtils.getStartEndByDays = function (start, days) {
        var result = [];
        for (var _i = 0, days_1 = days; _i < days_1.length; _i++) {
            var day = days_1[_i];
            var startDay = start + new Time({ Days: day - 1 }).value;
            var endDay = startDay + new Time({ Days: 1 }).value;
            result.push({ start: startDay, end: endDay });
        }
        return result;
    };
    CommonUtils.getStartEndByStartAndEnd = function (start, end) {
        var result = [];
        var dayPeriod = new Time({ Days: 1 }).value;
        var days = (end - start) / dayPeriod;
        for (var day = 0; day < days; day++) {
            var startDay = start + day * dayPeriod;
            var endDay = startDay + dayPeriod;
            result.push({ start: startDay, end: endDay });
        }
        return result;
    };
    CommonUtils.addObjectAndCheckReplace = function (map, key, value) {
        if (map[key] != undefined) {
            throw new Error("You replaced key ".concat(key.toString(), ". Please check creation of items"));
        }
        map[key] = value;
    };
    CommonUtils.getValueFromThresholdMap = function (map, thresholdValue) {
        var thresholdKeys = Object.keys(map)
            .map(function (threshold) { return +threshold; })
            .filter(function (threshold) { return !isNaN(threshold); })
            .sort(function (threshold1, threshold2) { return threshold1 - threshold2; });
        var maxKey = thresholdKeys[thresholdKeys.length - 1];
        if (maxKey != undefined && thresholdValue >= maxKey) {
            return map[maxKey];
        }
        var result;
        for (var _i = 0, thresholdKeys_1 = thresholdKeys; _i < thresholdKeys_1.length; _i++) {
            var thresholdKey = thresholdKeys_1[_i];
            if (thresholdKey > thresholdValue) {
                break;
            }
            result = map[thresholdKey];
        }
        if (!result) {
            throwDebugOrReturnDefault("getValueFromMap: in map ".concat(JSON.stringify(map), " no such value as ").concat(thresholdValue));
        }
        return result;
    };
    CommonUtils.getNumberWithStrictLength = function (num, length) {
        var result = num.toString();
        if (result.length > length) {
            throw new Error("getNumberWithStrictLength: cant create number with length ".concat(length, " from ").concat(num));
        }
        return new Array(length - result.length + 1).join('0') + result;
    };
    CommonUtils.getPeriodNumber = function (originTime, period, currentTime) {
        if (!originTime || !period || !currentTime || currentTime < originTime) {
            return undefined;
        }
        return ((currentTime - originTime) / period + 1) >> 0;
    };
    CommonUtils.getRelativeNumber = function (base, num) {
        if (typeof num == 'number')
            return num;
        if (num.indexOf("%") != -1) {
            num = parseFloat(num) / 100;
            return base * num;
        }
        return Number(num);
    };
    CommonUtils.hashCode = function (str) {
        var hash = 5381;
        var i = str.length;
        while (i) {
            hash = (hash * 33) ^ str.charCodeAt(--i);
        }
        return hash;
    };
    CommonUtils.positiveHashCode = function (str) {
        return CommonUtils.hashCode(str) >>> 0;
    };
    CommonUtils.roundToSplitDigit = function (x, digits) {
        var wholeDigits = Math.floor(digits);
        var splitDigit = digits - wholeDigits;
        var roundValue = Math.pow(10, Math.floor(Math.log(x) / Math.log(10)) - (wholeDigits - 1)) * splitDigit;
        return Math.round(x / roundValue) * roundValue;
    };
    CommonUtils.roundMathToSignificantDigits = function (x, digits, minRounding, roundFun) {
        if (roundFun === void 0) { roundFun = Math.round; }
        var roundValue = Math.max(minRounding, Math.pow(10, Math.max(0, Math.floor(Math.log(x) / Math.log(10)) - (digits - 1))));
        return roundFun(x / roundValue) * roundValue;
    };
    CommonUtils.getBooleanMapFromArray = function (array) {
        if (!array || array.length == 0) {
            return null;
        }
        var result = {};
        for (var _i = 0, array_2 = array; _i < array_2.length; _i++) {
            var el = array_2[_i];
            result[el] = true;
        }
        return result;
    };
    CommonUtils.clamp = function (value, min, max) {
        return Math.min(Math.max(value, min), max);
    };
    CommonUtils.setOnlyFilledValue = function (obj, objKey, value) {
        if (value) {
            var v = value;
            if (typeof v == "object") {
                if (Array.isArray(v)) {
                    if (v.length == 0) {
                        return;
                    }
                }
                else {
                    if (Object.keys(v).length == 0) {
                        return;
                    }
                }
            }
            obj[objKey] = value;
        }
    };
    CommonUtils.calculateFirstDayOfMonthWithOffset = function (startDate, offsetMonths) {
        var date = new Date(startDate);
        date.setMonth(date.getMonth() + offsetMonths, 1);
        return date.getTime();
    };
    CommonUtils.calculateLastDayOfMonthWithOffset = function (startDate, offsetMonths) {
        var date = new Date(startDate);
        date.setMonth(date.getMonth() + offsetMonths + 1, 1);
        return date.getTime() - new Time({ Days: 1 }).value;
    };
    CommonUtils.defaultNumberComparator = function (a, b, order) {
        if (order === void 0) { order = "ASC"; }
        return order == "ASC"
            ? +a - +b
            : +b - +a;
    };
    CommonUtils.compareVersions = function (a, b) {
        var aNumbers = a.split(".").map(function (v) { return isNumber(v) ? +v : 0; });
        var bNumbers = b.split(".").map(function (v) { return isNumber(v) ? +v : 0; });
        var maxSize = Math.max(aNumbers.length, bNumbers.length);
        for (var i = 0; i < maxSize; i++) {
            var aNumber = aNumbers[i] || 0;
            var bNumber = bNumbers[i] || 0;
            if (aNumber != bNumber) {
                return aNumber - bNumber;
            }
        }
        return 0;
    };
    return CommonUtils;
}());
function consoleLog() {
    var o = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        o[_i] = arguments[_i];
    }
    for (var _a = 0, o_1 = o; _a < o_1.length; _a++) {
        var v = o_1[_a];
        console.log(typeof v == 'object' || Array.isArray(v) ? JSON.stringify(v, null, "\t") : v);
    }
}
function extend(obj, src, reportConflicts) {
    if (reportConflicts === void 0) { reportConflicts = false; }
    for (var key in src) {
        if (reportConflicts && (key in obj)) {
            throw new Error("extend: key " + key + " present in both sources.");
        }
        if (src.hasOwnProperty(key))
            obj[key] = src[key];
    }
    return obj;
}
function deepCopyOverJSON(o) {
    try {
        return JSON.parse(JSON.stringify(o));
    }
    catch (e) {
        throw new Error("deepCopyOverJSON error: ".concat(e.message));
    }
}
function shuffle(list, rnd) {
    var size = list.length;
    for (var i = size; i > 1; i--)
        swap(list, i - 1, rnd.nextInt(i));
}
function swap(list, i, j) {
    var jElement = list[j];
    list[j] = list[i];
    list[i] = jElement;
}
function getValueByKeyDefault(js, key, defaultValue) {
    return js.hasOwnProperty(key) && js[key] != null && typeof js[key] != "undefined"
        ? js[key]
        : defaultValue;
}
function isNumber(value) {
    return !isNaN(parseFloat(value)) && isFinite(value);
}
function isInteger(value) {
    return isNumber(value) && Math.floor(value) === Number(value);
}
function isSafeInteger(value) {
    return isInteger(value) && Math.abs(value) <= MAX_SAFE_INTEGER;
}
function getObjectFromRaw(obj) {
    var result = {};
    if (obj) {
        for (var key in obj) {
            result[key] = obj[key];
        }
    }
    return result;
}
function getArrayFromRaw(array) {
    var jsArray = [];
    if (!array) {
        return jsArray;
    }
    if (array['length'] != undefined && Array.isArray(array)) {
        for (var _i = 0, array_3 = array; _i < array_3.length; _i++) {
            var i = array_3[_i];
            jsArray.push(i);
        }
    }
    else {
        for (var i in array)
            if (isNumber(i)) {
                jsArray.push(array[i]);
            }
    }
    return jsArray;
}
function throwDebugOrReturnDefault(log, defaultValue) {
    if (useDebugOverException) {
        throw new Error(log);
    }
    return defaultValue == null ? null : defaultValue;
}
