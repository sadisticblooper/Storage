var Time = (function () {
    function Time(js) {
        this.value = 0;
        var timeValues = {
            Days: 86400000,
            Hours: 3600000,
            Minutes: 60000,
            Seconds: 1000,
        };
        for (var key in js)
            if (js.hasOwnProperty(key) && timeValues.hasOwnProperty(key)) {
                this.value += timeValues[key] * js[key];
            }
    }
    Time.convertEuropeanDateToTimestampMs = function (europeanDate) {
        var match = europeanDate.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2}|\d{4})$/);
        if (!match) {
            throw new Error("convertEuropeanDateToTimestampMs: wrong date format \"".concat(europeanDate, "\", expected \"D.M.YY\" or \"DD.MM.YYYY\""));
        }
        var dayStr = match[1], monthStr = match[2], yearStrRaw = match[3];
        var yearStr = yearStrRaw.length === 2 ? "20".concat(yearStrRaw) : yearStrRaw;
        var day = parseInt(dayStr, 10);
        var month = parseInt(monthStr, 10);
        var year = parseInt(yearStr, 10);
        return new Date(year, month - 1, day).getTime();
    };
    return Time;
}());
