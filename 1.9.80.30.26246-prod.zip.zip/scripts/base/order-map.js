var OrderMap = (function () {
    function OrderMap(name) {
        if (name === void 0) { name = ""; }
        this.name = name;
        this.keys = [];
        this.values = {};
    }
    OrderMap.prototype.get = function (k) {
        return this.values[k];
    };
    OrderMap.prototype.checkedGet = function (k) {
        var result = this.values[k];
        if (!result)
            throw new Error("OrderMap checkedGet: map " + this.name + " does not contain ID " + k);
        return result;
    };
    OrderMap.prototype.put = function (k, v) {
        if (!isNumber(k)) {
            throw new Error("OrderMap put: k '".concat(k, "' is not a number for map ").concat(this.name));
        }
        k = +k;
        var result = this.get(k);
        if (!result) {
            this.keys.push(k);
        }
        this.values[k] = v;
        return result;
    };
    OrderMap.prototype.getKeys = function () {
        return this.keys;
    };
    OrderMap.prototype.getValues = function () {
        return this.values;
    };
    return OrderMap;
}());
function createIDMap(map, mapName) {
    if (mapName === void 0) { mapName = "unnamed"; }
    var sortable = [];
    var nameKey = "Name";
    var idKey = "ID";
    for (var key in map) {
        if (map.hasOwnProperty(key)) {
            var value = map[key];
            if (value[nameKey] == undefined) {
                value[nameKey] = key;
            }
            var id = value[idKey];
            if (id == undefined) {
                throw new Error("createIDMap ".concat(mapName, ": no ID for ").concat(key));
            }
            sortable.push([id, value]);
        }
    }
    sortable.sort(function (a, b) {
        return a[0] - b[0];
    });
    var resultMap = new OrderMap(mapName);
    for (var _i = 0, sortable_1 = sortable; _i < sortable_1.length; _i++) {
        var pair = sortable_1[_i];
        var id = pair[0], obj = pair[1];
        var existedObj = resultMap.put(id, obj);
        if (existedObj) {
            throw new Error("createIDMap ".concat(mapName, ": ").concat(obj[nameKey], " and ").concat(existedObj[nameKey], " has the same ID ").concat(id));
        }
    }
    return resultMap;
}
