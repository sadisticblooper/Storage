var SkipZeroPossibilityGroupOnDevelopEnvironment = true;
var ABTests = [];
var ABUtils = (function () {
    function ABUtils() {
    }
    ABUtils.checkTestsSum = function (abTests) {
        var partSum = 0;
        var countriesPartSum = {};
        for (var _i = 0, abTests_1 = abTests; _i < abTests_1.length; _i++) {
            var test_1 = abTests_1[_i];
            if (!test_1.Countries) {
                partSum += test_1.Part;
                if (partSum > 1) {
                    throw "AB error: parts sum more than 1 in test " + test_1.Tag;
                }
            }
            else {
                for (var _a = 0, _b = test_1.Countries; _a < _b.length; _a++) {
                    var region = _b[_a];
                    if (countriesPartSum[region] == undefined) {
                        countriesPartSum[region] = 0;
                    }
                    countriesPartSum[region] += test_1.Part;
                    if (countriesPartSum[region] > 1) {
                        throw "AB error: parts sum [country] more than 1 in " + region + " region for test " + test_1.Tag;
                    }
                }
            }
        }
        for (var region in countriesPartSum) {
            if (countriesPartSum[region] + partSum > 1) {
                throw "AB error: parts sum [full] more than 1 in " + region + " region";
            }
        }
    };
    ABUtils.getTestsTagMap = function (abTests) {
        var testsTagMap = {};
        for (var _i = 0, abTests_2 = abTests; _i < abTests_2.length; _i++) {
            var group = abTests_2[_i];
            testsTagMap[group.Tag] = group;
        }
        return testsTagMap;
    };
    ABUtils.setPathInTestGroupsOfMap = function (abTestsMap) {
        for (var tag in abTestsMap) {
            if (abTestsMap.hasOwnProperty(tag)) {
                var group = abTestsMap[tag];
                group.Path = "scripts/ab/" + group.Tag;
            }
        }
    };
    ABUtils.chooseABTag = function (settings) {
        var deviceId = settings.deviceId;
        var rnd = new PcgRandom(1);
        rnd.setSeed(CommonUtils.positiveHashCode(deviceId) % rnd.MAX_INTEGER());
        return ABUtils.getRandomTag(settings, rnd);
    };
    ABUtils.updateABTag = function (settings) {
        var playerABTag = settings.playerABTag;
        var playerGroup = ABTestsMap[playerABTag];
        if (playerGroup != undefined && ABUtils.isGroupAllowed(playerGroup, settings, false)) {
            return playerABTag;
        }
        var rnd = new PcgRandom(CommonUtils.getRandomJSSeed());
        return ABUtils.getRandomTag(settings, rnd, true);
    };
    ABUtils.getABTagList = function (developEnvironment) {
        var abTestsMap = ABTestsMap;
        var keyList = [];
        for (var key in abTestsMap) {
            if (abTestsMap.hasOwnProperty(key)) {
                if (abTestsMap[key].Part <= 0 && SkipZeroPossibilityGroupOnDevelopEnvironment && developEnvironment) {
                    continue;
                }
                keyList.push(key);
            }
        }
        return keyList;
    };
    ABUtils.getPathByABTag = function (tag) {
        var abTestsMap = ABTestsMap;
        if (abTestsMap.hasOwnProperty(tag)) {
            return abTestsMap[tag].Path;
        }
        else {
            throw "No group with tag " + tag;
        }
    };
    ABUtils.getRandomTag = function (settings, rnd, updateTag) {
        if (updateTag === void 0) { updateTag = false; }
        var abTests = ABTests;
        var partSum = 0;
        var randChoice = rnd.nextDouble();
        var tag = null;
        for (var _i = 0, abTests_3 = abTests; _i < abTests_3.length; _i++) {
            var group = abTests_3[_i];
            if (!ABUtils.isGroupAllowed(group, settings, updateTag)) {
                continue;
            }
            partSum += group.Part;
            if (partSum > randChoice) {
                tag = group.Tag;
                break;
            }
        }
        return tag;
    };
    ABUtils.isGroupAllowed = function (group, playerSettings, updateTag) {
        var countryCode = playerSettings.countryCode, campaign = playerSettings.campaign;
        var platform = isNumber(playerSettings.platform) ? +playerSettings.platform : PLATFORM.NONE;
        if (updateTag && !group.AllowForOldPlayers) {
            return false;
        }
        if (group.Countries && group.Countries.indexOf(countryCode) == -1) {
            return false;
        }
        if (group.Platforms && group.Platforms.indexOf(platform) == -1) {
            return false;
        }
        if (campaign != undefined && campaign.length > 0 && !group.AllowForPlayersWithCampaign) {
            return false;
        }
        return true;
    };
    return ABUtils;
}());
var ABTestsMap = ABUtils.getTestsTagMap(ABTests);
ABUtils.setPathInTestGroupsOfMap(ABTestsMap);
function chooseABTag(settings) {
    return ABUtils.chooseABTag(settings);
}
function updateABTag(settings) {
    return ABUtils.updateABTag(settings);
}
function getABTagList(developEnvironment) {
    if (developEnvironment === void 0) { developEnvironment = false; }
    return ABUtils.getABTagList(developEnvironment);
}
function hasABTag(tag) {
    return ABTestsMap.hasOwnProperty(tag);
}
function getPathByABTag(tag) {
    return ABUtils.getPathByABTag(tag);
}
