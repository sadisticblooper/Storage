var PlayerState = (function () {
    function PlayerState() {
    }
    PlayerState.setPlayerProgress = function (p) {
        PlayerState.cashedState = PlayerState.getCorrectProgress(p);
        return true;
    };
    PlayerState.getCorrectFromRawOrCache = function (p, partial) {
        if (partial != null) {
            for (var propertyName in partial) {
                if (partial[propertyName] == null) {
                    continue;
                }
                if (p == null) {
                    p = {};
                }
                p[propertyName] = partial[propertyName];
            }
        }
        if (PlayerState.cashedState != undefined && p == undefined) {
            return deepCopyOverJSON(PlayerState.cashedState);
        }
        else if (PlayerState.cashedState == undefined && p != undefined) {
            return deepCopyOverJSON(PlayerState.getCorrectProgress(p));
        }
        var result = {
            accountLevel: 0, accountExp: 0, playerArenaId: 0, maxPlayerArenaId: 0, playerRating: 0,
            maxPlayerRating: 0, heroes: {}, heroShards: {},
            emoji: [], skins: [], stances: [], taunts: [], weapons: [], textEmojiPacks: [], currencies: {},
            lastSeasonRating: 0, tutorialPassed: false, modifiers: {}, customizationShards: {}
        };
        for (var propertyName in result) {
            result[propertyName] = PlayerState.getProgressValueOrThrowError(p, PlayerState.cashedState, propertyName);
        }
        return deepCopyOverJSON(PlayerState.getCorrectProgress(result));
    };
    PlayerState.getCorrectProgress = function (p) {
        var accountLevel = +CommonUtils.getRawValueDefault(p, "accountLevel", 1);
        var heroes = CommonUtils.getRawValueDefault(p, "heroes", {});
        var modifiers = CommonUtils.getRawValueDefault(p, "modifiers", {});
        var heroShards = CommonUtils.getRawValueDefault(p, "heroShards", {});
        var arena = +CommonUtils.getRawValueDefault(p, "playerArenaId", 1);
        var rating = +CommonUtils.getRawValueDefault(p, "playerRating", 1);
        var _a = HeroUtils.getHeroesInfoFromRaw({
            HeroesInfo: heroes,
            ShardsInfo: heroShards,
        }), HeroesInfo = _a.HeroesInfo, ShardsInfo = _a.ShardsInfo;
        var skins = (p && p.skins ? getArrayFromRaw(p.skins) : []).concat(Skin.DefaultSkins);
        var stances = (p && p.stances ? getArrayFromRaw(p.stances) : []).concat(Stance.DefaultStances);
        var taunts = (p && p.taunts ? getArrayFromRaw(p.taunts) : []).concat(Taunt.DefaultTaunts);
        var weapons = (p && p.weapons ? getArrayFromRaw(p.weapons) : []).concat(HeroWeapon.DefaultWeapons);
        var emotes = (p && p.emoji ? getArrayFromRaw(p.emoji) : []).concat(Emoji.DefaultEmoji);
        var textEmojiPacks = (p && p.textEmojiPacks ? getArrayFromRaw(p.textEmojiPacks) : []).concat(TextEmojiPack.DefaultTextEmojiPacks);
        var customizationShards = CommonUtils.getRawValueDefault(p, "customizationShards", {});
        for (var _i = 0, skins_1 = skins; _i < skins_1.length; _i++) {
            var id = skins_1[_i];
            var skin = skinsMap.checkedGet(id);
            if (weapons.indexOf(skin.WeaponId) == -1) {
                weapons.push(skin.WeaponId);
            }
        }
        return {
            accountLevel: accountLevel,
            accountExp: +CommonUtils.getRawValueDefault(p, "accountExp", 0),
            playerArenaId: arena,
            maxPlayerArenaId: +CommonUtils.getRawValueDefault(p, "maxPlayerArenaId", arena),
            playerRating: rating,
            maxPlayerRating: +CommonUtils.getRawValueDefault(p, "maxPlayerRating", rating),
            lastSeasonRating: +CommonUtils.getRawValueDefault(p, "lastSeasonRating", 0),
            currencies: p && p.currencies ? getObjectFromRaw(p.currencies) : {},
            heroes: HeroesInfo,
            heroShards: ShardsInfo,
            modifiers: modifiers,
            skins: skins,
            taunts: taunts,
            emoji: emotes,
            stances: stances,
            weapons: weapons,
            textEmojiPacks: textEmojiPacks,
            tutorialPassed: !!(p && p.tutorialPassed),
            customizationShards: customizationShards,
        };
    };
    PlayerState.getProgressValueOrThrowError = function (fromRequest, fromCache, name) {
        if (fromRequest == null && fromCache == null) {
            throw new Error("Can not create playerProgress. Request params and cache are empty!");
        }
        if (fromRequest && fromRequest[name] != undefined) {
            return fromRequest[name];
        }
        else if (fromCache && fromCache[name] != undefined) {
            return fromCache[name];
        }
        throw new Error("Can not read property ".concat(name, " for playerProgress. \n            \r").concat(JSON.stringify([fromRequest, fromCache])));
    };
    return PlayerState;
}());
