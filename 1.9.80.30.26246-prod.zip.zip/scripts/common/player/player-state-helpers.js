var PlayerStateHelpers = (function () {
    function PlayerStateHelpers() {
    }
    PlayerStateHelpers.tryGetCustomizationShards = function (playerProgress, compositeId) {
        var collections = playerProgress.customizationShards;
        if (!collections)
            return 0;
        var content = collections[compositeId];
        return +content || 0;
    };
    return PlayerStateHelpers;
}());
