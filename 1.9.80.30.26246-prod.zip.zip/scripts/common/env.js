var CURRENT_BUILD_TYPE = BUILD_TYPE.GLOBAL;
function getGlobalOrChina(whenGlobal, whenChina) {
    return CURRENT_BUILD_TYPE === BUILD_TYPE.CHINA
        ? whenChina
        : whenGlobal;
}
