var icons = {
    event_april: {
        ID: 0,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_APRIL",
        color: "#FFD75E"
    },
    event_april_white: {
        ID: 1,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_APRIL",
        color: "#FFFFFF"
    },
    event_summer: {
        ID: 2,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_MIDSOMMAR",
        color: "#FFDD75"
    },
    event_summer_white: {
        ID: 3,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_SUMMER",
        color: "#FFB647"
    },
    event_viper_stuff: {
        ID: 4,
        icon: "Sprites/Assets/Challenges/Icons/icon_VIPER",
        color: "#FFD147"
    },
    event_butcher: {
        ID: 5,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_BUTCHER",
        color: "#E64049"
    },
    event_halloween: {
        ID: 6,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_HALLOWEEN",
        color: "#ff8f5e"
    },
    event_itu: {
        ID: 7,
        icon: "Sprites/Assets/Challenges/Icons/icon_ITU",
        color: "#47ffff"
    },
    event_NY2023: {
        ID: 8,
        icon: "Sprites/Assets/Challenges/Icons/icon_NEW_YEAR",
        color: "#ff5e5e"
    },
    event_MNY2023: {
        ID: 9,
        icon: "Sprites/Assets/Challenges/Icons/icon_VIPER",
        color: "#ffd75e"
    },
    event_yunlin: {
        ID: 10,
        icon: "Sprites/Assets/Challenges/Icons/icon_YUNLIN",
        color: "#e5a8df"
    },
    event_sakura: {
        ID: 11,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_SAKURA",
        color: "#ff8caf"
    },
    event_vampires: {
        ID: 12,
        icon: "Sprites/Assets/Challenges/Icons/icon_NEWVAMPIRES",
        color: "#E64049"
    },
    event_midsummer: {
        ID: 13,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_MIDSOMMAR",
        color: "#FFDD75"
    },
    cross_promo: {
        ID: 14,
        icon: "Sprites/PreviewImages/AdvertisingSF3/icon_Arena",
        color: "#5eb7ff"
    },
    event_xiangTzu: {
        ID: 15,
        icon: "Sprites/Assets/Challenges/Icons/icon_XIANG_TZU",
        color: "#ff5e1a"
    },
    roulette_universal: {
        ID: 16,
        icon: "Sprites/Assets/Challenges/Icons/icon_LUCKYBOARD",
        color: "#FFBF5E"
    },
    event_autumn: {
        ID: 17,
        icon: "Sprites/Assets/Challenges/Icons/icon_LEAFS",
        color: "#ffac30"
    },
    heroes_sale: {
        ID: 18,
        icon: "Sprites/Assets/Icons/icon_SALE_base",
        color: "#266754"
    },
    icon_ad: {
        ID: 19,
        icon: "Sprites/Assets/Challenges/Icons/icon_AD",
        color: "#61e540"
    },
    icon_arena_textured: {
        ID: 20,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_TEXTURED",
        color: "#ff4747"
    },
    icon_arena_textured_blue: {
        ID: 21,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_TEXTURED",
        color: "#5eb7ff"
    },
    event_ny2023: {
        ID: 22,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_STARLIGHT",
        color: "#bac1ff"
    },
    event_community2024: {
        ID: 23,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_COMMUNITY",
        color: "#d1bce6"
    },
    icon_arena_textured_vinous: {
        ID: 24,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_TEXTURED",
        color: "#730B0BB8"
    },
    icon_legendary_lynx_popup: {
        ID: 25,
        icon: "Sprites/Assets/PVE/BuffsIcon/HeroesIconPVE/icon_Lynx_buff",
        color: "#e6352c"
    },
    icon_gideon: {
        ID: 26,
        icon: "Sprites/Assets/Challenges/Icons/icon_GIDEON",
        color: "#5fcfcf"
    },
    icon_spine: {
        ID: 27,
        icon: "Sprites/PreviewImages/Advertising/AdvertisingSPINE/icon_SPINE",
        color: "#b3ff5c"
    },
    icon_leg_heroes: {
        ID: 28,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_LegHeroes",
        color: "#d1bce6"
    },
    icon_legion_king: {
        ID: 29,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_LEGIONKING",
        color: "#e6c155"
    },
    icon_arena_light_brown: {
        ID: 30,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_TEXTURED",
        color: "#e6c493"
    },
    icon_birthday_4: {
        ID: 31,
        icon: "Sprites/Assets/Challenges/Icons/icon_BIRTHDAY_4",
        color: "#FF9D8C"
    },
    icon_widow: {
        ID: 32,
        icon: "Sprites/Assets/Challenges/Icons/icon_WIDOW",
        color: "#e62c2c"
    },
    icon_leg_skin_itu: {
        ID: 33,
        icon: "Sprites/Assets/Challenges/Icons/icon_ITU",
        color: "#ffe3ba"
    },
    icon_valentine: {
        ID: 34,
        icon: "Sprites/Assets/Challenges/Icons/icon_VALENTINE",
        color: "#ffa3cd"
    },
    icon_collecting_email: {
        ID: 35,
        icon: "Sprites/Assets/Icons/icon_MAIL_2",
        color: "#5effcf"
    },
    icon_ninja_party: {
        ID: 36,
        icon: "Sprites/PreviewImages/Advertising/AdvertisingNP/icon_NINJA_PARTY",
        color: "#ffffff"
    },
    icon_holi: {
        ID: 37,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_HOLI",
        color: "#ff477e"
    },
    icon_arena_detailed: {
        ID: 38,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_DETAILED",
        color: "#ffd147"
    },
    icon_legendary_lk: {
        ID: 39,
        icon: "Sprites/Assets/Challenges/Icons/icon_EVENT_LEGIONKING",
        color: "#a3c8ff"
    },
    icon_RAIKICHI: {
        ID: 40,
        icon: "Sprites/Assets/Challenges/Icons/icon_RAIKICHI",
        color: "#a3acff"
    },
    icon_monkey_king: {
        ID: 41,
        icon: "Sprites/Assets/Challenges/Icons/icon_MONKEYKING",
        color: "#d1bce6"
    },
    icon_nekki_fest: {
        ID: 42,
        icon: "Sprites/PreviewImages/Events/NekkiFest/icon_NEKKI",
        color: "#ff8d30"
    },
    icon_legendary_kibo: {
        ID: 43,
        icon: "Sprites/Assets/Challenges/Icons/icon_KIBO",
        color: "#e6b46a"
    },
    icon_arena_violet: {
        ID: 44,
        icon: "Sprites/Assets/Challenges/Icons/icon_ARENA_TEXTURED",
        color: "#a393e6"
    },
    icon_diwali: {
        ID: 45,
        icon: "Sprites/PreviewImages/Events/Diwali/icon_DIWALI",
        color: "#ffac30"
    },
    icon_nonna: {
        ID: 46,
        icon: "Sprites/Assets/Challenges/Icons/icon_NONNA",
        color: "#e67f2c"
    },
    icon_nonna_light: {
        ID: 47,
        icon: "Sprites/Assets/Challenges/Icons/icon_NONNA",
        color: "#ff9a47"
    },
    icon_monkey_king_yellow: {
        ID: 48,
        icon: "Sprites/Assets/Challenges/Icons/icon_MONKEYKING",
        color: "#e6c155"
    },
    event_MNY2026: {
        ID: 49,
        icon: "Sprites/PreviewImages/Events/MoonNewYearEvent/icon_EVENT_NY_CHINA_2026",
        color: "#ffd75e"
    },
    event_legendary_weapon: {
        ID: 50,
        icon: "Sprites/PreviewImages/Events/ButcherWeapon/icon_LEGENDARY_WEAPON",
        color: "#5ee7ff"
    },
    event_earth_day: {
        ID: 51,
        icon: "Sprites/PreviewImages/Events/EarthDay/icon_EVENT_EARTH_DAY",
        color: "#5eff6e"
    },
    event_bamboo: {
        ID: 52,
        icon: "Sprites/PreviewImages/Events/Bamboo/icon_BAMBOO",
        color: "#c7cf3a"
    },
    event_ironclad_l_bull: {
        ID: 53,
        icon: "Sprites/PreviewImages/Events/Ironclad_L_Bull/popup_icon_ironclad_l_bull",
        color: "#ffe8a3"
    },
    event_shogun: {
        ID: 54,
        icon: "Sprites/Assets/Challenges/Icons/icon_SHOGUN",
        color: "#ff4f30"
    },
};
var iconsMap = createIDMap(icons, "iconMap");
