var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var CommonGameUtils = (function () {
    function CommonGameUtils() {
    }
    CommonGameUtils.findMinimumFromWeights = function (weights) {
        if (!weights || weights.length < 1)
            return 0;
        var result = weights[0].N;
        for (var _i = 0, weights_1 = weights; _i < weights_1.length; _i++) {
            var element = weights_1[_i];
            result = Math.min(result, element.N);
        }
        return result;
    };
    CommonGameUtils.findChanceFromWeights = function (weights) {
        if (!weights || weights.length < 1) {
            return 0;
        }
        var nonZeroSum = 0;
        var totalSum = 0;
        for (var _i = 0, weights_2 = weights; _i < weights_2.length; _i++) {
            var element = weights_2[_i];
            var amount = element.N;
            var weight = element.W;
            if (amount) {
                nonZeroSum += weight;
            }
            totalSum += weight;
        }
        return totalSum ? nonZeroSum / totalSum : 0;
    };
    CommonGameUtils.getNumberIntervalIndex = function (rangeValue, intervalArray) {
        if (!Array.isArray(intervalArray) || intervalArray.length < 1) {
            throw new Error("getIntervalIndex ERROR! intervalArray is not array: " + JSON.stringify(intervalArray));
        }
        intervalArray.sort(function (a, b) { return a.range.start - b.range.start; });
        var index = 0;
        for (var i = 0; i < intervalArray.length; i++) {
            var range = intervalArray[i].range;
            if (rangeValue >= range.start && rangeValue <= range.end) {
                return i;
            }
            if (rangeValue >= range.start) {
                index = i;
            }
        }
        return index;
    };
    CommonGameUtils.getNumberIntervalIndexes = function (rating, intervalArray) {
        if (!Array.isArray(intervalArray)) {
            throw new Error("getRatingIntervalIndexes ERROR! intervalArray is not array: " + JSON.stringify(intervalArray));
        }
        var result = [];
        for (var i = 0; i < intervalArray.length; i++) {
            var interval = intervalArray[i];
            if (interval.range == undefined || interval.range.start == undefined || interval.range.end == undefined) {
                throw new Error("getRatingIntervalIndexes ERROR! interval is not expected structure: "
                    + JSON.stringify([i, interval]));
            }
            if (rating >= interval.range.start && rating <= interval.range.end
                || rating >= interval.range.end && rating <= interval.range.start) {
                result.push(i);
            }
        }
        return result;
    };
    CommonGameUtils.getAllGameModules = function (exclude) {
        if (exclude === void 0) { exclude = []; }
        var result = [];
        for (var name_1 in GAME_MODULE) {
            if (isNumber(GAME_MODULE[name_1])) {
                if (exclude.indexOf(+GAME_MODULE[name_1]) > -1) {
                    continue;
                }
                result.push(Number(GAME_MODULE[name_1]));
            }
        }
        return result;
    };
    CommonGameUtils.getSkVars = function (vars) {
        var keys = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            keys[_i - 1] = arguments[_i];
        }
        var errors = [];
        for (var _a = 0, keys_1 = keys; _a < keys_1.length; _a++) {
            var key = keys_1[_a];
            if (vars[key] === undefined) {
                errors.push(key);
            }
        }
        if (errors.length > 0) {
            throw new Error("getSkVars: vars ".concat(errors.join(", "), " not found"));
        }
        return vars;
    };
    CommonGameUtils.getModuleCurrencies = function (settings) {
        var module = settings.module, moduleArg = settings.moduleArg, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS, seasonalEventID = settings.seasonalEventID;
        var seasonalEvent = seasonalEventsMap.get(seasonalEventID);
        var result = {
            currenciesToShow: [],
            currencyNotificationsToShow: [],
            nextUpdateTime: null
        };
        var updateNextTime = function (currSettings) {
            var _a;
            var dates = (_a = currSettings.pseudoCurrencySettings) === null || _a === void 0 ? void 0 : _a.datesSettings;
            var next = null;
            if (dates) {
                if (startTimeOfCurrentDayMS < dates.startDate) {
                    next = dates.startDate;
                }
                else if (startTimeOfCurrentDayMS < dates.expireDate) {
                    next = dates.expireDate;
                }
            }
            if (seasonalEvent && currSettings.isEventCurrency) {
                if (startTimeOfCurrentDayMS < seasonalEvent.endTime) {
                    if (next == null || seasonalEvent.endTime < next) {
                        next = seasonalEvent.endTime;
                    }
                }
            }
            if (next != null) {
                if (result.nextUpdateTime == null || next < result.nextUpdateTime) {
                    result.nextUpdateTime = next;
                }
            }
        };
        var pushCurrenciesWithNextTime = function (ids, target, updateNextTime) {
            for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                var id = ids_1[_i];
                if (skipCurrency(id)) {
                    continue;
                }
                target.push(id);
                var currSettings = currencySettings[id];
                if (currSettings) {
                    updateNextTime(currSettings, id);
                }
            }
        };
        var skipCurrency = function (currencyId) {
            var eventCurrency = currencySettings[currencyId].isEventCurrency;
            if (!eventCurrency)
                return false;
            if (!seasonalEvent)
                return true;
            var hasInCurrentEvent = seasonalEvent.eventCurrencies.indexOf(currencyId) > -1;
            if (!hasInCurrentEvent)
                return true;
            return startTimeOfCurrentDayMS > seasonalEvent.endTime;
        };
        var resetToDefault = function (result) {
            result.currenciesToShow = __spreadArray([], CurrencyConstants.DefaultCurrencies, true);
            result.currencyNotificationsToShow = [];
            result.nextUpdateTime = null;
        };
        if (moduleArg) {
            var orderMap = itemsToShowCurrenciesInGameModule[module];
            if (orderMap) {
                var item = orderMap.get(moduleArg);
                if (item && item.showInModuleSettings) {
                    resetToDefault(result);
                    pushCurrenciesWithNextTime(item.showInModuleSettings.currenciesToShow, result.currenciesToShow, updateNextTime);
                    pushCurrenciesWithNextTime(item.showInModuleSettings.currencyNotificationsToShow, result.currencyNotificationsToShow, updateNextTime);
                    return result;
                }
            }
        }
        for (var curr in currencySettings) {
            var currencyId = +curr;
            var currSettings = currencySettings[curr];
            if (skipCurrency(currencyId)) {
                continue;
            }
            if (currSettings.showInModules.indexOf(module) > -1) {
                result.currenciesToShow.push(currencyId);
                updateNextTime(currSettings);
            }
            if (currSettings.showNotificationsInModules.indexOf(module) > -1) {
                result.currencyNotificationsToShow.push(currencyId);
                updateNextTime(currSettings);
            }
        }
        result.currenciesToShow = ArrayUtils.getUniqueArray(result.currenciesToShow);
        return result;
    };
    return CommonGameUtils;
}());
