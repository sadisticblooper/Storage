function logMessageOverEnvironment(message) {
    if (typeof message == "string") {
        if (clientLoggerCallbackApi) {
            clientLoggerCallbackApi.log(message);
        }
    }
}
var ClientLogger = (function () {
    function ClientLogger() {
    }
    ClientLogger.prototype.log = function (log) {
        clientLog(log);
        this.flush();
    };
    ClientLogger.prototype.flush = function () {
        clientFlush();
    };
    return ClientLogger;
}());
var JsLogger = (function () {
    function JsLogger() {
    }
    JsLogger.prototype.log = function (log) {
        console.log(log);
    };
    JsLogger.prototype.flush = function () { };
    return JsLogger;
}());
var clientLog = function (log) { };
var clientFlush = function () { };
var clientLoggerCallbackApi;
var ClientLoggerCallbackApiImplEnum = {
    JS: "nodejs",
    SERVER: "server",
    CLIENT: "client"
};
