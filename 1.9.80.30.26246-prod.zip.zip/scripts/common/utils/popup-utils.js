var CommonPopUpUtils = (function () {
    function CommonPopUpUtils() {
    }
    CommonPopUpUtils.getActivityPopupId = function (commonId, subId) {
        return commonId + CommonUtils.getNumberWithStrictLength(subId, 2);
    };
    CommonPopUpUtils.setActivityPopupsOverMap = function (map, popups) {
        for (var _i = 0, popups_1 = popups; _i < popups_1.length; _i++) {
            var popup = popups_1[_i];
            var commonId = popup.data.ID;
            for (var subId = 0; subId < popup.data.activeTime.length; subId++) {
                var id = CommonPopUpUtils.getActivityPopupId(commonId, subId);
                if (CustomPopUpConditions.isIdForPopUp(+id)) {
                    throw new Error("CommonPopUpUtils.setActivityPopupsOverMap: you use common popup with daily id."
                        + "Change id for ".concat(commonId));
                }
                if (map[id] != undefined) {
                    throw new Error("CommonPopUpUtils.setActivityPopupsOverMap: repeated id ".concat(id, ". ")
                        + "Seed popup with id ".concat(commonId));
                }
                map[id] = popup;
            }
        }
        return popups;
    };
    CommonPopUpUtils.breakPopUpForCareGame = function (data, isCareGameBuild) {
        if (!isCareGameBuild) {
            return false;
        }
        return Boolean(data && data.navigation == POPUP_NAVIGATION.URL);
    };
    return CommonPopUpUtils;
}());
