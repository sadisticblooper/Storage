var CensorshipUtils = (function () {
    function CensorshipUtils() {
    }
    CensorshipUtils.stripZeroWidth = function (s) {
        for (var i = 0; i < s.length; i++) {
            if (this.ZERO_WIDTH_POINTS[s[i]]) {
                var out = "";
                for (var j = 0; j < s.length; j++) {
                    var ch = s[j];
                    if (!this.ZERO_WIDTH_POINTS[ch])
                        out += ch;
                }
                return out;
            }
        }
        return s;
    };
    CensorshipUtils.segmentString = function (input) {
        var arr = [];
        for (var i = 0; i < input.length; i++) {
            arr.push(input.charAt(i));
        }
        return arr;
    };
    CensorshipUtils.applyConfusables = function (point, map) {
        if (point.length > 1) {
            var out = "";
            for (var i = 0; i < point.length; i++) {
                var ch = point.charAt(i);
                out += (map[ch] !== undefined ? map[ch] : ch);
            }
            return out;
        }
        return map[point] !== undefined ? map[point] : point;
    };
    CensorshipUtils.makeSkeleton = function (segments, map) {
        var out = new Array(segments.length);
        for (var i = 0; i < segments.length; i++) {
            var point = segments[i];
            point = this.normalizeNFKC(point);
            point = this.stripZeroWidth(point);
            out[i] = this.applyConfusables(point, map);
        }
        return out;
    };
    CensorshipUtils.isConfusing = function (input, map) {
        if (map === void 0) { map = Confusables.Map; }
        var segments = this.segmentString(input);
        var skeleton = this.makeSkeleton(segments, map);
        for (var i = 0; i < skeleton.length; i++) {
            if (skeleton[i] !== segments[i])
                return true;
        }
        return false;
    };
    CensorshipUtils.confusables = function (input, map) {
        if (map === void 0) { map = Confusables.Map; }
        var segments = this.segmentString(input);
        var skeleton = this.makeSkeleton(segments, map);
        var res = [];
        var offset = 0;
        for (var i = 0; i < segments.length; i++) {
            var point = segments[i];
            var target = skeleton[i - offset];
            if (point.length == 1 && this.ZERO_WIDTH_POINTS[point]) {
                res.push({ point: point, similarTo: this.ZERO_WIDTH });
                offset += 1;
                continue;
            }
            if (!target || target == point) {
                res.push({ point: point });
            }
            else {
                res.push({ point: point, similarTo: target });
            }
        }
        return res;
    };
    CensorshipUtils.makeSkeletonString = function (input, map) {
        if (map === void 0) { map = Confusables.Map; }
        var segments = this.segmentString(input);
        var skeleton = this.makeSkeleton(segments, map);
        return skeleton.join("");
    };
    CensorshipUtils.isIgnorableSkeletonDiff = function (a, b) {
        var groupIL1 = { "I": true, "L": true, "l": true, "1": true, "|": true };
        for (var i = 0; i < a.length && i < b.length; i++) {
            var ca = a.charAt(i);
            var cb = b.charAt(i);
            if (ca == cb)
                continue;
            if (groupIL1[ca] && groupIL1[cb])
                continue;
            return false;
        }
        return a.length == b.length;
    };
    CensorshipUtils.rectifyConfusion = function (input, map) {
        if (map === void 0) { map = Confusables.Map; }
        return this.confusables(input, map)
            .map(function (x) { return (x.similarTo == null ? x.point : x.similarTo); })
            .join("");
    };
    CensorshipUtils.normalizeNFKC = function (s) {
        var anyStr = s;
        if (typeof anyStr.normalize === "function") {
            return anyStr.normalize("NFKC");
        }
        return s;
    };
    CensorshipUtils.isLatin = function (ch) {
        var c = ch.charCodeAt(0);
        return (c >= 0x0041 && c <= 0x005A) || (c >= 0x0061 && c <= 0x007A);
    };
    CensorshipUtils.isCyrillic = function (ch) {
        var c = ch.charCodeAt(0);
        return (c >= 0x0400 && c <= 0x04FF) || (c >= 0x0500 && c <= 0x052F);
    };
    CensorshipUtils.isGreek = function (ch) {
        var c = ch.charCodeAt(0);
        return (c >= 0x0370 && c <= 0x03FF);
    };
    CensorshipUtils.hasMixedScripts = function (s) {
        var hasLat = false, hasCyr = false, hasGre = false;
        for (var i = 0; i < s.length; i++) {
            var ch = s.charAt(i);
            if (this.isLatin(ch))
                hasLat = true;
            else if (this.isCyrillic(ch))
                hasCyr = true;
            else if (this.isGreek(ch))
                hasGre = true;
        }
        var count = (hasLat ? 1 : 0) + (hasCyr ? 1 : 0) + (hasGre ? 1 : 0);
        return count >= 2;
    };
    CensorshipUtils.isMostlyLatinLike = function (s) {
        for (var i = 0; i < s.length; i++) {
            var ch = s.charAt(i);
            var c = ch.charCodeAt(0);
            var isDigit = c >= 0x30 && c <= 0x39;
            var isAsciiSymbol = ch === "_" || ch === "-" || ch === " ";
            if (!(this.isLatin(ch) || isDigit || isAsciiSymbol))
                return false;
        }
        return true;
    };
    CensorshipUtils.toCyrillicPhonetic = function (input) {
        return LatinCyrillicPhoneticMap.apply(this.normalizeNFKC(this.stripZeroWidth(input)));
    };
    CensorshipUtils.passWithOutNormalization = function (s) {
        for (var i = 0; i < s.length; i++) {
            var ch = s.charAt(i);
            if (this.isLatin(ch) ||
                this.isCyrillic(ch) ||
                this.isGreek(ch) ||
                (ch.charCodeAt(0) >= 0x30 && ch.charCodeAt(0) <= 0x39)) {
                return true;
            }
        }
        return false;
    };
    CensorshipUtils.ZERO_WIDTH = "";
    CensorshipUtils.ZERO_WIDTH_POINTS = {
        "\u200b": true,
        "\u200c": true,
        "\u200d": true,
        "\ufeff": true,
        "\u2028": true,
        "\u2029": true,
    };
    return CensorshipUtils;
}());
