var LatinCyrillicPhoneticMap = (function () {
    function LatinCyrillicPhoneticMap() {
    }
    LatinCyrillicPhoneticMap.apply = function (input) {
        var out = input.toUpperCase();
        var keys = Object.keys(this.Map).sort(function (a, b) { return b.length - a.length; });
        for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
            var k = keys_1[_i];
            out = out.split(k).join(this.Map[k]);
        }
        return out;
    };
    LatinCyrillicPhoneticMap.Map = {
        "A": "А",
        "B": "В",
        "C": "С",
        "E": "Е",
        "H": "Н",
        "K": "К",
        "M": "М",
        "O": "О",
        "P": "П",
        "T": "Т",
        "X": "Х",
        "Y": "У",
        "ZH": "Ж",
        "KH": "Х",
        "TS": "Ц",
        "SHCH": "Щ",
        "SH": "Ш",
        "CH": "Ч",
        "R": "Р",
        "S": "С",
        "I": "И",
        "J": "Ж",
        "D": "Д",
        "U": "У",
    };
    return LatinCyrillicPhoneticMap;
}());
