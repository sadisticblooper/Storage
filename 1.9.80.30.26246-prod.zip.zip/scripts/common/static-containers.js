var activityPopupsMap = {};
var itemsToShowCurrenciesInGameModule = {};
