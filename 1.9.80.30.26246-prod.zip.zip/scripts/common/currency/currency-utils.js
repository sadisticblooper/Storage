var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var CurrencyUtils = (function () {
    function CurrencyUtils() {
    }
    CurrencyUtils.getPseudoEventCurrencies = function (settings) {
        var resultCurrencies = [];
        var pseudoCurrencies = CurrencyUtils.getPseudoCurrency();
        for (var _i = 0, pseudoCurrencies_1 = pseudoCurrencies; _i < pseudoCurrencies_1.length; _i++) {
            var id = pseudoCurrencies_1[_i];
            var currency = currencySettings[id];
            var dates = currency.pseudoCurrencySettings.datesSettings;
            var now = settings.serverCurrentTime;
            if (!dates.startDate || !dates.expireDate)
                continue;
            if (this.isPseudoCurrencyActive(currency, now)) {
                resultCurrencies.push({
                    currencyType: Number(id),
                    expireTime: dates.expireDate,
                });
            }
        }
        return resultCurrencies;
    };
    CurrencyUtils.getPseudoCurrency = function () {
        var result = [];
        for (var id in currencySettings) {
            if (isNumber(id) && CURRENCY[id] != undefined) {
                var currency = currencySettings[id];
                if (this.isPseudoCurrency(currency)) {
                    result.push(Number(id));
                }
            }
        }
        return result;
    };
    CurrencyUtils.getConvertedPseudoEventCurrencies = function (settings) {
        return {
            loot: null,
            withdraw: settings.pseudoEventCurrencies,
        };
    };
    CurrencyUtils.getAllCurrencyTypes = function (settings) {
        var all = [];
        var progress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var roguelikeAvailable = progress.maxPlayerRating >= RoguelikeMetaConstants.arenaRatingToUnlock;
        var roguelikeCurrencyIds = getRoguelikeCurrencyIds();
        for (var _i = 0, _a = settings.activeEvents; _i < _a.length; _i++) {
            var eventId = _a[_i];
            all.push.apply(all, getAllActiveCurrencyId(eventId));
        }
        if (settings.activeEvents.length == 0) {
            all.push.apply(all, getAllActiveCurrencyId(null));
        }
        if (roguelikeAvailable) {
            all.push.apply(all, roguelikeCurrencyIds);
        }
        else {
            all = all.filter(function (id) { return roguelikeCurrencyIds.indexOf(id) === -1; });
        }
        var unique = [];
        for (var i = 0; i < all.length; i++) {
            if (unique.indexOf(all[i]) == -1) {
                unique.push(all[i]);
            }
        }
        return unique;
    };
    CurrencyUtils.getCurrencyGroups = function (settings) {
        var resultGroups = [];
        var progress = PlayerState.getCorrectFromRawOrCache(settings.playerProgress);
        var roguelikeAvailable = progress.maxPlayerRating >= RoguelikeMetaConstants.arenaRatingToUnlock;
        var eventId = settings.activeEvents[0];
        var currencyGroupsSettings = getCurrencyGroupsSettings({ eventId: eventId });
        for (var index in currencyGroupsSettings) {
            var group = currencyGroupsSettings[index];
            if (!group)
                throwDebugOrReturnDefault("[getCurrencyGroups]: not valid settings in currency group");
            if (!roguelikeAvailable && group.roguelikeHideLocked)
                continue;
            resultGroups.push(group);
        }
        return {
            currenciesRowSize: CurrencyConstants.CurrencyHUBRowWidth,
            topCurrencies: CurrencyConstants.CurrenciesInHUBTopPinned,
            currencyGroups: resultGroups,
        };
    };
    CurrencyUtils.getCurrencyClickTransition = function (type) {
        var curSettings = currencySettings[type];
        var args = null;
        if (curSettings.transitionSettings)
            args = curSettings.transitionSettings;
        return args;
    };
    CurrencyUtils.isPseudoCurrency = function (currSettings) {
        return !!currSettings.pseudoCurrencySettings;
    };
    CurrencyUtils.getPseudoDates = function (currSettings) {
        var _a;
        var ds = (_a = currSettings.pseudoCurrencySettings) === null || _a === void 0 ? void 0 : _a.datesSettings;
        if (!ds)
            return null;
        if (!ds.startDate || !ds.expireDate)
            return null;
        return ds;
    };
    CurrencyUtils.isPseudoCurrencyActive = function (currSettings, currentServerTime) {
        var dates = this.getPseudoDates(currSettings);
        if (!dates)
            return true;
        return currentServerTime >= dates.startDate && currentServerTime < dates.expireDate;
    };
    CurrencyUtils.getNextPseudoUpdate = function (currSettings, currentServerTime) {
        var dates = this.getPseudoDates(currSettings);
        if (!dates)
            return null;
        if (currentServerTime < dates.startDate)
            return dates.startDate;
        if (currentServerTime < dates.expireDate)
            return dates.expireDate;
        return null;
    };
    CurrencyUtils.getCurrencyListForShopSections = function (settings) {
        var section = settings.section, eventId = settings.eventId, startTimeOfCurrentDayMS = settings.startTimeOfCurrentDayMS;
        var result = __spreadArray([], CurrencyConstants.CurrenciesInShopSection[section], true);
        var event = seasonalEventsMap.get(eventId);
        if (!event || eventId <= 0)
            return result;
        if (startTimeOfCurrentDayMS > event.endTime)
            return result;
        if (section == SHOP_SECTION.Special || section == SHOP_SECTION.Offers) {
            var currentEventCurrencies_1 = EventCurrency.getAllActiveCurrencyNames(eventId);
            var eventCurrenciesForHudInShop = CurrencyConstants.EventCurrenciesForHUD
                .filter(function (currency) { return currentEventCurrencies_1.indexOf(currency) > -1; });
            result.push.apply(result, eventCurrenciesForHudInShop);
        }
        return result;
    };
    CurrencyUtils.getPopupNotEnoughCurrencyInfo = function (type) {
        var currency = currencySettings[type];
        if (!currency || !currency.notEnoughCurrencyPopupInfo)
            return null;
        return currency.notEnoughCurrencyPopupInfo;
    };
    CurrencyUtils.mergeCurrencies = function (currenciesArray) {
        var result = {};
        currenciesArray.forEach(function (currencies) {
            var _a;
            for (var currency in currencies) {
                (_a = result[currency]) !== null && _a !== void 0 ? _a : (result[currency] = 0);
                result[currency] += currencies[currency];
            }
        });
        return result;
    };
    return CurrencyUtils;
}());
