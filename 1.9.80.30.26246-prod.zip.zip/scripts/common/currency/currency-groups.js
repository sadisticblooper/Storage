var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function getCurrencyGroupsSettingsForEvent(_a) {
    var _b, _c, _d, _e;
    var eventId = _a.eventId;
    var seasonalEvent = typeof eventId === 'number'
        ? seasonalEventsMap.get(eventId)
        : undefined;
    if (!seasonalEvent) {
        return {};
    }
    var config = seasonalEvent.currencyGroupConfig;
    return {
        event_group: {
            headerAlias: (_b = config === null || config === void 0 ? void 0 : config.headerAlias) !== null && _b !== void 0 ? _b : "hub_default_event_currency_group",
            colors: (_c = config === null || config === void 0 ? void 0 : config.colors) !== null && _c !== void 0 ? _c : {
                headerColor: "#82E56A",
                timerColor: "#82E56A",
                infoButtonColor: "#82E56A",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#82E56A" }, { time: 1, color: "#82E56A" }],
                },
            },
            tooltipHeaderAlias: (_d = config === null || config === void 0 ? void 0 : config.tooltipHeaderAlias) !== null && _d !== void 0 ? _d : "hub_default_event_currency_group_tooltip",
            tooltipDescriptionAlias: (_e = config === null || config === void 0 ? void 0 : config.tooltipDescriptionAlias) !== null && _e !== void 0 ? _e : "hub_default_event_currency_group_tooltip_desc",
            startTime: seasonalEvent.startTime,
            expireTime: seasonalEvent.endTime,
            currencies: seasonalEvent.eventCurrencies,
        },
    };
}
function getCurrencyGroupsSettings(options) {
    return __assign(__assign({ gacha_group: {
            headerAlias: "hub_gacha_currency_group",
            colors: {
                headerColor: "#5EE7FF",
                timerColor: "#5EE7FF",
                infoButtonColor: "#5EE7FF",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#5EE7FF" }, { time: 1, color: "#5EE7FF" }],
                },
            },
            currencies: [CURRENCY.GACHA_KEY],
        } }, getCurrencyGroupsSettingsForEvent(options)), { roguelike_group: {
            headerAlias: "hub_roguelike_currency_group",
            colors: {
                headerColor: "#FF8F5E",
                timerColor: "#FF8F5E",
                infoButtonColor: "#FF8F5E",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#FF8F5E" }, { time: 1, color: "#FF8F5E" }],
                },
            },
            currencies: [CURRENCY.SILVER, CURRENCY.ROGUELIKE_ENERGY],
            roguelikeHideLocked: true,
        }, pseudo_currency_group_1: {
            headerAlias: "hub_event_currency_group_title_Feldsher",
            colors: {
                headerColor: "#47FFFF",
                timerColor: "#47FFFF",
                infoButtonColor: "#47FFFF",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#47FFFF" }, { time: 1, color: "#47FFFF" }],
                },
            },
            startTime: ActivityTimeConstants.feldsher_rework_06_2026.start,
            expireTime: ActivityTimeConstants.feldsher_rework_06_2026.end,
            tooltipHeaderAlias: "hub_pseudo_currency_group_tooltip",
            tooltipDescriptionAlias: "hub_pseudo_currency_group_tooltip_desc",
            currencies: [CURRENCY.PSEUDO_CHIP_1],
        }, ad_token_group: {
            headerAlias: "hub_ad_token_currency_group",
            colors: {
                headerColor: "#82E56A",
                timerColor: "#82E56A",
                infoButtonColor: "#82E56A",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#82E56A" }, { time: 1, color: "#82E56A" }],
                },
            },
            currencies: [CURRENCY.AD_TOKEN],
        }, season_group: {
            headerAlias: "hub_season_currency_group",
            colors: {
                headerColor: "#5EE7FF",
                timerColor: "#5EE7FF",
                infoButtonColor: "#5EE7FF",
                headerBgGradient: {
                    mode: 0,
                    alphaKeys: [{ time: 0, alpha: 0 }, { time: 1, alpha: 1 }],
                    colorKeys: [{ time: 0, color: "#5EE7FF" }, { time: 1, color: "#5EE7FF" }],
                },
            },
            tooltipHeaderAlias: "hub_season_currency_group_tooltip",
            tooltipDescriptionAlias: "hub_season_currency_group_tooltip_desc",
            currencies: [CURRENCY.CUSTOMIZATION_TOKEN],
        } });
}
