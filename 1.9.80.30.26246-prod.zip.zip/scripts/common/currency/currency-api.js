function getAllCurrencyTypes(settings) {
    return CurrencyUtils.getAllCurrencyTypes(settings);
}
function getPseudoEventCurrencies(settings) {
    return CurrencyUtils.getPseudoEventCurrencies(settings);
}
function getConvertedPseudoEventCurrencies(settings) {
    return CurrencyUtils.getConvertedPseudoEventCurrencies(settings);
}
function getCurrencyGroups(settings) {
    return CurrencyUtils.getCurrencyGroups(settings);
}
function getCurrencyClickTransition(type) {
    return CurrencyUtils.getCurrencyClickTransition(type);
}
function getCurrencyListForShopSections(settings) {
    return CurrencyUtils.getCurrencyListForShopSections(settings);
}
function getPopupNotEnoughCurrencyInfo(type) {
    return CurrencyUtils.getPopupNotEnoughCurrencyInfo(type);
}
