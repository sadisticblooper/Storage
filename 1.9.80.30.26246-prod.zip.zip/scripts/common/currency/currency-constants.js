var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var _a;
var CurrencyConstants = (function () {
    function CurrencyConstants() {
    }
    var _b;
    _b = CurrencyConstants;
    CurrencyConstants.DefaultCurrencies = [CURRENCY.COIN, CURRENCY.BONUS];
    CurrencyConstants.CurrenciesInHUBTopPinned = _b.DefaultCurrencies;
    CurrencyConstants.CurrenciesInShopSection = (_a = {},
        _a[SHOP_SECTION.None] = __spreadArray([], _b.DefaultCurrencies, true),
        _a[SHOP_SECTION.Currencies] = __spreadArray(__spreadArray([], _b.DefaultCurrencies, true), [CURRENCY.AD_TOKEN, CURRENCY.GACHA_KEY], false),
        _a[SHOP_SECTION.Deals] = __spreadArray(__spreadArray([], _b.DefaultCurrencies, true), [CURRENCY.AD_TOKEN], false),
        _a[SHOP_SECTION.Chests] = __spreadArray([], _b.DefaultCurrencies, true),
        _a[SHOP_SECTION.Offers] = __spreadArray([], _b.DefaultCurrencies, true),
        _a[SHOP_SECTION.Free] = __spreadArray([], _b.DefaultCurrencies, true),
        _a[SHOP_SECTION.Special] = __spreadArray(__spreadArray([], _b.DefaultCurrencies, true), [CURRENCY.CUSTOMIZATION_TOKEN], false),
        _a);
    CurrencyConstants.EventCurrenciesForHUD = [
        CURRENCY.TOKEN_1, CURRENCY.CHIP_1,
        CURRENCY.TOKEN_2, CURRENCY.CHIP_2
    ];
    CurrencyConstants.CurrencyHUBRowWidth = 3;
    CurrencyConstants.MaxCurrenciesInHUBGroup = 6;
    return CurrencyConstants;
}());
