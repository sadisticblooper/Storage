var _a;
var CurrencyRates = (function () {
    function CurrencyRates() {
    }
    CurrencyRates.currencyPerBonusConversion = (_a = {},
        _a[CURRENCY.COIN] = 20,
        _a[CURRENCY.GACHA_KEY] = 1 / 299,
        _a[CURRENCY.TICKET_1] = 0.1,
        _a[CURRENCY.CHIP_1] = 0.5,
        _a[CURRENCY.TOKEN_1] = 10,
        _a[CURRENCY.TICKET_2] = 0.1,
        _a[CURRENCY.CHIP_2] = 0.5,
        _a[CURRENCY.TOKEN_2] = 10,
        _a[CURRENCY.CHIP_3] = 1 / 1.65,
        _a[CURRENCY.TOKEN_3] = 1 / 99.0000001,
        _a);
    CurrencyRates.nestedCurrenciesRelationship = {};
    return CurrencyRates;
}());
