var CareGameState = (function () {
    function CareGameState() {
    }
    CareGameState.setIsCareGameBuild = function (isCareGameBuild) {
        CareGameState.isCareGameBuild = isCareGameBuild;
        return true;
    };
    CareGameState.getIsCareGameBuild = function () {
        return CareGameState.isCareGameBuild;
    };
    CareGameState.isCareGameBuild = false;
    return CareGameState;
}());
