var SteamPlatformUtils = (function () {
    function SteamPlatformUtils() {
    }
    SteamPlatformUtils.isPCBuild = function (platform) {
        return [PLATFORM.SIMULATOR, PLATFORM.MAC_OS, PLATFORM.STEAM].indexOf(platform) > -1;
    };
    return SteamPlatformUtils;
}());
