var Timers = (function () {
    function Timers() {
    }
    Timers.pseudoCurrency1Period = {
        startDate: new Date('2025-01-01').getTime(),
        expireDate: new Date('2027-01-01').getTime(),
    };
    Timers.pseudoCurrency2Period = {
        startDate: new Date('2025-01-01').getTime(),
        expireDate: new Date('2026-03-20').getTime(),
    };
    return Timers;
}());
