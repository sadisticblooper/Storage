var _a, _b, _c, _d, _e, _f, _g, _h, _j;
var FightQualityConstants = (function () {
    function FightQualityConstants() {
    }
    FightQualityConstants.fightQualityPeriod = 10;
    FightQualityConstants.fightQualityDisabled = true;
    return FightQualityConstants;
}());
var AccountLevelUpPrices = (function () {
    function AccountLevelUpPrices() {
    }
    AccountLevelUpPrices[1] = 15;
    AccountLevelUpPrices[2] = 25;
    AccountLevelUpPrices[3] = 50;
    AccountLevelUpPrices[4] = 100;
    AccountLevelUpPrices[5] = 200;
    AccountLevelUpPrices[6] = 400;
    AccountLevelUpPrices[7] = 600;
    AccountLevelUpPrices[8] = 800;
    AccountLevelUpPrices[9] = 1200;
    AccountLevelUpPrices[10] = 1600;
    AccountLevelUpPrices[11] = 2500;
    AccountLevelUpPrices[12] = 3200;
    return AccountLevelUpPrices;
}());
var UserConstants = (function () {
    function UserConstants() {
    }
    UserConstants.minDisplayNameLength = 3;
    UserConstants.maxDisplayNameLength = 20;
    return UserConstants;
}());
var InputLagConstants = (function () {
    function InputLagConstants() {
    }
    InputLagConstants.min = 3;
    InputLagConstants.max = 16;
    return InputLagConstants;
}());
var FightConstants = (function () {
    function FightConstants() {
    }
    FightConstants.maxWinRounds = (_a = {},
        _a[TEAM_MODE._3_VS_3_] = 3,
        _a[TEAM_MODE._1_VS_1_] = 2,
        _a);
    FightConstants.formationsCountLimit = (_b = {},
        _b[TEAM_MODE._3_VS_3_] = 3,
        _b[TEAM_MODE._1_VS_1_] = 1,
        _b);
    return FightConstants;
}());
var DeviceRestriction = (function () {
    function DeviceRestriction() {
    }
    DeviceRestriction.minClientMemoryMb = { "ANDROID": 1700 };
    DeviceRestriction.allowPreviouslyLogged = true;
    return DeviceRestriction;
}());
var ClientModules = (function () {
    function ClientModules() {
    }
    ClientModules.BetaModules = {
        "EventHub": false,
        "TournamentDraft": false,
        "EventWindow": false,
    };
    ClientModules.featuresActivity = (_c = {},
        _c[FEATURE.DAILY_REWARDS] = false,
        _c[FEATURE.FIGHT_CHESTS] = true,
        _c[FEATURE.IN_GAME_MAIL] = true,
        _c);
    return ClientModules;
}());
var NotifyConstants = (function () {
    function NotifyConstants() {
    }
    NotifyConstants.FriendlyFightNotificatorSinceAccountLevel = 3;
    return NotifyConstants;
}());
var BetaCheats = (function () {
    function BetaCheats() {
    }
    BetaCheats.accountLevel = 13;
    BetaCheats.heroesLevel = 13;
    BetaCheats.unlockCustomizations = true;
    return BetaCheats;
}());
var HelpShift = (function () {
    function HelpShift() {
    }
    HelpShift.platformToTags = (_d = {},
        _d[PLATFORM.ANDROID_CHINA] = ["arena_china"],
        _d[PLATFORM.HUAWEI] = ["arena_huawei"],
        _d[PLATFORM.XSOLLA] = ["arena_xsolla"],
        _d[PLATFORM.IOS_CHINA] = ["arena_china"],
        _d[PLATFORM.CARE_GAME] = ["arena_caregame"],
        _d[PLATFORM.ANDROID_EGS] = ["arena_egs"],
        _d[PLATFORM.IOS_EGS] = ["arena_egs"],
        _d[PLATFORM.ANDROID_VIETNAM] = ["arena_vietnam"],
        _d[PLATFORM.IOS_VIETNAM] = ["arena_vietnam"],
        _d);
    return HelpShift;
}());
var VisualConstants = (function () {
    function VisualConstants() {
    }
    VisualConstants.commonTimerSettings = {
        iconColor: "#ffdd7589",
        timerColor: "#ffdd75",
        glowColor: "#ff00008a",
    };
    VisualConstants.commonModifierColor = "#ffe28c";
    return VisualConstants;
}());
var RewardConstants = (function () {
    function RewardConstants() {
    }
    RewardConstants.HeroInRewardRandomAvailabilitySchedule = { Origin: "2016-01-01T03:00:00+03", Period: new Time({ Days: 1 }).value };
    return RewardConstants;
}());
var UmoneyCustomPaymentMethods = (function () {
    function UmoneyCustomPaymentMethods() {
    }
    UmoneyCustomPaymentMethods.clientBuildNumberToPaymentMethodType = {
        "1474": "bank_card",
        "4074": "bank_card",
    };
    UmoneyCustomPaymentMethods.defaultPaymentMethodType = null;
    return UmoneyCustomPaymentMethods;
}());
var JsCallFilterConstants = (function () {
    function JsCallFilterConstants() {
    }
    JsCallFilterConstants.enabledPromoTriggersByFeature = (_e = {},
        _e[PROMO_EVENT_FEATURE.PEF_UNKNOWN] = [],
        _e[PROMO_EVENT_FEATURE.PEF_OFFERS] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.SERIAL,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.ARENA_CHANGE,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
            PROMO_TRIGGER_TYPE.RATING_CHANGE,
            PROMO_TRIGGER_TYPE.FIGHT_END,
            PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER,
            PROMO_TRIGGER_TYPE.CHANGE_BATTLE_PASS_LEVEL,
            PROMO_TRIGGER_TYPE.FIRST_TIME_COMPLETE_TOURNAMENT,
            PROMO_TRIGGER_TYPE.TUTORIAL_PASS,
            PROMO_TRIGGER_TYPE.MARATHON_PROGRESS_CHANGE,
            PROMO_TRIGGER_TYPE.MARATHON_END,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_ROULETTE] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.SERIAL,
            PROMO_TRIGGER_TYPE.FIGHT_END,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_TOURNAMENT] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
            PROMO_TRIGGER_TYPE.RATING_CHANGE,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_MARATHON] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
            PROMO_TRIGGER_TYPE.REACTIVATE_PLAYER,
            PROMO_TRIGGER_TYPE.MARATHON_END,
            PROMO_TRIGGER_TYPE.SERIAL,
            PROMO_TRIGGER_TYPE.RATING_CHANGE,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_SPECIAL_AND_EVENT_QUESTS] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.FIGHT_END,
            PROMO_TRIGGER_TYPE.SEASON_END,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_MULTI_BONUS] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.SERIAL,
            PROMO_TRIGGER_TYPE.FIGHT_END,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_GACHA] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_ADMIN_MAIL_REFRESH] = [
            PROMO_TRIGGER_TYPE.LOGIN
        ],
        _e[PROMO_EVENT_FEATURE.PEF_CONFIG_MAIL_REFRESH] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.ARENA_CHANGE,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.SEASON_END,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.HERO_TALENT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.HERO_LEVEL_UP,
            PROMO_TRIGGER_TYPE.FIRST_LOBBY_ENTRY_COMPLETE,
            PROMO_TRIGGER_TYPE.FIGHT_END,
            PROMO_TRIGGER_TYPE.PASS_ROGUELIKE_CHAPTER,
            PROMO_TRIGGER_TYPE.EMAIL_LINK,
            PROMO_TRIGGER_TYPE.INCREASE_CURRENCY_FROM_ZERO,
            PROMO_TRIGGER_TYPE.MAIL_ON_MIGRATION,
        ],
        _e[PROMO_EVENT_FEATURE.PEF_MAIL_EXPIRATION_CHECK] = [
            PROMO_TRIGGER_TYPE.LOGIN,
            PROMO_TRIGGER_TYPE.ARENA_CHANGE,
            PROMO_TRIGGER_TYPE.COMBINE_HERO,
            PROMO_TRIGGER_TYPE.SEASON_END,
            PROMO_TRIGGER_TYPE.ACCOUNT_LEVEL_UP,
            PROMO_TRIGGER_TYPE.EMAIL_LINK
        ],
        _e);
    return JsCallFilterConstants;
}());
var logBuffer = [];
var RandomInstance = new PcgRandom(1);
var MAX_SAFE_INTEGER = 9007199254740991;
var inGameSettingsPresets = {
    settingsPopup: (_f = {},
        _f[PREFERENCES_OPTION_TYPE.SOUND] = { nameAlias: "settings_sound", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.MUSIC] = { nameAlias: "settings_music", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.GRAPHIC_QUALITY] = { nameAlias: "settings_graphics_quality", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.DEVICE_VIBRATION] = { nameAlias: "settings_device_vibration", enabled: false },
        _f[PREFERENCES_OPTION_TYPE.AUTO_PLAY_VIDEO] = { nameAlias: "settings_video_autoplay", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.PUSH_NOTIFICATIONS] = { nameAlias: "settings_push_notifications", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.GAMEPAD_AUTO_DETECTION] = { nameAlias: "settings_gamepad_autodetection", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.IS_VOICE_OVER_ENABLED] = { nameAlias: "settings_voice_over", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.SHOW_DAMAGE_VALUES] = { nameAlias: "settings_damage_values", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.SHOW_ROGUELIKE_DIALOGUES] = { nameAlias: "settings_roguelike_dialog_values", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.SOCIAL_PROFILE_VISIBILITY] = { nameAlias: "settings_social_profile_visibility", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.DUEL_PERMISSION] = { nameAlias: "settings_duel_permission", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.COUNTRY_CODE_VISIBILITY] = { nameAlias: "settings_country_code_visibility", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.IS_FRIEND_REQUEST_ALLOWED] = { nameAlias: "settings_friend_request_allowed", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.FIGHT_JOURNAL_VISIBILITY] = { nameAlias: "settings_fight_journal_visibility", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.DISPLAY_MODE] = { nameAlias: "settings_display_mode", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.VSYNC] = { nameAlias: "settings_vsync", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.RESOLUTION] = { nameAlias: "settings_resolution", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.GAMEPAD_VIBRATION] = { nameAlias: "settings_gamepad_vibration", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_UP] = { nameAlias: "settings_keyboard_fight_up", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_RIGHT] = { nameAlias: "settings_keyboard_fight_right", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_DOWN] = { nameAlias: "settings_keyboard_fight_down", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_LEFT] = { nameAlias: "settings_keyboard_fight_left", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_UP_LEFT] = { nameAlias: "settings_keyboard_fight_up_left", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_UP_RIGHT] = { nameAlias: "settings_keyboard_fight_up_right", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_DOWN_LEFT] = { nameAlias: "settings_keyboard_fight_down_left", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_DOWN_RIGHT] = { nameAlias: "settings_keyboard_fight_down_right", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_PUNCH] = { nameAlias: "settings_keyboard_fight_punch", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_KICK] = { nameAlias: "settings_keyboard_fight_kick", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_MISSILE] = { nameAlias: "settings_keyboard_fight_missile", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_MAGIC] = { nameAlias: "settings_keyboard_fight_magic", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION1] = { nameAlias: "settings_keyboard_fight_selection_1", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION2] = { nameAlias: "settings_keyboard_fight_selection_2", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION3] = { nameAlias: "settings_keyboard_fight_selection_3", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION4] = { nameAlias: "settings_keyboard_fight_selection_4", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION5] = { nameAlias: "settings_keyboard_fight_selection_5", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION6] = { nameAlias: "settings_keyboard_fight_selection_6", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION7] = { nameAlias: "settings_keyboard_fight_selection_7", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_SELECTION8] = { nameAlias: "settings_keyboard_fight_selection_8", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_MUTE_EMOJI] = { nameAlias: "settings_keyboard_fight_mute_emoji", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_TOGGLE_EMOJI_PANEL_OR_TOGGLE_TRAINING_PANEL] = { nameAlias: "settings_keyboard_fight_toggle_emoji_panel_or_toggle_training_panel", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_TOGGLE_TAUNT_PANEL] = { nameAlias: "settings_keyboard_fight_toggle_taunt_panel", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.KEYBOARD_FIGHT_TOGGLE_TEXT_EMOJI_OR_TOGGLE_TRAINING_MIRROR_MODE] = { nameAlias: "settings_keyboard_fight_toggle_text_emoji_or_toggle_mirror_mode", enabled: true },
        _f[PREFERENCES_OPTION_TYPE.LOBBY_CAMERA_SHAKE] = { nameAlias: "settings_lobby_camera_shake", enabled: true },
        _f),
    excludedGraphicPresets: [
        "custom"
    ],
};
var MAX_ACCOUNT_LEVEL = (function () {
    var max = 0;
    for (var level in AccountLevelUpPrices)
        if (AccountLevelUpPrices.hasOwnProperty(level)) {
            max = Math.max(max, Number(level));
        }
    return max + 1;
})();
var priceToChangeNickName = (_g = {},
    _g[CURRENCY.BONUS] = 30,
    _g);
var GameStatusIndicatorConfig = {
    CheckPeriodFrames: 30,
    DropPercentageIndication: 0.5,
    PeakFrameMultiplier: 6
};
var FreeAttemptsToChangeName = 1;
var CurrentRateUsWindowState = RATE_WINDOW_STATE.WITH_REWARD_RATE_US;
var GameTimeLimitForPlayer = (_h = {},
    _h[DayOfWeek.Sunday] = new Time({ Hours: 3 }).value,
    _h[DayOfWeek.Monday] = new Time({ Hours: 1, Minutes: 30 }).value,
    _h[DayOfWeek.Tuesday] = new Time({ Hours: 1, Minutes: 30 }).value,
    _h[DayOfWeek.Wednesday] = new Time({ Hours: 1, Minutes: 30 }).value,
    _h[DayOfWeek.Thursday] = new Time({ Hours: 1, Minutes: 30 }).value,
    _h[DayOfWeek.Friday] = new Time({ Hours: 1, Minutes: 30 }).value,
    _h[DayOfWeek.Saturday] = new Time({ Hours: 3 }).value,
    _h);
var openingLimitConfig = {
    schedule: {
        Origin: "2018-06-04T12:00:00+03",
        Period: new Time({ Days: 1 }).value,
    },
};
var CompareOfflineStateAfterCommandExecution = false;
var enableHashVerification = true;
var useDebugOverException = false;
var ignoredPlatformVersions = (_j = {},
    _j[OS_FAMILY.ANDROID] = ["29", "30"],
    _j);
var isBeta = false;
var allPlatforms = Object.keys(PLATFORM).filter(function (pl) { return isNumber(pl); }).map(Number);
var allRegions = [
    "AD", "AE", "AF", "AG", "AI",
    "AL", "AM", "AN", "AO", "AQ",
    "AR", "AS", "AT", "AU", "AW",
    "AZ", "BB", "BD", "BE", "BF",
    "BG", "BH", "BI", "BJ", "BM",
    "BN", "BO", "BR", "BS", "BT",
    "BV", "BW", "BY", "BZ", "CA",
    "CC", "CF", "CG", "CH", "CI",
    "CK", "CL", "CM", "CN", "CO",
    "CR", "CU", "CV", "CX", "CY",
    "CZ", "DE", "DJ", "DK", "DM",
    "DO", "DZ", "EC", "EE", "EG",
    "EH", "ES", "ET", "FI", "FJ",
    "FK", "FM", "FO", "FR", "GA",
    "GB", "GD", "GE", "GF", "GH",
    "GI", "GL", "GM", "GN", "GP",
    "GQ", "GR", "GT", "GU", "GW",
    "GY", "HK", "HM", "HN", "HT",
    "HU", "ID", "IE", "IL", "IM",
    "IN", "IO", "IQ", "IR", "IS",
    "IT", "JM", "JO", "JP", "JT",
    "KE", "KG", "KH", "KI", "KM",
    "KN", "KP", "KR", "KW", "KY",
    "KZ", "LA", "LB", "LC", "LI",
    "LK", "LR", "LS", "LT", "LU",
    "LV", "LY", "MA", "MC", "MD",
    "MG", "MH", "MI", "ML", "MM",
    "MN", "MO", "MP", "MQ", "MR",
    "MS", "MT", "MU", "MV", "MW",
    "MX", "MY", "MZ", "NA", "NC",
    "NE", "NF", "NG", "NI", "NL",
    "NO", "NP", "NR", "NT", "NU",
    "NZ", "OM", "PA", "PE", "PF",
    "PG", "PH", "PK", "PL", "PM",
    "PN", "PR", "PT", "PW", "PY",
    "QA", "RE", "RO", "RU", "RW",
    "SA", "SB", "SC", "SD", "SE",
    "SG", "SH", "SJ", "SK", "SL",
    "SM", "SN", "SO", "SR", "ST",
    "SV", "SY", "SZ", "TC", "TD",
    "TF", "TG", "TH", "TJ", "TK",
    "TM", "TN", "TO", "TP", "TR",
    "TT", "TV", "TW", "TZ", "UA",
    "UG", "UM", "US", "UY", "UZ",
    "VA", "VC", "VE", "VG", "VI",
    "VN", "VU", "WF", "WK", "WS",
    "YE", "YU", "ZA", "ZM", "ZR",
    "ZW",
];
var CIS_COUNTRIES = [
    "AZ", "AM", "BY", "KZ", "KG", "MD", "RU", "TJ", "UZ"
];
var WORLD_PROD_EU_COUNTRIES = [
    "AD", "AE", "AL", "AM", "AO", "AT", "AZ", "BA", "BE",
    "BF", "BG", "BH", "BI", "BJ", "BW", "BY", "CD", "CF",
    "CG", "CH", "CI", "CM", "CV", "CY", "CZ", "DE", "DJ",
    "DK", "DZ", "EE", "EG", "ES", "ET", "FI", "FR", "GA",
    "GB", "GE", "GH", "GI", "GM", "GN", "GR", "GW", "HR",
    "HU", "IE", "IL", "IM", "IQ", "IR", "IS", "IT", "JE",
    "JO", "KE", "KG", "KM", "KW", "KZ", "LB", "LR", "LS",
    "LT", "LU", "LV", "LY", "MA", "MC", "MD", "ME", "MG",
    "MK", "ML", "MR", "MT", "MU", "MW", "MZ", "NA", "NE",
    "NG", "NL", "NO", "OM", "PL", "PS", "PT", "QA", "RE",
    "RO", "RS", "RU", "RW", "SA", "SC", "SD", "SE", "SI",
    "SK", "SL", "SM", "SN", "SO", "SS", "ST", "SY", "SZ",
    "TD", "TG", "TJ", "TM", "TN", "TR", "TZ", "UA", "UG",
    "UZ", "XK", "YE", "YT", "ZA", "ZM", "ZW"
];
var WORLD_PROD_US_COUNTRIES = [
    "AG", "AI", "AR", "AW", "BB", "BM", "BO", "BQ", "BR",
    "BS", "BZ", "CA", "CL", "CO", "CR", "CU", "CW", "DM",
    "DO", "EC", "GD", "GF", "GL", "GP", "GT", "GY", "HN",
    "HT", "JM", "KN", "KY", "LC", "MF", "MQ", "MS", "MX",
    "NI", "PA", "PE", "PR", "PY", "SR", "SV", "SX", "TC",
    "TT", "US", "UY", "VC", "VE", "VG", "VI"
];
var WORLD_PROD_AS_COUNTRIES = [
    "AF", "AS", "AU", "BD", "BN", "BT", "CN", "FJ",
    "FM", "GU", "HK", "ID", "IN", "JP", "KH", "KI",
    "KR", "LA", "LK", "MH", "MM", "MN", "MO", "MP",
    "MV", "MY", "NC", "NP", "NR", "NZ", "PF", "PG",
    "PH", "PK", "PW", "SB", "SG", "TH", "TL", "TO",
    "TW", "VN", "VU", "WS"
];
var TransferProgressCodeLifetime = new Time({ Minutes: 10 }).value;
var TransferProgressCodeCharactersLimit = 25;
var steamReleaseDateOnPC = new Date("2025-10-29").getTime();
var nonPCPlatforms = [
    PLATFORM.ANDROID, PLATFORM.ANDROID_CHINA, PLATFORM.ANDROID_EGS,
    PLATFORM.IOS, PLATFORM.IOS_CHINA, PLATFORM.IOS_EGS,
    PLATFORM.SAMSUNG, PLATFORM.XSOLLA, PLATFORM.ANDROID_VIETNAM, PLATFORM.IOS_VIETNAM
];
var IOS_PLATFORMS = [PLATFORM.IOS_EGS, PLATFORM.IOS, PLATFORM.IOS_CHINA, PLATFORM.IOS_VIETNAM];
var isIOSApproveInProgress = false;
var MAX_TALENT_MIN_WEIGHT = 0.00001;
