var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function isFeatureActive(feature) {
    return !!ClientModules.featuresActivity[feature];
}
function getCurrencySettings(currency) {
    return currency == -1
        ? battlePassPointsVisualSettings
        : currencySettings[currency]
            ? currencySettings[currency]
            : null;
}
function getCurrencyVisualSettings(currency) {
    return currency == -1
        ? battlePassPointsVisualSettings
        : currencySettings[currency]
            ? currencySettings[currency]
            : null;
}
function getModuleCurrencies(settings) {
    return CommonGameUtils.getModuleCurrencies(settings);
}
function getModulesForAddCurrencyButton() {
    return Object.keys(GAME_MODULE).filter(function (m) { return isNumber(m) && +m != GAME_MODULE.SocialProfile; }).map(Number);
}
function getAllCurrencyNames() {
    var result = [];
    for (var name_1 in CURRENCY) {
        result.push(name_1);
    }
    return result;
}
function getReplenishableCurrencySettings(currencyId) {
    if (currencyId == CURRENCY.ROGUELIKE_ENERGY) {
        return energyCurrencySettings;
    }
    return null;
}
function getAccountLevelProgressFromHeroes(heroesInfo) {
    return HeroUtils.getAccountLevelProgressFromHeroes(heroesInfo);
}
function initCallBackAPI(implEnum) {
    switch (implEnum) {
        case ClientLoggerCallbackApiImplEnum.CLIENT:
            clientLoggerCallbackApi = new ClientLogger();
            break;
        default:
            clientLoggerCallbackApi = new JsLogger();
    }
}
function setPlayerProgress(playerProgress) {
    return PlayerState.setPlayerProgress(playerProgress);
}
function setIsCareGameBuild(isCareGameBuild) {
    return CareGameState.setIsCareGameBuild(isCareGameBuild);
}
function getIconById(iconID) {
    return iconsMap.get(iconID) ? iconsMap.get(iconID) : null;
}
function getHeroCardsToLevel(settings) {
    return HeroUtils.getHeroCardsToLevel(settings);
}
function getInGameSettingsPresets() {
    var result = {
        settingsPopup: __assign({}, inGameSettingsPresets.settingsPopup),
        excludedGraphicPresets: inGameSettingsPresets.excludedGraphicPresets,
    };
    var isCareGameBuild = CareGameState.getIsCareGameBuild();
    if (isCareGameBuild) {
        result.settingsPopup[PREFERENCES_OPTION_TYPE.GRAPHIC_QUALITY]
            = { nameAlias: "settings_graphics_quality", enabled: false };
    }
    return result;
}
function getPlayerDefaultsForCareGameUser(settings) {
    return settings.skipTutorial ? 11 : 12;
}
function canUseMediaPlayer(settings) {
    return settings.platform != PLATFORM.CARE_GAME;
}
function TestPerformance(x) {
    return 0;
}
function getFightConstants(teamMode) {
    return {
        maxWinRounds: FightConstants.maxWinRounds[teamMode],
        formationsCountLimit: FightConstants.formationsCountLimit[teamMode],
    };
}
function getHelpShiftTags(settings) {
    return HelpShift.platformToTags[settings.platform] || [];
}
function getAccountDeletionSettings(settings) {
    var platform = settings.platform;
    var availablePlatforms = IOS_PLATFORMS.slice();
    if (isIOSApproveInProgress) {
    }
    var isDeletionAvailable = availablePlatforms.indexOf(platform) > -1;
    var confirmationPopupAlias = platform == PLATFORM.IOS
        ? "account_deletion_body_apple"
        : "account_deletion_body";
    return {
        isDeletionAvailable: isDeletionAvailable,
        deletionDelayInDays: 30,
        confirmationPopupAlias: confirmationPopupAlias
    };
}
