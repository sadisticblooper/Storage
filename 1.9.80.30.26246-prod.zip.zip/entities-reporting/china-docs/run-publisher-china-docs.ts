async function entryPoint() {
    const entityDataExtractors: Record<Entity, EntityData<unknown>> = {
        [Entity.CURRENCY]: new EntityCurrency(),
        [Entity.CHEST]: new EntityChests({
            filterItems: (chest) => !chest.Name.match(/^Irrelevant_|^TournamentMockChest$/),
        }),
        [Entity.HERO]: new EntiryHeroes(),
        [Entity.WEAPON]: new EntityWeapons(),
        [Entity.SKIN]: new EntitySkins(),
        [Entity.TAUNT]: new EntityTaunts(),
        [Entity.EMOJI]: new EntityEmoji({ images: 'static' }),
        [Entity.STANCE]: new EntityStances(),
        [Entity.TEXT_EMOJI_PACK]: new EntityTextEmojiPacks(),
        [Entity.CUSTOMIZATION_SHARD]: new EntityCustomizationShards(),
        [Entity.ROGUELIKE_MODIFIER]: new EntityRoguelikeModifiers(),
    }

    const chinaDocsPublisher = new PublisherChinaDocs(entityDataExtractors);
    await chinaDocsPublisher.build()
}

entryPoint();