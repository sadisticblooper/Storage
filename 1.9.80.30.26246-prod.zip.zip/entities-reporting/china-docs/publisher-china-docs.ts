class PublisherChinaDocs extends Publisher {
    constructor(entityDataExtractors: Record<Entity, EntityData<unknown>>) {
        super(entityDataExtractors);
    }

    protected getBranch(): string | null {
        return null;
    }

    public resolveColor(color: string): string {
        return `<span class="color" style="background: ${color}">${color}</span>`;
    }

    public async resolveAsset(asset: string): Promise<string> {
        try {
            const base64 = await this.resolveAssetAsBase64Jpg(asset);
            return `<img src="data:image/jpeg;base64,${base64}">`;
        } catch {
            return `❓`;
        }
    }

    public resolveAlias(alias: string): string {
        return [
            'ChineseTraditional',
            'ChineseSimplified',
            'English',
        ].map(locale => this.localization[locale][alias]).join('<br>');
    }

    public resolveVimeo(videoId: number): string {
        if (!videoId) {
            return `—`;
        }
        return `
            <iframe
                src="https://player.vimeo.com/video/${videoId}?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479"
                width="320"
                height="180"
                frameborder="0"
                allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
                referrerpolicy="strict-origin-when-cross-origin"
                loading="lazy"
                title=""
            ></iframe>
            <br>
            <a href="https://vimeo.com/${videoId}" target="_blank">open in a new tab</a>
        `;
    }

    public resolveRarity(rarity: string): string {
        return `${this.rarityMark(rarity)}${rarity}`;
    }

    public resolveHero(heroId: number): string {
        const hero = heroesMap.get(heroId);
        return `${this.rarityMark(HERO_RARITY[hero.Rarity])}${hero.Name}`;
    }

    private rarityMark(rarity: string): string {
        return `<meta name="rarity" content="${rarity}" />`
    }

    private makeStyles(resultDisplay: PublisherResultDisplay): string {
        return `
        <style>
            :root {
              color-scheme: light dark;
              background: light-dark(#ffffff, #121212);
              color: light-dark(#1a1a1a, #ededed);
            }
            td {
                border: 1px solid light-dark(#1a1a1a, #777);
                padding: 0 0.4rem;
            }
            body:has(#images_hide:checked) img { 
                display: none;
            }
            body:has(#images_small:checked) img { 
                max-width: 100px;
                max-height: 100px;
            }
            body:has(#images_small:checked) img { 
                max-width: 100px;
                max-height: 100px;
            }
            
            body:has(#video_normal:checked) iframe[src^="https://player."] { 
                width: 960px;
                height: 540px;
            }
            body:has(#video_small:checked) iframe[src^="https://player."] { 
                width: 320px;
                height: 180px;
            }
            body:has(#video_hide:checked) iframe[src^="https://player."] { 
                display: none;
            }
            .color {
                display: inline-block;
                padding: 0.2rem;
            }
            td:nth-child(1) {
                font-weight: bold;
            }
            fieldset {
                margin: 1rem 0;
            }
            
            body:not(:has(:where(#__ALL__):checked)) fieldset[class*="group-"] { 
                display: none;
            }
            
            ${resultDisplay.tables.map(({ name }) => `
                body:has(input[value="${name}"]:checked) .group-${name}
            `).join(', ')} {
                display: block;
            }
            
            td:has(meta[name="rarity"][content="COMMON"]) {
                background: #97aeb820;
            }
            
            td:has(meta[name="rarity"][content="RARE"]) {
                background: #8cbaff20;
            }
            
            td:has(meta[name="rarity"][content="EPIC"]) {
                background: #c48cfc20;
            }
            
            td:has(meta[name="rarity"][content="LEGENDARY"]) {
                background: #ffd75e20;
            }
            
            td:has(meta[name="rarity"][content="SEASON"]) {
                background: #ff5e7620;
            }
        </style>
        `;
    }

    private makeHtml(resultDisplay: PublisherResultDisplay): string {
        return `
${this.makeStyles(resultDisplay)}
<h2>
${[
            'Shadow Fight: Arena entities viewer',
            `Configs version: <code>${resultDisplay.version}</code>`,
            resultDisplay.branch ? `Branch: <code>${resultDisplay.branch}</code>` : false,
            `Update date: <code>${resultDisplay.updateDate}</code>`,
        ].filter(Boolean).join(' | ')}
</h2>
<fieldset>
    <legend>Settings</legend>
    <p style="display: flex; justify-content: flex-start; gap: 0.4rem 1rem; flex-wrap: wrap">
        Images:
        <label><input type="radio" name="images" id="images_normal" checked> normal</label>
        <label><input type="radio" name="images" id="images_small"> small</label>
        <label><input type="radio" name="images"  id="images_hide"> hide</label>
    </p>
    <p style="display: flex; justify-content: flex-start; gap: 0.4rem 1rem; flex-wrap: wrap">
        Video:
        <label><input type="radio" name="video" id="video_normal">normal</label>
        <label><input type="radio" name="video" id="video_small" checked>small</label>
        <label><input type="radio" name="video"  id="video_hide">hide</label>
    </p>
    <p style="display: flex; justify-content: flex-start; gap: 0.4rem 1rem; flex-wrap: wrap">
        Category:
        <label>
            <input type="radio" id="__ALL__" name="group" value="__ALL__" checked> ALL
        </label>
    ${resultDisplay.tables.map(({ name }) => `
        <label>
            <input type="radio" id="${name}" name="group" value="${name}"> ${name}
        </label>
    `).join('')}    
    </p>
</fieldset>
${resultDisplay.tables.map(({ name, table }) => {
    const [thead, ...tbody] = table;
    return `
    <fieldset class="group-${name}">
        <legend><h4>${name}</h4></legend>
        <table>
            <thead>
                <tr>
                    ${thead.map(col => `<th>${col}</th>`).join('')}
                </tr>
            </thead>
            <tbody>
                ${tbody.map(row => `<tr>
                    ${row.map(col => `<td>${col}</td>`).join('')}
                </tr>`).join('')}
            </tbody>
        </table>
    </fieldset>
    `;    
}).join('')}
`
    }

    public async build() {
        const resultDisplay = await this.displayTables();
        const html = this.makeHtml(resultDisplay);
        fs.writeFileSync(path.resolve(__dirname, `report.html`), html);
    }
}