const { execSync }: typeof import('node:child_process') = require('node:child_process');
const path: typeof import('node:path') = require('node:path');
const fs: typeof import('node:fs') = require('node:fs');

const sharp: typeof import('sharp') = require('sharp');

class Publisher {
    constructor(entityDataExtractors: Record<Entity, EntityData<unknown>>) {
        this.entities = Object.keys(entityDataExtractors) as Array<Entity>;

        this.result = {
            updateDate: this.getDate(),
            version: this.getVersion(),
            branch: this.getBranch(),
            tables: this.entities.map(entity => ({
                name: entity,
                table: this.makeTable(entityDataExtractors[entity]),
            })),
        }

        this.localization = Object.fromEntries(this.LOCALIZATIONS_NAMES.map(locatizationName => [
            locatizationName,
            parseLocalizationFile(
                path.resolve(__dirname, '..', '..', 'localizations', `${locatizationName}.bytes`),
                path.resolve(__dirname, '../../localizations/utils/LocalizationDTO.proto')
            ),
        ]));
    }

    protected readonly entities: Array<Entity>;

    protected readonly localization: Record<ArrayValues<Publisher['LOCALIZATIONS_NAMES']>, Record<string, string>>;

    public readonly result: PublisherResultData;

    private getDate(): string {
        return new Date().toISOString();
    }

    private getVersion(): string {
        const versionFile = fs.readFileSync(path.resolve(__dirname, '..', '..', 'version.json'), 'utf8');
        const versionObject = JSON.parse(versionFile);
        return versionObject.cur;
    }

    protected getBranch(): string | null {
        const cwd = process.cwd();
        return execSync('git rev-parse --abbrev-ref HEAD', { cwd }).toString().trim();
    }

    private makeTable<T>(entityData: EntityData<T>) {
        const columnDescriptors: Array<DataColumn<T>> = [
            { title: 'ID', getValue: entityData.getItemId },
            !entityData.noCode && { title: 'Code', getValue: entityData.getItemCode },
            ...entityData.getColumns(),
        ].filter(Boolean);
        return [
            columnDescriptors.map(descriptor => descriptor.title),
            ...entityData.getItems().map(item => columnDescriptors.map(descriptor => descriptor.getValue(item)))
        ]
    }

    private async resolveCell(col: DataValue, entity: Entity): Promise<string | { rarity: string; value: string }> {
        if (typeof col === 'string') {
            return col
        }
        if (typeof col === 'number') {
            return col.toString(10)
        }
        switch (col.type) {
            case 'alias': {
                return this.resolveAlias(col.value)
            }
            case 'asset': {
                return this.resolveAsset(col.value, entity)
            }
            case 'color': {
                return this.resolveColor(col.value)
            }
            case 'rarity': {
                return this.resolveRarity(col.value)
            }
            case 'hero': {
                return this.resolveHero(col.value)
            }
            case 'vimeo': {
                return this.resolveVimeo(col.value)
            }
            case 'gif': {
                return this.resolveGif(col.value, entity)
            }
        }
    }

    public async displayTables(): Promise<PublisherResultDisplay> {
        const tables = await Promise.all(
            this.result.tables.map(async ({ table, ...rest }) => ({
                ...rest,
                table: await Promise.all(
                    table.map(row => Promise.all(row.map(col => this.resolveCell(col, rest.name))))
                ),
            }))
        );

        return { ...this.result, tables };
    }

    public resolveGif(gifData: null | { filename: string, path: string }, entity: Entity): string | Promise<string> {
        return gifData?.filename ?? '—';
    }

    public resolveRarity(rarity: string): string | { rarity: string; value: string } {
        return rarity;
    }

    public resolveHero(heroId: number): string | { rarity: string; value: string } {
        return heroesMap.get(heroId).Name;
    }

    public resolveAlias(alias: string): string {
        return `alias: ${alias}`;
    }

    public resolveAsset(asset: string, entity: Entity): string | Promise<string> {
        return this.resolveAssetPath(asset);
    }

    public resolveVimeo(videoId: number) {
        return `https://vimeo.com/${videoId}`;
    }

    public resolveAssetPath(asset: string): string {
        return path.resolve(Publisher.ASSETS_PATH, asset);
    }

    public resolveColor(color: string): string {
        return color;
    }

    public async resolveAssetAsBase64Jpg(
        asset: string,
        settings: { quality?: number, maxWidth?: number, maxHeight?: number } = {}
    ): Promise<string> {
        const { quality = 60, maxWidth = 300, maxHeight = 300 } = settings;
        const assetPath = this.resolveAssetPath(asset);
        const buffer = await sharp(assetPath)
            .resize({
                width: maxWidth,
                height: maxHeight,
                fit: 'inside',
                withoutEnlargement: true,
            })
            .jpeg({ quality })
            .toBuffer();
        return buffer.toString('base64');
    }

    public readonly LOCALIZATIONS_NAMES = [
        'ChineseSimplified',
        'ChineseTraditional',
        'English',
        'French',
        'German',
        'Indonesian',
        'Italian',
        'Japanese',
        'Korean',
        'Portuguese',
        'Russian',
        'Spanish',
        'Thai',
        'Turkish',
        'Vietnamese',
    ]

    public static readonly ASSETS_PATH = (() => {
        const ASSETS_PATH = process.env.CLIENT_ASSETS_GAME_CONTENT_PATH;

        if (!ASSETS_PATH) {
            throw new Error('Please fill CLIENT_ASSETS_GAME_CONTENT_PATH env variable');
        }

        return ASSETS_PATH;
    })()
}