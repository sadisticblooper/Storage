async function entryPoint() {
    const entityEmoji = new EntityEmoji({ images: 'animated' });
    await entityEmoji.makeGifs();

    const entityDataExtractors: Record<Entity, EntityData<unknown>> = {
        [Entity.CURRENCY]: new EntityCurrency(),
        [Entity.CHEST]: new EntityChests(),
        [Entity.HERO]: new EntiryHeroes(),
        [Entity.WEAPON]: new EntityWeapons(),
        [Entity.SKIN]: new EntitySkins(),
        [Entity.TAUNT]: new EntityTaunts(),
        [Entity.EMOJI]: entityEmoji,
        [Entity.STANCE]: new EntityStances(),
        [Entity.TEXT_EMOJI_PACK]: new EntityTextEmojiPacks(),
        [Entity.CUSTOMIZATION_SHARD]: new EntityCustomizationShards(),
        [Entity.ROGUELIKE_MODIFIER]: new EntityRoguelikeModifiers(),
    }

    const confluenceDocsPublisher = new PublisherColnfuenceDocs(entityDataExtractors);
    await confluenceDocsPublisher.build();
}

entryPoint();