const { readFile } = require("node:fs/promises");

type ConfluencePage = {
    id: string;
    type: string;
    title: string;
    version: {
        number: number;
    };
};

type ConfluenceAttachment = {
    id: string;
    title: string;
};

class Semaphore {
    private active = 0;
    private readonly queue: Array<() => void> = [];

    constructor(private readonly limit: number) {}

    public async run<T>(task: () => Promise<T>): Promise<T> {
        if (this.active >= this.limit) {
            await new Promise<void>(resolve => this.queue.push(resolve));
        }
        this.active++;
        try {
            return await task();
        } finally {
            this.active--;
            this.queue.shift()?.();
        }
    }
}

class PublisherColnfuenceDocs extends Publisher {
    constructor(entityDataExtractors: Record<Entity, EntityData<unknown>>) {
        super(entityDataExtractors);
    }

    private readonly attachmentUploads = new Map<string, Promise<boolean>>();

    private readonly uploadSemaphore = new Semaphore(1);

    protected getBranch(): string | null {
        const branch = super.getBranch();
        return ['prod', 'develop56'].includes(branch) ? null : branch;
    }

    public resolveColor(color: string): string {
        return `<span class="color" style="background: ${color}">${color}</span>`;
    }

    public async resolveGif(gifData: null | { filename: string, path: string }, entity: Entity): Promise<string> {
        if (!gifData) {
            return '';
        }

        const pageId = PublisherColnfuenceDocs.pageIds[entity];
        const attachmentFilename = gifData.filename.replace(/[\/\\]/g, '__');

        let upload = this.attachmentUploads.get(attachmentFilename);
        if (!upload) {
            const assetPath = path.resolve(gifData.path, gifData.filename);
            upload = this.uploadAssetIfExists(assetPath, pageId, attachmentFilename);
            this.attachmentUploads.set(attachmentFilename, upload);
        }
        const uploaded = await upload;
        if (!uploaded) {
            return `❓`;
        }

        const escapedFilename = this.escapeAssetFilename(attachmentFilename);
        return `<ac:image ac:width="200"><ri:attachment ri:filename="${escapedFilename}" /></ac:image>`;
    }

    public async resolveAsset(asset: string, entity: Entity): Promise<string> {
        if (!asset) {
            return '';
        }

        const pageId = PublisherColnfuenceDocs.pageIds[entity];
        const attachmentFilename = asset.replace(/[\/\\]/g, '__');

        let upload = this.attachmentUploads.get(attachmentFilename);
        if (!upload) {
            const assetPath = this.resolveAssetPath(asset);
            upload = this.uploadAssetIfExists(assetPath, pageId, attachmentFilename);
            this.attachmentUploads.set(attachmentFilename, upload);
        }
        const uploaded = await upload;
        if (!uploaded) {
            return `❓`;
        }

        const escapedFilename = this.escapeAssetFilename(attachmentFilename);
        return `<ac:image ac:width="200"><ri:attachment ri:filename="${escapedFilename}" /></ac:image>`;
    }

    private async uploadAssetIfExists(assetPath: string, pageId: string, attachmentFilename: string): Promise<boolean> {
        let buffer: Buffer;
        try {
            buffer = await readFile(assetPath);
        } catch {
            return false;
        }
        await this.uploadSemaphore.run(() => this.upsertAttachment(pageId, attachmentFilename, buffer));
        return true;
    }

    private async upsertAttachment(pageId: string, filename: string, assetBuffer: Buffer): Promise<void> {
        const existing = await this.findAttachment(pageId, filename);
        if (existing) {
            return;
        }

        const url = `${PublisherColnfuenceDocs.CONFLUENCE_URL}/rest/api/content/${pageId}/child/attachment`;
        const form = new FormData();
        form.append("file", new File([assetBuffer], filename));

        await this.api(url, {
            method: "POST",
            headers: { "X-Atlassian-Token": "nocheck" },
            body: form,
        });
    }

    private async findAttachment(pageId: string, filename: string): Promise<ConfluenceAttachment | null> {
        const url = `${PublisherColnfuenceDocs.CONFLUENCE_URL}/rest/api/content/${pageId}/child/attachment?filename=${encodeURIComponent(filename)}`;
        const response: { results: Array<ConfluenceAttachment> } = await this.api(url);
        return response.results[0] ?? null;
    }

    private escapeAssetFilename(filename: string): string {
        return filename.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    }

    public resolveAlias(alias: string): string {
        return [
            'English',
            'Russian',
        ].map(locale => this.localization[locale][alias]).join('<br />');
    }

    public resolveVimeo(videoId: number): string {
        if (!videoId) {
            return `—`;
        }
        return `
            <ac:structured-macro ac:name="widget">
              <ac:parameter ac:name="url"><ri:url ri:value="https://vimeo.com/${videoId}" /></ac:parameter>
              <ac:parameter ac:name="width">320</ac:parameter>
              <ac:parameter ac:name="height">180</ac:parameter>
            </ac:structured-macro>
            <br />
            <a href="https://vimeo.com/${videoId}">vimeo</a>
        `;
    }

    public resolveRarity(rarity: string): { rarity: string; value: string } {
        return {
            rarity: rarity,
            value: rarity,
        };
    }

    public resolveHero(heroId: number): { rarity: string; value: string } {
        const hero = heroesMap.get(heroId);
        return {
            rarity: HERO_RARITY[hero.Rarity],
            value: hero.Name,
        };
    }

    private makeXhtml(
        resultMeta: Omit<PublisherResultDisplay, 'tables'>,
        table: ArrayValues<PublisherResultDisplay['tables']>['table'],
    ): string {
        const colorsByRarity = {
            COMMON: '#c1c7d0',
            RARE: '#deebff',
            EPIC: '#eae6ff',
            LEGENDARY: '#fff0b3',
            SEASON: '#ffebe6',
        }
        const [thead, ...tbody] = table;
        return `
            <h3>
                ${[
                    `Version: <code>${resultMeta.version}</code>`,
                    resultMeta.branch ? `Branch: <code>${resultMeta.branch}</code>` : false,
                    `Updated: <code>${resultMeta.updateDate}</code>`,
                ].filter(Boolean).join('<br />')}
            </h3>
            <table>
                <thead>
                    <tr>
                        ${thead.map(col => `<th>${col}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>
                    ${tbody.map(row => `<tr>
                        ${row.map(col => {
                            if (typeof col === 'string') {
                                return `<td>${col}</td>`;
                            }
                            const color = colorsByRarity[col.rarity];
                            return `<td class="highlight-${color}" data-highlight-colour="${color}">${col.value}</td>`
                        }).join('')}
                    </tr>`).join('')}
                </tbody>
            </table>
        `
    }

    public async build() {
        const resultDisplay = await this.displayTables();
        const tablesByEntity = this.getTablesByEntity(resultDisplay);
        for (const entity of this.entities) {
            const pageId = PublisherColnfuenceDocs.pageIds[entity];
            const page = await this.getConfluencePage(pageId);
            const table = tablesByEntity[entity];
            const xhtml = this.makeXhtml(resultDisplay, table);
            await this.updateConfluencePage(page, xhtml);
            console.log(`Обновлено успешно: ${entity}`);
        }
    }

    private getTablesByEntity(resultDisplay: PublisherResultDisplay): Record<Entity, ArrayValues<PublisherResultDisplay['tables']>['table']> {
        return Object.fromEntries(resultDisplay.tables.map(({ name, table }) => {
           return [name, table];
        })) as Record<Entity, ArrayValues<PublisherResultDisplay['tables']>['table']>;
    }

    private async api(url: string, options: RequestInit = {}) {
        const authHeaders = { Authorization: `Bearer ${PublisherColnfuenceDocs.PAT_CONFLUENCE}` };
        const res = await fetch(url, {
            ...options,
            headers: { ...authHeaders, ...(options.headers ?? {}) },
        });
        if (!res.ok) {
            const text = await res.text().catch(() => "");
            throw new Error(`${options.method ?? "GET"} ${url} → ${res.status}\n${text}`);
        }
        return res.json();
    }

    private getConfluencePage(pageId: string): Promise<ConfluencePage> {
        return this.api(`${PublisherColnfuenceDocs.CONFLUENCE_URL}/rest/api/content/${pageId}?expand=body.storage,version`);
    }

    private updateConfluencePage(page: ConfluencePage, xhtml: string): Promise<unknown> {
        return this.api(`${PublisherColnfuenceDocs.CONFLUENCE_URL}/rest/api/content/${page.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id: page.id,
                type: page.type,
                title: page.title,
                version: { number: page.version.number + 1 },
                body: {
                    storage: { value: xhtml, representation: "storage" },
                },
            }),
        });
    }

    private static readonly pageIds: Record<Entity, string> = {
        [Entity.CURRENCY]: '199444200',
        [Entity.CHEST]: '199444395',
        [Entity.HERO]: '199444397',
        [Entity.WEAPON]: '199444399',
        [Entity.SKIN]: '199444401',
        [Entity.TAUNT]: '199444404',
        [Entity.STANCE]: '199444406',
        [Entity.EMOJI]: '199444408',
        [Entity.TEXT_EMOJI_PACK]: '199444410',
        [Entity.CUSTOMIZATION_SHARD]: '199444412',
        [Entity.ROGUELIKE_MODIFIER]: '199444414',
    }

    private static readonly PAT_CONFLUENCE = (() => {
        const TOKEN = process.env.PAT_CONFLUENCE;
        if (!TOKEN) {
            throw new Error('Please fill PAT_CONFLUENCE env variable');
        }
        return TOKEN;
    })();

    private static readonly CONFLUENCE_URL = 'https://docs.nekki.com';
}
