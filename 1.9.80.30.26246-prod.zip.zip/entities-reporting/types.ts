enum Entity {
    CURRENCY = 'CURRENCY',
    CHEST = 'CHEST',
    HERO = 'HERO',
    WEAPON = 'WEAPON',
    SKIN = 'SKIN',
    TAUNT = 'TAUNT',
    EMOJI = 'EMOJI',
    STANCE = 'STANCE',
    TEXT_EMOJI_PACK = 'TEXT_EMOJI_PACK',
    CUSTOMIZATION_SHARD = 'CUSTOMIZATION_SHARD',
    ROGUELIKE_MODIFIER = 'ROGUELIKE_MODIFIER',
}

type ArrayValues<T extends readonly unknown[]> = T[number];

type DataValue =
    | number
    | string
    | { type: 'alias', value: string }
    | { type: 'color', value: string }
    | { type: 'vimeo', value: number }
    | { type: 'rarity', value: string }
    | { type: 'gif', value: null | { filename: string, path: string } }
    | { type: 'hero', value: number }
    | { type: 'asset', value: string };

type DataColumn<T> = {
    title: string;
    getValue: (item: T) => DataValue;
}

interface EntityData<T> {
    getItems: () => T[];
    getItemId: (item: T) => number;
    getItemCode: (item: T) => DataValue;
    getColumns: () => Array<DataColumn<T>>;
    noCode?: boolean;
}

type PublisherResult<TCellValue> = {
    updateDate: string;
    version: string;
    branch: string | null;
    tables: Array<{
        name: Entity;
        table: Array<Array<TCellValue>>;
    }>
}
type PublisherResultData = PublisherResult<DataValue>;
type PublisherResultDisplay = PublisherResult<string | { rarity: string; value: string }>;
