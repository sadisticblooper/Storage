function getEntityReleaseDate(entity: Entity, id: number): string | null {
    if (entity !== Entity.WEAPON) {
        throw new Error(`getEntityReleaseDate: неподдерживаемая сущность ${entity}`);
    }

    const fs: typeof import('node:fs') = require('node:fs');
    const path: typeof import('node:path') = require('node:path');

    const versionsDir = path.resolve(__dirname, '..', 'versions');
    const weaponsVersions: Record<string, string | null> = JSON.parse(
        fs.readFileSync(path.join(versionsDir, 'weapons-versions.json'), 'utf8')
    );
    const versionToCommit: Record<string, { commit: string, date: string }> = JSON.parse(
        fs.readFileSync(path.join(versionsDir, 'version-to-commit.json'), 'utf8')
    );

    if (!(id in weaponsVersions)) {
        throw new Error(`Please add weapon ID ${id} with version`);
    }

    const weaponVersion = weaponsVersions[id];

    if (weaponVersion === null) {
        return null;
    }

    if (!(weaponVersion in versionToCommit)) {
        throw new Error(`Please fill date for version ${weaponVersion}`);
    }

    return versionToCommit[weaponVersion].date;
}
