class EntityTaunts implements EntityData<Taunt & { Name: string }> {
    public getItems(): Array<Taunt & { Name: string }> {
        return Object.values(tauntsMap.getValues());
    }

    public getItemId(item: Taunt & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: Taunt & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<Taunt & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.Settings.NameAlias,
                }),
            },
            {
                title: 'Alias',
                getValue: (item) => item.Settings.NameAlias,
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.Settings.configsOrder,
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: TAUNT_RARITY[item.Settings.Rarity],
                }),
            },
            {
                title: 'Hero Owners',
                getValue: (item) => {
                    if (item.Settings.OwnerHeroes.length === 0) {
                        return 'Any';
                    }
                    if (item.Settings.OwnerHeroes.length === 1) {
                        return {
                            type: 'hero',
                            value: item.Settings.OwnerHeroes[0],
                        }
                    }
                    return item.Settings.OwnerHeroes.map(heroId => heroesMap.get(heroId).Name).join(', ')
                }
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/Heroes/${item.Settings.Icon}.png`,
                }),
            },
            {
                title: 'Video',
                getValue: (item) => ({
                    type: 'vimeo',
                    value: item.Settings.VideoId,
                }),
            },
        ];
    }
}
