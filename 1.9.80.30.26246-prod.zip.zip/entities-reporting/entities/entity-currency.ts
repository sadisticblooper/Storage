class EntityCurrency implements EntityData<ICurrencySettings & { id: number }> {
    public getItems(): Array<ICurrencySettings & { id: number }> {
        return Object.entries(currencySettings).map(([id, currencySettings]) => ({
            ...currencySettings,
            id: Number(id),
        }));
    }

    public getItemId(item: ICurrencySettings & { id: number }): number {
        return item.id;
    }

    public getItemCode(item: ICurrencySettings & { id: number }): string {
        return item.alias;
    }

    public getColumns(): Array<DataColumn<ICurrencySettings>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.alias,
                }),
            },
            {
                title: 'Color',
                getValue: (item) => ({
                    type: 'color',
                    value: item.color,
                }),
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `${item.bigIcon}.png`,
                }),
            },
        ];
    }
}
