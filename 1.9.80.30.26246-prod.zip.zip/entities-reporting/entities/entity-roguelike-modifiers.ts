class EntityRoguelikeModifiers implements EntityData<BuffModifier & { Name: string }> {
    public getItems(): Array<BuffModifier & { Name: string }> {
        return Object.values(buffModifiersMap.getValues());
    }

    public getItemId(item: BuffModifier & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: BuffModifier & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<BuffModifier & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.name,
                }),
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `${item.icon}.png`,
                }),
            },
        ];
    }
}
