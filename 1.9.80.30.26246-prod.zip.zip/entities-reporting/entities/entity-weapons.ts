class EntityWeapons implements EntityData<HeroWeapon & { Name: string }> {
    public getItems(): Array<HeroWeapon & { Name: string }> {
        return Object.values(weaponsMap.getValues());
    }

    public getItemId(item: HeroWeapon & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: HeroWeapon & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<HeroWeapon & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.Settings.Alias
                }),
            },
            {
                title: 'Alias',
                getValue: (item) => item.Settings.Alias,
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.Settings.configsOrder,
            },
            {
                title: 'Release Date',
                getValue: (item) => getEntityReleaseDate(Entity.WEAPON, item.ID) ?? '—',
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: HERO_WEAPON_RARITY[item.Settings.Rarity],
                }),
            },
            {
                title: 'Hero Owner',
                getValue: (item) => ({
                    type: 'hero',
                    value: item.Settings.HeroOwner,
                }),
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/Weapons/${item.Settings.Icon}.png`,
                }),
            },
        ];
    }
}
