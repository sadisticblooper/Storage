class EntityTextEmojiPacks implements EntityData<TextEmojiPack & { Name: string }> {
    public getItems(): Array<TextEmojiPack & { Name: string }> {
        return Object.values(textEmojiPacksMap.getValues());
    }

    public getItemId(item: TextEmojiPack & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: TextEmojiPack & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<TextEmojiPack & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.nameAlias,
                }),
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: TEXT_EMOJI_PACK_RARITY[item.rarity],
                }),
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.configsOrder,
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/TextEmoji/PackPreviews/${item.icon}.png`,
                }),
            },
        ];
    }
}
