const os: typeof import('os') = require('node:os');
const fsPromises: typeof import('fs/promises') = require('fs/promises');

class EntityEmoji implements EntityData<Emoji & { Name: string }> {
    constructor(private readonly options: { images: 'static' | 'animated' }) {}

    private readonly codeById = Object.fromEntries(Object.entries(emoji).map(([code, emoji]) => [emoji.ID, code]));

    private gifsExistById: Record<string, boolean> = {};

    public getItems(): Array<Emoji & { Name: string }> {
        return Object.values(emojiMap.getValues());
    }

    public getItemId(item: Emoji & { Name: string }): number {
        return item.ID;
    }

    public getItemCode = (item: Emoji & { Name: string }): string => {
        // Emoji#Name is settings.name, not code from original `emoji`
        return this.codeById[item.ID];
    }

    public async makeGifs() {
        const gifsExistById = {};

        const emojiFolderByCode = {
            Universal_Dynasty: 'Universal_Faction_Dynasty',
            Universal_Heralds: 'Universal_Faction_Heralds',
            Universal_Legion: 'Universal_Faction_Legion',
            HongJoo_cracker: 'HongJu_Cracker',
            HongJoo_ChefsKiss: 'HongJu_ChefsKiss',
        }

        for (let item of this.getItems()) {
            const code = this.getItemCode(item);
            const emojiFolder = emojiFolderByCode[code] ?? code;
            const pathToFrames = path.resolve(Publisher.ASSETS_PATH, 'Sprites/PreviewImages/Emoji', emojiFolder);

            const gifname = `${code}.gif`;
            if (!fs.existsSync(path.resolve(EntityEmoji.EMOJI_GIF_OUTPUT, gifname))) {
                await this.makeGif(pathToFrames, EntityEmoji.EMOJI_GIF_OUTPUT, gifname);
            }
            gifsExistById[item.ID] = true;
        }

        this.gifsExistById = gifsExistById;
    };

    private async makeGif(source: string, dest: string, gifName: string): Promise<void> {
        const entries = await fsPromises.readdir(source);
        const inputPaths = entries
            .map((file) => {
                const m = file.match(/(\d+)\.png$/i);
                return m ? { file, num: parseInt(m[1], 10) } : null;
            })
            .filter(Boolean)
            .sort((a, b) => a.num - b.num)
            .map((f) => path.join(source, f.file));

        const delays = new Array(inputPaths.length).fill(42);
        delays[0] = 2000;
        await sharp(inputPaths, { join: { animated: true } })
            .gif({
                delay: delays,
                loop: 0,
            })
            .toFile(path.join(dest, gifName));
    }

    public getColumns(): Array<DataColumn<Emoji & { Name: string }>> {
        return [
            {
                title: 'Hero',
                getValue: (item) => {
                    if (!item.Settings.heroId) {
                        return 'Any'
                    }
                    return {
                        type: 'hero',
                        value: item.Settings.heroId,
                    }
                }
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.Settings.configsOrder,
            },
            this.options.images === 'animated'
                ? {
                    title: 'Animation',
                    getValue: (item) => ({
                        type: 'gif',
                        value: this.gifsExistById[item.ID]
                            ? { filename: `${this.getItemCode(item)}.gif`, path: EntityEmoji.EMOJI_GIF_OUTPUT }
                            : null,
                    }),
                }
                : {
                    title: 'Image',
                    getValue: (item) => ({
                        type: 'asset',
                        value: `Sprites/PreviewImages/Emoji/AllPreview/${item.Settings.animation}.png`,
                    }),
                },
        ];
    }

    public static readonly EMOJI_GIF_OUTPUT = (() => {
        const OUTPUT = process.env.EMOJI_GIF_OUTPUT;

        if (!OUTPUT) {
            throw new Error('Please fill EMOJI_GIF_OUTPUT env variable');
        }

        return OUTPUT;
    })()
}
