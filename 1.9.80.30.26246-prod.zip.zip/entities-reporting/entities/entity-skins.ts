class EntitySkins implements EntityData<Skin & { Name: string }> {
    public getItems(): Array<Skin & { Name: string }> {
        return Object.values(skinsMap.getValues());
    }

    public getItemId(item: Skin & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: Skin & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<Skin & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.AliasName,
                })
            },
            {
                title: 'Alias',
                getValue: (item) => item.AliasName,
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.configsOrder,
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: SKIN_RARITY[item.Rarity],
                }),
            },
            {
                title: 'Hero Owner',
                getValue: (item) => ({
                    type: 'hero',
                    value: item.OwnerHeroID,
                })
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/Heroes/${item.BigAvatar}.png`,
                }),
            },
        ];
    }
}
