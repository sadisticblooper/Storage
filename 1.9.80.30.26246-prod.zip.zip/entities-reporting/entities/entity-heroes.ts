class EntiryHeroes implements EntityData<Hero & { Name: string }> {
    public getItems(): Array<Hero & { Name: string }> {
        return Object.values(heroesMap.getValues());
    }

    public getItemId(item: Hero & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: Hero & { Name: string }): DataValue {
        return ({
            type: 'hero',
            value: item.ID,
        });
    }

    public getColumns(): Array<DataColumn<Hero & { Name: string }>> {
        return [
            {
                title: 'Display Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.Alias,
                }),
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: HERO_RARITY[item.Rarity],
                }),
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/Heroes/${item.Icon}.png`,
                }),
            },
            {
                title: 'Video',
                getValue: (item) => ({
                    type: 'vimeo',
                    value: item.VideoId,
                }),
            },
        ];
    }
}
