class EntityChests implements EntityData<Chest & { Name: string }> {
    constructor(options: { filterItems?: (item: Chest & { Name: string }) => boolean } = {}) {
        this.filterItems = options.filterItems;
    }

    private readonly filterItems?: (item: Chest & { Name: string }) => boolean;

    public getItems(): Array<Chest & { Name: string }> {
        const items = Object.values(chestsMap.getValues());

        if (!this.filterItems) {
            return items;
        }

        return items.filter(this.filterItems);
    }

    public getItemId(item: Chest & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: Chest & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<Chest & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.Alias,
                }),
            },
            {
                title: 'Type',
                getValue: (item) => CHEST_TYPE[item.Type],
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `${item.Icon}.png`,
                }),
            },
        ];
    }
}
