class EntityCustomizationShards implements EntityData<ICustomizationShardsData & { Name: string }> {
    public readonly noCode = true;

    public getItems(): Array<ICustomizationShardsData & { Name: string }> {
        return Object.values(customizationShardsMap.getValues());
    }

    public getItemId(item: ICustomizationShardsData & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: ICustomizationShardsData & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<ICustomizationShardsData & { Name: string }>> {
        return [
            {
                title: 'Customization',
                getValue: (item) => CUSTOMIZATION[item.customizationType],
            },
            {
                title: 'Customization Id',
                getValue: (item) => item.entityId,
            },
            {
                title: 'Customization Code',
                getValue: (item) => {
                    const map = CustomizationUtils.getOrderMap(item.customizationType)
                    return map.get(item.entityId).Name;
                },
            },
        ];
    }
}
