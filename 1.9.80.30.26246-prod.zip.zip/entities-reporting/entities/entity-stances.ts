class EntityStances implements EntityData<Stance & { Name: string }> {
    public getItems(): Array<Stance & { Name: string }> {
        return Object.values(stancesMap.getValues());
    }

    public getItemId(item: Stance & { Name: string }): number {
        return item.ID;
    }

    public getItemCode(item: Stance & { Name: string }): string {
        return item.Name;
    }

    public getColumns(): Array<DataColumn<Stance & { Name: string }>> {
        return [
            {
                title: 'Name',
                getValue: (item) => ({
                    type: 'alias',
                    value: item.Settings.AliasName,
                }),
            },
            {
                title: 'Alias',
                getValue: (item) => item.Settings.AliasName,
            },
            {
                title: 'Configs Order',
                getValue: (item) => item.Settings.configsOrder,
            },
            {
                title: 'Type',
                getValue: (item) => STANCE_TYPE[item.Settings.StanceType],
            },
            {
                title: 'Rarity',
                getValue: (item) => ({
                    type: 'rarity',
                    value: STANCE_RARITY[item.Settings.Rarity],
                }),
            },
            {
                title: 'Hero Owners',
                getValue: (item) => {
                    if (item.Settings.OwnerHeroes.length === 0) {
                        return 'Any';
                    }
                    if (item.Settings.OwnerHeroes.length === 1) {
                        return {
                            type: 'hero',
                            value: item.Settings.OwnerHeroes[0],
                        }
                    }
                    return item.Settings.OwnerHeroes.map(heroId => heroesMap.get(heroId).Name).join(', ')
                },
            },
            {
                title: 'Image',
                getValue: (item) => ({
                    type: 'asset',
                    value: `Sprites/PreviewImages/Heroes/${item.Settings.Icon}.png`,
                }),
            },
            {
                title: 'Video',
                getValue: (item) => ({
                    type: 'vimeo',
                    value: item.Settings.VideoId,
                }),
            },
        ];
    }
}
