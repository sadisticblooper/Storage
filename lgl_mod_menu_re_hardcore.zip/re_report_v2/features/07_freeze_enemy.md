# Feature 7 — Freeze Enemy

| | |
|---|---|
| **Menu row** | `7_Toggle_Freeze Enemy` |
| **Widget** | Toggle |
| **`Changes()` id** | `7` |
| **Flag** | `bss+0x188` |
| **Apply** | worker `0x11fe8`, block at `0x12150` |

## Handler — verified

```
0000e67c:  tst   w6, #0xff
0000e680:  and   w8, w6, #0xff
0000e684:  cset  w9, ne
0000e688:  adrp  x10, #0xcb000
0000e68c:  strb  w9, [x10, #0x188]     ; bss+0x188 = enable
0000e690:  cbnz  w8, #0xf3f4           ; turning ON -> just store
```

Turning the feature **off** runs one extra action: an immediate one-shot sweep
over the current entity list.

```
0000e694:  adrp  x8, #0xcb000
0000e698:  ldrb  w8, [x8, #0x17c]      ; scan active?
0000e69c:  cmp   w8, #1
0000e6a0:  b.ne  #0xf3f4
0000e6a4:  adrp  x0, #0xcb000
0000e6a8:  add   x0, x0, #0xc8
0000e6ac:  bl    #0x3ff1c              ; lock
0000e6b0:  adrp  x8, #0xcb000
0000e6b4:  add   x8, x8, #0x118
0000e6b8:  ldp   x20, x21, [x8]        ; entity list begin/end
0000e6bc:  cmp   x20, x21
0000e6c0:  b.eq  #0xe6f4
0000e6c4:  adrp  x19, #0xcb000
0000e6c8:  add   x19, x19, #0x70
0000e6cc:  ldr   x23, [x20], #8
0000e6d0:  bl    #0xbec0               ; getpid()
0000e6d8:  sub   x2, x23, #0x1a8        ; target = entity - 0x1A8
0000e6dc:  mov   w1, #0x100000          ; value = 0x100000
0000e6e0:  mov   x0, x19
0000e6e4:  mov   w3, wzr
0000e6e8:  bl    #0x1d108              ; write
0000e6ec:  cmp   x21, x20
0000e6f0:  b.ne  #0xe6cc               ; next entity
0000e6f4:  bl    #0x3ff40              ; unlock
```

## Apply — verified, inside the worker `0x11fe8`

```
00012150:  adrp  x8, #0xcb000
00012154:  ldrb  w8, [x8, #0x188]      ; freeze enemy?
00012158:  cbz   w8, #0x12174
0001215c:  bl    #0xbec0               ; getpid()
00012160:  sub   x2, x26, #0x1a8        ; target = entity - 0x1A8
00012164:  mov   x0, x20
00012168:  mov   w1, wzr               ; value = 0
0001216c:  mov   w3, wzr
00012170:  bl    #0x1d108              ; write
```

## Exact modification

Two distinct operations:

| When | Field | Value |
|---|---|---|
| While enabled (worker, every pass) | `entity + 0x1F78A50` | `0x100000` |
| On transition to disabled (one-shot) | `entity - 0x1A8` | `0x100000` |

**The worker block writes `entity + 0x1F78A50` (the same field as Immortal),
while the disable sweep writes `entity - 0x1A8`.** An earlier version of this
report attributed the `entity - 0x1A8` write to the run-time path; it actually
happens only on the off-transition.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe67c` |
| Flag | `bss+0x188` |
| Disable sweep | `0xe6cc` … `0xe6f0` |
| Sweep field / value | `entity-0x1A8` = `0x100000` |
| Worker block | `0x12150` |
| Worker write | `0x1d108` at `0x12170` |
| Worker field | `entity + 0x1F78A50` = `0x100000` |
