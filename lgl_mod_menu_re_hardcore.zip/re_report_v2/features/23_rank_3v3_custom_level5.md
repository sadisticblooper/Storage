# Feature 23 — Level 5 (Custom Rank), 3v3

| | |
|---|---|
| **Menu row** | `23_CollapseAdd_InputValue_Level 5 (Custom Rank)` |
| **Widget** | Text input, inside the 3v3 collapsible group |
| **`Changes()` id** | `23` |
| **Apply** | thread `0x110d8` |

## Handler — verified

```
0000eac0:  cmp   w5, #1
0000eac4:  b.lt  #0xf3f4               ; no value typed -> ignore
0000eac8:  adrp  x1, #0x11000
0000eacc:  add   x1, x1, #0xd8         ; -> 0x110d8 (same thread as id 21)
0000eacc:  ...
0000ead8:  bl    #0x11300              ; thread start, value forwarded
0000eadc:  add   x0, sp, #0x18
0000eae0:  bl    #0x41b40
0000eae4:  b     #0xf3ec
```

Features 21 and 23 share the identical apply thread `0x110d8`: both format the
typed level into the match-id string and resolve it. They differ only in which
collapsible group the row belongs to (1v1 vs 3v3).

## Apply thread `0x110d8` — verified

```
000110f8:  mov   w19, w0               ; custom level
00011128:  adrp  x1, #0x9c000
0001112c:  add   x1, x1, #0x14e        ; format string
00011130:  add   x0, sp, #8
00011134:  mov   w2, w19
00011138:  bl    #0xbea0               ; snprintf
00011148:  bl    #0x1ddc0              ; lookup by formatted string
```

## Address reference

| Item | Address |
|---|---|
| Handler | `0xeac0` |
| Thread start | `0x11300` |
| Apply thread | `0x110d8` (shared with id 21) |
| Format string | `0x9c14e` |
