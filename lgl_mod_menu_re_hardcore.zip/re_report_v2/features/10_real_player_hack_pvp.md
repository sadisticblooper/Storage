# Feature 10 — Real Player Hack (PvP)

| | |
|---|---|
| **Menu row** | `10_Toggle_Real Player Hack (PvP)` |
| **Widget** | Toggle |
| **`Changes()` id** | `10` |
| **Flag** | `bss+0x194` |
| **Apply** | thread `0x15ea0` |

## Handler — verified

```
0000e8b4:  tst   w6, #0xff
0000e8b8:  cset  w8, ne
0000e8bc:  adrp  x9, #0xcb000
0000e8c0:  strb  w8, [x9, #0x194]      ; bss+0x194 = enable
0000e8c4:  b     #0xf3f4
```

## Flag consumer — verified

```
00011b40:  ldrb  w8, [x8, #0x194]      ; real player hack?
00011b44:  cbz   w8, #0x11b68
00011b50:  add   x1, x1, #0xea0        ; -> 0x15ea0
00011b54:  bl    #0x10458              ; pthread_create
```

## Apply thread `0x15ea0` — verified

```
00015fe4:  ldr   x21, [x25, #0x10]     ; entity payload
00015fe8:  bl    #0xbec0               ; getpid()
00015fec:  sub   x22, x21, #0x2c
00015ffc:  bl    #0x1cfe8              ; read64 entity-0x2c
00016008:  cmp   x23, x26              ; guard constant
0001600c:  b.ne  #0x16088
00016014:  sub   x1, x21, #0x14
00016020:  bl    #0x1cfe8              ; read64 entity-0x14
0001602c:  cmp   x23, x27              ; guard constant
00016030:  b.ne  #0x16088
00016038:  mov   w1, #0xffc8
0001603c:  movk  w1, #0x5f, lsl #16    ; value = 0x5FFFC8
00016044:  mov   x2, x21              ; target = entity + 0
0001604c:  bl    #0x1d108              ; write
00016058:  mov   w1, wzr               ; 0
0001605c:  mov   x2, x22              ; target = entity - 0x2c
00016064:  bl    #0x1d108              ; write
00016070:  mov   w1, #0x86a0
00016078:  movk  w1, #1, lsl #16       ; value = 0x186A0 = 100000
00016074:  sub   x2, x21, #0x28
00016084:  bl    #0x1d108              ; write
```

## Exact modification

When the entity's markers at `entity-0x2c` and `entity-0x14` match the expected
64-bit constants, three 32-bit writes happen:

| Field | New value |
|---|---|
| `entity + 0x00` | `0x5FFFC8` |
| `entity - 0x2c` | `0` |
| `entity - 0x28` | `0x186A0` (`100000`) |

This rewrites the player identity/owner markers so the target is treated as a
real player rather than an AI, and seeds its associated counters.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe8b4` |
| Flag | `bss+0x194` |
| Consumer | `0x11b40` |
| Apply thread | `0x15ea0` |
| Guard reads | `0x15ffc`, `0x16020` |
| Writes | `0x1604c`, `0x16064`, `0x16084` |

> **Related rows:** `10_Toggle_Real Player Hack (PvP)` and the collapsible
> `Collapse_Real Player to AI` group (GFL index 19) belong to this area. The
> group itself is a container, not a handler.
