# Feature 12 — Summon Ai Opponent

| | |
|---|---|
| **Menu row** | `12_Button_Summon Ai Opponent` |
| **Widget** | Button |
| **`Changes()` id** | `12` |
| **Flag** | none — one-shot action |
| **Apply** | thread `0x109b0` |

## Handler — verified

```
0000e954:  adrp  x1, #0x10000
0000e958:  add   x1, x1, #0x9b0        ; -> 0x109b0
0000e95c:  add   x0, sp, #0x18
0000e960:  bl    #0x10458              ; pthread_create
0000e964:  add   x0, sp, #0x18
0000e968:  bl    #0x41b40
0000e96c:  b     #0xf3ec
```

## Apply thread `0x109b0` — verified

```
000109c4:  add   x0, x0, #0xc8         ; lock
000109d0:  add   x19, x19, #0x70       ; entity list root
000109fc:  add   x8, x8, #0x848        ; decryption/name buffer
00010a74:  add   x1, x1, #0x848
00010a7c:  bl    #0x1ddc0              ; find by name
00010a90:  bl    #0x1e4bc              ; list head
00010ab8:  ldr   x2, [x21, #0x10]      ; entity payload
00010ac0:  mov   w1, wzr               ; value 0
00010ac8:  bl    #0x1d108              ; write
```

## Exact modification

The thread resolves its target by the name held in the buffer at `bss+0x848`,
iterates the resulting list, and writes **`0`** to **`entity + 0x00`** for the
located record. Because it is a button, it runs once per press and leaves no
persistent flag.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe954` |
| Apply thread | `0x109b0` |
| Name buffer | `bss+0x848` |
| Write | `0x1d108` at `0x10ac8` |
| Value | `0` |
