# Feature 15 — Enemy No Ability

| | |
|---|---|
| **Menu row** | `15_Toggle_Enemy No Ability` (GFL index 9) |
| **Widget** | Toggle |
| **`Changes()` id** | `15` |
| **Flag** | `bss+0x1a4` (`0xcb1a4`) |
| **Handler** | `0xe704` (dispatch entry at `0x700ec`) |
| **Apply** | worker `0x11fe8`, block at `0x12174` |

> **Pairing evidence** (see `14_one_hit_kill.md` for the full derivation):
> executing `Changes` with `w3 = 15` sets `0xcb1a4`; dispatch entry 14 at
> `0x700ec` holds `+0x6634` -> `0xe704`; and `0xe710` is the only `strb` to
> `0xcb1a4`. The menu label `15_Toggle_Enemy No Ability` carries id `15`.

## Handler — verified

```
0000e704:  tst   w6, #0xff
0000e708:  cset  w8, ne
0000e70c:  adrp  x9, #0xcb000
0000e710:  strb  w8, [x9, #0x1a4]      ; bss+0x1a4 = enable
0000e714:  b     #0xf3f4
```

Pure flag store — no thread is spawned, so this row relies entirely on the
always-running worker.

## Apply — verified, inside the worker `0x11fe8`

```
00012174:  adrp  x8, #0xcb000
00012178:  ldrb  w8, [x8, #0x1a4]      ; enemy no ability?
0001217c:  cbz   w8, #0x121a0
00012180:  bl    #0xbec0               ; getpid()
00012184:  mov   w8, #0x7bb8
00012188:  movk  w8, #2, lsl #16       ; w8 = 0x27BB8
0001218c:  add   x2, x26, x8           ; target = entity + 0x27BB8
00012190:  mov   x0, x20
00012194:  mov   w1, wzr               ; value = 0
00012198:  mov   w3, wzr
0001219c:  bl    #0x1d108              ; write
```

## Exact modification

For each entity in the list at `bss+0x118`, write **`0`** to
**`entity + 0x27BB8`** on every pass.

`0x27BB8` is the actor's ability slot: zero there means the enemy has no usable
ability. Holding it at zero for the whole match is what "Enemy No Ability"
delivers.

## Address reference

| Item | Address |
|---|---|
| Dispatch entry | `0x700ec` (delta `+0x6634`) |
| Handler | `0xe704` |
| Flag | `bss+0x1a4` (`0xcb1a4`) |
| Worker block | `0x12174` |
| Engine write | `0x1d108` at `0x1219c` |
| Field | `entity + 0x27BB8` |
| Value | `0` |
