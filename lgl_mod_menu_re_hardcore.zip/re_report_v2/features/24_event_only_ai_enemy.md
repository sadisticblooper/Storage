# Feature 24 — Event Only AI Enemy

| | |
|---|---|
| **Menu row** | `24_Spinner_Event Only AI Enemy_1st,2nd,3rd,4th,5th,6th,Last` |
| **Widget** | Spinner, 7 options |
| **`Changes()` id** | `24` |
| **Sub-table** | `0x70134` (indices 0..3), inline tails for 4..6 |

## Handler — verified

```
0000e984:  cmp   w5, #3
0000e988:  b.hi  #0xf154              ; indices 4..6 -> inline tails
0000e98c:  adrp  x9, #0x70000
0000e990:  mov   w8, w5
0000e994:  add   x9, x9, #0x134        ; sub-table 0x70134
0000e998:  ldrsw x8, [x9, x8, lsl #2]
0000e99c:  add   x8, x8, x9
0000e9a0:  br    x8
```

```
0000f154:  orr   w8, w5, #1
0000f158:  cmp   w8, #5
0000f15c:  b.ne  #0xf29c              ; index 4 or 5 -> 0xf160
0000f160:  ...                          ; uses buffer bss+0xa08
```

```
0000f29c:  cmp   w5, #6
0000f2a0:  b.ne  #0xf3f4              ; index 6 -> 0xf2a4, buffer bss+0xa28
```

Sub-table `0x70134` (signed offsets from `0x70134`):

| Index | Entry |
|---|---|
| 0 | `0xe9a4` |
| 1 | `0xf030` |
| 2 | `0xedc0` |
| 3 | `0xeeec` |

Indices 4 and 5 share the tail at `0xf160`; index 6 uses `0xf2a4`.

## Decoded event-id values — verified by emulation

Each option's payload decodes to a pair of decimal strings. Obtained by running
each entry point in the emulator and reading the decoded buffers:

| Spinner option | Index | Values |
|---|---|---|
| 1st | 0 | `40000` / `50000` |
| 2nd | 1 | `55000` / `65000` |
| 3rd | 2 | `85000` / `95000` |
| 4th | 3 | `100000` / `110000` |
| 5th | 4 | `120000` / `130000` |
| 6th | 5 | `120000` / `130000` |
| Last | 6 | `180000` / `190000` |

Each option carries a lower/upper pair: the code picks an AI opponent whose
event bracket falls inside that range. Note that **6th and 5th decode to the
same pair** — indices 4 and 5 share the tail at `0xf160` and therefore share its
buffer, so `6th` cannot select a distinct bracket from `5th` in this build. The
`Last` option does have its own pair.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe984` |
| Sub-table | `0x70134` |
| Tail for indices 4/5 | `0xf154` -> `0xf160` |
| Tail for index 6 | `0xf29c` -> `0xf2a4` |
| Payload buffers | `bss+0x988` … `bss+0xa48` |
