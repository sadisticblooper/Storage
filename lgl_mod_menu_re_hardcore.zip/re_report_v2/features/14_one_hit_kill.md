# Feature 14 — One Hit Kill

| | |
|---|---|
| **Menu row** | `14_Toggle_One Hit Kill` (GFL index 5) |
| **Widget** | Toggle |
| **`Changes()` id** | `14` |
| **Flag** | `bss+0x1a0` (`0xcb1a0`) |
| **Handler** | `0xe7a8` (dispatch entry at `0x700e8`) |
| **Apply** | thread `0x10db8`, loop `0x10e9c` |

> **How this pairing was established.** ids 14 and 15 are adjacent in the
> dispatch table and were transposed twice during this analysis, so it was
> settled three independent ways (all three agree):
>
> 1. **Live dispatch.** Executing `Changes` with `w3 = 14` in the emulator
>    leaves `0xcb1a0 = 1` and `0xcb1a4 = 0`. Executing with `w3 = 15` does the
>    opposite.
> 2. **Dispatch table.** Entry 13 (id 14) at file offset `0x700e8` holds a
>    signed 32-bit delta `+0x6238`; `0x700d0 + 0x6238 = 0xe7a8`. Entry 14
>    (id 15) at `0x700ec` holds `+0x6634` -> `0xe704`.
> 3. **`strb` scan.** `0xe7b8` (inside handler `0xe7a8`) is the only `strb` to
>    `0xcb1a0`; `0xe710` (inside handler `0xe704`) is the only `strb` to
>    `0xcb1a4`.
>
> The menu label confirms the id: `14_Toggle_One Hit Kill` carries the numeric
> prefix `14`.

## Handler — verified

```
0000e7a8:  tst   w6, #0xff
0000e7ac:  and   w8, w6, #0xff
0000e7b0:  cset  w9, ne
0000e7b4:  adrp  x10, #0xcb000
0000e7b8:  strb  w9, [x10, #0x1a0]     ; bss+0x1a0 = enable
0000e7bc:  cbz   w8, #0xf3f4           ; off -> tail
0000e7c0:  adrp  x8, #0xcb000
0000e7c4:  ldrb  w8, [x8, #0x17c]      ; scan active?
0000e7c8:  cmp   w8, #1
0000e7cc:  b.ne  #0xf3f4
0000e7d0:  adrp  x1, #0x10000
0000e7d4:  add   x1, x1, #0xdb8        ; -> 0x10db8 apply thread
0000e7d8:  add   x0, sp, #0x18
0000e7dc:  bl    #0x10458              ; pthread_create
0000e7e0:  add   x0, sp, #0x18
0000e7e4:  bl    #0x41b40
0000e7e8:  b     #0xf3ec
```

## Apply thread `0x10db8` — verified

```
00010e60:  bl    #0x1ddc0              ; find by name, returns a count
00010e64:  cmp   w0, #1
00010e68:  b.lt  #0x10ec4
00010e6c:  adrp  x0, #0xcb000
00010e70:  add   x0, x0, #0x70         ; entity list root
00010e74:  bl    #0x1e4bc              ; list head
00010e88:  ldr   x22, [x19, #8]
00010e9c:  bl    #0xbec0               ; getpid()
00010ea0:  ldr   x2, [x22, #0x10]      ; entity payload
00010ea4:  mov   w1, #0xffec
00010ea8:  movk  w1, #0x77f, lsl #16   ; value = 0x077FFFEC
00010eac:  mov   x0, x20
00010eb0:  mov   w3, wzr
00010eb4:  bl    #0x1d108              ; write
00010eb8:  ldr   x22, [x22, #8]
00010ebc:  cmp   x19, x22
00010ec0:  b.ne  #0x10e9c              ; next entity
```

## Exact modification

For every entity in the list rooted at `bss+0x70`, write
**`0x077FFFEC`** to **`entity + 0x10`**.

| Item | Value |
|---|---|
| Field | `entity + 0x10` (32-bit) |
| New value | `0x077FFFEC` |
| Loop | `0x10e9c` … `0x10ec0` |

`0x077FFFEC` is `0x08000000 - 20` — an overwhelmingly large damage/attack word.
Writing it into the entity's outgoing-hit field makes any single hit resolve as
lethal, which is exactly what the label promises.

## Address reference

| Item | Address |
|---|---|
| Dispatch entry | `0x700e8` (delta `+0x6238`) |
| Handler | `0xe7a8` |
| Flag | `bss+0x1a0` (`0xcb1a0`) |
| Apply thread | `0x10db8` |
| Engine write | `0x1d108` at `0x10eb4` |
| Field | `entity + 0x10` |
| Value | `0x077FFFEC` |
