# Feature 20 — 1v1 Match level

| | |
|---|---|
| **Menu row** | `20_CollapseAdd_Spinner_1v1 Match_Lvl 1,Lvl 2,Lvl 3,Lvl 4` |
| **Widget** | Spinner, 4 options, inside a collapsible group |
| **`Changes()` id** | `20` |
| **Sub-table** | `0x70154` |

## Handler — verified

```
0000e568:  cmp   w5, #3                ; 0..3
0000e56c:  b.hi  #0xf3f4
0000e570:  adrp  x9, #0x70000
0000e574:  mov   w8, w5
0000e578:  add   x9, x9, #0x154        ; sub-table 0x70154
0000e57c:  ldrsw x8, [x9, x8, lsl #2]
0000e580:  add   x8, x8, x9
0000e584:  br    x8
```

Sub-table `0x70154` resolved (dumped directly, signed 32-bit offsets from
`0x70154`):

| Index | Entry |
|---|---|
| 0 | `0xe588` |
| 1 | `0xec2c` |
| 2 | `0xeba4` |
| 3 | `0xebe8` |

Each entry runs the decrypt-once / emit-name sequence for that level.

## Decoded match-id strings — verified by emulation

Each level's payload struct decodes on first use. The decoded value is a decimal
string, obtained by running the lazy-init block in the emulator:

| Level | Struct | Decoded value | Hex |
|---|---|---|---|
| Lvl 1 | `bss+0x890` | `644245094400` | `0x9600000000` |
| Lvl 2 | `bss+0x8b0` | `85899345920001` | `0x4e2000000001` |
| Lvl 3 | `bss+0x8c8` | `128849018880001` | `0x753000000001` |
| Lvl 4 | `bss+0x8e8` | `193273528320001` | `0xafc800000001` |

These are the match/opponent identifiers handed to the Java side for a 1v1 match
at each rank level.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe568` |
| Sub-table | `0x70154` |
| Payload structs | `bss+0x890`, `+0x8b0`, `+0x8c8`, `+0x8e8` |
| Values | see table above |
