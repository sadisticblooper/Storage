# Feature 5 — Autowin

| | |
|---|---|
| **Menu row** | `5_Toggle_Autowin` |
| **Widget** | Toggle |
| **`Changes()` id** | `5` |
| **Flag** | `bss+0x180` |
| **Apply** | classifier block at `0x11c20` |

## Handler — verified

```
0000e800:  tst   w6, #0xff
0000e804:  and   w8, w6, #0xff
0000e808:  cset  w9, ne
0000e80c:  adrp  x10, #0xcb000
0000e810:  strb  w9, [x10, #0x180]     ; bss+0x180 = enable
0000e814:  cbz   w8, #0xf3f4           ; off -> tail
0000e818:  adrp  x8, #0xcb000
0000e81c:  ldrb  w8, [x8, #0x17c]      ; scan active?
0000e820:  cmp   w8, #1
0000e824:  b.ne  #0xf3f4
0000e828:  mov   w0, #8
0000e82c:  bl    #0x44c58             ; operator new
0000e834:  bl    #0x41dd8             ; thread attr
0000e838:  mov   w0, #8
0000e83c:  bl    #0x44c58             ; closure
0000e844:  str   x19, [x0]
0000e848:  adrp  x2, #0x1b000
0000e84c:  add   x2, x2, #0x7f8       ; trampoline
0000e85c:  bl    #0xc0f0              ; pthread_create
```

Stores the flag, and if the scan is already live it also starts a worker thread.

## Where the flag is consumed — verified

`bss+0x180` is read in the classifier at `0x11c20`:

```
00011c1c:  adrp  x8, #0xcb000
00011c20:  ldrb  w8, [x8, #0x180]      ; autowin?
00011c24:  cbz   w8, #0x11dfc           ; no -> skip whole block
00011c28:  ldp   x24, x8, [sp, #0x38]
00011c2c:  stp   xzr, xzr, [sp, #0x20]
00011c34:  subs  x28, x8, x24          ; walk the scan result list
00011c38:  b.eq  #0x11d00
00011c3c:  asr   x25, x28, #3
```

When set, the classifier iterates the discovered entity list and runs the
win-trigger path over it every pass. When clear, it jumps over the entire block
to `0x11dfc`.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe800` |
| Flag | `bss+0x180` |
| Flag reader | `0x11c20` |
| Skipped block | `0x11c28` … `0x11dfc` |

Unlike the pure-flag toggles, Autowin both sets a persistent flag **and** spawns
a thread on the off->on transition while a scan is live.
