# Feature 22 — 3v3 Match level

| | |
|---|---|
| **Menu row** | `22_CollapseAdd_Spinner_3v3 Match_Lvl 1,Lvl 2,Lvl 3,Lvl 4` |
| **Widget** | Spinner, 4 options, inside a collapsible group |
| **`Changes()` id** | `22` |
| **Sub-table** | `0x70144` |

## Handler — verified

```
0000e8f0:  cmp   w5, #3
0000e8f4:  b.hi  #0xf3f4
0000e8f8:  adrp  x9, #0x70000
0000e8fc:  mov   w8, w5
0000e900:  add   x9, x9, #0x144        ; sub-table 0x70144
0000e904:  ldrsw x8, [x9, x8, lsl #2]
0000e908:  add   x8, x8, x9
0000e90c:  br    x8
```

Sub-table `0x70144` resolved:

| Index | Entry |
|---|---|
| 0 | `0xe910` |
| 1 | `0xed7c` |
| 2 | `0xecf4` |
| 3 | `0xed38` |

## Decoded match-id strings — verified by emulation

| Level | Struct | Decoded value | Hex |
|---|---|---|---|
| Lvl 1 | `bss+0x908` | `128849018880001` | `0x753000000001` |
| Lvl 2 | `bss+0x928` | `193273528320001` | `0xafc800000001` |
| Lvl 3 | `bss+0x948` | `257698037760001` | `0xea6000000001` |
| Lvl 4 | `bss+0x968` | `515396075520001` | `0x1d4c000000001` |

Note that 3v3 Lvl 1 equals 1v1 Lvl 3 — the tables overlap, which is expected
because they index the same underlying match-id space.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe8f0` |
| Sub-table | `0x70144` |
| Payload structs | `bss+0x908`, `+0x928`, `+0x948`, `+0x968` |
