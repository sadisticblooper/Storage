# Settings row — Save feature preferences

| | |
|---|---|
| **Menu row** | `-1_Toggle_Save feature preferences` |
| **Widget** | Toggle |
| **Handled by** | Java layer (`SettingsList`) |

## What it does

This row is pure UI/state. It is returned by `SettingsList`:

```
Category_Settings
-1_Toggle_Save feature preferences
-3_Toggle_Auto size vertically
Category_Menu
-6_Button_Close settings
```

The negative id (`-1`) marks it as a *settings* entry rather than a feature
entry. Setting it causes the menu framework to write the toggle states to
`SharedPreferences` so they survive a restart. The native side never sees it:
`Changes` only accepts ids `1..25` (`sub w8, w3, #1` / `cmp w8, #0x18`), so a
negative id falls straight through to the default tail.

## Address reference

| Item | Value |
|---|---|
| Row | `-1_Toggle_Save feature preferences` |
| Producer | `SettingsList` `0x12e64` |
| Native handler | none |
| Persistence | `SharedPreferences`, key suffix `_preferences` (seen in `payload.dex`) |
