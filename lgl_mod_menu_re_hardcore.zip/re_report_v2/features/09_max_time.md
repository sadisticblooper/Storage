# Feature 9 — Max Time

| | |
|---|---|
| **Menu row** | `9_Toggle_Max Time` |
| **Widget** | Toggle |
| **`Changes()` id** | `9` |
| **Flag** | `bss+0x190` |
| **Apply** | worker `0x11fe8` block `0x121ac` + thread `0x10728` |

## Handler — verified

```
0000e870:  tst   w6, #0xff
0000e874:  cset  w8, ne
0000e878:  adrp  x9, #0xcb000
0000e87c:  strb  w8, [x9, #0x190]      ; bss+0x190 = enable
0000e884:  cbz   w8, #0xf3f4
0000e888:  adrp  x8, #0xcb000
0000e88c:  ldrb  w8, [x8, #0x17c]      ; scan active?
0000e890:  cmp   w8, #1
0000e894:  b.ne  #0xf3f4
0000e898:  adrp  x1, #0x10000
0000e89c:  add   x1, x1, #0x728        ; -> 0x10728
0000e8a4:  bl    #0x10458              ; pthread_create
```

## Two write paths

### (a) Worker `0x11fe8`, block at `0x121ac` — the timer field

```
000121ac:  adrp  x8, #0xcb000
000121b0:  ldrb  w8, [x8, #0x190]      ; max time?
000121b4:  mov   w27, #0x8a40
000121b8:  movk  w27, #0x1f7, lsl #16  ; 0x1F78A40
000121bc:  cbz   w8, #0x121fc
000121c0:  adrp  x8, #0xcb000
000121c4:  add   x8, x8, #0x148
000121c8:  ldp   x24, x26, [x8]        ; list at bss+0x148
000121d4:  ldr   x21, [x24]
000121d8:  bl    #0xbec0               ; getpid()
000121dc:  mov   w1, #0x71700000       ; float pattern
000121e0:  mov   x0, x20
000121e4:  mov   x2, x21
000121e8:  mov   w3, wzr
000121ec:  bl    #0x1d108              ; write
```

### (b) Apply thread `0x10728`

Walks the entity list, reads `entity-0x74` and `entity-0x80`, and when they
match its guard appends `entity + 0x14` to the list at `bss+0xf0`:

```
00010848:  bl    #0xbec0
0001084c:  sub   x1, x25, #0x74
00010858:  bl    #0x1cf40              ; read entity-0x74
0001085c:  mov   w24, w0
00010864:  sub   x1, x25, #0x80
00010870:  bl    #0x1cfe8              ; read64 entity-0x80
00010888:  mov   x8, #0x28f0000000000000
0001088c:  cmp   x28, x8
000108a8:  add   x9, x25, #0x14
000108b8:  str   x9, [x8], #8          ; append entity+0x14
000108bc:  str   x8, [x19, #8]
```

## Exact modification

| Path | Target | Value |
|---|---|---|
| Worker | list at `bss+0x148`, entity field `+0x00` | `0x71700000` via `0x1d108` |
| Thread | list at `bss+0xf0`, append `entity + 0x14` | — |

The worker writes the constant `0x71700000` directly as a 32-bit float bit
pattern, a very large finite value (approx. 1.0e19). The battle timer is pinned
near its maximum so the match does not expire.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe870` |
| Flag | `bss+0x190` |
| Worker block | `0x121ac` |
| Worker write | `0x1d108` at `0x121ec` |
| Timer value | `0x71700000` |
| Apply thread | `0x10728` |
| Thread list | `bss+0xf0`, element `entity + 0x14` |
