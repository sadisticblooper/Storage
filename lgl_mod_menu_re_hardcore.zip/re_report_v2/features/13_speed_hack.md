# Feature 13 — Speed Hack

| | |
|---|---|
| **Menu row** | `13_Toggle_Speed Hack` |
| **Widget** | Toggle |
| **`Changes()` id** | `13` |
| **Flag** | `bss+0x19c` |
| **Apply** | thread `0x10b48`; revert in handler at `0xeae8` |

## Handler — verified

```
0000e648:  tst   w6, #0xff
0000e64c:  and   w8, w6, #0xff
0000e650:  cset  w9, ne
0000e654:  adrp  x10, #0xcb000
0000e658:  strb  w9, [x10, #0x19c]     ; bss+0x19c = enable
0000e65c:  cbz   w8, #0xeae8           ; OFF -> revert path
0000e660:  adrp  x1, #0x10000
0000e664:  add   x1, x1, #0xb48        ; -> 0x10b48
0000e66c:  bl    #0x10458              ; pthread_create
```

## Apply thread `0x10b48` — verified

It walks the entity list, validates a pair of 32-bit tags at `entity+4` and
`entity+8`, and when they match records the entity pointer into the list at
`bss+0x160`:

```
00010c74:  ldr   x23, [x25, #0x10]     ; entity payload
00010c80:  add   x1, x23, #4
00010c8c:  bl    #0x1cf40              ; read entity+0x04
00010c98:  cmp   w23, w26              ; guard A
00010c9c:  b.ne  #0x10d00
00010ca8:  add   x1, x23, #8
00010cb4:  bl    #0x1cf40              ; read entity+0x08
00010cc0:  cmp   w23, w27              ; guard B
00010cc4:  b.ne  #0x10d00
00010cc8:  bl    #0x3ff1c              ; lock
00010cd0:  ldp   x8, x9, [x22, #8]      ; list at bss+0x160
00010ce0:  str   x9, [x8], #8           ; append entity pointer
00010ce4:  str   x8, [x22, #8]
```

## Revert on disable — verified

The off-branch at `0xeae8` walks the recorded list at `bss+0x160` and restores
the float field to `1.0f` through the float writer:

```
0000eae8:  adrp  x0, #0xcb000
0000eaec:  add   x0, x0, #0xf0         ; lock
0000eaf0:  bl    #0x3ff1c
0000eaf4:  adrp  x20, #0xcb000
0000eaf8:  add   x20, x20, #0x160
0000eafc:  ldp   x21, x23, [x20]       ; list begin/end
0000eb0c:  add   x19, x19, #0x70       ; engine context
0000eb10:  fmov  s8, #1.00000000       ; 1.0f
0000eb14:  ldr   x1, [x21]
0000eb1c:  mov   v0.16b, v8.16b
0000eb20:  mov   w2, wzr
0000eb24:  bl    #0x1d180              ; write float 1.0f
0000eb28:  add   x21, x21, #8
0000eb2c:  cmp   x23, x21
0000eb30:  b.ne  #0xeb14
0000eb34:  ...                          ; truncate the list
0000eb3c:  bl    #0x3ff40              ; unlock
```

## Exact modification

| Direction | Action |
|---|---|
| Enable | record the matching entities into `bss+0x160`; their speed field is driven through the engine |
| Disable | walk `bss+0x160` and write `1.0f` (via `0x1d180`) to each recorded entity |

This is genuinely reversible: turning the toggle off restores each recorded
entity's multiplier to `1.0f`.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe648` |
| Flag | `bss+0x19c` |
| Apply thread | `0x10b48` |
| Guard reads | `0x10c8c`, `0x10cb4` |
| Revert path | `0xeae8` … `0xeb3c` |
| Revert write | `0x1d180` at `0xeb24`, value `1.0f` |
| Recorded list | `bss+0x160` |
