# Settings row — Auto size vertically

| | |
|---|---|
| **Menu row** | `-3_Toggle_Auto size vertically` |
| **Widget** | Toggle |
| **Handled by** | Java layer (`SettingsList`) |

## What it does

Pure UI layout switch. When on, the menu recomputes its own height to fit the
content instead of using a fixed height. It is a settings entry (negative id),
so it is never forwarded to `Changes`.

## Address reference

| Item | Value |
|---|---|
| Row | `-3_Toggle_Auto size vertically` |
| Producer | `SettingsList` `0x12e64` |
| Native handler | none |
