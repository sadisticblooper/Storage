# Feature 25 — Max Upgrade Character

| | |
|---|---|
| **Menu row** | `25_InputValue_Max Upgrade Character` |
| **Widget** | Text input |
| **`Changes()` id** | `25` |
| **Apply** | thread `0x105d0` |

## Handler — verified

```
0000e53c:  b     #0xf3f4
0000e540:  cmp   w5, #1
0000e544:  b.lt  #0xf3f4               ; no value typed -> ignore
0000e548:  adrp  x1, #0x11000
0000e54c:  add   x1, x1, #0x5d0        ; -> 0x105d0
0000e550:  add   x0, sp, #0x18
0000e554:  add   x2, sp, #0x24         ; &w5
0000e558:  bl    #0x11300              ; thread start, value forwarded
0000e55c:  add   x0, sp, #0x18
0000e560:  bl    #0x41b40
0000e564:  b     #0xf3ec
```

> **Correction.** The earlier report said this id had no handler. It does:
> the `Changes` range is ids **1..25** (`sub w8, w3, #1` then `cmp w8, #0x18`),
> and id 25 dispatches to `0xe540`.

## Apply thread `0x105d0` — verified

```
000105d0:  add   x0, x0, #0x70         ; entity list root
000105d8:  bl    #0x1e4bc              ; list head
000105ec:  ldr   x23, [x19, #8]
00010600:  ldr   x21, [x23, #0x10]     ; entity payload
00010608:  sub   x1, x21, #0xc
00010614:  bl    #0x1cf40              ; read entity-0x0c
00010620:  sub   x1, x21, #8
0001062c:  bl    #0x1cf40              ; read entity-0x08
00010630:  mov   w22, w0
00010638:  cmp   w22, #1               ; must be 1
0001063c:  b.ne  #0x106ac
00010644:  sub   x1, x21, #4
00010650:  bl    #0x1cf40              ; read entity-0x04
0001065c:  add   x1, x21, #4
00010668:  bl    #0x1cf40              ; read entity+0x04
00010674:  add   x1, x21, #8
00010680:  bl    #0x1cf40              ; read entity+0x08
0001068c:  cmp   w22, #1               ; must be 1
00010690:  b.ne  #0x106ac
00010698:  mov   w1, #0xe00000         ; value = 0xE00000
0001069c:  mov   x0, x20
000106a0:  mov   x2, x21              ; target = entity + 0
000106a8:  bl    #0x1d108              ; write
```

## Exact modification

For entities whose markers read `1` at `entity-0x08` and `1` at `entity+0x08`,
write **`0xE00000`** to **`entity + 0x00`**.

`0xE00000` is the maxed upgrade/level word for the character record identified
by the surrounding markers. Pressing the input re-applies it, so the character
stays at maximum upgrade.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe540` |
| Thread start | `0x11300` |
| Apply thread | `0x105d0` |
| Marker reads | `0x10614` … `0x10680` |
| Engine write | `0x1d108` at `0x106a8` |
| Field | `entity + 0x00` |
| Value | `0xE00000` |
