# Feature 1 — Instant Win

| | |
|---|---|
| **Menu row** | `1_Spinner_Instant Win_None,1v1,3v3,Story Mode,Chronicles Mode` |
| **Widget** | Spinner, 5 options |
| **`Changes()` id** | `1` |
| **Flag** | `bss+0x178` — u32, the selected mode |
| **Apply routine** | `0x115d0` |

## Options

The spinner is `None, 1v1, 3v3, Story Mode, Chronicles Mode`. The selected index
is the value handed to `Changes` in `w5`.

## Handler — verified

```
0000e530: br    x8
0000e534: adrp  x8, #0xcb000
0000e538: str   w5, [x8, #0x178]     ; bss+0x178 = selected mode
0000e53c: b     #0xf3f4              ; common tail
0000e540: cmp   w5, #1
```

Nothing else happens here. The handler only records the mode.

## Apply routine `0x115d0` — verified

It walks the list rooted at `bss+0x70` and, for each record, reads a series of
32-bit fields relative to the payload pointer:

```
0001168c:  bl  #0x1cf40   ; read entity-0x10
000116ac:  bl  #0x1cf40   ; read entity-0x0c
000116cc:  bl  #0x1cf40   ; read entity-0x08
000116ec:  bl  #0x1cf40   ; read entity-0x04
0001170c:  bl  #0x1cf40   ; read entity+0x00
0001172c:  bl  #0x1cf40   ; read entity+0x04
0001174c:  bl  #0x1cf40   ; read entity+0x08
0001176c:  bl  #0x1cf40   ; read entity+0x0c
0001178c:  bl  #0x1cf40   ; read entity+0x10
```

The decisive part is the tail:

```
000117a0:  bl    #0xbec0              ; getpid()
000117a4:  sub   x21, x21, #0x24      ; x21 = entity - 0x24
000117b4:  bl    #0x1cf40             ; read entity-0x24
000117b8:  sub   w8, w0, #1
000117bc:  cmp   w8, #0xb             ; accept iff value-1 <= 11
000117c0:  b.hi  #0x117dc             ;   i.e. value in [1..12]
000117c4:  bl    #0xbec0              ; getpid()
000117c8:  mov   w1, #0xd             ; value = 13
000117cc:  mov   x0, x20              ; engine context
000117d0:  mov   x2, x21              ; target = entity - 0x24
000117d8:  bl    #0x1d108             ; process_vm_writev(...)
```

## Exact modification

For every entity whose state word at **`entity - 0x24`** currently holds a value
in **1 … 12**, write **`13`** to that same word.

| Item | Value |
|---|---|
| Field | `entity - 0x24` (32-bit) |
| Precondition | `1 <= v <= 12` |
| New value | `0x0D` = `13` |
| Gate | the field reads at `0x1168c`…`0x1178c` must all match their constants |

The field behaves as a match/round result or phase code; `13` is the terminal
"won / complete" state for that participant. The `13` -> "win" reading is an
interpretation of the observed constant — what is certain is the field, the
`1..12` acceptance window, and the written value `13`.

The stored mode at `bss+0x178` selects which entity list the routine is pointed
at (1v1 / 3v3 / Story / Chronicles).

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe534` |
| Mode flag | `bss+0x178` |
| Apply routine | `0x115d0` |
| Field reads | `0x1168c` … `0x1178c` |
| Window test | `0x117b8` |
| Engine write | `0x1d108` at `0x117d8` |
| Field | `entity - 0x24` |
| Value written | `13` |
