# Feature 6 — Immortal

| | |
|---|---|
| **Menu row** | `6_Toggle_Immortal` |
| **Widget** | Toggle |
| **`Changes()` id** | `6` |
| **Flag** | `bss+0x184` |
| **Apply** | worker `0x11fe8`, block at `0x12128` |

## Handler — verified

```
0000e7ec:  tst   w6, #0xff
0000e7f0:  cset  w8, ne
0000e7f4:  adrp  x9, #0xcb000
0000e7f8:  strb  w8, [x9, #0x184]      ; bss+0x184 = enable
0000e7fc:  b     #0xf3f4
```

Pure flag store.

## Apply — verified, inside the worker `0x11fe8`

```
00012128:  adrp  x8, #0xcb000
0001212c:  ldrb  w8, [x8, #0x184]      ; immortal?
00012130:  cbz   w8, #0x12150          ;   no -> next feature
00012134:  bl    #0xbec0               ; getpid()
0001213c:  add   x2, x26, x28          ; entity + 0x1F78A50
00012140:  mov   w1, #0x100000         ; value = 0x100000
00012144:  mov   x0, x20               ; engine context
00012148:  mov   w3, wzr
0001214c:  bl    #0x1d108              ; write
```

## Exact modification

For every entity in the list at `bss+0x118`, while Immortal is on, write
**`0x100000`** to **`entity + 0x1F78A50`** on every pass. This keeps the
invulnerability flag continuously asserted.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe7ec` |
| Flag | `bss+0x184` |
| Worker block | `0x12128` |
| Engine write | `0x1d108` at `0x1214c` |
| Field | `entity + 0x1F78A50` |
| Value | `0x100000` |

> **Shared target:** Freeze Enemy (`bss+0x188`) writes the same field. Max Shadow
> Ability (`bss+0x18c`) gates the read-modify-write branch just above this block.
> See `07_freeze_enemy.md` and `08_max_shadow_ability.md`.
