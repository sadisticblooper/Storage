# Feature 2 — Long Range Hits

| | |
|---|---|
| **Menu row** | `2_Toggle_Long Range Hits` |
| **Widget** | Toggle |
| **`Changes()` id** | `2` |
| **Flag** | none — uses a one-shot latch at `0xd8000+0x338` |
| **Apply routine** | `0x10264` |

## Handler — verified

```
0000e718:  adrp  x8, #0xd8000
0000e71c:  add   x8, x8, #0x338
0000e720:  ldarb w9, [x8]              ; latch byte
0000e724:  tst   w6, #0xff
0000e728:  b.eq  #0xeb50               ; w6==0 -> disable path
0000e72c:  tbnz  w9, #0, #0xf3f4       ; already latched -> done
0000e730:  mov   w9, #1
0000e734:  stlrb w9, [x8]              ; set latch
0000e738:  adrp  x8, #0xcb000
0000e73c:  add   x8, x8, #0x7d0
0000e740:  ldarb w8, [x8]              ; string built?
0000e744:  tbz   w8, #0, #0xf510       ;   no -> lazy build
0000e748:  adrp  x21, #0xcb000
0000e74c:  add   x21, x21, #0x7b8      ; string object
0000e750:  mov   x0, x21
0000e754:  bl    #0x1b730             ; decrypt string in place
0000e758:  mov   x0, x20
0000e75c:  mov   x1, x19
0000e760:  mov   x2, x21
0000e764:  bl    #0xfd94              ; apply
0000e768:  adrp  x8, #0xcb000
0000e76c:  ldrb  w8, [x8, #0x17c]
0000e770:  cmp   w8, #1
0000e774:  b.ne  #0xf3f4
0000e784:  bl    #0x10458             ; pthread_create (0x10264)
```

On disable the latch is cleared:

```
0000eb50:  tbz   w9, #0, #0xf3f4
0000eb54:  stlrb wzr, [x8]             ; clear latch
```

## Apply routine `0x10264` — verified

Per entity it reads five marker words, and if they match, writes a float:

```
00010334:  ldr   x21, [x23, #0x10]     ; entity payload
0001033c:  sub   x1, x21, #0xc
00010348:  bl    #0x1cf40              ; read entity-0x0c
00010354:  sub   x1, x21, #8
00010360:  bl    #0x1cf40              ; read entity-0x08
0001036c:  cmp   w22, #1
00010370:  b.ne  #0x103e0
00010378:  sub   x1, x21, #4
00010384:  bl    #0x1cf40              ; read entity-0x04
00010390:  add   x1, x21, #4
0001039c:  bl    #0x1cf40              ; read entity+0x04
000103a8:  add   x1, x21, #8
000103b4:  bl    #0x1cf40              ; read entity+0x08
000103c0:  cmp   w22, #1
000103c4:  b.ne  #0x103e0
000103cc:  mov   w1, #0x57800000       ; 288.0f
000103d0:  mov   x0, x20
000103d4:  mov   x2, x21              ; target = entity + 0
000103dc:  bl    #0x1d108             ; write
```

## Exact modification

Targets must satisfy:

| Offset | Required value |
|---|---|
| `entity-0x0c` | `0` |
| `entity-0x08` | `1` |
| `entity-0x04` | `0` |
| `entity+0x04` | `1` |

Then write the 32-bit float **`0x57800000` = 288.0** to **`entity + 0`**.

| Item | Address |
|---|---|
| Handler | `0xe718` |
| Latch | `0xd8000+0x338` |
| Apply routine | `0x10264` |
| Marker reads | `0x10348` … `0x103b4` |
| Engine write | `0x1d108` at `0x103dc` |
| Field | `entity + 0x00` |
| Value | `0x57800000` = `288.0f` |

288.0 is a range/reach value: the entity's attack reach is set to a fixed large
float, so its hits land from far away.

This is the only feature with no persistent enable byte; it latches on, applies,
and is cleared by the disable path.
