# Feature 8 — Max Shadow Ability

| | |
|---|---|
| **Menu row** | `8_Toggle_Max Shadow Ability` |
| **Widget** | Toggle |
| **`Changes()` id** | `8` |
| **Flag** | `bss+0x18c` |
| **Apply** | worker `0x11fe8`, read-modify-write at `0x120e0` |

## Handler — verified

```
0000e794:  tst   w6, #0xff
0000e798:  cset  w8, ne
0000e79c:  adrp  x9, #0xcb000
0000e7a0:  strb  w8, [x9, #0x18c]      ; bss+0x18c = enable
0000e7a4:  b     #0xf3f4
```

Pure flag store.

## Apply — verified, a genuine read-modify-write

```
000120dc:  adrp  x8, #0xcb000
000120e0:  ldrb  w8, [x8, #0x18c]      ; max shadow?
000120e4:  ldr   x26, [x24]            ; entity
000120e8:  cbz   w8, #0x12128          ;   no -> skip to Immortal block
000120ec:  bl    #0xbec0               ; getpid()
000120f0:  add   x8, x26, x28          ; entity + 0x1F78A50
000120f4:  add   x21, x8, #8           ; field = entity + 0x1F78A58
000120f8:  mov   x0, x20
000120fc:  mov   x1, x21
00012100:  mov   w2, wzr
00012104:  bl    #0x1cf40              ; READ current value
00012108:  cbnz  w0, #0x12128          ; already non-zero -> leave alone
0001210c:  bl    #0xbec0               ; getpid()
00012114:  mov   w1, #0x100000         ; value = 0x100000
00012118:  mov   x0, x20
0001211c:  mov   x2, x21               ; same field
00012120:  mov   w3, wzr
00012124:  bl    #0x1d108              ; WRITE
```

## Exact modification

For each entity:

1. read the 32-bit word at **`entity + 0x1F78A58`**;
2. if it is already non-zero, do nothing;
3. otherwise write **`0x100000`** to it.

This is "fill the ability/energy gauge to max only when it is empty", which
avoids fighting the game's own value management the way a blind store would.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe794` |
| Flag | `bss+0x18c` |
| Worker check | `0x120e0` |
| Engine read | `0x1cf40` at `0x12104` |
| Engine write | `0x1d108` at `0x12124` |
| Field | `entity + 0x1F78A58` |
| Value | `0x100000` |
| Guard | skip when current value != 0 |

> Not the same field as Immortal/Freeze. Those write `entity + 0x1F78A50`;
> Max Shadow reads and writes `entity + 0x1F78A58`, 8 bytes further on, and only
> when it reads zero.
