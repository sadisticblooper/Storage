# Settings row — Close settings

| | |
|---|---|
| **Menu row** | `-6_Button_Close settings` |
| **Widget** | Button |
| **Handled by** | Java layer (`SettingsList`) |

## What it does

Closes the settings sheet and returns to the feature list. Purely a UI action;
no native call.

## Address reference

| Item | Value |
|---|---|
| Row | `-6_Button_Close settings` |
| Producer | `SettingsList` `0x12e64` |
| Native handler | none |
