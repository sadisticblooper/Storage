# Unused feature ids — 3, 4, 16, 17, 18, 19

These six slots in the `Changes` dispatch table point at the default tail
`0xf3f4`, and none of them appears as a `<id>_<Widget>_<Label>` row in
`GetFeatureList`. They are reserved.

| id | Table entry | Appears in menu? |
|---|---|---|
| 3 | `0xf3f4` | no |
| 4 | `0xf3f4` | no |
| 16 | `0xf3f4` | no |
| 17 | `0xf3f4` | no |
| 18 | `0xf3f4` | no |
| 19 | `0xf3f4` | no |

## Why they exist

The GFL string array has 26 entries, but the entries at GFL index 7, 10, 13, 16
and 19 are **category headers** (`Category_Enemy Hack`, `Category_Character
Hacks`, `Category_Battle Hacks`, `Category_Rank Mode`) and index 19 is the
collapsible group header `Collapse_Real Player to AI`. Headers have no numeric
id, so the range of real feature ids has gaps where the headers sit.

In addition, ids 3 and 4 have no row at all — they are simply unallocated.

## The default tail `0xf3f4`

Every handler that has nothing to do branches here. It is the shared exit that
runs the common string/UI cleanup and then returns; it performs no memory
writes.

## Address reference

| Item | Address |
|---|---|
| Default tail | `0xf3f4` |
| Range check | `0xe504` … `0xe51c` |
| Table base | `0x700d0` |
