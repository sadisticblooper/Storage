# Feature 21 — Level 5 (Custom Rank), 1v1

| | |
|---|---|
| **Menu row** | `21_CollapseAdd_InputValue_Level 5 (Custom Rank)` |
| **Widget** | Text input, inside the 1v1 collapsible group |
| **`Changes()` id** | `21` |
| **Apply** | thread `0x110d8` |

## Handler — verified

```
0000e8c8:  cmp   w5, #1
0000e8cc:  b.lt  #0xf3f4               ; no value typed -> ignore
0000e8d0:  adrp  x1, #0x11000
0000e8d4:  add   x1, x1, #0xd8         ; -> 0x110d8
0000e8d8:  add   x0, sp, #0x18
0000e8dc:  add   x2, sp, #0x24         ; &w5 (the typed value)
0000e8e0:  bl    #0x11300              ; thread start, value passed through
0000e8e4:  add   x0, sp, #0x18
0000e8e8:  bl    #0x41b40
0000e8ec:  b     #0xf3ec
```

`0x11300` is the pthread wrapper variant that also forwards a 32-bit value to
the closure. The typed number (`w5`) therefore reaches the worker.

## Apply thread `0x110d8` — verified

```
000110f8:  mov   w19, w0               ; w19 = custom level
00011128:  adrp  x1, #0x9c000
0001112c:  add   x1, x1, #0x14e        ; format string at 0x9c14e
00011130:  add   x0, sp, #8
00011134:  mov   w2, w19
00011138:  bl    #0xbea0               ; snprintf(buf, fmt, level)
00011140:  mov   x0, x20
00011148:  bl    #0x1ddc0              ; look up by formatted string
0001114c:  cmp   w0, #1
```

The level is formatted into the same kind of decimal string the fixed levels
(feature 20) use, then resolved against the same table. "Level 5 (Custom Rank)"
therefore reuses the match-id mechanism with a user-supplied level.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe8c8` |
| Thread start | `0x11300` |
| Apply thread | `0x110d8` |
| Format string | `0x9c14e` |
| Lookup | `0x1ddc0` |
