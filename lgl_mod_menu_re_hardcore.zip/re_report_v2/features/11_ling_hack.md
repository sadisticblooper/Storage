# Feature 11 — Ling Hack

| | |
|---|---|
| **Menu row** | `11_Toggle_Ling Hack` |
| **Widget** | Toggle |
| **`Changes()` id** | `11` |
| **Flag** | `bss+0x198` |
| **Apply** | thread `0x1612c` |

## Handler — verified

```
0000e970:  tst   w6, #0xff
0000e974:  cset  w8, ne
0000e978:  adrp  x9, #0xcb000
0000e97c:  strb  w8, [x9, #0x198]      ; bss+0x198 = enable
0000e980:  b     #0xf3f4
```

## Flag consumer — verified

```
00011b94:  adrp  x8, #0xcb000
00011b98:  ldrb  w8, [x8, #0x198]      ; ling hack?
00011b9c:  cbz   w8, #0x11bc0
00011ba0:  adrp  x1, #0x16000
00011ba8:  add   x1, x1, #0x12c        ; -> 0x1612c
00011bac:  bl    #0x10458              ; pthread_create
```

## Apply thread `0x1612c` — verified

Per entity it reads five fields and validates them:

```
00016204:  ldr   x21, [x27, #0x10]     ; entity payload
00016214:  sub   x24, x21, #4
00016220:  bl    #0x1cf40              ; read entity-0x04
0001622c:  cmp   w23, #2               ; must be 2
00016230:  add   x22, x21, #4
00016240:  bl    #0x1cf40              ; read entity+0x04
0001624c:  cmp   w23, #2               ; must be 2
00016258:  add   x23, x21, #8
00016268:  bl    #0x1cf40              ; read entity+0x08
00016274:  cmp   w23, #8               ; must be 8
00016280:  add   x25, x21, #0xc
00016290:  bl    #0x1cf40              ; read entity+0x0c
0001629c:  cmp   w23, #8               ; must be 8
000162a8:  add   x26, x21, #0x10
000162b8:  bl    #0x1cf40              ; read entity+0x10
```

Then the writes:

```
000162c8:  mov   w1, #0xa              ; 10
000162cc:  mov   x2, x24              ; entity - 0x04
000162d8:  bl    #0x1d108
000162e0:  mov   w1, #0xf              ; 15
000162e8:  mov   x2, x21              ; entity + 0x00
000162f0:  bl    #0x1d108
000162fc:  mov   w1, #1                ; 1
00016304:  mov   x2, x22              ; entity + 0x04
0001630c:  bl    #0x1d108
00016330:  mov   x2, x25              ; entity + 0x0c
00016338:  bl    #0x1d108              ; value 0
00016348:  mov   x2, x26              ; entity + 0x10
00016350:  bl    #0x1d108              ; value 0
```

## Exact modification

For entities whose markers read `2, 2, 8, 8`:

| Field | New value |
|---|---|
| `entity - 0x04` | `10` |
| `entity + 0x00` | `15` |
| `entity + 0x04` | `1` |
| `entity + 0x0c` | `0` |
| `entity + 0x10` | `0` |

`15` in the character-type field is the character this row is named after; the
surrounding values are its accompanying stat/state seeds.

## Address reference

| Item | Address |
|---|---|
| Handler | `0xe970` |
| Flag | `bss+0x198` |
| Consumer | `0x11b94` |
| Apply thread | `0x1612c` |
| Guard reads | `0x16220` … `0x162b8` |
| Writes | `0x162d8`, `0x162f0`, `0x1630c`, `0x16340`, `0x16358` |
