# MISCELLANEOUS — PID, memory engine, loader, anti-analysis

Everything here is about the machinery that the menu rows sit on: how the
target process is identified, how memory is read and written, how the library
bootstraps itself, and how it hides.

---

## 1. Where the PID comes from, and how it is used

### 1.1 Acquisition

`JNI_OnLoad` → registration path → context constructor `0x1bdf4`. Inside it:

```
0000e110:  mov   w8, #0x83ca
...
0001be68:  bl    #0xbec0        ; getpid()
...
           str   w0, [x19, #0x38]
```

`0xbec0` is `getpid` (confirmed from the PLT map). The result is stored at
**context + 0x38**.

There is no search for the game by name here, and no `fork`/`ptrace` dance: the
library runs inside the game's own process, so `getpid()` is already the target.

### 1.2 Use

Each operation reloads the pid from its context rather than keeping it in a
register:

```
0001cf98:  ldr   w1, [x20, #0x38]      ; read32
0001d14c:  ldr   w1, [x0, #0x38]       ; write32
0001d1c4:  ldr   w1, [x0, #0x38]       ; write float
```

Every operations routine also calls `getpid()` again just before dispatching,
which makes it safe if the context is ever used after a fork:

```
0001cf9c:  bl    #0xbec0               ; getpid() again
0001cfa4:  mov   w0, #0x10e            ; __NR_process_vm_readv
```

### 1.3 Answer to "what is the pid for?"

It is the *target process id* argument for `process_vm_readv` and
`process_vm_writev`. Those syscalls take a pid as their first argument, so the
library must supply one — and because it lives inside the game, it supplies its
own.

---

## 2. The memory engine

### 2.1 Syscall choice

| Routine | Address | Syscall | Number |
|---|---|---|---|
| read32 | `0x1cf40` | `process_vm_readv` | `0x10e` = 270 |
| read64 | `0x1cfe8` | `process_vm_readv` | `0x10e` = 270 |
| write32 | `0x1d108` | `process_vm_writev` | `0x10f` = 271 |
| write float | `0x1d180` | `process_vm_writev` | `0x10f` = 271 |

`0xc190` is `syscall`. There is **no** `ptrace` and **no** `/proc/<pid>/mem`
open in the engine.

### 2.2 read32 — `0x1cf40`

```
0001cf58:  mrs   x23, tpidr_el0
0001cf70:  str   wzr, [sp, #4]          ; zero the output slot
0001cf88:  bl    #0xc1a0                ; memset(&out, 0, 4)
0001cf8c:  add   x8, x22, w19, sxtw     ; remote address base + offset
0001cf90:  stp   x24, x21, [sp, #0x18]  ; local iovec  {&out, len}
0001cf94:  stp   x8,  x21, [sp, #8]     ; remote iovec {addr, len}
0001cf98:  ldr   w1, [x20, #0x38]       ; pid
0001cf9c:  mov   w0, #0x10e             ; __NR_process_vm_readv
0001cfa0:  add   x2, sp, #0x18
0001cfa4:  mov   w3, #1
0001cfa8:  add   x4, sp, #8
0001cfac:  mov   w5, #1
0001cfb0:  mov   w6, wzr
0001cfb4:  bl    #0xc190                ; syscall()
0001cfb8:  ldr   w0, [sp, #4]           ; return the value
```

`x1` is the base address, `w2` is an added offset, `x0` is the engine context.
The length (`x21`) comes from `[ctx]` / `[ctx,#4]` depending on the width.

### 2.3 write32 — `0x1d108`

```
0001d130:  str   w1, [sp, #4]           ; stash the value to write
0001d134:  ldrsw x9, [x0]               ; length
0001d138:  add   x8, sp, #4
0001d144:  stp   x8, x9, [sp, #0x18]    ; local iovec  {&value, len}
0001d148:  stp   x10, x9, [sp, #8]      ; remote iovec {addr+off, len}
0001d14c:  ldr   w1, [x0, #0x38]        ; pid
0001d150:  mov   w0, #0x10f             ; __NR_process_vm_writev
0001d158:  bl    #0xc190                ; syscall()
0001d15c:  ...                           ; stack canary check
```

### 2.4 write float — `0x1d180`

Same shape, but the value comes in `s0`:

```
0001d1a8:  str   s0, [sp, #4]
0001d1c8:  mov   w0, #0x10f
```

### 2.5 Stack protection

Every routine ends with the standard canary comparison against
`tpidr_el0+0x28`, failing to `0xc3a0` (`__stack_chk_fail`). Nothing unusual
there; worth noting only because it means the routines cannot be lifted out of
context trivially.

---

## 3. The loader chain

### 3.1 JNI_OnLoad at `0x135b0`

Observed JNI calls during emulation (indices are the JNIEnv table slots):

```
idx 6   FindClass        'android/app/ActivityThread'
idx 113 GetStaticMethodID 'currentApplication' '()Landroid/app/Application;'
idx 23  NewStringUTF     (path / identifier strings)
idx 172 NewObjectArray
idx 174 SetObjectArrayElement
idx 6   FindClass        'java/nio/ByteBuffer'
idx 23  NewStringUTF     'ELF'  / 'dex'
idx 172 ...              -> 'java/lang/ClassLoader'
idx 6   FindClass        'dalvik/system/InMemoryDexClassLoader'
idx 33  GetMethodID
idx 35  ...
idx 167 NewObject        'com.android.support.Menu'
```

The flow is:

1. obtain the running `Application` via `ActivityThread.currentApplication()`;
2. wrap the embedded DEX bytes in a `ByteBuffer`;
3. construct an `InMemoryDexClassLoader` over that buffer;
4. load and instantiate `com.android.support.Menu` with the LGL entry point.

The embedded DEX is stored inside the `.so`; its DEX header (`dex\n035`) is part
of the payload described above.

### 3.2 Registration and worker startup

```
00013630:  adrp x12, #0x12000
00013648:  add  x12, x12, #0xe64       ; 0x12e64 SettingsList
00013654:  add  x8,  x8,  #0x4e0       ; 0x4e0 worker/registration
00013658:  add  x2,  x2,  #0x658       ; 0x1658 trampoline
00013668:  str  x19, [x20, #0x1a8]
0001366c:  str  x12, [x11, #0x58]      ; export SettingsList ptr
00013670:  str  x8,  [x9,  #0x68]      ; export worker ptr
00013674:  bl   #0xc0f0                ; pthread_create
00013678:  bl   #0xbcd0                ; pthread_detach
00013680:  mov  w0, #3
00013684:  bl   #0xc000                ; sleep(3)
```

`sleep(3)` before touching the game's structures gives the host process time to
finish starting up.

### 3.3 Symbol resolution

`0x18fa8` (called from the supervisor at `0x15658`) resolves its target by name
through `dlopen` (`0xc1b0`); the manager call at `0x19360` uses
`dl_iterate_phdr` (`0xc400`) with `svc #0`-based direct syscalls to enumerate
loaded modules and locate versioned symbols without going through the public
`dlsym` path.

---

## 4. Anti-analysis

| Mechanism | Detail |
|---|---|
| Encrypted strings | every literal lives in `.bss` as an EOR-encrypted blob plus an `adrp`-relative XOR key, and is decoded lazily the first time it is used |
| Lazy flags | each struct carries a `len` byte; when it is 0 the decode has not run yet, so the plaintext never exists in the file |
| Direct syscalls | `svc #0` with explicit numbers instead of libc wrappers for the sensitive operations |
| `dl_iterate_phdr` | resolves module symbols without an obvious `dlsym` string reference |
| OLLVM | the library's control flow is flattened in places and the string helpers are inlined, which is why static reading alone produced wrong results earlier |
| Stack canaries | every engine routine checks `tpidr_el0+0x28` |
| `prctl` | thread naming via `prctl(PR_SET_NAME, pid)` in the trampoline |

---

## 5. Verified symbol map

| Address | Symbol |
|---|---|
| `0xbec0` | `getpid` |
| `0xc000` | `sleep` |
| `0xc0f0` | `pthread_create` |
| `0xc190` | `syscall` |
| `0xc1a0` | `memset` |
| `0xc1b0` | `dlopen` |
| `0xbcd0` | `pthread_detach` |
| `0xc400` | `dl_iterate_phdr` |
| `0xc3a0` | `__stack_chk_fail` |
| `0x44c58` | `operator new` |
| `0x41dd8` | `pthread_attr_init` |
| `0x3ff1c` / `0x3ff40` | mutex lock / unlock |
| `0x42400` / `0x424c8` | lazy-init guard test / set |
| `0x135b0` | `JNI_OnLoad` |
| `0xc9b0` | `GetFeatureList` |
| `0x12e64` | `SettingsList` |
| `0x4e0` | worker/registration |
| `0xe4e0` | `Changes` |

---

## 6. Threading model

| Function | Role |
|---|---|
| `0x1b3c8` | generic closure trampoline (worker) |
| `0x1b7f8` | closure trampoline used by Autowin |
| `0x1b924` | closure trampoline with one argument |
| `0x1ba10` | closure trampoline with a 32-bit argument |
| `0x10458` / `0x11008` / `0x11300` | pthread wrappers: no arg / pointer arg / 32-bit value arg |
| `0x11820` | classifier / one-shot dispatcher |
| `0x11fe8` | steady-state entity enumerator |
| `0x16860` | entity sweep: writes `entity + 0x27BB0 = 0` for every entry in `bss+0x118`, then resets that list |

Threads are created detached (`pthread_detach` right after creation), so the
menu does not join them; they stop when the process exits or when their flag
clears.

### Who spawns what

Resolving each handler's `adrp`/`add` pair to its thread body gives:

| Change id | Handler | Thread body |
|---|---|---|
| 2 | `0xe718` | `0x10264` |
| 5 | `0xe800` | `0x1b7f8` trampoline |
| 9 | `0xe870` | `0x10728` |
| 12 | `0xe954` | `0x109b0` |
| 13 | `0xe648` | `0x10b48` |
| 14 | `0xe7a8` | `0x10db8` |
| 21 / 23 | `0xe8c8` / `0xeac0` | `0x110d8` |
| 25 | `0xe540` | `0x105d0` |
| 10 | `0x11820` classifier | `0x15ea0` |
| 11 | `0x11820` classifier | `0x1612c` |

The remaining toggles (6, 7, 8, 15) store their flag only and rely on the
always-running worker `0x11fe8`; they have no thread target of their own.

---

## 7. The entity scan

The classifier locates entities by matching a signature rather than by a fixed
address:

```
000119c4:  bl    #0x1cfe8              ; read64 candidate-0x10
000119e0:  bl    #0x1cfe8              ; read64 candidate-0x14
000119ec:  mov   x8, #0x1000100010001
000119f0:  movk  x8, #2
000119f4:  movk  x8, #0xffff, lsl #16  ; expect 0x0002FFFF000100010001000100010001
000119f8:  cmp   x28, x8
000119fc:  b.ne  #0x11aa0              ; reject
00011a04:  mov   x8, #0x200000000
00011a08:  movk  x8, #0xffff, lsl #48  ; expect 0xFFFF0000000000020000000000000000
00011a0c:  cmp   x24, x8
00011a10:  b.ne  #0x11aa0              ; reject
00011a1c:  sub   x1, x24, #0x1a8
00011a2c:  bl    #0x1cf40              ; read state word
00011a38:  cmp   w24, #0x100, lsl #12
00011a3c:  b.eq  #0x11a50
00011a40:  cbnz  w24, #0x11aa0
00011a44:  adrp  x8, #0xcb000
00011a48:  ldrb  w8, [x8, #0x188]
00011a4c:  cbz   w8, #0x11aa0
```

A candidate is accepted only when **both** 64-bit words match their exact
64-bit constants:

| Offset | Required 64-bit value |
|---|---|
| `candidate - 0x10` | `0x0002FFFF000100010001000100010001` |
| `candidate - 0x14` | `0xFFFF0000000000020000000000000000` |

and the state word at `candidate - 0x1A8` is either `0x100000` or `0` (with
Freeze Enemy enabled allowing the zero case).

This is a structural signature match over the actor class, so the scan does not
break when the game updates its memory layout as long as the vtable/shape
pattern is stable.
