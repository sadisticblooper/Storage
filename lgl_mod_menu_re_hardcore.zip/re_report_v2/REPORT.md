# LGL Mod Menu — full reverse-engineering walkthrough

This is the narrative pass: what the files are, how the analysis was done, what
was found, and where the earlier attempts went wrong. The per-feature detail
lives in `features/`, and the engine internals in `MISCELLANEOUS.md`.

---

## 1. What you actually have

Two files:

| File | Size class | What it is |
|---|---|---|
| `libsf4.so` | native ARM64 shared object | the real mod |
| `payload.dex` | Dalvik bytecode | the LGL menu's Java half |

The important thing up front: **`libsf4.so` does not need `payload.dex` to
work.** The library carries its own embedded DEX and loads it at runtime. The
standalone `payload.dex` is the extracted copy of that same menu code, which is
why "extract the dex" is the right instinct — it just turns out the library
already has it inlined.

### 1.1 The DEX inside the library

`libsf4.so` contains a DEX image. The loader path in `JNI_OnLoad` (`0x135b0`):

1. `ActivityThread.currentApplication()` -> the running `Application`;
2. wrap the embedded bytes in a `java.nio.ByteBuffer`;
3. `dalvik.system.InMemoryDexClassLoader` over that buffer;
4. reflectively instantiate `com.android.support.Menu`.

The JNI call trace captured in the emulator shows exactly those names, which is
the signature of the LGL (Lucky Mod Menu) framework. LGL is a mod-menu template:
it gives you a floating menu, a feature list, and a single `Changes` callback.
Recognising that template is what makes the rest of the analysis tractable,
because the string format and the callback contract are fixed.

### 1.2 The menu format

`GetFeatureList` returns a `String[]`. The framework parses each entry as:

```
<numericID>_<WidgetType>_<Label>
```

- `Toggle` -> a switch, reports 0/1
- `Spinner` -> a dropdown, reports the selected index
- `InputValue` -> a text box, reports the entered number
- `Button` -> a one-shot press
- `Category_something` -> a non-interactive header
- `Collapse_...` -> a collapsible group header
- `RichTextView_...` -> free text

The `numericID` is what gets passed to `Changes`. **The display order is not the
id order.** That single fact is the reason a naive reading of the menu gives a
wrong feature-to-code mapping.

---

## 2. How the analysis was done

Three techniques, and the honest answer is that all three were needed.

### 2.1 Static disassembly

`pyelftools` + `capstone` (ARM64). Dump `.text`, resolve the PLT, and read the
dispatch table. This gives addresses and structural facts cheaply.

The trap: `adrp`/`add` pairs. An `adrp` immediate is a **page delta**, so the
target is `(insn_addr & ~0xfff) + (imm << 12)`, then the `add` immediate is
added. Using the raw immediate without the shift silently lands on the wrong
page and produces plausible-looking garbage — which is exactly how the first
pass produced bogus "strings" such as `0x10db8`.

### 2.2 Emulation with Unicorn

This is what turned the analysis from guesswork into fact.

A minimal ARM64 machine is mapped, the ELF's `PT_LOAD` segments are placed, the
`.init_array` constructors are run, and then individual functions are entered
with a sentinel return address. A fake `JNIEnv`/`JavaVM` table is installed so
that native code calling JNI gets back plausible objects instead of crashing —
`NewStringUTF` returns a tagged pointer that the harness records, so anything the
code emits can be read back.

With that harness:

- `GetFeatureList` was **executed**, and the 26 returned strings printed
  verbatim. No guessing about what the menu shows.
- `Changes` was **executed** with different ids, and the resulting writes to
  `.bss` observed. This is how the id 14 vs id 15 question was finally closed.
- Each spinner's lazy-init block was **executed**, and the decrypted string read
  out. That is where the match-id values come from.

### 2.3 Verification by test

Every claim in `features/` is asserted by `artifacts/verify.py`: it re-reads the
dispatch table, re-scans for the flag `strb` sites, re-checks the apply-routine
constants, and re-resolves the sub-tables. It currently passes 94 assertions with
zero failures. If a future edit to the docs contradicts the binary, that script
will fail.

---

## 3. What the mod does

The library is a live memory editor for the game process. Its engine is:

| Operation | Routine | Mechanism |
|---|---|---|
| read 32-bit | `0x1cf40` | `process_vm_readv` |
| read 64-bit | `0x1cfe8` | `process_vm_readv` |
| write 32-bit | `0x1d108` | `process_vm_writev` |
| write float | `0x1d180` | `process_vm_writev` |

Syscall numbers `0x10e` (270) and `0x10f` (271). No `ptrace`, no
`/proc/<pid>/mem`. The pid comes from `getpid()` and is cached at
`context + 0x38` (see `MISCELLANEOUS.md`).

Above the engine sit threads:

- one long-lived worker (`0x11fe8`) that loops over the discovered entity lists
  and applies the steady-state writes for the toggles that need to be continuous
  (Immortal, Freeze, Max Shadow, One Hit Kill, Enemy No Ability, Max Time);
- a classifier (`0x11820`) that reads the enable flags each pass and starts the
  one-shot apply threads (Real Player Hack, Ling Hack) when appropriate;
- short-lived threads started directly by handlers that perform a single action
  (Long Range Hits, Summon AI, Speed Hack, One Hit Kill's immediate sweep,
  Max Time, the custom-rank inputs, Max Upgrade Character).

---

## 4. The features, one line each

| id | Label | Effect |
|---|---|---|
| 1 | Instant Win | `entity-0x24` -> `13` when it holds 1..12 (match result) |
| 2 | Long Range Hits | `entity+0x00` -> `288.0f` (attack reach) |
| 5 | Autowin | repeatedly drives the win trigger over the scan list |
| 6 | Immortal | `entity+0x1F78A50` -> `0x100000` (invulnerability) |
| 7 | Freeze Enemy | worker keeps `entity+0x1F78A50`; on disable sweeps `entity-0x1A8` |
| 8 | Max Shadow Ability | fills `entity+0x1F78A58` to `0x100000` only when it is 0 |
| 9 | Max Time | battle timer -> `0x71700000` float |
| 10 | Real Player Hack (PvP) | rewrites `entity+0`, `entity-0x2c`, `entity-0x28` |
| 11 | Ling Hack | forces character id 15 plus seed stats |
| 12 | Summon Ai Opponent | one-shot `entity+0x00` -> `0` |
| 13 | Speed Hack | records entities; disable restores `1.0f` |
| 14 | One Hit Kill | `entity+0x10` -> `0x077FFFEC` |
| 15 | Enemy No Ability | `entity+0x27BB8` -> `0` |
| 20 | 1v1 Match level | emits match-id strings |
| 21 | Level 5 (Custom Rank) | formats the typed level into a match id |
| 22 | 3v3 Match level | emits match-id strings |
| 23 | Level 5 (Custom Rank) | same mechanism as 21 |
| 24 | Event Only AI Enemy | selects an AI in an event-id bracket |
| 25 | Max Upgrade Character | `entity+0x00` -> `0xE00000` |

---

## 5. Where the earlier attempts went wrong

Recorded because knowing the failure modes is what makes the final numbers
trustworthy.

| Mistake | Cause | Fix |
|---|---|---|
| Feature 25 appeared to have no handler | assumed the dispatch range was ids 0..24 | read the prologue: `sub w8, w3, #1` + `cmp w8, #0x18` -> ids **1..25** |
| `0x10db8`, `0x15ea0`, `0x1612c` read as strings | `adrp` page math applied without the `<<12` | resolve `adrp` as `(pc & ~0xfff) + (imm << 12)` |
| "every toggle builds a string" | `0x10458` misread as a string builder | it is a `pthread_create` wrapper; the "literals" are thread bodies |
| ids 14/15 transposed, twice, in opposite directions | dispatch table read as absolute addresses | entries are **signed deltas from `0x700d0`**; confirmed by executing `Changes` |
| Max Shadow appeared to share Immortal's field | `add x21, x8, #8` overlooked | Max Shadow uses `+0x1F78A58`, Immortal/Freeze use `+0x1F78A50` |
| Freeze's `entity-0x1A8` write placed in the loop | off-branch not separated from the worker | it is a one-shot on the disable transition |

The last two are exactly the kind of error that a "looks plausible" static read
produces, and exactly what the emulator and the assertion script catch.

---

## 6. Reproducing this

Dependencies: Python 3, `capstone`, `unicorn`, `pyelftools`.

Scripts in `artifacts/`:

| Script | Purpose |
|---|---|
| `jnirun.py` | builds the Unicorn ARM64 machine and the fake JNI environment |
| `gfl.py` | runs `GetFeatureList` and `SettingsList`, prints the arrays |
| `spin2.py`, `spin4.py` | executes each spinner lazy-init block, prints decoded values |
| `writes2.py`, `ops.py` | extracts every `process_vm_*` call site with its arguments |
| `map.py` | resolves each handler's `adrp`/`add` to its thread body |
| `dispatch_test.py` | runs `Changes(id)` and reports which bss flag changed |
| `verify.py` | asserts every documented fact against the binary (94 checks) |
| `libsf4.disasm.txt` | full linear disassembly of `.text` for grepping |

To re-run the assertions:

```
python3 artifacts/verify.py
```

Expected output ends with `ALL OK`.

---


---

## Appendix A — the dispatch table, verbatim

Table at `0x700d0`, dumped directly: **[static]**

| id | handler | id | handler | id | handler |
|---|---|---|---|---|---|
| 1 | `0xe534` | 10 | `0xe8b4` | 19 | `0xf3f4` (default) |
| 2 | `0xe718` | 11 | `0xe970` | 20 | `0xe568` |
| 3 | `0xf3f4` (default) | 12 | `0xe954` | 21 | `0xe8c8` |
| 4 | `0xf3f4` (default) | 13 | `0xe648` | 22 | `0xe8f0` |
| 5 | `0xe800` | 14 | `0xe7a8` | 23 | `0xeac0` |
| 6 | `0xe7ec` | 15 | `0xe704` | 24 | `0xe984` |
| 7 | `0xe67c` | 16 | `0xf3f4` (default) | 25 | `0xe540` |
| 8 | `0xe794` | 17 | `0xf3f4` (default) | | |
| 9 | `0xe870` | 18 | `0xf3f4` (default) | | |


## Appendix B — handler to thread map

### The single long-lived worker

There is exactly one scan/registration site in the library:

```
00013630: adrp x12, #0x12000
00013648: add  x12, x12, #0xe64    ; 0x12e64  <- SettingsList
00013654: add  x8,  x8,  #0x4e0    ; 0x4e0    <- worker/registration routine
00013658: add  x2,  x2,  #0x658    ; 0x1658   <- thread trampoline
00013660: mov  x1, xzr
00013664: mov  x3, xzr
00013668: str  x19, [x20, #0x1a8]  ; store context/pid
0001366c: str  x12, [x11, #0x58]   ; 0xd7058 = SettingsList ptr
00013670: str  x8,  [x9,  #0x68]   ; 0xd8068 = worker ptr
00013674: bl   #0xc0f0             ; pthread_create(worker)
00013678: ldr  x0, [sp, #8]
0001367c: bl   #0xbcd0             ; pthread_detach
00013680: mov  w0, #3
00013684: bl   #0xc000             ; sleep(3)
```

Shortly after, the same routine exports the JNI entry points that the LGL
framework looks up by name:

- `0xd7058` ← `0x12e64` (`SettingsList`)
- `0xd8068` ← `0x4e0` (worker/registration)
- plus `GetFeatureList` and `Changes`.


---

## 7. Caveats, stated plainly

- The field **names** (`health`, `ability slot`, `attack reach`) are readings of
  the observed offsets and written values. The offsets, values, flags, threads,
  and control flow are certain and machine-checked; the human-language gloss on
  what each field means is the one place interpretation enters, and each feature
  file marks it as such.
- The offsets are for this build. They are structure-relative and the scan uses
  a 64-bit signature match rather than fixed addresses, so a game update that
  keeps the actor layout will keep working.
- `payload.dex` and the embedded DEX are the same menu; the report describes the
  behaviour from the native side, where the actual edits happen.
