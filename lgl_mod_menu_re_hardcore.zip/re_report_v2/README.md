# LGL Mod Menu — Feature Documentation Index (v2, verified)

One `.md` per menu entry, plus a miscellaneous file for the engine internals.
This version supersedes the first pass: every claim here was checked by running
the code in an emulator or by dumping the data tables directly, and the places
where the first pass was wrong are called out in the relevant files.

**Start here:** [REPORT.md](REPORT.md) — the full analysis, including the
corrections.

**Internals:** [MISCELLANEOUS.md](MISCELLANEOUS.md) — PID origin, memory engine,
loader, anti-analysis.

---

## The actual menu, as recovered

`GetFeatureList` returns one string per row. The format is
`"<numericID>_<WidgetType>_<Label>"`, and the numeric prefix is the id sent to
`Changes`. Display order does not match id order.

| id | Row | Widget | Handler |
|---|---|---|---|
| 1 | `1_Spinner_Instant Win` | Spinner (5) | `0xe534` |
| 2 | `2_Toggle_Long Range Hits` | Toggle | `0xe718` |
| 5 | `5_Toggle_Autowin` | Toggle | `0xe800` |
| 6 | `6_Toggle_Immortal` | Toggle | `0xe7ec` |
| 7 | `7_Toggle_Freeze Enemy` | Toggle | `0xe67c` |
| 8 | `8_Toggle_Max Shadow Ability` | Toggle | `0xe794` |
| 9 | `9_Toggle_Max Time` | Toggle | `0xe870` |
| 10 | `10_Toggle_Real Player Hack (PvP)` | Toggle | `0xe8b4` |
| 11 | `11_Toggle_Ling Hack` | Toggle | `0xe970` |
| 12 | `12_Button_Summon Ai Opponent` | Button | `0xe954` |
| 13 | `13_Toggle_Speed Hack` | Toggle | `0xe648` |
| 14 | `14_Toggle_One Hit Kill` | Toggle | `0xe7a8` |
| 15 | `15_Toggle_Enemy No Ability` | Toggle | `0xe704` |
| 20 | `20_Spinner_1v1 Match` | Spinner (4) | `0xe568` |
| 21 | `21_InputValue_Level 5 (Custom Rank)` | Input | `0xe8c8` |
| 22 | `22_Spinner_3v3 Match` | Spinner (4) | `0xe8f0` |
| 23 | `23_InputValue_Level 5 (Custom Rank)` | Input | `0xeac0` |
| 24 | `24_Spinner_Event Only AI Enemy` | Spinner (7) | `0xe984` |
| 25 | `25_InputValue_Max Upgrade Character` | Input | `0xe540` |

Non-feature rows (category headers and the note) have no id:
`Category_Player Hack`, `Category_Enemy Hack`, `Category_Character Hacks`,
`Category_Battle Hacks`, `Category_Rank Mode`, `Collapse_Real Player to AI`,
`RichTextView_NOTE…`.

---

## Feature files

| # | File | What it really writes |
|---|---|---|
| 1 | [features/01_instant_win.md](features/01_instant_win.md) | `entity-0x24` = `13` when it currently holds 1..12 |
| 2 | [features/02_long_range_hits.md](features/02_long_range_hits.md) | `entity+0x00` = `288.0f` |
| 5 | [features/05_autowin.md](features/05_autowin.md) | win-trigger over the scan list; flag `bss+0x180` |
| 6 | [features/06_immortal.md](features/06_immortal.md) | `entity+0x1F78A50` = `0x100000` |
| 7 | [features/07_freeze_enemy.md](features/07_freeze_enemy.md) | worker: `entity+0x1F78A50` = `0x100000`; disable sweep: `entity-0x1A8` = `0x100000` |
| 8 | [features/08_max_shadow_ability.md](features/08_max_shadow_ability.md) | `entity+0x1F78A58` = `0x100000`, only if currently 0 |
| 9 | [features/09_max_time.md](features/09_max_time.md) | timer field = `0x71700000` float |
| 10 | [features/10_real_player_hack_pvp.md](features/10_real_player_hack_pvp.md) | `entity+0` = `0x5FFFC8`, `entity-0x2c` = `0`, `entity-0x28` = `100000` |
| 11 | [features/11_ling_hack.md](features/11_ling_hack.md) | `entity+0` = `15`, `entity-4` = `10`, `entity+4` = `1`, `entity+0xc` = `0`, `entity+0x10` = `0` |
| 12 | [features/12_summon_ai_opponent.md](features/12_summon_ai_opponent.md) | `entity+0x00` = `0` (one-shot) |
| 13 | [features/13_speed_hack.md](features/13_speed_hack.md) | records entities; on disable restores `1.0f` |
| 14 | [features/14_one_hit_kill.md](features/14_one_hit_kill.md) | `entity+0x10` = `0x077FFFEC` |
| 15 | [features/15_enemy_no_ability.md](features/15_enemy_no_ability.md) | `entity+0x27BB8` = `0` |
| 20 | [features/20_rank_1v1_level.md](features/20_rank_1v1_level.md) | match-id strings `0x9600000000` … `0xafc800000001` |
| 21 | [features/21_rank_1v1_custom_level5.md](features/21_rank_1v1_custom_level5.md) | formatted custom level |
| 22 | [features/22_rank_3v3_level.md](features/22_rank_3v3_level.md) | match-id strings `0x753000000001` … `0x1d4c000000001` |
| 23 | [features/23_rank_3v3_custom_level5.md](features/23_rank_3v3_custom_level5.md) | formatted custom level (same thread as 21) |
| 24 | [features/24_event_only_ai_enemy.md](features/24_event_only_ai_enemy.md) | event bracket pairs `40000`/`50000` … `180000`/`190000` |
| 25 | [features/25_max_upgrade_character.md](features/25_max_upgrade_character.md) | `entity+0x00` = `0xE00000` |
| — | [features/00_settings_save_prefs.md](features/00_settings_save_prefs.md) | Java only |
| — | [features/00_settings_auto_size.md](features/00_settings_auto_size.md) | Java only |
| — | [features/00_settings_close.md](features/00_settings_close.md) | Java only |
| — | [features/99_unused_ids.md](features/99_unused_ids.md) | ids 3, 4, 16–19 are unallocated |

---

## Corrections made in this version

1. **ids 14/15 are settled.** They are adjacent in the dispatch table and were
   transposed twice during analysis, so the pairing is now confirmed three
   independent ways that agree: running `Changes` itself in the emulator
   (`w3=14` sets `0xcb1a0`, `w3=15` sets `0xcb1a4`), the signed deltas in the
   table (`0x700e8` -> `0xe7a8`, `0x700ec` -> `0xe704`), and a scan for the
   only `strb` to each flag. Result: **14 = One Hit Kill** (`0xe7a8`,
   `entity+0x10 = 0x077FFFEC`), **15 = Enemy No Ability** (`0xe704`,
   `entity+0x27BB8 = 0`).
2. **Feature 25 does have a handler.** The `Changes` range is ids 1..25
   (`sub w8, w3, #1` + `cmp w8, #0x18`), not 0..24, and id 25 dispatches to
   `0xe540`.
3. **Event AI Enemy's option values were corrected.** There is not one
   constant per spinner row: each option carries a lower/upper pair, and the
   `6th` and `5th` entries share the tail at `0xf160`, so they resolve to the
   same pair. Measured: `40000`/`50000`, `55000`/`65000`, `85000`/`95000`,
   `100000`/`110000`, `120000`/`130000`, `120000`/`130000`, `180000`/`190000`.
4. **The `bl 0x10458` calls are `pthread_create`, not string building.** The
   library spawns real worker threads; they are not functor objects.
5. **Freeze Enemy's `entity-0x1A8` write happens on the disable transition**,
   not continuously.
6. **Max Shadow Ability is a read-modify-write on a different field**
   (`+0x1F78A58`), not a blind store on the same field as Immortal/Freeze.
7. **Every payload value in this version was decoded by execution**, not read
   out of a static table. The `adrp` page math in the first pass was wrong.

---

## Key addresses

| Item | Address |
|---|---|
| `Changes` | `0xe4e0` |
| `Changes` dispatch table | `0x700d0` (ids 1..25) |
| `GetFeatureList` | `0xc9b0` |
| `SettingsList` | `0x12e64` |
| `JNI_OnLoad` | `0x135b0` |
| classifier | `0x11820` |
| worker enumerator | `0x11fe8` |
| read32 / read64 | `0x1cf40` / `0x1cfe8` |
| write32 / write float | `0x1d108` / `0x1d180` |
| `getpid` | `0xbec0` |
| `syscall` | `0xc190` |
| `pthread_create` | `0xc0f0` |
"""
